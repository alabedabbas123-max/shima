package com.blankj.utilcode.util;

import android.content.Context;
import android.util.AttributeSet;

public class ToastUtils$UtilsMaxWidthRelativeLayout extends android.widget.RelativeLayout {
  public ToastUtils$UtilsMaxWidthRelativeLayout(Context c) {
    super(c);
  }

  public ToastUtils$UtilsMaxWidthRelativeLayout(Context c, AttributeSet a) {
    super(c, a);
  }

  public ToastUtils$UtilsMaxWidthRelativeLayout(Context c, AttributeSet a, int s) {
    super(c, a, s);
  }
}
