package com.shima.demo;

import android.app.*;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.MenuItem;
import android.widget.Toast;

/** Arabic settings screen. It is opened explicitly from the Settings command only. */
public class SettingsActivity extends Activity {
  @Override
  public void onCreate(Bundle state) {
    super.onCreate(state);
    setContentView(R.layout.activity_settings);
    setTitle(R.string.settings_title);
    ActionBar bar = getActionBar();
    if (bar != null) {
      bar.setDisplayHomeAsUpEnabled(true);
      bar.setHomeAsUpIndicator(R.drawable.ic_navigation_back);
      bar.setBackgroundDrawable(new ColorDrawable(Color.rgb(34, 34, 34)));
    }
    getWindow().setStatusBarColor(Color.BLACK);
    getWindow().setNavigationBarColor(Color.rgb(35, 35, 35));
    findViewById(R.id.settingsColors)
        .setOnClickListener(v -> startActivity(new Intent(this, ThemeActivity.class)));
    findViewById(R.id.settingsPermissions).setOnClickListener(v -> openPermissions());
    findViewById(R.id.settingsFont)
        .setOnClickListener(
            v ->
                Toast.makeText(this, getString(R.string.settings_font_size), Toast.LENGTH_SHORT)
                    .show());
    findViewById(R.id.settingsCompletion)
        .setOnClickListener(
            v ->
                Toast.makeText(this, getString(R.string.settings_completion), Toast.LENGTH_SHORT)
                    .show());
    findViewById(R.id.settingsSession)
        .setOnClickListener(
            v ->
                Toast.makeText(this, getString(R.string.settings_session), Toast.LENGTH_SHORT)
                    .show());
  }

  private void openPermissions() {
    try {
      Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
      intent.setData(Uri.parse("package:" + getPackageName()));
      startActivity(intent);
    } catch (Exception error) {
      Toast.makeText(this, R.string.settings_permissions, Toast.LENGTH_SHORT).show();
    }
  }

  @Override
  public boolean onOptionsItemSelected(MenuItem item) {
    if (item.getItemId() == android.R.id.home) {
      finish();
      return true;
    }
    return super.onOptionsItemSelected(item);
  }
}
