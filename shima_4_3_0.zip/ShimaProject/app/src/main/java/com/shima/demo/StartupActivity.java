package com.shima.demo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

/**
 * Invisible router: normal launches go directly to the IDE; recovery is shown only after a crash.
 */
public class StartupActivity extends Activity {
  @Override
  public void onCreate(Bundle state) {
    super.onCreate(state);
    String lastError = CrashStore.read(this);
    Class<?> destination = lastError.isEmpty() ? MainActivity.class : RecoveryActivity.class;
    startActivity(new Intent(this, destination));
    finish();
  }
}
