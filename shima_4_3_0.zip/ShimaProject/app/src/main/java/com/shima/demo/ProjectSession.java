package com.shima.demo;

import android.content.Context;
import java.io.File;

/** Small persistent description of the active project; no project files are copied. */
public final class ProjectSession {
  private final Context context;
  private String name = "", path = "";

  public ProjectSession(Context c) {
    context = c.getApplicationContext();
    name = prefs().getString("name", "");
    path = prefs().getString("path", "");
  }

  public void open(String projectName, String projectPath) {
    name = projectName == null ? "" : projectName;
    path = projectPath == null ? "" : projectPath;
    prefs().edit().putString("name", name).putString("path", path).apply();
  }

  public void clear() {
    name = "";
    path = "";
    prefs().edit().clear().apply();
  }

  public boolean isOpen() {
    return !name.isEmpty() && !path.isEmpty();
  }

  public String name() {
    return name;
  }

  public String path() {
    return path;
  }

  public File directory() {
    return path.startsWith("/") ? new File(path) : null;
  }

  public boolean hasGradleWrapper() {
    File d = directory();
    return d != null && new File(d, "gradlew").isFile();
  }

  private android.content.SharedPreferences prefs() {
    return context.getSharedPreferences("project_session", Context.MODE_PRIVATE);
  }
}
