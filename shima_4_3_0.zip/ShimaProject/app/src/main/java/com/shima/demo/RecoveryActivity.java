package com.shima.demo;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.widget.*;

/** Error UI shown instead of silently closing the application. */
public class RecoveryActivity extends Activity {
  int dp(int v) {
    return (int) (v * getResources().getDisplayMetrics().density + .5f);
  }

  @Override
  public void onCreate(Bundle state) {
    super.onCreate(state);
    getWindow().setStatusBarColor(Color.rgb(120, 35, 35));
    LinearLayout page = new LinearLayout(this);
    page.setOrientation(LinearLayout.VERTICAL);
    page.setPadding(dp(20), dp(24), dp(20), dp(16));
    page.setBackgroundColor(Color.rgb(25, 25, 25));
    TextView title = new TextView(this);
    title.setText("تعذر فتح واجهة البرمجة");
    title.setTextColor(Color.WHITE);
    title.setTextSize(23);
    title.setTypeface(null, Typeface.BOLD);
    page.addView(title);
    TextView help = new TextView(this);
    help.setText(
        "لم يُغلق التطبيق دون توضيح. تفاصيل الخطأ موجودة أدناه ويمكن متابعة العمل بالوضع الآمن.");
    help.setTextColor(Color.LTGRAY);
    help.setTextSize(14);
    help.setPadding(0, dp(8), 0, dp(14));
    page.addView(help);
    TextView error = new TextView(this);
    String value = CrashStore.read(this);
    error.setText(value.isEmpty() ? "لا توجد تفاصيل محفوظة." : value);
    error.setTextColor(Color.rgb(255, 180, 180));
    error.setTextSize(11);
    error.setTypeface(Typeface.MONOSPACE);
    error.setTextIsSelectable(true);
    ScrollView log = new ScrollView(this);
    log.addView(error);
    page.addView(log, new LinearLayout.LayoutParams(-1, 0, 1));
    Button safe = new Button(this);
    safe.setText("متابعة بالوضع الآمن");
    safe.setOnClickListener(
        v ->
            startActivity(
                new Intent(this, MainActivity.class)
                    .putExtra("safe_mode", true)
                    .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)));
    page.addView(safe);
    Button retry = new Button(this);
    retry.setText("إعادة محاولة فتح الواجهة");
    retry.setOnClickListener(
        v -> {
          CrashStore.clear(this);
          startActivity(
              new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
        });
    page.addView(retry);
    Button home = new Button(this);
    home.setText("العودة إلى شاشة الفحص");
    home.setOnClickListener(
        v ->
            startActivity(
                new Intent(this, StartupActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)));
    page.addView(home);
    setContentView(page);
  }
}
