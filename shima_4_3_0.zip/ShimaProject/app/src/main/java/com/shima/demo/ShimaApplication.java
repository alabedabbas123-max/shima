package com.shima.demo;

import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Process;
import java.util.Locale;

/** Global last-resort crash handler. Errors are saved and opened in RecoveryActivity. */
public class ShimaApplication extends Application {
  @Override
  protected void attachBaseContext(Context base) {
    Locale arabic = new Locale("ar");
    Locale.setDefault(arabic);
    Configuration configuration = new Configuration(base.getResources().getConfiguration());
    configuration.setLocale(arabic);
    base.getResources().updateConfiguration(configuration, base.getResources().getDisplayMetrics());
    super.attachBaseContext(base.createConfigurationContext(configuration));
  }

  @Override
  public void onConfigurationChanged(Configuration configuration) {
    super.onConfigurationChanged(configuration);
    Locale arabic = new Locale("ar");
    Locale.setDefault(arabic);
    Configuration localized = new Configuration(configuration);
    localized.setLocale(arabic);
    getResources().updateConfiguration(localized, getResources().getDisplayMetrics());
  }

  @Override
  public void onCreate() {
    super.onCreate();
    Thread.UncaughtExceptionHandler fallback = Thread.getDefaultUncaughtExceptionHandler();
    Thread.setDefaultUncaughtExceptionHandler(
        (thread, error) -> {
          if (isDeadSystem(error)) {
            Process.killProcess(Process.myPid());
            return;
          }
          try {
            CrashStore.save(this, error);
            Intent intent =
                new Intent(this, RecoveryActivity.class)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            Thread.sleep(250);
          } catch (Throwable ignored) {
            if (fallback != null) fallback.uncaughtException(thread, error);
          }
          Process.killProcess(Process.myPid());
          System.exit(10);
        });
  }

  private boolean isDeadSystem(Throwable error) {
    for (Throwable current = error; current != null; current = current.getCause()) {
      String name = current.getClass().getName();
      if (name.endsWith("DeadSystemException") || name.endsWith("DeadSystemRuntimeException"))
        return true;
    }
    return false;
  }
}
