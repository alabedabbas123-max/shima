package com.shima.demo;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import java.util.LinkedHashMap;
import java.util.Map;

/** Persistent editor/browser color scheme with built-in dark and light defaults. */
public final class ThemeConfig {
  public static final String BACKGROUND = "background";
  public static final String PLAIN = "plain";
  public static final String KEYWORD = "keyword";
  public static final String IDENTIFIER = "identifier";
  public static final String FUNCTION = "function";
  public static final String VARIABLE = "variable";
  public static final String LITERAL = "literal";
  public static final String OPERATOR = "operator";
  public static final String TYPE = "type";
  public static final String NAMESPACE = "namespace";
  public static final String SEPARATOR = "separator";
  public static final String COMMENT = "comment";
  public static final String LINE_NUMBER = "line_number";
  public static final String SELECTED_LINE = "selected_line";
  public static final String SELECTED_TEXT = "selected_text";

  private static final String PREFS = "shima_color_scheme";
  private static final String SCHEME = "scheme";
  private final SharedPreferences preferences;

  public ThemeConfig(Context context) {
    preferences = context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
  }

  public boolean isDark() {
    return !"light".equals(preferences.getString(SCHEME, "dark"));
  }

  public String schemeName(Context context) {
    return context.getString(isDark() ? R.string.color_scheme_dark : R.string.color_scheme_light);
  }

  public void reset(boolean dark) {
    preferences.edit().clear().putString(SCHEME, dark ? "dark" : "light").apply();
  }

  public int color(String key) {
    int fallback = defaults(isDark()).get(key);
    return preferences.getInt("color_" + key, fallback);
  }

  public void setColor(String key, int color) {
    preferences.edit().putInt("color_" + key, color).apply();
  }

  public void resetColor(String key) {
    preferences.edit().remove("color_" + key).apply();
  }

  public int defaultColor(String key) {
    Integer value = defaults(isDark()).get(key);
    return value == null ? Color.WHITE : value;
  }

  public String hex(String key) {
    return String.format("#%08X", color(key));
  }

  public static int parseColor(String value) {
    String text = value == null ? "" : value.trim();
    if (!text.startsWith("#")) text = "#" + text;
    if (text.length() == 7) text = "#FF" + text.substring(1);
    if (text.length() != 9) throw new IllegalArgumentException("Use #AARRGGBB");
    return Color.parseColor(text);
  }

  public static LinkedHashMap<String, String> labels(Context context) {
    LinkedHashMap<String, String> labels = new LinkedHashMap<>();
    labels.put(BACKGROUND, context.getString(R.string.color_scheme_background));
    labels.put(PLAIN, context.getString(R.string.color_scheme_plain));
    labels.put(KEYWORD, context.getString(R.string.color_scheme_keyword));
    labels.put(TYPE, context.getString(R.string.color_scheme_type));
    labels.put(FUNCTION, context.getString(R.string.color_scheme_function));
    labels.put(VARIABLE, context.getString(R.string.color_scheme_variable));
    labels.put(IDENTIFIER, context.getString(R.string.color_scheme_identifier));
    labels.put(LITERAL, context.getString(R.string.color_scheme_literal));
    labels.put(OPERATOR, context.getString(R.string.color_scheme_operator));
    labels.put(NAMESPACE, context.getString(R.string.color_scheme_namespace));
    labels.put(SEPARATOR, context.getString(R.string.color_scheme_separator));
    labels.put(COMMENT, context.getString(R.string.color_scheme_comment));
    labels.put(LINE_NUMBER, context.getString(R.string.color_scheme_line_number));
    labels.put(SELECTED_LINE, context.getString(R.string.color_scheme_selected_line));
    labels.put(SELECTED_TEXT, context.getString(R.string.color_scheme_selected_text));
    return labels;
  }

  private static Map<String, Integer> defaults(boolean dark) {
    LinkedHashMap<String, Integer> colors = new LinkedHashMap<>();
    if (dark) {
      colors.put(BACKGROUND, 0xFF000000);
      colors.put(PLAIN, 0xFFFFFFFF);
      colors.put(KEYWORD, 0xFFFF5252);
      colors.put(IDENTIFIER, 0xFFECEFF1);
      colors.put(FUNCTION, 0xFF82AAFF);
      colors.put(VARIABLE, 0xFFFFD740);
      colors.put(LITERAL, 0xFF8BC34A);
      colors.put(OPERATOR, 0xFFEC407A);
      colors.put(TYPE, 0xFF23BBFF);
      colors.put(NAMESPACE, 0xFFFFD740);
      colors.put(SEPARATOR, 0xFF4DD0E1);
      colors.put(COMMENT, 0xFF04DA2B);
      colors.put(LINE_NUMBER, 0xFF23BBFF);
      colors.put(SELECTED_LINE, 0x00000000);
      colors.put(SELECTED_TEXT, 0xFF2E94C2);
    } else {
      colors.put(BACKGROUND, 0xFFFFFFFF);
      colors.put(PLAIN, 0xFF202124);
      colors.put(KEYWORD, 0xFFD32F2F);
      colors.put(IDENTIFIER, 0xFF37474F);
      colors.put(FUNCTION, 0xFF6F42C1);
      colors.put(VARIABLE, 0xFF795548);
      colors.put(LITERAL, 0xFF388E3C);
      colors.put(OPERATOR, 0xFFC2185B);
      colors.put(TYPE, 0xFF0277BD);
      colors.put(NAMESPACE, 0xFFF57F17);
      colors.put(SEPARATOR, 0xFF00838F);
      colors.put(COMMENT, 0xFF2E7D32);
      colors.put(LINE_NUMBER, 0xFF0288D1);
      colors.put(SELECTED_LINE, 0xFFE3F2FD);
      colors.put(SELECTED_TEXT, 0xFF90CAF9);
    }
    return colors;
  }
}
