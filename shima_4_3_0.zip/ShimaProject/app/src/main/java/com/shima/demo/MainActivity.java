package com.shima.demo;

import android.app.*;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v4.widget.DrawerLayout;
import android.view.*;
import android.widget.*;
import com.almlkid.kay.ui.ProjectSymbolIndex;
import com.almlkid.kay.view.VPDrawerLayout;
import com.almlkid.ui.AIDEEditorPager;
import com.almlkid.ui.browsers.BrowserPager;
import java.io.File;
import java.util.*;

/** Java controller for the original res/layout/main_drawer.xml screen. */
public class MainActivity extends Activity
    implements BrowserPager.ActionListener, CommandCenter.Host {
  VPDrawerLayout drawer;
  AIDEEditorPager editor;
  BrowserPager browser;
  ImageButton masterButton;
  View moreActionView;
  PopupWindow ideMenuWindow;
  View empty;
  boolean projectOpen = false;
  final CommandCenter commands = new CommandCenter();
  final ShellCommandRunner shell = new ShellCommandRunner();
  ProjectSession session;
  AlertDialog requiredStorageDialog;

  @Override
  public void onCreate(Bundle state) {
    super.onCreate(state);
    getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
    getWindow().setStatusBarColor(Color.BLACK);
    getWindow().setNavigationBarColor(Color.rgb(35, 35, 35));
    if (getIntent().getBooleanExtra("safe_mode", false)) {
      showSafeMode();
      return;
    }
    try {
      session = new ProjectSession(this);
      setContentView(R.layout.main_drawer);
      configureActionBar();
      drawer = findViewById(R.id.mainDrawerLayout);
      editor = findViewById(R.id.mainCodePageView);
      browser = findViewById(R.id.mainBrowserPager);
      empty = findViewById(R.id.mainCodeEmptyView);
      if (drawer == null || editor == null || browser == null || empty == null)
        throw new IllegalStateException("main_drawer.xml is missing a required view");
      browser.setOnFileSelectedListener(
          (name, content) -> {
            drawer.closeDrawers();
            openFile(name, content);
          });
      browser.setActionListener(this);
      editor.setQuickFixListener(this::confirmCreateMissingMember);
      editor.setDefinitionListener(this::openDefinition);
      masterButton = findViewById(R.id.mainMasterButton);
      if (masterButton != null) {
        masterButton.setOnClickListener(v -> showCommands());
        hideMasterButtonWithKeyboard(masterButton);
      }
      ProgressBar progress = findViewById(R.id.mainErrorProgress);
      if (progress != null) progress.setVisibility(View.GONE);
      configureDrawer();
      applySelectedTheme();
      showNoProject();
      editor.restoreSessionAsync(
          restored -> {
            if (!restored) return;
            projectOpen = true;
            empty.setVisibility(View.GONE);
            editor.setVisibility(View.VISIBLE);
            if (masterButton != null) masterButton.setVisibility(View.VISIBLE);
            browser.indexProjectSymbols(editor::refreshSemanticDiagnostics);
          });
      browser.postDelayed(this::showPermissionsCenterOnFirstRun, 500);
    } catch (Throwable error) {
      CrashStore.save(this, error);
      showStartupError(error);
    }
  }

  void configureActionBar() {
    ActionBar b = getActionBar();
    if (b == null) return;
    b.setTitle("المشروع الحالي");
    b.setSubtitle("بيئة البرمجة العربية");
    b.setBackgroundDrawable(new ColorDrawable(Color.rgb(34, 34, 34)));
    b.setDisplayHomeAsUpEnabled(true);
    b.setHomeButtonEnabled(true);
    b.setHomeAsUpIndicator(R.drawable.ic_navigation_menu);
  }

  void applySelectedTheme() {
    ThemeConfig theme = new ThemeConfig(this);
    int background = theme.color(ThemeConfig.BACKGROUND);
    int chrome = Color.rgb(34, 34, 34);
    getWindow().setStatusBarColor(theme.isDark() ? Color.BLACK : Color.rgb(224, 224, 224));
    getWindow()
        .setNavigationBarColor(theme.isDark() ? Color.rgb(35, 35, 35) : Color.rgb(224, 224, 224));
    ActionBar bar = getActionBar();
    if (bar != null) bar.setBackgroundDrawable(new ColorDrawable(chrome));
    if (empty != null) empty.setBackgroundColor(background);
    if (editor != null) editor.applyTheme();
    if (browser != null) browser.applyTheme();
  }

  void configureDrawer() {
    drawer.setScrimColor(Color.BLACK);
    drawer.addDrawerListener(
        new DrawerLayout.SimpleDrawerListener() {
          @Override
          public void onDrawerOpened(View v) {
            getActionBar().setHomeAsUpIndicator(R.drawable.ic_navigation_back);
            invalidateOptionsMenu();
          }

          @Override
          public void onDrawerClosed(View v) {
            getActionBar().setHomeAsUpIndicator(R.drawable.ic_navigation_menu);
            invalidateOptionsMenu();
          }
        });
    browser.post(
        () -> {
          View parent = (View) browser.getParent();
          ViewGroup.LayoutParams p = parent.getLayoutParams();
          p.width = getResources().getDisplayMetrics().widthPixels - dp(60);
          parent.setLayoutParams(p);
        });
  }

  void showNoProject() {
    projectOpen = false;
    empty.setVisibility(View.VISIBLE);
    editor.setVisibility(View.GONE);
    if (masterButton != null) masterButton.setVisibility(View.GONE);
    getActionBar().setTitle("المشروع الحالي");
    getActionBar().setSubtitle("بيئة البرمجة العربية");
  }

  void openFile(String file) {
    openFile(file, null);
  }

  void openFile(String file, String content) {
    projectOpen = true;
    empty.setVisibility(View.GONE);
    if (content == null) editor.openFile(file);
    else editor.openFile(file, content);
    if (masterButton != null) masterButton.setVisibility(View.VISIBLE);
    getActionBar().setTitle(file);
    getActionBar().setSubtitle("المشروع المفتوح");
  }

  @Override
  public void onProjectOpened(String name, String path) {
    projectOpen = true;
    session.open(name, path);
    boolean hasOpenFile = editor.hasOpenFile();
    empty.setVisibility(hasOpenFile ? View.GONE : View.VISIBLE);
    editor.setVisibility(hasOpenFile ? View.VISIBLE : View.GONE);
    if (masterButton != null) masterButton.setVisibility(hasOpenFile ? View.VISIBLE : View.GONE);
    getActionBar().setTitle(name);
    getActionBar().setSubtitle("مشروع Android");
    browser.indexProjectSymbols(editor::refreshSemanticDiagnostics);
  }

  private void openDefinition(ProjectSymbolIndex.DefinitionTarget definition) {
    if (definition == null) return;
    if (definition.source == null
        && definition.fileName != null
        && definition.fileName.equals(editor.getActiveFile())) {
      editor.goToOffset(definition.offset);
      return;
    }
    browser.openDefinition(
        definition,
        (success, fileName, content, offset, message) -> {
          Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
          if (!success || fileName == null || content == null) return;
          openFile(fileName, content);
          editor.goToOffset(offset);
        });
  }

  private void confirmCreateMissingMember(ProjectSymbolIndex.MissingMember member) {
    StringBuilder signature = new StringBuilder();
    signature.append(member.returnType).append(' ').append(member.methodName).append('(');
    for (int i = 0; i < member.parameters.size(); i++) {
      if (i > 0) signature.append(", ");
      ProjectSymbolIndex.Parameter parameter = member.parameters.get(i);
      signature.append(parameter.type).append(' ').append(parameter.name);
    }
    signature.append(')');
    new AlertDialog.Builder(this)
        .setTitle("تعديل الملفات")
        .setMessage(
            "هل تريد إنشاء الدالة التالية؟\n\n" + member.className + ".java\n\n" + signature)
        .setNegativeButton("لا", null)
        .setPositiveButton(
            "نعم",
            (dialog, which) ->
                browser.createMissingMember(
                    member,
                    (success, fileName, content, message) -> {
                      Toast.makeText(this, message, Toast.LENGTH_LONG).show();
                      if (success) {
                        openFile(fileName, content);
                        editor.refreshSemanticDiagnostics();
                      }
                    }))
        .show();
  }

  @Override
  public boolean onCreateOptionsMenu(Menu menu) {
    menu.clear();
    menu.add(0, 1, 0, getString(R.string.command_run))
        .setIcon(R.drawable.ic_vectoric_run)
        .setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
    menu.add(0, 2, 1, getString(R.string.command_edit))
        .setIcon(R.drawable.ic_vectoric_edit)
        .setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
    MenuItem more = menu.add(0, 3, 2, getString(R.string.menu_more));
    ImageButton button = new ImageButton(this);
    button.setImageResource(R.drawable.ic_vectoric_more);
    button.setContentDescription(getString(R.string.menu_more));
    button.setBackgroundColor(Color.TRANSPARENT);
    button.setPadding(dp(12), dp(12), dp(12), dp(12));
    button.setOnClickListener(v -> showIdeRootMenu(v));
    moreActionView = button;
    more.setActionView(button);
    more.setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
    return true;
  }

  @Override
  public boolean onOptionsItemSelected(MenuItem item) {
    if (item.getItemId() == android.R.id.home) {
      if (drawer.isDrawerOpen(Gravity.LEFT)) drawer.closeDrawers();
      else openBrowser();
      return true;
    }
    if (item.getItemId() == 1) {
      runProject();
      return true;
    }
    if (item.getItemId() == 2) {
      if (projectOpen) Toast.makeText(this, "Edit mode", Toast.LENGTH_SHORT).show();
      else openBrowser();
      return true;
    }
    if (item.getItemId() == 3) {
      showIdeRootMenu(moreActionView != null ? moreActionView : masterButton);
      return true;
    }
    return super.onOptionsItemSelected(item);
  }

  @Override
  public void onCreateProject() {
    drawer.closeDrawers();
    View v = getLayoutInflater().inflate(R.layout.createproject, null);
    TextView type = v.findViewById(R.id.createprojectType),
        location = v.findViewById(R.id.createprojectLocation);
    EditText name = v.findViewById(R.id.createprojectName),
        pkg = v.findViewById(R.id.createprojectPackage);
    type.setText("تطبيق أندرويد");
    location.setText("/storage/emulated/0/AppProjects");
    name.setText("");
    pkg.setText("");
    new AlertDialog.Builder(this)
        .setTitle("إنشاء مشروع جديد")
        .setView(v)
        .setNegativeButton("إلغاء", null)
        .setPositiveButton(
            "إنشاء",
            (d, w) -> {
              projectOpen = true;
              openFile("MainActivity.java");
              Toast.makeText(this, "تم إنشاء المشروع", Toast.LENGTH_SHORT).show();
            })
        .show();
  }

  @Override
  public void onCloneGit() {
    drawer.closeDrawers();
    View v = getLayoutInflater().inflate(R.layout.gitclonerepository, null);
    ((TextView) v.findViewById(R.id.gitclonerepositoryLocation))
        .setText("/storage/emulated/0/AppProjects");
    ((EditText) v.findViewById(R.id.gitclonerepositoryUrl)).setText("");
    ((EditText) v.findViewById(R.id.gitclonerepositoryDirectoryName)).setText("");
    new AlertDialog.Builder(this)
        .setTitle("استنساخ مستودع Git")
        .setView(v)
        .setNegativeButton("إلغاء", null)
        .setPositiveButton(
            "استنساخ",
            (d, w) -> Toast.makeText(this, "جارِ استنساخ المستودع…", Toast.LENGTH_SHORT).show())
        .show();
  }

  void openBrowser() {
    if (drawer != null) drawer.openDrawer(Gravity.LEFT);
  }

  @Override
  public void onStoragePermissionRequested() {
    showPermissionsCenter();
  }

  private void showPermissionsCenterOnFirstRun() {
    ensureRequiredStorageAccess();
  }

  private void ensureRequiredStorageAccess() {
    if (browser == null || !browser.needsProjectFolderSelection()) {
      if (requiredStorageDialog != null && requiredStorageDialog.isShowing()) {
        requiredStorageDialog.dismiss();
      }
      return;
    }
    if (isFinishing() || (requiredStorageDialog != null && requiredStorageDialog.isShowing()))
      return;

    requiredStorageDialog =
        new AlertDialog.Builder(this)
            .setTitle("السماح بالوصول إلى ملفات المشاريع")
            .setMessage(
                "يحتاج Shima إلى صلاحية قراءة مجلد المشاريع حتى تظهر الملفات داخل المجلدات."
                    + " اختر مجلد AppProjects من منتقي النظام، أو امنح الوصول لجميع الملفات.")
            .setPositiveButton("اختيار مجلد المشاريع", (dialog, which) -> onSelectProjectFolder())
            .setNeutralButton("الوصول لجميع الملفات", (dialog, which) -> openAllFilesSettings())
            .create();
    requiredStorageDialog.setCancelable(false);
    requiredStorageDialog.setCanceledOnTouchOutside(false);
    requiredStorageDialog.show();
  }

  private void showPermissionsCenter() {
    String files =
        android.os.Build.VERSION.SDK_INT < 30 || android.os.Environment.isExternalStorageManager()
            ? "✓ الوصول لجميع الملفات"
            : "الوصول لجميع الملفات";
    String installs =
        android.os.Build.VERSION.SDK_INT < 26 || getPackageManager().canRequestPackageInstalls()
            ? "✓ تثبيت ملفات APK"
            : "تثبيت ملفات APK";
    String overlay =
        android.os.Build.VERSION.SDK_INT < 23 || android.provider.Settings.canDrawOverlays(this)
            ? "✓ الظهور فوق التطبيقات"
            : "الظهور فوق التطبيقات";
    android.os.PowerManager power =
        (android.os.PowerManager) getSystemService(android.content.Context.POWER_SERVICE);
    String battery =
        android.os.Build.VERSION.SDK_INT < 23
                || (power != null && power.isIgnoringBatteryOptimizations(getPackageName()))
            ? "✓ استثناء تحسين البطارية"
            : "استثناء تحسين البطارية";
    String[] options = {
      "اختيار مجلد المشروع — موصى به",
      files,
      installs,
      overlay,
      battery,
      "صلاحيات التخزين القديمة",
      "معلومات الصلاحيات المتقدمة"
    };
    new AlertDialog.Builder(this)
        .setTitle("صلاحيات التطبيق")
        .setItems(
            options,
            (dialog, which) -> {
              switch (which) {
                case 0:
                  onSelectProjectFolder();
                  break;
                case 1:
                  openAllFilesSettings();
                  break;
                case 2:
                  openInstallPackagesSettings();
                  break;
                case 3:
                  openOverlaySettings();
                  break;
                case 4:
                  requestBatteryExemption();
                  break;
                case 5:
                  requestLegacyStoragePermissions();
                  break;
                default:
                  showMessage(
                      "الصلاحيات المتقدمة",
                      "INTERNET وACCESS_NETWORK_STATE وACCESS_WIFI_STATE وWAKE_LOCK تُمنح تلقائيًا"
                          + " عند التثبيت.\n\n"
                          + "READ_LOGS لا يُمنح لتطبيق عادي إلا عبر ADB أو كتطبيق نظام."
                          + " ACCESS_SUPERUSER لا يمنح صلاحية root؛ يتطلب جهازًا مروّتًا ومدير"
                          + " root. صلاحية C2DM تحتاج خدمة إشعارات مهيأة وليست نافذة إذن مستقلة.");
              }
            })
        .setNegativeButton("إغلاق", null)
        .show();
  }

  private void openAllFilesSettings() {
    if (android.os.Build.VERSION.SDK_INT < 30) {
      requestLegacyStoragePermissions();
      return;
    }
    try {
      startActivity(
          new android.content.Intent(
              android.provider.Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
              android.net.Uri.parse("package:" + getPackageName())));
    } catch (Exception error) {
      startActivity(
          new android.content.Intent(
              android.provider.Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));
    }
  }

  private void openInstallPackagesSettings() {
    if (android.os.Build.VERSION.SDK_INT < 26) return;
    startActivity(
        new android.content.Intent(
            android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
            android.net.Uri.parse("package:" + getPackageName())));
  }

  private void openOverlaySettings() {
    if (android.os.Build.VERSION.SDK_INT < 23) return;
    startActivity(
        new android.content.Intent(
            android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            android.net.Uri.parse("package:" + getPackageName())));
  }

  private void requestBatteryExemption() {
    if (android.os.Build.VERSION.SDK_INT < 23) return;
    try {
      startActivity(
          new android.content.Intent(
              android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
              android.net.Uri.parse("package:" + getPackageName())));
    } catch (Exception error) {
      startActivity(
          new android.content.Intent(
              android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
    }
  }

  private void requestLegacyStoragePermissions() {
    if (android.os.Build.VERSION.SDK_INT < 23) return;
    if (android.os.Build.VERSION.SDK_INT >= 33) {
      showMessage(
          "صلاحية التخزين",
          "في Android 13 وما بعده استخدم اختيار مجلد المشروع أو صلاحية الوصول لجميع الملفات.");
      return;
    }
    String[] permissions =
        android.os.Build.VERSION.SDK_INT <= 29
            ? new String[] {
              android.Manifest.permission.READ_EXTERNAL_STORAGE,
              android.Manifest.permission.WRITE_EXTERNAL_STORAGE
            }
            : new String[] {android.Manifest.permission.READ_EXTERNAL_STORAGE};
    requestPermissions(permissions, 40);
  }

  @Override
  public void onSelectProjectFolder() {
    android.content.Intent intent =
        new android.content.Intent(android.content.Intent.ACTION_OPEN_DOCUMENT_TREE);
    intent.addFlags(
        android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
            | android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            | android.content.Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
            | android.content.Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
    startActivityForResult(intent, 77);
  }

  @Override
  protected void onActivityResult(int requestCode, int resultCode, android.content.Intent data) {
    super.onActivityResult(requestCode, resultCode, data);
    if (requestCode == 88) {
      applySelectedTheme();
      return;
    }
    if (requestCode == 77) {
      if (resultCode == RESULT_OK && data != null && data.getData() != null) {
        android.net.Uri uri = data.getData();
        int flags =
            data.getFlags()
                & (android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                    | android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        try {
          getContentResolver().takePersistableUriPermission(uri, flags);
        } catch (Exception ignored) {
        }
        if (browser != null) browser.openTree(uri);
      }
      getWindow().getDecorView().postDelayed(this::ensureRequiredStorageAccess, 350);
    }
  }

  @Override
  protected void onPause() {
    if (editor != null) editor.saveSession();
    super.onPause();
  }

  @Override
  protected void onResume() {
    super.onResume();
    applySelectedTheme();
    if (browser != null) browser.refresh();
    getWindow().getDecorView().postDelayed(this::ensureRequiredStorageAccess, 450);
  }

  void showMasterMenu(View anchor) {
    PopupMenu p = new PopupMenu(this, anchor);
    String[] ids = {"run", "save", "find", "goto_line", "files", "terminal", "settings"};
    for (String id : ids) {
      CommandCenter.Command c = commands.get(id);
      MenuItem item = p.getMenu().add(c.title);
      item.setIntent(new android.content.Intent().putExtra("command_id", id));
      item.setEnabled(c.enabled(this));
    }
    p.setOnMenuItemClickListener(
        i -> {
          dispatch(i.getIntent().getStringExtra("command_id"));
          return true;
        });
    p.show();
  }

  private interface MenuAction {
    void run(View anchor);
  }

  private static final class IdeMenuEntry {
    final int title;
    final boolean submenu, highlighted;
    final String command;
    final MenuAction action;

    IdeMenuEntry(
        int title, boolean submenu, boolean highlighted, String command, MenuAction action) {
      this.title = title;
      this.submenu = submenu;
      this.highlighted = highlighted;
      this.command = command;
      this.action = action;
    }
  }

  private IdeMenuEntry menu(int title, boolean submenu, String command, MenuAction action) {
    return new IdeMenuEntry(title, submenu, false, command, action);
  }

  private IdeMenuEntry highlightedMenu(
      int title, boolean submenu, String command, MenuAction action) {
    return new IdeMenuEntry(title, submenu, true, command, action);
  }

  void showIdeRootMenu(View anchor) {
    if (anchor == null) return;
    showIdeMenu(
        anchor,
        Arrays.asList(
            menu(R.string.menu_code, true, null, this::showIdeCodeMenu),
            menu(R.string.menu_view, true, null, this::showIdeViewMenu),
            menu(R.string.menu_goto, false, "goto_line", null),
            menu(R.string.menu_save, false, "save", null),
            menu(R.string.menu_more, true, null, this::showIdeMoreMenu)));
  }

  private void showIdeMoreMenu(View anchor) {
    showIdeMenu(
        anchor,
        Arrays.asList(
            highlightedMenu(R.string.menu_back, false, null, this::showIdeRootMenu),
            menu(R.string.menu_find, true, null, this::showIdeFindMenu),
            menu(R.string.menu_refactor, true, null, this::showIdeRefactorMenu),
            menu(R.string.menu_code, true, null, this::showIdeCodeMenu),
            menu(R.string.menu_format, true, null, this::showIdeFormatMenu),
            menu(R.string.menu_project, true, null, this::showIdeProjectMenu),
            menu(R.string.menu_tools, true, null, this::showIdeToolsMenu),
            menu(R.string.menu_settings, false, "settings", null),
            menu(R.string.menu_exit, false, null, a -> confirmExit())));
  }

  private void showIdeCodeMenu(View anchor) {
    showCommandMenu(
        anchor,
        new int[] {
          R.string.menu_diagnostics,
          R.string.menu_completion,
          R.string.menu_format,
          R.string.menu_close_file,
          R.string.menu_close_all
        },
        new String[] {"analyze", "complete", "format", "close_file", "close_all"});
  }

  private void showIdeViewMenu(View anchor) {
    showCommandMenu(
        anchor,
        new int[] {R.string.menu_files, R.string.menu_color_scheme, R.string.menu_diagnostics},
        new String[] {"files", "theme", "analyze"});
  }

  private void showIdeFindMenu(View anchor) {
    showCommandMenu(
        anchor,
        new int[] {R.string.menu_find, R.string.menu_replace, R.string.menu_goto},
        new String[] {"find", "replace", "goto_line"});
  }

  private void showIdeRefactorMenu(View anchor) {
    showCommandMenu(
        anchor,
        new int[] {R.string.menu_diagnostics, R.string.menu_organize, R.string.menu_format},
        new String[] {"analyze", "format", "format"});
  }

  private void showIdeFormatMenu(View anchor) {
    showCommandMenu(
        anchor,
        new int[] {R.string.menu_format, R.string.menu_organize},
        new String[] {"format", "format"});
  }

  private void showIdeProjectMenu(View anchor) {
    showCommandMenu(
        anchor,
        new int[] {
          R.string.menu_build_debug,
          R.string.menu_build_release,
          R.string.menu_clean,
          R.string.menu_files
        },
        new String[] {"build_debug", "build_release", "clean", "files"});
  }

  private void showIdeToolsMenu(View anchor) {
    showCommandMenu(
        anchor,
        new int[] {
          R.string.menu_terminal,
          R.string.menu_permissions,
          R.string.menu_color_scheme,
          R.string.menu_about
        },
        new String[] {"terminal", "permissions", "theme", "about"});
  }

  private void showCommandMenu(View anchor, int[] labels, String[] commandIds) {
    ArrayList<IdeMenuEntry> items = new ArrayList<>();
    items.add(highlightedMenu(R.string.menu_back, false, null, this::showIdeMoreMenu));
    for (int i = 0; i < labels.length; i++) items.add(menu(labels[i], false, commandIds[i], null));
    showIdeMenu(anchor, items);
  }

  private void showIdeMenu(View anchor, List<IdeMenuEntry> items) {
    if (anchor == null) return;
    if (ideMenuWindow != null) ideMenuWindow.dismiss();
    LinearLayout container =
        (LinearLayout) getLayoutInflater().inflate(R.layout.ide_overflow_menu, null, false);
    for (IdeMenuEntry entry : items) {
      View row = getLayoutInflater().inflate(R.layout.ide_overflow_entry, container, false);
      TextView title = row.findViewById(R.id.ideOverflowEntryTitle);
      TextView arrow = row.findViewById(R.id.ideOverflowEntryArrow);
      title.setText(entry.title);
      if (entry.highlighted) title.setTextColor(Color.rgb(41, 182, 246));
      arrow.setVisibility(entry.submenu ? View.VISIBLE : View.GONE);
      boolean enabled = true;
      if (entry.command != null) {
        CommandCenter.Command command = commands.get(entry.command);
        enabled = command != null && command.enabled(this);
      }
      row.setEnabled(enabled);
      row.setAlpha(enabled ? 1f : 0.38f);
      row.setOnClickListener(
          v -> {
            if (!v.isEnabled()) return;
            ideMenuWindow.dismiss();
            if (entry.command != null) dispatch(entry.command);
            else if (entry.action != null) anchor.post(() -> entry.action.run(anchor));
          });
      container.addView(row);
    }
    ideMenuWindow = new PopupWindow(container, dp(320), ViewGroup.LayoutParams.WRAP_CONTENT, true);
    ideMenuWindow.setBackgroundDrawable(new ColorDrawable(Color.rgb(48, 48, 48)));
    ideMenuWindow.setOutsideTouchable(true);
    ideMenuWindow.setElevation(dp(10));
    ideMenuWindow.setAnimationStyle(android.R.style.Animation_Dialog);
    int x = -dp(320) + anchor.getWidth();
    ideMenuWindow.showAsDropDown(anchor, x, -dp(4));
  }

  private void confirmExit() {
    new AlertDialog.Builder(this)
        .setTitle(R.string.menu_exit_title)
        .setMessage(R.string.menu_exit_message)
        .setNegativeButton(R.string.action_no, null)
        .setPositiveButton(R.string.action_yes, (dialog, which) -> finish())
        .show();
  }

  void showCommands() {
    final List<String> groups = commands.groups();
    new AlertDialog.Builder(this)
        .setTitle("الأوامر")
        .setItems(groups.toArray(new String[0]), (d, w) -> showCommandGroup(groups.get(w)))
        .show();
  }

  void showCommandGroup(String group) {
    final List<CommandCenter.Command> list = commands.inGroup(group);
    String[] labels = new String[list.size()];
    for (int i = 0; i < list.size(); i++) {
      CommandCenter.Command c = list.get(i);
      labels[i] = (c.enabled(this) ? "" : "🔒  ") + c.title;
    }
    new AlertDialog.Builder(this)
        .setTitle(group)
        .setItems(labels, (d, w) -> dispatch(list.get(w).id))
        .setNegativeButton("رجوع", (d, w) -> showCommands())
        .show();
  }

  void dispatch(String id) {
    CommandCenter.Command c = commands.get(id);
    if (!commands.dispatch(id, this)) {
      Toast.makeText(
              this,
              c != null && c.needsProject ? "افتح مشروعًا أولًا" : "افتح ملفًا في المحرر أولًا",
              Toast.LENGTH_SHORT)
          .show();
    }
  }

  void showFind() {
    View v = getLayoutInflater().inflate(R.layout.gotobrowser, null);
    new AlertDialog.Builder(this)
        .setTitle("بحث")
        .setView(v)
        .setNegativeButton("إغلاق", null)
        .show();
  }

  void showDesigner() {
    View v = getLayoutInflater().inflate(R.layout.designer, null);
    new AlertDialog.Builder(this)
        .setTitle("المصمم المرئي")
        .setView(v)
        .setNegativeButton("إغلاق", null)
        .show();
  }

  void runProject() {
    runBuild("assembleDebug", "تشغيل المشروع");
  }

  void runBuild(String task, String title) {
    File root = session == null ? null : session.directory();
    if (root == null || !root.isDirectory()) {
      showMessage(
          "البناء",
          "هذا المشروع مفتوح عبر مزود مستندات لا يكشف مسارًا تنفيذيًا. التصفح والتحرير متاحان، لكن"
              + " تشغيل Gradle يحتاج مجلدًا محليًا مباشرًا.");
      return;
    }
    File wrapper = new File(root, "gradlew");
    if (!wrapper.isFile()) {
      showMessage("البناء", "لم يتم العثور على gradlew في:\n" + root.getAbsolutePath());
      return;
    }
    View view = getLayoutInflater().inflate(R.layout.outputconsole, null);
    TextView output = view.findViewById(R.id.outputConsole);
    output.setTextColor(Color.LTGRAY);
    output.setTextSize(13);
    output.setPadding(dp(12), dp(10), dp(12), dp(10));
    AlertDialog dialog =
        new AlertDialog.Builder(this)
            .setTitle(title)
            .setView(view)
            .setNegativeButton("إيقاف", null)
            .create();
    dialog.setOnShowListener(
        x -> {
          dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener(v -> shell.cancel());
          Map<String, String> env = new HashMap<>();
          env.put("SHIMA_CURRENT_PROJECT", root.getAbsolutePath());
          shell.run(
              root,
              Arrays.asList("sh", "gradlew", task, "--no-daemon"),
              env,
              new ShellCommandRunner.Listener() {
                public void onStart(String c) {
                  output.setText("$ " + c + "\n\n");
                }

                public void onLine(String line) {
                  output.append(line + "\n");
                }

                public void onFinish(int code, boolean cancelled) {
                  output.append(cancelled ? "\nتم إيقاف العملية." : "\nانتهت العملية برمز " + code);
                  dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setText("إغلاق");
                  dialog
                      .getButton(AlertDialog.BUTTON_NEGATIVE)
                      .setOnClickListener(v -> dialog.dismiss());
                }
              });
        });
    dialog.setOnDismissListener(x -> shell.cancel());
    dialog.show();
  }

  void runShell(String command, String title) {
    File root = session == null ? null : session.directory();
    if (root == null) {
      showMessage(title, "الأمر يحتاج مشروعًا ذا مسار محلي مباشر.");
      return;
    }
    View view = getLayoutInflater().inflate(R.layout.outputconsole, null);
    TextView output = view.findViewById(R.id.outputConsole);
    output.setTextColor(Color.LTGRAY);
    output.setTextSize(13);
    AlertDialog dialog =
        new AlertDialog.Builder(this)
            .setTitle(title)
            .setView(view)
            .setNegativeButton("إيقاف", null)
            .create();
    dialog.setOnShowListener(
        x -> {
          dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener(v -> shell.cancel());
          Map<String, String> env = new HashMap<>();
          env.put("SHIMA_CURRENT_PROJECT", root.getAbsolutePath());
          shell.run(
              root,
              Arrays.asList("sh", "-c", command),
              env,
              new ShellCommandRunner.Listener() {
                public void onStart(String c) {
                  output.setText("$ " + command + "\n\n");
                }

                public void onLine(String line) {
                  output.append(line + "\n");
                }

                public void onFinish(int code, boolean stopped) {
                  output.append(stopped ? "\nتم الإيقاف." : "\nرمز الخروج: " + code);
                  dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setText("إغلاق");
                  dialog
                      .getButton(AlertDialog.BUTTON_NEGATIVE)
                      .setOnClickListener(v -> dialog.dismiss());
                }
              });
        });
    dialog.setOnDismissListener(x -> shell.cancel());
    dialog.show();
  }

  void promptTerminal() {
    final EditText input = new EditText(this);
    input.setHint("مثال: ./gradlew tasks");
    input.setSingleLine(true);
    new AlertDialog.Builder(this)
        .setTitle("طرفية المشروع")
        .setView(input)
        .setNegativeButton("إلغاء", null)
        .setPositiveButton(
            "تشغيل",
            (d, w) -> {
              String c = input.getText().toString().trim();
              if (!c.isEmpty()) runShell(c, "الطرفية");
            })
        .show();
  }

  void promptCommit() {
    final EditText input = new EditText(this);
    input.setHint("رسالة الالتزام");
    input.setSingleLine(true);
    new AlertDialog.Builder(this)
        .setTitle("Git: إنشاء التزام")
        .setView(input)
        .setNegativeButton("إلغاء", null)
        .setPositiveButton(
            "التزام",
            (d, w) -> {
              String m = input.getText().toString().trim();
              if (!m.isEmpty()) runShell("git commit -m " + shellQuote(m), "Git");
            })
        .show();
  }

  String shellQuote(String value) {
    return "'" + value.replace("'", "'\\''") + "'";
  }

  void showMessage(String title, String text) {
    new AlertDialog.Builder(this)
        .setTitle(title)
        .setMessage(text)
        .setPositiveButton("حسنًا", null)
        .show();
  }

  @Override
  public boolean hasProject() {
    return projectOpen && session != null && session.isOpen();
  }

  @Override
  public boolean hasEditor() {
    return editor != null && editor.hasOpenFile();
  }

  @Override
  public void execute(String id) {
    switch (id) {
      case "run":
      case "build_debug":
        runBuild("assembleDebug", id.equals("run") ? "تشغيل المشروع" : "بناء نسخة التصحيح");
        break;
      case "build_release":
        runBuild("assembleRelease", "بناء نسخة الإصدار");
        break;
      case "clean":
        runBuild("clean", "تنظيف المشروع");
        break;
      case "terminal":
        promptTerminal();
        break;
      case "save":
        browser.saveOpenedFileAsync(
            editor.getActiveFile(),
            editor.getTextContent(),
            (saved, message) -> Toast.makeText(this, message, Toast.LENGTH_SHORT).show());
        break;
      case "undo":
        editor.undoEdit();
        break;
      case "redo":
        editor.redoEdit();
        break;
      case "find":
        promptFind();
        break;
      case "replace":
        promptReplace();
        break;
      case "goto_line":
        promptGotoLine();
        break;
      case "format":
        editor.formatSource();
        Toast.makeText(this, "تم تنسيق المصدر", Toast.LENGTH_SHORT).show();
        break;
      case "analyze":
        showDiagnostics();
        break;
      case "complete":
        showCompletions();
        break;
      case "close_file":
        editor.closeCurrent();
        if (!editor.hasOpenFile()) {
          empty.setVisibility(View.VISIBLE);
          editor.setVisibility(View.GONE);
        }
        break;
      case "close_all":
        editor.closeAll();
        empty.setVisibility(View.VISIBLE);
        break;
      case "files":
        openBrowser();
        break;
      case "new_file":
        openBrowser();
        browser.createFile();
        break;
      case "new_folder":
        openBrowser();
        browser.createFolder();
        break;
      case "refresh":
        browser.refresh();
        break;
      case "git_status":
        runShell("git status --short --branch", "Git: الحالة");
        break;
      case "git_log":
        runShell("git log --oneline -n 20", "Git: السجل");
        break;
      case "git_add":
        runShell("git add -A && git status --short", "Git: إضافة التغييرات");
        break;
      case "git_commit":
        promptCommit();
        break;
      case "git_pull":
        runShell("git pull --ff-only", "Git: سحب");
        break;
      case "git_push":
        runShell("git push", "Git: رفع");
        break;
      case "theme":
        startActivityForResult(new android.content.Intent(this, ThemeActivity.class), 88);
        break;
      case "permissions":
        showPermissionsCenter();
        break;
      case "settings":
        startActivity(new Intent(this, SettingsActivity.class));
        break;
      case "about":
        showMessage(
            "حول Shima IDE",
            "بيئة برمجة Android عربية. نظام الأوامر والبناء وGit مستقل وخفيف، ولا يحتوي على ملفات"
                + " المصدر المرجعية الخارجية.");
        break;
    }
  }

  void showDiagnostics() {
    java.util.List<com.almlkid.kay.ui.CodeLanguageTools.Diagnostic> items = editor.diagnostics();
    if (items.isEmpty()) {
      showMessage(
          "فحص بناء الجمل",
          "لم تُكتشف أخطاء في الأقواس أو السلاسل النصية أو التعليقات أو وسوم XML.");
      return;
    }
    String[] rows = new String[items.size()];
    for (int i = 0; i < items.size(); i++) rows[i] = items.get(i).toString();
    new AlertDialog.Builder(this)
        .setTitle("أخطاء بناء الجمل (" + items.size() + ")")
        .setItems(rows, (d, w) -> editor.goToLine(items.get(w).line))
        .setPositiveButton("إغلاق", null)
        .show();
  }

  void showCompletions() {
    java.util.List<String> values = editor.completions();
    if (values.isEmpty()) {
      Toast.makeText(this, "لا توجد اقتراحات للكلمة الحالية", Toast.LENGTH_SHORT).show();
      return;
    }
    new AlertDialog.Builder(this)
        .setTitle("الإكمال التلقائي")
        .setItems(values.toArray(new String[0]), (d, w) -> editor.applyCompletion(values.get(w)))
        .setNegativeButton("إلغاء", null)
        .show();
  }

  void promptFind() {
    final EditText input = new EditText(this);
    input.setHint("النص المطلوب");
    new AlertDialog.Builder(this)
        .setTitle("بحث في الملف")
        .setView(input)
        .setNegativeButton("إلغاء", null)
        .setPositiveButton(
            "بحث",
            (d, w) -> {
              if (!editor.findText(input.getText().toString()))
                Toast.makeText(this, "لم يتم العثور على النص", Toast.LENGTH_SHORT).show();
            })
        .show();
  }

  void promptReplace() {
    LinearLayout box = new LinearLayout(this);
    box.setOrientation(LinearLayout.VERTICAL);
    final EditText from = new EditText(this), to = new EditText(this);
    from.setHint("البحث عن");
    to.setHint("الاستبدال بـ");
    box.addView(from);
    box.addView(to);
    new AlertDialog.Builder(this)
        .setTitle("بحث واستبدال")
        .setView(box)
        .setNegativeButton("إلغاء", null)
        .setPositiveButton(
            "استبدال الكل",
            (d, w) ->
                Toast.makeText(
                        this,
                        "تم استبدال "
                            + editor.replaceAll(from.getText().toString(), to.getText().toString())
                            + " موضع",
                        Toast.LENGTH_SHORT)
                    .show())
        .show();
  }

  void promptGotoLine() {
    final EditText input = new EditText(this);
    input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
    input.setHint("رقم السطر");
    new AlertDialog.Builder(this)
        .setTitle("انتقال إلى سطر")
        .setView(input)
        .setNegativeButton("إلغاء", null)
        .setPositiveButton(
            "انتقال",
            (d, w) -> {
              try {
                if (!editor.goToLine(Integer.parseInt(input.getText().toString())))
                  Toast.makeText(this, "رقم السطر خارج الملف", Toast.LENGTH_SHORT).show();
              } catch (Exception e) {
                Toast.makeText(this, "أدخل رقمًا صحيحًا", Toast.LENGTH_SHORT).show();
              }
            })
        .show();
  }

  void hideMasterButtonWithKeyboard(final View masterButton) {
    final View root = getWindow().getDecorView();
    final int[] largestVisibleHeight = {0};
    root.getViewTreeObserver()
        .addOnGlobalLayoutListener(
            () -> {
              android.graphics.Rect frame = new android.graphics.Rect();
              root.getWindowVisibleDisplayFrame(frame);
              int currentHeight = frame.height();
              if (currentHeight > largestVisibleHeight[0]) largestVisibleHeight[0] = currentHeight;
              int difference = largestVisibleHeight[0] - currentHeight;
              boolean keyboardShown = difference > Math.max(dp(170), largestVisibleHeight[0] / 6);
              boolean editorActive =
                  editor != null && editor.hasOpenFile() && editor.getVisibility() == View.VISIBLE;
              int expected = keyboardShown || !editorActive ? View.GONE : View.VISIBLE;
              if (masterButton.getVisibility() != expected) masterButton.setVisibility(expected);
            });
  }

  void showStartupError(Throwable error) {
    ActionBar bar = getActionBar();
    if (bar != null) bar.hide();
    LinearLayout page = new LinearLayout(this);
    page.setOrientation(LinearLayout.VERTICAL);
    page.setPadding(dp(20), dp(24), dp(20), dp(16));
    page.setBackgroundColor(Color.rgb(25, 25, 25));
    TextView title = new TextView(this);
    title.setText("خطأ في تحميل واجهة البرمجة");
    title.setTextColor(Color.WHITE);
    title.setTextSize(22);
    page.addView(title);
    TextView message = new TextView(this);
    message.setText(
        "تم احتواء الخطأ ولن يتم إغلاق التطبيق. يمكنك عرض التفاصيل أو متابعة العمل بالوضع الآمن.");
    message.setTextColor(Color.LTGRAY);
    message.setPadding(0, dp(10), 0, dp(12));
    page.addView(message);
    TextView log = new TextView(this);
    log.setText(CrashStore.read(this));
    log.setTextColor(Color.rgb(255, 180, 180));
    log.setTextSize(11);
    log.setTypeface(android.graphics.Typeface.MONOSPACE);
    log.setTextIsSelectable(true);
    ScrollView scroll = new ScrollView(this);
    scroll.addView(log);
    page.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
    Button safe = new Button(this);
    safe.setText("فتح الوضع الآمن");
    safe.setOnClickListener(v -> showSafeMode());
    page.addView(safe);
    Button retry = new Button(this);
    retry.setText("إعادة المحاولة");
    retry.setOnClickListener(v -> recreate());
    page.addView(retry);
    setContentView(page);
  }

  void showSafeMode() {
    ActionBar bar = getActionBar();
    if (bar != null) bar.hide();
    LinearLayout page = new LinearLayout(this);
    page.setOrientation(LinearLayout.VERTICAL);
    page.setGravity(Gravity.CENTER_HORIZONTAL);
    page.setPadding(dp(24), dp(42), dp(24), dp(20));
    page.setBackgroundColor(Color.rgb(25, 25, 25));
    ImageView logo = new ImageView(this);
    logo.setImageResource(R.drawable.ic_launcher);
    page.addView(logo, new LinearLayout.LayoutParams(dp(80), dp(80)));
    TextView title = new TextView(this);
    title.setText("Almk AIDE — الوضع الآمن");
    title.setTextColor(Color.WHITE);
    title.setTextSize(22);
    title.setGravity(Gravity.CENTER);
    title.setPadding(0, dp(18), 0, dp(8));
    page.addView(title);
    TextView note = new TextView(this);
    note.setText(
        "تم تعطيل الواجهات المخصصة مؤقتًا. ملفات المشروع لم تُحذف ويمكن إعادة محاولة فتح الواجهة"
            + " الكاملة.");
    note.setTextColor(Color.LTGRAY);
    note.setTextSize(15);
    note.setGravity(Gravity.CENTER);
    page.addView(note, new LinearLayout.LayoutParams(-1, 0, 1));
    Button retry = new Button(this);
    retry.setText("فتح الواجهة الكاملة");
    retry.setOnClickListener(
        v -> {
          getIntent().removeExtra("safe_mode");
          recreate();
        });
    page.addView(retry, new LinearLayout.LayoutParams(-1, dp(52)));
    Button report = new Button(this);
    report.setText("عرض آخر خطأ");
    report.setOnClickListener(
        v -> startActivity(new android.content.Intent(this, RecoveryActivity.class)));
    page.addView(report, new LinearLayout.LayoutParams(-1, dp(52)));
    setContentView(page);
  }

  int dp(int n) {
    return (int) (n * getResources().getDisplayMetrics().density + .5f);
  }

  @Override
  public void onBackPressed() {
    if (drawer != null && drawer.isDrawerOpen(Gravity.LEFT)) {
      drawer.closeDrawers();
      return;
    }
    if (projectOpen) {
      showNoProject();
      return;
    }
    super.onBackPressed();
  }
}
