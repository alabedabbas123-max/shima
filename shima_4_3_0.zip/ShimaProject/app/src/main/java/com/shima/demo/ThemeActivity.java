package com.shima.demo;

import android.app.*;
import android.graphics.*;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import java.util.Map;

/** Editable Dark/Light color scheme screen modeled after the IDE color-scheme panel. */
public class ThemeActivity extends Activity {
  private ThemeConfig theme;
  private LinearLayout entries;
  private TextView selector;
  private View root;

  @Override
  protected void onCreate(Bundle state) {
    super.onCreate(state);
    theme = new ThemeConfig(this);
    setContentView(R.layout.activity_color_scheme);
    root = findViewById(R.id.colorSchemeRoot);
    entries = findViewById(R.id.colorSchemeEntries);
    selector = findViewById(R.id.colorSchemeSelector);
    ActionBar bar = getActionBar();
    if (bar != null) {
      bar.setTitle(R.string.color_scheme_title);
      bar.setDisplayHomeAsUpEnabled(true);
      bar.setHomeAsUpIndicator(R.drawable.ic_navigation_back);
    }
    selector.setOnClickListener(v -> chooseScheme());
    render();
  }

  private void chooseScheme() {
    String[] choices = {
      getString(R.string.color_scheme_dark), getString(R.string.color_scheme_light)
    };
    new AlertDialog.Builder(this)
        .setTitle(R.string.color_scheme_title)
        .setSingleChoiceItems(
            choices,
            theme.isDark() ? 0 : 1,
            (dialog, which) -> {
              theme.reset(which == 0);
              dialog.dismiss();
              render();
              setResult(RESULT_OK);
            })
        .show();
  }

  private void render() {
    int background = theme.isDark() ? 0xFF191919 : 0xFFF5F5F5;
    int text = theme.isDark() ? Color.WHITE : 0xFF202124;
    root.setBackgroundColor(background);
    selector.setText(theme.schemeName(this));
    selector.setTextColor(text);
    getWindow().setStatusBarColor(Color.BLACK);
    getWindow().setNavigationBarColor(theme.isDark() ? 0xFF232323 : 0xFFE0E0E0);
    ActionBar bar = getActionBar();
    if (bar != null) bar.setBackgroundDrawable(new ColorDrawable(0xFF232323));
    entries.removeAllViews();
    for (Map.Entry<String, String> item : ThemeConfig.labels(this).entrySet()) {
      View row = getLayoutInflater().inflate(R.layout.color_scheme_entry, entries, false);
      TextView label = row.findViewById(R.id.colorSchemeEntryLabel);
      TextView value = row.findViewById(R.id.colorSchemeEntryValue);
      label.setText(item.getValue());
      label.setTextColor(text);
      value.setText(theme.hex(item.getKey()));
      value.setTextColor(contrast(theme.color(item.getKey())));
      value.setBackground(new ColorPreviewDrawable(theme.color(item.getKey())));
      row.setOnClickListener(v -> editColor(item.getKey(), item.getValue()));
      entries.addView(row);
    }
  }

  private void editColor(String key, String label) {
    int initialColor = theme.color(key);
    yuku.ambilwarna.AmbilWarnaDialog picker =
        new yuku.ambilwarna.AmbilWarnaDialog(
            this,
            initialColor,
            true,
            new yuku.ambilwarna.AmbilWarnaDialog.OnAmbilWarnaListener() {
              @Override
              public void onCancel(yuku.ambilwarna.AmbilWarnaDialog dialog) {}

              @Override
              public void onOk(yuku.ambilwarna.AmbilWarnaDialog dialog, int color) {
                theme.setColor(key, color);
                render();
                setResult(RESULT_OK);
              }
            });
    picker.show();
    picker.getDialog().setTitle(label);
  }

  private int contrast(int color) {
    double luminance =
        (0.299 * Color.red(color) + 0.587 * Color.green(color) + 0.114 * Color.blue(color));
    return luminance > 150 ? Color.BLACK : Color.WHITE;
  }

  private int dp(int value) {
    return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
  }

  @Override
  public boolean onOptionsItemSelected(android.view.MenuItem item) {
    if (item.getItemId() == android.R.id.home) {
      finish();
      return true;
    }
    return super.onOptionsItemSelected(item);
  }

  private static final class ColorPreviewDrawable extends Drawable {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final int color;

    ColorPreviewDrawable(int color) {
      this.color = color;
    }

    @Override
    public void draw(Canvas canvas) {
      Rect bounds = getBounds();
      int size = Math.max(8, bounds.height() / 4);
      for (int y = bounds.top; y < bounds.bottom; y += size) {
        for (int x = bounds.left; x < bounds.right; x += size) {
          boolean dark = ((x - bounds.left) / size + (y - bounds.top) / size) % 2 == 0;
          paint.setColor(dark ? 0xFFBDBDBD : 0xFFFFFFFF);
          canvas.drawRect(
              x, y, Math.min(x + size, bounds.right), Math.min(y + size, bounds.bottom), paint);
        }
      }
      paint.setColor(color);
      canvas.drawRect(bounds, paint);
    }

    @Override
    public void setAlpha(int alpha) {}

    @Override
    public void setColorFilter(android.graphics.ColorFilter filter) {}

    @Override
    public int getOpacity() {
      return android.graphics.PixelFormat.TRANSLUCENT;
    }
  }
}
