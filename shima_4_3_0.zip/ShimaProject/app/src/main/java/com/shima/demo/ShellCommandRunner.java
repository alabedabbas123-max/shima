package com.shima.demo;

import android.os.Handler;
import android.os.Looper;
import java.io.*;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** One short-lived process per IDE operation, with streamed output and cancellation. */
public final class ShellCommandRunner {
  public interface Listener {
    void onStart(String shown);

    void onLine(String line);

    void onFinish(int exitCode, boolean cancelled);
  }

  private final ExecutorService worker = Executors.newSingleThreadExecutor();
  private final Handler main = new Handler(Looper.getMainLooper());
  private volatile Process process;
  private volatile boolean cancelled;

  public synchronized boolean isRunning() {
    return process != null;
  }

  public void run(
      File directory, List<String> command, Map<String, String> environment, Listener listener) {
    cancel();
    cancelled = false;
    worker.execute(
        () -> {
          int code = -1;
          try {
            String shown = join(command);
            main.post(() -> listener.onStart(shown));
            ProcessBuilder builder = new ProcessBuilder(command).redirectErrorStream(true);
            if (directory != null) builder.directory(directory);
            if (environment != null) builder.environment().putAll(environment);
            process = builder.start();
            BufferedReader reader =
                new BufferedReader(new InputStreamReader(process.getInputStream()));
            String line;
            while ((line = reader.readLine()) != null) {
              final String value = line;
              main.post(() -> listener.onLine(value));
            }
            code = process.waitFor();
          } catch (Exception error) {
            final String message = "خطأ: " + error.getMessage();
            main.post(() -> listener.onLine(message));
          } finally {
            process = null;
            final int result = code;
            final boolean wasCancelled = cancelled;
            main.post(() -> listener.onFinish(result, wasCancelled));
          }
        });
  }

  public synchronized void cancel() {
    cancelled = true;
    if (process != null) {
      process.destroy();
      process = null;
    }
  }

  public void close() {
    cancel();
    worker.shutdownNow();
  }

  private String join(List<String> values) {
    StringBuilder out = new StringBuilder();
    for (String v : values) {
      if (out.length() > 0) out.append(' ');
      out.append(v.indexOf(' ') >= 0 ? '\'' + v + '\'' : v);
    }
    return out.toString();
  }
}
