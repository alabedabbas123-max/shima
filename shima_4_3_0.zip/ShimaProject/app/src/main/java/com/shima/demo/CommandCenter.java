package com.shima.demo;

import java.util.*;

/**
 * The IDE command catalogue. UI controls only submit an id; eligibility and execution are kept out
 * of menu code so the same command can later be used by a shortcut, palette, toolbar or test.
 */
public final class CommandCenter {
  public interface Host {
    boolean hasProject();

    boolean hasEditor();

    void execute(String id);
  }

  public static final class Command {
    public final String id, title, group;
    public final boolean needsProject, needsEditor;

    Command(String i, String t, String g, boolean p, boolean e) {
      id = i;
      title = t;
      group = g;
      needsProject = p;
      needsEditor = e;
    }

    public boolean enabled(Host h) {
      return (!needsProject || h.hasProject()) && (!needsEditor || h.hasEditor());
    }
  }

  private final LinkedHashMap<String, Command> all = new LinkedHashMap<>();

  public CommandCenter() {
    add("run", "تشغيل المشروع", "البناء", true, false);
    add("build_debug", "بناء APK للتصحيح", "البناء", true, false);
    add("build_release", "بناء APK للإصدار", "البناء", true, false);
    add("clean", "تنظيف نواتج البناء", "البناء", true, false);
    add("terminal", "طرفية المشروع", "البناء", true, false);
    add("save", "حفظ الملف", "المحرر", true, true);
    add("undo", "تراجع", "المحرر", false, true);
    add("redo", "إعادة", "المحرر", false, true);
    add("find", "بحث في الملف", "المحرر", false, true);
    add("replace", "بحث واستبدال", "المحرر", false, true);
    add("goto_line", "انتقال إلى سطر", "المحرر", false, true);
    add("format", "تنسيق المصدر", "المحرر", false, true);
    add("analyze", "فحص بناء الجمل", "المحرر", false, true);
    add("complete", "الإكمال التلقائي", "المحرر", false, true);
    add("close_file", "إغلاق الملف الحالي", "المحرر", false, true);
    add("close_all", "إغلاق جميع الملفات", "المحرر", false, true);
    add("files", "ملفات المشروع", "الملفات", false, false);
    add("new_file", "ملف جديد", "الملفات", true, false);
    add("new_folder", "مجلد جديد", "الملفات", true, false);
    add("refresh", "تحديث شجرة المشروع", "الملفات", false, false);
    add("git_status", "Git: الحالة", "Git", true, false);
    add("git_log", "Git: آخر الالتزامات", "Git", true, false);
    add("git_add", "Git: إضافة التغييرات", "Git", true, false);
    add("git_commit", "Git: إنشاء التزام", "Git", true, false);
    add("git_pull", "Git: سحب", "Git", true, false);
    add("git_push", "Git: رفع", "Git", true, false);
    add("theme", "نظام الألوان", "عام", false, false);
    add("permissions", "صلاحيات التطبيق", "عام", false, false);
    add("settings", "الإعدادات", "عام", false, false);
    add("about", "حول التطبيق", "عام", false, false);
  }

  private void add(String i, String t, String g, boolean p, boolean e) {
    all.put(i, new Command(i, t, g, p, e));
  }

  public Command get(String id) {
    return all.get(id);
  }

  public List<String> groups() {
    LinkedHashSet<String> s = new LinkedHashSet<>();
    for (Command c : all.values()) s.add(c.group);
    return new ArrayList<>(s);
  }

  public List<Command> inGroup(String group) {
    ArrayList<Command> r = new ArrayList<>();
    for (Command c : all.values()) if (c.group.equals(group)) r.add(c);
    return r;
  }

  public boolean dispatch(String id, Host host) {
    Command c = all.get(id);
    if (c == null || !c.enabled(host)) return false;
    host.execute(id);
    return true;
  }
}
