package com.shima.demo;

import android.content.Context;
import java.io.PrintWriter;
import java.io.StringWriter;

/** Persists the last fatal error so it is visible on the next launch. */
public final class CrashStore {
  private static final String PREFS = "diagnostics";
  private static final String KEY_ERROR = "last_error";

  private CrashStore() {}

  public static void save(Context context, Throwable error) {
    StringWriter buffer = new StringWriter();
    error.printStackTrace(new PrintWriter(buffer));
    context
        .getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        .edit()
        .putString(KEY_ERROR, buffer.toString())
        .apply();
  }

  public static String read(Context context) {
    return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_ERROR, "");
  }

  public static void clear(Context context) {
    context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(KEY_ERROR).apply();
  }
}
