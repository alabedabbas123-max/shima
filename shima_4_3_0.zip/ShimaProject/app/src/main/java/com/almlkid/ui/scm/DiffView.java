package com.almlkid.ui.scm;

import android.content.Context;
import android.util.AttributeSet;

public class DiffView extends android.widget.TextView {
  public DiffView(Context c) {
    super(c);
  }

  public DiffView(Context c, AttributeSet a) {
    super(c, a);
  }

  public DiffView(Context c, AttributeSet a, int s) {
    super(c, a, s);
  }
}
