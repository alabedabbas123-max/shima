package com.almlkid.kay.aide.preference;

import android.content.Context;
import android.preference.ListPreference;
import android.util.AttributeSet;

/** Theme selector referenced by the original preference XML files. */
@SuppressWarnings("deprecation")
public class PreferenceTheme extends ListPreference {
  public PreferenceTheme(Context context) {
    super(context);
    init();
  }

  public PreferenceTheme(Context context, AttributeSet attrs) {
    super(context, attrs);
    init();
  }

  private void init() {
    setTitle("Theme");
    setEntries(new String[] {"Material Dark", "Material Light"});
    setEntryValues(new String[] {"dark", "light"});
    setDefaultValue("dark");
  }
}
