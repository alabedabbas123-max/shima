package com.almlkid.ui.preferences;

import android.content.Context;
import android.preference.EditTextPreference;
import android.util.AttributeSet;

/** Compatibility implementation for the original preference XML. */
@SuppressWarnings("deprecation")
public class PremiumEditTextPreference extends EditTextPreference {
  public PremiumEditTextPreference(Context context) {
    super(context);
  }

  public PremiumEditTextPreference(Context context, AttributeSet attrs) {
    super(context, attrs);
  }

  public PremiumEditTextPreference(Context context, AttributeSet attrs, int style) {
    super(context, attrs, style);
  }
}
