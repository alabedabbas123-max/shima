package com.almlkid.kay.ui;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Small dependency-free language service used by the editor. */
public final class CodeLanguageTools {
  public static final int KEYWORD = 1,
      STRING = 2,
      COMMENT = 3,
      NUMBER = 4,
      ANNOTATION = 5,
      TAG = 6,
      IDENTIFIER = 7,
      OPERATOR = 8,
      NAMESPACE = 9,
      SEPARATOR = 10,
      FUNCTION = 11,
      VARIABLE = 12;
  private static final Set<String> JAVA_WORDS =
      set(
          "abstract assert boolean break byte case catch char class const continue default do"
              + " double else enum extends final finally float for goto if implements import"
              + " instanceof int interface long native new package private protected public return"
              + " short static strictfp super switch synchronized this throw throws transient try"
              + " void volatile while true false null record sealed permits var override fun val"
              + " object when is in as typealias suspend data companion");
  private static final Set<String> COMMON_WORDS =
      set(
          "android application activity service fragment view bundle string integer color style"
              + " layout id drawable manifest resources gradle implementation dependencies plugins"
              + " namespace compileSdk minSdk targetSdk versionCode versionName");
  private static final Pattern IDENTIFIER_PATTERN = Pattern.compile("[A-Za-z_$][A-Za-z0-9_$]*");

  private CodeLanguageTools() {}

  public static final class Range {
    public final int start, end, type;

    Range(int s, int e, int t) {
      start = s;
      end = e;
      type = t;
    }
  }

  public static final class Diagnostic {
    public final int offset, end, line, column;
    public final String message;

    Diagnostic(int o, int l, int c, String m) {
      this(o, o + 1, l, c, m);
    }

    Diagnostic(int o, int e, int l, int c, String m) {
      offset = o;
      end = Math.max(o + 1, e);
      line = l;
      column = c;
      message = m;
    }

    @Override
    public String toString() {
      return "السطر " + line + "، العمود " + column + ": " + message;
    }
  }

  private static final class Open {
    final char value;
    final int offset, line, column;

    Open(char v, int o, int l, int c) {
      value = v;
      offset = o;
      line = l;
      column = c;
    }
  }

  public static List<Range> highlight(String fileName, String text) {
    return isXml(fileName) ? highlightXml(text) : highlightCode(text);
  }

  private static List<Range> highlightCode(String text) {
    ArrayList<Range> out = new ArrayList<>();
    int n = text.length(), i = 0;
    boolean expectType = false;
    boolean qualifiedName = false;
    while (i < n) {
      char c = text.charAt(i);
      if (c == ';') qualifiedName = false;
      if (c == '/' && i + 1 < n && text.charAt(i + 1) == '/') {
        int s = i;
        i += 2;
        while (i < n && text.charAt(i) != '\n') i++;
        out.add(new Range(s, i, COMMENT));
        continue;
      }
      if (c == '/' && i + 1 < n && text.charAt(i + 1) == '*') {
        int s = i;
        i += 2;
        while (i + 1 < n && !(text.charAt(i) == '*' && text.charAt(i + 1) == '/')) i++;
        i = Math.min(n, i + 2);
        out.add(new Range(s, i, COMMENT));
        continue;
      }
      if (c == '"' || c == '\'') {
        int s = i++;
        char quote = c;
        boolean escape = false;
        while (i < n) {
          char x = text.charAt(i++);
          if (escape) {
            escape = false;
            continue;
          }
          if (x == '\\') {
            escape = true;
            continue;
          }
          if (x == quote) break;
        }
        out.add(new Range(s, i, STRING));
        continue;
      }
      if (c == '@' && i + 1 < n && Character.isJavaIdentifierStart(text.charAt(i + 1))) {
        int s = i++;
        while (i < n && Character.isJavaIdentifierPart(text.charAt(i))) i++;
        out.add(new Range(s, i, ANNOTATION));
        continue;
      }
      if (Character.isDigit(c)) {
        int s = i++;
        while (i < n
            && (Character.isLetterOrDigit(text.charAt(i)) || "._xX+-".indexOf(text.charAt(i)) >= 0))
          i++;
        out.add(new Range(s, i, NUMBER));
        continue;
      }
      if (Character.isJavaIdentifierStart(c)) {
        int s = i++;
        while (i < n && Character.isJavaIdentifierPart(text.charAt(i))) i++;
        String word = text.substring(s, i);
        if (JAVA_WORDS.contains(word)) {
          out.add(new Range(s, i, KEYWORD));
          if (word.equals("import") || word.equals("package")) qualifiedName = true;
          expectType =
              word.equals("class")
                  || word.equals("interface")
                  || word.equals("enum")
                  || word.equals("extends")
                  || word.equals("implements")
                  || word.equals("new");
        } else {
          int next = nextNonWhitespace(text, i);
          boolean function = next < n && text.charAt(next) == '(';
          if (qualifiedName && !Character.isUpperCase(word.charAt(0)))
            out.add(new Range(s, i, NAMESPACE));
          else if (expectType || Character.isUpperCase(word.charAt(0))) {
            out.add(new Range(s, i, TAG));
          } else if (function) {
            out.add(new Range(s, i, FUNCTION));
          } else {
            out.add(new Range(s, i, VARIABLE));
          }
          expectType = false;
        }
        continue;
      }
      if ("+-*/%=!<>?&|^~".indexOf(c) >= 0) {
        int start = i++;
        while (i < n && "+-*/%=!<>?&|^~".indexOf(text.charAt(i)) >= 0) i++;
        out.add(new Range(start, i, OPERATOR));
        continue;
      }
      if (".,;:()[]{}".indexOf(c) >= 0) {
        out.add(new Range(i, i + 1, SEPARATOR));
      }
      i++;
    }
    return out;
  }

  private static int nextNonWhitespace(String text, int offset) {
    int cursor = offset;
    while (cursor < text.length() && Character.isWhitespace(text.charAt(cursor))) cursor++;
    return cursor;
  }

  private static List<Range> highlightXml(String text) {
    ArrayList<Range> out = new ArrayList<>();
    int i = 0, n = text.length();
    while (i < n) {
      if (text.startsWith("<!--", i)) {
        int e = text.indexOf("-->", i + 4);
        e = e < 0 ? n : e + 3;
        out.add(new Range(i, e, COMMENT));
        i = e;
        continue;
      }
      if (text.startsWith("<![CDATA[", i)) {
        int e = text.indexOf("]]>", i + 9);
        e = e < 0 ? n : e + 3;
        out.add(new Range(i, e, STRING));
        i = e;
        continue;
      }
      if (text.charAt(i) == '<') {
        int e = findTagEnd(text, i + 1);
        out.add(new Range(i, e, TAG));
        int p = i;
        while (p < e) {
          char q = text.charAt(p);
          if (q == '"' || q == '\'') {
            int s = p++;
            while (p < e) {
              char x = text.charAt(p++);
              if (x == q) break;
            }
            out.add(new Range(s, p, STRING));
          } else p++;
        }
        i = e;
        continue;
      }
      i++;
    }
    return out;
  }

  private static int findTagEnd(String text, int from) {
    char quote = 0;
    for (int i = from; i < text.length(); i++) {
      char c = text.charAt(i);
      if (quote != 0) {
        if (c == quote) quote = 0;
      } else if (c == '"' || c == '\'') quote = c;
      else if (c == '>') return i + 1;
    }
    return text.length();
  }

  public static List<Diagnostic> inspect(String fileName, String text) {
    return isXml(fileName) ? inspectXml(text) : inspectCode(fileName, text);
  }

  private static List<Diagnostic> inspectCode(String fileName, String text) {
    ArrayList<Diagnostic> result = new ArrayList<>();
    ArrayDeque<Open> stack = new ArrayDeque<>();
    int line = 1, col = 1, n = text.length();
    boolean lineComment = false, blockComment = false, escape = false;
    char quote = 0;
    int quoteOffset = -1,
        quoteLine = 1,
        quoteCol = 1,
        blockOffset = -1,
        blockLine = 1,
        blockCol = 1;
    for (int i = 0; i < n; i++) {
      char c = text.charAt(i), next = i + 1 < n ? text.charAt(i + 1) : 0;
      if (c == '\n') {
        line++;
        col = 1;
        lineComment = false;
        if (quote != 0 && quote != '`') {
          result.add(new Diagnostic(quoteOffset, quoteLine, quoteCol, "سلسلة نصية غير مغلقة"));
          quote = 0;
          escape = false;
        }
        continue;
      }
      if (lineComment) {
        col++;
        continue;
      }
      if (blockComment) {
        if (c == '*' && next == '/') {
          blockComment = false;
          i++;
          col += 2;
        } else col++;
        continue;
      }
      if (quote != 0) {
        if (escape) escape = false;
        else if (c == '\\') escape = true;
        else if (c == quote) quote = 0;
        col++;
        continue;
      }
      if (c == '/' && next == '/') {
        lineComment = true;
        i++;
        col += 2;
        continue;
      }
      if (c == '/' && next == '*') {
        blockComment = true;
        blockOffset = i;
        blockLine = line;
        blockCol = col;
        i++;
        col += 2;
        continue;
      }
      if (c == '"' || c == '\'' || c == '`') {
        quote = c;
        quoteOffset = i;
        quoteLine = line;
        quoteCol = col;
        col++;
        continue;
      }
      if (c == '(' || c == '[' || c == '{') stack.push(new Open(c, i, line, col));
      else if (c == ')' || c == ']' || c == '}') {
        char expected = c == ')' ? '(' : c == ']' ? '[' : '{';
        if (stack.isEmpty()) result.add(new Diagnostic(i, line, col, "قوس إغلاق بلا قوس افتتاح"));
        else if (stack.peek().value != expected) {
          Open open = stack.pop();
          result.add(
              new Diagnostic(
                  i, line, col, "قوس الإغلاق لا يطابق القوس المفتوح في السطر " + open.line));
        } else stack.pop();
      }
      col++;
    }
    if (blockComment)
      result.add(new Diagnostic(blockOffset, blockLine, blockCol, "تعليق متعدد الأسطر غير مغلق"));
    if (quote != 0)
      result.add(new Diagnostic(quoteOffset, quoteLine, quoteCol, "سلسلة نصية غير مغلقة"));
    while (!stack.isEmpty()) {
      Open o = stack.removeLast();
      result.add(new Diagnostic(o.offset, o.line, o.column, "قوس افتتاح غير مغلق: " + o.value));
    }
    inspectDeclarations(fileName, text, result);
    result.addAll(ProjectSymbolIndex.inspectCalls(text));
    return result;
  }

  private static void inspectDeclarations(
      String fileName, String source, List<Diagnostic> diagnostics) {
    String code = maskCommentsAndStrings(source);
    String[] lines = code.split("\n", -1);
    int offset = 0;
    for (String line : lines) {
      String trimmed = line.trim();
      if ((trimmed.startsWith("package ") || trimmed.startsWith("import "))
          && !trimmed.endsWith(";")) {
        addAt(
            diagnostics,
            source,
            offset + Math.max(0, line.indexOf(trimmed)),
            "يجب إنهاء العبارة بـ ;");
      }
      offset += line.length() + 1;
    }

    Pattern declaration = Pattern.compile("\\b(class|interface|enum|record)\\b");
    Matcher matcher = declaration.matcher(code);
    HashSet<String> names = new HashSet<>();
    while (matcher.find()) {
      int cursor = nextNonWhitespace(code, matcher.end());
      if (cursor >= code.length() || !Character.isJavaIdentifierStart(code.charAt(cursor))) {
        addAt(diagnostics, source, matcher.start(), "تعريف " + matcher.group() + " بلا اسم صالح");
        continue;
      }
      int end = cursor + 1;
      while (end < code.length() && Character.isJavaIdentifierPart(code.charAt(end))) end++;
      String name = code.substring(cursor, end);
      if (!names.add(name)) addAt(diagnostics, source, cursor, "اسم كلاس مكرر في الملف: " + name);

      int body = findDeclarationBody(code, end);
      if (body < 0) addAt(diagnostics, source, cursor, "تعريف " + name + " بلا جسم { ... }");

      int lineStart = code.lastIndexOf('\n', matcher.start()) + 1;
      String prefix = code.substring(lineStart, matcher.start());
      boolean topLevel = braceDepthAt(code, matcher.start()) == 0;
      if (topLevel
          && containsWord(prefix, "public")
          && fileName.toLowerCase(Locale.US).endsWith(".java")) {
        String expected = fileName.substring(0, fileName.length() - 5);
        if (!expected.equals(name))
          addAt(
              diagnostics,
              source,
              cursor,
              "اسم الكلاس العام " + name + " يجب أن يطابق اسم الملف " + expected);
      }
    }

    Matcher incompleteExtends =
        Pattern.compile("\\bextends\\s*(?=\\{|implements\\b|$)").matcher(code);
    while (incompleteExtends.find())
      addAt(diagnostics, source, incompleteExtends.start(), "يجب تحديد اسم الكلاس بعد extends");
    Matcher incompleteImplements = Pattern.compile("\\bimplements\\s*(?=\\{|$)").matcher(code);
    while (incompleteImplements.find())
      addAt(diagnostics, source, incompleteImplements.start(), "يجب تحديد واجهة بعد implements");
  }

  private static int findDeclarationBody(String code, int from) {
    int angle = 0, parentheses = 0;
    for (int i = from; i < code.length(); i++) {
      char c = code.charAt(i);
      if (c == '<') angle++;
      else if (c == '>' && angle > 0) angle--;
      else if (c == '(') parentheses++;
      else if (c == ')' && parentheses > 0) parentheses--;
      else if (angle == 0 && parentheses == 0 && c == '{') return i;
      else if (angle == 0 && parentheses == 0 && (c == ';' || c == '}')) return -1;
    }
    return -1;
  }

  private static int braceDepthAt(String code, int offset) {
    int depth = 0;
    for (int i = 0; i < offset; i++) {
      if (code.charAt(i) == '{') depth++;
      else if (code.charAt(i) == '}') depth = Math.max(0, depth - 1);
    }
    return depth;
  }

  private static boolean containsWord(String text, String word) {
    return Pattern.compile("(?:^|\\W)" + Pattern.quote(word) + "(?:$|\\W)").matcher(text).find();
  }

  private static String maskCommentsAndStrings(String source) {
    StringBuilder masked = new StringBuilder(source);
    boolean lineComment = false, blockComment = false, escape = false;
    char quote = 0;
    for (int i = 0; i < source.length(); i++) {
      char c = source.charAt(i), next = i + 1 < source.length() ? source.charAt(i + 1) : 0;
      if (c == '\n') {
        lineComment = false;
        escape = false;
        continue;
      }
      if (lineComment) {
        masked.setCharAt(i, ' ');
        continue;
      }
      if (blockComment) {
        masked.setCharAt(i, ' ');
        if (c == '*' && next == '/') {
          masked.setCharAt(++i, ' ');
          blockComment = false;
        }
        continue;
      }
      if (quote != 0) {
        masked.setCharAt(i, ' ');
        if (escape) escape = false;
        else if (c == '\\') escape = true;
        else if (c == quote) quote = 0;
        continue;
      }
      if (c == '/' && next == '/') {
        masked.setCharAt(i, ' ');
        masked.setCharAt(++i, ' ');
        lineComment = true;
      } else if (c == '/' && next == '*') {
        masked.setCharAt(i, ' ');
        masked.setCharAt(++i, ' ');
        blockComment = true;
      } else if (c == '"' || c == '\'' || c == '`') {
        masked.setCharAt(i, ' ');
        quote = c;
      }
    }
    return masked.toString();
  }

  private static List<Diagnostic> inspectXml(String text) {
    ArrayList<Diagnostic> out = new ArrayList<>();
    ArrayDeque<String> names = new ArrayDeque<>();
    ArrayDeque<Integer> offsets = new ArrayDeque<>();
    int i = 0;
    while (i < text.length()) {
      int s = text.indexOf('<', i);
      if (s < 0) break;
      if (text.startsWith("<!--", s)) {
        int e = text.indexOf("-->", s + 4);
        if (e < 0) {
          addAt(out, text, s, "تعليق XML غير مغلق");
          break;
        }
        i = e + 3;
        continue;
      }
      if (text.startsWith("<![CDATA[", s)) {
        int e = text.indexOf("]]>", s + 9);
        if (e < 0) {
          addAt(out, text, s, "CDATA غير مغلقة");
          break;
        }
        i = e + 3;
        continue;
      }
      int e = findTagEnd(text, s + 1);
      if (e >= text.length() && text.charAt(text.length() - 1) != '>') {
        addAt(out, text, s, "وسم XML غير مغلق");
        break;
      }
      String body = text.substring(s + 1, e - 1).trim();
      if (body.startsWith("?") || body.startsWith("!")) {
        i = e;
        continue;
      }
      boolean closing = body.startsWith("/"), self = body.endsWith("/");
      String clean = closing ? body.substring(1).trim() : body;
      Matcher m = IDENTIFIER_PATTERN.matcher(clean);
      if (!m.find()) {
        addAt(out, text, s, "اسم وسم غير صالح");
        i = e;
        continue;
      }
      String name = m.group();
      if (closing) {
        if (names.isEmpty()) addAt(out, text, s, "وسم إغلاق بلا افتتاح: " + name);
        else if (!names.peek().equals(name))
          addAt(out, text, s, "متوقع إغلاق " + names.peek() + " بدل " + name);
        else {
          names.pop();
          offsets.pop();
        }
      } else if (!self) {
        names.push(name);
        offsets.push(s);
      }
      i = e;
    }
    while (!names.isEmpty()) {
      String name = names.removeLast();
      int offset = offsets.removeLast();
      addAt(out, text, offset, "وسم غير مغلق: " + name);
    }
    return out;
  }

  private static void addAt(List<Diagnostic> out, String text, int offset, String message) {
    int line = 1, col = 1;
    for (int i = 0; i < offset && i < text.length(); i++) {
      if (text.charAt(i) == '\n') {
        line++;
        col = 1;
      } else col++;
    }
    out.add(new Diagnostic(offset, line, col, message));
  }

  public static String format(String fileName, String source) {
    return isXml(fileName) ? formatXml(source) : formatCode(source);
  }

  private static String formatCode(String source) {
    String text = source.replace("\r", "");
    StringBuilder output = new StringBuilder();
    StringBuilder line = new StringBuilder();
    int indent = 0, parentheses = 0, brackets = 0;
    boolean pendingSpace = false;
    for (int i = 0; i < text.length(); i++) {
      char c = text.charAt(i), next = i + 1 < text.length() ? text.charAt(i + 1) : 0;
      if (c == '/' && next == '/') {
        appendPendingSpace(line, pendingSpace);
        int end = text.indexOf('\n', i);
        if (end < 0) end = text.length();
        line.append(text, i, end);
        emitFormattedLine(output, line, indent);
        pendingSpace = false;
        i = end;
        continue;
      }
      if (c == '/' && next == '*') {
        appendPendingSpace(line, pendingSpace);
        int end = text.indexOf("*/", i + 2);
        if (end < 0) end = text.length() - 2;
        String comment = text.substring(i, Math.min(text.length(), end + 2));
        String[] parts = comment.split("\n", -1);
        for (int part = 0; part < parts.length; part++) {
          if (part > 0) emitFormattedLine(output, line, indent);
          line.append(parts[part].trim());
        }
        pendingSpace = true;
        i = Math.min(text.length() - 1, end + 1);
        continue;
      }
      if (c == '"' || c == '\'' || c == '`') {
        appendPendingSpace(line, pendingSpace);
        char quote = c;
        line.append(c);
        boolean escape = false;
        while (++i < text.length()) {
          char value = text.charAt(i);
          line.append(value);
          if (escape) escape = false;
          else if (value == '\\') escape = true;
          else if (value == quote) break;
        }
        pendingSpace = false;
        continue;
      }
      if (Character.isWhitespace(c)) {
        pendingSpace = line.length() > 0;
        continue;
      }
      if (c == '{') {
        if (line.length() > 0
            && line.charAt(line.length() - 1) != ' '
            && line.charAt(line.length() - 1) != '('
            && line.charAt(line.length() - 1) != '[') {
          line.append(' ');
        }
        line.append('{');
        emitFormattedLine(output, line, indent++);
        pendingSpace = false;
        continue;
      }
      if (c == '}') {
        emitFormattedLine(output, line, indent);
        indent = Math.max(0, indent - 1);
        line.append('}');
        int after = nextNonWhitespace(text, i + 1);
        boolean joinsWord =
            startsWord(text, after, "else")
                || startsWord(text, after, "catch")
                || startsWord(text, after, "finally")
                || startsWord(text, after, "while");
        boolean joinsPunctuation =
            after < text.length() && ");,.]".indexOf(text.charAt(after)) >= 0;
        if (joinsWord) pendingSpace = true;
        else if (joinsPunctuation) pendingSpace = false;
        else emitFormattedLine(output, line, indent);
        continue;
      }
      if (c == '(') parentheses++;
      else if (c == ')') parentheses = Math.max(0, parentheses - 1);
      else if (c == '[') brackets++;
      else if (c == ']') brackets = Math.max(0, brackets - 1);

      if (c == ';') {
        trimTrailingSpace(line);
        line.append(c);
        if (parentheses == 0 && brackets == 0) emitFormattedLine(output, line, indent);
        else line.append(' ');
        pendingSpace = false;
        continue;
      }
      if (c == ',') {
        trimTrailingSpace(line);
        line.append(", ");
        pendingSpace = false;
        continue;
      }
      if (").]".indexOf(c) >= 0) {
        trimTrailingSpace(line);
        line.append(c);
      } else {
        appendPendingSpace(line, pendingSpace);
        line.append(c);
      }
      pendingSpace = false;
    }
    emitFormattedLine(output, line, indent);
    while (output.length() > 0 && output.charAt(output.length() - 1) == '\n')
      output.setLength(output.length() - 1);
    return output.toString();
  }

  private static boolean startsWord(String text, int offset, String word) {
    if (offset < 0
        || offset + word.length() > text.length()
        || !text.regionMatches(offset, word, 0, word.length())) return false;
    int end = offset + word.length();
    return end == text.length() || !Character.isJavaIdentifierPart(text.charAt(end));
  }

  private static void appendPendingSpace(StringBuilder line, boolean pending) {
    if (pending && line.length() > 0 && line.charAt(line.length() - 1) != ' ') line.append(' ');
  }

  private static void trimTrailingSpace(StringBuilder line) {
    while (line.length() > 0 && Character.isWhitespace(line.charAt(line.length() - 1)))
      line.setLength(line.length() - 1);
  }

  private static void emitFormattedLine(StringBuilder output, StringBuilder line, int indent) {
    trimTrailingSpace(line);
    int start = 0;
    while (start < line.length() && Character.isWhitespace(line.charAt(start))) start++;
    if (start >= line.length()) {
      line.setLength(0);
      return;
    }
    for (int i = 0; i < Math.max(0, indent); i++) output.append("    ");
    output.append(line, start, line.length()).append('\n');
    line.setLength(0);
  }

  private static String formatXml(String source) {
    String normalized = source.replaceAll(">\\s*<", ">\n<");
    String[] lines = normalized.replace("\r", "").split("\n", -1);
    StringBuilder out = new StringBuilder();
    int indent = 0;
    for (String raw : lines) {
      String t = rtrim(raw).trim();
      if (t.isEmpty()) continue;
      boolean close = t.startsWith("</");
      if (close) indent = Math.max(0, indent - 1);
      for (int j = 0; j < indent; j++) out.append("    ");
      out.append(t).append('\n');
      if (t.startsWith("<")
          && !t.startsWith("</")
          && !t.startsWith("<?")
          && !t.startsWith("<!")
          && !t.endsWith("/>")
          && !t.matches(".*</[^>]+>.*")) indent++;
    }
    if (out.length() > 0) out.setLength(out.length() - 1);
    return out.toString();
  }

  private static String rtrim(String s) {
    int i = s.length();
    while (i > 0 && Character.isWhitespace(s.charAt(i - 1))) i--;
    return s.substring(0, i);
  }

  public static List<String> complete(String fileName, String text, int cursor) {
    int at = Math.max(0, Math.min(cursor, text.length())), start = at;
    while (start > 0 && Character.isJavaIdentifierPart(text.charAt(start - 1))) start--;
    String prefix = text.substring(start, at).toLowerCase(Locale.US);
    TreeSet<String> values = new TreeSet<>();
    values.addAll(JAVA_WORDS);
    values.addAll(COMMON_WORDS);
    Matcher m = IDENTIFIER_PATTERN.matcher(text);
    while (m.find()) if (m.group().length() > 1) values.add(m.group());
    ArrayList<String> out = new ArrayList<>();
    for (String value : values)
      if (prefix.isEmpty() || value.toLowerCase(Locale.US).startsWith(prefix)) out.add(value);
    if (out.size() > 80) return new ArrayList<>(out.subList(0, 80));
    return out;
  }

  public static int completionStart(String text, int cursor) {
    int start = Math.max(0, Math.min(cursor, text.length()));
    while (start > 0 && Character.isJavaIdentifierPart(text.charAt(start - 1))) start--;
    return start;
  }

  private static boolean isXml(String name) {
    if (name == null) return false;
    String n = name.toLowerCase(Locale.US);
    return n.endsWith(".xml") || n.endsWith(".html") || n.endsWith(".htm");
  }

  private static Set<String> set(String values) {
    return new HashSet<>(Arrays.asList(values.split(" ")));
  }
}
