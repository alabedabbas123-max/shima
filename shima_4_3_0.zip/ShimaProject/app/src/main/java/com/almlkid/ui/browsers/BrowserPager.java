package com.almlkid.ui.browsers;

import android.app.AlertDialog;
import android.content.*;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.support.v4.provider.DocumentFile;
import android.util.AttributeSet;
import android.view.*;
import android.webkit.MimeTypeMap;
import android.widget.*;
import com.almlkid.kay.ui.ProjectSymbolIndex;
import com.shima.demo.R;
import com.shima.demo.ThemeConfig;
import java.io.*;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/** Complete project browser. SAF is the primary backend; java.io.File is a fallback. */
public class BrowserPager extends LinearLayout {
  public interface Listener {
    void selected(String name, String content);
  }

  public interface MutationListener {
    void completed(boolean success, String fileName, String content, String message);
  }

  public interface SaveListener {
    void completed(boolean success, String message);
  }

  public interface DefinitionOpenListener {
    void completed(boolean success, String fileName, String content, int offset, String message);
  }

  public interface ActionListener {
    void onCreateProject();

    void onCloneGit();

    void onStoragePermissionRequested();

    void onProjectOpened(String name, String path);

    void onSelectProjectFolder();
  }

  private static final int ACTION_CREATE_PROJECT = 1,
      ACTION_CLONE = 2,
      ACTION_PERMISSION = 3,
      ACTION_UP_DOCUMENT = 4,
      ACTION_SELECT_TREE = 5,
      ACTION_EMPTY = 6;
  private Listener listener;
  private ActionListener actions;
  private TextView pathLabel;
  private View header;
  private ListView list;
  private final ArrayList<Entry> entries = new ArrayList<>();
  private final Map<String, Entry> openedEntries = Collections.synchronizedMap(new HashMap<>());
  private ExecutorService fileReader = Executors.newSingleThreadExecutor();
  private ExecutorService directoryReader = Executors.newFixedThreadPool(2);
  private ExecutorService symbolWorker = Executors.newSingleThreadExecutor();
  private final HashMap<String, Entry> symbolFiles = new HashMap<>();
  private final android.os.Handler mainHandler =
      new android.os.Handler(android.os.Looper.getMainLooper());
  private final LinkedHashMap<String, List<Entry>> directoryCache =
      new LinkedHashMap<String, List<Entry>>(64, 0.75f, true) {
        @Override
        protected boolean removeEldestEntry(Map.Entry<String, List<BrowserPager.Entry>> eldest) {
          return size() > 40;
        }
      };
  private final HashSet<String> prefetching = new HashSet<>();
  private final LinkedHashMap<String, String> fileContentCache =
      new LinkedHashMap<String, String>(24, 0.75f, true) {
        @Override
        protected boolean removeEldestEntry(Map.Entry<String, String> eldest) {
          return size() > 12;
        }
      };
  private int openGeneration, navigationGeneration;
  private Future<?> openTask;
  private Uri pendingProjectDetection, projectDocumentUri;
  private File currentFile, projectFile;
  private DocumentFile documentRoot, currentDocument;
  private final ArrayDeque<DocumentFile> documentParents = new ArrayDeque<>();
  private boolean usingDocuments;

  private static class Entry {
    String name;
    File file;
    DocumentFile document;
    Uri documentUri;
    long size;
    boolean folder;
    int icon, action, depth;

    Entry(String n, File f, DocumentFile d, boolean dir, int i, int a) {
      this(n, f, d, dir, i, a, 0);
    }

    Entry(String n, File f, DocumentFile d, boolean dir, int i, int a, int level) {
      name = n;
      file = f;
      document = d;
      documentUri = d == null ? null : d.getUri();
      folder = dir;
      icon = i;
      action = a;
      depth = level;
      size = -1;
    }

    Entry(String n, Uri uri, boolean dir, long length, int drawable) {
      name = n;
      documentUri = uri;
      folder = dir;
      size = length;
      icon = drawable;
    }
  }

  public BrowserPager(Context c) {
    super(c);
    init();
  }

  public BrowserPager(Context c, AttributeSet a) {
    super(c, a);
    init();
  }

  public BrowserPager(Context c, AttributeSet a, int s) {
    super(c, a, s);
    init();
  }

  public void setOnFileSelectedListener(Listener l) {
    listener = l;
  }

  public void setActionListener(ActionListener l) {
    actions = l;
  }

  private void init() {
    setLayoutDirection(LAYOUT_DIRECTION_LTR);
    setTextDirection(TEXT_DIRECTION_LTR);
    setOrientation(VERTICAL);
    setBackgroundColor(Color.rgb(25, 25, 25));
    header = LayoutInflater.from(getContext()).inflate(R.layout.browser_header, this, false);
    header.setLayoutDirection(LAYOUT_DIRECTION_LTR);
    pathLabel = header.findViewById(R.id.browserHeaderLabel);
    pathLabel.setTextDirection(TEXT_DIRECTION_LTR);
    pathLabel.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
    ((ImageView) header.findViewById(R.id.browserHeaderIcon))
        .setImageResource(R.drawable.folder_open);
    header.findViewById(R.id.browserHeaderMenuButton).setOnClickListener(this::showHeaderMenu);
    addView(header, new LayoutParams(-1, -2));
    View body = LayoutInflater.from(getContext()).inflate(R.layout.filebrowser, this, false);
    list = body.findViewById(R.id.filebrowserFileList);
    list.setBackgroundColor(Color.rgb(25, 25, 25));
    list.setCacheColorHint(Color.TRANSPARENT);
    list.setDivider(new ColorDrawable(Color.TRANSPARENT));
    list.setDividerHeight(0);
    list.setAdapter(new FolderAdapter());
    list.setOnItemClickListener((p, v, pos, id) -> activate(entries.get(pos)));
    list.setOnItemLongClickListener(
        (p, v, pos, id) -> {
          Entry e = entries.get(pos);
          if (e.action == 0) showEntryMenu(v, e);
          return true;
        });
    addView(body, new LayoutParams(-1, 0, 1));
    applyTheme();
    pathLabel.setText("جارٍ تحميل المشاريع…");
    restoreProjectRootReference();
    post(
        () -> {
          if (!restoreDocumentTree()) {
            loadFile(new File(Environment.getExternalStorageDirectory(), "AppProjects"));
          }
        });
  }

  public void openTree(Uri treeUri) {
    try {
      getContext()
          .getContentResolver()
          .takePersistableUriPermission(
              treeUri,
              Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
    } catch (Exception writeNotGranted) {
      try {
        getContext()
            .getContentResolver()
            .takePersistableUriPermission(treeUri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
      } catch (Exception ignored) {
      }
    }
    getContext()
        .getSharedPreferences("file_browser", Context.MODE_PRIVATE)
        .edit()
        .putString("tree_uri", treeUri.toString())
        .apply();
    DocumentFile root = DocumentFile.fromTreeUri(getContext(), treeUri);
    if (root == null) {
      toast("تعذر فتح المجلد المحدد");
      return;
    }
    usingDocuments = true;
    documentRoot = root;
    documentParents.clear();
    pendingProjectDetection = root.getUri();
    loadDocument(root, false);
  }

  private boolean restoreDocumentTree() {
    String saved =
        getContext()
            .getSharedPreferences("file_browser", Context.MODE_PRIVATE)
            .getString("tree_uri", "");
    if (saved.isEmpty()) return false;
    try {
      Uri savedUri = Uri.parse(saved);
      if (!hasPersistedReadPermission(savedUri)) {
        clearSavedTree();
        return false;
      }
      DocumentFile root = DocumentFile.fromTreeUri(getContext(), savedUri);
      if (root != null) {
        usingDocuments = true;
        documentRoot = root;
        documentParents.clear();
        loadDocument(root, false);
        return true;
      }
    } catch (Exception ignored) {
    }
    clearSavedTree();
    return false;
  }

  private boolean hasPersistedReadPermission(Uri treeUri) {
    for (UriPermission permission :
        getContext().getContentResolver().getPersistedUriPermissions()) {
      if (permission.isReadPermission() && permission.getUri().equals(treeUri)) return true;
    }
    return false;
  }

  private void clearSavedTree() {
    getContext()
        .getSharedPreferences("file_browser", Context.MODE_PRIVATE)
        .edit()
        .remove("tree_uri")
        .apply();
  }

  private void rememberProjectRoot() {
    getContext()
        .getSharedPreferences("file_browser", Context.MODE_PRIVATE)
        .edit()
        .putString("project_uri", projectDocumentUri == null ? "" : projectDocumentUri.toString())
        .putString("project_file", projectFile == null ? "" : projectFile.getAbsolutePath())
        .apply();
  }

  private void restoreProjectRootReference() {
    android.content.SharedPreferences preferences =
        getContext().getSharedPreferences("file_browser", Context.MODE_PRIVATE);
    String uri = preferences.getString("project_uri", "");
    String file = preferences.getString("project_file", "");
    if (!uri.isEmpty()) {
      projectDocumentUri = Uri.parse(uri);
      projectFile = null;
    } else if (!file.isEmpty()) {
      projectFile = new File(file);
      projectDocumentUri = null;
    }
  }

  public void applyTheme() {
    ThemeConfig theme = new ThemeConfig(getContext());
    int background = theme.isDark() ? Color.rgb(25, 25, 25) : Color.rgb(250, 250, 250);
    int chrome = Color.rgb(31, 31, 31);
    setBackgroundColor(background);
    if (list != null) {
      list.setBackgroundColor(background);
      ((BaseAdapter) list.getAdapter()).notifyDataSetChanged();
    }
    if (header != null) header.setBackgroundColor(chrome);
    if (pathLabel != null) pathLabel.setTextColor(Color.WHITE);
  }

  public void refresh() {
    if (usingDocuments && currentDocument != null) {
      invalidateDirectory(documentCacheKey(currentDocument.getUri()));
      loadDocument(currentDocument, true);
    } else if (currentFile != null) {
      invalidateDirectory(fileCacheKey(currentFile));
      loadFile(currentFile);
    }
  }

  public void createFile() {
    promptCreate(false);
  }

  public void createFolder() {
    promptCreate(true);
  }

  public String getCurrentPath() {
    return usingDocuments && currentDocument != null
        ? pathForDocument(currentDocument)
        : currentFile == null ? "" : currentFile.getAbsolutePath();
  }

  public void saveOpenedFileAsync(String name, String content, SaveListener listener) {
    Entry entry = openedEntries.get(name);
    if (entry == null) {
      if (listener != null) listener.completed(false, "تعذر العثور على الملف المفتوح");
      return;
    }
    fileReader.execute(
        () -> {
          boolean success = false;
          String message;
          try {
            OutputStream output =
                entry.documentUri != null
                    ? getContext().getContentResolver().openOutputStream(entry.documentUri, "wt")
                    : new FileOutputStream(entry.file, false);
            if (output == null) throw new IOException("مزود الملفات لم يسمح بالكتابة");
            output.write(content.getBytes("UTF-8"));
            output.flush();
            output.close();
            cacheFileContent(fileContentKey(entry), content);
            success = true;
            message = "تم حفظ الملف";
          } catch (Exception error) {
            message = "تعذر الحفظ: " + error.getMessage();
          }
          final boolean result = success;
          final String resultMessage = message;
          mainHandler.post(
              () -> {
                if (listener != null) listener.completed(result, resultMessage);
              });
        });
  }

  private void activate(Entry e) {
    if (e.action == ACTION_CREATE_PROJECT) {
      if (actions != null) actions.onCreateProject();
      return;
    }
    if (e.action == ACTION_CLONE) {
      if (actions != null) actions.onCloneGit();
      return;
    }
    if (e.action == ACTION_PERMISSION) {
      if (actions != null) actions.onStoragePermissionRequested();
      return;
    }
    if (e.action == ACTION_SELECT_TREE) {
      if (actions != null) actions.onSelectProjectFolder();
      return;
    }
    if (e.action == ACTION_UP_DOCUMENT) {
      if (!documentParents.isEmpty()) loadDocument(documentParents.removeLast(), true);
      return;
    }
    if (e.action == ACTION_EMPTY) return;
    if (e.folder) {
      if (usingDocuments) {
        DocumentFile target =
            e.document != null
                ? e.document
                : DocumentFile.fromSingleUri(getContext(), e.documentUri);
        if (target == null) {
          toast("تعذر فتح المجلد");
          return;
        }
        if (currentDocument == documentRoot && actions != null) {
          projectDocumentUri = e.documentUri;
          projectFile = null;
          rememberProjectRoot();
          actions.onProjectOpened(e.name, pathForUri(e.documentUri));
        }
        documentParents.addLast(currentDocument);
        loadDocument(target, true);
      } else {
        if (currentFile != null && currentFile.getName().equals("AppProjects") && actions != null) {
          projectFile = e.file;
          projectDocumentUri = null;
          rememberProjectRoot();
          actions.onProjectOpened(e.name, e.file.getAbsolutePath());
        }
        loadFile(e.file);
      }
      return;
    }
    openedEntries.put(e.name, e);
    final int request = ++openGeneration;
    final String cacheKey = fileContentKey(e);
    String cached = cachedFileContent(cacheKey);
    if (cached != null) {
      if (listener != null) listener.selected(e.name, cached);
      return;
    }
    if (openTask != null) openTask.cancel(true);
    openTask =
        fileReader.submit(
            () -> {
              String content =
                  e.documentUri != null
                      ? readDocument(e.documentUri, e.name, e.size)
                      : readFile(e.file, e.name);
              cacheFileContent(cacheKey, content);
              mainHandler.post(
                  () -> {
                    if (request == openGeneration && listener != null) {
                      listener.selected(e.name, content);
                    }
                  });
            });
  }

  private void loadDocument(DocumentFile directory, boolean preserveParents) {
    usingDocuments = true;
    currentDocument = directory;
    currentFile = null;
    pathLabel.setText(pathForDocument(directory));
    final Uri uri = directory.getUri();
    final String key = documentCacheKey(uri);
    final int request = ++navigationGeneration;
    List<Entry> cached = cachedDirectory(key);
    if (cached != null) {
      showDocumentEntries(directory, uri, cached, request);
      return;
    }
    showLoadingEntry();
    directoryReader.execute(
        () -> {
          List<Entry> loaded;
          try {
            loaded = sortedEntries(queryDocumentChildren(uri));
            cacheDirectory(key, loaded);
          } catch (Exception error) {
            loaded = null;
          }
          final List<Entry> result = loaded;
          mainHandler.post(() -> showDocumentEntries(directory, uri, result, request));
        });
  }

  private void showDocumentEntries(
      DocumentFile directory, Uri uri, List<Entry> children, int request) {
    if (request != navigationGeneration
        || currentDocument == null
        || !currentDocument.getUri().equals(uri)) return;
    entries.clear();
    if (!documentParents.isEmpty())
      entries.add(new Entry("..", null, null, true, R.drawable.folder_open, ACTION_UP_DOCUMENT));
    if (directory == documentRoot && nameForUri(uri).equalsIgnoreCase("AppProjects")) {
      entries.add(
          new Entry(
              "إنشاء مشروع جديد...",
              null,
              null,
              false,
              R.drawable.ic_launcher_java,
              ACTION_CREATE_PROJECT));
      entries.add(
          new Entry(
              "استنساخ مستودع Git...", null, null, false, R.drawable.browser_git, ACTION_CLONE));
    }
    if (children == null) {
      entries.add(
          new Entry(
              "⚠ أعد اختيار المجلد لمنح صلاحية القراءة",
              null,
              null,
              false,
              R.drawable.folder_open,
              ACTION_SELECT_TREE));
    } else if (children.isEmpty()) {
      entries.add(
          new Entry("المجلد فارغ", null, null, false, R.drawable.folder_open, ACTION_EMPTY));
    } else {
      entries.addAll(children);
    }
    notifyList();
    if (pendingProjectDetection != null && pendingProjectDetection.equals(uri)) {
      pendingProjectDetection = null;
      if (children != null && entriesLookLikeProject() && actions != null) {
        projectDocumentUri = uri;
        projectFile = null;
        rememberProjectRoot();
        actions.onProjectOpened(nameForUri(uri), pathForDocument(directory));
      }
    }
    if (children != null) prefetchDocumentChildren(children);
  }

  private void showLoadingEntry() {
    entries.clear();
    entries.add(
        new Entry("جارٍ فتح المجلد…", null, null, false, R.drawable.folder_open, ACTION_EMPTY));
    notifyList();
  }

  private List<Entry> sortedEntries(Entry[] source) {
    Arrays.sort(
        source,
        (a, b) -> {
          if (a.folder != b.folder) return a.folder ? -1 : 1;
          return a.name.compareToIgnoreCase(b.name);
        });
    return new ArrayList<>(Arrays.asList(source));
  }

  private void prefetchDocumentChildren(List<Entry> children) {
    ArrayList<Entry> folders = new ArrayList<>();
    for (Entry entry : children) {
      if (entry.folder && entry.documentUri != null && folders.size() < 8) folders.add(entry);
    }
    if (folders.isEmpty()) return;
    directoryReader.execute(
        () -> {
          for (Entry folder : folders) {
            String key = documentCacheKey(folder.documentUri);
            synchronized (directoryCache) {
              if (directoryCache.containsKey(key) || !prefetching.add(key)) continue;
            }
            try {
              cacheDirectory(key, sortedEntries(queryDocumentChildren(folder.documentUri)));
            } catch (Exception ignored) {
            } finally {
              synchronized (directoryCache) {
                prefetching.remove(key);
              }
            }
          }
        });
  }

  private Entry[] queryDocumentChildren(Uri directoryUri) throws Exception {
    String parentId = DocumentsContract.getDocumentId(directoryUri);
    Uri childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(directoryUri, parentId);
    String[] projection = {
      DocumentsContract.Document.COLUMN_DOCUMENT_ID,
      DocumentsContract.Document.COLUMN_DISPLAY_NAME,
      DocumentsContract.Document.COLUMN_MIME_TYPE,
      DocumentsContract.Document.COLUMN_SIZE
    };
    ArrayList<Entry> result = new ArrayList<>();
    try (Cursor cursor =
        getContext().getContentResolver().query(childrenUri, projection, null, null, null)) {
      if (cursor == null) throw new IOException("Document provider returned no cursor");
      int idColumn = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DOCUMENT_ID);
      int nameColumn = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DISPLAY_NAME);
      int mimeColumn = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_MIME_TYPE);
      int sizeColumn = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_SIZE);
      while (cursor.moveToNext()) {
        String documentId = cursor.getString(idColumn);
        String name = cursor.isNull(nameColumn) ? "بدون اسم" : cursor.getString(nameColumn);
        String mime = cursor.isNull(mimeColumn) ? "" : cursor.getString(mimeColumn);
        boolean folder = DocumentsContract.Document.MIME_TYPE_DIR.equals(mime);
        long size = sizeColumn < 0 || cursor.isNull(sizeColumn) ? -1 : cursor.getLong(sizeColumn);
        Uri childUri = DocumentsContract.buildDocumentUriUsingTree(directoryUri, documentId);
        result.add(
            new Entry(name, childUri, folder, size, folder ? folderIconFor(name) : iconFor(name)));
      }
    }
    return result.toArray(new Entry[0]);
  }

  private String fileContentKey(Entry entry) {
    return entry.documentUri != null
        ? "content:" + entry.documentUri + ":" + entry.size
        : "content:" + entry.file.getAbsolutePath();
  }

  private String cachedFileContent(String key) {
    synchronized (fileContentCache) {
      return fileContentCache.get(key);
    }
  }

  private void cacheFileContent(String key, String content) {
    if (content == null || content.length() > 350000) return;
    synchronized (fileContentCache) {
      fileContentCache.put(key, content);
    }
  }

  private String documentCacheKey(Uri uri) {
    return "document:" + uri;
  }

  private String fileCacheKey(File directory) {
    return "file:" + directory.getAbsolutePath();
  }

  private List<Entry> cachedDirectory(String key) {
    synchronized (directoryCache) {
      List<Entry> value = directoryCache.get(key);
      return value == null ? null : new ArrayList<>(value);
    }
  }

  private void cacheDirectory(String key, List<Entry> value) {
    synchronized (directoryCache) {
      directoryCache.put(key, new ArrayList<>(value));
    }
  }

  private void invalidateDirectory(String key) {
    synchronized (directoryCache) {
      directoryCache.remove(key);
    }
  }

  public void indexProjectSymbols(Runnable completed) {
    symbolWorker.execute(
        () -> {
          buildSymbolIndex();
          if (completed != null) mainHandler.post(completed);
        });
  }

  public void openDefinition(
      ProjectSymbolIndex.DefinitionTarget definition, DefinitionOpenListener listener) {
    if (definition == null) {
      if (listener != null) listener.completed(false, null, null, 0, "تعذر تحديد تعريف العنصر");
      return;
    }
    if (definition.source != null) {
      if (listener != null)
        listener.completed(
            true,
            definition.fileName,
            definition.source,
            definition.offset,
            "تم فتح تعريف النظام للقراءة فقط");
      return;
    }
    symbolWorker.execute(
        () -> {
          Entry target;
          synchronized (symbolFiles) {
            target = symbolFiles.get(definition.className);
            if (target == null && definition.fileName != null)
              for (Entry candidate : symbolFiles.values())
                if (definition.fileName.equals(candidate.name)) {
                  target = candidate;
                  break;
                }
          }
          if (target == null) {
            buildSymbolIndex();
            synchronized (symbolFiles) {
              target = symbolFiles.get(definition.className);
              if (target == null && definition.fileName != null)
                for (Entry candidate : symbolFiles.values())
                  if (definition.fileName.equals(candidate.name)) {
                    target = candidate;
                    break;
                  }
            }
          }
          if (target == null) {
            mainHandler.post(
                () -> {
                  if (listener != null)
                    listener.completed(
                        false,
                        definition.fileName,
                        null,
                        0,
                        "تعذر العثور على ملف تعريف " + definition.symbol);
                });
            return;
          }
          String source = readEntryText(target);
          openedEntries.put(target.name, target);
          final Entry opened = target;
          mainHandler.post(
              () -> {
                if (listener != null)
                  listener.completed(
                      true,
                      opened.name,
                      source,
                      Math.min(definition.offset, source.length()),
                      "تم الانتقال إلى " + definition.symbol);
              });
        });
  }

  public void createMissingMember(
      ProjectSymbolIndex.MissingMember member, MutationListener listener) {
    symbolWorker.execute(
        () -> {
          Entry target;
          synchronized (symbolFiles) {
            target = symbolFiles.get(member.className);
          }
          if (target == null) {
            buildSymbolIndex();
            synchronized (symbolFiles) {
              target = symbolFiles.get(member.className);
            }
          }
          if (target == null) {
            postMutation(
                listener, false, null, null, "تعذر العثور على " + member.className + ".java");
            return;
          }
          String source = readEntryText(target);
          int closing = source.lastIndexOf('}');
          if (closing < 0) {
            postMutation(listener, false, target.name, null, "ملف الكلاس لا يحتوي قوس إغلاق");
            return;
          }
          if (ProjectSymbolIndex.hasMethod(member.className, member.methodName)) {
            postMutation(listener, false, target.name, source, "الدالة موجودة بالفعل");
            return;
          }
          String updated =
              source.substring(0, closing).replaceFirst("\\s+$", "")
                  + "\n"
                  + member.methodSource()
                  + source.substring(closing);
          if (!writeEntryText(target, updated)) {
            postMutation(listener, false, target.name, null, "تعذر تعديل ملف الكلاس");
            return;
          }
          ProjectSymbolIndex.registerSource(target.name, updated);
          cacheFileContent(fileContentKey(target), updated);
          openedEntries.put(target.name, target);
          postMutation(
              listener, true, target.name, updated, "تم إنشاء الدالة " + member.methodName);
        });
  }

  private void buildSymbolIndex() {
    ProjectSymbolIndex.clear();
    synchronized (symbolFiles) {
      symbolFiles.clear();
    }
    ArrayDeque<Entry> queue = new ArrayDeque<>();
    if (projectDocumentUri != null)
      queue.add(
          new Entry(
              nameForUri(projectDocumentUri), projectDocumentUri, true, -1, R.drawable.folder));
    else if (projectFile != null)
      queue.add(new Entry(projectFile.getName(), projectFile, null, true, R.drawable.folder, 0));
    else return;
    int visited = 0;
    while (!queue.isEmpty() && visited < 4000 && !Thread.currentThread().isInterrupted()) {
      Entry item = queue.removeFirst();
      visited++;
      if (item.folder) {
        if (item.documentUri != null) {
          try {
            for (Entry child : queryDocumentChildren(item.documentUri)) queue.addLast(child);
          } catch (Exception ignored) {
          }
        } else {
          List<Entry> children = queryFileChildren(item.file);
          if (children != null) queue.addAll(children);
        }
        continue;
      }
      if (!item.name.toLowerCase(Locale.US).endsWith(".java")) continue;
      String source = readEntryText(item);
      ProjectSymbolIndex.registerSource(item.name, source);
      String className = item.name.substring(0, item.name.length() - 5);
      synchronized (symbolFiles) {
        symbolFiles.put(className, item);
      }
      if (visited % 20 == 0) {
        try {
          Thread.sleep(2);
        } catch (InterruptedException interrupted) {
          Thread.currentThread().interrupt();
        }
      }
    }
  }

  private String readEntryText(Entry entry) {
    try {
      InputStream input =
          entry.documentUri != null
              ? getContext().getContentResolver().openInputStream(entry.documentUri)
              : new FileInputStream(entry.file);
      return input == null ? "" : new String(readBytes(input), "UTF-8");
    } catch (Exception error) {
      return "";
    }
  }

  private boolean writeEntryText(Entry entry, String content) {
    try {
      OutputStream output =
          entry.documentUri != null
              ? getContext().getContentResolver().openOutputStream(entry.documentUri, "wt")
              : new FileOutputStream(entry.file, false);
      if (output == null) return false;
      output.write(content.getBytes("UTF-8"));
      output.flush();
      output.close();
      return true;
    } catch (Exception error) {
      return false;
    }
  }

  private void postMutation(
      MutationListener listener, boolean success, String name, String content, String message) {
    if (listener != null)
      mainHandler.post(() -> listener.completed(success, name, content, message));
  }

  private boolean canReadDirectStorage() {
    return android.os.Build.VERSION.SDK_INT < 30 || Environment.isExternalStorageManager();
  }

  public boolean needsProjectFolderSelection() {
    return !usingDocuments && !canReadDirectStorage();
  }

  private void loadFile(File directory) {
    usingDocuments = false;
    currentFile = directory;
    currentDocument = null;
    pathLabel.setText(shortPath(directory));
    if (!canReadDirectStorage()) {
      entries.clear();
      entries.add(
          new Entry(
              "اختيار مجلد المشروع لإظهار جميع ملفاته...",
              null,
              null,
              false,
              R.drawable.folder_open,
              ACTION_SELECT_TREE));
      entries.add(
          new Entry(
              "أو منح صلاحية جميع الملفات...",
              null,
              null,
              false,
              R.drawable.folder_open,
              ACTION_PERMISSION));
      notifyList();
      return;
    }
    final String key = fileCacheKey(directory);
    final int request = ++navigationGeneration;
    List<Entry> cached = cachedDirectory(key);
    if (cached != null) {
      showFileEntries(directory, cached, request);
      return;
    }
    showLoadingEntry();
    directoryReader.execute(
        () -> {
          List<Entry> loaded = queryFileChildren(directory);
          if (loaded != null) cacheDirectory(key, loaded);
          mainHandler.post(() -> showFileEntries(directory, loaded, request));
        });
  }

  private List<Entry> queryFileChildren(File directory) {
    File[] files;
    try {
      files = directory.listFiles();
    } catch (SecurityException error) {
      return null;
    }
    if (files == null) return null;
    Arrays.sort(
        files,
        (a, b) -> {
          if (a.isDirectory() != b.isDirectory()) return a.isDirectory() ? -1 : 1;
          return a.getName().compareToIgnoreCase(b.getName());
        });
    ArrayList<Entry> result = new ArrayList<>(files.length);
    for (File file : files) {
      String name = file.getName();
      boolean folder = file.isDirectory();
      result.add(
          new Entry(name, file, null, folder, folder ? folderIconFor(name) : iconFor(name), 0, 0));
    }
    return result;
  }

  private void showFileEntries(File directory, List<Entry> children, int request) {
    if (request != navigationGeneration || currentFile == null || !currentFile.equals(directory))
      return;
    entries.clear();
    if (directory.getParentFile() != null)
      entries.add(
          new Entry("..", directory.getParentFile(), null, true, R.drawable.folder_open, 0));
    if (directory.getName().equals("AppProjects")) {
      entries.add(
          new Entry(
              "اختيار مجلد المشاريع...",
              null,
              null,
              false,
              R.drawable.folder_open,
              ACTION_SELECT_TREE));
      entries.add(
          new Entry(
              "إنشاء مشروع جديد...",
              null,
              null,
              false,
              R.drawable.ic_launcher_java,
              ACTION_CREATE_PROJECT));
      entries.add(
          new Entry(
              "استنساخ مستودع Git...", null, null, false, R.drawable.browser_git, ACTION_CLONE));
    }
    if (children == null) {
      entries.add(
          new Entry(
              "اختيار المجلد لعرض جميع ملفاته...",
              null,
              null,
              false,
              R.drawable.folder_open,
              ACTION_SELECT_TREE));
      entries.add(
          new Entry(
              "منح صلاحية جميع الملفات...",
              null,
              null,
              false,
              R.drawable.folder_open,
              ACTION_PERMISSION));
    } else if (children.isEmpty()) {
      entries.add(
          new Entry("المجلد فارغ", null, null, false, R.drawable.folder_open, ACTION_EMPTY));
    } else {
      entries.addAll(children);
    }
    notifyList();
    if (children != null) prefetchFileChildren(children);
  }

  private void prefetchFileChildren(List<Entry> children) {
    ArrayList<File> folders = new ArrayList<>();
    for (Entry entry : children) {
      if (entry.folder && entry.file != null && folders.size() < 8) folders.add(entry.file);
    }
    if (folders.isEmpty()) return;
    directoryReader.execute(
        () -> {
          for (File folder : folders) {
            String key = fileCacheKey(folder);
            synchronized (directoryCache) {
              if (directoryCache.containsKey(key) || !prefetching.add(key)) continue;
            }
            try {
              List<Entry> result = queryFileChildren(folder);
              if (result != null) cacheDirectory(key, result);
            } finally {
              synchronized (directoryCache) {
                prefetching.remove(key);
              }
            }
          }
        });
  }

  private void notifyList() {
    ((BaseAdapter) list.getAdapter()).notifyDataSetChanged();
  }

  private void showHeaderMenu(View anchor) {
    PopupMenu m = new PopupMenu(getContext(), anchor);
    String[] items = {
      "ملف جديد",
      "مجلد جديد",
      "تحديث",
      "اختيار مجلد المشاريع",
      "نسخ مسار المجلد",
      "منح صلاحية الملفات"
    };
    for (String x : items) m.getMenu().add(x);
    m.setOnMenuItemClickListener(
        i -> {
          String x = i.getTitle().toString();
          if (x.equals("ملف جديد")) promptCreate(false);
          else if (x.equals("مجلد جديد")) promptCreate(true);
          else if (x.equals("تحديث")) refresh();
          else if (x.equals("اختيار مجلد المشاريع")) {
            if (actions != null) actions.onSelectProjectFolder();
          } else if (x.startsWith("نسخ")) copyCurrentPath();
          else if (actions != null) actions.onStoragePermissionRequested();
          return true;
        });
    m.show();
  }

  private void showEntryMenu(View anchor, Entry e) {
    PopupMenu m = new PopupMenu(getContext(), anchor);
    for (String x : new String[] {"فتح", "إعادة تسمية", "حذف", "نسخ المسار"}) m.getMenu().add(x);
    m.setOnMenuItemClickListener(
        i -> {
          String x = i.getTitle().toString();
          if (x.equals("فتح")) activate(e);
          else if (x.equals("إعادة تسمية")) promptRename(e);
          else if (x.equals("حذف")) confirmDelete(e);
          else copyEntryPath(e);
          return true;
        });
    m.show();
  }

  private void promptCreate(boolean folder) {
    EditText input = new EditText(getContext());
    input.setHint(folder ? "اسم المجلد" : "اسم الملف مع الامتداد");
    input.setSingleLine(true);
    new AlertDialog.Builder(getContext())
        .setTitle(folder ? "إنشاء مجلد" : "إنشاء ملف")
        .setView(input)
        .setNegativeButton("إلغاء", null)
        .setPositiveButton(
            "إنشاء",
            (d, w) -> {
              String name = input.getText().toString().trim();
              if (!validName(name)) return;
              final boolean documents = usingDocuments;
              final DocumentFile documentParent = currentDocument;
              final File fileParent = currentFile;
              directoryReader.execute(
                  () -> {
                    boolean success = false;
                    String error = "تعذر الإنشاء أو أن الاسم موجود";
                    try {
                      if (documents) success = createDocumentChild(documentParent, folder, name);
                      else {
                        if (!fileParent.exists()) fileParent.mkdirs();
                        File target = new File(fileParent, name);
                        success = folder ? target.mkdirs() : target.createNewFile();
                      }
                    } catch (Exception exception) {
                      error = "تعذر الإنشاء: " + exception.getMessage();
                    }
                    final boolean result = success;
                    final String message = error;
                    mainHandler.post(
                        () -> {
                          if (result) refresh();
                          else toast(message);
                        });
                  });
            })
        .show();
  }

  private boolean createDocumentChild(DocumentFile parent, boolean folder, String name) {
    try {
      String mime = folder ? DocumentsContract.Document.MIME_TYPE_DIR : mimeFor(name);
      Uri created =
          DocumentsContract.createDocument(
              getContext().getContentResolver(), parent.getUri(), mime, name);
      return created != null;
    } catch (Exception directCreateFailed) {
      DocumentFile created =
          folder ? parent.createDirectory(name) : parent.createFile(mimeFor(name), name);
      return created != null;
    }
  }

  private void promptRename(Entry e) {
    EditText input = new EditText(getContext());
    input.setText(e.name);
    input.setSelectAllOnFocus(true);
    new AlertDialog.Builder(getContext())
        .setTitle("إعادة تسمية")
        .setView(input)
        .setNegativeButton("إلغاء", null)
        .setPositiveButton(
            "حفظ",
            (d, w) -> {
              String name = input.getText().toString().trim();
              if (!validName(name)) return;
              final boolean documents = usingDocuments;
              directoryReader.execute(
                  () -> {
                    boolean success =
                        documents
                            ? renameDocument(e.documentUri, name)
                            : e.file.renameTo(new File(e.file.getParentFile(), name));
                    mainHandler.post(
                        () -> {
                          if (success) refresh();
                          else toast("تعذر تغيير الاسم");
                        });
                  });
            })
        .show();
  }

  private void confirmDelete(Entry e) {
    new AlertDialog.Builder(getContext())
        .setTitle("حذف")
        .setMessage("هل تريد حذف " + e.name + "؟")
        .setNegativeButton("إلغاء", null)
        .setPositiveButton(
            "حذف",
            (d, w) -> {
              final boolean documents = usingDocuments;
              directoryReader.execute(
                  () -> {
                    boolean success =
                        documents ? deleteDocument(e.documentUri) : deleteRecursively(e.file);
                    mainHandler.post(
                        () -> {
                          if (success) refresh();
                          else toast("تعذر الحذف");
                        });
                  });
            })
        .show();
  }

  private boolean renameDocument(Uri uri, String name) {
    try {
      return uri != null
          && DocumentsContract.renameDocument(getContext().getContentResolver(), uri, name) != null;
    } catch (Exception error) {
      return false;
    }
  }

  private boolean deleteDocument(Uri uri) {
    try {
      return uri != null
          && DocumentsContract.deleteDocument(getContext().getContentResolver(), uri);
    } catch (Exception error) {
      return false;
    }
  }

  private boolean deleteRecursively(File f) {
    if (f.isDirectory()) {
      File[] c = f.listFiles();
      if (c != null) for (File x : c) if (!deleteRecursively(x)) return false;
    }
    return f.delete();
  }

  private String readDocument(Uri uri, String name, long size) {
    try {
      InputStream in = getContext().getContentResolver().openInputStream(uri);
      if (in == null) return "تعذر فتح الملف";
      byte[] data = readBytes(in);
      return isTextFile(name, data)
          ? new String(data, "UTF-8")
          : binaryPreview(pathForUri(uri), size, data);
    } catch (Exception e) {
      return "تعذر فتح الملف:\n" + e;
    }
  }

  private String readFile(File file, String name) {
    try {
      FileInputStream in = new FileInputStream(file);
      byte[] data = readBytes(in);
      return isTextFile(name, data)
          ? new String(data, "UTF-8")
          : binaryPreview(file.getAbsolutePath(), file.length(), data);
    } catch (Exception e) {
      return "تعذر فتح الملف:\n" + e;
    }
  }

  private byte[] readBytes(InputStream in) throws IOException {
    ByteArrayOutputStream out = new ByteArrayOutputStream();
    byte[] b = new byte[8192];
    int n;
    while (!Thread.currentThread().isInterrupted()
        && (n = in.read(b)) > 0
        && out.size() < 1024 * 1024) out.write(b, 0, n);
    in.close();
    return out.toByteArray();
  }

  private boolean isTextFile(String name, byte[] data) {
    String n = name.toLowerCase();
    if (n.matches(
        ".*\\.(java|kt|xml|gradle|properties|json|md|txt|html|htm|css|js|ts|c|cpp|cc|h|hpp|py|sh|yaml|yml|pro|cfg|ini|csv)$"))
      return true;
    for (int i = 0; i < Math.min(512, data.length); i++) if (data[i] == 0) return false;
    return true;
  }

  private String binaryPreview(String path, long size, byte[] data) {
    StringBuilder s =
        new StringBuilder("عارض ملف ثنائي\n\nالمسار: ")
            .append(path)
            .append("\nالحجم: ")
            .append(size)
            .append(" بايت\n\nHEX:\n");
    for (int i = 0; i < Math.min(4096, data.length); i++) {
      if (i % 16 == 0) s.append(String.format("%n%08X  ", i));
      s.append(String.format("%02X ", data[i] & 255));
    }
    return s.toString();
  }

  private boolean entriesLookLikeProject() {
    for (Entry entry : entries) {
      String name = entry.name;
      if (name.equals("settings.gradle")
          || name.equals("settings.gradle.kts")
          || name.equals("AndroidManifest.xml")) return true;
    }
    return false;
  }

  private String pathForDocument(DocumentFile doc) {
    return pathForUri(doc.getUri());
  }

  private String pathForUri(Uri uri) {
    try {
      String id = DocumentsContract.getDocumentId(uri);
      if (id.startsWith("primary:")) return "/storage/emulated/0/" + id.substring(8);
      return id;
    } catch (Exception e) {
      return uri == null ? "" : uri.toString();
    }
  }

  private String shortPath(File d) {
    String p = d.getAbsolutePath(),
        base = Environment.getExternalStorageDirectory().getAbsolutePath();
    return p.startsWith(base) ? "…ulated/0" + p.substring(base.length()) : p;
  }

  private String nameForUri(Uri uri) {
    try {
      String id = DocumentsContract.getDocumentId(uri);
      int slash = id.lastIndexOf('/');
      int colon = id.lastIndexOf(':');
      int separator = Math.max(slash, colon);
      String name = separator >= 0 ? id.substring(separator + 1) : id;
      return name.isEmpty() ? "بدون اسم" : name;
    } catch (Exception error) {
      String name = uri == null ? null : uri.getLastPathSegment();
      return name == null || name.isEmpty() ? "بدون اسم" : name;
    }
  }

  private String mimeFor(String name) {
    String ext = MimeTypeMap.getFileExtensionFromUrl(name);
    String mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext.toLowerCase());
    return mime == null ? "application/octet-stream" : mime;
  }

  private int folderIconFor(String name) {
    String n = name.toLowerCase(Locale.US);
    if (n.equals("build") || n.equals("bin") || n.equals("obj") || n.startsWith(".")) {
      return R.drawable.folder_hidden;
    }
    return R.drawable.folder;
  }

  private int iconFor(String name) {
    String n = name.toLowerCase(Locale.US);
    if (n.endsWith(".java") || n.endsWith(".kt")) return R.drawable.file_type_java;
    if (n.endsWith(".xml")) return R.drawable.file_type_xml;
    if (n.endsWith(".gradle") || n.endsWith(".gradle.kts")) {
      return R.drawable.project_properties;
    }
    if (n.endsWith(".html") || n.endsWith(".htm")) return R.drawable.file_type_html;
    if (n.endsWith(".js") || n.endsWith(".ts")) return R.drawable.file_type_js;
    if (n.endsWith(".css")) return R.drawable.file_type_css;
    if (n.endsWith(".c")) return R.drawable.file_type_c;
    if (n.endsWith(".cpp") || n.endsWith(".cc") || n.endsWith(".cxx")) {
      return R.drawable.file_type_cpp;
    }
    if (n.endsWith(".h") || n.endsWith(".hpp")) return R.drawable.file_type_h;
    if (n.endsWith(".zip") || n.endsWith(".jar") || n.endsWith(".aar") || n.endsWith(".apk")) {
      return R.drawable.file_type_zip;
    }
    if (n.endsWith(".txt")
        || n.endsWith(".md")
        || n.endsWith(".markdown")
        || n.endsWith(".properties")
        || n.endsWith(".json")
        || n.endsWith(".yaml")
        || n.endsWith(".yml")
        || n.endsWith(".toml")
        || n.endsWith(".ini")
        || n.endsWith(".cfg")
        || n.endsWith(".sh")
        || n.endsWith(".py")) return R.drawable.file_type_txt;
    return R.drawable.file_type_unknown;
  }

  private void copyCurrentPath() {
    copy(usingDocuments ? pathForDocument(currentDocument) : currentFile.getAbsolutePath());
  }

  private void copyEntryPath(Entry e) {
    copy(usingDocuments ? pathForUri(e.documentUri) : e.file.getAbsolutePath());
  }

  private void copy(String value) {
    ClipboardManager c =
        (ClipboardManager) getContext().getSystemService(Context.CLIPBOARD_SERVICE);
    c.setPrimaryClip(ClipData.newPlainText("path", value));
    toast("تم نسخ المسار");
  }

  private boolean validName(String n) {
    if (n.isEmpty() || n.equals(".") || n.equals("..") || n.contains("/") || n.contains("\\")) {
      toast("اسم غير صالح");
      return false;
    }
    return true;
  }

  private void toast(String s) {
    Toast.makeText(getContext(), s, Toast.LENGTH_SHORT).show();
  }

  private class FolderAdapter extends BaseAdapter {
    public int getCount() {
      return entries.size();
    }

    public Object getItem(int p) {
      return entries.get(p);
    }

    public long getItemId(int p) {
      return p;
    }

    public View getView(int p, View v, ViewGroup parent) {
      if (v == null)
        v = LayoutInflater.from(getContext()).inflate(R.layout.filebrowser_entry, parent, false);
      Entry e = entries.get(p);
      v.setLayoutDirection(LAYOUT_DIRECTION_LTR);
      v.setPadding(dp(20 + e.depth * 18), dp(4), dp(10), dp(4));
      ((ImageView) v.findViewById(R.id.filebrowserEntryFileImage)).setImageResource(e.icon);
      TextView name = v.findViewById(R.id.filebrowserEntryName);
      name.setText(e.name);
      name.setTextDirection(TEXT_DIRECTION_LTR);
      name.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
      name.setSingleLine(false);
      name.setMaxLines(2);
      name.setEllipsize(android.text.TextUtils.TruncateAt.END);
      ThemeConfig theme = new ThemeConfig(getContext());
      name.setTextColor(theme.color(ThemeConfig.PLAIN));
      v.setBackgroundColor(Color.TRANSPARENT);
      v.setMinimumHeight(dp(57));
      return v;
    }
  }

  @Override
  protected void onAttachedToWindow() {
    super.onAttachedToWindow();
    if (fileReader.isShutdown()) fileReader = Executors.newSingleThreadExecutor();
    if (directoryReader.isShutdown()) directoryReader = Executors.newFixedThreadPool(2);
    if (symbolWorker.isShutdown()) symbolWorker = Executors.newSingleThreadExecutor();
  }

  @Override
  protected void onDetachedFromWindow() {
    openGeneration++;
    navigationGeneration++;
    fileReader.shutdownNow();
    directoryReader.shutdownNow();
    symbolWorker.shutdownNow();
    mainHandler.removeCallbacksAndMessages(null);
    super.onDetachedFromWindow();
  }

  private int dp(int n) {
    return (int) (n * getResources().getDisplayMetrics().density + .5f);
  }
}
