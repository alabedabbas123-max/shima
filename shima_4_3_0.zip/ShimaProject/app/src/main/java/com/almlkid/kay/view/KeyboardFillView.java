package com.almlkid.kay.view;

import android.content.Context;
import android.util.AttributeSet;

public class KeyboardFillView extends android.view.View {
  public KeyboardFillView(Context c) {
    super(c);
  }

  public KeyboardFillView(Context c, AttributeSet a) {
    super(c, a);
  }

  public KeyboardFillView(Context c, AttributeSet a, int s) {
    super(c, a, s);
  }
}
