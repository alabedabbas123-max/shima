package com.almlkid.kay.aide.widget;

import android.content.Context;
import android.util.AttributeSet;

public class CustomSplitView extends android.widget.LinearLayout {
  public CustomSplitView(Context c) {
    super(c);
  }

  public CustomSplitView(Context c, AttributeSet a) {
    super(c, a);
  }

  public CustomSplitView(Context c, AttributeSet a, int s) {
    super(c, a, s);
  }
}
