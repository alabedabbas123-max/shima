package com.almlkid.common;

import android.content.Context;
import android.util.AttributeSet;

public class ColorPickerView extends android.view.View {
  public ColorPickerView(Context c) {
    super(c);
  }

  public ColorPickerView(Context c, AttributeSet a) {
    super(c, a);
  }

  public ColorPickerView(Context c, AttributeSet a, int s) {
    super(c, a, s);
  }
}
