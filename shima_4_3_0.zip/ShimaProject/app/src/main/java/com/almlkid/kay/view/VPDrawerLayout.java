package com.almlkid.kay.view;

import android.content.Context;
import android.support.v4.widget.DrawerLayout;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;

/**
 * Drawer implementation used by the original main_drawer.xml. The original resource declares the
 * browser pane match_parent; the proprietary widget reserved a 60dp dark strip. This replacement
 * preserves that behavior.
 */
public class VPDrawerLayout extends DrawerLayout {
  public VPDrawerLayout(Context c) {
    super(c);
  }

  public VPDrawerLayout(Context c, AttributeSet a) {
    super(c, a);
  }

  public VPDrawerLayout(Context c, AttributeSet a, int s) {
    super(c, a, s);
  }

  @Override
  protected void onMeasure(int widthSpec, int heightSpec) {
    int width = MeasureSpec.getSize(widthSpec);
    if (getChildCount() > 1) {
      View drawer = getChildAt(1);
      ViewGroup.LayoutParams p = drawer.getLayoutParams();
      int target = Math.max(1, width - dp(60));
      if (p.width != target) {
        p.width = target;
        drawer.setLayoutParams(p);
      }
    }
    super.onMeasure(widthSpec, heightSpec);
  }

  int dp(int n) {
    return (int) (n * getResources().getDisplayMetrics().density + .5f);
  }
}
