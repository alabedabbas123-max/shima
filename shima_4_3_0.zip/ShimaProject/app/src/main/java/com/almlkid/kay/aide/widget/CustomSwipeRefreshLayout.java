package com.almlkid.kay.aide.widget;

import android.content.Context;
import android.util.AttributeSet;

public class CustomSwipeRefreshLayout extends android.widget.FrameLayout {
  public CustomSwipeRefreshLayout(Context c) {
    super(c);
  }

  public CustomSwipeRefreshLayout(Context c, AttributeSet a) {
    super(c, a);
  }

  public CustomSwipeRefreshLayout(Context c, AttributeSet a, int s) {
    super(c, a, s);
  }
}
