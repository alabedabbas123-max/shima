package com.almlkid.ui.browsers;

import android.content.Context;
import android.util.AttributeSet;

public class FindResultTextView extends android.widget.TextView {
  public FindResultTextView(Context c) {
    super(c);
  }

  public FindResultTextView(Context c, AttributeSet a) {
    super(c, a);
  }

  public FindResultTextView(Context c, AttributeSet a, int s) {
    super(c, a, s);
  }
}
