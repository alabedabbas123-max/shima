package com.almlkid.ui.views;

import android.content.Context;
import android.util.AttributeSet;

public class CompletionListView extends android.widget.ListView {
  public CompletionListView(Context c) {
    super(c);
  }

  public CompletionListView(Context c, AttributeSet a) {
    super(c, a);
  }

  public CompletionListView(Context c, AttributeSet a, int s) {
    super(c, a, s);
  }
}
