package com.almlkid.ui.preferences;

import android.content.Context;
import android.preference.CheckBoxPreference;
import android.util.AttributeSet;

/** Compatibility implementation for the original preference XML. */
@SuppressWarnings("deprecation")
public class PremiumCheckBoxPreference extends CheckBoxPreference {
  public PremiumCheckBoxPreference(Context context) {
    super(context);
  }

  public PremiumCheckBoxPreference(Context context, AttributeSet attrs) {
    super(context, attrs);
  }

  public PremiumCheckBoxPreference(Context context, AttributeSet attrs, int style) {
    super(context, attrs, style);
  }
}
