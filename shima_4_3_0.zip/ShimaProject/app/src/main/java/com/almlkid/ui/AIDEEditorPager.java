package com.almlkid.ui;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.view.*;
import android.widget.*;
import com.almlkid.kay.ui.AlmlkEditor;
import com.almlkid.kay.ui.ProjectSymbolIndex;
import com.shima.demo.R;
import com.shima.demo.ThemeConfig;
import java.util.ArrayDeque;
import java.util.LinkedHashMap;
import java.util.Map;

/** Multi-tab editor with file header, line numbers and a keyboard-only quick-key bar. */
public class AIDEEditorPager extends LinearLayout {
  public interface QuickFixListener {
    void createMissingMember(ProjectSymbolIndex.MissingMember member);
  }

  public interface SessionListener {
    void restored(boolean success);
  }

  public interface DefinitionListener {
    void requested(ProjectSymbolIndex.DefinitionTarget target);
  }

  private final LinkedHashMap<String, LinearLayout> tabs = new LinkedHashMap<>();
  private final LinkedHashMap<String, String> fileContents = new LinkedHashMap<>();
  private final LinkedHashMap<String, java.io.File> lazySessionFiles = new LinkedHashMap<>();
  private final LinkedHashMap<String, Integer> sessionCursors = new LinkedHashMap<>();
  private final LinkedHashMap<String, Integer> sessionScrollX = new LinkedHashMap<>();
  private final LinkedHashMap<String, Integer> sessionScrollY = new LinkedHashMap<>();
  private LinearLayout tabStrip, quickBar;
  private View fileHeader;
  private View editorRow;
  private TextView headerName, headerPath;
  private EditorLineNumberView lineNumbers;
  private ImageView headerIcon;
  private AlmlkEditor code;
  private String activeFile;
  private String loadingFile;
  private final ArrayDeque<String> undoHistory = new ArrayDeque<>(),
      redoHistory = new ArrayDeque<>();
  private boolean historyLocked;
  private boolean keyboardVisible, dismissedForCurrentKeyboard;
  private QuickFixListener quickFixListener;
  private DefinitionListener definitionListener;
  private int quickFixGeneration, definitionGeneration;
  private PopupWindow completionWindow;
  private java.util.concurrent.ExecutorService completionWorker =
      java.util.concurrent.Executors.newSingleThreadExecutor();
  private int completionGeneration;
  private long lastEditorErrorTime;
  private final Runnable completionTask = this::showLiveCompletions;
  private int largestVisibleHeight;

  public AIDEEditorPager(Context c) {
    super(c);
    init();
  }

  public AIDEEditorPager(Context c, AttributeSet a) {
    super(c, a);
    init();
  }

  public AIDEEditorPager(Context c, AttributeSet a, int s) {
    super(c, a, s);
    init();
  }

  private void init() {
    setLayoutDirection(LAYOUT_DIRECTION_LTR);
    setOrientation(VERTICAL);
    setBackgroundColor(Color.BLACK);
    addTabs();
    addFileHeader();
    addEditor();
    addQuickKeys();
    applyTheme();
    watchKeyboard();
    setVisibility(GONE);
  }

  private void addTabs() {
    HorizontalScrollView scroll = new HorizontalScrollView(getContext());
    scroll.setHorizontalScrollBarEnabled(false);
    scroll.setFillViewport(true);
    scroll.setBackgroundColor(Color.rgb(34, 34, 34));
    tabStrip = new LinearLayout(getContext());
    tabStrip.setOrientation(HORIZONTAL);
    tabStrip.setLayoutDirection(LAYOUT_DIRECTION_LTR);
    scroll.addView(tabStrip, new HorizontalScrollView.LayoutParams(-2, -1));
    addView(scroll, new LayoutParams(-1, dp(46)));
  }

  private void addFileHeader() {
    LinearLayout header = new LinearLayout(getContext());
    header.setOrientation(HORIZONTAL);
    header.setGravity(Gravity.CENTER_VERTICAL);
    header.setPadding(dp(12), dp(5), dp(12), dp(5));
    header.setBackgroundColor(Color.BLACK);
    header.setLayoutDirection(LAYOUT_DIRECTION_LTR);
    headerIcon = new ImageView(getContext());
    headerIcon.setImageResource(R.drawable.file_type_java);
    headerIcon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
    header.addView(headerIcon, new LinearLayout.LayoutParams(dp(48), dp(48)));
    LinearLayout labels = new LinearLayout(getContext());
    labels.setOrientation(VERTICAL);
    labels.setPadding(dp(8), 0, 0, 0);
    headerName = text("MainActivity.java", 17, Color.WHITE);
    headerName.setTypeface(null, Typeface.BOLD);
    headerName.setSingleLine(false);
    headerName.setMaxLines(2);
    headerName.setEllipsize(android.text.TextUtils.TruncateAt.END);
    headerPath = text("/storage/emulated/0/AppProjects", 12, Color.LTGRAY);
    headerPath.setSingleLine(true);
    headerPath.setEllipsize(android.text.TextUtils.TruncateAt.START);
    labels.addView(headerName, new LinearLayout.LayoutParams(-1, 0, 1));
    labels.addView(headerPath, new LinearLayout.LayoutParams(-1, 0, 1));
    header.addView(labels, new LinearLayout.LayoutParams(0, -1, 1));
    fileHeader = header;
    addView(header, new LayoutParams(-1, dp(61)));
    View line = new View(getContext());
    line.setBackgroundColor(Color.rgb(41, 182, 246));
    addView(line, new LayoutParams(-1, dp(2)));
  }

  private void addEditor() {
    LinearLayout row = new LinearLayout(getContext());
    row.setOrientation(HORIZONTAL);
    row.setLayoutDirection(LAYOUT_DIRECTION_LTR);
    row.setBackgroundColor(Color.BLACK);
    editorRow = row;
    lineNumbers = new EditorLineNumberView(getContext());
    lineNumbers.setTextColor(Color.rgb(52, 155, 210));
    lineNumbers.setPadding(dp(2), dp(5), dp(8), 0);
    row.addView(lineNumbers, new LinearLayout.LayoutParams(dp(48), -1));
    code = new AlmlkEditor(getContext());
    code.setLineSpacing(dp(3), 1);
    lineNumbers.attachTo(code);
    code.setScrollListener(
        new AlmlkEditor.ScrollListener() {
          @Override
          public void onEditorScroll(int x, int y) {
            lineNumbers.invalidate();
          }

          @Override
          public void onEditorZoom(float textSizePixels) {
            lineNumbers.setTextSizePixels(textSizePixels);
          }
        });
    code.setCustomSelectionActionModeCallback(
        new ActionMode.Callback() {
          private static final int CREATE_MISSING_MEMBER = 0x53484D41;
          private static final int EXPAND_SELECTION = 0x53484D42;
          private static final int GO_TO_DEFINITION = 0x53484D43;

          @Override
          public boolean onCreateActionMode(ActionMode mode, android.view.Menu menu) {
            code.normalizeSelectionToTouchedIdentifier();
            android.view.MenuItem item =
                menu.add(0, CREATE_MISSING_MEMBER, 0, "إنشاء الدالة في الكلاس");
            android.graphics.drawable.Drawable icon =
                getResources().getDrawable(android.R.drawable.ic_input_add).mutate();
            icon.setColorFilter(0xFF43A047, android.graphics.PorterDuff.Mode.SRC_IN);
            item.setIcon(icon);
            item.setShowAsAction(android.view.MenuItem.SHOW_AS_ACTION_NEVER);
            android.view.MenuItem expand = menu.add(0, EXPAND_SELECTION, 1, "توسيع التحديد");
            expand.setIcon(android.R.drawable.ic_menu_crop);
            expand.setShowAsAction(android.view.MenuItem.SHOW_AS_ACTION_ALWAYS);
            android.view.MenuItem definition =
                menu.add(0, GO_TO_DEFINITION, 2, "الانتقال إلى التعريف");
            definition.setIcon(android.R.drawable.ic_menu_directions);
            definition.setShowAsAction(android.view.MenuItem.SHOW_AS_ACTION_NEVER);
            return true;
          }

          @Override
          public boolean onPrepareActionMode(ActionMode mode, android.view.Menu menu) {
            return false;
          }

          private void analyzeQuickFixOnDemand(ActionMode mode) {
            final int selectionStart = code.getSelectionStart();
            final int selectionEnd = code.getSelectionEnd();
            final String source = code.getText().toString();
            mode.finish();
            final int request = ++quickFixGeneration;
            completionWorker.execute(
                () -> {
                  try {
                    final ProjectSymbolIndex.MissingMember result =
                        ProjectSymbolIndex.analyzeSelection(source, selectionStart, selectionEnd);
                    post(
                        () -> {
                          if (request != quickFixGeneration) return;
                          if (result != null && quickFixListener != null)
                            quickFixListener.createMissingMember(result);
                          else
                            Toast.makeText(
                                    getContext(),
                                    "لا توجد دالة مفقودة للعنصر المحدد",
                                    Toast.LENGTH_SHORT)
                                .show();
                        });
                  } catch (Throwable error) {
                    post(
                        () -> {
                          if (request == quickFixGeneration) showEditorError(error);
                        });
                  }
                });
          }

          private void resolveDefinitionOnDemand(ActionMode mode) {
            final int selectionStart = code.getSelectionStart();
            final int selectionEnd = code.getSelectionEnd();
            final String source = code.getText().toString();
            final String sourceFile = activeFile;
            mode.finish();
            final int request = ++definitionGeneration;
            completionWorker.execute(
                () -> {
                  try {
                    final ProjectSymbolIndex.DefinitionTarget target =
                        ProjectSymbolIndex.resolveDefinition(
                            sourceFile, source, selectionStart, selectionEnd);
                    post(
                        () -> {
                          if (request != definitionGeneration) return;
                          if (target != null && definitionListener != null)
                            definitionListener.requested(target);
                          else
                            Toast.makeText(
                                    getContext(),
                                    "تعذر العثور على تعريف العنصر المحدد",
                                    Toast.LENGTH_SHORT)
                                .show();
                        });
                  } catch (Throwable error) {
                    post(
                        () -> {
                          if (request == definitionGeneration) showEditorError(error);
                        });
                  }
                });
          }

          @Override
          public boolean onActionItemClicked(ActionMode mode, android.view.MenuItem item) {
            int id = item.getItemId();
            if (id == android.R.id.selectAll
                || id == android.R.id.cut
                || id == android.R.id.copy
                || id == android.R.id.paste) {
              boolean handled = code.onTextContextMenuItem(id);
              if (handled && id != android.R.id.selectAll) mode.finish();
              return handled;
            }
            if (id == EXPAND_SELECTION) {
              expandCodeSelection();
              return true;
            }
            if (id == CREATE_MISSING_MEMBER) {
              analyzeQuickFixOnDemand(mode);
              return true;
            }
            if (id == GO_TO_DEFINITION) {
              resolveDefinitionOnDemand(mode);
              return true;
            }
            return false;
          }

          @Override
          public void onDestroyActionMode(ActionMode mode) {
            quickFixGeneration++;
            definitionGeneration++;
          }
        });
    code.addTextChangedListener(
        new android.text.TextWatcher() {
          public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            if (!historyLocked && s.length() <= 60000) {
              String value = s.toString();
              if (undoHistory.isEmpty() || !undoHistory.peek().equals(value)) {
                undoHistory.push(value);
                while (undoHistory.size() > 30) undoHistory.removeLast();
              }
              redoHistory.clear();
            }
          }

          public void onTextChanged(CharSequence s, int start, int before, int count) {
            lineNumbers.invalidate();
            if (!historyLocked
                && isXmlFile()
                && count == 1
                && start > 0
                && start < s.length()
                && s.charAt(start - 1) == '<'
                && s.charAt(start) == '/') {
              final int marker = start + 1;
              post(() -> completeXmlClosingTag(marker));
            }
            removeCallbacks(completionTask);
            completionGeneration++;
            if (!historyLocked && count > 0 && start + count <= s.length()) {
              char last = s.charAt(start + count - 1);
              if (Character.isJavaIdentifierPart(last)
                  || last == '.'
                  || last == '<'
                  || last == ':'
                  || last == '@') postDelayed(completionTask, 90);
              else dismissCompletions();
            }
          }

          public void afterTextChanged(android.text.Editable e) {}
        });
    row.addView(code, new LinearLayout.LayoutParams(0, -1, 1));
    addView(row, new LayoutParams(-1, 0, 1));
  }

  private void expandCodeSelection() {
    String text = code.getText().toString();
    int start = Math.max(0, Math.min(code.getSelectionStart(), code.getSelectionEnd()));
    int end = Math.min(text.length(), Math.max(code.getSelectionStart(), code.getSelectionEnd()));
    int left = start, right = end;
    while (left > 0 && Character.isJavaIdentifierPart(text.charAt(left - 1))) left--;
    while (right < text.length() && Character.isJavaIdentifierPart(text.charAt(right))) right++;
    int dotBefore = left - 1;
    while (dotBefore >= 0 && Character.isWhitespace(text.charAt(dotBefore))) dotBefore--;
    if (dotBefore >= 0 && text.charAt(dotBefore) == '.') {
      left = dotBefore;
      while (left > 0 && Character.isJavaIdentifierPart(text.charAt(left - 1))) left--;
    }
    int cursor = right;
    while (cursor < text.length() && Character.isWhitespace(text.charAt(cursor))) cursor++;
    if (cursor < text.length() && text.charAt(cursor) == '.') {
      cursor++;
      while (cursor < text.length() && Character.isWhitespace(text.charAt(cursor))) cursor++;
      while (cursor < text.length() && Character.isJavaIdentifierPart(text.charAt(cursor)))
        cursor++;
    }
    while (cursor < text.length() && Character.isWhitespace(text.charAt(cursor))) cursor++;
    if (cursor < text.length() && text.charAt(cursor) == '(') {
      int depth = 0;
      char quote = 0;
      boolean escape = false;
      for (int i = cursor; i < text.length(); i++) {
        char value = text.charAt(i);
        if (quote != 0) {
          if (escape) escape = false;
          else if (value == '\\') escape = true;
          else if (value == quote) quote = 0;
        } else if (value == '"' || value == '\'') quote = value;
        else if (value == '(') depth++;
        else if (value == ')' && --depth == 0) {
          right = i + 1;
          break;
        }
      }
    } else right = Math.max(right, cursor);
    if (left == start && right == end) {
      left = text.lastIndexOf('\n', start - 1) + 1;
      int lineEnd = text.indexOf('\n', end);
      right = lineEnd < 0 ? text.length() : lineEnd;
    }
    if (left < right) code.setSelection(left, right);
  }

  private void addQuickKeys() {
    quickBar = new LinearLayout(getContext());
    quickBar.setOrientation(HORIZONTAL);
    quickBar.setGravity(Gravity.CENTER_VERTICAL);
    quickBar.setLayoutDirection(LAYOUT_DIRECTION_LTR);
    quickBar.setBackgroundColor(Color.rgb(31, 31, 31));
    HorizontalScrollView scroll = new HorizontalScrollView(getContext());
    scroll.setHorizontalScrollBarEnabled(false);
    scroll.setFillViewport(false);
    LinearLayout keys = new LinearLayout(getContext());
    keys.setOrientation(HORIZONTAL);
    keys.setLayoutDirection(LAYOUT_DIRECTION_LTR);
    String[] values = {
      "→", "{", "}", "(", ")", ";", "=", "\"", "|", "&", "[", "]", "<", ">", "/", "\\", "+", "-",
      "*", ":"
    };
    for (String value : values) {
      TextView key = text(value, 18, Color.WHITE);
      key.setGravity(Gravity.CENTER);
      key.setPadding(0, 0, 0, 0);
      key.setBackground(selectable());
      key.setOnClickListener(v -> smartInsert(((TextView) v).getText().toString()));
      keys.addView(key, new LinearLayout.LayoutParams(dp(38), dp(40)));
    }
    scroll.addView(keys, new HorizontalScrollView.LayoutParams(-2, -1));
    quickBar.addView(scroll, new LinearLayout.LayoutParams(0, dp(42), 1));
    TextView close = text("×", 28, Color.WHITE);
    close.setGravity(Gravity.CENTER);
    close.setBackgroundColor(Color.rgb(31, 31, 31));
    close.setOnClickListener(
        v -> {
          dismissedForCurrentKeyboard = true;
          quickBar.setVisibility(GONE);
        });
    quickBar.addView(close, new LinearLayout.LayoutParams(dp(46), dp(42)));
    addView(quickBar, new LayoutParams(-1, dp(42)));
    quickBar.setVisibility(GONE);
  }

  private void watchKeyboard() {
    getViewTreeObserver()
        .addOnGlobalLayoutListener(
            () -> {
              Rect area = new Rect();
              getWindowVisibleDisplayFrame(area);
              int current = area.height();
              if (current > largestVisibleHeight) largestVisibleHeight = current;
              int total = getRootView().getHeight();
              boolean visible =
                  (largestVisibleHeight - current) > Math.max(dp(170), largestVisibleHeight / 6)
                      || (total - area.bottom) > Math.max(dp(170), total / 6);
              if (visible != keyboardVisible) {
                keyboardVisible = visible;
                if (!visible) {
                  dismissedForCurrentKeyboard = false;
                  dismissCompletions();
                  quickBar.setVisibility(GONE);
                  fileHeader.setVisibility(VISIBLE);
                } else {
                  fileHeader.setVisibility(GONE);
                  if (!dismissedForCurrentKeyboard) quickBar.setVisibility(VISIBLE);
                }
              }
            });
  }

  private static final class SessionData {
    String selected;
    final LinkedHashMap<String, String> files = new LinkedHashMap<>();
  }

  public void restoreSessionAsync(SessionListener listener) {
    completionWorker.execute(() -> restoreSessionInBackground(listener));
  }

  private void restoreSessionInBackground(SessionListener listener) {
    java.io.File session = new java.io.File(getContext().getFilesDir(), "editor-session.bin");
    if (!session.isFile()) {
      if (listener != null) post(() -> listener.restored(false));
      return;
    }
    try (java.io.DataInputStream input =
        new java.io.DataInputStream(
            new java.io.BufferedInputStream(new java.io.FileInputStream(session)))) {
      int version = input.readInt();
      String selected = input.readUTF();
      int count = Math.min(12, Math.max(0, input.readInt()));
      if (version == 4 || version == 3) {
        LinkedHashMap<String, java.io.File> lazyFiles = new LinkedHashMap<>();
        LinkedHashMap<String, Integer> cursors = new LinkedHashMap<>();
        LinkedHashMap<String, Integer> scrollXs = new LinkedHashMap<>();
        LinkedHashMap<String, Integer> scrollYs = new LinkedHashMap<>();
        java.io.File directory = new java.io.File(getContext().getFilesDir(), "session-tabs");
        for (int i = 0; i < count; i++) {
          String name = input.readUTF();
          String storedName = input.readUTF();
          lazyFiles.put(name, new java.io.File(directory, storedName));
          if (version == 4) {
            cursors.put(name, Math.max(0, input.readInt()));
            scrollXs.put(name, Math.max(0, input.readInt()));
            scrollYs.put(name, Math.max(0, input.readInt()));
          }
        }
        post(() -> applyLazySession(selected, lazyFiles, cursors, scrollXs, scrollYs, listener));
        return;
      }
      if (version == 2 && count > 0) {
        String firstName = input.readUTF();
        String firstContent = readSessionContent(input);
        post(
            () -> {
              applyFirstSessionFile(firstName, firstContent);
              if (listener != null) listener.restored(true);
            });
        SessionData remaining = new SessionData();
        remaining.selected = selected;
        for (int i = 1; i < count; i++) {
          String name = input.readUTF();
          remaining.files.put(name, readSessionContent(input));
        }
        if (!remaining.files.isEmpty()) post(() -> appendSessionFiles(remaining));
        return;
      }
      if (version != 1) throw new java.io.IOException("Unsupported session version");
      SessionData legacy = new SessionData();
      legacy.selected = selected;
      for (int i = 0; i < count; i++) {
        String name = input.readUTF();
        legacy.files.put(name, readSessionContent(input));
      }
      post(
          () -> {
            boolean success = applyLegacySession(legacy);
            if (listener != null) listener.restored(success);
          });
    } catch (Exception error) {
      session.delete();
      post(
          () -> {
            if (listener != null) listener.restored(false);
          });
    }
  }

  private String readSessionContent(java.io.DataInputStream input) throws java.io.IOException {
    int length = input.readInt();
    if (length < 0 || length > 1200000) throw new java.io.IOException("Invalid session file");
    byte[] bytes = new byte[length];
    input.readFully(bytes);
    try {
      return new String(bytes, "UTF-8");
    } catch (java.io.UnsupportedEncodingException impossible) {
      throw new java.io.IOException(impossible);
    }
  }

  private void applyLazySession(
      String selected,
      LinkedHashMap<String, java.io.File> files,
      LinkedHashMap<String, Integer> cursors,
      LinkedHashMap<String, Integer> scrollXs,
      LinkedHashMap<String, Integer> scrollYs,
      SessionListener listener) {
    if (files.isEmpty()) {
      if (listener != null) listener.restored(false);
      return;
    }
    lazySessionFiles.clear();
    lazySessionFiles.putAll(files);
    sessionCursors.clear();
    sessionCursors.putAll(cursors);
    sessionScrollX.clear();
    sessionScrollX.putAll(scrollXs);
    sessionScrollY.clear();
    sessionScrollY.putAll(scrollYs);
    for (String name : files.keySet()) if (!tabs.containsKey(name)) addTab(name);
    String first = files.containsKey(selected) ? selected : files.keySet().iterator().next();
    setVisibility(VISIBLE);
    if (listener != null) listener.restored(true);
    postOnAnimation(() -> selectFile(first));
  }

  private void applyFirstSessionFile(String name, String content) {
    if (!tabs.containsKey(name)) addTab(name);
    fileContents.put(name, content);
    selectFile(name);
    setVisibility(VISIBLE);
  }

  private void appendSessionFiles(SessionData data) {
    for (Map.Entry<String, String> entry : data.files.entrySet()) {
      if (!tabs.containsKey(entry.getKey())) addTab(entry.getKey());
      fileContents.put(entry.getKey(), entry.getValue());
    }
  }

  private boolean applyLegacySession(SessionData data) {
    if (data == null || data.files.isEmpty()) return false;
    for (Map.Entry<String, String> entry : data.files.entrySet()) {
      if (!tabs.containsKey(entry.getKey())) addTab(entry.getKey());
      fileContents.put(entry.getKey(), entry.getValue());
    }
    selectFile(tabs.containsKey(data.selected) ? data.selected : tabs.keySet().iterator().next());
    setVisibility(VISIBLE);
    return true;
  }

  public void saveSession() {
    rememberActiveViewport();
    if (activeFile != null && code != null && !activeFile.equals(loadingFile))
      fileContents.put(activeFile, code.getText().toString());
    final String selected = activeFile == null ? "" : activeFile;
    final LinkedHashMap<String, String> snapshot = new LinkedHashMap<>();
    if (!selected.isEmpty() && tabs.containsKey(selected))
      snapshot.put(selected, fileContents.get(selected));
    for (String name : tabs.keySet()) {
      if (snapshot.size() >= 12) break;
      if (!snapshot.containsKey(name)) snapshot.put(name, fileContents.get(name));
    }
    final LinkedHashMap<String, Integer> cursors = new LinkedHashMap<>(sessionCursors);
    final LinkedHashMap<String, Integer> scrollXs = new LinkedHashMap<>(sessionScrollX);
    final LinkedHashMap<String, Integer> scrollYs = new LinkedHashMap<>(sessionScrollY);
    final LinkedHashMap<String, java.io.File> lazyFiles = new LinkedHashMap<>(lazySessionFiles);
    completionWorker.execute(
        () -> writeSession(selected, snapshot, cursors, scrollXs, scrollYs, lazyFiles));
  }

  private void writeSession(
      String selected,
      LinkedHashMap<String, String> snapshot,
      LinkedHashMap<String, Integer> cursors,
      LinkedHashMap<String, Integer> scrollXs,
      LinkedHashMap<String, Integer> scrollYs,
      LinkedHashMap<String, java.io.File> lazyFiles) {
    java.io.File target = new java.io.File(getContext().getFilesDir(), "editor-session.bin");
    java.io.File temporary = new java.io.File(getContext().getFilesDir(), "editor-session.tmp");
    java.io.File directory = new java.io.File(getContext().getFilesDir(), "session-tabs");
    if (snapshot.isEmpty()) {
      target.delete();
      temporary.delete();
      return;
    }
    directory.mkdirs();
    try (java.io.DataOutputStream output =
        new java.io.DataOutputStream(
            new java.io.BufferedOutputStream(new java.io.FileOutputStream(temporary)))) {
      output.writeInt(4);
      output.writeUTF(selected);
      output.writeInt(snapshot.size());
      for (Map.Entry<String, String> entry : snapshot.entrySet()) {
        String storedName = sessionFileName(entry.getKey());
        java.io.File storedFile = new java.io.File(directory, storedName);
        String content = entry.getValue();
        if (content != null) writeSessionTab(storedFile, content);
        else {
          java.io.File previous = lazyFiles.get(entry.getKey());
          if (!storedFile.isFile() && previous != null && previous.isFile())
            copyFile(previous, storedFile);
          if (!storedFile.isFile()) writeSessionTab(storedFile, "");
        }
        output.writeUTF(entry.getKey());
        output.writeUTF(storedName);
        output.writeInt(cursors.containsKey(entry.getKey()) ? cursors.get(entry.getKey()) : 0);
        output.writeInt(scrollXs.containsKey(entry.getKey()) ? scrollXs.get(entry.getKey()) : 0);
        output.writeInt(scrollYs.containsKey(entry.getKey()) ? scrollYs.get(entry.getKey()) : 0);
      }
    } catch (Exception error) {
      temporary.delete();
      return;
    }
    if (target.exists()) target.delete();
    temporary.renameTo(target);
  }

  private String sessionFileName(String name) {
    int forward = name.hashCode();
    int reverse = new StringBuilder(name).reverse().toString().hashCode();
    return Integer.toHexString(forward) + "-" + Integer.toHexString(reverse) + ".txt";
  }

  private void writeSessionTab(java.io.File target, String content) throws java.io.IOException {
    byte[] bytes = content.getBytes("UTF-8");
    if (bytes.length > 1200000) bytes = new byte[0];
    java.io.File temporary = new java.io.File(target.getParentFile(), target.getName() + ".tmp");
    try (java.io.FileOutputStream output = new java.io.FileOutputStream(temporary)) {
      output.write(bytes);
      output.flush();
    }
    if (target.exists()) target.delete();
    if (!temporary.renameTo(target)) throw new java.io.IOException("Session tab rename failed");
  }

  private void copyFile(java.io.File source, java.io.File target) throws java.io.IOException {
    try (java.io.FileInputStream input = new java.io.FileInputStream(source);
        java.io.FileOutputStream output = new java.io.FileOutputStream(target)) {
      byte[] buffer = new byte[8192];
      int read;
      while ((read = input.read(buffer)) >= 0) output.write(buffer, 0, read);
    }
  }

  public void openFile(String name) {
    openFile(name, null);
  }

  public void openFile(String name, String content) {
    if (!tabs.containsKey(name)) addTab(name);
    lazySessionFiles.remove(name);
    if (content != null) fileContents.put(name, content);
    else if (!fileContents.containsKey(name)) fileContents.put(name, sample(name));
    selectFile(name);
    setVisibility(VISIBLE);
  }

  private void addTab(String name) {
    LinearLayout holder = new LinearLayout(getContext());
    holder.setOrientation(VERTICAL);
    TextView label = text(name, 14, Color.LTGRAY);
    label.setGravity(Gravity.CENTER);
    label.setSingleLine(false);
    label.setMaxLines(2);
    label.setEllipsize(android.text.TextUtils.TruncateAt.END);
    label.setPadding(dp(10), 0, dp(10), 0);
    holder.addView(label, new LinearLayout.LayoutParams(dp(175), 0, 1));
    View line = new View(getContext());
    holder.addView(line, new LinearLayout.LayoutParams(-1, dp(3)));
    holder.setOnClickListener(v -> selectFile(name));
    tabs.put(name, holder);
    tabStrip.addView(holder, new LinearLayout.LayoutParams(dp(175), -1));
  }

  private void rememberActiveViewport() {
    if (activeFile == null || code == null) return;
    sessionCursors.put(activeFile, Math.max(0, code.getSelectionStart()));
    sessionScrollX.put(activeFile, Math.max(0, code.getScrollX()));
    sessionScrollY.put(activeFile, Math.max(0, code.getScrollY()));
  }

  private void restoreViewport(String name) {
    int cursor = sessionCursors.containsKey(name) ? sessionCursors.get(name) : 0;
    int x = sessionScrollX.containsKey(name) ? sessionScrollX.get(name) : 0;
    int y = sessionScrollY.containsKey(name) ? sessionScrollY.get(name) : 0;
    code.post(
        () -> {
          if (!name.equals(activeFile)) return;
          code.setSelection(Math.min(Math.max(0, cursor), code.length()));
          code.scrollTo(x, y);
        });
  }

  private void selectFile(String name) {
    dismissCompletions();
    rememberActiveViewport();
    if (activeFile != null && code != null && !activeFile.equals(loadingFile))
      fileContents.put(activeFile, code.getText().toString());
    activeFile = name;
    for (String key : tabs.keySet()) {
      LinearLayout h = tabs.get(key);
      TextView label = (TextView) h.getChildAt(0);
      boolean active = key.equals(name);
      label.setTextColor(active ? Color.WHITE : Color.LTGRAY);
      label.setTypeface(null, active ? Typeface.BOLD : Typeface.NORMAL);
      h.getChildAt(1).setBackgroundColor(active ? Color.rgb(41, 182, 246) : Color.TRANSPARENT);
    }
    headerName.setText(name);
    headerIcon.setImageResource(iconForFile(name));
    headerPath.setText("/storage/emulated/0/AppProjects/المشروع/" + name);
    historyLocked = true;
    java.io.File lazyFile = lazySessionFiles.get(name);
    boolean lazyRestore = !fileContents.containsKey(name) && lazyFile != null;
    code.setAnalysisPaused(lazyRestore);
    code.setFileName(name);
    if (lazyRestore) {
      loadingFile = name;
      code.setHint(R.string.session_restoring_file);
      code.setText("");
      loadLazySessionFile(name, lazyFile);
    } else {
      loadingFile = null;
      code.setHint(null);
      code.setText(fileContents.containsKey(name) ? fileContents.get(name) : sample(name));
      restoreViewport(name);
    }
    historyLocked = false;
    undoHistory.clear();
    redoHistory.clear();
    if (!lazyRestore) code.refreshNow();
  }

  private void loadLazySessionFile(String name, java.io.File source) {
    completionWorker.execute(
        () -> {
          String content = "";
          try {
            long size = source.length();
            if (size >= 0 && size <= 1200000) {
              byte[] bytes = new byte[(int) size];
              try (java.io.FileInputStream input = new java.io.FileInputStream(source)) {
                int offset = 0;
                while (offset < bytes.length) {
                  int read = input.read(bytes, offset, bytes.length - offset);
                  if (read < 0) break;
                  offset += read;
                }
                content = new String(bytes, 0, offset, "UTF-8");
              }
            }
          } catch (Exception ignored) {
          }
          final String restored = content;
          post(
              () -> {
                lazySessionFiles.remove(name);
                fileContents.put(name, restored);
                if (!name.equals(activeFile)) return;
                if (name.equals(loadingFile) && code.length() == 0) {
                  historyLocked = true;
                  code.setHint(null);
                  code.setText(restored);
                  historyLocked = false;
                  loadingFile = null;
                  restoreViewport(name);
                  code.setAnalysisPaused(false);
                  code.postDelayed(code::refreshNow, 500);
                } else if (name.equals(loadingFile)) {
                  fileContents.put(name, code.getText().toString());
                  loadingFile = null;
                  code.setHint(null);
                  code.setAnalysisPaused(false);
                  code.postDelayed(code::refreshNow, 500);
                }
              });
        });
  }

  private void smartInsert(String value) {
    android.text.Editable editable = code.getText();
    if (editable == null) return;
    int start = Math.max(0, Math.min(code.getSelectionStart(), code.getSelectionEnd()));
    int end = Math.max(start, Math.max(code.getSelectionStart(), code.getSelectionEnd()));
    if ("→".equals(value)) {
      code.setSelection(Math.min(editable.length(), end + 1));
      code.requestFocus();
      return;
    }
    String close = null;
    if ("{".equals(value)) close = "}";
    else if ("(".equals(value)) close = ")";
    else if ("[".equals(value)) close = "]";
    else if ("<".equals(value) && isXmlFile()) close = ">";
    else if ("\"".equals(value)) close = "\"";
    if (close != null) {
      if ("\"".equals(value) && start == end && isEscaped(editable, start)) {
        editable.insert(start, value);
        code.setSelection(start + 1);
      } else if ("\"".equals(value) && start == end && isInsideDoubleQuote(editable, start)) {
        if (start < editable.length() && editable.charAt(start) == '"')
          code.setSelection(start + 1);
        else {
          editable.insert(start, value);
          code.setSelection(start + 1);
        }
      } else {
        CharSequence selected = editable.subSequence(start, end);
        editable.replace(start, end, value + selected.toString() + close);
        code.setSelection(start + value.length(), start + value.length() + selected.length());
      }
    } else if (start == end
        && value.length() == 1
        && "})]>\"".indexOf(value.charAt(0)) >= 0
        && start < editable.length()
        && editable.charAt(start) == value.charAt(0)) {
      code.setSelection(start + 1);
    } else {
      editable.replace(start, end, value);
      code.setSelection(start + value.length());
    }
    code.requestFocus();
  }

  private boolean isXmlFile() {
    String name = activeFile == null ? "" : activeFile.toLowerCase(java.util.Locale.US);
    return name.endsWith(".xml");
  }

  private boolean isEscaped(CharSequence text, int offset) {
    int slashes = 0;
    for (int i = offset - 1; i >= 0 && text.charAt(i) == '\\'; i--) slashes++;
    return (slashes & 1) != 0;
  }

  private boolean isInsideDoubleQuote(CharSequence text, int offset) {
    boolean quoted = false, escaped = false;
    int lineStart = offset;
    while (lineStart > 0 && text.charAt(lineStart - 1) != '\n') lineStart--;
    for (int i = lineStart; i < offset; i++) {
      char value = text.charAt(i);
      if (escaped) escaped = false;
      else if (value == '\\') escaped = true;
      else if (value == '"') quoted = !quoted;
    }
    return quoted;
  }

  private void completeXmlClosingTag(int marker) {
    android.text.Editable editable = code.getText();
    if (editable == null || marker < 2 || marker > editable.length()) return;
    if (editable.charAt(marker - 2) != '<' || editable.charAt(marker - 1) != '/') return;
    String tag = findUnclosedXmlTag(editable, marker - 2);
    if (tag == null || tag.isEmpty()) return;
    historyLocked = true;
    if (marker < editable.length() && editable.charAt(marker) == '>') {
      editable.insert(marker, tag);
      code.setSelection(marker + tag.length() + 1);
    } else {
      editable.insert(marker, tag + ">");
      code.setSelection(marker + tag.length() + 1);
    }
    historyLocked = false;
  }

  private String findUnclosedXmlTag(CharSequence text, int limit) {
    ArrayDeque<String> stack = new ArrayDeque<>();
    int i = 0;
    while (i < limit) {
      int open = indexOf(text, '<', i, limit);
      if (open < 0 || open + 1 >= limit) break;
      if (startsWith(text, open, "<!--")) {
        int close = indexOf(text, "-->", open + 4, limit);
        i = close < 0 ? limit : close + 3;
        continue;
      }
      int close = xmlTagEnd(text, open + 1, limit);
      if (close < 0) {
        int nameStart = open + 1;
        while (nameStart < limit && Character.isWhitespace(text.charAt(nameStart))) nameStart++;
        int nameEnd = nameStart;
        while (nameEnd < limit && isXmlNameCharacter(text.charAt(nameEnd))) nameEnd++;
        if (nameEnd > nameStart) stack.push(text.subSequence(nameStart, nameEnd).toString());
        break;
      }
      char kind = text.charAt(open + 1);
      if (kind != '!' && kind != '?') {
        boolean closing = kind == '/';
        int nameStart = open + (closing ? 2 : 1);
        while (nameStart < close && Character.isWhitespace(text.charAt(nameStart))) nameStart++;
        int nameEnd = nameStart;
        while (nameEnd < close && isXmlNameCharacter(text.charAt(nameEnd))) nameEnd++;
        if (nameEnd > nameStart) {
          String name = text.subSequence(nameStart, nameEnd).toString();
          if (closing) {
            while (!stack.isEmpty()) {
              String current = stack.pop();
              if (current.equals(name)) break;
            }
          } else {
            int tail = close - 1;
            while (tail > nameEnd && Character.isWhitespace(text.charAt(tail))) tail--;
            if (text.charAt(tail) != '/') stack.push(name);
          }
        }
      }
      i = close + 1;
    }
    return stack.isEmpty() ? null : stack.peek();
  }

  private int xmlTagEnd(CharSequence text, int from, int limit) {
    char quote = 0;
    for (int i = from; i < limit; i++) {
      char value = text.charAt(i);
      if (quote != 0) {
        if (value == quote) quote = 0;
      } else if (value == '"' || value == '\'') quote = value;
      else if (value == '>') return i;
    }
    return -1;
  }

  private boolean isXmlNameCharacter(char value) {
    return Character.isLetterOrDigit(value)
        || value == '_'
        || value == '-'
        || value == ':'
        || value == '.';
  }

  private int indexOf(CharSequence text, char needle, int from, int limit) {
    for (int i = Math.max(0, from); i < Math.min(limit, text.length()); i++)
      if (text.charAt(i) == needle) return i;
    return -1;
  }

  private int indexOf(CharSequence text, String needle, int from, int limit) {
    int last = Math.min(limit, text.length()) - needle.length();
    for (int i = Math.max(0, from); i <= last; i++) {
      if (startsWith(text, i, needle)) return i;
    }
    return -1;
  }

  private boolean startsWith(CharSequence text, int offset, String value) {
    if (offset < 0 || offset + value.length() > text.length()) return false;
    for (int i = 0; i < value.length(); i++)
      if (text.charAt(offset + i) != value.charAt(i)) return false;
    return true;
  }

  public void applyTheme() {
    ThemeConfig theme = new ThemeConfig(getContext());
    int background = theme.color(ThemeConfig.BACKGROUND);
    int plain = theme.color(ThemeConfig.PLAIN);
    int chrome = theme.isDark() ? Color.rgb(34, 34, 34) : Color.rgb(238, 238, 238);
    setBackgroundColor(background);
    if (editorRow != null) editorRow.setBackgroundColor(background);
    if (fileHeader != null) fileHeader.setBackgroundColor(background);
    if (tabStrip != null) {
      tabStrip.setBackgroundColor(chrome);
      if (tabStrip.getParent() instanceof View)
        ((View) tabStrip.getParent()).setBackgroundColor(chrome);
    }
    if (quickBar != null) quickBar.setBackgroundColor(chrome);
    if (headerName != null) headerName.setTextColor(plain);
    if (headerPath != null) headerPath.setTextColor(theme.isDark() ? Color.LTGRAY : Color.DKGRAY);
    if (lineNumbers != null) lineNumbers.setTextColor(theme.color(ThemeConfig.LINE_NUMBER));
    if (code != null) code.applyTheme();
    for (LinearLayout holder : tabs.values()) {
      TextView label = (TextView) holder.getChildAt(0);
      label.setTextColor(
          holder == tabs.get(activeFile) ? plain : (theme.isDark() ? Color.LTGRAY : Color.DKGRAY));
    }
  }

  public boolean hasOpenFile() {
    return activeFile != null;
  }

  public String getActiveFile() {
    return activeFile;
  }

  public String getTextContent() {
    return code == null ? "" : code.getText().toString();
  }

  public void undoEdit() {
    if (undoHistory.isEmpty()) return;
    historyLocked = true;
    redoHistory.push(code.getText().toString());
    code.setText(undoHistory.pop());
    code.setSelection(code.length());
    historyLocked = false;
  }

  public void redoEdit() {
    if (redoHistory.isEmpty()) return;
    historyLocked = true;
    undoHistory.push(code.getText().toString());
    code.setText(redoHistory.pop());
    code.setSelection(code.length());
    historyLocked = false;
  }

  public boolean findText(String query) {
    if (query == null || query.isEmpty()) return false;
    String text = code.getText().toString();
    int from = Math.max(0, code.getSelectionEnd());
    int at = text.indexOf(query, from);
    if (at < 0) at = text.indexOf(query);
    if (at < 0) return false;
    code.requestFocus();
    code.setSelection(at, at + query.length());
    return true;
  }

  public int replaceAll(String from, String to) {
    if (from == null || from.isEmpty()) return 0;
    String before = code.getText().toString();
    int count = 0, at = 0;
    while ((at = before.indexOf(from, at)) >= 0) {
      count++;
      at += from.length();
    }
    if (count > 0) {
      int cursor = Math.max(0, code.getSelectionStart());
      code.setText(before.replace(from, to == null ? "" : to));
      code.setSelection(Math.min(cursor, code.length()));
    }
    return count;
  }

  public boolean goToOffset(int offset) {
    if (code == null) return false;
    int target = Math.max(0, Math.min(offset, code.length()));
    code.requestFocus();
    code.setSelection(target);
    code.post(() -> code.bringPointIntoView(target));
    return true;
  }

  public boolean goToLine(int line) {
    if (line < 1) return false;
    String text = code.getText().toString();
    int at = 0;
    for (int n = 1; n < line; n++) {
      at = text.indexOf('\n', at);
      if (at < 0) return false;
      at++;
    }
    code.requestFocus();
    code.setSelection(Math.min(at, code.length()));
    return true;
  }

  public void formatSource() {
    String original = code.getText().toString();
    String formatted = code.formatCode();
    if (original.equals(formatted)) return;
    int semanticCursor = semanticPosition(original, Math.max(0, code.getSelectionStart()));
    if (undoHistory.isEmpty() || !undoHistory.peek().equals(original)) {
      undoHistory.push(original);
      while (undoHistory.size() > 30) undoHistory.removeLast();
    }
    redoHistory.clear();
    historyLocked = true;
    code.setText(formatted);
    code.setSelection(offsetForSemanticPosition(formatted, semanticCursor));
    historyLocked = false;
    code.refreshNow();
  }

  private int semanticPosition(String text, int offset) {
    int count = 0;
    for (int i = 0; i < Math.min(offset, text.length()); i++)
      if (!Character.isWhitespace(text.charAt(i))) count++;
    return count;
  }

  private int offsetForSemanticPosition(String text, int semanticPosition) {
    int count = 0;
    for (int i = 0; i < text.length(); i++) {
      if (!Character.isWhitespace(text.charAt(i)) && count++ >= semanticPosition) return i;
    }
    return text.length();
  }

  public void setQuickFixListener(QuickFixListener listener) {
    quickFixListener = listener;
  }

  public void setDefinitionListener(DefinitionListener listener) {
    definitionListener = listener;
  }

  public void refreshSemanticDiagnostics() {
    if (code != null && activeFile != null) code.refreshNow();
  }

  public java.util.List<com.almlkid.kay.ui.CodeLanguageTools.Diagnostic> diagnostics() {
    code.refreshNow();
    return code.getDiagnostics();
  }

  private void showLiveCompletions() {
    if (code == null || !code.hasFocus() || code.getSelectionStart() != code.getSelectionEnd())
      return;
    final String source = code.getText().toString();
    final int cursor = code.getSelectionStart();
    final int request = ++completionGeneration;
    completionWorker.execute(
        () -> {
          try {
            final java.util.List<ProjectSymbolIndex.CompletionItem> items =
                ProjectSymbolIndex.complete(activeFile, source, cursor);
            post(
                () -> {
                  if (request != completionGeneration || code.getSelectionStart() != cursor) return;
                  displayLiveCompletions(items);
                });
          } catch (Throwable error) {
            post(() -> showEditorError(error));
          }
        });
  }

  private void displayLiveCompletions(
      final java.util.List<ProjectSymbolIndex.CompletionItem> items) {
    if (items.isEmpty()) {
      dismissCompletions();
      return;
    }
    ListView suggestions =
        (ListView)
            LayoutInflater.from(getContext()).inflate(R.layout.code_completion_popup, null, false);
    suggestions.setAdapter(
        new BaseAdapter() {
          public int getCount() {
            return items.size();
          }

          public Object getItem(int position) {
            return items.get(position);
          }

          public long getItemId(int position) {
            return position;
          }

          public View getView(int position, View reusable, ViewGroup parent) {
            View row =
                reusable != null
                    ? reusable
                    : LayoutInflater.from(getContext())
                        .inflate(R.layout.code_completion_entry, parent, false);
            ProjectSymbolIndex.CompletionItem item = items.get(position);
            ImageView icon = row.findViewById(R.id.codeCompletionIcon);
            TextView name = row.findViewById(R.id.codeCompletionName);
            TextView detail = row.findViewById(R.id.codeCompletionDetail);
            icon.setImageResource(
                item.kind == ProjectSymbolIndex.CompletionItem.METHOD
                    ? R.drawable.completion_method
                    : item.kind == ProjectSymbolIndex.CompletionItem.VARIABLE
                        ? R.drawable.completion_variable
                        : item.kind == ProjectSymbolIndex.CompletionItem.XML
                            ? R.drawable.completion_xml
                            : item.kind == ProjectSymbolIndex.CompletionItem.BUILD
                                ? R.drawable.completion_build
                                : R.drawable.completion_class);
            name.setText(item.label);
            name.setTextColor(
                item.kind == ProjectSymbolIndex.CompletionItem.CLASS
                    ? Color.rgb(35, 187, 255)
                    : item.kind == ProjectSymbolIndex.CompletionItem.VARIABLE
                        ? Color.rgb(0, 174, 226)
                        : Color.WHITE);
            detail.setText(" : " + item.detail);
            return row;
          }
        });
    suggestions.setOnItemClickListener(
        (parent, view, position, id) -> {
          applyCompletion(items.get(position).insertText);
          dismissCompletions();
        });
    dismissCompletions();
    int width = Math.min(dp(310), getResources().getDisplayMetrics().widthPixels - dp(24));
    int height = Math.min(dp(190), dp(8 + Math.min(4, items.size()) * 44));
    completionWindow = new PopupWindow(suggestions, width, height, false);
    completionWindow.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0xFF292929));
    completionWindow.setOutsideTouchable(true);
    completionWindow.setTouchable(true);
    completionWindow.setElevation(dp(10));
    int[] location = new int[2];
    code.getLocationOnScreen(location);
    android.text.Layout layout = code.getLayout();
    int cursor = Math.max(0, code.getSelectionStart());
    int x = location[0] + dp(8);
    int y = location[1] + dp(38);
    if (layout != null && cursor <= code.length()) {
      int line = layout.getLineForOffset(cursor);
      x = location[0] + (int) layout.getPrimaryHorizontal(cursor) - code.getScrollX();
      y = location[1] + layout.getLineBottom(line) - code.getScrollY();
    }
    x =
        Math.max(
            dp(8), Math.min(x, getResources().getDisplayMetrics().widthPixels - width - dp(8)));
    Rect visibleFrame = new Rect();
    getWindowVisibleDisplayFrame(visibleFrame);
    int bottomLimit = visibleFrame.bottom - dp(6);
    if (quickBar != null && quickBar.getVisibility() == VISIBLE) {
      int[] quickLocation = new int[2];
      quickBar.getLocationOnScreen(quickLocation);
      bottomLimit = Math.min(bottomLimit, quickLocation[1] - dp(4));
    }
    y = Math.max(dp(70), Math.min(y, bottomLimit - height));
    completionWindow.showAtLocation(this, Gravity.NO_GRAVITY, x, y);
  }

  private void showEditorError(Throwable error) {
    long now = android.os.SystemClock.uptimeMillis();
    if (now - lastEditorErrorTime < 3000 || !isAttachedToWindow()) return;
    lastEditorErrorTime = now;
    dismissCompletions();
    new android.app.AlertDialog.Builder(getContext())
        .setTitle("خطأ في المحرر")
        .setMessage(
            "تعذر إكمال العملية دون إغلاق التطبيق:\n\n"
                + error.getClass().getSimpleName()
                + (error.getMessage() == null ? "" : "\n" + error.getMessage()))
        .setPositiveButton("حسنًا", null)
        .show();
  }

  private void dismissCompletions() {
    completionGeneration++;
    if (completionWindow != null) {
      completionWindow.dismiss();
      completionWindow = null;
    }
  }

  public java.util.List<String> completions() {
    java.util.List<ProjectSymbolIndex.CompletionItem> detailed =
        ProjectSymbolIndex.complete(
            activeFile, code.getText().toString(), code.getSelectionStart());
    java.util.ArrayList<String> values = new java.util.ArrayList<>();
    for (ProjectSymbolIndex.CompletionItem item : detailed) values.add(item.insertText);
    if (values.isEmpty()) values.addAll(code.completions());
    return values;
  }

  public void applyCompletion(String value) {
    code.applyCompletion(value);
  }

  public void closeCurrent() {
    if (activeFile == null) return;
    LinearLayout tab = tabs.remove(activeFile);
    if (tab != null) tabStrip.removeView(tab);
    fileContents.remove(activeFile);
    lazySessionFiles.remove(activeFile);
    sessionCursors.remove(activeFile);
    sessionScrollX.remove(activeFile);
    sessionScrollY.remove(activeFile);
    activeFile = null;
    if (tabs.isEmpty()) {
      setVisibility(GONE);
      code.setText("");
    } else selectFile(tabs.keySet().iterator().next());
  }

  public void closeAll() {
    tabs.clear();
    fileContents.clear();
    lazySessionFiles.clear();
    sessionCursors.clear();
    sessionScrollX.clear();
    sessionScrollY.clear();
    loadingFile = null;
    tabStrip.removeAllViews();
    activeFile = null;
    code.setText("");
    setVisibility(GONE);
  }

  private int iconForFile(String name) {
    String n = name == null ? "" : name.toLowerCase(java.util.Locale.US);
    if (n.endsWith(".java") || n.endsWith(".kt")) return R.drawable.file_type_java;
    if (n.endsWith(".xml")) return R.drawable.file_type_xml;
    if (n.endsWith(".gradle") || n.endsWith(".gradle.kts")) {
      return R.drawable.project_properties;
    }
    if (n.endsWith(".zip") || n.endsWith(".jar") || n.endsWith(".aar") || n.endsWith(".apk")) {
      return R.drawable.file_type_zip;
    }
    if (n.endsWith(".txt") || n.endsWith(".md") || n.endsWith(".properties") || n.endsWith(".json"))
      return R.drawable.file_type_txt;
    return R.drawable.file_type_unknown;
  }

  private android.graphics.drawable.Drawable selectable() {
    android.util.TypedValue out = new android.util.TypedValue();
    getContext().getTheme().resolveAttribute(android.R.attr.selectableItemBackground, out, true);
    return getResources().getDrawable(out.resourceId);
  }

  private TextView text(String value, int size, int color) {
    TextView t = new TextView(getContext());
    t.setText(value);
    t.setTextSize(size);
    t.setTextColor(color);
    return t;
  }

  @Override
  protected void onAttachedToWindow() {
    super.onAttachedToWindow();
    if (completionWorker.isShutdown())
      completionWorker = java.util.concurrent.Executors.newSingleThreadExecutor();
  }

  @Override
  protected void onDetachedFromWindow() {
    removeCallbacks(completionTask);
    dismissCompletions();
    completionWorker.shutdownNow();
    super.onDetachedFromWindow();
  }

  private int dp(int n) {
    return (int) (n * getResources().getDisplayMetrics().density + .5f);
  }

  private String sample(String name) {
    if (name.endsWith(".xml"))
      return "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n"
          + "<LinearLayout xmlns:android=\"http://schemas.android.com/apk/res/android\"\n"
          + "    android:layout_width=\"match_parent\"\n"
          + "    android:layout_height=\"match_parent\" />";
    return "package com.example.myapp;\n\n"
        + "import android.app.Activity;\n"
        + "import android.os.Bundle;\n\n"
        + "public class "
        + name.replace(".java", "")
        + " extends Activity {\n"
        + "    @Override\n"
        + "    protected void onCreate(Bundle state) {\n"
        + "        super.onCreate(state);\n"
        + "    }\n"
        + "}";
  }
}
