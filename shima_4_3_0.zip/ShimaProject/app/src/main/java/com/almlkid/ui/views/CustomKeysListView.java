package com.almlkid.ui.views;

import android.content.Context;
import android.util.AttributeSet;

public class CustomKeysListView extends android.widget.ListView {
  public CustomKeysListView(Context c) {
    super(c);
  }

  public CustomKeysListView(Context c, AttributeSet a) {
    super(c, a);
  }

  public CustomKeysListView(Context c, AttributeSet a, int s) {
    super(c, a, s);
  }
}
