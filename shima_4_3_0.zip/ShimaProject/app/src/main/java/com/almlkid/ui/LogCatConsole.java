package com.almlkid.ui;

import android.content.Context;
import android.util.AttributeSet;

public class LogCatConsole extends android.widget.TextView {
  public LogCatConsole(Context c) {
    super(c);
  }

  public LogCatConsole(Context c, AttributeSet a) {
    super(c, a);
  }

  public LogCatConsole(Context c, AttributeSet a, int s) {
    super(c, a, s);
  }
}
