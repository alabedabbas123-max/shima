package com.almlkid.ui.views;

import android.content.Context;
import android.util.AttributeSet;

public class SplitView extends android.widget.LinearLayout {
  public SplitView(Context c) {
    super(c);
  }

  public SplitView(Context c, AttributeSet a) {
    super(c, a);
  }

  public SplitView(Context c, AttributeSet a, int s) {
    super(c, a, s);
  }
}
