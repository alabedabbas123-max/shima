package com.almlkid.ui.scm;

import android.content.Context;
import android.util.AttributeSet;

public class ModifiedFileListEntry extends android.widget.LinearLayout {
  public ModifiedFileListEntry(Context c) {
    super(c);
  }

  public ModifiedFileListEntry(Context c, AttributeSet a) {
    super(c, a);
  }

  public ModifiedFileListEntry(Context c, AttributeSet a, int s) {
    super(c, a, s);
  }
}
