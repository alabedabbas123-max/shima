package com.almlkid.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.text.Layout;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.View;
import com.almlkid.kay.ui.AlmlkEditor;

/** Draws only visible line numbers; it never creates a giant line-number string. */
public final class EditorLineNumberView extends View {
  private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
  private AlmlkEditor editor;

  public EditorLineNumberView(Context context) {
    super(context);
    init();
  }

  public EditorLineNumberView(Context context, AttributeSet attrs) {
    super(context, attrs);
    init();
  }

  private void init() {
    paint.setTypeface(Typeface.MONOSPACE);
    paint.setTextAlign(Paint.Align.RIGHT);
    paint.setTextSize(
        TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_SP, 11, getResources().getDisplayMetrics()));
    setWillNotDraw(false);
  }

  public void attachTo(AlmlkEditor value) {
    editor = value;
    invalidate();
  }

  public void setTextColor(int color) {
    paint.setColor(color);
    invalidate();
  }

  public void setTextSizePixels(float size) {
    paint.setTextSize(size);
    invalidate();
  }

  @Override
  protected void onDraw(Canvas canvas) {
    super.onDraw(canvas);
    if (editor == null) return;
    Layout layout = editor.getLayout();
    if (layout == null || layout.getLineCount() == 0) return;
    int scrollY = editor.getScrollY();
    int first = Math.max(0, layout.getLineForVertical(scrollY) - 1);
    int last =
        Math.min(
            layout.getLineCount() - 1, layout.getLineForVertical(scrollY + editor.getHeight()) + 1);
    float right = getWidth() - getPaddingRight();
    int topPadding = editor.getTotalPaddingTop();
    for (int line = first; line <= last; line++) {
      float baseline = topPadding + layout.getLineBaseline(line) - scrollY;
      canvas.drawText(Integer.toString(line + 1), right, baseline, paint);
    }
  }
}
