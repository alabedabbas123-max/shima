package net.margaritov.preference.colorpicker;

import android.content.Context;
import android.util.AttributeSet;

public class ColorPickerPanelView extends android.view.View {
  public ColorPickerPanelView(Context c) {
    super(c);
  }

  public ColorPickerPanelView(Context c, AttributeSet a) {
    super(c, a);
  }

  public ColorPickerPanelView(Context c, AttributeSet a, int s) {
    super(c, a, s);
  }
}
