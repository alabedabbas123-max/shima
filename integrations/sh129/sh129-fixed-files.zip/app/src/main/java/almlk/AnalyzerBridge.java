package almlk;

import android.content.Context;
import com.shima.analyzer.AnalysisHandle;
import com.shima.analyzer.CodeAnalyzer;
import com.shima.analyzer.core.AnalysisConfig;
import com.shima.analyzer.core.AnalysisResult;
import com.shima.analyzer.core.Language;
import com.shima.analyzer.editor.EditorAdapter;
import java.util.ArrayList;
import java.util.List;

/**
 * جِسْرُ المُستَهلِكِ لِوَحدَةِ الفَحصِ وَالرَّسمِ — ‏1.0.198 (ج٤٧).
 *
 * <p>سَببُ وُجُودِهِ: وَجهُ المَكتَبَةِ يَطلُبُ (١) نَصًّا آخِرًا عِندَ الطَّلَبِ، (٢) إِخطَارًا
 * بِالتَّغَيُّرِ، (٣) خَيطَ الوَاجِهَةِ لِـ{@code start}/{@code requestAnalysis}/{@code close} —
 * وَكُلُّ ذلِكَ عِندَنَا فِي {@code AIDEEditorPager}، لَا فِي {@code EditText} صَافٍ. فَهذَا
 * الصِّنفُ يَحَمِلُ وَجهَ المَكتَبَةِ (‏{@link EditorAdapter}‏) وَيَبقَى المُحرِّرُ بِلَا عِلْمٍ بِهِ:
 * لَا سَطْرَ فِي وَجهَةِ المُحرِّرِ يَسأَلُ المَكتَبَةَ شَيئًا، وَلَا قُفلَ يَنتَظِرُهَا، وَلَا كَتَابَةَ
 * عَلَى النَّصِّ مِن قَبلِهَا — الكِتَابَةُ كُلُّهَا تَجرِي مِن صُفوفِ {@link almlk.QuickFix}
 * عَلى مَسَارِ الإِصلاحِ الوَاحدِ عِندَنَا.
 *
 * <p><b>عَهدُ الخَيطِ</b>: صِفْرُ عَمَلٍ عَلى خَيطِ العَمَلِ. المَكتَبَةُ تَنشُرُ عَلَى خَيطِهَا
 * (نَحْوٌ وَفَحصٌ فِي «‏shima-analyzer‏» ذِي الأَولَوِيَّةِ الخَافِضَةِ)، وَتُرسِلُ النَّتِيجَةَ
 * إِلَى الوَاجِهَةِ؛ وَالحَدُّ هُنَا: حَجمُ مُسَوَّدَةٍ وَاحدَةٍ (‏{@code maxDocumentChars}‏) وَزَمَنٌ
 * قَطَعٌ (‏{@code timeoutMillis}‏) — فَإن جَاوَزَهُمَا فَيلٌ يَر جَعُ {@code PARTIAL}، وَتَقُولُ
 * الوَحدَةُ ذلِكَ عَلَى صَفٍّ، وَلَا تَدَّعِي سَلَامَةً.
 *
 * <p><b>سَقَطَ الجِذرُ؟</b>: يَنبَغِي أن يُعلَنَ. أَوَّلُ لَمسَةٍ لِـ{@code NativeBridge} تَرمِي
 * {@link LinkageError} إِنَّ لَم يُوجَدِ ‏{@code libshima_analyzer.so} لِلمِعمَارِيَّةِ؛ نَكتَشِفُ
 * ذلِكَ مَرَّةً وَاحدَةً (بِلَا إِعادَةٍ عِندَ كُلِّ حَرفٍ) وَنَنشُرُ سَبَبَهُ صَفًّا، ثُمَّ نَسكُتُ
 * عَنِ المَكتَبَةِ دُونَ أن نُسكِتَ عَنِ السَّبَبِ.
 */
public final class AnalyzerBridge {

  /** صَاحِبُ النَّصِّ الحَيِّ: وَجهَةُ المُحرِّرِ، فَلا نَسخَ عَلَى القُرصِ عِندَنَا. */
  public interface TextSource {
    /** نَصُّ التبويبِ، أَو {@code null} إِنَّ لَم يُوجَد — تُترَكُ الصُّفوفُ كَمَا هِيَ. */
    String textOf(String reference);
  }

  /** طَلَبُ إِعادَةِ النَّشرِ (عِندَ المُضيفِ: {@code publishProjectDiagnostics(false)}). */
  public interface Publisher {
    void publish();
  }

  /**
   * مَا يَعرِفُهُ المُضيفُ عَنِ المِشرُوعِ: مُجلَّدُ الوَحدَةِ (‏app/‏) وَوَصفُ حِزمَتِهَا. الجَولَةُ
   * الجَمعِيَّةُ لَا تَطلُبُ أَكثَرَ مِن ذلِكَ — لَا Gradle، لَا فَتحًا لِمانيفست، لَا قَيدَ بِنَاءٍ:
   * كُلَّمَا قَلَّ مَا يَعرِفُهُ المُساعِدُ قَلَّ مَا يَستَطِيعُ أن يُخطِئَ فِيهِ.
   */
  public interface ProjectHost {
    /** مُجلَّدُ الوَحدَةِ، أو {@code null} إِنَّ لَم يُفتَتَحْ مِشرُوعٌ (فَيَكتَفِي الجِسْرُ بِالتَّبويِبِ). */
    java.io.File moduleDir();

    /** ‏namespace‏/‏applicationId‏؛ قَد يَكونُ فَارِغًا أَو غَيرَ صَالِحٍ — نُتجَاهَلُهُ وَلَا نَرمِيهِ. */
    String namespace();
  }

  private final Context appContext;
  private final TextSource source;
  private final Publisher publisher;
  private final List<Runnable> changeListeners = new ArrayList<>();

  /** أَقلُّ فَاصِلَةٍ بَينَ جَولَتَينِ جَمعِيَّتَينِ: المِحرِّرُ يُكتَبُ، وَالعَقلُ الجَمعِيُّ يَرتَاحُ. */
  public static final long PROJECT_PASS_INTERVAL_MS = 4000L;
  /**
   * مِرجَعُ صَفِّ «الفَحصُ الجَمعِيُّ نَاقِصٌ»: لَيسَ مِلَفًّا فَلا يُنسَبُ إِلَى سَطْرٍ وَلَا يُلوَّنُ،
   * وَلكِنَّهُ يَظهَرُ فِي اللَّوحَةِ — فَالتَّسمِيَةُ تُغني عَنِ الكِتمَانِ.
   */
  public static final String PROJECT_NOTE_REFERENCE = "shima:workspace";

  private ProjectHost projectHost;
  private java.util.concurrent.ExecutorService projectWorker;
  private final android.os.Handler projectMain =
      new android.os.Handler(android.os.Looper.getMainLooper());
  private final Runnable projectKick =
      new Runnable() {
        @Override public void run() {
          startProjectPass();
        }
      };
  private final List<String> projectWritten = new ArrayList<>();
  private volatile boolean projectRunning;
  private volatile boolean projectQueued;
  private volatile long projectLastStart;

  private AnalysisHandle handle;
  private String reference;
  private String fileName;
  private boolean probed;
  private boolean nativeReady;
  private String nativeReason = "";

  /**
   * الحِرسُ ضِدَّ الدَّورَةِ: نَشرُنَا يُؤَدِّي بِالحَامِلِ إِلَى رَسمِ الصَّفحَةِ، وَالرَّسمُ
   * يُطلِعُنَا عَلَى الوَجهَةِ (‏{@code onFocus}‏) — فَإِنۡ لَبَّينَا ذٰلِكَ الإِشرَاقَ عُدۡنَا
   * نَنشُرُ، فَدَورَةٌ لَا نِهَايَةَ لَهَا سَقَطَتۡ عَلَيهَا الوَاجِهَةُ
   * بِ‏{@link StackOverflowError} قَبلَ أن تَظهَرَ تَاجاتُ المَشارِيعِ (ج٥٤، عَلى الجِهَازِ).
   * الحَارِسُ خَيطٌ لَا عَلَامَةٌ: نَتَائِجُ المَكتَبَةِ تَأتِي مِن خَيطِهَا، فَحَظرُ عَلَامَةٍ
   * عَامَّةٍ كَانَ يَسُدُّ طَرِيقَ النَّتَائِجِ بَعۡدَ كُلِّ نَشرٍ.
   */
  private Thread publishOwner;
  /** طَلَبَاتٌ جَاءَتۡ أَثۡنَاءَ الرَّسمِ: نَظرَةٌ وَاحدَةٌ بَعۡدَ أن تَسۡتَقِرَّ الصَّفحَةُ. */
  private boolean publishAgain;

  public AnalyzerBridge(Context context, TextSource textSource, Publisher publish) {
    this.appContext = context == null ? null : context.getApplicationContext();
    this.source = textSource;
    this.publisher = publish;
  }

  /** هَلِ الجِذرُ هُنَا؟ مَرَّةً وَاحدَةً، وَبِالحُكمِ عَلَى نَفسِهِ لَا عَلى ظَنِّنَا. */
  private boolean nativeAvailable() {
    if (probed) return nativeReady;
    probed = true;
    try {
      Class.forName("com.shima.analyzer.core.NativeBridge", true, NativeBridgeLoader.loader());
      nativeReady = true;
    } catch (Throwable failure) {
      nativeReady = false;
      nativeReason = failure.getClass().getSimpleName()
          + (failure.getMessage() == null ? "" : ": " + failure.getMessage());
    }
    return nativeReady;
  }

  /** التَّبويِبُ الجَارِي هُوَ المَفحوصُ وَحدَهُ؛ إِنَّ تَغَيَّرَتِ الوَجهَةُ أُغلِقَ الكُلُّ وَأُعيِدَ. */
  public void focus(String tabFileName, String tabReference) {
    if (echoing()) return; // صَدَىٰ رَسمٍ: لَا فَتحَ لِوَحدَةٍ وَلَا إِغلَاقًا مِن دَاخِلِهِ
    String next = tabReference == null ? "" : tabReference;
    if (!isSupported(next)) {
      release();
      return;
    }
    if (handle != null && next.equals(reference)) {
      requestAnalysis();
      return;
    }
    release();
    // Keep ownership of the unavailable row too, so release/switch clears it.
    fileName = tabFileName;
    reference = next;
    if (!nativeAvailable()) {
      AnalyzerErrorUnit.putUnavailable(next, tabFileName, text(), new IllegalStateException(nativeReason));
      notifyPublisher();
      return;
    }
    try {
      handle = CodeAnalyzer.with(appContext)
          .attachTo(new BridgeAdapter())
          .sourceId(next)
          .language(languageOf(next))
          .config(editorConfig(text()))
          .debounceMillis(250)
          .onResult(new CodeAnalyzer.ResultListener() {
            @Override public void onResult(AnalysisResult result) {
              AnalyzerErrorUnit.put(reference, fileName, text(), result);
              notifyPublisher();
            }
          })
          .onError(new CodeAnalyzer.ErrorListener() {
            @Override public void onError(Throwable error) {
              AnalyzerErrorUnit.putUnavailable(reference, fileName, text(), error);
              notifyPublisher();
            }
          })
          .start();
    } catch (RuntimeException | LinkageError failure) {
      handle = null;
      nativeReady = false;
      nativeReason = failure.getClass().getSimpleName()
          + (failure.getMessage() == null ? "" : ": " + failure.getMessage());
      AnalyzerErrorUnit.putUnavailable(next, tabFileName, text(), failure);
      notifyPublisher();
    }
  }

  /**
   * إِشرَاقُ التبويبِ وَتَغَيُّرُهُ عَلى سَبيلٍ وَاحدٍ: إِنَّ تَغَيَّرَتِ الوَجهَةُ أُغلِقَ مَا قَبلَهَا
   * وَفُتِحَ الجَدِيدُ، وَإِلَّا جُدوِلَ الفَحصُ بِتَرَدُّدِ المَكتَبَةِ — لا فَحصَ مُتَزَامِنًا مَعَ
   * كُلِّ حَرفٍ، وَلَا قَرَارًا عَلى نَصٍّ قَديمٍ.
   */
  public void onEditorSignal(String tabFileName, String tabReference) {
    if (echoing()) return; // الحَامِلُ يُعلِمُنَا بِمَا رَسَمهُ نَشرُنَا — فَذَاكَ إِعدَادٌ لَا إِشرَاقٌ
    if (tabReference == null || !tabReference.equals(reference)) {
      focus(tabFileName, tabReference);
      return;
    }
    textChanged();
  }

  /** المُحرِّرُ قَال: تَغَيَّرَ النَّصُّ. لَا قِرَاءَةَ هُنَا وَلَا فَحصًا — إِخطَارٌ فَقط. */
  public void textChanged() {
    if (echoing()) return; // الكِتَابَةُ أَثۡنَاءَ النَّشرِ لَا تُعِيدُ الفَحصَ
    for (Runnable listener : new ArrayList<>(changeListeners)) listener.run();
    if (handle == null && reference != null && nativeAvailable()) focus(fileName, reference);
  }

  /** طَلَبُ فَحصٍ مُبَاشِرٌ (بَعدَ الحِفظِ قَبلَ البِنَاءِ: النَّافِذَةُ تَقرَأُ آخِرَ مَا كُتِبَ). */
  public void requestAnalysis() {
    if (handle != null) handle.requestAnalysis();
  }

  /** بِذلِكَ يَعرِفُ المَمَرُّ الجَمعِيُّ أَينَ يَمشِي؛ {@code null} تُلغِي الجَمعَ وَتُبقِي فَحصَ التبويبِ. */
  public void setProjectHost(ProjectHost host) {
    projectHost = host;
    if (host == null) {
      projectMain.removeCallbacks(projectKick);
      clearProjectRows();
    }
  }

  /**
   * جَدوَلَةُ مَمَرٍّ جَمعِيٍّ: إِنْ كَانَ وَاحِدٌ جَارِيًا فَنَضعُ عَلَمَ قُفلٍ وَاحدًا (لَا طَابُورًا
   * يَنمُو مَعَ كُلِّ حِفظٍ)، وَإِن مَضَى عَلَيهِ زَمَنٌ قَصيرٌ نُؤَجِّلُ بِمُهَلَةِ الوَاجِهَةِ لَا
   * بِنَومٍ — فَخَيطُ العَمَلِ لَا يَنَامُ عِندَنَا، وَلَا يَقرَأُ القُرصَ أَصلاً.
   */
  public void requestProjectPass() {
    if (projectHost == null || !nativeAvailable()) return;
    if (projectRunning) {
      projectQueued = true;
      return;
    }
    long since = android.os.SystemClock.uptimeMillis() - projectLastStart;
    if (since < PROJECT_PASS_INTERVAL_MS) {
      projectMain.removeCallbacks(projectKick);
      projectMain.postDelayed(projectKick, PROJECT_PASS_INTERVAL_MS - Math.max(0L, since));
      return;
    }
    startProjectPass();
  }

  private void startProjectPass() {
    if (projectRunning || projectHost == null) return;
    final java.io.File module = projectHost.moduleDir();
    if (module == null || !module.isDirectory()) return;
    if (projectWorker == null) {
      projectWorker =
          java.util.concurrent.Executors.newSingleThreadExecutor(
              new java.util.concurrent.ThreadFactory() {
                @Override public Thread newThread(Runnable task) {
                  Thread worker = new Thread(task, "shima-project");
                  // خَيطٌ خافِضُ الأَولَوِيَّةِ رَهِينُ الدَّهرِ: القَتلُ عِندَ الإِغلَاقِ أَصدَقُ مِنَ
                  // وَلا يَنتَظِرُ أَحَدٌ إِغلَاقَهُ: لَا يَحمِلُ عَلَيهِ قُفلًا وَلَا حِفظًا.
                  worker.setDaemon(true);
                  worker.setPriority(Thread.MIN_PRIORITY);
                  return worker;
                }
              });
    }
    projectRunning = true;
    projectLastStart = android.os.SystemClock.uptimeMillis();
    final String focusRef = reference;
    final String focusText = text();
    try {
      projectWorker.submit(
          new Runnable() {
            @Override public void run() {
              runProjectPass(module, focusRef, focusText);
            }
          });
    } catch (RuntimeException rejection) {
      projectRunning = false;
      projectQueued = false;
    }
  }

  /** جِسمُ الخَيطِ: جَدوَلَةٌ، ثُمَّ قِرَاءَةٌ بِحَدٍّ، ثُمَّ مَمرٌ وَاحدٌ، ثُمَّ نَشرٌ عَلَى الوَاجِهَةِ. */
  private void runProjectPass(java.io.File module, String focusRef, String focusText) {
    String note = null;
    int feedSkipped = 0; // كَم صِنفًا تُرِكَ عَنِ التَّغمِيذِ لِأَجلِ الحِصَّةِ — يُعلَنُ كَغَيرِهِ
    List<String> written = new ArrayList<>();
    try {
      AnalyzerWorkspacePlan.Plan plan = AnalyzerWorkspacePlan.of(module);
      int droppedAtRead = 0;
      if (!plan.isEmpty()) {
        ArrayList<com.shima.analyzer.core.SourceFile> files = new ArrayList<>();
        java.util.HashMap<String, String> texts = new java.util.HashMap<String, String>();
        java.util.HashMap<String, String> resourceTexts =
            new java.util.HashMap<String, String>(); // بِالمِسَارِ النِّسبِيِّ: كَمَا تَقُولُهُ المَكتَبَة
        for (AnalyzerWorkspacePlan.Entry entry : plan.sources) {
          String id = entry.reference(module);
          if (id.equals(focusRef)) continue; // النَّصُّ الحَيُّ يُرسَلُ تَحتَ مِرجَعِ التبويبِ أدنَاهُ
          AnalyzerWorkspacePlan.Read read = AnalyzerWorkspacePlan.read(module, entry);
          if (!read.usable()) {
            droppedAtRead++; // إِعلَانٌ لَا إِسقاطٌ: مَا لَم يُقَرَأ لَيسَ «سَلِيمًا» بِالحُكمِ.
            continue;
          }
          files.add(
              new com.shima.analyzer.core.SourceFile(
                  id, kindOf(entry.kind), read.text));
          texts.put(id, read.text);
        }
        String liveResource = null;
        if (focusRef != null && focusText != null && isSupported(focusRef)) {
          if (focusRef.endsWith(".xml")) {
            // «‏Use addResource for XML‏» عِندَهُم (‏WorkspaceSnapshot:19‏): فَالحَيُّ مِن ‏.xml‏
            // يَدخُلُ مَوَارِدَ، وَبِدَلَالَتِهِ يَصيرُ صَفُّ المُحرِّرِ مُتَّفِقًا مَعَ صَفِّ الجَمعِ.
            liveResource = relativeIn(module, focusRef);
            if (liveResource != null) {
              resourceTexts.put(liveResource, focusText);
            } else {
              texts.put(focusRef, focusText);
              files.add(new com.shima.analyzer.core.SourceFile(focusRef, Language.JAVA, focusText));
            }
          } else {
            files.add(
                new com.shima.analyzer.core.SourceFile(
                    focusRef, languageOf(focusRef), focusText));
            texts.put(focusRef, focusText);
          }
        }
        ArrayList<com.shima.analyzer.core.ResourceFile> resources =
            new ArrayList<com.shima.analyzer.core.ResourceFile>();
        for (AnalyzerWorkspacePlan.Entry entry : plan.resources) {
          if (entry.relativePath.equals(plan.idsRelativePath)) continue;
          if (entry.relativePath.equals(liveResource)) continue; // النَّصُّ الحَيُّ يُرسَلُ أدنَاهُ
          AnalyzerWorkspacePlan.Read read = AnalyzerWorkspacePlan.read(module, entry);
          if (!read.usable()) {
            droppedAtRead++;
            continue;
          }
          resources.add(new com.shima.analyzer.core.ResourceFile(entry.relativePath, read.text));
          resourceTexts.put(entry.relativePath, read.text);
        }
        com.shima.analyzer.core.WorkspaceSnapshot.Builder snapshot =
            com.shima.analyzer.core.WorkspaceSnapshot.builder()
                .resourceIndexComplete(plan.resourcesComplete)
                .idsFile(plan.idsRelativePath == null ? "res/values/ids.xml" : plan.idsRelativePath);
        String ns = projectHost == null ? null : projectHost.namespace();
        if (ns != null
            && ns.matches("[A-Za-z_$][A-Za-z0-9_$]*(?:\\.[A-Za-z_$][A-Za-z0-9_$]*)*")) {
          snapshot.namespace(ns);
        }
        for (com.shima.analyzer.core.SourceFile file : files) snapshot.addSource(file);
        for (com.shima.analyzer.core.ResourceFile resource : resources) snapshot.addResource(resource);
        com.shima.analyzer.core.WorkspaceSnapshot built = snapshot.build();
        if (liveResource != null) {
          built = built.withResource(
              new com.shima.analyzer.core.ResourceFile(liveResource, focusText));
        }
        java.util.ArrayList<String> forFeed = new java.util.ArrayList<String>(texts.values());
        forFeed.addAll(resourceTexts.values());
        FedConfig fed = projectConfig(forFeed);
        com.shima.analyzer.core.AnalysisConfig config = fed.config;
        feedSkipped = fed.skipped;
        com.shima.analyzer.core.WorkspaceResult result;
        com.shima.analyzer.core.Analyzer analyzer = new com.shima.analyzer.core.Analyzer(config);
        try {
          result = analyzer.analyzeWorkspace(built);
        } finally {
          try {
            analyzer.close();
          } catch (RuntimeException ignored) {
            // إِغلَاقُ مُستَثنًى لَا يُبطِلُ نَتيجَةً وُجِدَت: النَّشرُ أَهمُّ مِنَ التَّنَظُّفِ.
          }
        }
        for (java.util.Map.Entry<String, com.shima.analyzer.core.AnalysisResult> one
            : result.getSources().entrySet()) {
          String id = one.getKey();
          List<AnalyzerErrorUnit.Row> rows =
              AnalyzerErrorUnit.map(nameOf(id), id, texts.get(id), one.getValue());
          AnalyzerErrorUnit.putProjectRows(id, rows);
          written.add(id);
        }
        // رَجعُ المَوَارِدِ لَيسَ زِخرَفًا: ‏XML_SYNTAX_ERROR‏ يَخرُجُ هُنَاكَ دُونَ غَيرِهَا
        // (قِسنَاهُ: وَثيقَةٌ غَيرُ مُغلَقَةٍ ← صَفٌّ فِي ‏getResources()‏ وَصِفرٌ فِي غَيرِهَا)،
        // فَكُنَّا نَرمِيهِ بِالحَقِيقَةِ. المِفتَاحُ مُطلَقٌ: نَفسُ لاصِقِ التبويبِ، فَلَا تَابُوتَانِ
        // لِمِلَفٍّ وَاحدٍ وَلَا خَطٌّ تَحتَ غَيرِهِ.
        for (java.util.Map.Entry<String, com.shima.analyzer.core.AnalysisResult> one
            : result.getResources().entrySet()) {
          String id = new java.io.File(module, one.getKey()).getAbsolutePath();
          List<AnalyzerErrorUnit.Row> rows =
              AnalyzerErrorUnit.map(
                  nameOf(id), id, resourceTexts.get(one.getKey()), one.getValue());
          AnalyzerErrorUnit.putProjectRows(id, rows);
          written.add(id);
        }
      }
      note = withApiAssumption(withFeedCap(
          AnalyzerWorkspacePlan.withReadDrops(plan.coverageNote(), droppedAtRead), feedSkipped));
    } catch (IllegalArgumentException budget) {
      // تَجَاوُزُ المِلقَطِ حِصَّةً حِسَابِيَّةٌ عِندَنَا: نَعلَنُ النَّقصَ، وَلَا نَرمِي «جِذرًا مَيِّتًا»
      // وَلَا نَكتُمُ السَّبَبَ — هذِهِ الحَالَةُ هِيَ الفَرقُ بَينَ صَفِّ وَهمٍ وَصَفٍّ صَادِقٍ.
      note = "الفَحصُ الجَمعِيُّ وَقَفَ قَبلَ النَّهَايَةِ: "
          + (budget.getMessage() == null ? "حِصَّةٌ مُخَالَفَةٌ" : budget.getMessage());
    } catch (RuntimeException | LinkageError failure) {
      final String referenceSnapshot = reference;
      final String fileSnapshot = fileName;
      AnalyzerErrorUnit.putUnavailable(
          referenceSnapshot, fileSnapshot, focusText, failure);
      notifyPublisher();
      projectRunning = false;
      if (projectQueued) {
        projectQueued = false;
        projectMain.post(projectKick);
      }
      return;
    }
    publishProjectPass(written, note, module.getName());
  }

  /** حَلقَةُ الوَاجِهَةِ: تَنظِيفُ مَا خَرَجَ مِنَ المِلقَطِ، ثُمَّ النَّشرُ — مَرَّةً وَاحدَةً. */
  private void publishProjectPass(final List<String> written, final String note, final String moduleName) {
    projectMain.post(
        new Runnable() {
          @Override public void run() {
            for (String previous : new ArrayList<>(projectWritten)) {
              if (!written.contains(previous)) AnalyzerErrorUnit.clear(previous);
            }
            projectWritten.clear();
            projectWritten.addAll(written);
            if (note == null) {
              AnalyzerErrorUnit.clear(PROJECT_NOTE_REFERENCE);
            } else {
              ArrayList<AnalyzerErrorUnit.Row> rows = new ArrayList<AnalyzerErrorUnit.Row>();
              AnalyzerErrorUnit.Row row =
                  AnalyzerErrorUnit.budgetRow(moduleName, PROJECT_NOTE_REFERENCE, note);
              if (row != null) rows.add(row);
              AnalyzerErrorUnit.putProjectRows(PROJECT_NOTE_REFERENCE, rows);
            }
            projectRunning = false;
            notifyPublisher();
            if (projectQueued) {
              projectQueued = false;
              startProjectPass();
            }
          }
        });
  }

  private void clearProjectRows() {
    for (String previous : new ArrayList<>(projectWritten)) AnalyzerErrorUnit.clear(previous);
    projectWritten.clear();
    AnalyzerErrorUnit.clear(PROJECT_NOTE_REFERENCE);
  }

  private static Language kindOf(AnalyzerWorkspacePlan.Kind kind) {
    return kind == AnalyzerWorkspacePlan.Kind.KOTLIN ? Language.KOTLIN : Language.JAVA;
  }

  private static String nameOf(String reference) {
    String path = reference == null ? "" : reference.replace('\\', '/');
    int slash = path.lastIndexOf('/');
    return slash < 0 ? path : path.substring(slash + 1);
  }

  /**
   * بَابُ النَّشرِ الوَاحِدُ: إِنۡ كُنَّا دَاخِلَ نَشرٍ فَالطَّلَبُ مُجَمَّعٌ (نَظرَةٌ وَاحِدَةٌ
   * بَعۡدَ الفَرَاغِ) لَا مُتَتَالٍ — فَالقَطۡعُ هُنَا، إِذۡ لَا مَعۡنَىٰ لأنۡ يُنشِئَ نَشرٌ نَشرًا.
   */
  private void notifyPublisher() {
    if (publisher == null) return;
    // A project-pass failure can reach here on the worker, but the publisher
    // updates Android views and all focus/paint guards belong to the main thread.
    if (android.os.Looper.myLooper() != android.os.Looper.getMainLooper()) {
      projectMain.post(this::notifyPublisher);
      return;
    }
    if (publishOwner == Thread.currentThread()) {
      publishAgain = true;
      return;
    }
    publishOwner = Thread.currentThread();
    try {
      publisher.publish();
      if (publishAgain) {
        publishAgain = false;
        publisher.publish();
      }
    } finally {
      publishAgain = false;
      publishOwner = null;
    }
  }

  /** هَلۡ إِشرَاقُنَا الحَالِيُّ صَدَىٰ رَسمٍ نَشَرۡنَاهُ نَحنُ؟ فَلَيسَ مِن حَقِّنَا تَلۡبِيَتُهُ. */
  private boolean echoing() {
    return publishOwner == Thread.currentThread();
  }

  public void release() {
    // إِن لَّم يَكُن مَفْتُوحًا شَيْءٌ فَلَمْ يَزُلْ شَيْءٌ، فَلا إِعْلانَ عَلى «لا شَيْءَ»:
    // النَّشْرُ الأَعْمَى هُنَا هُوَ الَّذِي أَشْعَلَ الدَّوْرَةَ عِنْدَ الإِقْلَاعِ بِلَا مَشْرُوعٍ.
    boolean hadState = handle != null || reference != null || fileName != null
        || !changeListeners.isEmpty() || !projectWritten.isEmpty();
    if (handle != null) {
      try {
        handle.close();
      } catch (RuntimeException ignored) {
        // الإِغلَاقُ مُتَكَرِّرُ الأَمانِ عِندَ المَكتَبَةِ؛ وَإِن ثَمَّ شَيءٌ يَخرُجُ فَلا نَترُكُ الجِهَةَ.
      }
      handle = null;
    }
    changeListeners.clear();
    projectMain.removeCallbacks(projectKick);
    clearProjectRows();
    if (reference != null) AnalyzerErrorUnit.clear(reference);
    reference = null;
    fileName = null;
    if (hadState) notifyPublisher();
  }

  /** مَا يَرَاهُ الشَّريطُ/البَوَّابَةُ: لَا «سَلِيمٌ» عِندَمَا لَم يَنظُرْ أحَدٌ. */
  public String status() {
    if (!probed) return "IDLE";
    if (!nativeReady) return "UNAVAILABLE_NATIVE(" + nativeReason + ")";
    String tab = handle == null ? "READY_NO_TAB" : "READY";
    if (projectRunning) return tab + "+PROJECT_PASS";
    return projectWritten.isEmpty() ? tab : tab + "+PROJECT_" + projectWritten.size();
  }

  private String text() {
    return source == null || reference == null ? null : source.textOf(reference);
  }

  /**
   * الجَاوَا وَكُوتلِنُ وَ‏xml‏: الأَوَّلَانِ بِالشَّجَرَةِ، وَالثَّالِثُ بِـ‏XmlAnalyzer‏ — قَرَأتُ
   * ‏AnalysisHandle:83-90‏ فَوَجَدتُ المَكتَبَةَ نَفسَهَا تَفتَحُ ‏Language.XML‏ عَلى فَحصِ الوَثيقَةِ
   * (بِلَا نَحوٍ طَبيعِيٍّ وَلَا قَيدِ مُستَهلِكٍ)، فَوَضعُ التبويبِ عَلَيهَا كَاذِبٌ بَعدَ اليَومِ.
   * أَمَّا مَا بَينَ ذلِكَ (قِيَمُ ‏@drawable‏ المُعلَّقَةِ وَتَناسُقُ الأَسمَاءِ) فَغَيرُ مَفتُوحٍ
   * عِندَهُم — وَلَا نَدَّعِيهِ.
   */
  private static boolean isSupported(String path) {
    return path.endsWith(".java") || path.endsWith(".kt") || path.endsWith(".xml");
  }

  /** لُغَةٌ وَاحِدَةٌ لِلطَّرِيقَينِ: إِنْ تَزَحزَحَت إحدَاهُمَا عَنِ الأُخرَى فَصَارَ التَّبويبُ يُفحَصُ بِلِسَانٍ غَلَطٍ. */
  private static Language languageOf(String path) {
    String p = path == null ? "" : path;
    if (p.endsWith(".xml")) return Language.XML;
    return p.endsWith(".kt") ? Language.KOTLIN : Language.JAVA;
  }

  /**
   * تَركِيبَةُ فَحصِ التبويبِ: مُستَوَيَا المِشرُوعِ لَا مُستَوَيَا الجِهَازِ — لِأَنَّ
   * «مَهجُورٌ مُنذُ ٢٦» عِندَهُم لَا تُقَالُ إِلَّا إِذَا كَانَ ‏deprecated ≤ compileApi‏
   * (‏SemanticRules:127‏). قِسنَاهُ: نَفسُ المِلَفِّ مَعَ ‏compileApi=25‏ صَمتٌ، وَمَعَهُ ٣٧
   * صَفُّ ‏ANDROID_DEPRECATED‏ — فَالجِهَازُ يُسكِتُ الحَقَّ.
   */
  private AnalysisConfig editorConfig(String text) {
    ProjectPlatform platform = ProjectPlatform.current();
    AnalysisConfig.Builder builder =
        AnalysisConfig.builder()
            .minApi(platform.analyzerMinApi())
            .compileApi(platform.analyzerCompileApi(android.os.Build.VERSION.SDK_INT));
    // صِفْرُ إِعلَانٍ عَنِ الحِصَّةِ هُنَا عَمدًا: تبويبٌ وَاحدٌ لَا يَبلُغُ ‏8192‏ مُدخَلًا،
    // وَمَا يَحدُثُ عَلى المِشرُوعِ كُلِّهِ يُقالُ عَلَى صَفِّ الجَمعِ.
    feedAndroidTypes(builder, java.util.Collections.singletonList(text));
    return builder.build();
  }

  /** نَتِيجَةُ تَركِيبَةِ الجَمعِ: المِخدَعُ + مَا تُرِكَ مِنَ التَّغمِيذِ (لَا يُكتمُ السَّقَطُ). */
  private static final class FedConfig {
    final AnalysisConfig config;
    final int skipped;

    FedConfig(AnalysisConfig config, int skipped) {
      this.config = config;
      this.skipped = skipped;
    }
  }

  /** تَركِيبَةُ الجَمعِ: الحُدُودُ أَدنَى مِن سَقَفِهِم دَائِمًا — وَإِلَّا فَهُوَ رَفعُ استِثنَاءٍ لَا ‏PARTIAL‏. */
  private static FedConfig projectConfig(java.util.Collection<String> texts) {
    ProjectPlatform platform = ProjectPlatform.current();
    AnalysisConfig.Builder builder =
        AnalysisConfig.builder()
            .minApi(platform.analyzerMinApi())
            .compileApi(platform.analyzerCompileApi(android.os.Build.VERSION.SDK_INT))
            .maxProjectFiles(AnalyzerWorkspacePlan.MAX_FILES + 8)
            .maxProjectChars(AnalyzerWorkspacePlan.MAX_TOTAL_CHARS)
            .maxDocumentChars(AnalyzerWorkspacePlan.MAX_FILE_CHARS);
    int skipped = feedAndroidTypes(builder, texts);
    return new FedConfig(builder.build(), skipped);
  }

  /**
   * كَتالُوجُهُم قَصْدًا تِسعَةُ أَصنَافٍ (‏ApiCatalog:16-24‏: «المَجهُولُ لَا يَستَحقُّ دَعوَى»)،
   * وَفَهرَسُنَا المَحمِيُّ عَنِ الأَصلَابِ أَوسَعُ — فَنَحنُ نَغذُوهُ بِمَا ذُكِرَ فِي المِلَفِّ
   * فَحَسبُ (مِن سُطُورِ ‏import android.‏): قَدرٌ مَحدُودٌ، وَلَا دَعوَى عَلَى صِنفٍ لَم نَرَ
   * مُستَوَاهُ. وَمَا لَا يَقبَلُونَهُ يُترَكُ — صِفْرُ صُفوفٍ أَصدَقُ مِن صَفٍّ مَبنِيٍّ عَلَى
   * تَفسِيرٍ لَا يُطِيقُونَهُ.
   */
  private static final int MAX_FED_TYPES = 4096;
  /** حِصَّةٌ وَاحدَةٌ لِلأَنوَاعِ وَالسَّاكِنَاتِ جَمِيعًا — سَقفُهُم ‏50_000‏ يَجمَعُهُمَا (‏AnalysisConfig:30‏). */
  private static final int MAX_FED_ENTRIES = 8192;

  /** يَرجِعُ عَدَدَ مَا تُرِكَ مِن أَجلِ الحِصَّةِ — يُعلَنُ عَلَى صَفِّ النَّقصِ، وَلَا يُكتمُ. */
  private static int feedAndroidTypes(
      AnalysisConfig.Builder builder, java.util.Collection<String> texts) {
    if (texts == null || texts.isEmpty()) return 0;
    if (!almlk.AndroidApiIndex.isLoaded()) return 0; // الفَهرَسُ لَم يُحمَّل بَعدُ: لَا شَيءَ نُثبِتُهُ
    java.util.LinkedHashSet<String> wanted = new java.util.LinkedHashSet<String>();
    for (String text : texts) {
      collectAndroidImports(text, wanted);
      if (wanted.size() >= MAX_FED_TYPES) break;
    }
    int fed = 0;
    int skipped = 0;
    for (String fqcn : wanted) {
      almlk.AndroidApiIndex.ClassInfo info = almlk.AndroidApiIndex.classByQualifiedName(fqcn);
      if (info == null) continue; // مَجهُولٌ عِندَنَا: نَكتُمُ — وَلَا نَختَرِعُ مُستَوًى
      almlk.AnalyzerSymbolFeed.Feed feed = almlk.AnalyzerSymbolFeed.of(
          fqcn, info.since, info.deprecated, membersOf(info), MAX_FED_ENTRIES - fed);
      if (feed == null) {
        skipped++; // حِصَّةٌ لَا تَبقَى لَهَا: الصِّنفُ كُلُّهُ يُترَكُ — وَيُذكَرُ أَنَّهُ تُرِكَ
        continue;
      }
      if (feed.entries == 0) {
        skipped++;
        continue; // الحِصَّةُ انقَضَت: هذَا الصِّنفُ لَا يُغذَّى نِصفًا
      }
      fed += feed.entries;
      try {
        builder.addAndroidApiType(feed.type, feed.since, feed.deprecated);
      } catch (RuntimeException rejected) {
        // رَفضَهُم (مَثَلًا صِنفٌ لَيسَ ‏android.*‏): يَمضِي الفَحصُ بِدُونِهِ.
        skipped++;
      }
      for (java.util.Map.Entry<String, int[]> one : feed.statics.entrySet()) {
        try {
          builder.addAndroidApiStaticMethod(feed.type, one.getKey(), one.getValue()[0],
              one.getValue()[1]);
        } catch (RuntimeException rejected) {
          skipped++; // الاِسمُ رُبَّمَا كَسَرَ حِدَّهِم: العُضوُ وَحدَهُ يُترَكُ، لَا المِلَفُّ كُلُّهُ
        }
      }
    }
    return skipped;
  }

  /**
   * مَا يُمكِنُ للإِرسَالِ أَن يُبَنِىَ عَلَيهِ: ‏isStatic‏ مَعلُومٌ عِندَنَا (‏AndroidApiIndex:102‏)،
   * وَهُوَ الفَصلُ عِندَهُم — قِسنَا أَنَّ المِفْتَاحَ ‏owner#name‏ لَا يُدرِكُ النِّدَاءَ عَبرَ
   * مُتَغَيِّرٍ، فَالسَّاكِنُ فَحَسبُ هُوَ الَّذي لَا يَضَعُ حُكمًا فِى غَيرِ مَوضِعِهِ.
   * وَ‏ownLevels‏ يَستَبعِدُ مَا وَرِثَهُ العُضوُ عَنِ الصِّنفِ (فَهرَسُنَا يَملاُ بِهِ، قَيدٌ عَلى ‏:117‏).
   */
  private static java.util.List<almlk.AnalyzerSymbolFeed.Member> membersOf(
      almlk.AndroidApiIndex.ClassInfo info) {
    java.util.ArrayList<almlk.AnalyzerSymbolFeed.Member> out =
        new java.util.ArrayList<almlk.AnalyzerSymbolFeed.Member>();
    for (almlk.AndroidApiIndex.Member m : almlk.AndroidApiIndex.declaredMembers(info)) {
      if (m == null) continue;
      boolean own = m.since != info.since || m.deprecated != info.deprecated;
      out.add(new almlk.AnalyzerSymbolFeed.Member(
          m.name, m.isStatic, m.kind == almlk.AndroidApiIndex.Member.METHOD,
          m.since, m.deprecated, own));
    }
    return out;
  }

  /** سُطُورُ ‏import android.…;‏ فَحَسبُ — لِأنَّ ‏addAndroidApiType‏ عِندَهُم يَشرُطُ بَادِئَةَ ‏android.‏. */
  private static void collectAndroidImports(String text, java.util.LinkedHashSet<String> out) {
    if (text == null) return;
    int at = 0;
    while (out.size() < MAX_FED_TYPES) {
      int found = text.indexOf("import ", at);
      if (found < 0) return;
      int end = text.indexOf(';', found);
      if (end < 0) return;
      at = end + 1;
      String fqcn = text.substring(found + "import ".length(), end).trim();
      if (fqcn.endsWith("*") || !fqcn.startsWith("android.") || fqcn.startsWith("androidx.")) continue;
      if (fqcn.indexOf('(') >= 0 || fqcn.indexOf(' ') >= 0) continue;
      out.add(fqcn);
    }
  }

  /** إِذَا اُفتُرِضَ شَيءٌ فَذلِكَ مَكتُوبٌ فِي اللَّوحَةِ: قَرَارٌ عَلَى مُستَوًى لَم نَقرَؤُهُ لَا يُنسَبُ إِلَينَا. */
  private static String withApiAssumption(String note) {
    if (!ProjectPlatform.current().analyzerApiAssumed()) return note;
    return appendSentence(note,
        "مُستَوَيَا ‏minSdk/compileSdk‏ مأخُوذَانِ عَنِ الجِهَازِ لَا مِنَ المِشرُوعِ "
            + "(لَم يُصَرِّحْ بِهِمَا ‏build.gradle‏ رَقمًا صَريحًا) — فَقَرَارَاتُ «هذَا لَيسَ فِي حَدِّكَ» "
            + "وَ«مَهجُورٌ مُنذُ كَذَا» مُبَنِيَّةٌ عَلَى هذَا الاِفتِرَاضِ");
  }

  /** حِصَّةُ التَّغمِيذِ إِذَا انقَضَت تُذكَرُ: فَالنَّاقِصُ المَكتُومُ أَخطَرُ مِنَ الكَثِيرِ المُتَأَخِّرِ. */
  private static String withFeedCap(String note, int skipped) {
    if (skipped <= 0) return note;
    return appendSentence(note, skipped + " صِنفًا تُرِكَ عَن تَغمِيذِ المُحرِّكِ (بَلَغَ حِصَّتَهُ) — "
        + "فَمَا قِيلَ فِيهَا مِن «مَهجُورٍ» وَ«مُستَوًى» يَحتَمِلُ الزِّيَادَةَ لَو تَمَّ الإِرسَالُ");
  }

  /** جُمَلَةُ النَّقصِ وَاحدَةُ البِنَاءِ: تُفتَحُ إِنْ لَم يَكُن شَيءٌ، وَتُلحَقُ قَبلَ الذَّيلِ إِنْ كَانَ. */
  private static String appendSentence(String note, String extra) {
    if (note == null || note.isEmpty()) {
      return "الفَحصُ الجَمعِيُّ: " + extra + "؛ فَصَمتِي عَمَّا لَم أَصِلْ إِلَيهِ لَيسَ بَرَاءَةً.";
    }
    int tail = note.lastIndexOf(" — فَصَمتِي");
    if (tail < 0) return note + " وَ" + extra + "؛";
    return note.substring(0, tail) + " وَ" + extra + "؛" + note.substring(tail);
  }

  /** مَسَارٌ مُطلَقٌ إِلَى نِسبِيٍّ دَاخِلَ الوَحدَةِ، أَو {@code null} — لِتَبدِيلِ المَوَارِدِ الحَيَّةِ. */
  private static String relativeIn(java.io.File module, String reference) {
    if (module == null || reference == null) return null;
    String root = module.getAbsolutePath().replace('\\', '/');
    String path = reference.replace('\\', '/');
    if (!path.startsWith(root + "/") || path.length() <= root.length() + 1) return null;
    return path.substring(root.length() + 1);
  }

  /** مُحمِّلٌ وَاحدٌ لِلتَّحقُّقِ مِن وُجُودِ الصِّنفِ قَبلَ أن يَكتَشِفَهُ المُحرِّرُ نَفسُهُ. */
  private static final class NativeBridgeLoader {
    static ClassLoader loader() { return AnalyzerBridge.class.getClassLoader(); }
  }

  /** وَجهَةُ المَكتَبَةِ إِلَى نَصِّنَا: قِرَاءَةٌ، وَإِخطَارٌ، وَلَا كِتَابَةَ — صَفُّ الإِصلاحِ يَفِي بِكُلِّ شَيءٍ. */
  private final class BridgeAdapter implements EditorAdapter {
    @Override public String getText() {
      String value = text();
      return value == null ? "" : value;
    }

    @Override public void replace(int startOffset, int endOffset, String replacement) {
      // لَا سَبِيلَ إِلَى هُنَا فِي تَطرِيقَتِنَا: الإِصلاحُ يَمرُّ عَلى صَفِّ {@link almlk.QuickFix}
      // فَيَأخُذُ التَّراجُعَ وَالاتَّسَاخَ وَالحِفظَ قَبلَ البِنَاءِ وَدَورَةَ المُكتَبَاتِ كُلَّهَا.
      // لَو تَغَيَّرَ ذلِكَ يَومًا فَالسَّقطةُ هُنَا أَصدَقُ مِن كِتَابَةٍ نِصفَ مَسمُوعَةٍ.
      throw new UnsupportedOperationException(
          "Apply analyzer fixes through almlk.QuickFix rows (undo, dirty and save are theirs).");
    }

    @Override public Subscription subscribe(Runnable onChange) {
      changeListeners.add(onChange);
      return new Subscription() {
        @Override public void close() {
          changeListeners.remove(onChange);
        }
      };
    }
  }
}
