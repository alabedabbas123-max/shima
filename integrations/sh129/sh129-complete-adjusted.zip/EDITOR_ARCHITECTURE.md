# بنية محرر Shima وفق مواصفات Almlk_AR

المرجع التنفيذي الذي بُنيت عليه هذه الطبقة:

<https://github.com/alabedabbas123-max/kingid/blob/main/Almlk_AR.md>

تمت ترجمة المواصفات إلى Java/Android Views الموجودة في Shima بدل إدخال Compose أو نسخ أي كود خارجي.

## طبقات التنفيذ

```text
MainActivity / AIDEEditorPager
        │
AlmlkEditor (واجهة EditText متوافقة + إشعارات التغيير)
        │
com.shima.editor.core
  PieceTableDocument
  LineIndex
  UndoRedoManager
  SmaliTokenizer + SmaliTokenCache
  SmaliDiagnosticsEngine
  SmaliCompletionEngine
  InMemoryWorkspaceIndex
  LazyProjectTree
  AtomicSaveManager
  DexMetadataReader
```

## ما تم تثبيته

- Piece Table يحتفظ بالنص في قطع، وتُضاف التعديلات إلى add-buffer بدل إعادة بناء String عند كل تحرير.
- LineIndex محدث محليًا عند الاستبدال، ويدعم `lineOf` و`offsetOfLine`.
- Undo/Redo قائم على أوامر مع تجميع الكتابة المتتابعة خلال 300ms.
- Smali tokenizer يتعرف على التعليقات، directives، opcodes، registers، labels، descriptors، strings، الأرقام، methods، fields، annotations.
- Token cache حسب رقم السطر ونسخة المستند، مع إبطال من السطر المتأثر.
- Diagnostics تدريجية أساسية لـ Smali: نطاق registers، labels المكررة/المفقودة، method غير المغلقة، descriptor غير صالح.
- Completion خاص بـ Smali لمصادر directives/opcodes/registers/labels/descriptors، بحد أقصى 50 نتيجة.
- Go To Definition محلي لـ Smali مع إبقاء مسار فهرس المشروع الحالي للغات الأخرى.
- DEX metadata viewer يقرأ الترويسة والأعداد/الإزاحات فقط ولا ينفذ bytecode.
- Workspace index عام غير متزامن لفهرسة class/method/field/references دون تحميل أو تنفيذ classes.
- شجرة مشروع lazy ونماذج أنواع الملفات.
- حفظ ذري للملفات المحلية، وحفظ SAF عبر `ContentResolver`، مع autosave debounce 750ms وrecovery copy.
- ربط التعديل داخل `AlmlkEditor` بنموذج Piece Table، مع إبقاء EditText الحالي كطبقة إدخال/تحديد متوافقة.
- توسيع أنواع الملفات النصية لتشمل Smali وCSV.

## حدود متعمدة

- الملفات العملاقة جدًا ما زالت تستخدم مسار `ViewportCodeEditorView` كطبقة foundation؛ ترحيل كل عمليات التحرير المرئي من EditText إلى viewport مخصص مستقل هو مرحلة لاحقة عالية المخاطر على ميزات ActionMode ولوحة المفاتيح.
- فهرس `ProjectSymbolIndex` القديم ما زال موجودًا للحفاظ على completion/definition الحالي، بينما `InMemoryWorkspaceIndex` يمثل واجهة WorkspaceIndex الجديدة ويمكن ربطه تدريجيًا بموفر ملفات المشروع.
- لا يتم تفسير أو تنفيذ DEX.

## فحوصات البناء

- `:app:compileDebugJavaWithJavac` ناجح.
- اختبارات smoke لنموذج Piece Table وLineIndex وSmali tokenizer/diagnostics ناجحة.
