import almlk.AnalyzerBridge;
import almlk.AnalyzerErrorUnit;
import almlk.AnalyzerSignalQueue;
import almlk.EditorFocusEdge;
import com.almlkid.kay.ui.ProjectDiagnostic;
import android.content.Context;
import java.lang.reflect.Field;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;

/** Host regression for the real app bridge and the main-thread signal queue. */
public final class AnalyzerSignalQueueRegression {
  private static int checks;

  private static void check(boolean value, String message) {
    checks++;
    if (!value) throw new AssertionError(message);
  }

  private static final class QueuePoster implements AnalyzerSignalQueue.Poster {
    final ArrayDeque<Runnable> tasks = new ArrayDeque<>();
    boolean rejectNext;
    public boolean post(Runnable task) {
      if (rejectNext) { rejectNext = false; return false; }
      tasks.addLast(task);
      return true;
    }
    void runOne() { tasks.removeFirst().run(); }
    void drain() {
      int count = 0;
      while (!tasks.isEmpty()) {
        if (++count > 128) throw new AssertionError("runaway editor-signal loop");
        runOne();
      }
    }
  }

  private static void queueSemantics() {
    QueuePoster poster = new QueuePoster();
    List<String> delivered = new ArrayList<>();
    AnalyzerSignalQueue q = new AnalyzerSignalQueue(poster,
        (name, ref, changed) -> delivered.add(name + ":" + ref + ":" + changed));
    check(q.offer("A", "/A.java", false), "first signal accepted");
    q.offer("A", "/A.java", true);
    q.offer("B", "/B.java", false);
    check(poster.tasks.size() == 1, "signals share one queued task");
    poster.drain();
    check(delivered.size() == 1 && delivered.get(0).equals("B:/B.java:true"),
        "latest focus and edit flag survive coalescing");

    q.offer("stale", "/stale.java", true);
    q.cancel();
    q.offer("fresh", "/fresh.java", false);
    check(poster.tasks.size() == 2, "a new task is scheduled after cancellation");
    poster.runOne();
    check(delivered.size() == 1, "a cancelled task cannot consume the new signal");
    poster.drain();
    check(delivered.size() == 2 && delivered.get(1).equals("fresh:/fresh.java:false"),
        "the new signal survives a stale queued task");

    poster.rejectNext = true;
    check(!q.offer("rejected", "/r.java", true), "rejected post is reported");
    check(q.offer("retry", "/retry.java", false), "a later signal retries posting");
    poster.drain();
    check(delivered.get(2).equals("retry:/retry.java:true"),
        "an edit is retained across a rejected post");

    final AnalyzerSignalQueue[] recursive = new AnalyzerSignalQueue[1];
    final int[] depth = {0}, maxDepth = {0}, count = {0};
    recursive[0] = new AnalyzerSignalQueue(poster, (name, ref, changed) -> {
      depth[0]++;
      maxDepth[0] = Math.max(maxDepth[0], depth[0]);
      if (++count[0] == 1) recursive[0].offer("second", "/second.java", false);
      depth[0]--;
    });
    recursive[0].offer("first", "/first.java", false);
    poster.drain();
    check(count[0] == 2 && maxDepth[0] == 1,
        "a signal emitted during delivery is queued, not recursively dispatched");
  }

  private static Object field(Object target, String name) throws Exception {
    Field f = target.getClass().getDeclaredField(name);
    f.setAccessible(true);
    return f.get(target);
  }

  private static boolean nativeAvailable() {
    try {
      Class.forName("com.shima.analyzer.core.NativeBridge", true,
          AnalyzerSignalQueueRegression.class.getClassLoader());
      return true;
    } catch (ClassNotFoundException | LinkageError missing) {
      return false;
    }
  }

  private static void bridgeAndFocus(boolean haveNative) throws Exception {
    AnalyzerErrorUnit.clearAll();
    QueuePoster poster = new QueuePoster();
    EditorFocusEdge edge = new EditorFocusEdge();
    final AnalyzerBridge[] bridge = new AnalyzerBridge[1];
    final String[] activeName = {null}, activeRef = {null}, deliveredRef = {null};
    final boolean[] switchDuringPaint = {false};
    final int[] publishes = {0}, deliveries = {0};

    AnalyzerSignalQueue signals = new AnalyzerSignalQueue(poster, (name, ref, changed) -> {
      deliveries[0]++;
      deliveredRef[0] = ref;
      if (changed) bridge[0].onEditorSignal(name, ref);
      else bridge[0].focus(name, ref);
      if (changed) bridge[0].requestProjectPass();
    });
    EditorFocusEdge.Sink focus = (name, ref) -> signals.offer(name, ref, false);
    bridge[0] = new AnalyzerBridge(new Context(), ref ->
        ref != null && ref.equals(activeRef[0]) ? "class Demo { int value; }" : null, () -> {
          if (++publishes[0] > 32) throw new AssertionError("diagnostic/focus feedback loop");
          if (switchDuringPaint[0]) {
            switchDuringPaint[0] = false;
            activeName[0] = "C.java";
            activeRef[0] = "/p/C.java";
          }
          edge.announce(focus, activeName[0], activeRef[0]);
        });

    edge.announce(focus, null, null);
    poster.drain();
    for (int i = 0; i < 10000; i++) edge.announce(focus, null, null);
    check(publishes[0] == 0 && deliveries[0] == 1 && poster.tasks.isEmpty(),
        "repainting without a project does not recurse or republish");

    activeName[0] = "A.java"; activeRef[0] = "/p/A.java";
    edge.announce(focus, activeName[0], activeRef[0]);
    poster.drain();
    check(haveNative ? "/p/A.java".equals(field(bridge[0], "reference"))
                     : bridge[0].status().startsWith("UNAVAILABLE_NATIVE"),
        "first real focus is delivered");

    activeName[0] = "B.java"; activeRef[0] = "/p/B.java";
    switchDuringPaint[0] = true;
    edge.announce(focus, activeName[0], activeRef[0]);
    poster.drain();
    check(!switchDuringPaint[0] && edge.isCurrent("C.java", "/p/C.java"),
        "the publisher actually changed the focused editor during a transition");
    check("/p/C.java".equals(deliveredRef[0]), "the nested focus is delivered after painting");
    if (haveNative) {
      check("/p/C.java".equals(field(bridge[0], "reference")),
          "the bridge ends attached to C, not the obsolete B");
      Object handle = field(bridge[0], "handle");
      long before = ((Long) field(handle, "generation")).longValue();
      signals.offer("C.java", "/p/C.java", true);
      poster.drain();
      long after = ((Long) field(handle, "generation")).longValue();
      check(after > before, "text changes still invalidate analysis");
    } else {
      boolean found = false;
      for (ProjectDiagnostic row : AnalyzerErrorUnit.rows())
        if ("/p/C.java".equals(row.reference)) found = true;
      check(found, "the final file still reports an unavailable native analyzer");
      check("/p/C.java".equals(field(bridge[0], "reference")),
          "unavailable diagnostics remain owned by the final file");
    }
    check(publishes[0] < 10, "diagnostic publishes remain bounded");

    activeName[0] = "stale.java"; activeRef[0] = "/p/stale.java";
    edge.announce(focus, activeName[0], activeRef[0]);
    signals.cancel();
    activeName[0] = null; activeRef[0] = null;
    bridge[0].release();
    poster.drain();
    check(field(bridge[0], "reference") == null,
        "a queued focus cannot reopen an editor after the session closes");
    check(AnalyzerErrorUnit.rows().isEmpty(), "closing clears the last file's analyzer rows");
    bridge[0].release();
    AnalyzerErrorUnit.clearAll();
  }

  public static void main(String[] args) throws Exception {
    boolean haveNative = nativeAvailable();
    if (args.length > 0) check(haveNative == "native".equals(args[0]), "unexpected native test mode");
    queueSemantics();
    bridgeAndFocus(haveNative);
    System.out.println("PASS: " + checks + " app bridge/queue checks (native=" + haveNative + ")");
  }
}
