#!/usr/bin/sh
# حارسُ اللقطةِ — مُستَقلٌّ ليُجرى قبلَ أيِّ بناءٍ لا قبلَ البواباتِ فقط.
# مساحةُ العملِ تُلتَقَطُ باستثناءِ أدلّةٍ اسمُها build (وout/dist/target/…)؛ فدليلُ المصدرِ
# app/src/main/java/com/almlkid/ui/build/ يَفرَغُ عندَ كلِّ استئنافٍ، والبناءُ لا يَنبِهُ لأنَّ
# التخطيطَ يسمي الصنفَ ولا يستدعي ترجمتَهُ — فيخرجُ apk ناقصًا ثمَّ يَنقَبلُ التخطيطُ inflated.
# النُّسخُ محفوظةٌ هنا بأسماءٍ مُفلَّطَةٍ ( __ ← / ) لا يَلمسُها الاستثناءُ، ولا كِتابةَ فوقَ موجودٍ.
cd "$(dirname "$0")/../.." || exit 2
restored=0
for f in qa/attic/*.java; do
  [ -e "$f" ] || continue
  n=$(basename "$f")
  p="app/src/main/java/$(printf '%s' "${n%.java}" | sed 's#__#/#g').java"
  if [ ! -f "$p" ]; then
    mkdir -p "$(dirname "$p")"; cp "$f" "$p"
    echo "أُعيدَ المصدرُ من qa/attic/ (مجلدٌ باسمِ build تستثنيهِ اللقطةُ): $p"
    restored=$((restored+1))
  fi
done
[ $restored -eq 0 ] && echo "لا شيءَ مُستَثْنًى مفقودٌ: كلُّ مصادرِ qa/attic/ في مكانِها."
exit 0
