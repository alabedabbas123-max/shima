package android.util;

/** بديلٌ اختياريٌّ: السِّجلُّ عَلى المُستَوضِفِ صَمتٌ — لَا نُبَلِّغُ عَن شَيءٍ بِه. */
public final class Log {
  private Log() {}

  public static int v(String tag, String msg) { return 0; }

  public static int d(String tag, String msg) { return 0; }

  public static int i(String tag, String msg) { return 0; }

  public static int w(String tag, String msg) { return 0; }

  public static int e(String tag, String msg) { return 0; }

  public static int e(String tag, String msg, Throwable failure) { return 0; }
}
