package android.text;

/** بديلٌ اختياريٌّ للمُستَوضِفِ: لا نَحتاجُ مِنَ النَّصِّ القَابِلِ لِلتَّغلُّغِ إِلَّا {@code replace} وَ{@code toString}. */
public interface Editable extends CharSequence {
  Editable replace(int start, int end, CharSequence text);
}
