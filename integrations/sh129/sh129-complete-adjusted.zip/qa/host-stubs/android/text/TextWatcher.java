package android.text;

/** بديلٌ اختياريٌّ: تُستَعمَلُ {@code afterTextChanged} وَحدَهَا فِي وَجهَةِ المَكتَبَةِ. */
public interface TextWatcher {
  void beforeTextChanged(CharSequence s, int start, int count, int after);

  void onTextChanged(CharSequence s, int start, int before, int count);

  void afterTextChanged(Editable s);
}
