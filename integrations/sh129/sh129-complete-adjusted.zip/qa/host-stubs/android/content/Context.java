package android.content;

/** بديل اختياري — يكفي {@code getApplicationContext()} الذي تستخدمه شيفرتنا. */
public class Context {
  public Context getApplicationContext() {
    return this;
  }

  public java.io.File getFilesDir() {
    return new java.io.File(System.getProperty("java.io.tmpdir"), "shima-qa-files");
  }

  public java.io.File getNoBackupFilesDir() {
    return new java.io.File(System.getProperty("java.io.tmpdir"), "shima-qa-nobackup");
  }

  public SharedPreferences getSharedPreferences(String name, int mode) {
    return null;
  }
}
