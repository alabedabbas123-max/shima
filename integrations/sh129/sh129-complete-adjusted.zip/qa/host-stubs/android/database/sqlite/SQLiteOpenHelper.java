package android.database.sqlite;

/**
 * Regression stub: only the public member names of the real class matter — the semantic checker
 * reads them by reflection through {@code almlk.PlatformMemberLookup}.
 */
public abstract class SQLiteOpenHelper {
  public SQLiteOpenHelper() {}

  public String getDatabaseName() { return null; }

  public void setWriteAheadLoggingEnabled(boolean enabled) {}

  public void setLookasideConfig(int slotSize, int slotCount) {}

  public void setOpenParams(Object openParams) {}

  public void setIdleConnectionTimeout(long idleConnectionTimeoutMs) {}

  public Object getWritableDatabase() { return null; }

  public Object getReadableDatabase() { return null; }

  public synchronized void close() {}

  public void onConfigure(Object db) {}

  public abstract void onCreate(Object db);

  public abstract void onUpgrade(Object db, int oldVersion, int newVersion);

  public void onDowngrade(Object db, int oldVersion, int newVersion) {}

  public void onOpen(Object db) {}
}
