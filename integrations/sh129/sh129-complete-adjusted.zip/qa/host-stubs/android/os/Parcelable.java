package android.os;

/**
 * بديلٌ مِضيفيٌّ لواجهةِ {@code android.os.Parcelable} (تحتَ {@code qa/host-stubs/} خارجَ جذورِ مصادرِ
 * المشروعِ عمدًا): الغرضُ وحدَهُ أن تُختَبَرَ سياسةُ القناةِ في {@code almlk.AnalyzerProtocol} — فهي
 * تُميِّزُ {@code Parcelable} من غيرِهِ بالاسمِ لا بالنوعِ، ولا يُثبَتُ التمييزُ على المضيفِ بلا هذه
 * الواجهةِ. لا يُفهرَسُ شيئٌ منهُ على الجهازِ: ملفٌّ باسمِ {@code android.os.Parcelable} لا يجوزُ أن
 * يكونَ تعريفَ ذلكَ النوعِ، والتوقيعُ هنا أخفُّ مما في ‏android.jar لأنَّ {@code writeToParcel} لا يُستدعَى.
 */
public interface Parcelable {

  void writeToParcel(Object dest, int flags);

  int describeContents();
}
