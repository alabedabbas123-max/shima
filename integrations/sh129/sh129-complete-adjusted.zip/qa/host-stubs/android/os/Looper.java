package android.os;

/**
 * بديلٌ اختياريٌّ لِلقَرنِ الرَّئيسِيِّ. خَيطُ المُستَوضِفِ وَاحدٌ، فَهُوَ قَرۡنٌ رَئيسِيٌّ
 * أَبَدًا — بِذلِكَ تَعَبُرُ «شَرطُ صَفحَةِ الوَاجِهَةِ» عِندَ المَكتَبَةِ وَلَا تُرفَضُ
 * طَلَبةٌ فِي الاختِبَارِ لِغَيرِ سَبَبٍ.
 */
public final class Looper {
  private static final Looper MAIN = new Looper();

  private Looper() {}

  public static Looper getMainLooper() {
    return MAIN;
  }

  public static Looper myLooper() {
    return MAIN;
  }
}
