package android.os;

/** بديلٌ اختياريٌّ: {@code SDK_INT} رَقَمٌ ثَابِتٌ — قَدۡ يُقَيَّدُ بِهِ مُستَوَى التَّرجَمَةِ (‏ج٤٩). */
public final class Build {
  private Build() {}

  public static final class VERSION {
    public static final int SDK_INT = 34;

    private VERSION() {}
  }

  public static final class VERSION_CODES {
    public static final int Q = 29;

    private VERSION_CODES() {}
  }
}
