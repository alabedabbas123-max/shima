package android.os;

/** بديلٌ اختياريٌّ: زَمَنٌ نَازِلٌ مِن {@code System} — لِئَلَّا يُقارَنَ بِزَمَنِ النَّظَامِ. */
public final class SystemClock {
  private SystemClock() {}

  public static long uptimeMillis() {
    return System.nanoTime() / 1_000_000L;
  }
}
