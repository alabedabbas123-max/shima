package android.widget;

import android.text.Editable;
import android.text.TextWatcher;

/** بديلٌ اختياريٌّ: مَا تَطلُبُهُ {@code EditTextAdapter} مِنَ الحَقلِ — نَصٌّ وَمُراقِبُو تَغَيُّرٍ. */
public class EditText {
  public Editable getText() {
    return null;
  }

  public void addTextChangedListener(TextWatcher watcher) {}

  public void removeTextChangedListener(TextWatcher watcher) {}
}
