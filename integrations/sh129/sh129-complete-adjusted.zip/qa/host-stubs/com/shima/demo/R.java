package com.shima.demo;

/**
 * بدلة {@code R} لاختبارات {@code qa} خارج android.jar: قيم مميّزة لكل مورد حتى يقارَن الاختبار
 * بالهوية (لا بأسماء نصوص). لا تُستعمل في البناء الحقيقي أبدًا — APK يولّد {@code R} الخاص به.
 */
public final class R {
  private R() {}

  public static final class drawable {
    public static final int file_type_java = 1;
    public static final int file_type_xml = 2;
    public static final int file_type_html = 3;
    public static final int file_type_js = 4;
    public static final int file_type_css = 5;
    public static final int file_type_c = 6;
    public static final int file_type_cpp = 7;
    public static final int file_type_h = 8;
    public static final int file_type_zip = 9;
    public static final int file_type_txt = 10;
    public static final int file_type_unknown = 11;
    public static final int project_properties = 12;
    public static final int folder = 13;
    public static final int folder_hidden = 14;
  }

  public static final class layout {
    public static final int errorbrowser = 101;
    public static final int errorbrowser_entry = 102;
    public static final int browser_header = 103;
  }

  public static final class id {
    public static final int errorbrowserErrorList = 201;
    public static final int browserHeaderMenuButton = 202;
  }
}
