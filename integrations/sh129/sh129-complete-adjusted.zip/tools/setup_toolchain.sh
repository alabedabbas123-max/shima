#!/usr/bin/env bash
# يُعيد تركيب أداة البناء في ~/.cache (خارج لقطةِ العملِ عمدًا): جdk17 + android-SDK + gradle عبر الغلاف.
set -uo pipefail
CACHE=/home/user/.cache; mkdir -p "$CACHE"
log(){ echo "[setup] $*"; }

if [ ! -x "$CACHE/jdk21/bin/javac" ] && [ ! -x "$CACHE/jdk17/bin/javac" ]; then
  log "تنزيل JDK 17 (Temurin) ..."
  mkdir -p "$CACHE/tz"; cd "$CACHE/tz"
  curl -sSL -o jdk.tar.gz "https://api.adoptium.net/v3/binary/latest/17/ga/linux/x64/jdk/hotspot/normal/eclipse" \
    || curl -sSL -o jdk.tar.gz "https://github.com/adoptium/temurin17-binaries/releases/download/jdk-17.0.10%2B7/OpenJDK17U-jdk_x64_linux_hotspot_17.0.10_7.tar.gz"
  tar xzf jdk.tar.gz
  d=$(find "$CACHE/tz" -maxdepth 1 -type d -name 'jdk*' | head -1)
  mv "$d" "$CACHE/jdk17" && log "JDK: $("$CACHE/jdk17/bin/javac" -version 2>&1)"
fi

if [ ! -x "$CACHE/android-sdk/cmdline-tools/latest/bin/sdkmanager" ]; then
  log "تنزيل أدواتِ الأندرويد السطرية ..."
  cd "$CACHE"
  curl -sSL -o cmdline.zip "https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip"
  rm -rf "$CACHE/cmdtmp"; mkdir -p "$CACHE/cmdtmp"; unzip -qo cmdline.zip -d "$CACHE/cmdtmp"
  mkdir -p "$CACHE/android-sdk/cmdline-tools"; rm -rf "$CACHE/android-sdk/cmdline-tools/latest"
  mv "$CACHE/cmdtmp/cmdline-tools" "$CACHE/android-sdk/cmdline-tools/latest"
fi
export JAVA_HOME="$CACHE/jdk17"; export ANDROID_HOME="$CACHE/android-sdk"; export PATH="$JAVA_HOME/bin:$PATH"
log "قبولُ الرخصِ ..."; yes | "$CACHE/android-sdk/cmdline-tools/latest/bin/sdkmanager" --licenses >/dev/null 2>&1
log "تنزيل منصةِ البناءِ ..."
for pkg in "platform-tools" "platforms;android-37" "build-tools;37.0.0"; do
  "$CACHE/android-sdk/cmdline-tools/latest/bin/sdkmanager" "$pkg" >/dev/null 2>&1 \
    && log "✔ $pkg" || log "✘ $pkg (تعذَّر)"
done
ls -d "$CACHE/android-sdk/platforms"/* "$CACHE/android-sdk/build-tools"/* 2>/dev/null
log "التحققُ من غلافِ Gradle ..."
cd /home/user/ShimaProject && ANDROID_HOME="$CACHE/android-sdk" sh gradlew -q --version 2>&1 | head -6
log "اكتملَ الإعدادُ."
