#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""قاعدةُ تسميةِ الإصداراتِ (ج٥٧): ‏1.<mid>.<tail>‏ حيالَ ‏tail‏ من واحدٍ إلى مئةٍ.

السببُ العمليُّ: كانَ الذَّيلُ يَمضي واحِدًا واحِدًا حتَّى بلغَ «‏1.0.206‏»، فصارَ اسمُ
الحِزمَةِ أطوَلَ ممَّا يُحتَمَلُ قِراءَتُهُ، وَ«‏4.4.0‏» فِي المَانيفستِ كانَ يَجعَلُ
البِنۡيَتَيۡنِ مُتَشَابِهَتَيۡنِ عَلى الشَّاشَة. مِن الآنَ:

    ‏1.0.100 ← آخِرُ مَا فِي الوَعَاءِ الأَوَّل
    ‏1.1.1   ← الحَادِيَةُ وَالعِشۡرُونَ بَعدَ المِائَة (لَا «‏1.0.101‏»)
    ‏1.1.100 ← آخِرُ الوَعَاءِ الثَّانِي
    ‏1.2.1   ← حَمۡلٌ آخَر

أيۡ أَنَّ التَّرمِيزَ تَشفِيرٌ بِأَسَاسِ مِائَة لِلذَّيلِ وَاحِدٌ فَما فَوقَ (لا صِفر):

    global = mid * 100 + tail          (tail في 1..100)
    mid    = (global - 1) // 100
    tail   = (global - 1) % 100 + 1

وَرَقۡمُ البِنَاءِ (‏versionCode‏) يَمۡضِي خُطۡوَةً وَاحدَةً كُلَّ جَولَة، وَالأَزۡحَاحَةُ
بَيۡنَهُمَا ثَابِتَةٌ: ‏global = versionCode + OFFSET‏. فَالبَوَّابَةُ تَستَطِيعُ أَنۡ
تَقۡرَأَ كِلَا الرَّقَمَيۡنِ مِن المِلۡفِ نَفۡسِهِ وَلَا تُصَدِّقَ كَلِمَةً مَكتُوبَة.

الأسۡلُوبُ (‏--check‏) هُوَ مَا تَدعُوهُ ‏qa/acceptance.sh‏ بَابَها؛ يُخرِجُ صِفۡرًا
وَسَطۡرًا وَاحِدًا عِندَ الصِّحَّة، وَوَاحِدًا وَسَبَبًا صَرِيحًا عِندَمَا لَا تَكُون.
"""
from __future__ import annotations

import argparse
import os
import re
import sys

MAJOR = 1
BUCKET = 100
# ‏1.0.206 ↔ versionCode 56، أَيۡ 206 = 56 + 150 — ثَابِتُ الانفِصَالِ عَنۡ عَهدِ ج٥٦.
OFFSET = 150
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def encode(global_index: int) -> str:
    """التَّرقِيمُ العَادِيُّ: رَقۡمُ البِنۡيَةِ الجَامِعُ ← سِلۡسِلَةُ الإِصدَار القَانُونِيَّة."""
    if global_index < 1:
        raise ValueError("العَدَدُ الجَامِعُ يَجِبُ أَنۡ يَكُونَ وَاحدًا فَمَا فَوۡق: %d" % global_index)
    mid = (global_index - 1) // BUCKET
    tail = (global_index - 1) % BUCKET + 1
    return "%d.%d.%d" % (MAJOR, mid, tail)


def decode(version: str) -> int:
    """العَكۡسُ، مَعَ رَفۡضٍ صَرِيحٍ لِلغَيۡرِ القَانُونِيّ (كَـ«‏1.0.206‏» القَدِيمَة)."""
    text = (version or "").strip()
    match = re.fullmatch(r"(\d+)\.(\d+)\.(\d+)", text)
    if not match:
        raise ValueError("لَيۡسَ «‏major.mid.tail‏»: %r" % text)
    major, mid, tail = (int(x) for x in match.groups())
    if major != MAJOR:
        raise ValueError("الكَبيرُ يَجِبُ أَنۡ يَبقَىٰ %d (الإِصدَارُ نَشرٌ لَا مَذهَبٌ): %s" % (MAJOR, text))
    if mid < 0:
        raise ValueError("الأَوسطُ سَلۡبِيٌّ: %s" % text)
    if not 1 <= tail <= BUCKET:
        raise ValueError(
            "الذَّيلُ %d خَارِجَ 1..%d — فَالحَمۡلُ وَاجِبٌ: %s ← %s"
            % (tail, BUCKET, text, encode(mid * BUCKET + tail))
        )
    return mid * BUCKET + tail


def read_text(path: str) -> str:
    with open(os.path.join(ROOT, path), encoding="utf-8") as handle:
        return handle.read()


def current() -> tuple[str, int]:
    version = read_text("VERSION").strip()
    gradle = read_text("app/build.gradle")
    match = re.search(r"^\s*versionCode\s+(\d+)\s*$", gradle, re.MULTILINE)
    if not match:
        raise ValueError("لَمۡ تُقۡرَأۡ versionCode مِن app/build.gradle")
    return version, int(match.group(1))


def cmd_check(args: argparse.Namespace) -> int:
    try:
        version, code = current()
        global_index = decode(version)
    except (OSError, ValueError) as failure:
        print("✘ قَاعِدَةُ التَّسمِيَة: %s" % failure)
        return 1
    problems = []
    if global_index != code + OFFSET:
        problems.append(
            "العَلَاقَةُ مَقۡطُوعَة: %s ↔ %d؛ مُنتَظَرٌ %s لِهذَا الرَّقَمِ أَوۡ versionCode=%d"
            % (version, code, encode(code + OFFSET), global_index - OFFSET)
        )
    if version != encode(global_index):
        problems.append("غَيۡرُ قَانُونِيّ: اُكۡتُبۡ %s عِوَضَ %s" % (encode(global_index), version))
    name = "shima_%s.apk" % version.replace(".", "_")
    if problems:
        print("✘ قَاعِدَةُ التَّسمِيَة: " + "؛ ".join(problems))
        return 1
    print("✔ %s ← بِنۡيَةٌ %d، وَالذَّيلُ %d مِن %d، وَالۡمُخرَجُ %s"
          % (version, code, decode(version) % BUCKET or BUCKET, BUCKET, name))
    return 0


def cmd_next(args: argparse.Namespace) -> int:
    version, code = current()
    nxt = code + 1
    print("%s %d" % (encode(nxt + OFFSET), nxt))
    return 0


def cmd_normalize(args: argparse.Namespace) -> int:
    """يُجَيِّرُ أَيَّ «‏1.mid.tail‏» إِلَى الصِّيغَةِ القَانُونِيَّة (حَمۡلُ المِائَةِ إِلى الأَوسَط)."""
    text = (args.version or "").strip()
    match = re.fullmatch(r"(\d+)\.(\d+)\.(\d+)", text)
    if not match:
        print("✘ لَيۡسَ «‏major.mid.tail‏»: %r" % text)
        return 1
    major, mid, tail = (int(x) for x in match.groups())
    if major != MAJOR:
        print("✘ الكَبيرُ يَجِبُ أَنۡ يَبقَىٰ %d (الإِصدَارُ نَشرٌ لَا مَذهَبٌ): %s" % (MAJOR, text))
        return 1
    if tail < 1:
        print("✘ الذَّيلُ يَبۡدَأُ مِنۡ وَاحدٍ لَا مِنۡ صِفۡرٍ (وَسۡطُ «‏‏1.0.100‏» نِهَائِيٌّ لَا «‏1.0.0‏»): %s" % text)
        return 1
    canonical = encode(mid * BUCKET + tail)
    print(("%s (بِلَا تَغۡيِيرٍ)" % canonical) if canonical == text else "%s ← %s" % (canonical, text))
    return 0


def cmd_encode(args: argparse.Namespace) -> int:
    print(encode(args.global_index))
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    commands = parser.add_mutually_exclusive_group()
    commands.add_argument("--check", action="store_true", help="القِرَاءَةُ مِنَ الشَّجَرَةِ وَالحُكۡم (للبَوَّابَة)")
    commands.add_argument("--next", action="store_true", help="مَا هُوَ الإِصدَارُ وَالبِنۡيَةُ الجَدِيدَانِ؟")
    commands.add_argument("--normalize", dest="version", metavar="VERSION",
                    help="تَطۡبِيقُ الحَمۡلِ عَلى رَقۡمٍ قَدِيمٍ")
    commands.add_argument("--encode", type=int, metavar="GLOBAL", dest="global_index", help="رَقۡمٌ جَامِعٌ ← تَسۡمِيَة")
    args = parser.parse_args(argv)
    if getattr(args, "version", None) is not None:
        return cmd_normalize(args)
    if args.global_index is not None:
        return cmd_encode(args)
    if args.next:
        return cmd_next(args)
    return cmd_check(args)


if __name__ == "__main__":
    sys.exit(main())
