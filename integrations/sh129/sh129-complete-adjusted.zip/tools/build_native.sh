#!/usr/bin/sh
# ‏tools/build_native.sh — جِذرُ libshima_analyzer.so لِوَحدَةِ التَّحلِيلِ (ج٤٧، ‏1.0.200).
#
# لِمَاذَا سِكرِiptٌ لَا externalNativeBuild دَاخِلَ الوَحدَةِ؟
#   مُخَرَّجَاتُ CMake لِـ tree-sitter وَparsers الجَاوِيَّةِ وَالكُوتلِنِيَّةِ تَزنُ مِئَاتِ المِغَابَايتَاتِ
#   (شَجَرَةُ Kotlin أَكثَرُ مِن عِشرِينَ مِغَابَايتًا مِن C). لَو وُضِعَت تَحتَ analyzer/.cxx دَاخِلَ
#   المِساحَةِ المُلتَقَطَةِ لَزَحَمَت سَقفَ القُيُودِ وَأَفرَغَت مَحتَوًى آخَرَ — وَهذَا قَد جَرَبنَاهُ:
#   ضَاعَ baseline/ مِن قَبلُ بِسَبَبِ الحَجُمِ لَا بِسَبَبِ الحَذفِ. فَالبِنَاءُ يَخرُجُ إِلَى
#   ‏$CACHE/shima-native/‏ خَارِجَ القَيدِ، وَالمُشَحَّنُ هُنَا هُوَ ثُنَائِيَّ المُكتَبَةِ فَقط، مَعَ
#   صِفْرٍ مِن قُيُودِ الوَسَائِطِ.
#
# يَكتُبُ:
#   app/src/main/jniLibs/<abi>/libshima_analyzer.so        (لِلمُعمَارَيَتَينِ المُستَهدَفَتَينِ)
#   app/src/main/jniLibs/ANALYZER_NATIVE.sha256            (بِصمَةُ المَصَادِرِ + البِنَارَاتِ: حَرَسُ الانحرَافِ)
#   $CACHE/shima-native/host/libshima_analyzer.so          (لِلبَوَّابَةِ عَلى المُستَضِيفِ: JNI حَقِيقِيٌّ)
#
# الاستخدام:
#   export JAVA_HOME=… ANDROID_HOME=…            # JDK ‏17‏ وَ ‏ndk;25.1.8937393‏ وَ ‏cmake;3.22.1‏
#   sh tools/build_native.sh            # الأَجمَلُ: جِذرَانِ + مُستَضِيفٌ
#   sh tools/build_native.sh host       # المُستَضِيفُ فَقط (لِلبَوَّابَةِ)
set -e
cd "$(dirname "$0")/.." || exit 2
ROOT="$PWD"
CACHE="${NATIVE_CACHE:-/home/user/.cache}"
OUT="$CACHE/shima-native"
NDK="${ANDROID_NDK_HOME:-$ANDROID_HOME/ndk/25.1.8937393}"
CMAKE="${CMAKE:-$ANDROID_HOME/cmake/3.22.1/bin/cmake}"
TARBALL="$ROOT/third_party/parsers-0.25.0-java-0.23.5-kotlin-1.1.0.tar.gz"
CPP="$ROOT/analyzer/src/main/cpp"
ABIS="${ANALYZER_ABIS:-arm64-v8a x86_64}"
[ -f "$TARBALL" ] || { echo "نَاقِصٌ: $TARBALL (حُزمَةُ parsers المُثَبَّتَةُ)" >&2; exit 3; }
[ -f "$CPP/native_bridge.c" ] || { echo "نَاقِصٌ: $CPP/native_bridge.c" >&2; exit 3; }

build_one() { # $1 = dest dir, rest = extra cmake args
  dest="$1"; shift
  mkdir -p "$dest"
  "$CMAKE" -S "$CPP" -B "$dest" -DCMAKE_BUILD_TYPE=Release "$@" > "$dest/cmake.log" 2>&1 \
    || { echo "فَشِلَ cmake فِي $dest:"; tail -20 "$dest/cmake.log"; exit 4; }
  "$CMAKE" --build "$dest" --parallel 2 >> "$dest/cmake.log" 2>&1 \
    || { echo "فَشِلَت تَرجَمَةُ C فِي $dest:"; tail -25 "$dest/cmake.log"; exit 5; }
  [ -f "$dest/libshima_analyzer.so" ] || { echo "لَم يَخرُجِ الجِذرُ فِي $dest" >&2; exit 6; }
}

WANT_HOST=1; WANT_ANDROID=1
case "${1:-all}" in host) WANT_ANDROID=0 ;; android) WANT_HOST=0 ;; esac

if [ "$WANT_ANDROID" = 1 ]; then
  [ -d "$NDK" ] || { echo "لا NDK عِندَ $NDK — شغِّلْ tools/setup_ndk.sh" >&2; exit 7; }
  [ -x "$CMAKE" ] || { echo "لا cmake عِندَ $CMAKE" >&2; exit 7; }
  for abi in $ABIS; do
    echo "── جِذرُ $abi ──"
    build_one "$OUT/$abi" \
      -DCMAKE_TOOLCHAIN_FILE="$NDK/build/cmake/android.toolchain.cmake" \
      -DANDROID_ABI="$abi" -DANDROID_PLATFORM=android-21 -DANDROID_STL=none
    mkdir -p "$ROOT/app/src/main/jniLibs/$abi"
    cp "$OUT/$abi/libshima_analyzer.so" "$ROOT/app/src/main/jniLibs/$abi/libshima_analyzer.so"
  done
fi

if [ "$WANT_HOST" = 1 ]; then
  echo "── جِذرُ المُستَضِيفِ (للبوابةِ الحَقِيقِيَّةِ عَلى جَاوَا) ──"
  build_one "$OUT/host" "-DCMAKE_C_FLAGS=-I$JAVA_HOME/include -I$JAVA_HOME/include/linux -O1"
fi

# ‏— حَرَسُ الانحرَافِ: بِصمَةُ مَا يُبنى مِنهُ الجِذرُ، لِأنَّ المُشَحَّنَ بِنَارِيٌّ.
MANIFEST="$ROOT/app/src/main/jniLibs/ANALYZER_NATIVE.sha256"
{
  printf '# مَنشُورُ بِصمَةِ جِذرِ التَّحلِيلِ — يُعيدُ tools/build_native.sh كِتَابَتَهُ. \n'
  printf '# إِنْ تَغَيَّرَ سَطْرٌ هُنَا وَلَم تُعَدِ البِنَارَاتُ فَبَابُ القَبولِ يَحمَرُّ (لَا جِذرٌ قَديمٌ مَعَ نَحْوٍ جَدِيدٍ).\n'
  ( cd "$ROOT" && sha256sum "$TARBALL" | sed "s#$TARBALL#third_party/$(basename "$TARBALL")#" )
  ( cd "$ROOT" && sha256sum analyzer/src/main/cpp/native_bridge.c analyzer/src/main/cpp/CMakeLists.txt )
  for abi in $ABIS; do
    f="$ROOT/app/src/main/jniLibs/$abi/libshima_analyzer.so"
    [ -f "$f" ] && ( cd "$ROOT" && sha256sum "app/src/main/jniLibs/$abi/libshima_analyzer.so" )
  done
} > "$MANIFEST"
echo "── المَنشُورُ ──"; cat "$MANIFEST"
ls -la "$ROOT"/app/src/main/jniLibs/*/libshima_analyzer.so 2>/dev/null || true
echo "BUILD_NATIVE_DONE"
