#!/usr/bin/sh
# ‏tools/setup_ndk.sh — عِدَّةُ بِنَاءِ جِذرِ وَحدَةِ التَّحلِيلِ (JNI + CMake).
# تُشغَّلُ بَعدَ tools/setup_toolchain.sh وَ tools/setup_platform37.sh (وَهي تَعمَلُ خَارِجَ
# المِساحَةِ المُلتَقَطَةِ عِندَ ‏~/.cache‏، فَلا تَأكُلُ سَقفَ القُيُودِ). إِذَا مَسَحَ الصُّندوقُ
# الرَّمْلِيُّ ‏~/.cache‏ بَينَ جَلسَتَينِ فَاِستَأنِفْ بِالثَّلَاثَةِ جَمِيعًا: نَحوُ عَشرِ دَقَائِقَ.
#   NDK ‏25.1.8937393‏ هُوَ المُثَبَّتُ فِي وَثَائِقِ المَكتَبَةِ؛ وَCMake ‏3.22.1‏ هُوَ الأَدنَى
#   فِيمَا يَقبَلُهُ ‏analyzer/src/main/cpp/CMakeLists.txt.
set -e
CACHE="${TOOLCHAIN_CACHE:-/home/user/.cache}"
export JAVA_HOME="$CACHE/jdk17"
export ANDROID_HOME="$CACHE/android-sdk"
SDKM="$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager"
[ -x "$SDKM" ] || { echo "أَكمِلْ tools/setup_toolchain.sh أَوَّلًا (لا sdkmanager)" >&2; exit 2; }
yes | "$SDKM" --licenses > /dev/null 2>&1 || true
"$SDKM" "ndk;25.1.8937393" "cmake;3.22.1"
du -sh "$ANDROID_HOME/ndk" "$ANDROID_HOME/cmake"
echo "SETUP_NDK_DONE"
