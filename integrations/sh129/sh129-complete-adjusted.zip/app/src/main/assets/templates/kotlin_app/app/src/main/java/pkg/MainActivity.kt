package $package_name$

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

/** نقطةُ البدايةِ بـKotlin — تُبنى بـ`kotlin-android`، ولا يلوّنُها محرِّرُ Javac. */
class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        findViewById<TextView>(R.id.message)?.text = getString(R.string.hello_world)
    }
}
