package $package_name$;

public class Main {

    public static void main(String[] args) {
        System.out.println("مرحبًا من $project_name$!");
    }
}
