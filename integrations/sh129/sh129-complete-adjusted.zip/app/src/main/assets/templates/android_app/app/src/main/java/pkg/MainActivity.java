package $package_name$;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

/** نقطةُ البدايةِ — قالبُ «$project_name$». */
public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextView message = (TextView) findViewById(R.id.message);
        if (message != null) message.setText(getString(R.string.hello_world));
    }
}
