package $package_name$;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

/** يستدعي الكودَ الأصليَّ: `native-lib` مبنيٌّ بـCMake من `src/main/cpp`. */
public class MainActivity extends Activity {

    static {
        System.loadLibrary("native-lib");
    }

    public native String stringFromJNI();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextView message = (TextView) findViewById(R.id.message);
        if (message != null) message.setText(stringFromJNI());
    }
}
