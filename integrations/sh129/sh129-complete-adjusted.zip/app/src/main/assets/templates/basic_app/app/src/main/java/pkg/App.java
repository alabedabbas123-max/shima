package $package_name$;

import android.app.Application;
import android.os.Build;
import android.util.Log;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;

/**
 * تطبيقٌ يرصدُ السقوطَ: كلُّ استثناءٍ غيرِ معالَجٍ يُكتَبُ في `getExternalFilesDir(null)` أو
 * مجلدِ التخزينِ الداخليِّ، ويُرفَقُ بسطرِ الإصدارِ — ليعرفَ المطوِّرُ سببَ السقوطِ بلا adb.
 */
public class App extends Application {

    private static final String TAG = "$package_name$";

    @Override
    public void onCreate() {
        super.onCreate();
        installCrashReporter();
    }

    private void installCrashReporter() {
        final Thread.UncaughtExceptionHandler previous = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler(
                new Thread.UncaughtExceptionHandler() {
                    @Override
                    public void uncaughtException(Thread thread, Throwable error) {
                        try {
                            File dir = getExternalFilesDir(null);
                            if (dir == null) dir = getFilesDir();
                            if (!dir.isDirectory() && !dir.mkdirs()) return;
                            File log = new File(dir, "crash-" + System.currentTimeMillis() + ".txt");
                            PrintWriter out = new PrintWriter(new FileWriter(log));
                            out.println("device: " + Build.MANUFACTURER + " " + Build.MODEL + " api " + Build.VERSION.SDK_INT);
                            out.println("thread: " + thread.getName());
                            error.printStackTrace(out);
                            out.close();
                            Log.e(TAG, "crash written to " + log.getAbsolutePath(), error);
                        } catch (Throwable ignored) {
                        } finally {
                            if (previous != null) previous.uncaughtException(thread, error);
                        }
                    }
                });
    }
}
