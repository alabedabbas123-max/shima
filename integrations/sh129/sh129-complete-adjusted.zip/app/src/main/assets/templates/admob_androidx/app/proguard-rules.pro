# قواعدُ حمايةٍ لهذا المشروعِ — تُقرأُ عندَ تفعيلِ minifyEnabled في build.gradle.
# لا تخفِ ما يحتاجُهُ الانعكاسُ: طبقةُ التطبيقِ وحدَها، والأدواتُ تُبقي ما تستدعيهِ.
-dontwarn java.lang.invoke.StringConcatFactory
-keep class $package_name$.** { *; }
