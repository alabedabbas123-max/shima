package net.margaritov.preference.colorpicker;

/** محلل Hex صارم مستقل عن Android لحقل منتقي اللون: RGB6 أو ARGB8 فقط، مع # اختيارية. */
public final class HexColorCodec {
  private HexColorCodec() {}

  /**
   * يحول RRGGBB إلى لون معتم، أو AARRGGBB حين تكون الألفا مسموحة.
   *
   * @throws IllegalArgumentException عند الطول أو الخانة غير الصالحة.
   */
  public static int parse(CharSequence value, boolean alphaAllowed) {
    if (value == null) throw new IllegalArgumentException("HEX فارغ");
    int length = value.length();
    int offset = length > 0 && value.charAt(0) == '#' ? 1 : 0;
    int digits = length - offset;
    if (digits != 6 && !(alphaAllowed && digits == 8))
      throw new IllegalArgumentException("يلزم 6 خانات RGB أو 8 خانات ARGB");

    long packed = 0;
    for (int i = offset; i < length; i++) {
      int nibble = hex(value.charAt(i));
      if (nibble < 0) throw new IllegalArgumentException("خانة HEX غير صالحة");
      packed = (packed << 4) | nibble;
    }
    return digits == 6 ? (int) (0xFF000000L | packed) : (int) packed;
  }

  public static boolean isValid(CharSequence value, boolean alphaAllowed) {
    try {
      parse(value, alphaAllowed);
      return true;
    } catch (IllegalArgumentException invalid) {
      return false;
    }
  }

  private static int hex(char value) {
    if (value >= '0' && value <= '9') return value - '0';
    if (value >= 'a' && value <= 'f') return value - 'a' + 10;
    if (value >= 'A' && value <= 'F') return value - 'A' + 10;
    return -1;
  }
}
