package com.shima.demo;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.text.method.LinkMovementMethod;
import android.util.TypedValue;
import android.view.MenuItem;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** شاشة About — معلومات قانونية وعن الإصدار (رأس تبويب Settings). */
public class AboutActivity extends LocaleAwareActivity {
  @Override
  protected void onCreate(Bundle state) {
    super.onCreate(state);
    setTitle(R.string.preference_title_legal);
    if (getActionBar() != null) getActionBar().setDisplayHomeAsUpEnabled(true);

    TextView body = new TextView(this);
    body.setTextColor(almlk.ChromeTheme.primaryText(this));
    body.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
    body.setLineSpacing(8, 1f);
    body.setPadding(48, 40, 48, 40);
    body.setMovementMethod(LinkMovementMethod.getInstance());
    body.setText(buildText());

    ScrollView scroll = new ScrollView(this);
    scroll.setBackgroundColor(almlk.ChromeTheme.appBackground(this));
    scroll.addView(
        body,
        new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
    setContentView(scroll);
  }

  private String buildText() {
    String version = "";
    try {
      version = getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
    } catch (Exception ignored) {
      // بلا معلومات إصدار
    }
    return getString(R.string.app_name)
        + (version == null ? "" : " — " + version)
        + "\n\n"
        + getString(R.string.ui_about_message);
  }

  @Override
  public boolean onOptionsItemSelected(MenuItem item) {
    if (item.getItemId() == android.R.id.home) {
      finish();
      return true;
    }
    return super.onOptionsItemSelected(item);
  }
}
