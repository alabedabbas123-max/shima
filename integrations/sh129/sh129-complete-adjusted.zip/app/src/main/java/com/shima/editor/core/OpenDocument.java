package com.shima.editor.core;

import java.nio.charset.Charset;

/** Metadata and buffer for an open tab. Content is owned by the PieceTableDocument. */
public final class OpenDocument {
  public final String path;
  public final String documentId;
  public final PieceTableDocument document;
  public final EditorPosition position = new EditorPosition();
  public Charset encoding;
  public LineEnding lineEnding;
  public boolean dirty;
  public boolean readOnly;

  public OpenDocument(
      String path,
      String documentId,
      CharSequence text,
      boolean readOnly,
      Charset encoding,
      LineEnding lineEnding) {
    this.path = path == null ? "" : path;
    this.documentId = documentId == null ? this.path : documentId;
    this.readOnly = readOnly;
    this.encoding = encoding;
    this.lineEnding = lineEnding == null ? LineEnding.LF : lineEnding;
    this.document = new PieceTableDocument(this.documentId, text, readOnly);
  }

  public enum LineEnding {
    LF("\n"),
    CRLF("\r\n");

    public final String value;

    LineEnding(String value) {
      this.value = value;
    }
  }
}
