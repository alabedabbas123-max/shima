package com.shima.editor.core;

import java.util.ArrayList;

/** Incrementally maintained line-start index. Offsets are UTF-16 offsets, matching Android text APIs. */
public final class LineIndex {
  private final ArrayList<Long> starts = new ArrayList<>();

  public LineIndex(CharSequence initial) {
    reset(initial);
  }

  public synchronized void reset(CharSequence text) {
    starts.clear();
    starts.add(0L);
    if (text == null) return;
    for (int i = 0; i < text.length(); i++) {
      if (text.charAt(i) == '\n') starts.add((long) i + 1L);
    }
  }

  /** Updates only line starts touched by a replacement and shifts the unchanged suffix. */
  public synchronized void replace(long start, long removedLength, CharSequence inserted) {
    int safeStart = (int) Math.max(0L, Math.min(start, Integer.MAX_VALUE));
    int safeRemoved = (int) Math.max(0L, Math.min(removedLength, Integer.MAX_VALUE));
    long oldEnd = (long) safeStart + safeRemoved;
    int first = upperBound(safeStart);
    // The line beginning exactly at oldEnd is the first untouched suffix line; retain it and shift it.
    int last = lowerBound(oldEnd);
    if (last > first) starts.subList(first, last).clear();

    long insertedLength = inserted == null ? 0L : inserted.length();
    long delta = insertedLength - safeRemoved;
    for (int i = first; i < starts.size(); i++) starts.set(i, starts.get(i) + delta);

    if (inserted != null && inserted.length() > 0) {
      ArrayList<Long> newStarts = new ArrayList<>();
      for (int i = 0; i < inserted.length(); i++) {
        if (inserted.charAt(i) == '\n') newStarts.add((long) safeStart + i + 1L);
      }
      if (!newStarts.isEmpty()) starts.addAll(first, newStarts);
    }
    if (starts.isEmpty() || starts.get(0) != 0L) starts.add(0, 0L);
  }

  public synchronized int lineCount() {
    return starts.size();
  }

  public synchronized int lineOf(long offset) {
    long safe = Math.max(0L, offset);
    int low = 0, high = starts.size() - 1;
    while (low <= high) {
      int middle = (low + high) >>> 1;
      if (starts.get(middle) <= safe) low = middle + 1;
      else high = middle - 1;
    }
    return Math.max(0, high);
  }

  public synchronized long offsetOfLine(int line) {
    if (line <= 0) return 0L;
    if (line >= starts.size()) return starts.get(starts.size() - 1);
    return starts.get(line);
  }

  public synchronized long lineStart(int line) {
    return offsetOfLine(line);
  }

  public synchronized long lineEnd(int line, long documentLength) {
    if (line < 0) return 0L;
    if (line + 1 < starts.size()) return Math.max(starts.get(line), starts.get(line + 1) - 1L);
    return Math.max(starts.get(Math.min(line, starts.size() - 1)), documentLength);
  }

  public synchronized long[] snapshot() {
    long[] result = new long[starts.size()];
    for (int i = 0; i < starts.size(); i++) result[i] = starts.get(i);
    return result;
  }

  private int lowerBound(long value) {
    int low = 0, high = starts.size();
    while (low < high) {
      int middle = (low + high) >>> 1;
      if (starts.get(middle) < value) low = middle + 1;
      else high = middle;
    }
    return low;
  }

  private int upperBound(long value) {
    int low = 0, high = starts.size();
    while (low < high) {
      int middle = (low + high) >>> 1;
      if (starts.get(middle) <= value) low = middle + 1;
      else high = middle;
    }
    return low;
  }
}
