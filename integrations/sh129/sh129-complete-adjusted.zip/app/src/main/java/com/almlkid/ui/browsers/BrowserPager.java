package com.almlkid.ui.browsers;

import android.app.AlertDialog;
import android.content.*;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Environment;
import android.provider.DocumentsContract;
import androidx.documentfile.provider.DocumentFile;
import android.util.AttributeSet;
import android.view.*;
import android.webkit.MimeTypeMap;
import android.widget.*;
import com.almlkid.kay.ui.BuildDiagnosticsParser;
import com.almlkid.kay.ui.CodeLanguageTools;
import com.almlkid.kay.ui.ProjectDiagnostic;
import com.almlkid.kay.ui.ProjectSearchEngine;
import com.almlkid.kay.ui.ProjectSymbolIndex;
import com.almlkid.kay.ui.UsageSearchEngine;
import com.shima.demo.R;
import com.shima.demo.UiStrings;
import com.shima.performance.EncodingManager;
import com.shima.performance.PersistentSymbolIndexStore;
import com.shima.performance.ProjectDiagnosticsSnapshot;
import com.shima.editor.core.DexMetadataReader;
import com.shima.demo.ThemeConfig;
import java.io.*;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/** Complete project browser. SAF is the primary backend; java.io.File is a fallback. */
public class BrowserPager extends LinearLayout {
  private static final int MAX_PROJECT_DIAGNOSTICS = 5000;
  private static final int MAX_PROJECT_DIAGNOSTIC_FILES = 10000;

  public interface Listener {
    void selected(String name, String content);
  }

  /**
   * تقرير فتح الملفات — «فتح فوري»: يُطلق لحظة نقرة الملف (قبل قراءة المحتوى)
   * ليعرض التبويب فورًا. Default فارغ حتى تبقى بقية الحالات اختيارية.
   */
  public interface FileOpeningCallback {
    void onFileOpening(String name);
  }

  /** حاوية قابلة للإلغاء تخزّن المؤشر، وتتسامح مع عدم الربط. */
  private static final class OpeningCallbackHolder {
    FileOpeningCallback callback;

    void notifyOpening(String name) {
      if (callback != null) callback.onFileOpening(name);
    }
  }

  public interface MutationListener {
    void completed(boolean success, String fileName, String content, String message);
  }

  public interface SaveListener {
    void completed(boolean success, String message);
  }

  public interface DefinitionOpenListener {
    void completed(boolean success, String fileName, String content, int offset, String message);
  }

  public interface ProjectDiagnosticsListener {
    void completed(List<ProjectDiagnostic> diagnostics);

    /**
     * R6: a partial picture while the scan runs (or the saved one when the project opens) —
     * files not scanned yet keep their last known findings. {@link #completed} still follows.
     */
    default void progress(List<ProjectDiagnostic> diagnostics) {}
  }

  public interface UsageListener {
    /** يُستدعى بدفعات تدريجية؛ done=true عند آخر دفعة — مضمونة الوصول دائمًا. */
    void completed(List<UsageSearchEngine.Usage> usages, boolean done);
  }

  public interface ProjectSearchListener {
    void completed(List<UsageSearchEngine.Usage> results, int filesScanned, boolean cancelled);
  }

  public interface DefinitionSearchListener {
    void completed(ProjectSymbolIndex.DefinitionTarget target);
  }

  public interface SymbolSearchListener {
    void completed(List<ProjectSymbolIndex.DefinitionTarget> results, boolean cancelled);
  }

  public interface ActionListener {
    void onCreateProject();

    void onCloneGit();

    void onStoragePermissionRequested();

    void onProjectOpened(String name, String path);

    void onSelectProjectFolder();

    /** كُتب ملف بناء (اعتماد/JAR) — يعيد المضيف دورة الاعتمادات بصمت. */
    default void onBuildFilesChanged(File buildFile) {}
  }

  private static final int ACTION_CREATE_PROJECT = 1,
      ACTION_CLONE = 2,
      ACTION_PERMISSION = 3,
      ACTION_UP_DOCUMENT = 4,
      ACTION_SELECT_TREE = 5,
      ACTION_EMPTY = 6,
      ACTION_UP_FILE = 7,
      ACTION_NEW_CLASS = 8,
      ACTION_NEW_XML = 9,
      ACTION_OPEN_PROJECT = 10,
      ACTION_PROJECT_PROPERTIES = 11,
      ACTION_ADD_TO_PROJECT = 12,
      ACTION_UP_TO_FILES = 13;

  // ===== بنية المرجع: شارات المجلدات ومصغرات الملفات (خيط خلفي + كاش + حارس tag) =====
  private final ExecutorService iconLoader = Executors.newSingleThreadExecutor();
  private final Map<String, Object> folderBadgeCache = new java.util.concurrent.ConcurrentHashMap<>();
  private final Map<String, Object> fileIconCache = new java.util.concurrent.ConcurrentHashMap<>();
  private static final Object NO_BADGE = new Object();

  // ذاكرة موضع التمرير لكل مجلد (بنية المرجع) — LRU محدودة حتى لا تنمو بلا سقف.
  private final LinkedHashMap<String, Integer> scrollPositions =
      new LinkedHashMap<String, Integer>(16, 0.75f, true) {
        @Override
        protected boolean removeEldestEntry(Map.Entry<String, Integer> eldest) {
          return size() > 64;
        }
      };
  private String displayedLocationKey;
  private Listener listener;
  private final OpeningCallbackHolder openingCallback = new OpeningCallbackHolder();
  private ActionListener actions;
  private TextView pathLabel;
  private View header;
  private ListView list;
  private final ArrayList<Entry> entries = new ArrayList<>();
  /** تقرير AIDE — ThemeConfig واحد مخزّن بدل إنشائه لكل صف في القائمة. */
  private ThemeConfig cachedEntryTheme;
  private final Map<String, Entry> openedEntries = Collections.synchronizedMap(new HashMap<>());
  private ExecutorService fileReader = Executors.newSingleThreadExecutor();
  private ExecutorService directoryReader = Executors.newFixedThreadPool(2);
  private ExecutorService symbolWorker = Executors.newSingleThreadExecutor();
  private ExecutorService projectDiagnosticsWorker = Executors.newSingleThreadExecutor();
  /** R6: reads the saved diagnostics of a reopened project while the index is being built. */
  private ExecutorService diagnosticsSnapshotWorker = Executors.newSingleThreadExecutor();
  private ProjectDiagnosticsSnapshot diagnosticsSnapshot;
  /** Last complete (or restored) project findings and the project they belong to. */
  private volatile List<ProjectDiagnostic> lastProjectDiagnostics = Collections.emptyList();
  private volatile String lastProjectDiagnosticsKey = "";
  /** Project whose live scan already published: a late snapshot must not cover fresher results. */
  private volatile String scanPublishedKey = "";
  /** طلبُ مسحٍ مؤجَّلٌ إلى ما بعدَ الفهرسةِ (الجولةُ ٣٨): قَفزةٌ واحدةٌ لكلِّ فهرسةٍ. */
  private volatile boolean diagnosticsScanQueued;
  /** File checked first (the active editor tab). */
  private volatile String diagnosticsPriorityReference = "";
  /** W20′2: compileSdk آخرِ مسحٍ كاملٍ — يعيدُ الفحصُ الموضعيُّ ضبطَهُ فلا ينعقدَ حكمُ «عضوٍ مفقودٍ». */
  private volatile int diagnosticsCompileSdk;
  private static final long PROGRESS_INTERVAL_MS = 250;
  // Searches have their own short-lived lane so the first project index build never blocks typing.
  private ExecutorService symbolSearchWorker = Executors.newFixedThreadPool(2);
  private final HashMap<String, Entry> symbolFiles = new HashMap<>();
  private PersistentSymbolIndexStore symbolIndexStore;
  private String indexedProjectKey = "";
  private final Object activeSymbolLock = new Object();
  private String activeSymbolFile = "", activeSymbolReference = "", activeSymbolSource = "";
  private int activeSymbolLength, activeSymbolHash;
  private boolean activeSymbolsReady;
  private List<ProjectSymbolIndex.DefinitionTarget> activeSymbols = Collections.emptyList();
  // Metadata-only workspace catalog. Contents stay lazy and are loaded only when a search/open
  // request needs them, following AndroidIDE's separate file/index and document-content model.
  private final LinkedHashMap<String, Entry> searchFileCatalog = new LinkedHashMap<>();
  private volatile boolean searchCatalogReady;
  private final android.os.Handler mainHandler =
      new android.os.Handler(android.os.Looper.getMainLooper());
  private final LinkedHashMap<String, List<Entry>> directoryCache =
      new LinkedHashMap<String, List<Entry>>(64, 0.75f, true) {
        @Override
        protected boolean removeEldestEntry(Map.Entry<String, List<BrowserPager.Entry>> eldest) {
          return size() > 40;
        }
      };
  private final HashSet<String> prefetching = new HashSet<>();
  private final com.shima.performance.FileContentCache fileContentCache =
      new com.shima.performance.FileContentCache(24 * 1024 * 1024);
  private int openGeneration, navigationGeneration;
  private Future<?> openTask, projectSearchTask, symbolSearchTask;
  private int projectSearchGeneration;
  private Uri pendingProjectDetection, projectDocumentUri;
  private File currentFile, projectFile;
  private DocumentFile documentRoot, currentDocument;
  private final ArrayDeque<DocumentFile> documentParents = new ArrayDeque<>();
  private boolean usingDocuments;

  private static class Entry {
    String name;
    File file;
    DocumentFile document;
    Uri documentUri;
    long size;
    long modified;
    boolean folder;
    int icon, action, depth;

    Entry(String n, File f, DocumentFile d, boolean dir, int i, int a) {
      this(n, f, d, dir, i, a, 0);
    }

    Entry(String n, File f, DocumentFile d, boolean dir, int i, int a, int level) {
      name = n;
      file = f;
      document = d;
      documentUri = d == null ? null : d.getUri();
      folder = dir;
      icon = i;
      action = a;
      depth = level;
      size = f == null ? -1 : f.isFile() ? f.length() : -1;
      modified = f == null ? 0 : f.lastModified();
    }

    Entry(String n, Uri uri, boolean dir, long length, int drawable) {
      this(n, uri, dir, length, 0, drawable);
    }

    Entry(String n, Uri uri, boolean dir, long length, long lastModified, int drawable) {
      name = n;
      documentUri = uri;
      folder = dir;
      size = length;
      modified = lastModified;
      icon = drawable;
    }
  }

  private String ui(String key) {
    return UiStrings.get(getContext(), key);
  }

  private String uiFormat(String key, Object... values) {
    return UiStrings.format(getContext(), key, values);
  }

  public BrowserPager(Context c) {
    super(c);
    init();
  }

  public BrowserPager(Context c, AttributeSet a) {
    super(c, a);
    init();
  }

  public BrowserPager(Context c, AttributeSet a, int s) {
    super(c, a, s);
    init();
  }

  public void setOnFileSelectedListener(Listener l) {
    listener = l;
  }

  /** تقرير فتح الملفات — ربط نغمة «الفتح الفوري» (تُستدعى قبل محتوى الملف). */
  public void setOnFileOpeningListener(FileOpeningCallback callback) {
    openingCallback.callback = callback;
  }

  public void setActionListener(ActionListener l) {
    actions = l;
  }

  private void init() {
    symbolIndexStore = new PersistentSymbolIndexStore(getContext());
    setOrientation(VERTICAL);
    setBackgroundColor(Color.rgb(25, 25, 25));
    header = LayoutInflater.from(getContext()).inflate(R.layout.browser_header, this, false);
    pathLabel = header.findViewById(R.id.browserHeaderLabel);
    pathLabel.setTextDirection(TEXT_DIRECTION_LTR);
    pathLabel.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
    ((ImageView) header.findViewById(R.id.browserHeaderIcon))
        .setImageResource(R.drawable.folder_open);
    header.findViewById(R.id.browserHeaderMenuButton).setOnClickListener(this::showHeaderMenu);
    addView(header, new LayoutParams(-1, -2));
    View body = LayoutInflater.from(getContext()).inflate(R.layout.filebrowser, this, false);
    list = body.findViewById(R.id.filebrowserFileList);
    list.setBackgroundColor(Color.rgb(25, 25, 25));
    list.setCacheColorHint(Color.TRANSPARENT);
    list.setDivider(new ColorDrawable(Color.TRANSPARENT));
    list.setDividerHeight(0);
    list.setAdapter(new FolderAdapter());
    list.setOnItemClickListener((p, v, pos, id) -> activate(entries.get(pos)));
    list.setOnItemLongClickListener(
        (p, v, pos, id) -> {
          Entry e = entries.get(pos);
          if (e.action == 0) showEntryMenu(v, e);
          return true;
        });
    addView(body, new LayoutParams(-1, 0, 1));
    applyTheme();
    pathLabel.setText(ui("ui_loading_projects"));
    restoreProjectRootReference();
    final int startupGeneration = navigationGeneration;
    post(
        () -> {
          // استعادة جلسة المشروع من MainActivity تسبق هذا الـpost — أي تنقل حدث قبله
          // يعني أن القائمة فُتحت على المشروع بالفعل ولا يجوز الدوس عليها بالافتراضي.
          if (navigationGeneration != startupGeneration) return;
          if (!restoreDocumentTree()) {
            // دلالة CurrentDir المرجعية: الإقلاع يعود إلى آخر مجلد تصفح لا إلى الجذر الافتراضي.
            loadFile(startupDirectory());
          }
        });
  }

  public void openTree(Uri treeUri) {
    try {
      getContext()
          .getContentResolver()
          .takePersistableUriPermission(
              treeUri,
              Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
    } catch (Exception writeNotGranted) {
      try {
        getContext()
            .getContentResolver()
            .takePersistableUriPermission(treeUri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
      } catch (Exception ignored) {
      }
    }
    getContext()
        .getSharedPreferences("file_browser", Context.MODE_PRIVATE)
        .edit()
        .putString("tree_uri", treeUri.toString())
        .apply();
    DocumentFile root = DocumentFile.fromTreeUri(getContext(), treeUri);
    if (root == null) {
      toast(ui("ui_folder_open_failed"));
      return;
    }
    usingDocuments = true;
    documentRoot = root;
    invalidateSearchCatalog();
    documentParents.clear();
    pendingProjectDetection = root.getUri();
    loadDocument(root, false);
    // دلالة CurrentDir: العودة لآخر مجلد زاره المستخدم داخل هذه الشجرة — كما في المرجع.
    restoreDocumentDirAsync(root, treeUri);
  }

  /** يفتح جذر مشروع محدد مباشرة — لاستعادة الجلسة أو التراجع عن تبديل المشروع. */
  public void openProjectRoot(String path) {
    if ((path == null || path.isEmpty()) && projectDocumentUri != null) {
      openTree(projectDocumentUri);
      return;
    }
    if (path == null || path.isEmpty()) return;
    if (path.startsWith("content:")) {
      openTree(Uri.parse(path));
      return;
    }
    // المشروع فُتح أصلًا عبر شجرة المستندات بنفس المسار: الاستعادة بنفس القناة حتى
    // تعود ذاكرة آخر مجلد (current_doc_rel) معها ولا يُكسر وضع SAF إلى File.
    if (projectDocumentUri != null && path.equals(pathForUri(projectDocumentUri))) {
      openTree(projectDocumentUri);
      return;
    }
    File dir = new File(path);
    if (!dir.isDirectory()) {
      // سقوط آمن: بلا قراءة مباشرة نعود لقناة المستندات إن كانت متاحة.
      if (projectDocumentUri != null) openTree(projectDocumentUri);
      return;
    }
    projectFile = dir;
    projectDocumentUri = null;
    rememberProjectRoot();
    // دلالة CurrentDir: إن كان آخر مجلد تصفح داخل هذا المشروع نعود إليه بدل الجذر.
    File remembered = savedCurrentDir();
    if (remembered != null
        && (remembered.equals(dir)
            || remembered.getAbsolutePath().startsWith(dir.getAbsolutePath() + "/")))
      loadFile(remembered);
    else loadFile(dir);
  }

  /** التخزين المؤقت للمشروع الحالي فقط: إسقاط كاشات مشروع سابق فورًا وبسرعة. */
  public void suspendProjectCacheFor(String previousReference) {
    if (previousReference != null && !previousReference.isEmpty() && symbolIndexStore != null) {
      String key =
          previousReference.startsWith("/")
              ? "file:" + previousReference
              : previousReference.startsWith("content:") ? "uri:" + previousReference : "";
      // إسقاط قيود المشروع السابق فقط من المخزن الدائم — مشروع المستخدم الحالي لا يُمس.
      if (!key.isEmpty() && !key.equals(symbolProjectKey())) {
        try {
          symbolIndexStore.pruneProject(key, java.util.Collections.<String>emptySet());
        } catch (Throwable ignored) {
        }
      }
    }
    synchronized (definitionLookupCache) {
      definitionLookupCache.clear();
    }
    synchronized (symbolFiles) {
      symbolFiles.clear();
    }
    synchronized (searchFileCatalog) {
      searchFileCatalog.clear();
      searchCatalogReady = false;
    }
    openedEntries.clear();
  }

  private boolean restoreDocumentTree() {
    String saved =
        getContext()
            .getSharedPreferences("file_browser", Context.MODE_PRIVATE)
            .getString("tree_uri", "");
    if (saved.isEmpty()) return false;
    try {
      Uri savedUri = Uri.parse(saved);
      if (!hasPersistedReadPermission(savedUri)) {
        clearSavedTree();
        return false;
      }
      DocumentFile root = DocumentFile.fromTreeUri(getContext(), savedUri);
      if (root != null) {
        usingDocuments = true;
        documentRoot = root;
        documentParents.clear();
        loadDocument(root, false);
        // دلالة CurrentDir: الإقلاع على الشجرة يعود لآخر مجلد زاره المستخدم فيها.
        restoreDocumentDirAsync(root, savedUri);
        return true;
      }
    } catch (Exception ignored) {
    }
    clearSavedTree();
    return false;
  }

  private boolean hasPersistedReadPermission(Uri treeUri) {
    for (UriPermission permission :
        getContext().getContentResolver().getPersistedUriPermissions()) {
      if (permission.isReadPermission() && permission.getUri().equals(treeUri)) return true;
    }
    return false;
  }

  private void clearSavedTree() {
    getContext()
        .getSharedPreferences("file_browser", Context.MODE_PRIVATE)
        .edit()
        .remove("tree_uri")
        .apply();
  }

  private void rememberProjectRoot() {
    getContext()
        .getSharedPreferences("file_browser", Context.MODE_PRIVATE)
        .edit()
        .putString("project_uri", projectDocumentUri == null ? "" : projectDocumentUri.toString())
        .putString("project_file", projectFile == null ? "" : projectFile.getAbsolutePath())
        .apply();
  }

  // ======== المرحلة د: دلالة CurrentDir المرجعية — آخر مجلد تصفح يُحفظ ويُستعاد ========

  /** حفظ آخر مجلد تصفح (وضع الملفات المباشر فقط) — دلالة CurrentDir في المرجع. */
  private void persistCurrentDir(File directory) {
    if (directory == null || !canReadDirectStorage()) return;
    getContext()
        .getSharedPreferences("file_browser", Context.MODE_PRIVATE)
        .edit()
        .putString("current_dir", directory.getAbsolutePath())
        .apply();
  }

  /**
   * دلالة CurrentDir لوضع المستندات (SAF): يُحفظ المسار النسبي من جذر الشجرة عند كل
   * تنقل، فتعود القائمة لآخر مجلد زاره المستخدم عند إعادة فتح الشجرة نفسها.
   */
  private void persistCurrentDocumentDir(DocumentFile directory) {
    if (directory == null || documentRoot == null) return;
    String rootPath = pathForDocument(documentRoot);
    String dirPath = pathForDocument(directory);
    String relative =
        dirPath.equals(rootPath)
            ? ""
            : dirPath.startsWith(rootPath + "/") ? dirPath.substring(rootPath.length() + 1) : null;
    if (relative == null) return; // خارج الشجرة الحالية — لا يُحفظ.
    getContext()
        .getSharedPreferences("file_browser", Context.MODE_PRIVATE)
        .edit()
        .putString("current_doc_tree", documentRoot.getUri().toString())
        .putString("current_doc_rel", relative)
        .apply();
  }

  /**
   * استعادة آخر مجلد مستندات بعد فتح الشجرة: نزول آمن بالأسماء مقطعًا‑مقطعًا في الخلفية
   * مع بناء سلسلة الآباء لزر «..» — أي مقطع مفقود يعني البقاء في الجذر بصمت.
   */
  private void restoreDocumentDirAsync(DocumentFile root, Uri treeUri) {
    android.content.SharedPreferences preferences =
        getContext().getSharedPreferences("file_browser", Context.MODE_PRIVATE);
    String savedTree = preferences.getString("current_doc_tree", "");
    String relative = preferences.getString("current_doc_rel", "");
    if (relative.isEmpty() || !savedTree.equals(treeUri.toString())) return;
    String[] segments = relative.split("/");
    if (segments.length == 0 || segments.length > 10) return;
    directoryReader.execute(
        () -> {
          ArrayList<DocumentFile> parents = new ArrayList<>();
          DocumentFile cursor = root;
          for (String segment : segments) {
            if (segment.isEmpty()) return;
            DocumentFile next;
            try {
              next = cursor.findFile(segment);
            } catch (Throwable unreadable) {
              return;
            }
            if (next == null || !next.isDirectory()) return;
            parents.add(cursor);
            cursor = next;
          }
          final DocumentFile target = cursor;
          final ArrayList<DocumentFile> chain = parents;
          mainHandler.post(
              () -> {
                // لا استعادة إن تنقل المستخدم بنفسه أثناء النزول أو تبدلت الشجرة.
                if (!usingDocuments
                    || documentRoot == null
                    || !documentRoot.getUri().equals(treeUri)
                    || currentDocument == null
                    || !currentDocument.getUri().equals(root.getUri())) return;
                documentParents.clear();
                documentParents.addAll(chain);
                loadDocument(target, true);
              });
        });
  }

  // ======== خيار معلومات الملفات (المرجع: file_browser_display_file_info) ========
  private Boolean showFileDetails;

  private boolean showFileDetails() {
    if (showFileDetails == null)
      showFileDetails =
          getContext()
              .getSharedPreferences("file_browser", Context.MODE_PRIVATE)
              .getBoolean("show_details", false);
    return showFileDetails;
  }

  private void setShowFileDetails(boolean enabled) {
    showFileDetails = enabled;
    getContext()
        .getSharedPreferences("file_browser", Context.MODE_PRIVATE)
        .edit()
        .putBoolean("show_details", enabled)
        .apply();
    notifyList();
  }

  private final java.text.SimpleDateFormat entryInfoDate =
      new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US);

  /** سطر المعلومات كالمرجع: تاريخ التعديل، وللملف الحجم بعده — فارغ يعني لا سطر. */
  private String formatEntryInfo(Entry e) {
    StringBuilder out = new StringBuilder();
    if (e.modified > 0) out.append(entryInfoDate.format(new java.util.Date(e.modified)));
    if (!e.folder && e.size >= 0) {
      if (out.length() > 0) out.append("  ");
      out.append(formatSize(e.size));
    }
    return out.toString();
  }

  private String formatSize(long bytes) {
    if (bytes < 1024) return uiFormat("ui_file_size_bytes", bytes);
    if (bytes < 1024 * 1024)
      return String.format(Locale.US, ui("ui_file_size_kb"), bytes / 1024.0);
    return String.format(Locale.US, ui("ui_file_size_mb"), bytes / (1024.0 * 1024.0));
  }

  /**
   * «ملف جديد» من قائمة الرأس بنفس آلية صفوف ➕ السياقية: داخل مصادر الجافا يفتح
   * حوار الكلاس الكامل، وداخل المجلدات الفرعية لـres يفتح حوار XML، وإلا الحوار العام.
   */
  private void createFileContextually() {
    File target = currentFile != null ? currentFile : documentDirAsFile();
    if (target != null) {
      String path = target.getAbsolutePath().replace('\\', '/');
      if (isJavaSourceDir(path)) {
        promptCreateClass(target);
        return;
      }
      if (isResSubDir(path)) {
        promptCreateXml(target);
        return;
      }
    }
    promptCreate(false);
  }

  /**
   * المجلد الحالي في وضع المستندات كمجلد مباشر — يتيح لحوارات الإنشاء الكاملة
   * (كلاس بمنيفست وLayout) العمل داخل شجرة SAF عبر المسار الحقيقي، وإلا null.
   */
  private File documentDirAsFile() {
    if (!usingDocuments || currentDocument == null || !canReadDirectStorage()) return null;
    File direct = new File(pathForDocument(currentDocument));
    return direct.isDirectory() ? direct : null;
  }

  /** آخر مجلد تصفح محفوظ إن كان ما يزال مجلدًا موجودًا — وإلا null. */
  private File savedCurrentDir() {
    String path =
        getContext()
            .getSharedPreferences("file_browser", Context.MODE_PRIVATE)
            .getString("current_dir", "");
    if (path.isEmpty()) return null;
    File dir = new File(path);
    return dir.isDirectory() ? dir : null;
  }

  /** المرحلة 5: بيت المشاريع من الإعداد project_home إن كان مسارًا مطلقًا. */
  private java.io.File projectsHomeDir() {
    String custom =
        almlk.AppSettings.prefs(getContext()).getString("project_home", null);
    if (custom != null && custom.startsWith("/")) return new java.io.File(custom);
    return new java.io.File(Environment.getExternalStorageDirectory(), "AppProjects");
  }

  /** مجلد الإقلاع: آخر مجلد تصفح إن صلح، وإلا AppProjects الافتراضي. */
  private File startupDirectory() {
    File remembered = savedCurrentDir();
    return remembered != null ? remembered : projectsHomeDir();
  }

  /** إغلاق المشروع (أمر المرجع): مسح مرجع الجذر والعودة إلى بيت المشاريع. */
  public void showProjectsHome() {
    projectFile = null;
    projectDocumentUri = null;
    getContext()
        .getSharedPreferences("file_browser", Context.MODE_PRIVATE)
        .edit()
        .remove("project_uri")
        .remove("project_file")
        .apply();
    java.io.File home = projectsHomeDir();
    if (canReadDirectStorage() && home.isDirectory()) {
      usingDocuments = false;
      loadFile(home);
      return;
    }
    refresh();
  }

  private void restoreProjectRootReference() {
    android.content.SharedPreferences preferences =
        getContext().getSharedPreferences("file_browser", Context.MODE_PRIVATE);
    String uri = preferences.getString("project_uri", "");
    String file = preferences.getString("project_file", "");
    if (!uri.isEmpty()) {
      projectDocumentUri = Uri.parse(uri);
      projectFile = null;
    } else if (!file.isEmpty()) {
      projectFile = new File(file);
      projectDocumentUri = null;
    }
  }

  public void applyTheme() {
    ThemeConfig theme = new ThemeConfig(getContext());
    int background = theme.isDark() ? Color.rgb(25, 25, 25) : Color.rgb(250, 250, 250);
    int chrome = theme.isDark() ? Color.rgb(31, 31, 31) : Color.rgb(240, 240, 240);
    setBackgroundColor(background);
    if (list != null) {
      list.setBackgroundColor(background);
      ((BaseAdapter) list.getAdapter()).notifyDataSetChanged();
    }
    if (header != null) header.setBackground(headerBackground(chrome));
    if (pathLabel != null) pathLabel.setTextColor(theme.color(ThemeConfig.PLAIN));
  }

  /**
   * خط فاصل بين ترويسة المسار والقائمة كما في المرجع: طبقتان — لون التمييز كاملًا، وفوقه
   * لون الترويسة مُزاحًا 2dp من الأسفل فيبقى شريط التمييز ظاهرًا أسفلها فقط.
   */
  private Drawable headerBackground(int chrome) {
    android.util.TypedValue value = new android.util.TypedValue();
    int accent = 0xFF03A9F4;
    if (getContext().getTheme().resolveAttribute(android.R.attr.colorAccent, value, true)
        && value.type >= android.util.TypedValue.TYPE_FIRST_COLOR_INT
        && value.type <= android.util.TypedValue.TYPE_LAST_COLOR_INT) accent = value.data;
    int line = Math.max(1, Math.round(2 * getResources().getDisplayMetrics().density));
    android.graphics.drawable.LayerDrawable layers =
        new android.graphics.drawable.LayerDrawable(
            new Drawable[] {new ColorDrawable(accent), new ColorDrawable(chrome)});
    layers.setLayerInset(1, 0, 0, 0, line);
    return layers;
  }

  private void invalidateSearchCatalog() {
    synchronized (searchFileCatalog) {
      searchFileCatalog.clear();
      searchCatalogReady = false;
    }
  }

  public void refresh() {
    invalidateSearchCatalog();
    // إن تغيّر الثيم (تبديل داكن/فاتح) نعيد بناء ThemeConfig المخزّن ليتلوّن النص الجديد.
    cachedEntryTheme = null;
    if (usingDocuments && currentDocument != null) {
      invalidateDirectory(documentCacheKey(currentDocument.getUri()));
      loadDocument(currentDocument, true);
    } else if (currentFile != null) {
      invalidateDirectory(fileCacheKey(currentFile));
      loadFile(currentFile);
    }
  }

  public void createFile() {
    promptCreate(false);
  }

  public void createFolder() {
    promptCreate(true);
  }

  public String getCurrentPath() {
    return usingDocuments && currentDocument != null
        ? pathForDocument(currentDocument)
        : currentFile == null ? "" : currentFile.getAbsolutePath();
  }

  /** Returns a stable File path or SAF content URI for metadata-only session restoration. */
  public String fileReference(String name) {
    Entry entry = openedEntries.get(name);
    if (entry == null) return "";
    if (entry.documentUri != null) return entry.documentUri.toString();
    return entry.file == null ? "" : entry.file.getAbsolutePath();
  }

  /** Supplies the visible editor snapshot so Go To Element can answer before the disk index ends. */
  public void setActiveEditorSnapshot(String fileName, String source, String reference) {
    String file = fileName == null ? "" : fileName;
    String text = source == null ? "" : source;
    String stable = reference == null ? "" : reference;
    int length = text.length();
    int hash = text.hashCode();
    synchronized (activeSymbolLock) {
      if (activeSymbolFile.equals(file)
          && activeSymbolReference.equals(stable)
          && activeSymbolLength == length
          && activeSymbolHash == hash) return;
      activeSymbolFile = file;
      activeSymbolReference = stable;
      activeSymbolSource = text;
      activeSymbolLength = length;
      activeSymbolHash = hash;
      activeSymbols = Collections.emptyList();
      activeSymbolsReady = false;
    }
  }

  private List<ProjectSymbolIndex.DefinitionTarget> activeSymbolsSnapshot() {
    String file, reference, source;
    int length, hash;
    synchronized (activeSymbolLock) {
      if (activeSymbolsReady) return activeSymbols;
      file = activeSymbolFile;
      reference = activeSymbolReference;
      source = activeSymbolSource;
      length = activeSymbolLength;
      hash = activeSymbolHash;
    }
    if (source.isEmpty() || file.isEmpty()) return Collections.emptyList();
    List<ProjectSymbolIndex.DefinitionTarget> parsed =
        ProjectSymbolIndex.extractSourceSymbols(file, reference, source);
    synchronized (activeSymbolLock) {
      if (activeSymbolFile.equals(file)
          && activeSymbolReference.equals(reference)
          && activeSymbolLength == length
          && activeSymbolHash == hash) {
        activeSymbols = Collections.unmodifiableList(new ArrayList<>(parsed));
        activeSymbolsReady = true;
        return activeSymbols;
      }
    }
    return parsed;
  }

  private List<ProjectSymbolIndex.DefinitionTarget> searchSymbolsNow(
      String query, boolean includeSystem) {
    ArrayList<ProjectSymbolIndex.DefinitionTarget> combined = new ArrayList<>();
    combined.addAll(ProjectSymbolIndex.searchSymbols(query, 400, includeSystem));
    combined.addAll(ProjectSymbolIndex.filterSymbols(activeSymbolsSnapshot(), query, 200));
    return ProjectSymbolIndex.filterSymbols(combined, query, 400);
  }

  public void saveOpenedFileAsync(String name, String content, SaveListener listener) {
    Entry entry = openedEntries.get(name);
    if (entry == null) {
      if (listener != null) listener.completed(false, ui("ui_file_not_found"));
      return;
    }
    fileReader.execute(
        () -> {
          boolean success = false;
          String message;
          try {
            OutputStream output =
                entry.documentUri != null
                    ? getContext().getContentResolver().openOutputStream(entry.documentUri, "wt")
                    : new FileOutputStream(entry.file, false);
            if (output == null) throw new IOException(ui("ui_provider_write_denied"));
            output.write(EncodingManager.encodeUtf8(content));
            output.flush();
            output.close();
            cacheFileContent(fileContentKey(entry), content);
            persistJavaIndex(entry, content);
            success = true;
            message = ui("ui_file_saved");
          } catch (Exception error) {
            message = uiFormat("ui_save_failed", UiStrings.message(getContext(), error));
          }
          final boolean result = success;
          final String resultMessage = message;
          mainHandler.post(
              () -> {
                if (listener != null) listener.completed(result, resultMessage);
              });
        });
  }

  /** صفّا المرجع في جذر المشروع: «خصائص المشروع…» ثم «إضافة إلى المشروع…». */
  private void addProjectRows(File projectDir) {
    entries.add(
        new Entry(
            ui("command_files_project_properties"),
            projectDir,
            null,
            false,
            R.drawable.project_properties,
            ACTION_PROJECT_PROPERTIES));
    entries.add(
        new Entry(
            ui("command_files_add_to_project"),
            projectDir,
            null,
            false,
            R.drawable.project_new,
            ACTION_ADD_TO_PROJECT));
  }

  private void activate(Entry e) {
    if (e.action == ACTION_PROJECT_PROPERTIES) {
      openProjectProperties(e.file);
      return;
    }
    if (e.action == ACTION_ADD_TO_PROJECT) {
      showAddToProjectDialog(e.file);
      return;
    }
    if (e.action == ACTION_UP_TO_FILES) {
      if (e.file != null && e.file.isDirectory()) loadFileUp(e.file);
      else if (actions != null) actions.onSelectProjectFolder();
      return;
    }
    if (e.action == ACTION_CREATE_PROJECT) {
      if (actions != null) actions.onCreateProject();
      return;
    }
    if (e.action == ACTION_CLONE) {
      if (actions != null) actions.onCloneGit();
      return;
    }
    if (e.action == ACTION_PERMISSION) {
      if (actions != null) actions.onStoragePermissionRequested();
      return;
    }
    if (e.action == ACTION_SELECT_TREE) {
      if (actions != null) actions.onSelectProjectFolder();
      return;
    }
    if (e.action == ACTION_UP_DOCUMENT) {
      if (!documentParents.isEmpty()) loadDocument(documentParents.removeLast(), true);
      return;
    }
    // تقرير فتح الملفات — قناة الصعود آمنة دائمًا: «..» لا يمر أبدًا بضغط المجلدات
    // وحيدة الفرع، وإلا ارتدّ المستخدم إلى قاع سلسلة java/com/example بلا مخرج.
    if (e.action == ACTION_UP_FILE) {
      if (e.file != null) loadFileUp(e.file);
      return;
    }
    if (e.action == ACTION_NEW_CLASS) {
      File target = currentFile != null ? currentFile : documentDirAsFile();
      if (target != null) promptCreateClass(target);
      return;
    }
    if (e.action == ACTION_NEW_XML) {
      File target = currentFile != null ? currentFile : documentDirAsFile();
      if (target != null) promptCreateXml(target);
      return;
    }
    if (e.action == ACTION_OPEN_PROJECT) {
      if (e.file != null && actions != null) {
        projectFile = e.file;
        projectDocumentUri = null;
        rememberProjectRoot();
        actions.onProjectOpened(e.file.getName(), e.file.getAbsolutePath());
      }
      return;
    }
    if (e.action == ACTION_EMPTY) return;
    if (e.folder) {
      if (usingDocuments) {
        // تقرير «إظهار جميع الملفات» — عنصر مدمج من التخزين المباشر (نقطي مثل .gradle)
        // لا documentUri له: تنقّل عبر المسار المباشر بأمان تام.
        if (e.documentUri == null && e.file != null) {
          loadFile(e.file);
          return;
        }
        DocumentFile target =
            e.document != null
                ? e.document
                : DocumentFile.fromSingleUri(getContext(), e.documentUri);
        if (target == null) {
          toast(ui("ui_folder_open_failed"));
          return;
        }
        if (currentDocument == documentRoot && actions != null) {
          projectDocumentUri = e.documentUri;
          projectFile = null;
          rememberProjectRoot();
          actions.onProjectOpened(e.name, pathForUri(e.documentUri));
        }
        documentParents.addLast(currentDocument);
        loadDocument(target, true);
      } else {
        if (currentFile != null && currentFile.getName().equals("AppProjects") && actions != null) {
          projectFile = e.file;
          projectDocumentUri = null;
          rememberProjectRoot();
          actions.onProjectOpened(e.name, e.file.getAbsolutePath());
        }
        loadFile(e.file);
      }
      return;
    }
    // اعتراض غير النصي كما في المرجع: صورة → معاينة فورية، APK → معلومات الحزمة.
    String lowerName = e.name == null ? "" : e.name.toLowerCase(Locale.US);
    if (isImageName(lowerName)) {
      showImagePreview(e);
      return;
    }
    if (lowerName.endsWith(".apk") && e.file != null) {
      showApkInfo(e.file);
      return;
    }
    openedEntries.put(e.name, e);
    if (listener == null) {
      // دفاع: لا صمت أبدًا — المُستمع يجب أن يكوّن مربوطًا دائمًا في MainActivity.
      toast(ui("ui_file_open_unavailable"));
      return;
    }
    // تقرير فتح الملفات — الملكية الصحيحة للقراءة: الخدمة almlk.FileContentService تنشق عن
    // مصير هذا الدرج (الذي يُغلق للحظة ولا يجوز أن يقتل قراءة جارية). هنا نعلن فورًا فقط.
    openGeneration++;
    openingCallback.notifyOpening(e.name);
  }

  private void loadDocument(DocumentFile directory, boolean preserveParents) {
    rememberScrollPosition();
    usingDocuments = true;
    currentDocument = directory;
    currentFile = null;
    pathLabel.setText(pathForDocument(directory));
    persistCurrentDocumentDir(directory);
    final Uri uri = directory.getUri();
    final String key = documentCacheKey(uri);
    final int request = ++navigationGeneration;
    List<Entry> cached = cachedDirectory(key);
    if (cached != null) {
      showDocumentEntries(directory, uri, cached, request);
      return;
    }
    showLoadingEntry();
    directoryReader.execute(
        () -> {
          List<Entry> loaded;
          try {
            loaded = sortedEntries(queryDocumentChildren(uri));
            cacheDirectory(key, loaded);
          } catch (Exception error) {
            loaded = null;
          }
          final List<Entry> result = loaded;
          mainHandler.post(() -> showDocumentEntries(directory, uri, result, request));
        });
  }

  private void showDocumentEntries(
      DocumentFile directory, Uri uri, List<Entry> children, int request) {
    if (request != navigationGeneration
        || currentDocument == null
        || !currentDocument.getUri().equals(uri)) return;
    entries.clear();
    if (!documentParents.isEmpty())
      entries.add(new Entry("..", null, null, true, R.drawable.folder_open, ACTION_UP_DOCUMENT));
    else {
      // جذر شجرة SAF: «..» يصعد إلى المجلد الأب عبر التخزين المباشر إن أمكن، وإلا يفتح منتقي المجلد.
      File treeDir = canReadDirectStorage() ? new File(pathForDocument(directory)) : null;
      File treeParent = treeDir != null && treeDir.isDirectory() ? treeDir.getParentFile() : null;
      entries.add(new Entry("..", treeParent, null, true, R.drawable.folder_open, ACTION_UP_TO_FILES));
    }
    File directDocumentDir = documentDirAsFile();
    if (directory == documentRoot && nameForUri(uri).equalsIgnoreCase("AppProjects")) {
      entries.add(
          new Entry(
              ui("ui_new_project_entry"),
              null,
              null,
              false,
              R.drawable.ic_launcher_java,
              ACTION_CREATE_PROJECT));
      entries.add(
          new Entry(
              ui("ui_clone_git_entry"), null, null, false, R.drawable.browser_git, ACTION_CLONE));
    }
    if (directDocumentDir != null && isProjectRoot(directDocumentDir)) addProjectRows(directDocumentDir);
    // أوامر المرجع السياقية في وضع المستندات أيضًا — نفس نظام وضع الملفات تمامًا:
    // «إنشاء كلاس جديد» داخل مصادر الجافا و«إنشاء ملف XML جديد» داخل res.
    if (children != null && documentDirAsFile() != null) {
      String directoryPath = pathForDocument(directory).replace('\\', '/');
      if (isJavaSourceDir(directoryPath))
        entries.add(
            new Entry(
                ui("ui_new_class_entry"),
                null,
                null,
                false,
                R.drawable.file_type_java,
                ACTION_NEW_CLASS));
      if (isResSubDir(directoryPath))
        entries.add(
            new Entry(
                ui("ui_new_xml_entry"),
                null,
                null,
                false,
                R.drawable.file_type_xml,
                ACTION_NEW_XML));
    }
    if (children == null) {
      entries.add(
          new Entry(
              ui("ui_reselect_folder_read_access"),
              null,
              null,
              false,
              R.drawable.folder_open,
              ACTION_SELECT_TREE));
    } else if (children.isEmpty()) {
      entries.add(
          new Entry(ui("ui_empty_folder"), null, null, false, R.drawable.folder_open, ACTION_EMPTY));
    } else {
      entries.addAll(children);
    }
    notifyList();
    restoreScrollPosition(documentCacheKey(uri));
    if (pendingProjectDetection != null && pendingProjectDetection.equals(uri)) {
      pendingProjectDetection = null;
      if (children != null && entriesLookLikeProject() && actions != null) {
        projectDocumentUri = uri;
        projectFile = null;
        rememberProjectRoot();
        actions.onProjectOpened(nameForUri(uri), pathForDocument(directory));
      }
    }
    if (children != null) prefetchDocumentChildren(children);
  }

  private void showLoadingEntry() {
    entries.clear();
    entries.add(
        new Entry(ui("ui_opening_folder"), null, null, false, R.drawable.folder_open, ACTION_EMPTY));
    notifyList();
  }

  private List<Entry> sortedEntries(Entry[] source) {
    Arrays.sort(source, BrowserPager::compareEntries);
    return new ArrayList<>(Arrays.asList(source));
  }

  /**
   * فرز المرجع الخماسي: مجلدات عادية → مجلدات بناء خاصة (bin/obj/build/gradle) →
   * مجلدات مخفية → ملفات عادية → ملفات مخفية؛ وداخل كل فئة فرز طبيعي يفصل
   * الأرقام عن الحروف («App2» قبل «App10»).
   */
  private static int compareEntries(Entry a, Entry b) {
    int rank = categoryRank(a) - categoryRank(b);
    if (rank != 0) return rank;
    return naturalCompare(a.name == null ? "" : a.name, b.name == null ? "" : b.name);
  }

  private static int categoryRank(Entry e) {
    String name = e.name == null ? "" : e.name;
    boolean hidden = name.startsWith(".");
    if (e.folder) {
      if (hidden) return 2;
      String lower = name.toLowerCase(Locale.US);
      if (lower.equals("bin") || lower.equals("obj") || lower.equals("build") || lower.equals("gradle"))
        return 1;
      return 0;
    }
    return hidden ? 4 : 3;
  }

  /** مقارنة طبيعية: مقاطع الأرقام تُقارن كقيم لا كنصوص، والباقي بلا حساسية حالة. */
  private static int naturalCompare(String a, String b) {
    int i = 0, j = 0, lengthA = a.length(), lengthB = b.length();
    while (i < lengthA && j < lengthB) {
      char ca = a.charAt(i), cb = b.charAt(j);
      if (Character.isDigit(ca) && Character.isDigit(cb)) {
        int startA = i, startB = j;
        while (i < lengthA && Character.isDigit(a.charAt(i))) i++;
        while (j < lengthB && Character.isDigit(b.charAt(j))) j++;
        int zeroA = startA, zeroB = startB;
        while (zeroA < i - 1 && a.charAt(zeroA) == '0') zeroA++;
        while (zeroB < j - 1 && b.charAt(zeroB) == '0') zeroB++;
        int digitsA = i - zeroA, digitsB = j - zeroB;
        if (digitsA != digitsB) return digitsA - digitsB;
        for (int k = 0; k < digitsA; k++) {
          int diff = a.charAt(zeroA + k) - b.charAt(zeroB + k);
          if (diff != 0) return diff;
        }
      } else {
        int diff = Character.toLowerCase(ca) - Character.toLowerCase(cb);
        if (diff != 0) return diff;
        i++;
        j++;
      }
    }
    return (lengthA - i) - (lengthB - j);
  }

  private void prefetchDocumentChildren(List<Entry> children) {
    ArrayList<Entry> folders = new ArrayList<>();
    for (Entry entry : children) {
      if (entry.folder && entry.documentUri != null && folders.size() < 8) folders.add(entry);
    }
    if (folders.isEmpty()) return;
    directoryReader.execute(
        () -> {
          for (Entry folder : folders) {
            String key = documentCacheKey(folder.documentUri);
            synchronized (directoryCache) {
              if (directoryCache.containsKey(key) || !prefetching.add(key)) continue;
            }
            try {
              cacheDirectory(key, sortedEntries(queryDocumentChildren(folder.documentUri)));
            } catch (Exception ignored) {
            } finally {
              synchronized (directoryCache) {
                prefetching.remove(key);
              }
            }
          }
        });
  }

  private Entry[] queryDocumentChildren(Uri directoryUri) throws Exception {
    String parentId = DocumentsContract.getDocumentId(directoryUri);
    Uri childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(directoryUri, parentId);
    String[] projection = {
      DocumentsContract.Document.COLUMN_DOCUMENT_ID,
      DocumentsContract.Document.COLUMN_DISPLAY_NAME,
      DocumentsContract.Document.COLUMN_MIME_TYPE,
      DocumentsContract.Document.COLUMN_SIZE,
      DocumentsContract.Document.COLUMN_LAST_MODIFIED
    };
    ArrayList<Entry> result = new ArrayList<>();
    try (Cursor cursor =
        getContext().getContentResolver().query(childrenUri, projection, null, null, null)) {
      if (cursor == null) throw new IOException("Document provider returned no cursor");
      int idColumn = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DOCUMENT_ID);
      int nameColumn = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DISPLAY_NAME);
      int mimeColumn = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_MIME_TYPE);
      int sizeColumn = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_SIZE);
      int modifiedColumn = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_LAST_MODIFIED);
      while (cursor.moveToNext()) {
        String documentId = cursor.getString(idColumn);
        String name = cursor.isNull(nameColumn) ? ui("ui_unnamed") : cursor.getString(nameColumn);
        String mime = cursor.isNull(mimeColumn) ? "" : cursor.getString(mimeColumn);
        boolean folder = DocumentsContract.Document.MIME_TYPE_DIR.equals(mime);
        long size = sizeColumn < 0 || cursor.isNull(sizeColumn) ? -1 : cursor.getLong(sizeColumn);
        long modified =
            modifiedColumn < 0 || cursor.isNull(modifiedColumn) ? 0 : cursor.getLong(modifiedColumn);
        Uri childUri = DocumentsContract.buildDocumentUriUsingTree(directoryUri, documentId);
        result.add(
            new Entry(
                name,
                childUri,
                folder,
                size,
                modified,
                folder ? folderIconFor(name) : iconFor(name)));
      }
    }
    // تقرير «إظهار جميع الملفات» — مزوّد SAF يُقصي كل ملف يبدأ بنقطة (.gitignore/.gradle…)
    // وقد يُقصي عناصر أخرى بحسب الـ ROM. ندمج قائمة File المباشرة (حين يسمح الوصول المباشر)
    // كي تظهر كل محتويات المجلد دون إخفاء، مع إزالة التكرار بالاسم.
    mergeDirectChildren(directoryUri, result);
    return result.toArray(new Entry[0]);
  }

  /** يدمج ما يخفيه المزوّد (عادة الملفات النقطية) من قائمة File المباشرة. بلا ضجيج عند غياب الوصول. */
  private void mergeDirectChildren(Uri directoryUri, ArrayList<Entry> into) {
    if (!canReadDirectStorage()) return;
    File direct = fileForDocumentUri(directoryUri);
    if (direct == null) return;
    File[] files;
    try {
      files = direct.listFiles();
    } catch (Throwable failure) {
      return;
    }
    if (files == null) return;
    java.util.HashSet<String> seen = new java.util.HashSet<>();
    for (Entry entry : into)
      if (entry.name != null) seen.add(entry.name);
    boolean added = false;
    for (File file : files) {
      String name = file.getName();
      if (seen.contains(name)) continue;
      boolean folder = file.isDirectory();
      into.add(
          new Entry(name, file, null, folder, folder ? folderIconFor(name) : iconFor(name), 0, 0));
      seen.add(name);
      added = true;
    }
    if (added) {
      // إعادة الفرز بالمقارن الموحد (خماسي طبيعي) — ترتيب واحد في كل المسارات.
      into.sort(BrowserPager::compareEntries);
    }
  }

  /** هندسة المسار لتحويل SAF URI لوحدة التخزين الأساسية إلى ملف مباشر (عندما يمكن ذلك). */
  private File fileForDocumentUri(Uri uri) {
    if (uri == null) return null;
    try {
      String id = DocumentsContract.getDocumentId(uri);
      if (id == null) return null;
      int colon = id.indexOf(':');
      String volume = colon < 0 ? id : id.substring(0, colon);
      String rel = colon < 0 ? "" : id.substring(colon + 1);
      if ("primary".equalsIgnoreCase(volume) || "home".equalsIgnoreCase(volume)) {
        return new File(android.os.Environment.getExternalStorageDirectory(), rel);
      }
    } catch (Throwable ignored) {
    }
    return null;
  }

  private String fileContentKey(Entry entry) {
    if (entry == null) return "";
    if (entry.documentUri != null)
      return "content:" + entry.documentUri + ":" + entry.size;
    if (entry.file == null) return "";
    return "content:" + entry.file.getAbsolutePath() + ":" + entry.file.lastModified() + ":" + entry.file.length();
  }

  private String cachedFileContent(String key) {
    return fileContentCache.get(key);
  }

  private void cacheFileContent(String key, String content) {
    fileContentCache.put(key, content);
  }

  private String documentCacheKey(Uri uri) {
    return "document:" + uri;
  }

  private String fileCacheKey(File directory) {
    return "file:" + directory.getAbsolutePath();
  }

  private List<Entry> cachedDirectory(String key) {
    synchronized (directoryCache) {
      List<Entry> value = directoryCache.get(key);
      return value == null ? null : new ArrayList<>(value);
    }
  }

  private void cacheDirectory(String key, List<Entry> value) {
    synchronized (directoryCache) {
      directoryCache.put(key, new ArrayList<>(value));
    }
  }

  private void invalidateDirectory(String key) {
    synchronized (directoryCache) {
      directoryCache.remove(key);
    }
  }

  /** كم ملفًّا يُسمَحُ بهِ لجذورِ الوحداتِ المرتبطةِ — زيادةٌ على سقفِ المسحةِ لا بدلٌ منهُ. */
  private static final int LINKED_VISIT_BUDGET = 4000;
  private volatile String linkedRootsProjectPath = "";
  private volatile java.util.function.Supplier<java.util.List<File>> linkedSourceRoots;
  /**
   * جذورٌ أعلنَها المشروعُ خارجَ جذرِ المتصفّحِ (وحداتٌ موصولةٌ): لِيَرجعَ سطرُ خطأٍ في
   * ‏`res/` أو في مانيفستِ وحدةٍ إلى ملفٍّ مفتوحٍ، لا إلى «لا مُدخَلَ لهذا المسارِ».
   * لقطَةٌ تُحدَّثُ كلَّ مسحةٍ على خيطِ الفهرسِ، فلا قرصَ في خيطِ الواجهةِ.
   */
  private volatile String[] linkedRootPrefixes = new String[0];

  /**
   * مَن يملكُ مصادرَ خارجَ الجذرِ (‏{@code project(':mylib')} معَ {@code projectDir = new
   * File('../mylib')}): يُسنَدُ مسارُ المشروعِ ومحلٌّ كسولٌ، فتُقرأُ الجذورُ على خيطِ الفهرسةِ
   * وقتَ المسحةِ — لا شبكةَ، ولا بناءَ، ولا قرصَ في خيطِ الواجهةِ.
   */
  public void setLinkedSourceRoots(File projectRoot,
      java.util.function.Supplier<java.util.List<File>> resolver) {
    linkedRootsProjectPath = projectRoot == null ? "" : canonicalPath(projectRoot);
    linkedSourceRoots = resolver;
  }

  /** جذورُ مواردِ الوحداتِ المرتبطةِ (‏{@code res} خارجَ الجذرِ) — خيطٌ ثانٍ بنفسِ الحِلمةِ. */
  private volatile String linkedResourceProjectPath = "";
  private volatile java.util.function.Supplier<java.util.List<File>> linkedResourceRoots;

  /**
   * مَن يملكُ <em>مواردَ</em> خارجَ الجذرِ: وحدةٌ موصولةٌ بمجلدٍ خارجِ شجرةِ المشروعِ
   * لها ‏{@code src/main/res} لا يراهُ ماشيُ الجذرِ، فيبقى ‏{@code @drawable/…} في XML
   * بلا هدفٍ. يُسنَدُ مسارُ المشروعِ ومحلٌّ كسولٌ يُستدعى على خيطِ العملِ عندَ
   * الطلبِ فقط — لا قرصَ في خيطِ الواجهةِ، ولا فهرسَ لمشروعٍ لم يعلنْ وحدةً.
   */
  public void setLinkedResourceRoots(File projectRoot,
      java.util.function.Supplier<java.util.List<File>> resolver) {
    linkedResourceProjectPath = projectRoot == null ? "" : canonicalPath(projectRoot);
    linkedResourceRoots = resolver;
  }

  /**
   * جذورُ المواردِ الزائدةِ لهذهِ النافذةِ، أو {@code null}. تُحَلُّ كسولًا لأنَّ
   * ‏resourceRoots() تمسُّ القرصَ؛ وما لم يطابقْ مسارُ الجذرِ يُهملُ فلا تُقرأ وحداتُ
   * مشروعٍ آخرِ. حلٌّ فاشلٌ يعني «بلا وحداتٍ هذهِ المرةَ» لا «لا مواردَ» — البحثُ
   * يبقى على ما في الجذرِ، ولا نوتةَ فجوةٍ هنا لأنَّ لا مَسحةَ تُبترُ (طلبُ انتقالٍ واحدٌ).
   */
  private java.util.List<File> extraResourceRoots(File ownRoot) {
    java.util.function.Supplier<java.util.List<File>> resolver = linkedResourceRoots;
    if (resolver == null) return null;
    if (ownRoot != null && !canonicalPath(ownRoot).equals(linkedResourceProjectPath)) return null;
    try {
      java.util.List<File> dirs = resolver.get();
      return dirs == null || dirs.isEmpty() ? null : dirs;
    } catch (RuntimeException unavailable) {
      return null;
    }
  }

  public void indexProjectSymbols(Runnable completed) {
    symbolWorker.execute(
        () -> {
          buildSymbolIndex();
          if (completed != null) mainHandler.post(completed);
        });
  }

  private synchronized ProjectDiagnosticsSnapshot diagnosticsSnapshot() {
    if (diagnosticsSnapshot == null)
      diagnosticsSnapshot =
          new ProjectDiagnosticsSnapshot(new File(getContext().getFilesDir(), "diagnostics-snapshots"));
    return diagnosticsSnapshot;
  }

  /** R6: the file whose findings matter most right now (the active tab) is checked first. */
  public void setDiagnosticsPriority(String reference) {
    diagnosticsPriorityReference = reference == null ? "" : reference;
  }

    /** W21′1: نتيجةُ طلبِ المنادِينِ — ملفَّاتٌ معدودةٌ تصلحُ مرشَّحاتٍ لإعادةِ الفحصِ. */
  public interface DependentsListener {
    void found(ArrayList<Reinspection> dependents);
  }

  /**
   * W21′1 — من نادى عضوًا تغيّرَ عقدُهُ؟ البحثُ نفسُهُ الذي يعتمدُ عليهِ «بحثُ المشروعِ» لا ماسحٌ ثانٍ:
   * كتالوجُ الفهرسِ، كاشُ المحتوى المُرحَّلُ، حدُّ الملفَّاتِ، وإلغاءٌ عندَ تغيّرِ المشروعِ، على خيطِ
   * الفحصِ نفسِهِ فيصطفُّ وراءَ إعادةِ الفحصِ الجاريةِ لا أمامَها. الاسمُ يُقابَلُ كلمةً كاملةً فلا يجعلُ
   * `getKey` منادِيًا لـ`getKeyFast`، والمرشَّحاتُ تُعادُ بأسماءِ ملفَّاتِها ليُبدَّلَ محتواها الحيُّ في
   * الطبقةِ العليا إن كانَ التبويبُ مفتوحًا. {@code skipReferences} هو ما عُولِجَ في جولةٍ سابقةٍ من
   * البُرقةِ نفسِها: بلاهُ كانَ الحدُّ يُعيدُ أولَ ثمانيةٍ كلَّ مرةٍ فلا ينفدُ الطابورُ أبدًا.
   */
  public void findDependentsAsync(
      final ArrayList<String> names,
      final int limit,
      final ArrayList<String> skipReferences,
      final DependentsListener listener) {
    if (listener == null) return;
    if (names == null || names.isEmpty() || limit <= 0) {
      mainHandler.post(() -> listener.found(new ArrayList<Reinspection>()));
      return;
    }
    final String projectKey = symbolProjectKey();
    if (projectDiagnosticsWorker.isShutdown())
      projectDiagnosticsWorker = Executors.newSingleThreadExecutor();
    projectDiagnosticsWorker.execute(
        () -> {
          ArrayList<Reinspection> out = new ArrayList<>(limit);
          LinkedHashMap<String, Entry> candidates = new LinkedHashMap<>();
          synchronized (searchFileCatalog) {
            candidates.putAll(searchFileCatalog);
          }
          synchronized (openedEntries) {
            for (Entry entry : openedEntries.values())
              if (entry != null && isSearchableTextFile(entry))
                candidates.put(referenceForEntry(entry), entry);
          }
          int scanned = 0;
          for (Entry item : candidates.values()) {
            if (out.size() >= limit || scanned >= 5000 || Thread.currentThread().isInterrupted()) break;
            if (!projectKey.isEmpty() && !projectKey.equals(symbolProjectKey())) break;
            if (item == null || !isProjectDiagnosticFile(item)) continue;
            scanned++;
            String cacheKey = fileContentKey(item);
            String source = cachedFileContent(cacheKey);
            if (source == null) {
              source = readEntryText(item);
              if (!source.isEmpty()) cacheFileContent(cacheKey, source);
            }
            if (source == null || !mentionsAnyName(source, names)) continue;
            String reference = referenceForEntry(item);
            if (skipReferences != null && skipReferences.contains(reference)) continue;
            out.add(new Reinspection(item.name, reference, source));
          }
          final ArrayList<Reinspection> found = out;
          mainHandler.post(() -> listener.found(found));
        });
  }

  /** كلمةٌ كاملةٌ كما كُتِبَت: لا بادئةَ ولا لاحقًا داخلَ معرِّفٍ أطولَ. */
  private static boolean mentionsAnyName(String source, ArrayList<String> names) {
    for (int i = 0; i < names.size(); i++) {
      String name = names.get(i);
      if (name == null || name.isEmpty()) continue;
      for (int at = source.indexOf(name); at >= 0; at = source.indexOf(name, at + 1)) {
        if (at > 0 && Character.isJavaIdentifierPart(source.charAt(at - 1))) continue;
        int atEnd = at + name.length();
        if (atEnd < source.length() && Character.isJavaIdentifierPart(source.charAt(atEnd))) continue;
        return true;
      }
    }
    return false;
  }

/** {@code source} = النصُّ الحيُّ إن وُجِدَ، وnull تُقرأ من القرصِ عبرَ كاشِ المحتوى نفسِهِ. */
  public static final class Reinspection {
    public final String fileName;
    public final String reference;
    public final String source;

    public Reinspection(String fileName, String reference, String source) {
      this.fileName = fileName == null ? "" : fileName;
      this.reference = reference == null ? "" : reference;
      this.source = source;
    }
  }

  /**
   * W20′2 — إعادةُ فحصٍ موضعيّةٌ بعدَ إصلاحٍ: تُعيدُ تشخيصاتِ الملفاتِ المذكورةِ وحدَها على خيطِ الفحصِ
   * نفسِهِ (ملفٌّ لا خطأَ فيهِ يعيدُ قائمةً فارغةً فتزولُ علاماتُهُ وحدَهُ)، ولا تمسُّ لقطةَ المشروعِ ولا
   * أولويّتَهُ ولا عدّادَ اكتمالِهِ — فالفحصُ الذي كانَ يعيدُ قراءةَ المشروعِ كلِّهِ ويهدمُ اللوحةَ صارَ
   * بضعَ ملفاتَ تُبدَّلُ صفوفُها في مكانِها. ملفٌّ لا يُعرَفُ لهُ موضعٌ يُترَكُ كما هو (لا كذبَ بالصمتِ).
   */
  public void reinspectFilesAsync(
      ArrayList<Reinspection> items, final ProjectDiagnosticsListener listener) {
    if (listener == null) return;
    if (items == null || items.isEmpty()) {
      mainHandler.post(() -> listener.completed(Collections.<ProjectDiagnostic>emptyList()));
      return;
    }
    final ArrayList<Reinspection> probes = new ArrayList<>(items);
    final String projectKey = symbolProjectKey();
    if (projectDiagnosticsWorker.isShutdown())
      projectDiagnosticsWorker = Executors.newSingleThreadExecutor();
    projectDiagnosticsWorker.execute(
        () -> {
          // حكمُ «عضوٍ مفقودٍ من المنصّةِ» قاطعٌ بقدرِ SDK المشروعِ: يُستعملُ آخرُ ما عُرفَ بهِ.
          almlk.PlatformMemberLookup.setCompileSdk(diagnosticsCompileSdk);
          LinkedHashMap<String, ProjectDiagnostic> unique = new LinkedHashMap<>();
          int manifestRows = 0;
          for (Reinspection probe : probes) {
            if (Thread.currentThread().isInterrupted()) break;
            if (!projectKey.isEmpty() && !projectKey.equals(symbolProjectKey())) return;
            String fileName = probe.fileName;
            String reference = probe.reference;
            String source = probe.source;
            if (source == null) {
              Entry entry = entryForFile(fileName, reference);
              if (entry == null) continue;
              fileName = entry.name;
              reference = referenceForEntry(entry);
              try {
                source = cachedFileContent(fileContentKey(entry));
                if (source == null) {
                  source = readEntryText(entry);
                  if (!source.isEmpty()) cacheFileContent(fileContentKey(entry), source);
                }
              } catch (Throwable ignored) {
                continue;
              }
            }
            if (fileName == null || fileName.isEmpty()
                || source == null || source.isEmpty() || source.length() > 80000) continue;
            try {
              ProjectSymbolIndex.registerSource(fileName, reference, source);
              for (CodeLanguageTools.Diagnostic item : CodeLanguageTools.inspect(fileName, source)) {
                ProjectDiagnostic diagnostic =
                    ProjectDiagnostic.fromSource(fileName, reference, source, item);
                if (diagnostic != null) unique.put(diagnostic.key(), diagnostic);
                if (unique.size() >= MAX_PROJECT_DIAGNOSTICS) break;
              }
            } catch (Throwable ignored) {
              // ملفٌّ لا يُحلَّلُ لا يُبطِلُ فحصَ غيرِهِ
            }
            // وسمُ المانيفستِ يسألُ عن مكوّناتِهِ: ‏`.MainActivity` اسمُهُ الكاملُ بحزمةِ
            // مانيفستِهِ، وإن لم تكنْ حزمَتُهُ حزمةَ هذا المشروعِ المُفهرَسِ لم يُسأَلْ عنها.
            if (fileName.toLowerCase(Locale.US).endsWith("androidmanifest.xml")
                && unique.size() < MAX_PROJECT_DIAGNOSTICS) {
              try {
                String manifestPackage = almlk.AndroidManifestModel.packageOf(source);
                if (!manifestPackage.isEmpty()
                    && ProjectSymbolIndex.isProjectPackage(manifestPackage)) {
                  for (ProjectDiagnostic item : ProjectDiagnostic.fromManifestComponents(
                      fileName, reference, source, ProjectSymbolIndex::knowsClass)) {
                    if (item == null) continue;
                    if (unique.putIfAbsent(item.key(), item) == null
                        && ++manifestRows >= MAX_MANIFEST_ROWS) break;
                  }
                }
              } catch (Throwable ignored) {
                // مكوّنٌ لا يُثبَتُ غيابُهُ لا يُخبَرُ عنهُ
              }
            }
            if (unique.size() >= MAX_PROJECT_DIAGNOSTICS) break;
          }
          ArrayList<ProjectDiagnostic> result = new ArrayList<>(unique.values());
          sortProjectDiagnostics(result);
          final ArrayList<ProjectDiagnostic> found = result;
          mainHandler.post(
              () -> {
                if (!projectKey.isEmpty() && !projectKey.equals(symbolProjectKey())) return;
                listener.completed(found);
              });
        });
  }

  /** هل يعرفُ الفهرسُ هذا الملفَّ؟ بلاهُ يعني: لا تُلمَسُ علاماتُهُ (لا كذبَ بالصمتِ في إعادةِ الفحصِ). */
  public boolean hasFileEntry(String fileName, String reference) {
    return entryForFile(fileName, reference) != null;
  }

  /** Entry ملفٍّ معروفٍ: من فهرسِ البحثِ ثمَّ من المفتوحةِ، فمسحٌ واحدٌ بالمرجعِ عندَ الحاجةِ. */
  private Entry entryForFile(String fileName, String reference) {
    Entry found = fileName == null || fileName.isEmpty() ? null : searchFileCatalog.get(fileName);
    if (found == null && fileName != null && !fileName.isEmpty()) found = openedEntries.get(fileName);
    if (found != null || reference == null || reference.isEmpty()) return found;
    synchronized (searchFileCatalog) {
      for (Entry entry : searchFileCatalog.values()) {
        if (entry != null && almlk.FileReferences.same(reference, referenceForEntry(entry)))
          return entry;
      }
    }
    return null;
  }

  /**
   * R6 — errors at once when a project opens: the findings saved by the last complete scan (for
   * files unchanged since) are handed to {@code listener.progress} before indexing even starts.
   */
  public void restoreProjectDiagnostics(ProjectDiagnosticsListener listener) {
    final String projectKey = symbolProjectKey();
    if (projectKey.isEmpty() || listener == null) return;
    if (diagnosticsSnapshotWorker.isShutdown())
      diagnosticsSnapshotWorker = Executors.newSingleThreadExecutor();
    final ProjectDiagnosticsSnapshot store = diagnosticsSnapshot();
    diagnosticsSnapshotWorker.execute(
        () -> {
          List<ProjectDiagnostic> saved;
          try {
            saved = store.load(
                projectKey,
                ProjectDiagnosticsSnapshot::fileStamp,
                com.almlkid.kay.ui.ProjectSymbolIndex.structureEpoch());
          } catch (Throwable ignored) {
            return;
          }
          if (saved.isEmpty() || !projectKey.equals(symbolProjectKey())) return;
          if (projectKey.equals(scanPublishedKey)) return; // the live scan is already ahead
          final ArrayList<ProjectDiagnostic> snapshot = new ArrayList<>(saved);
          sortProjectDiagnostics(snapshot);
          lastProjectDiagnostics = Collections.unmodifiableList(snapshot);
          lastProjectDiagnosticsKey = projectKey;
          mainHandler.post(
              () -> {
                if (projectKey.equals(symbolProjectKey()) && !projectKey.equals(scanPublishedKey))
                  listener.progress(snapshot);
              });
        });
  }

  /** Fresh findings plus the last known ones of files the running scan has not reached yet. */
  private List<ProjectDiagnostic> mergedProgress(
      String projectKey, Map<String, ProjectDiagnostic> fresh, Set<String> scanned) {
    ArrayList<ProjectDiagnostic> merged;
    synchronized (fresh) {
      merged = new ArrayList<>(fresh.values());
    }
    if (projectKey.equals(lastProjectDiagnosticsKey))
      for (ProjectDiagnostic old : lastProjectDiagnostics)
        if (old != null && !old.fromBuild && !scanned.contains(old.reference)) merged.add(old);
    sortProjectDiagnostics(merged);
    return merged;
  }

  /** Scans indexed Java/XML/Smali sources off the UI thread and emits file-qualified diagnostics. */
  public void scanProjectDiagnosticsAsync(ProjectDiagnosticsListener listener) {
    final String projectKey = symbolProjectKey();
    if (projectKey.isEmpty()) {
      if (listener != null) mainHandler.post(() -> listener.completed(Collections.emptyList()));
      return;
    }
    if (!searchCatalogReady || !projectKey.equals(indexedProjectKey)) {
      // الجولةُ ٣٨: الفتحُ يَطلُبُ المسحَ الآنَ والفهرسةُ جاريةٌ، فيُجمَعُ الطلبُ في قَفزةٍ واحدةٍ
      // إلى ما بعدَ الفهرسِ — مسحتانِ مُتَتابِعتانِ على الفتحِ نفسِهِ ثمنُهما ضِعفُ الوقتِ بلا فائدةٍ.
      if (diagnosticsScanQueued) return;
      diagnosticsScanQueued = true;
      indexProjectSymbols(
          () -> {
            diagnosticsScanQueued = false;
            scanProjectDiagnosticsAsync(listener);
          });
      return;
    }
    diagnosticsScanQueued = false;
    if (projectDiagnosticsWorker.isShutdown())
      projectDiagnosticsWorker = Executors.newSingleThreadExecutor();
    projectDiagnosticsWorker.execute(
        () -> {
          try {
            if (!projectKey.equals(indexedProjectKey)) return;
            ArrayList<Entry> candidates = new ArrayList<>();
            ArrayList<Entry> buildFiles = new ArrayList<>();
            synchronized (searchFileCatalog) {
              for (Entry entry : searchFileCatalog.values()) {
                if (isBuildConfigurationFile(entry) && buildFiles.size() < 16) buildFiles.add(entry);
                if (candidates.size() < MAX_PROJECT_DIAGNOSTIC_FILES && isProjectDiagnosticFile(entry))
                  candidates.add(entry);
              }
            }
            // Stage 4: platform "member not found" is only definitive when this device's API level
            // is at least the project's compileSdk (otherwise newer APIs would look missing).
            int compileSdk = 0;
            for (Entry entry : buildFiles) {
              try {
                compileSdk =
                    Math.max(compileSdk, almlk.PlatformMemberLookup.parseCompileSdk(readEntryText(entry)));
              } catch (Throwable ignored) {
                // An unreadable build file only keeps platform absence non-definitive.
              }
            }
            almlk.PlatformMemberLookup.setCompileSdk(compileSdk);
            diagnosticsCompileSdk = compileSdk;
            final String priority = diagnosticsPriorityReference;
            // الجولةُ ٣٨: المفتوحُ أوَّلًا، ثمَّ ما يَستورِدُهُ المفتوحُ، ثمَّ الباقي أبجديًّا. المرجعُ
            // المفتوحُ يُؤخَذُ من القائمةِ نفسِها بعدَ مطابقةِ {@code FileReferences}، فلا يقارَنُ
            // مسارٌ بمسارٍ بصيغتَيْنِ؛ والسياسةُ كلُّها في {@code ProjectScanPace} يقرَأُها المسحُ
            // وترتيبُ النتائجِ، فلا ترتيبَينِ لمسحٍ واحدٍ.
            String openReference = "";
            for (Entry entry : candidates) {
              String reference = referenceForEntry(entry);
              if (!priority.isEmpty() && almlk.FileReferences.same(priority, reference)) {
                openReference = reference;
                break;
              }
            }
            final String priorityReference = openReference;
            final HashSet<String> scanDependents = dependentsOf(openReference, candidates);
            candidates.sort(
                (a, b) ->
                    almlk.ProjectScanPace.compare(
                        referenceForEntry(a), referenceForEntry(b), priorityReference, scanDependents));
            // Rehydrate source headers even when the persistent symbol cache supplied the basic
            // member index: interface/SDK inheritance uncertainty is not stored in old cache rows.
            // This conservative refresh prevents false missing-method reports for partial SDK APIs.
            for (Entry entry : candidates) {
              if (Thread.currentThread().isInterrupted() || !projectKey.equals(symbolProjectKey())) break;
              if (entry.name == null || !entry.name.toLowerCase(Locale.US).endsWith(".java")) continue;
              try {
                String cacheKey = fileContentKey(entry);
                String source = cachedFileContent(cacheKey);
                if (source == null) {
                  source = readEntryText(entry);
                  if (!source.isEmpty()) cacheFileContent(cacheKey, source);
                }
                if (source != null && source.length() <= 600000)
                  ProjectSymbolIndex.registerSource(entry.name, referenceForEntry(entry), source);
              } catch (Throwable ignored) {
                // A file-level index failure does not block analysis of other files.
              }
            }
            // R6: findings are published as they come (first one at once, then in batches), so the
            // panel fills progressively instead of waiting for the last file.
            // الجولةُ ٣٨: الملفَّاتُ تُفحَصُ في حِزَمٍ على خيوطٍ معدودةٍ — كلُّ ملفٍّ يُشخَّصُ وحدَهُ،
            // والنموذجُ ومَلكُ الأصنافِ مُزامَنانِ أصلًا؛ والسقفُ عامٌّ يَعمَلُ من أوَّلِ مَليءٍ فلا
            // يصيرُ أربعةَ أمثالِهِ بتوازيِ الأرباعِ. قائمةٌ أقصرُ من سقفِ خيطٍ ثانٍ: خيطٌ واحدٌ كما كانَ.
            final int scanWorkers =
                almlk.ProjectScanPace.workerCountFor(
                    candidates.size(), Runtime.getRuntime().availableProcessors());
            final Map<String, ProjectDiagnostic> unique =
                java.util.Collections.synchronizedMap(new LinkedHashMap<String, ProjectDiagnostic>());
            final Set<String> scanned =
                java.util.Collections.synchronizedSet(new HashSet<String>());
            final java.util.concurrent.atomic.AtomicBoolean scanFull =
                new java.util.concurrent.atomic.AtomicBoolean(false);
            final ArrayList<Entry> scanFiles = candidates;
            final int fileCount = scanFiles.size();
            ExecutorService scanPool = scanWorkers > 1 ? Executors.newFixedThreadPool(scanWorkers) : null;
            ArrayList<Future<?>> scanFutures = new ArrayList<>();
            for (int shard = 0; shard < scanWorkers; shard++) {
              final int from = almlk.ProjectScanPace.startOf(shard, fileCount, scanWorkers);
              final int to = almlk.ProjectScanPace.endOf(shard, fileCount, scanWorkers);
              Runnable body =
                  () ->
                      analyseDiagnosticShard(
                          projectKey, scanFiles, from, to, unique, scanned, scanFull);
              if (scanPool == null) body.run();
              else scanFutures.add(scanPool.submit(body));
            }
            long lastProgress = 0;
            int publishedCount = -1;
            while (true) {
              boolean allDone = true;
              for (Future<?> future : scanFutures) {
                if (!future.isDone()) {
                  allDone = false;
                  break;
                }
              }
              int size = unique.size();
              long now = android.os.SystemClock.uptimeMillis();
              if (size != publishedCount
                  && almlk.ProjectScanPace.publishNow(size, now, lastProgress, PROGRESS_INTERVAL_MS)) {
                publishedCount = size;
                lastProgress = now;
                scanPublishedKey = projectKey;
                final List<ProjectDiagnostic> partial = mergedProgress(projectKey, unique, scanned);
                mainHandler.post(
                    () -> {
                      if (projectKey.equals(symbolProjectKey()) && listener != null)
                        listener.progress(partial);
                    });
              }
              if (allDone) break;
              try {
                Thread.sleep(PROGRESS_INTERVAL_MS);
              } catch (InterruptedException interrupted) {
                Thread.currentThread().interrupt();
                break;
              }
            }
            if (scanPool != null) {
              for (Future<?> future : scanFutures) {
                try {
                  future.get();
                } catch (Throwable ignored) {
                  // حِزْمةٌ فشَلَتْ: بقيةُ المشروعِ في نفسِ الوعاءِ، والفحصُ مُستَأنَفٌ عندَ الحفظِ
                }
              }
              scanPool.shutdownNow();
            }
            ArrayList<ProjectDiagnostic> result = new ArrayList<>(unique.values());
            sortProjectDiagnostics(result);
            final ArrayList<ProjectDiagnostic> snapshot = result;
            if (projectKey.equals(symbolProjectKey()) && !Thread.currentThread().isInterrupted()) {
              scanPublishedKey = projectKey;
              lastProjectDiagnostics = Collections.unmodifiableList(new ArrayList<>(result));
              lastProjectDiagnosticsKey = projectKey;
              // الجولةُ ٣٨: ما حُسِبَ والنموذجُ غيرُ جازمٍ لا يُقفَّلُ في القرصِ — سطرٌ وهميٌّ محفوظٌ
              // على ملفٍّ لم يتغيَّرْ يُرى عندَ الفتحِ التالي خطأً لا يُبرَّرُ. يُعرَضُ في الجلسةِ ويُترَكُ.
              if (almlk.ProjectScanPace.mayPersistSnapshot(almlk.JavaProjectModel.absenceProvablyComplete())) {
                try {
                  diagnosticsSnapshot().save(projectKey, result,
                  ProjectDiagnosticsSnapshot::fileStamp,
                  com.almlkid.kay.ui.ProjectSymbolIndex.structureEpoch());
                } catch (Throwable ignored) {
                  // the snapshot only speeds up the next open
                }
              }
            }
            mainHandler.post(
                () -> {
                  if (projectKey.equals(symbolProjectKey()) && listener != null)
                    listener.completed(snapshot);
                });
          } catch (Throwable ignored) {
            mainHandler.post(
                () -> {
                  if (projectKey.equals(symbolProjectKey()) && listener != null)
                    listener.completed(Collections.emptyList());
                });
          }
        });
  }

  /**
   * حِزْمةٌ من مرشَّحي المسحِ: قراءةٌ من الكاشِ أو القرصِ ثمَّ تشخيصاتٌ إلى وعاءٍ مُشتَرَكٍ. لا قراءةَ
   * ثانيةً ولا ترتيبًا داخلَ الحِزْمةِ — الترتيبُ كلُّهُ صنَعَهُ {@code candidates.sort} قبلَ التوزيعِ،
   * فأيُّ ملفٍّ يُفحَصُ وحدَهُ بصيغةٍ لا تعرفُ مَن يسبِقُهُ. والإلغاءُ مُراعىً كما في الخيطِ الواحدِ:
   * مفتاحُ المشروعِ تغيَّرَ أو قُطِعَ الخيطُ رجَعَتِ الحِزْمةُ بما فرَغَ منهُ لا بأكثرَ.
   */
  private void analyseDiagnosticShard(
      String projectKey,
      ArrayList<Entry> files,
      int from,
      int to,
      Map<String, ProjectDiagnostic> unique,
      Set<String> scanned,
      java.util.concurrent.atomic.AtomicBoolean full) {
    for (int i = from; i < to; i++) {
      if (full.get()) return;
      if (Thread.currentThread().isInterrupted() || !projectKey.equals(symbolProjectKey())) return;
      Entry entry = files.get(i);
      scanned.add(referenceForEntry(entry));
      String source;
      try {
        String cacheKey = fileContentKey(entry);
        source = cachedFileContent(cacheKey);
        if (source == null) {
          source = readEntryText(entry);
          if (!source.isEmpty()) cacheFileContent(cacheKey, source);
        }
      } catch (Throwable ignored) {
        continue;
      }
      if (source == null || source.isEmpty() || source.length() > 80000) continue;
      try {
        List<CodeLanguageTools.Diagnostic> found = CodeLanguageTools.inspect(entry.name, source);
        String reference = referenceForEntry(entry);
        for (CodeLanguageTools.Diagnostic item : found) {
          ProjectDiagnostic diagnostic =
              ProjectDiagnostic.fromSource(entry.name, reference, source, item);
          if (diagnostic == null) continue;
          synchronized (unique) {
            unique.put(diagnostic.key(), diagnostic);
            if (unique.size() >= MAX_PROJECT_DIAGNOSTICS) full.set(true);
          }
        }
      } catch (Throwable ignored) {
        // A malformed or unsupported source must not stop diagnostics in other files.
      }
      if (full.get()) return;
    }
  }

  /**
   * ما يَستورِدُهُ الملفُّ المفتوحُ من أصنافِ المشروعِ: أسماءُ الأصنافِ في أسطرِ ‏`import`‏ تُرجَمُ
   * بمَلكِ الأصنافِ نفسِهِ إلى مراجعَ، فيصيرُ «الملفُّ المفتوحُ ومكتباتُهُ» طبقةً في الطابورِ لا حدسًا.
   * صنفٌ خارجيٌّ أو غيرُ مَفهرَسٍ لا يُرجِمُ شيئًا: قائمةُ انتظارٍ بلا مُنتظَرٍ، ولا قراءةَ قرصٍ هنا
   * سوى نصِّ المفتوحِ — وقد كَفَّاهُ الكاشُ غالبًا.
   */
  private HashSet<String> dependentsOf(String openReference, ArrayList<Entry> candidates) {
    HashSet<String> out = new HashSet<>();
    if (openReference == null || openReference.isEmpty()) return out;
    String text = null;
    for (Entry entry : candidates) {
      if (!almlk.FileReferences.same(openReference, referenceForEntry(entry))) continue;
      try {
        String cacheKey = fileContentKey(entry);
        text = cachedFileContent(cacheKey);
        if (text == null) text = readEntryText(entry);
      } catch (Throwable ignored) {
        return out;
      }
      break;
    }
    if (text == null || text.isEmpty()) return out;
    for (String imported : ProjectSymbolIndex.importsOf(text)) {
      if (imported == null || imported.isEmpty()) continue;
      String className = imported.substring(imported.lastIndexOf('.') + 1);
      Entry owner;
      synchronized (symbolFiles) {
        owner = symbolFiles.get(className);
      }
      if (owner != null) out.add(referenceForEntry(owner));
    }
    return out;
  }

  private static boolean isBuildConfigurationFile(Entry entry) {
    if (entry == null || entry.name == null) return false;
    String name = entry.name.replace('\\', '/');
    name = name.substring(name.lastIndexOf('/') + 1).toLowerCase(Locale.US);
    return name.equals("build.gradle") || name.equals("build.gradle.kts")
        || name.equals("project.properties");
  }

  /** Resolves compiler paths back to project entries and attaches exact source ranges. */
  public void resolveBuildDiagnosticsAsync(
      List<BuildDiagnosticsParser.BuildError> errors, ProjectDiagnosticsListener listener) {
    final String projectKey = symbolProjectKey();
    if (errors == null || errors.isEmpty() || projectKey.isEmpty()) {
      if (listener != null) mainHandler.post(() -> listener.completed(Collections.emptyList()));
      return;
    }
    final ArrayList<BuildDiagnosticsParser.BuildError> snapshot = new ArrayList<>(errors);
    if (!searchCatalogReady || !projectKey.equals(indexedProjectKey)) {
      indexProjectSymbols(() -> resolveBuildDiagnosticsAsync(snapshot, listener));
      return;
    }
    if (projectDiagnosticsWorker.isShutdown())
      projectDiagnosticsWorker = Executors.newSingleThreadExecutor();
    projectDiagnosticsWorker.execute(
        () -> {
          if (!projectKey.equals(indexedProjectKey)) return;
          LinkedHashMap<String, ProjectDiagnostic> unique = new LinkedHashMap<>();
          for (BuildDiagnosticsParser.BuildError error : snapshot) {
            if (!projectKey.equals(symbolProjectKey())) break;
            Entry entry = findBuildEntry(error.fileName);
            String source = "";
            String fileName = error.fileName;
            String reference = error.fileName;
            if (entry != null) {
              fileName = entry.name;
              reference = referenceForEntry(entry);
              try {
                String cacheKey = fileContentKey(entry);
                source = cachedFileContent(cacheKey);
                if (source == null) {
                  source = readEntryText(entry);
                  if (!source.isEmpty()) cacheFileContent(cacheKey, source);
                }
              } catch (Throwable ignored) {
                source = "";
              }
            }
            ProjectDiagnostic diagnostic = ProjectDiagnostic.fromBuild(fileName, reference, source, error);
            if (diagnostic != null) unique.put(diagnostic.key(), diagnostic);
            if (unique.size() >= MAX_PROJECT_DIAGNOSTICS) break;
          }
          ArrayList<ProjectDiagnostic> result = new ArrayList<>(unique.values());
          sortProjectDiagnostics(result);
          mainHandler.post(
              () -> {
                if (projectKey.equals(symbolProjectKey()) && listener != null)
                  listener.completed(result);
              });
        });
  }

  /** سقفُ صفوفِ المانيفستِ في المسحةِ الواحدةِ: المكوّناتُ كثيرةٌ في المشاريعِ الكبيرةِ. */
  private static final int MAX_MANIFEST_ROWS = 24;

  private boolean isProjectDiagnosticFile(Entry entry) {
    if (entry == null || entry.folder || entry.name == null) return false;
    String name = entry.name.toLowerCase(Locale.US);
    return name.endsWith(".java") || name.endsWith(".xml") || name.endsWith(".smali");
  }

  private void sortProjectDiagnostics(List<ProjectDiagnostic> values) {
    values.sort(
        (a, b) -> {
          int file = a.groupKey().compareToIgnoreCase(b.groupKey());
          if (file != 0) return file;
          int line = Integer.compare(a.diagnostic.line, b.diagnostic.line);
          return line != 0 ? line : Integer.compare(a.diagnostic.column, b.diagnostic.column);
        });
  }

  /** داخلَ جذرٍ أعلنَهُ المشروعُ وحدَهُ — لا كلُّ مسارٍ مقروءٍ على القرصِ. */
  private boolean isUnderLinkedRoot(String candidatePath) {
    String[] prefixes = linkedRootPrefixes;
    if (prefixes.length == 0 || candidatePath == null) return false;
    for (String prefix : prefixes) {
      if (candidatePath.equals(prefix) || candidatePath.startsWith(prefix + File.separator)) return true;
    }
    return false;
  }

  private Entry findBuildEntry(String reportedPath) {
    if (reportedPath == null || reportedPath.trim().isEmpty()) return null;
    String wanted = reportedPath.trim().replace('\\', '/');
    if (wanted.startsWith("file://")) wanted = android.net.Uri.decode(wanted.substring(7));
    File root = projectFile;
    if (root != null) {
      try {
        File rootCanonical = root.getCanonicalFile();
        File candidate = new File(wanted);
        if (!candidate.isAbsolute()) candidate = new File(rootCanonical, wanted);
        candidate = candidate.getCanonicalFile();
        String rootPath = rootCanonical.getPath();
        String candidatePath = candidate.getPath();
        if (candidate.isFile()
            && (candidatePath.equals(rootPath)
                || candidatePath.startsWith(rootPath + File.separator)
                || isUnderLinkedRoot(candidatePath))) {
          String reference = candidatePath.replace('\\', '/');
          synchronized (searchFileCatalog) {
            Entry existing = searchFileCatalog.get(reference);
            if (existing != null) return existing;
            Entry direct = new Entry(candidate.getName(), candidate, null, false, iconFor(candidate.getName()), 0);
            searchFileCatalog.put(reference, direct);
            return direct;
          }
        }
      } catch (Exception ignored) {
        // Fall back to the already indexed catalog; never follow compiler paths outside the project.
      }
    }
    Entry exact = null;
    Entry uniqueName = null;
    int sameName = 0;
    synchronized (searchFileCatalog) {
      for (Entry entry : searchFileCatalog.values()) {
        String reference = referenceForEntry(entry).replace('\\', '/');
        String name = entry.name == null ? "" : entry.name.replace('\\', '/');
        if (reference.equals(wanted)) return entry;
        if (reference.endsWith("/" + wanted)) exact = entry;
        if (name.equals(new File(wanted).getName())) {
          uniqueName = entry;
          sameName++;
        }
      }
    }
    if (exact != null) return exact;
    return sameName == 1 ? uniqueName : null;
  }

  // تقرير 05 — كاش LRU صغير لآخر عمليات التنقل الدقيقة (exact lookup شبه فوري عند التكرار).
  private final java.util.LinkedHashMap<String, ProjectSymbolIndex.DefinitionTarget>
      definitionLookupCache =
          new java.util.LinkedHashMap<String, ProjectSymbolIndex.DefinitionTarget>(
              16, 0.75f, true) {
            @Override
            protected boolean removeEldestEntry(
                java.util.Map.Entry<String, ProjectSymbolIndex.DefinitionTarget> eldest) {
              return size() > 8;
            }
          };

  /** Resolves a definition after the complete project index is available. */
  public interface XmlResourceListener {
    void completed(
        almlk.XmlResourceReference reference, almlk.XmlResourceIndex.Declaration declaration);
  }

  /** جذر المشروع في وضع الملفات المباشرة؛ {@code null} في وضع شجرة المستندات (SAF). */
  public File projectRootFile() {
    return projectFile;
  }

  /**
   * حلّ مرجع مورد XML من جذر المشروع — المرحلة السابعة.
   *
   * <p>الفهرسة والقراءة على خيط خلفي حصرًا (لا I/O على خيط الواجهة)، والنتيجة تُبث على
   * الخيط الرئيسي. {@code declaration == null} يعني أن المرجع مقروء لكنه غير معرّف في {@code res/}.
   */
  public void resolveXmlResourceAsync(String source, int offset, XmlResourceListener listener) {
    final File root = projectFile;
    if (symbolWorker.isShutdown()) symbolWorker = Executors.newSingleThreadExecutor();
    symbolWorker.execute(
        () -> {
          almlk.XmlResourceReference reference = null;
          almlk.XmlResourceIndex.Declaration declaration = null;
          try {
            reference = almlk.XmlResourceReference.at(source, offset);
            if (reference != null && root != null) {
              declaration =
                  almlk.XmlResourceIndex.build(root, extraResourceRoots(root)).lookup(reference);
            }
          } catch (Throwable ignored) {
            declaration = null;
          }
          final almlk.XmlResourceReference resolved = reference;
          final almlk.XmlResourceIndex.Declaration found = declaration;
          mainHandler.post(
              () -> {
                if (listener != null) listener.completed(resolved, found);
              });
        });
  }

  public void findDefinitionAsync(
      String fileName,
      String source,
      int selectionStart,
      int selectionEnd,
      DefinitionSearchListener listener) {
    // W21′2: بصمةُ البنيةِ في المفتاحِ — بعدَ حذفِ عضوٍ أو إضافتِهِ تُبطَلُ نتيجةُ قفزةٍ سابقةٍ،
    // فذاكرةُ البحثِ لا تُعيدُ نقلَ المستخدمِ إلى تعريفٍ لم يعُدْ هو (كُنَّا نَعِدُّ النصَّ وحدَهُ).
    final String cacheKey =
        fileName + "@" + selectionStart + ":" + selectionEnd
            + "#" + (source == null ? 0 : source.hashCode())
            + "#" + ProjectSymbolIndex.structureEpoch();
    synchronized (definitionLookupCache) {
      ProjectSymbolIndex.DefinitionTarget cached = definitionLookupCache.get(cacheKey);
      if (cached != null) {
        mainHandler.post(() -> {
          if (listener != null) listener.completed(cached);
        });
        return;
      }
    }
    symbolWorker.execute(
        () -> {
          if (symbolFiles.isEmpty()) buildSymbolIndex();
          ProjectSymbolIndex.DefinitionTarget target =
              ProjectSymbolIndex.resolveDefinition(fileName, source, selectionStart, selectionEnd);
          if (target != null) {
            synchronized (definitionLookupCache) {
              definitionLookupCache.put(cacheKey, target);
            }
          }
          if (target == null) {
            // W21′2: لا قفزةَ على اسمٍ وحدَهُ. كانَ الفهرسُ يُمرَّرُ على كلِّ ملفٍّ حتى يوافقَ اسمًا،
            // فيُفتَحُ صنفٌ وارِثٌ لا يملِكُ العضوَ — والقفزةُ الغلطُ أخطرُ من لا قفزةٍ لأنَّها تُقنِعُ
            // القارئَ بأنَّ التعريفَ هناك. بقيَ المرجعُ الأخيرُ النصَّ المحلِّيَّ وحدَهُ: تعريفٌ في الملفِّ
            // نفسِهِ لا يحتاجُ تفسيرَ أنواعٍ ولا يُنقَلُ فيهِ إلى ملفٍّ آخَر. وما سوى ذلكَ لا شيءَ،
            // فيُنبِّهُ المستدعي «لا يمكنُ تحديدُ الكودِ المحددِ» كما يصنعُ المرجعُ، ولا يتحرَّكُ محرِّرٌ.
            String symbol = UsageSearchEngine.identifierAt(source, selectionStart, selectionEnd);
            int offset = UsageSearchEngine.findDeclarationOffset(source, symbol);
            if (offset >= 0)
              target = new ProjectSymbolIndex.DefinitionTarget(fileName, "", symbol, null, offset, false);
          }
          final ProjectSymbolIndex.DefinitionTarget result = target;
          mainHandler.post(() -> {
            if (listener != null) listener.completed(result);
          });
        });
  }

  /** Searches indexed project symbols without rescanning source files for every query. */
  public void searchSymbolsAsync(String query, SymbolSearchListener listener) {
    searchSymbolsAsync(query, true, listener);
  }

  public void searchSymbolsAsync(
      String query, boolean includeSystem, SymbolSearchListener listener) {
    final String wanted = query == null ? "" : query.trim();
    final int request = ++projectSearchGeneration;
    if (symbolSearchTask != null) symbolSearchTask.cancel(true);
    symbolSearchTask = symbolSearchWorker.submit(() -> {
      boolean cancelled = request != projectSearchGeneration || Thread.currentThread().isInterrupted();
      final List<ProjectSymbolIndex.DefinitionTarget> immediate =
          cancelled || wanted.isEmpty()
              ? Collections.emptyList()
              : searchSymbolsNow(wanted, includeSystem);
      mainHandler.post(() -> {
        if (request == projectSearchGeneration && listener != null)
          listener.completed(immediate, cancelled);
      });
      // Return the active-file suggestions immediately, then refresh the same query as soon as
      // the background project index becomes ready. No keystroke waits for a full disk traversal.
      if (!cancelled && !searchCatalogReady) {
        long deadline = android.os.SystemClock.uptimeMillis() + 4000;
        while (request == projectSearchGeneration
            && !Thread.currentThread().isInterrupted()
            && !searchCatalogReady
            && android.os.SystemClock.uptimeMillis() < deadline) {
          try {
            Thread.sleep(16);
          } catch (InterruptedException interrupted) {
            Thread.currentThread().interrupt();
            break;
          }
        }
      }
      boolean ready = request == projectSearchGeneration
          && !Thread.currentThread().isInterrupted()
          && searchCatalogReady
          && !wanted.isEmpty();
      if (ready) {
        final List<ProjectSymbolIndex.DefinitionTarget> refreshed =
            searchSymbolsNow(wanted, includeSystem);
        mainHandler.post(() -> {
          if (request == projectSearchGeneration && listener != null)
            listener.completed(refreshed, false);
        });
      }
    });
  }

  /**
   * Searches the metadata catalog built during project indexing. File contents remain lazy, while
   * repeated searches skip directory traversal and open each candidate through the bounded cache.
   */
  public void searchProjectAsync(
      ProjectSearchEngine.Query query, ProjectSearchListener listener) {
    if (query == null || query.isEmpty()) {
      if (listener != null) mainHandler.post(() -> listener.completed(Collections.emptyList(), 0, false));
      return;
    }
    final int request = ++projectSearchGeneration;
    if (projectSearchTask != null) projectSearchTask.cancel(true);
    projectSearchTask = symbolWorker.submit(() -> {
      if (!searchCatalogReady) buildSymbolIndex();
      LinkedHashMap<String, Entry> candidates = new LinkedHashMap<>();
      synchronized (searchFileCatalog) {
        candidates.putAll(searchFileCatalog);
      }
      synchronized (openedEntries) {
        for (Entry entry : openedEntries.values()) {
          if (entry != null && isSearchableTextFile(entry))
            candidates.put(referenceForEntry(entry), entry);
        }
      }
      ArrayList<UsageSearchEngine.Usage> results = new ArrayList<>();
      int filesScanned = 0;
      for (Entry item : candidates.values()) {
        if (filesScanned >= 5000
            || results.size() >= query.maxResults
            || request != projectSearchGeneration
            || Thread.currentThread().isInterrupted()) break;
        if (item == null || !isSearchableTextFile(item)) continue;
        filesScanned++;
        String cacheKey = fileContentKey(item);
        String source = cachedFileContent(cacheKey);
        if (source == null) {
          source = readEntryText(item);
          cacheFileContent(cacheKey, source);
        }
        int remaining = Math.max(1, query.maxResults - results.size());
        ProjectSearchEngine.Query fileQuery =
            remaining == query.maxResults
                ? query
                : new ProjectSearchEngine.Query(
                    query.text,
                    query.caseSensitive,
                    query.wholeWord,
                    query.regularExpression,
                    remaining);
        results.addAll(
            ProjectSearchEngine.search(
                item.name,
                referenceForEntry(item),
                source,
                fileQuery,
                () -> request != projectSearchGeneration || Thread.currentThread().isInterrupted()));
      }
      boolean cancelled = request != projectSearchGeneration || Thread.currentThread().isInterrupted();
      final int scanned = filesScanned;
      final ArrayList<UsageSearchEngine.Usage> found = results;
      mainHandler.post(() -> {
        if (request == projectSearchGeneration && listener != null)
          listener.completed(found, scanned, cancelled);
      });
    });
  }

  public void cancelProjectSearch() {
    projectSearchGeneration++;
    if (projectSearchTask != null) projectSearchTask.cancel(true);
    if (symbolSearchTask != null) symbolSearchTask.cancel(true);
  }

  private boolean isSearchableTextFile(Entry entry) {
    if (entry == null || entry.folder || entry.name == null) return false;
    if (entry.size > ProjectSearchEngine.DEFAULT_MAX_FILE_BYTES) return false;
    String lower = entry.name.toLowerCase(Locale.US);
    int dot = lower.lastIndexOf('.');
    if (dot < 0) return lower.equals("readme") || lower.equals("license") || lower.equals("makefile");
    String extension = lower.substring(dot);
    return extension.equals(".java")
        || extension.equals(".smali")
        || extension.equals(".kt")
        || extension.equals(".kts")
        || extension.equals(".xml")
        || extension.equals(".gradle")
        || extension.equals(".properties")
        || extension.equals(".json")
        || extension.equals(".csv")
        || extension.equals(".txt")
        || extension.equals(".md")
        || extension.equals(".yaml")
        || extension.equals(".yml")
        || extension.equals(".html")
        || extension.equals(".css")
        || extension.equals(".js")
        || extension.equals(".ts")
        || extension.equals(".c")
        || extension.equals(".cc")
        || extension.equals(".cpp")
        || extension.equals(".h")
        || extension.equals(".hpp")
        || extension.equals(".sh")
        || extension.equals(".sql")
        || extension.equals(".toml")
        || extension.equals(".pro");
  }

  private boolean skipSearchFolder(String name) {
    if (name == null) return true;
    String lower = name.toLowerCase(Locale.US);
    return lower.equals(".git")
        || lower.equals(".gradle")
        || lower.equals("build")
        || lower.equals("out")
        || lower.equals("target")
        || lower.equals("node_modules")
        || lower.equals(".idea")
        || lower.equals(".cxx")
        || lower.equals("captures");
  }

  /** Scans project source files off the UI thread and returns bounded usage results. */
  // ===== أماكن التواجد: بث تدريجي سريع بمنفذ مستقل — نفس مبدأ المرجع: مخازن حية أولًا =====
  private ExecutorService usageWorker = Executors.newSingleThreadExecutor();
  private ExecutorService usageReadPool = Executors.newFixedThreadPool(4);
  private volatile int usageSearchGeneration;

  public void findUsagesAsync(
      String fileName,
      String source,
      int selectionStart,
      int selectionEnd,
      UsageListener listener) {
    final String symbol = UsageSearchEngine.identifierAt(source, selectionStart, selectionEnd);
    if (symbol.isEmpty()) {
      if (listener != null)
        mainHandler.post(() -> listener.completed(Collections.emptyList(), true));
      return;
    }
    final int request = ++usageSearchGeneration;
    if (usageWorker.isShutdown()) usageWorker = Executors.newSingleThreadExecutor();
    if (usageReadPool.isShutdown()) usageReadPool = Executors.newFixedThreadPool(4);
    usageWorker.execute(
        () -> {
          // القوائم متزامنة: عمال القراءة الأربعة يضيفون إليها بالتوازي.
          final List<UsageSearchEngine.Usage> collected =
              Collections.synchronizedList(new ArrayList<>());
          final java.util.Set<String> seen =
              Collections.synchronizedSet(new java.util.HashSet<>());
          try {
            // المرحلة 1: الملف النشط بنصه الحي — نتائج فورية قبل أي قرص (مخازن المرجع الحية).
            if (source != null && fileName != null) {
              for (UsageSearchEngine.Usage usage :
                  UsageSearchEngine.findUsages(
                      fileName, fileReference(fileName), source, symbol, selectionStart)) {
                if (usage != null && seen.add(usage.fileName + "@" + usage.offset))
                  collected.add(usage);
              }
              postUsages(listener, request, collected, false);
            }
            if (!searchCatalogReady) buildSymbolIndex();
            if (request != usageSearchGeneration) return;
            // جرد موحّد بالمرجع القانوني: نفس الملف الفيزيائي يُفحص مرة واحدة فقط.
            LinkedHashMap<String, Entry> files = new LinkedHashMap<>();
            synchronized (searchFileCatalog) {
              for (Entry entry : searchFileCatalog.values()) {
                if (entry != null && !entry.folder) files.put(referenceForEntry(entry), entry);
              }
            }
            synchronized (symbolFiles) {
              for (Entry entry : symbolFiles.values()) {
                if (entry != null && !entry.folder) files.put(referenceForEntry(entry), entry);
              }
            }
            synchronized (openedEntries) {
              for (Entry entry : openedEntries.values()) {
                if (entry != null && !entry.folder) files.put(referenceForEntry(entry), entry);
              }
            }
            // المرحلة 2: المكاشة فورًا (ذاكرة فقط)، والقرص يؤجل لطابور القراءة المتوازية.
            final java.util.concurrent.ConcurrentLinkedQueue<Entry> diskQueue =
                new java.util.concurrent.ConcurrentLinkedQueue<>();
            for (Entry entry : files.values()) {
              if (request != usageSearchGeneration) return;
              String lower = entry.name.toLowerCase(Locale.US);
              if (!(lower.endsWith(".java") || lower.endsWith(".kt"))) continue;
              if (source != null && entry.name.equals(fileName)) continue; // فُحص حيًا.
              String cached = cachedFileContent(fileContentKey(entry));
              if (cached != null) {
                scanUsageText(entry, cached, symbol, seen, collected);
              } else {
                diskQueue.add(entry);
              }
            }
            postUsages(listener, request, collected, false);
            // المرحلة 3: القرص بأربعة خيوط قراءة + بث خانق كل ~80ms حتى تتدفق النتائج.
            final int workers = 4;
            final java.util.concurrent.CountDownLatch doneLatch =
                new java.util.concurrent.CountDownLatch(workers);
            for (int n = 0; n < workers; n++) {
              usageReadPool.execute(
                  () -> {
                    try {
                      Entry entry;
                      while ((entry = diskQueue.poll()) != null) {
                        if (request != usageSearchGeneration
                            || Thread.currentThread().isInterrupted()) break;
                        if (collected.size() >= 1000) break;
                        String text;
                        try {
                          String cacheKey = fileContentKey(entry);
                          text = cachedFileContent(cacheKey);
                          if (text == null) {
                            text = readEntryText(entry);
                            cacheFileContent(cacheKey, text);
                          }
                        } catch (Throwable unreadable) {
                          continue; // ملف متعذر القراءة لا يوقف بقية المسح أبدًا.
                        }
                        scanUsageText(entry, text, symbol, seen, collected);
                      }
                    } finally {
                      doneLatch.countDown();
                    }
                  });
            }
            int lastPublished = collected.size();
            while (!doneLatch.await(80, java.util.concurrent.TimeUnit.MILLISECONDS)) {
              if (request != usageSearchGeneration) return;
              if (collected.size() != lastPublished) {
                lastPublished = collected.size();
                postUsages(listener, request, collected, false);
              }
            }
          } catch (Throwable ignored) {
            // البث النهائي في finally يضمن ألا تعلق اللوحة على حالة وسيطة مهما حدث.
          } finally {
            postUsages(listener, request, collected, true);
          }
        });
  }

  /** مسح نص واحد وإضافة نتائجه بلا تكرار (نفس الملف والإزاحة لا يظهران مرتين أبدًا). */
  private void scanUsageText(
      Entry entry,
      String text,
      String symbol,
      java.util.Set<String> seen,
      List<UsageSearchEngine.Usage> collected) {
    if (text == null || collected.size() >= 1000) return;
    String reference = referenceForEntry(entry);
    for (UsageSearchEngine.Usage usage :
        UsageSearchEngine.findUsages(entry.name, reference, text, symbol, -1)) {
      if (usage != null && seen.add(usage.fileName + "@" + usage.offset)) collected.add(usage);
      if (collected.size() >= 1000) break;
    }
  }

  /** بث لقطة مفروزة ملف‑فملف (ترتيب المرجع الحتمي) إلى خيط الواجهة. */
  private void postUsages(
      UsageListener listener, int request, List<UsageSearchEngine.Usage> collected, boolean done) {
    if (listener == null) return;
    final ArrayList<UsageSearchEngine.Usage> snapshot;
    synchronized (collected) {
      snapshot = new ArrayList<>(collected);
    }
    snapshot.sort(
        (a, b) -> {
          int byFile = a.fileName.compareToIgnoreCase(b.fileName);
          return byFile != 0 ? byFile : Integer.compare(a.offset, b.offset);
        });
    mainHandler.post(
        () -> {
          // طلب ملغى لا يبث شيئًا — الطلب الأحدث هو من يملك اللوحة الآن.
          if (request == usageSearchGeneration) listener.completed(snapshot, done);
        });
  }

  /** Opens a usage result lazily and returns its source plus the exact offset. */
  public void openUsageAsync(
      UsageSearchEngine.Usage usage, DefinitionOpenListener listener) {
    if (usage == null) return;
    symbolWorker.execute(
        () -> {
          Entry target = null;
          synchronized (openedEntries) {
            target = openedEntries.get(usage.fileName);
          }
          if (target == null) {
            synchronized (searchFileCatalog) {
              if (!usage.reference.isEmpty()) target = searchFileCatalog.get(usage.reference);
              if (target == null)
                for (Entry candidate : searchFileCatalog.values()) {
                  if (candidate != null
                      && usage.fileName.equals(candidate.name)
                      && (usage.reference.isEmpty() || usage.reference.equals(referenceForEntry(candidate)))) {
                    target = candidate;
                    break;
                  }
                }
            }
          }
          if (target == null) {
            synchronized (symbolFiles) {
              for (Entry candidate : symbolFiles.values()) {
                if (candidate != null
                    && usage.fileName.equals(candidate.name)
                    && (usage.reference.isEmpty() || usage.reference.equals(referenceForEntry(candidate)))) {
                  target = candidate;
                  break;
                }
              }
            }
          }
          if (target == null) {
            mainHandler.post(
                () -> {
                  if (listener != null)
                    listener.completed(false, usage.fileName, null, 0, ui("ui_usage_open_failed"));
                });
            return;
          }
          String text = readEntryTextOrNull(target);
          if (text == null) {
            // مسارُ الفشلِ حرفيًّا كما عندَ المرجعِ: المُستقبِلُ يُظهِرُ «could not be loaded!» ولا
            // يَغلِقُ اللوحةَ ولا يَحقنُ نصًّا فارغًا؛ ولا يُخزَّنُ مُدخَلٌ لم يُقرَأْ كيلا يُعادَ عليهِ الثقةُ.
            final String failedPath = usage.reference.isEmpty() ? usage.fileName : usage.reference;
            mainHandler.post(
                () -> {
                  if (listener != null) listener.completed(false, failedPath, null, 0, null);
                });
            return;
          }
          openedEntries.put(target.name, target);
          final Entry opened = target;
          mainHandler.post(
              () -> {
                if (listener != null)
                  listener.completed(
                      true,
                      opened.name,
                      text,
                      Math.min(usage.offset, text.length()),
                      uiFormat("ui_usage_opened_at_line", usage.line));
              });
        });
  }

  private String referenceForEntry(Entry entry) {
    if (entry == null) return "";
    return entry.documentUri != null
        ? entry.documentUri.toString()
        : entry.file == null ? "" : entry.file.getAbsolutePath();
  }

  private String symbolProjectKey() {
    if (projectDocumentUri != null) return "uri:" + projectDocumentUri;
    if (projectFile != null) return "file:" + projectFile.getAbsolutePath();
    return "";
  }

  private Entry findDefinitionEntry(ProjectSymbolIndex.DefinitionTarget definition) {
    if (definition == null) return null;
    synchronized (searchFileCatalog) {
      if (definition.reference != null && !definition.reference.isEmpty()) {
        Entry exact = searchFileCatalog.get(definition.reference);
        if (exact != null) return exact;
        for (Entry candidate : searchFileCatalog.values())
          if (candidate != null && definition.reference.equals(referenceForEntry(candidate))) return candidate;
      }
    }
    synchronized (symbolFiles) {
      Entry byClass = symbolFiles.get(definition.className);
      if (byClass != null) return byClass;
      if (definition.fileName != null)
        for (Entry candidate : symbolFiles.values())
          if (candidate != null && definition.fileName.equals(candidate.name)) return candidate;
    }
    if (definition.fileName != null) {
      synchronized (searchFileCatalog) {
        for (Entry candidate : searchFileCatalog.values())
          if (candidate != null && definition.fileName.equals(candidate.name)) return candidate;
      }
    }
    return null;
  }

  public void openDefinition(
      ProjectSymbolIndex.DefinitionTarget definition, DefinitionOpenListener listener) {
    if (definition == null) {
      if (listener != null) listener.completed(false, null, null, 0, ui("ui_definition_not_found"));
      return;
    }
    if (definition.source != null) {
      // كما في المرجع: كلاس يملك ملف مصدر حقيقي في المشروع لا يُعرض أبدًا كهيكل ‎.class —
      // يُفتح مصدره الكامل (استيرادات وتلوين) ويُقفز للرمز فيه.
      symbolWorker.execute(
          () -> {
            Entry real = null;
            String wantedFile =
                (definition.className == null || definition.className.isEmpty()
                        ? definition.symbol
                        : definition.className)
                    + ".java";
            synchronized (symbolFiles) {
              Entry candidate = symbolFiles.get(definition.className);
              if (candidate != null && !candidate.folder) real = candidate;
            }
            if (real == null) {
              synchronized (searchFileCatalog) {
                for (Entry candidate : searchFileCatalog.values()) {
                  if (candidate != null && !candidate.folder
                      && wantedFile.equals(candidate.name)) {
                    real = candidate;
                    break;
                  }
                }
              }
            }
            if (real != null) {
              try {
                String cacheKey = fileContentKey(real);
                String source = cachedFileContent(cacheKey);
                if (source == null) {
                  source = readEntryText(real);
                  cacheFileContent(cacheKey, source);
                }
                int at = UsageSearchEngine.findDeclarationOffset(source, definition.symbol);
                openedEntries.put(real.name, real);
                final Entry opened = real;
                final String text = source;
                final int offset = Math.max(0, at);
                mainHandler.post(
                    () -> {
                      if (listener != null)
                        listener.completed(
                            true, opened.name, text, offset,
                            uiFormat("ui_definition_opened", definition.symbol));
                    });
                return;
              } catch (Throwable ignored) {
                // تعذر فتح المصدر الحقيقي → العرض الافتراضي أدناه.
              }
            }
            mainHandler.post(
                () -> {
                  if (listener != null)
                    listener.completed(
                        true,
                        definition.fileName,
                        definition.source,
                        definition.offset,
                        ui("ui_system_definition_opened"));
                });
          });
      return;
    }
    symbolWorker.execute(
        () -> {
          Entry target = findDefinitionEntry(definition);
          if (target == null) {
            buildSymbolIndex();
            target = findDefinitionEntry(definition);
          }
          if (target == null) {
            mainHandler.post(
                () -> {
                  if (listener != null)
                    listener.completed(
                        false,
                        definition.fileName,
                        null,
                        0,
                        uiFormat("ui_definition_file_not_found", definition.symbol));
                });
            return;
          }
          String source = readEntryText(target);
          openedEntries.put(target.name, target);
          final Entry opened = target;
          mainHandler.post(
              () -> {
                if (listener != null)
                  listener.completed(
                      true,
                      opened.name,
                      source,
                      Math.min(definition.offset, source.length()),
                      uiFormat("ui_definition_opened", definition.symbol));
              });
        });
  }

  /** المرحلة 3: تحويل يطبّق على نص صنف من القرص؛ يعيد null إن لم يلزم أي تعديل. */
  public interface SourceEdit {
    String apply(String source);
  }

  /** يجد ملف الصنف عبر فهرس الرموز (يبنيه عند الحاجة) ويقرأ نصه في الخلفية لعرض التأكيد. */
  public void locateClassSource(String className, MutationListener listener) {
    symbolWorker.execute(
        () -> {
          Entry target = classEntry(className);
          if (target == null) {
            postMutation(listener, false, null, null, uiFormat("ui_class_file_not_found", className));
            return;
          }
          openedEntries.put(target.name, target);
          postMutation(listener, true, target.name, readEntryText(target), "");
        });
  }

  /**
   * يعيد قراءة ملف الصنف لحظة التطبيق (لا لقطة باهتة) ويمرره على {@code edit} ثم يكتبه ذريًا
   * ويحدّث الفهرس الدائم وكاش المحتوى. لا كتابة إن أعاد التحويل null.
   */
  public void editClassSource(String className, SourceEdit edit, MutationListener listener) {
    symbolWorker.execute(
        () -> {
          Entry target = classEntry(className);
          if (target == null) {
            postMutation(listener, false, null, null, uiFormat("ui_class_file_not_found", className));
            return;
          }
          String source = readEntryText(target);
          String updated;
          try {
            updated = edit == null ? null : edit.apply(source);
          } catch (Throwable error) {
            updated = null;
          }
          if (updated == null) {
            postMutation(listener, false, target.name, source, ui("ui_method_already_exists"));
            return;
          }
          if (!writeEntryText(target, updated)) {
            postMutation(listener, false, target.name, null, ui("ui_class_file_edit_failed"));
            return;
          }
          persistJavaIndex(target, updated);
          cacheFileContent(fileContentKey(target), updated);
          openedEntries.put(target.name, target);
          postMutation(listener, true, target.name, updated, "");
        });
  }

  private Entry classEntry(String className) {
    Entry target;
    synchronized (symbolFiles) {
      target = symbolFiles.get(className);
    }
    if (target == null) {
      buildSymbolIndex();
      synchronized (symbolFiles) {
        target = symbolFiles.get(className);
      }
    }
    return target;
  }

  private void persistJavaIndex(Entry entry, String source) {
    if (entry == null || entry.folder || entry.name == null
        || !entry.name.toLowerCase(Locale.US).endsWith(".java")) return;
    String reference = referenceForEntry(entry);
    ProjectSymbolIndex.registerSource(entry.name, reference, source == null ? "" : source);
    List<ProjectSymbolIndex.CachedClass> parsed =
        ProjectSymbolIndex.cachedClassesForFile(entry.name, reference);
    long size = entry.file != null ? entry.file.length() : EncodingManager.encodeUtf8(source == null ? "" : source).length;
    long modified = entry.file != null ? entry.file.lastModified() : System.currentTimeMillis();
    entry.size = size;
    entry.modified = modified;
    if (symbolIndexStore != null) {
      try {
        symbolIndexStore.save(
            symbolProjectKey(), reference, entry.name, reference, size, modified, parsed);
      } catch (Throwable ignored) {
      }
    }
    synchronized (symbolFiles) {
      for (ProjectSymbolIndex.CachedClass owner : parsed) symbolFiles.put(owner.name, entry);
    }
  }

  /**
   * المسحة كلها داخل {@code beginPass}/{@code endPass}: ما دام الفهرسة جاريةً أو تركت ملفًا بلا قراءة
   * يمتنع على التحليل الجزم بغياب رمز (1.0.130 — «Unknown entity» الكاذبة على أصناف المشروع).
   */
  private void buildSymbolIndex() {
    almlk.JavaProjectModel.beginPass();
    try {
      collectSymbolIndex();
    } finally {
      almlk.JavaProjectModel.endPass();
    }
  }

  private void collectSymbolIndex() {
    ProjectSymbolIndex.clear();
    synchronized (symbolFiles) {
      symbolFiles.clear();
    }
    synchronized (searchFileCatalog) {
      searchFileCatalog.clear();
      searchCatalogReady = false;
    }
    final String projectKey = symbolProjectKey();
    indexedProjectKey = projectKey;
    HashSet<String> visitedSymbolFiles = new HashSet<>();
    ArrayDeque<Entry> queue = new ArrayDeque<>();
    Entry root = null;
    if (projectDocumentUri != null)
      root = new Entry(nameForUri(projectDocumentUri), projectDocumentUri, true, -1, R.drawable.folder);
    else if (projectFile != null)
      root = new Entry(projectFile.getName(), projectFile, null, true, R.drawable.folder, 0);
    if (root == null) return;
    queue.add(root);
    drainSymbolQueue(queue, root, visitedSymbolFiles, projectKey, 10000);
    ArrayDeque<Entry> linked = new ArrayDeque<>();
    seedLinkedSourceRoots(linked, projectFile);
    if (!linked.isEmpty())
      drainSymbolQueue(linked, null, visitedSymbolFiles, projectKey, LINKED_VISIT_BUDGET);
    if (!queue.isEmpty() || !linked.isEmpty()) {
      // المسحة توقّفت (حدّ الملفات أو انقطاع الخيط): ما لم يُمَرّ عليه ليس دليلًا على عدم وجوده.
      almlk.JavaProjectModel.notePassGap();
    }
    if (symbolIndexStore != null && !projectKey.isEmpty()) {
      try {
        symbolIndexStore.pruneProject(projectKey, visitedSymbolFiles);
      } catch (Throwable ignored) {
      }
    }
    if (!Thread.currentThread().isInterrupted()) {
      synchronized (searchFileCatalog) {
        searchCatalogReady = true;
      }
      warmUsageCacheAsync();
    }
  }

  /**
   * مسحُ طابورٍ واحدٍ إلى فهرسِ الرموزِ: تُجرَى بهِ شجرةُ المشروعِ أولًا ثمَّ جذورُ الوحداتِ
   * المرتبطةِ خارجَهُ — بالفلاترِ نفسِها (الامتدادُ، ورفضُ أدواتِ العملِ، ودفعُ الكاشِ، وتفريقُ
   * المكرَّرِ بـvisitedSymbolFiles) وبسقفٍ لكلِّ طابورٍ: فلا تجوعُ شجرةُ المشروعِ ولا تُهمَلُ
   * الوحدةُ أبدًا. وما يُترَكُ لسقفٍ يعلنُ لهُ JavaProjectModel نقصَهُ كما كانَ.
   */
  private void drainSymbolQueue(ArrayDeque<Entry> queue, Entry allowedRoot,
      HashSet<String> visitedSymbolFiles, String projectKey, int budget) {
    int visited = 0;
    while (!queue.isEmpty() && visited < budget && !Thread.currentThread().isInterrupted()) {
    Entry item = queue.removeFirst();
    visited++;
    // نبضةُ المسحِ (الجولةُ ‏33، قـ١): المشروعُ الكبيرُ يُمسَحُ أكثرَ من PASS_STALE_MS، وما دامَ
    // الماسحُ يَنبِضُ فاليقينُ بالغيابِ ممنوعٌ — لا يُفتَحُ البابُ لمجرّدِ طولِ العمرِ.
    if ((visited & 31) == 0) almlk.JavaProjectModel.notePassProgress();
    if (item.folder) {
      if (item != allowedRoot && skipSearchFolder(item.name)) continue;
      if (item.documentUri != null) {
        try {
          for (Entry child : queryDocumentChildren(item.documentUri)) queue.addLast(child);
        } catch (Exception unreadableFolder) {
          // مجلد لم يُقرأ = نموذج أنقص: لا يجوز بعده الجزم بغياب رمز.
          almlk.JavaProjectModel.notePassGap();
        }
      } else {
        List<Entry> children = queryFileChildren(item.file);
        if (children != null) queue.addAll(children);
      }
      continue;
    }
    if (isSearchableTextFile(item)) {
      synchronized (searchFileCatalog) {
        searchFileCatalog.put(referenceForEntry(item), item);
      }
    }
    if (item.name.toLowerCase(Locale.US).endsWith(".kt")) almlk.JavaProjectModel.noteForeignSource();
    if (!item.name.toLowerCase(Locale.US).endsWith(".java")) continue;

    String reference = referenceForEntry(item);
    // W21′2: أداةُ العملِ ليست مصدرَ المشروعِ. مجلدُ الاختبارِ على المضيفِ والتقاويرُ ومخرَجُ
    // البناءِ كلُّها تُقرأُ وتُعرَضُ وتُبحثُ (سُجِّلَت في الفهرسِ البحثيِّ فوقَ هذا مباشرةً) ولا
    // تُفهرَسُ رموزًا — وإلا صارَ qa/host-stubs/android/content/Context.java «تعريفَ» Context.
    // الاستثناءُ ملفٌّ لا مجلدٌ، فلا يُفقَدُ شيءٌ من البحثِ في الملفاتِ؛ والرفضُ لتسجيلِ الرمزِ
    // وحدَهُ، فمَن فتحَ ملفًّا من تلكَ المجلداتِ يراهُ ويعدّلُهُ كغيرِهِ.
    if (almlk.ProjectSourceRoots.skipIndexingFor(reference)) continue;
    String fileKey = reference;
    visitedSymbolFiles.add(fileKey);
    List<ProjectSymbolIndex.CachedClass> cached = null;
    if (symbolIndexStore != null) {
      try {
        cached =
            symbolIndexStore.loadIfFresh(
                projectKey, fileKey, item.name, reference, item.size, item.modified);
      } catch (Throwable ignored) {
        cached = null;
      }
    }
    // Last-resort bulkhead: indexing is best-effort, so a single pathological file (or a
    // low-memory moment) must never be able to crash the app with an escaping Error.
    try {
      if (cached != null) {
        for (ProjectSymbolIndex.CachedClass owner : cached)
          ProjectSymbolIndex.registerCachedClass(owner);
      } else {
        String source = readEntryText(item);
        // النص قُرئ للفهرسة أصلًا — تخزينه يجعل بحث الاستخدامات التالي ذاكرة فقط.
        cacheFileContent(fileContentKey(item), source);
        ProjectSymbolIndex.registerSource(item.name, reference, source);
        List<ProjectSymbolIndex.CachedClass> parsed =
            ProjectSymbolIndex.cachedClassesForFile(item.name, reference);
        if (symbolIndexStore != null) {
          try {
            symbolIndexStore.save(
                projectKey, fileKey, item.name, reference, item.size, item.modified, parsed);
          } catch (Throwable ignored) {
            // A cache failure must never prevent the source index from being available in RAM.
          }
        }
        cached = parsed;
      }
    } catch (Throwable indexFailure) {
      cached = null;
      almlk.JavaProjectModel.notePassGap();
    }
    if (cached != null && !almlk.JavaProjectModel.knows(reference)) {
      // الكاش يخبرنا أن الملف لم يتغيّر منذ آخر مسحة — لا أن نموذج هذه العملية يعرفه. فليُقرأ وليُسجَّل
      // وإلا غابت أصنافه عن الحلّ فبُلّغ عنها «Unknown entity» و«Unknown type of field» كذبًا.
      try {
        String source = readEntryText(item);
        cacheFileContent(fileContentKey(item), source);
        ProjectSymbolIndex.registerSource(item.name, reference, source);
      } catch (Throwable unreadable) {
        almlk.JavaProjectModel.notePassGap();
      }
    }
    if (cached != null) {
      synchronized (symbolFiles) {
        for (ProjectSymbolIndex.CachedClass owner : cached)
          symbolFiles.put(owner.name, item);
      }
    }
    if (visited % 20 == 0 && Thread.currentThread().isInterrupted()) break;
    }
  }

  /**
   * جذورُ مصادرِ الوحداتِ المعلَنةِ خارجَ جذرِ المتصفّحِ. تُحَلُّ هنا — على خيطِ الفهرسةِ — لأنَّ
   * ‏sourceDirs() تمسُّ القرصَ، ولا قرصَ في خيطِ الواجهةِ. وما كانَ تحتَ جذرِ المشروعِ يُتجاوَزُ:
   * شجرَتُهُ تُمسَحُ بالفعلِ، وإلا ضاعَ نصفُ السقفِ في مشيٍ مكرَّرٍ. ومسارُ المشروعِ المُسنَدُ
   * يُطابَقُ مع مسارِ هذهِ النافذةِ، فلا تُفهرَسُ وحداتُ مشروعٍ آخرِ بعدَ تبديلِهِ.
   */
  private void seedLinkedSourceRoots(ArrayDeque<Entry> into, File ownRoot) {
    linkedRootPrefixes = new String[0]; // لا بقايا مشروعٍ سابقٍ في مطابقةِ المساراتِ
    java.util.function.Supplier<java.util.List<File>> resolver = linkedSourceRoots;
    if (resolver == null) return;
    if (ownRoot != null && !canonicalPath(ownRoot).equals(linkedRootsProjectPath)) return;
    java.util.List<File> dirs;
    try {
      dirs = resolver.get();
    } catch (RuntimeException unavailable) {
      // نموذجٌ يُقفَلُ أو قرصٌ لا يُقرأ: بلا وحداتَ هذهِ المسحةَ، ولا كذبَ بغيابِ رمزٍ.
      almlk.JavaProjectModel.notePassGap();
      return;
    }
    if (dirs == null || dirs.isEmpty()) return;
    ArrayList<String> prefixes = new ArrayList<>();
    String ownPrefix = ownRoot == null ? "" : canonicalPath(ownRoot) + "/";
    for (File dir : dirs) {
      // لا سقفَ هنا: السقفُ سياسةُ الطبقةِ الصافيةِ (sourceDirs)، والمشيُ مقصورٌ على budgetَ الطابورِ.
      if (dir == null || !dir.isDirectory()) continue;
      String path = canonicalPath(dir);
      if (!ownPrefix.isEmpty() && (path + "/").startsWith(ownPrefix)) continue;
      prefixes.add(path);
      int slash = path.lastIndexOf('/');
      into.addLast(new Entry(slash < 0 ? path : path.substring(slash + 1), dir, null, true,
          R.drawable.folder, 0));
    }
    // ومجلداتُ الوحداتِ التي تُقرأُ منها المواردُ: هي الأخرى معلَنةٌ، فما فيها (‏`res`،
    // ‏`assets`، المانيفستُ) ملفٌّ للمشروعِ يُفتَحُ من اللوحةِ لا من نافذةٍ جديدةٍ.
    java.util.function.Supplier<java.util.List<File>> resources = linkedResourceRoots;
    if (resources != null
        && (ownRoot == null || canonicalPath(ownRoot).equals(linkedResourceProjectPath))) {
      try {
        java.util.List<File> extra = resources.get();
        if (extra != null) {
          for (File dir : extra) {
            if (dir == null || !dir.isDirectory()) continue;
            String path = canonicalPath(dir);
            if (!ownPrefix.isEmpty() && (path + "/").startsWith(ownPrefix)) continue;
            if (!prefixes.contains(path)) prefixes.add(path);
          }
        }
      } catch (RuntimeException unavailable) {
        // لا شيءَ زائدًا هذهِ المرةَ: المطابقةُ تبقى على ما حُمِلَ من مصادرَ
      }
    }
    linkedRootPrefixes = prefixes.toArray(new String[0]);
  }

  /** ‏canonical بلا انفعالٍ: مسارٌ لا يُقرأ يُستعمَلُ كما هو، فالمقارنةُ لا القرارُ. */
  private static String canonicalPath(File file) {
    try {
      return file.getCanonicalPath();
    } catch (java.io.IOException unreadable) {
      return file.getAbsolutePath();
    }
  }

  /**
   * تسخين خلفي صامت: يقرأ كل ملفات ‎.java/.kt غير المكاشة إلى كاش المحتوى فور جاهزية
   * الكاتالوج — فيعمل أول «أماكن تواجد» من الذاكرة مباشرة كمخازن المرجع الحية.
   */
  private void warmUsageCacheAsync() {
    final java.util.concurrent.ConcurrentLinkedQueue<Entry> queue =
        new java.util.concurrent.ConcurrentLinkedQueue<>();
    synchronized (searchFileCatalog) {
      for (Entry entry : searchFileCatalog.values()) {
        if (entry == null || entry.folder) continue;
        String lower = entry.name.toLowerCase(Locale.US);
        if (lower.endsWith(".java") || lower.endsWith(".kt")) queue.add(entry);
      }
    }
    if (queue.isEmpty()) return;
    if (usageReadPool.isShutdown()) usageReadPool = Executors.newFixedThreadPool(4);
    for (int n = 0; n < 4; n++) {
      usageReadPool.execute(
          () -> {
            Entry entry;
            while ((entry = queue.poll()) != null) {
              if (Thread.currentThread().isInterrupted()) return;
              try {
                String cacheKey = fileContentKey(entry);
                if (cachedFileContent(cacheKey) != null) continue;
                cacheFileContent(cacheKey, readEntryText(entry));
              } catch (Throwable ignored) {
                // التسخين أفضل جهد — ملف متعذر لا يوقف البقية.
              }
            }
          });
    }
  }

  private String readEntryText(Entry entry) {
    String text = readEntryTextOrNull(entry);
    return text == null ? "" : text;
  }

  /**
   * نصُّ المُدخَلِ، أو {@code null} عندَ تعذُّرِ القراءةِ. كانَ المسارُ كلُّهُ يَبتَلِعُ الاستثناءَ في
   * {@code ""} فيُفتَحُ تبويبٌ فارغٌ ويُبلَّغُ «نجاحٌ»؛ والمطلوبُ (ورقةُ هذهِ الجولةِ §١٫٤، ومُسارُ
   * ‏{@code MainActivity.m401j6} عندَ المرجعِ) فشلٌ صريحٌ يُروَى بنصِّهِ لا جَهلٌ مُزيَّنٌ. طبقةُ
   * {@code null} مُنفَصِلَةٌ عن {@link #readEntryText} عمدًا: ستةَ عشرَ مُستَعمِلًا آخَرُ يَقرَأُ
   * نصَّ الفهرسِ والتجميعِ ولا يَنبَغي أن يَرَى {@code null}، والقارئُ الذي يُخبِرُ المستخدمَ وحدَهُ
   * يَستَعمِلُ هذهِ.
   */
  private String readEntryTextOrNull(Entry entry) {
    try {
      InputStream input =
          entry.documentUri != null
              ? getContext().getContentResolver().openInputStream(entry.documentUri)
              : new FileInputStream(entry.file);
      return input == null
          ? null
          : EncodingManager.readUtf8(input, EncodingManager.DEFAULT_MAX_BYTES);
    } catch (Exception error) {
      return null; // لا «ملفٌّ فارغٌ»: تعذَّرَ تحميلُهُ، وهذا كُلُّ ما نَعلَمُهُ
    }
  }

  /** كتابة ذرية للملفات المباشرة (ملف مؤقت مجاور ثم إعادة تسمية)؛ SAF يُكتب باقتطاع "wt". */
  private boolean writeEntryText(Entry entry, String content) {
    byte[] bytes = EncodingManager.encodeUtf8(content);
    if (entry.documentUri != null) {
      try (OutputStream output =
          getContext().getContentResolver().openOutputStream(entry.documentUri, "wt")) {
        if (output == null) return false;
        output.write(bytes);
        output.flush();
        return true;
      } catch (Exception error) {
        return false;
      }
    }
    if (entry.file == null) return false;
    java.io.File temp = new java.io.File(entry.file.getParentFile(), "." + entry.file.getName() + ".shima-tmp");
    try (FileOutputStream output = new FileOutputStream(temp, false)) {
      output.write(bytes);
      output.flush();
      output.getFD().sync();
    } catch (Exception error) {
      temp.delete();
      return false;
    }
    if (temp.renameTo(entry.file)) return true;
    temp.delete();
    return false;
  }

  private void postMutation(
      MutationListener listener, boolean success, String name, String content, String message) {
    if (listener != null)
      mainHandler.post(() -> listener.completed(success, name, content, message));
  }

  private boolean canReadDirectStorage() {
    return android.os.Build.VERSION.SDK_INT < 30 || Environment.isExternalStorageManager();
  }

  public boolean needsProjectFolderSelection() {
    return !usingDocuments && !canReadDirectStorage();
  }

  private void loadFile(File directory) {
    loadFile(directory, 0);
  }

  /** «الانتقال إلى مجلد» (أدوات › أخرى): يعرض المجلد كما هو دون ضغط السلاسل الأحادية. */
  public boolean showDirectory(File directory) {
    if (directory == null || !directory.isDirectory()) return false;
    loadFile(directory, COMPACT_HOP_LIMIT);
    return true;
  }

  /** صعود «..»: إعادة الضغط معطّلة عبر تمرير عدّاد القفزات ممتلئًا سلفًا. */
  private void loadFileUp(File directory) {
    loadFile(directory, COMPACT_HOP_LIMIT);
  }

  /**
   * تقرير AIDE — بناء الشجرة (بند 4): «ضغط المجلدات وحيدة الفرع».
   * إن كان المجلد يحوي ابنًا واحدًا فقط وهو مجلد، ننزل داخله تلقائيًا (بحد أقصى 4 قفزات)
   * فيُقفز مسار مثل com/example/app دفعة واحدة بدل ثلاث نقرات. سلسلة النزول كلها في خيط
   * الخلفية بلا قفزات للرئيسي، وزر «..» النهائي يشير إلى ما فوق السلسلة ككل.
   */
  /** حدّ أقصى للنزول المتسلسل — يمنع الحلقات ويكبح التمريرات العميقة المريبة. */
  private static final int COMPACT_HOP_LIMIT = 4;

  private void loadFile(File directory, int compactHops) {
    rememberScrollPosition();
    usingDocuments = false;
    currentFile = directory;
    currentDocument = null;
    pathLabel.setText(shortPath(directory));
    persistCurrentDir(directory);
    if (!canReadDirectStorage()) {
      entries.clear();
      entries.add(
          new Entry(
              ui("ui_choose_folder_to_show_files"),
              null,
              null,
              false,
              R.drawable.folder_open,
              ACTION_SELECT_TREE));
      entries.add(
          new Entry(
              ui("ui_permissions_grant_all_files"),
              null,
              null,
              false,
              R.drawable.folder_open,
              ACTION_PERMISSION));
      notifyList();
      return;
    }
    final int request = ++navigationGeneration;
    final List<Entry> cached = cachedDirectory(fileCacheKey(directory));
    if (cached != null) {
      Entry single = compactHops < COMPACT_HOP_LIMIT ? singleChildFolder(cached) : null;
      if (single != null) {
        loadFile(single.file, compactHops + 1);
        return;
      }
      showFileEntries(directory, cached, request);
      return;
    }
    showLoadingEntry();
    directoryReader.execute(
        () -> {
          File dir = directory;
          int hops = compactHops;
          List<Entry> loaded = queryFileChildren(dir);
          if (loaded != null) cacheDirectory(fileCacheKey(dir), loaded);
          while (hops < COMPACT_HOP_LIMIT) {
            Entry single = singleChildFolder(loaded);
            if (single == null) break;
            dir = single.file;
            List<Entry> next = cachedDirectory(fileCacheKey(dir));
            if (next == null) {
              next = queryFileChildren(dir);
              if (next != null) cacheDirectory(fileCacheKey(dir), next);
            }
            loaded = next;
            hops++;
          }
          final File finalDir = dir;
          final List<Entry> finalLoaded = loaded;
          mainHandler.post(() -> showCompactedFileEntries(finalDir, finalLoaded, request));
        });
  }

  /** عتبة الضغط: ابن وحيد وهو مجلد (لا ملفات، لا صفوف أوامر). */
  private Entry singleChildFolder(List<Entry> children) {
    if (children == null || children.size() != 1) return null;
    Entry only = children.get(0);
    if (only == null || !only.folder || only.action != 0 || only.file == null) return null;
    return only.file.isDirectory() ? only : null;
  }

  /** عرض نتيجة سلسلة النزول: ضبط الحالة للمجلد العميق ثم الرسم المعتاد. */
  private void showCompactedFileEntries(File directory, List<Entry> children, int request) {
    if (request != navigationGeneration) return;
    currentFile = directory;
    currentDocument = null;
    pathLabel.setText(shortPath(directory));
    showFileEntries(directory, children, request);
  }

  private List<Entry> queryFileChildren(File directory) {
    File[] files;
    try {
      files = directory.listFiles();
    } catch (SecurityException error) {
      return null;
    }
    if (files == null) return null;
    ArrayList<Entry> result = new ArrayList<>(files.length);
    for (File file : files) {
      String name = file.getName();
      boolean folder = file.isDirectory();
      result.add(
          new Entry(name, file, null, folder, folder ? folderIconFor(name) : iconFor(name), 0, 0));
    }
    result.sort(BrowserPager::compareEntries);
    return result;
  }

  private void showFileEntries(File directory, List<Entry> children, int request) {
    if (request != navigationGeneration || currentFile == null || !currentFile.equals(directory))
      return;
    entries.clear();
    if (directory.getParentFile() != null)
      entries.add(
          new Entry(
              "..", directory.getParentFile(), null, true, R.drawable.folder_open, ACTION_UP_FILE));
    boolean projectsHome = directory.getName().equals("AppProjects");
    if (projectsHome)
      entries.add(
          new Entry(
              ui("ui_select_project_folder_entry"),
              null,
              null,
              false,
              R.drawable.folder_open,
              ACTION_SELECT_TREE));
    // المرجع: صفا الإنشاء والاستنساخ في مجلد المشاريع فقط؛ جذر المشروع يعرض صفّي الخصائص والإضافة.
    if (projectsHome) {
      entries.add(
          new Entry(
              ui("ui_new_project_entry"),
              null,
              null,
              false,
              R.drawable.ic_launcher_java,
              ACTION_CREATE_PROJECT));
      entries.add(
          new Entry(
              ui("ui_clone_git_entry"), null, null, false, R.drawable.browser_git, ACTION_CLONE));
    }
    if (isProjectRoot(directory)) addProjectRows(directory);
    // أوامر المرجع السياقية: تظهر فقط حيث لها معنى — كما في AIDE تمامًا.
    String directoryPath = directory.getAbsolutePath().replace('\\', '/');
    if (isJavaSourceDir(directoryPath))
      entries.add(
          new Entry(
              ui("ui_new_class_entry"),
              null,
              null,
              false,
              R.drawable.file_type_java,
              ACTION_NEW_CLASS));
    if (isResSubDir(directoryPath))
      entries.add(
          new Entry(
              ui("ui_new_xml_entry"), null, null, false, R.drawable.file_type_xml, ACTION_NEW_XML));
    if (isProjectRoot(directory) && (projectFile == null || !directory.equals(projectFile)))
      entries.add(
          new Entry(
              ui("ui_open_project_entry"),
              directory,
              null,
              false,
              R.drawable.ic_launcher_java,
              ACTION_OPEN_PROJECT));
    if (children == null) {
      entries.add(
          new Entry(
              ui("ui_choose_folder_to_show_files"),
              null,
              null,
              false,
              R.drawable.folder_open,
              ACTION_SELECT_TREE));
      entries.add(
          new Entry(
              ui("ui_permissions_grant_all_files"),
              null,
              null,
              false,
              R.drawable.folder_open,
              ACTION_PERMISSION));
    } else if (children.isEmpty()) {
      entries.add(
          new Entry(ui("ui_empty_folder"), null, null, false, R.drawable.folder_open, ACTION_EMPTY));
    } else {
      entries.addAll(children);
    }
    notifyList();
    restoreScrollPosition(fileCacheKey(directory));
    if (children != null) prefetchFileChildren(children);
  }

  /** حفظ موضع تمرير المجلد المعروض حاليًا قبل مغادرته — بنية المرجع. */
  private void rememberScrollPosition() {
    if (displayedLocationKey != null && list != null)
      scrollPositions.put(displayedLocationKey, list.getFirstVisiblePosition());
  }

  /** استعادة موضع المجلد عند العودة إليه، أو البداية لمجلد يُزار أول مرة. */
  private void restoreScrollPosition(String key) {
    displayedLocationKey = key;
    if (list == null) return;
    Integer saved = scrollPositions.get(key);
    list.setSelection(saved != null && saved >= 0 && saved < entries.size() ? saved : 0);
  }

  private void prefetchFileChildren(List<Entry> children) {
    ArrayList<File> folders = new ArrayList<>();
    for (Entry entry : children) {
      if (entry.folder && entry.file != null && folders.size() < 8) folders.add(entry.file);
    }
    if (folders.isEmpty()) return;
    directoryReader.execute(
        () -> {
          for (File folder : folders) {
            String key = fileCacheKey(folder);
            synchronized (directoryCache) {
              if (directoryCache.containsKey(key) || !prefetching.add(key)) continue;
            }
            try {
              List<Entry> result = queryFileChildren(folder);
              if (result != null) cacheDirectory(key, result);
            } finally {
              synchronized (directoryCache) {
                prefetching.remove(key);
              }
            }
          }
        });
  }

  private void notifyList() {
    ((BaseAdapter) list.getAdapter()).notifyDataSetChanged();
  }

  private void showHeaderMenu(View anchor) {
    PopupMenu menu = new PopupMenu(getContext(), anchor);
    final boolean detailsVisible = showFileDetails();
    final int[] ids = {201, 202, 203, 204, 205, 206, 208, 207};
    final String[] keys = {
      "ui_header_file_new",
      "ui_header_folder_new",
      "ui_action_refresh",
      detailsVisible ? "ui_toggle_file_details_hide" : "ui_toggle_file_details_show",
      "ui_select_project_folder_entry",
      "ui_copy_folder_path",
      "command_files_show_projects",
      "ui_grant_file_access"
    };
    for (int i = 0; i < ids.length; i++)
      menu.getMenu().add(0, ids[i], i, ui(keys[i]));
    menu.setOnMenuItemClickListener(
        item -> {
          switch (item.getItemId()) {
            case 201:
              createFileContextually();
              break;
            case 202:
              promptCreate(true);
              break;
            case 203:
              refresh();
              break;
            case 204:
              setShowFileDetails(!showFileDetails());
              break;
            case 205:
              if (actions != null) actions.onSelectProjectFolder();
              break;
            case 206:
              copyCurrentPath();
              break;
            case 207:
              if (actions != null) actions.onStoragePermissionRequested();
              break;
            case 208:
              showProjectsFolder();
              break;
            default:
              return false;
          }
          return true;
        });
    menu.show();
  }

  // ======== المرحلة هـ: قائمة الضغط المطول المطابقة لـfilebrowser_context_menu ========

  /** قائمة الضغط المطول — بنود المرجع مفلترة حسب السياق (ملف/مجلد/وضع الوصول). */
  private void showEntryMenu(View anchor, Entry e) {
    PopupMenu menu = new PopupMenu(getContext(), anchor);
    Menu popup = menu.getMenu();
    popup.add(0, 301, 0, ui("ui_rename_context"));
    popup.add(0, 302, 1, ui("ui_delete_context"));
    popup.add(0, 303, 2, ui("ui_copy_path_context"));
    popup.add(0, 304, 3, ui("ui_show_projects_context"));
    final String activeName = currentEditorFileName();
    final String activeReference =
        activeName == null || activeName.isEmpty() ? "" : fileReference(activeName);
    final boolean canShowCurrent =
        activeReference != null
            && activeReference.startsWith("/")
            && new File(activeReference).getParentFile() != null
            && new File(activeReference).getParentFile().isDirectory();
    if (canShowCurrent) popup.add(0, 305, 4, ui("ui_show_current_file_context"));
    final boolean directFolder = e.folder && e.file != null && !usingDocuments;
    if (directFolder) {
      String path = e.file.getAbsolutePath().replace('\\', '/');
      if (isJavaSourceDir(path)) popup.add(0, 306, 5, ui("ui_new_class_entry"));
      else if (isResDir(path)) popup.add(0, 307, 6, ui("ui_new_xml_entry"));
      popup.add(0, 308, 7, ui("ui_header_file_new"));
      popup.add(0, 309, 8, ui("ui_header_folder_new"));
      popup.add(0, 310, 9, ui("ui_new_project_entry"));
      // W22/4ب٢: بنَدا المرجعِ في القائمةِ نفسِها («Add library to project» و«Remove library
      // from project»). لا قرصَ هنا: صلاحيةُ المجلدِ تُفهَمُ في الخيطِ العاملِ عندَ النقرِ،
      // فلا تُبطَأُ القائمةُ ولا يُمسُّ خيطُ الواجهةِ.
      popup.add(0, 311, 10, ui("ui_browser_add_library"));
      popup.add(0, 312, 11, ui("ui_browser_remove_library"));
    } else if (e.folder && usingDocuments) {
      popup.add(0, 308, 7, ui("ui_header_file_new"));
      popup.add(0, 309, 8, ui("ui_header_folder_new"));
    }
    // W22/5د: بندُ المرجعِ في القائمةِ نفسِها — «Install» لمِلفِّ ‏apk‏ عندَهم (‏FileOptions‏).
    // لا شاشةَ جديدةً ولا نُقطةَ ثانيةَ: النقرُ يَبني قرارًا في ‏almlk/ApkInstallPlan‏ ثمَّ نِيةً
    // واحدةً. والفلترةُ بالسياقِ كما في بقيّةِ البنودِ: ملفٌّ، لا مجلدٌ، واسمُهُ ينتهي بـ‏.apk‏.
    if (!e.folder && e.file != null && e.name != null
        && e.name.toLowerCase(Locale.US).endsWith(".apk")) {
      popup.add(0, 313, 5, ui("ui_install_apk_entry"));
    }
    menu.setOnMenuItemClickListener(
        item -> {
          switch (item.getItemId()) {
            case 301:
              promptRename(e);
              break;
            case 302:
              confirmDelete(e);
              break;
            case 303:
              copyEntryPath(e);
              break;
            case 304:
              showProjectsFolder();
              break;
            case 305:
              if (canShowCurrent)
                loadFile(new File(activeReference).getParentFile());
              break;
            case 306:
              promptCreateClass(e.file);
              break;
            case 307:
              promptCreateXml(e.file);
              break;
            case 308:
              promptCreate(false, directFolder ? e.file : null);
              break;
            case 309:
              promptCreate(true, directFolder ? e.file : null);
              break;
            case 310:
              if (actions != null) actions.onCreateProject();
              break;
            case 311:
              confirmLinkLibrary(e.file, true);
              break;
            case 312:
              confirmLinkLibrary(e.file, false);
              break;
            case 313:
              installApk(e.file);
              break;
            default:
              return false;
          }
          return true;
        });
    menu.show();
  }

  /**
   * W22/5د: التثبيتُ من القائمةِ — قرارٌ صافٍ ثمَّ نِيةٌ واحدةٌ، على وَفقِ سبيلِ غيرِ الجذرِ في
   * ‏`abcd.lk.j6(String)` (‏`535054`‏): ‏VIEW‏، وصيغةُ الحزمةِ، ومُوفِّرٌ فوقَ الإصدارِ الرابعِ
   * والعِشرِينَ ‏`file://` تحتَهُ، وإقرارُ قراءةٍ، ثمَّ ‏startActivity‏ داخلَ ‏try/catch‏. لا
   * ‏PackageInstaller‏ ولا ‏ProgressDialog‏ ولا نَسخَ للملفِّ ولا ‏su: ما بعدَ النِّيةِ شأنُ
   * مُثبِّتِ النظامِ، وما قبلَها حسابٌ لا عَمليّةٌ.
   */
  private void installApk(File apk) {
    final int sdk = android.os.Build.VERSION.SDK_INT;
    boolean permitted = true;
    if (sdk >= almlk.ApkInstallPlan.API_INSTALL_PERMISSIONS) {
      try {
        permitted = getContext().getPackageManager().canRequestPackageInstalls();
      } catch (Throwable denied) {
        permitted = false;
      }
    }
    almlk.ApkInstallPlan.Plan plan =
        almlk.ApkInstallPlan.of(apk, sdk, permitted, getContext().getPackageName());
    if (!plan.ready) {
      toast(installMessage(plan));
      return;
    }
    android.net.Uri uri;
    try {
      uri = plan.authority == null ? android.net.Uri.fromFile(apk)
          : androidx.core.content.FileProvider.getUriForFile(getContext(), plan.authority, apk);
    } catch (Throwable unprovided) {
      toast(ui("ui_install_apk_no_provider"));
      return;
    }
    final android.content.Intent intent = new android.content.Intent(plan.action)
        .setDataAndType(uri, plan.mime)
        .addFlags(plan.flags);
    java.util.List<android.content.pm.ResolveInfo> found = null;
    try {
      found = getContext().getPackageManager().queryIntentActivities(intent, 0);
    } catch (Throwable ignored) {
      found = null;
    }
    java.util.List<String> names = new java.util.ArrayList<String>();
    if (found != null) {
      for (android.content.pm.ResolveInfo info : found) {
        names.add(info == null || info.activityInfo == null ? null : info.activityInfo.packageName);
      }
    }
    // كما في ‏535162:‏ إن كانَ مُثبِّتُ النظامِ حاضرًا فُرِضَ؛ وإلا تركناهُ يَختارُ — لا قائمةَ
    // مُختلَقةً ولا ترتيبًا مُرتَجَلًا.
    String pinned = almlk.ApkInstallPlan.installerChoice(names);
    if (pinned != null && found != null) {
      for (android.content.pm.ResolveInfo info : found) {
        if (info == null || info.activityInfo == null) continue;
        if (pinned.equals(info.activityInfo.packageName)) {
          intent.setComponent(new android.content.ComponentName(info.activityInfo.packageName,
              info.activityInfo.name));
          break;
        }
      }
    }
    try {
      getContext().startActivity(intent);
    } catch (Throwable refused) {
      toast(ui("ui_install_apk_failed"));
    }
  }

  /** كلُّ حالَةٍ مُسَمّاةٍ لها نصُّها: لا رسالةٌ إنجليزيّةٌ تُعرَضُ للمستخدمِ من الطبقةِ الصافيةِ. */
  private String installMessage(almlk.ApkInstallPlan.Plan plan) {
    if (plan == null || plan.ready) return null;
    switch (plan.state) {
      case "empty_file":
        return ui("ui_install_apk_empty");
      case "not_apk":
        return ui("ui_install_apk_not_apk");
      case "bad_authority":
        return ui("ui_install_apk_no_provider");
      case "blocked_installs":
        return ui("ui_install_apk_blocked");
      default:
        return ui("ui_install_apk_missing");
    }
  }

  /**
   * «إضافةَ مكتبةٍ إلى المشروعِ» / «إزالةَ مكتبةٍ من المشروعِ» — تأكيدٌ واحدٌ ثمَّ تحريرُ
   * ملفَّيِ المشروعِ في الخيطِ العاملِ، وإشعارٌ قصيرٌ (كِبرُ رسالةِ المرجعِ «Library has been
   * added»)، ثمَّ إعادةُ دورةِ الاعتماداتِ الصامتةِ كي تُعرَفَ الوحدةُ في الحلِّ والفهرسةِ.
   */
  private void confirmLinkLibrary(final File folder, final boolean link) {
    if (folder == null) return;
    final File root = projectRootFile();
    if (root == null) {
      toast(ui("ui_project_build_file_missing"));
      return;
    }
    new AlertDialog.Builder(getContext())
        .setTitle(ui(link ? "ui_browser_add_library" : "ui_browser_remove_library"))
        .setMessage(uiFormat(link ? "ui_browser_add_library_confirm" : "ui_browser_remove_library_confirm",
            folder.getName(), root.getName()))
        .setNegativeButton(ui("dialog_cancel"), null)
        .setPositiveButton(
            ui(link ? "ui_browser_add_library" : "ui_browser_remove_library"),
            (d, w) -> applyLibraryLink(root, folder, link))
        .show();
  }

  /** الكتابةُ في الخلفيّةِ: لا قرصَ في خيطِ الواجهةِ، ولا انتظارَ على الشاشةِ. */
  private void applyLibraryLink(final File root, final File folder, final boolean link) {
    fileReader.execute(
        () -> {
          almlk.GradleLibraryLinks.Result result;
          try {
            result =
                link
                    ? almlk.GradleLibraryLinks.link(root, folder)
                    : almlk.GradleLibraryLinks.unlink(root, folder.getName());
          } catch (RuntimeException failure) {
            result =
                new almlk.GradleLibraryLinks.Result(
                    almlk.GradleLibraryLinks.IO_ERROR, folder.getName(), false, false, String.valueOf(failure));
          }
          final almlk.GradleLibraryLinks.Result done = result;
          mainHandler.post(
              () -> {
                toast(libraryMessage(done, link));
                if (!done.changedAnything()) return;
                refresh();
                File buildFile = almlk.GradleDependencyEditor.moduleBuildFile(root);
                if (buildFile != null && actions != null) actions.onBuildFilesChanged(buildFile);
              });
        });
  }

  /** رسالةٌ واحدةٌ لكلِّ حالةٍ مسمّاةٍ — لا استثناءً يراهُ المستخدمُ ولا رقمَ حالةٍ جافًا. */
  private String libraryMessage(almlk.GradleLibraryLinks.Result result, boolean link) {
    switch (result.status) {
      case almlk.GradleLibraryLinks.DONE:
        return uiFormat(link ? "ui_browser_add_library_done" : "ui_browser_remove_library_done", result.name);
      case almlk.GradleLibraryLinks.ALREADY_LINKED:
        return uiFormat("ui_browser_add_library_exists", result.name);
      case almlk.GradleLibraryLinks.NOT_LINKED:
        return uiFormat("ui_browser_remove_library_none", result.name);
      case almlk.GradleLibraryLinks.NOT_A_MODULE:
        return ui("ui_browser_add_library_not_module");
      case almlk.GradleLibraryLinks.IS_OPEN_PROJECT:
        return ui("ui_browser_add_library_self");
      case almlk.GradleLibraryLinks.BAD_NAME:
        return ui("ui_browser_add_library_bad_name");
      default:
        return uiFormat(
            "ui_browser_library_failed",
            result.detail.isEmpty() ? almlk.GradleLibraryLinks.reason(result.status) : result.detail);
    }
  }

  /**
   * بند «إظهار المشاريع» المرجعي: مجلد المشاريع (project_home) بالتخزين المباشر متى أمكن —
   * حتى من وضع المستندات. بلا وصول مباشر: جذر الشجرة إن كان هو AppProjects، وإلا منتقي المجلد.
   */
  private void showProjectsFolder() {
    File home = projectsHomeDir();
    if (canReadDirectStorage()) {
      if (!home.isDirectory()) home.mkdirs();
      if (home.isDirectory()) {
        loadFile(home);
        return;
      }
    }
    if (documentRoot != null && nameForUri(documentRoot.getUri()).equalsIgnoreCase("AppProjects")) {
      documentParents.clear();
      loadDocument(documentRoot, false);
      return;
    }
    if (actions != null) actions.onSelectProjectFolder();
  }

  /** «خصائص المشروع…»: يفتح ملف البناء (build.gradle ثم ‎.kts) أو المنيفست لمشاريع Eclipse. */
  private void openProjectProperties(File projectDir) {
    File target = almlk.GradleDependencyEditor.buildFileIn(projectDir);
    if (target == null && projectDir != null) {
      File manifest = new File(projectDir, "AndroidManifest.xml");
      if (manifest.isFile()) target = manifest;
    }
    if (target == null) {
      toast(ui("ui_project_build_file_missing"));
      return;
    }
    activate(new Entry(target.getName(), target, null, false, iconFor(target.getName()), 0, 0));
  }

  /** «إضافة إلى المشروع…»: مكتبات JAR في libs أو اعتماد Maven يُكتب في ملف بناء الوحدة. */
  private void showAddToProjectDialog(final File projectDir) {
    final File buildFile = almlk.GradleDependencyEditor.moduleBuildFile(projectDir);
    if (buildFile == null) {
      toast(ui("ui_project_build_file_missing"));
      return;
    }
    final boolean kts = buildFile.getName().endsWith(".kts");
    String[] items = {
      ui("ui_add_to_project_jar_files"), ui("ui_add_dependency_title"), ui("ui_maven_browse_title")
    };
    new AlertDialog.Builder(getContext())
        .setTitle(ui("command_files_add_to_project"))
        .setItems(
            items,
            (dialog, which) -> {
              if (which == 0) {
                new File(buildFile.getParentFile(), "libs").mkdirs();
                addDependencyLines(
                    buildFile, java.util.Collections.singletonList(almlk.GradleDependencyEditor.jarFolderLine(kts)));
              } else if (which == 1) {
                com.almlkid.ui.AddDependencyDialog.show(
                    getContext(), kts, lines -> addDependencyLines(buildFile, lines));
              } else {
                // تصفُّحٌ حيٌّ: الإحداثياتُ المختارةُ تمرُّ بالمسارِ نفسِهِ (تحقُّقٌ ثمَّ كتابةٌ في الخلفيةِ).
                com.almlkid.ui.MavenBrowseDialog.show(
                    getContext(),
                    projectDir,
                    coordinate -> {
                      String line = almlk.GradleDependencyEditor.dependencyLine(coordinate, kts);
                      if (line == null) {
                        toast(ui("ui_add_to_project_maven_invalid"));
                        return;
                      }
                      addDependencyLines(buildFile, java.util.Collections.singletonList(line));
                    });
              }
            })
        .setNegativeButton(ui("dialog_cancel"), null)
        .show();
  }

  /** كتابة الاعتماد في الخلفية ثم فتح ملف البناء في المحرر ليرى المستخدم السطر المضاف. */
  private void addDependencyLines(final File buildFile, final List<String> lines) {
    fileReader.execute(
        () -> {
          String message;
          boolean added = false;
          try {
            String text = readTextFrom(buildFile);
            String updated = almlk.GradleDependencyEditor.addDependencies(text, lines);
            if (updated.equals(text)) {
              message = ui("ui_add_to_project_exists");
            } else {
              writeTextTo(buildFile, updated);
              Entry written =
                  new Entry(buildFile.getName(), buildFile, null, false, iconFor(buildFile.getName()), 0, 0);
              cacheFileContent(fileContentKey(written), updated);
              added = true;
              message = ui("ui_add_dependency_added");
            }
          } catch (Exception failure) {
            message = uiFormat("ui_save_failed", UiStrings.message(getContext(), failure));
          }
          final String result = message;
          final boolean changed = added;
          mainHandler.post(
              () -> {
                toast(result);
                if (changed) {
                  refresh();
                  if (actions != null) actions.onBuildFilesChanged(buildFile);
                }
                openProjectBuildFile(buildFile);
              });
        });
  }

  private void openProjectBuildFile(File buildFile) {
    activate(new Entry(buildFile.getName(), buildFile, null, false, iconFor(buildFile.getName()), 0, 0));
  }

  private void promptCreate(boolean folder) {
    promptCreate(folder, null);
  }

  /**
   * إنشاء ملف/مجلد بدلالات المرجع الكاملة: زر الإنشاء معطل حتى كتابة اسم، الفشل يظهر على
   * الحقل نفسه دون إغلاق الحوار، الكيبورد يظهر تلقائيًا، الامتداد والقالب يُكملان تلقائيًا
   * حسب مجلد الهدف (جافا → ‎.java وقالب كلاس، موارد → ‎.xml وقالب المجلد)، والملف المنشأ
   * يُفتح في المحرر فورًا عبر مسار الفتح المعتاد نفسه — كما يفعل المرجع تمامًا.
   */
  private void promptCreate(boolean folder, File target) {
    Context context = getContext();
    EditText input = new EditText(context);
    input.setHint(folder ? ui("ui_folder_name_hint") : ui("ui_new_file_name_hint"));
    input.setSingleLine(true);
    LinearLayout box = new LinearLayout(context);
    box.setOrientation(LinearLayout.VERTICAL);
    int pad = (int) (16 * getResources().getDisplayMetrics().density);
    box.setPadding(pad, pad / 2, pad, 0);
    box.addView(input);
    AlertDialog dialog =
        new AlertDialog.Builder(context)
            .setTitle(folder ? ui("ui_create_folder_title") : ui("ui_create_file_title"))
            .setView(box)
            .setNegativeButton(ui("dialog_cancel"), null)
            .setPositiveButton(ui("ui_action_create"), null)
            .create();
    if (dialog.getWindow() != null)
      dialog.getWindow().setSoftInputMode(
          android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
    dialog.show();
    final Button createButton = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
    createButton.setEnabled(false);
    input.addTextChangedListener(
        new android.text.TextWatcher() {
          public void beforeTextChanged(CharSequence s, int a, int b, int c) {}

          public void onTextChanged(CharSequence s, int a, int b, int c) {}

          public void afterTextChanged(android.text.Editable s) {
            // كالمرجع: الكتابة تمسح الخطأ السابق وتفعّل الزر عند وجود اسم.
            input.setError(null);
            createButton.setEnabled(!s.toString().trim().isEmpty());
          }
        });
    createButton.setOnClickListener(
        v -> {
          String raw = input.getText().toString().trim();
          if (!validName(raw)) {
            input.setError(ui("ui_name_invalid"));
            return;
          }
          final boolean documents = target == null && usingDocuments;
          final DocumentFile documentParent = currentDocument;
          final File fileParent = target != null ? target : currentFile;
          String parentPath =
              documents
                  ? (documentParent == null ? "" : pathForDocument(documentParent))
                  : (fileParent == null ? "" : fileParent.getAbsolutePath());
          // التوجيه السياقي للمرجع: الاسم النهائي + قالب البداية حسب مجلد الهدف.
          String[] resolved = resolveCreationTemplate(folder, parentPath, raw);
          final String finalName = resolved[0];
          final String content = resolved[1];
          directoryReader.execute(
              () -> {
                boolean success = false;
                boolean exists = false;
                String error = ui("ui_create_failed_short");
                try {
                  if (documents) {
                    if (documentParent != null && documentParent.findFile(finalName) != null) {
                      exists = true;
                    } else {
                      success = createDocumentChild(documentParent, folder, finalName);
                      if (success && !folder && !content.isEmpty()) {
                        DocumentFile created = documentParent.findFile(finalName);
                        if (created != null) {
                          try (java.io.OutputStream out =
                              getContext()
                                  .getContentResolver()
                                  .openOutputStream(created.getUri(), "wt")) {
                            if (out != null)
                              out.write(
                                  com.shima.performance.EncodingManager.encodeUtf8(content));
                          }
                        }
                      }
                    }
                  } else {
                    if (!fileParent.exists()) fileParent.mkdirs();
                    File created = new File(fileParent, finalName);
                    if (created.exists()) {
                      exists = true;
                    } else if (folder) {
                      success = created.mkdirs();
                    } else {
                      writeTextTo(created, content);
                      success = true;
                    }
                  }
                } catch (Exception exception) {
                  error = uiFormat("ui_create_failed", UiStrings.message(getContext(), exception));
                }
                final boolean created = success;
                final boolean duplicate = exists;
                final String message = error;
                mainHandler.post(
                    () -> {
                      // كالمرجع: الفشل لا يغلق الحوار — الخطأ يظهر على الحقل نفسه.
                      if (duplicate) {
                        input.setError(folder ? ui("ui_folder_already_exists") : ui("ui_file_already_exists"));
                        return;
                      }
                      if (!created) {
                        input.setError(message);
                        return;
                      }
                      dialog.dismiss();
                      // إنشاء داخل مجلد فرعي من قائمة السياق: إبطال كاشه ليظهر الجديد فورًا.
                      if (target != null) invalidateDirectory(fileCacheKey(target));
                      if (documents && documentParent != null)
                        invalidateDirectory(documentCacheKey(documentParent.getUri()));
                      else if (fileParent != null)
                        invalidateDirectory(fileCacheKey(fileParent));
                      refresh();
                      // ترتيب المرجع: الملف المنشأ يُفتح في المحرر فورًا والبقاء بنفس المجلد.
                      if (!folder) {
                        if (documents) {
                          directoryReader.execute(
                              () -> {
                                DocumentFile opened =
                                    documentParent == null
                                        ? null
                                        : documentParent.findFile(finalName);
                                if (opened == null) return;
                                final Uri uri = opened.getUri();
                                mainHandler.post(
                                    () ->
                                        activate(
                                            new Entry(
                                                finalName, uri, false, 0,
                                                iconFor(finalName))));
                              });
                        } else {
                          activate(
                              new Entry(
                                  finalName,
                                  new File(fileParent, finalName),
                                  null,
                                  false,
                                  iconFor(finalName),
                                  0,
                                  0));
                        }
                      }
                    });
              });
        });
  }

  /**
   * التوجيه السياقي للإنشاء العام — قاعدة المرجع: اسم بلا امتداد داخل مصادر جافا يُكمل
   * ‎.java ويُحقن قالب كلاس كامل (Activity/Service/Receiver حسب نهاية الاسم)، وداخل مجلدات
   * الموارد يُكمل ‎.xml بقالب المجلد؛ خارج السياقين يبقى الاسم كما كُتب والملف فارغًا.
   */
  private static String[] resolveCreationTemplate(
      boolean folder, String parentPath, String raw) {
    if (folder) return new String[] {raw, ""};
    String path = parentPath == null ? "" : parentPath.replace('\\', '/');
    String simpleRaw = raw.substring(raw.lastIndexOf('/') + 1);
    int dot = simpleRaw.lastIndexOf('.');
    boolean hasExtension = dot > 0 && dot < simpleRaw.length() - 1;
    if (isJavaSourceDir(path)) {
      String name = hasExtension ? raw : raw + ".java";
      if (name.endsWith(".java")) {
        String simple = name.substring(name.lastIndexOf('/') + 1, name.length() - 5);
        if (simple.matches("[A-Za-z_$][A-Za-z0-9_$]*")) {
          int kind =
              simple.endsWith("Activity")
                  ? 1
                  : simple.endsWith("Service") ? 4 : simple.endsWith("Receiver") ? 5 : 0;
          return new String[] {name, classCodeFor(kind, packageForDir(path), simple, false, "")};
        }
      }
      return new String[] {name, ""};
    }
    if (isResDir(path)) {
      String folderName = path.substring(path.lastIndexOf('/') + 1).toLowerCase(Locale.US);
      String base =
          folderName.contains("-")
              ? folderName.substring(0, folderName.indexOf('-'))
              : folderName;
      String name = hasExtension ? raw : raw + ".xml";
      if (name.endsWith(".xml")) return new String[] {name, xmlTemplateForFolder(base)};
      return new String[] {name, ""};
    }
    return new String[] {raw, ""};
  }

  private boolean createDocumentChild(DocumentFile parent, boolean folder, String name) {
    try {
      String mime = folder ? DocumentsContract.Document.MIME_TYPE_DIR : mimeFor(name);
      Uri created =
          DocumentsContract.createDocument(
              getContext().getContentResolver(), parent.getUri(), mime, name);
      return created != null;
    } catch (Exception directCreateFailed) {
      DocumentFile created =
          folder ? parent.createDirectory(name) : parent.createFile(mimeFor(name), name);
      return created != null;
    }
  }

  /**
   * إعادة تسمية بدلالات المرجع: النص محدد كاملًا، زر الحفظ معطل حتى يتغير الاسم فعلًا،
   * والفشل أو التكرار يظهران على الحقل نفسه دون إغلاق الحوار، مع كيبورد تلقائي.
   */
  private void promptRename(Entry e) {
    Context context = getContext();
    EditText input = new EditText(context);
    input.setText(e.name);
    input.setSingleLine(true);
    input.setSelectAllOnFocus(true);
    LinearLayout box = new LinearLayout(context);
    box.setOrientation(LinearLayout.VERTICAL);
    int pad = (int) (16 * getResources().getDisplayMetrics().density);
    box.setPadding(pad, pad / 2, pad, 0);
    box.addView(input);
    AlertDialog dialog =
        new AlertDialog.Builder(context)
            .setTitle(ui("ui_rename_context"))
            .setView(box)
            .setNegativeButton(ui("dialog_cancel"), null)
            .setPositiveButton(ui("ui_action_save"), null)
            .create();
    if (dialog.getWindow() != null)
      dialog.getWindow().setSoftInputMode(
          android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
    dialog.show();
    final Button saveButton = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
    saveButton.setEnabled(false);
    input.addTextChangedListener(
        new android.text.TextWatcher() {
          public void beforeTextChanged(CharSequence s, int a, int b, int c) {}

          public void onTextChanged(CharSequence s, int a, int b, int c) {}

          public void afterTextChanged(android.text.Editable s) {
            // كالمرجع: الزر يعمل فقط عند اسم غير فارغ ومختلف عن الأصلي.
            input.setError(null);
            String text = s.toString().trim();
            saveButton.setEnabled(!text.isEmpty() && !text.equals(e.name));
          }
        });
    saveButton.setOnClickListener(
        v -> {
          String name = input.getText().toString().trim();
          if (!validName(name)) {
            input.setError(ui("ui_name_invalid"));
            return;
          }
          // تكرار الاسم في وضع الملفات يُكتشف مسبقًا ويبقى الحوار مفتوحًا — كالمرجع.
          if (!usingDocuments
              && e.file != null
              && new File(e.file.getParentFile(), name).exists()) {
            input.setError(ui("ui_name_already_exists"));
            return;
          }
          final boolean documents = usingDocuments;
          directoryReader.execute(
              () -> {
                boolean success =
                    documents
                        ? renameDocument(e.documentUri, name)
                        : e.file.renameTo(new File(e.file.getParentFile(), name));
                mainHandler.post(
                    () -> {
                      if (success) {
                        dialog.dismiss();
                        refresh();
                      } else {
                        input.setError(ui("ui_rename_failed"));
                      }
                    });
              });
        });
  }

  private void confirmDelete(Entry e) {
    new AlertDialog.Builder(getContext())
        .setTitle(ui("ui_delete_context"))
        .setMessage(uiFormat("ui_delete_confirm", e.name))
        .setNegativeButton(ui("dialog_cancel"), null)
        .setPositiveButton(
            ui("ui_delete_context"),
            (d, w) -> {
              final boolean documents = usingDocuments;
              directoryReader.execute(
                  () -> {
                    boolean success =
                        documents ? deleteDocument(e.documentUri) : deleteRecursively(e.file);
                    mainHandler.post(
                        () -> {
                          if (success) refresh();
                          else toast(ui("ui_delete_failed"));
                        });
                  });
            })
        .show();
  }

  private boolean renameDocument(Uri uri, String name) {
    try {
      return uri != null
          && DocumentsContract.renameDocument(getContext().getContentResolver(), uri, name) != null;
    } catch (Exception error) {
      return false;
    }
  }

  private boolean deleteDocument(Uri uri) {
    try {
      return uri != null
          && DocumentsContract.deleteDocument(getContext().getContentResolver(), uri);
    } catch (Exception error) {
      return false;
    }
  }

  private boolean deleteRecursively(File f) {
    if (f.isDirectory()) {
      File[] c = f.listFiles();
      if (c != null) for (File x : c) if (!deleteRecursively(x)) return false;
    }
    return f.delete();
  }

  private String readDocument(Uri uri, String name, long size) {
    try {
      InputStream in = getContext().getContentResolver().openInputStream(uri);
      if (in == null) return ui("ui_error_open_file");
      byte[] data = readBytes(in);
      if (isTextFile(name, data)) return EncodingManager.decodeUtf8(data);
      return binaryPreview(pathForUri(uri), size, data);
    } catch (Exception e) {
      return uiFormat("ui_error_open_file_details", UiStrings.message(getContext(), e));
    }
  }

  private String readFile(File file, String name) {
    try {
      FileInputStream in = new FileInputStream(file);
      byte[] data = readBytes(in);
      if (isTextFile(name, data)) return EncodingManager.decodeUtf8(data);
      return binaryPreview(file.getAbsolutePath(), file.length(), data);
    } catch (Exception e) {
      return uiFormat("ui_error_open_file_details", UiStrings.message(getContext(), e));
    }
  }

  private byte[] readBytes(InputStream in) throws IOException {
    ByteArrayOutputStream out = new ByteArrayOutputStream();
    byte[] b = new byte[8192];
    int n;
    while (!Thread.currentThread().isInterrupted()
        && (n = in.read(b)) > 0
        && out.size() < 8 * 1024 * 1024) out.write(b, 0, n);
    in.close();
    return out.toByteArray();
  }

  private boolean isTextFile(String name, byte[] data) {
    String n = name.toLowerCase();
    if (n.matches(
        ".*\\.(java|smali|kt|xml|gradle|properties|json|md|txt|html|htm|css|js|ts|c|cpp|cc|h|hpp|py|sh|yaml|yml|pro|cfg|ini|csv)$"))
      return true;
    for (int i = 0; i < Math.min(512, data.length); i++) if (data[i] == 0) return false;
    return true;
  }

  private String binaryPreview(String path, long size, byte[] data) {
    if (path != null && path.toLowerCase(Locale.US).endsWith(".dex"))
      return DexMetadataReader.describe(getContext(), path, size, data);
    StringBuilder s =
        new StringBuilder(ui("ui_binary_file_viewer_title") + "\n\n" + ui("ui_binary_path") + ": ")
            .append(path)
            .append("\n" + ui("ui_binary_size") + ": ")
            .append(size)
            .append(" " + ui("ui_byte_unit") + "\n\nHEX:\n");
    for (int i = 0; i < Math.min(4096, data.length); i++) {
      if (i % 16 == 0) s.append(String.format("%n%08X  ", i));
      s.append(String.format("%02X ", data[i] & 255));
    }
    return s.toString();
  }

  private boolean entriesLookLikeProject() {
    for (Entry entry : entries) {
      String name = entry.name;
      if (name.equals("settings.gradle")
          || name.equals("settings.gradle.kts")
          || name.equals("AndroidManifest.xml")) return true;
    }
    return false;
  }

  private String pathForDocument(DocumentFile doc) {
    return pathForUri(doc.getUri());
  }

  private String pathForUri(Uri uri) {
    try {
      String id = DocumentsContract.getDocumentId(uri);
      if (id.startsWith("primary:")) return "/storage/emulated/0/" + id.substring(8);
      return id;
    } catch (Exception e) {
      return uri == null ? "" : uri.toString();
    }
  }

  private String shortPath(File d) {
    String p = d.getAbsolutePath(),
        base = Environment.getExternalStorageDirectory().getAbsolutePath();
    return p.startsWith(base) ? "…ulated/0" + p.substring(base.length()) : p;
  }

  private String nameForUri(Uri uri) {
    try {
      String id = DocumentsContract.getDocumentId(uri);
      int slash = id.lastIndexOf('/');
      int colon = id.lastIndexOf(':');
      int separator = Math.max(slash, colon);
      String name = separator >= 0 ? id.substring(separator + 1) : id;
      return name.isEmpty() ? ui("ui_unnamed") : name;
    } catch (Exception error) {
      String name = uri == null ? null : uri.getLastPathSegment();
      return name == null || name.isEmpty() ? ui("ui_unnamed") : name;
    }
  }

  private String mimeFor(String name) {
    String ext = MimeTypeMap.getFileExtensionFromUrl(name);
    String mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext.toLowerCase());
    return mime == null ? "application/octet-stream" : mime;
  }

  /**
   * أيقونتا الملف والمجلد: كلاهما من {@code almlk.FileTypeIcons} وحده (كانت هنا خريطة أوسع من
   * خريطة اللوحة والمحرر — الإتحاد الآن في ذلك الصنف فلا تفقد هذه الواجهة شيئًا).
   */
  private int folderIconFor(String name) {
    return almlk.FileTypeIcons.forFolder(name);
  }

  private int iconFor(String name) {
    return almlk.FileTypeIcons.forFile(name);
  }

  private void copyCurrentPath() {
    copy(usingDocuments ? pathForDocument(currentDocument) : currentFile.getAbsolutePath());
  }

  private void copyEntryPath(Entry e) {
    copy(usingDocuments ? pathForUri(e.documentUri) : e.file.getAbsolutePath());
  }

  private void copy(String value) {
    ClipboardManager c =
        (ClipboardManager) getContext().getSystemService(Context.CLIPBOARD_SERVICE);
    c.setPrimaryClip(ClipData.newPlainText("path", value));
    toast(ui("ui_copy_path_context"));
  }

  private boolean validName(String n) {
    if (n.isEmpty() || n.equals(".") || n.equals("..") || n.contains("/") || n.contains("\\")) {
      toast(ui("ui_name_invalid"));
      return false;
    }
    return true;
  }

  private void toast(String s) {
    Toast.makeText(getContext(), s, Toast.LENGTH_SHORT).show();
  }

  // ===================== المرحلة أ: شارات المشاريع والمصغرات والأوامر السياقية =====================

  /** المجلد الهدف لإنشاء/استيراد المشاريع: مجلد المتصفح الحالي أو AppProjects الافتراضي. */
  public File projectsTargetDirectory() {
    File base = !usingDocuments && currentFile != null ? currentFile : documentDirAsFile();
    if (base != null) {
      // من داخل جذر مشروع يُنشأ المشروع الجديد بجواره لا بداخله — كالمرجع.
      if (isProjectRoot(base) && base.getParentFile() != null) return base.getParentFile();
      return base;
    }
    // `project_home` (كما في المرجعِ: «Custom project home — default: /sdcard/AppProject») يسكنُ
    // حيثُ لا مجلدَ حاليًّا للمتبِّحِ: هو المجلدُ الهدفُ الجديدُ، لا بديلٌ ثانٍ له.
    String home = almlk.AppSettings.projectHome(getContext());
    if (!home.isEmpty()) {
      File dir = new File(home);
      if (dir.isAbsolute()) return dir;
    }
    if (canReadDirectStorage())
      return new File(Environment.getExternalStorageDirectory(), "AppProjects");
    return null;
  }

  /** بعد إنشاء مشروع: إبطال كاش الأب، اعتماد الجذر، إشعار المضيف، والانتقال إليه. */
  public void openCreatedProject(File root) {
    if (root == null) return;
    File parent = root.getParentFile();
    if (parent != null) invalidateDirectory(fileCacheKey(parent));
    folderBadgeCache.remove(root.getAbsolutePath());
    projectFile = root;
    projectDocumentUri = null;
    rememberProjectRoot();
    if (actions != null) actions.onProjectOpened(root.getName(), root.getAbsolutePath());
    loadFile(root);
  }

  /** إعادة تحميل المجلد المعروض (بعد استيراد مشروع مثلًا). */
  public void refreshListing() {
    if (!usingDocuments && currentFile != null) {
      invalidateDirectory(fileCacheKey(currentFile));
      loadFile(currentFile);
    } else if (currentDocument != null) {
      invalidateDirectory(documentCacheKey(currentDocument.getUri()));
      loadDocument(currentDocument, true);
    }
  }

  private String currentEditorFileName() {
    synchronized (activeSymbolLock) {
      return activeSymbolFile;
    }
  }

  /** مطابقة صف المتصفح مع الملف النشط: بالمرجع الكامل إن توفر (يميّز الأب عن الابن بنفس الاسم). */
  private boolean isActiveEditorEntry(Entry e) {
    String name, reference;
    synchronized (activeSymbolLock) {
      name = activeSymbolFile;
      reference = activeSymbolReference;
    }
    if (name == null || name.isEmpty() || e.name == null) return false;
    if (reference != null && reference.startsWith("/") && e.file != null)
      return e.file.getAbsolutePath().equals(reference);
    return e.name.equals(name.substring(name.lastIndexOf('/') + 1));
  }

  private static boolean isImageName(String lower) {
    return lower.endsWith(".png")
        || lower.endsWith(".jpg")
        || lower.endsWith(".jpeg")
        || lower.endsWith(".webp")
        || lower.endsWith(".gif")
        || lower.endsWith(".bmp");
  }

  /** مجلد مصادر جافا: يقع تحت src وداخل مقطع java — شرط ظهور «إنشاء كلاس جديد». */
  private static boolean isJavaSourceDir(String path) {
    int srcAt = path.indexOf("/src");
    if (srcAt < 0) return false;
    int javaAt = path.indexOf("/java", srcAt);
    if (javaAt < 0) return false;
    int end = javaAt + 5;
    return end == path.length() || path.charAt(end) == '/';
  }

  /** مجلد موارد: res نفسه أو أحد أبنائه — لتوجيه القوالب وقوائم الضغط الطويل. */
  private static boolean isResDir(String path) {
    return path.endsWith("/res") || path.contains("/res/");
  }

  /**
   * ابن مجلد res فقط (layout/values/drawable...) — كالمرجع تمامًا: صف «إنشاء ملف
   * XML جديد» يظهر داخل المجلدات الفرعية لا في صفحة res التي تسرد المجلدات.
   */
  private static boolean isResSubDir(String path) {
    return path.contains("/res/");
  }

  /** جذر مشروع بقواعد المرجع: Gradle (build.gradle) أو Eclipse (AndroidManifest+src). */
  private static boolean isProjectRoot(File dir) {
    if (dir == null) return false;
    if ((new File(dir, "build.gradle").isFile() || new File(dir, "build.gradle.kts").isFile())
        && (new File(dir, "src").isDirectory()
            || new File(dir, "settings.gradle").isFile()
            || new File(dir, "settings.gradle.kts").isFile()
            || new File(dir, "app").isDirectory())) return true;
    return new File(dir, "AndroidManifest.xml").isFile() && new File(dir, "src").isDirectory();
  }

  /** حزمة جافا المشتقة من المسار بعد مقطع java/ — فارغة في جذر المصادر. */
  private static String packageForDir(String path) {
    // ‏1.0.197: قَاعِدَةٌ وَاحِدَةٌ — صَفُّ «‏Create class‏» فِي لوحَةِ الأَخطَاءِ يَسأَلُ نَفسَ
    // السُّؤَالِ، فَإن بَقِيَت صِيغَتَانِ لِـ«مَوضِعِ الصِّنْفِ» كَانَ المَكتُوبُ عِندَنا غَيرَ
    // المَكتُوبِ عِندَ المُتَصَفِّرِ، وَهُوَ أَسرَعُ طَرِيقٍ إلى صِنفٍ لا تُقرَؤُهُ البَاقَةُ.
    return almlk.SourceLayout.packageOfDirectory(path);
  }

  // ======== المرحلة ج: إنشاء كلاسات وXML بدلالات المرجع (أنواع + تحقق حي + مانيفست) ========

  /** Localized class-template labels; the stable numeric kind IDs stay unchanged. */
  private String[] classKindLabels() {
    return new String[] {
      ui("ui_class_kind_class"),
      ui("ui_class_kind_activity"),
      ui("ui_class_kind_interface"),
      ui("ui_class_kind_enum"),
      ui("ui_class_kind_service"),
      ui("ui_class_kind_broadcast_receiver")
    };
  }

  /** هل يُسجَّل هذا النوع في AndroidManifest تلقائيًا؟ (Activity/Service/Receiver). */
  private static boolean kindRegistersInManifest(int kind) {
    return kind == 1 || kind == 4 || kind == 5;
  }

  /** حوار إنشاء كلاس جديد: نوع + اسم بتحقق حي + Layout تلقائي للـActivity + تسجيل مانيفست. */
  private void promptCreateClass(File dir) {
    Context context = getContext();
    LinearLayout box = new LinearLayout(context);
    box.setOrientation(LinearLayout.VERTICAL);
    int pad = (int) (16 * getResources().getDisplayMetrics().density);
    box.setPadding(pad, pad / 2, pad, 0);

    Spinner kindSpinner = new Spinner(context);
    ArrayAdapter<String> kinds =
        new ArrayAdapter<>(context, android.R.layout.simple_spinner_item, classKindLabels());
    kinds.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
    kindSpinner.setAdapter(kinds);
    box.addView(kindSpinner);

    EditText nameInput = new EditText(context);
    nameInput.setHint(ui("ui_class_name_hint"));
    nameInput.setSingleLine(true);
    box.addView(nameInput);

    CheckBox manifestCheck = new CheckBox(context);
    manifestCheck.setText(ui("ui_register_manifest"));
    manifestCheck.setChecked(true);
    manifestCheck.setVisibility(View.GONE);
    box.addView(manifestCheck);

    CheckBox layoutCheck = new CheckBox(context);
    layoutCheck.setText(ui("ui_create_layout_link"));
    layoutCheck.setChecked(true);
    layoutCheck.setVisibility(View.GONE);
    box.addView(layoutCheck);

    EditText layoutInput = new EditText(context);
    layoutInput.setHint(ui("ui_layout_file_name"));
    layoutInput.setSingleLine(true);
    layoutInput.setVisibility(View.GONE);
    box.addView(layoutInput);

    ScrollView scroller = new ScrollView(context);
    scroller.addView(box);

    AlertDialog dialog =
        new AlertDialog.Builder(context)
            .setTitle(ui("ui_create_class_title"))
            .setView(scroller)
            .setNegativeButton(ui("dialog_cancel"), null)
            .setPositiveButton(ui("ui_action_create"), null)
            .create();
    if (dialog.getWindow() != null)
      dialog.getWindow().setSoftInputMode(
          android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
    dialog.show();
    final Button createButton = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
    createButton.setEnabled(false);

    // تحقق حي: تعطيل الزر مع إظهار سبب الرفض على الحقل نفسه دون إغلاق الحوار.
    Runnable validator =
        () -> {
          String raw = nameInput.getText().toString().trim();
          if (raw.endsWith(".java")) raw = raw.substring(0, raw.length() - 5);
          if (raw.isEmpty()) {
            createButton.setEnabled(false);
            return;
          }
          String simple = raw.substring(raw.lastIndexOf('/') + 1);
          if (!raw.matches("([A-Za-z_][A-Za-z0-9_]*/)*[A-Za-z_][A-Za-z0-9_]*")) {
            nameInput.setError(ui("ui_name_invalid"));
            createButton.setEnabled(false);
            return;
          }
          File parent =
              raw.contains("/") ? new File(dir, raw.substring(0, raw.lastIndexOf('/'))) : dir;
          if (new File(parent, simple + ".java").exists()) {
            nameInput.setError(ui("ui_file_already_exists"));
            createButton.setEnabled(false);
            return;
          }
          createButton.setEnabled(true);
        };
    nameInput.addTextChangedListener(
        new android.text.TextWatcher() {
          public void beforeTextChanged(CharSequence s, int a, int b, int c) {}

          public void onTextChanged(CharSequence s, int a, int b, int c) {}

          public void afterTextChanged(android.text.Editable s) {
            // اسم الـLayout يُشتق تلقائيًا من اسم الكلاس ما لم يعدّله المستخدم.
            if (layoutInput.getTag() == null) {
              String simple = s.toString().trim();
              simple = simple.substring(simple.lastIndexOf('/') + 1);
              layoutInput.setTag("auto");
              layoutInput.setText(defaultLayoutNameFor(simple));
              layoutInput.setTag(null);
            }
            validator.run();
          }
        });
    kindSpinner.setOnItemSelectedListener(
        new AdapterView.OnItemSelectedListener() {
          @Override
          public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
            boolean manifest = kindRegistersInManifest(position);
            manifestCheck.setVisibility(manifest ? View.VISIBLE : View.GONE);
            boolean activity = position == 1;
            layoutCheck.setVisibility(activity ? View.VISIBLE : View.GONE);
            layoutInput.setVisibility(activity ? View.VISIBLE : View.GONE);
          }

          @Override
          public void onNothingSelected(AdapterView<?> parent) {}
        });

    createButton.setOnClickListener(
        v -> {
          String raw = nameInput.getText().toString().trim();
          if (raw.endsWith(".java")) raw = raw.substring(0, raw.length() - 5);
          final int kind = kindSpinner.getSelectedItemPosition();
          final boolean register =
              kindRegistersInManifest(kind)
                  && manifestCheck.getVisibility() == View.VISIBLE
                  && manifestCheck.isChecked();
          final boolean withLayout =
              kind == 1 && layoutCheck.getVisibility() == View.VISIBLE && layoutCheck.isChecked();
          final String layoutName = sanitizeResourceName(layoutInput.getText().toString());
          if (withLayout && layoutName.isEmpty()) {
            layoutInput.setError(ui("ui_name_invalid"));
            return;
          }
          final File parentDir =
              raw.contains("/") ? new File(dir, raw.substring(0, raw.lastIndexOf('/'))) : dir;
          final String simple = raw.substring(raw.lastIndexOf('/') + 1);
          dialog.dismiss();
          createClassArtifacts(parentDir, simple, kind, register, withLayout, layoutName);
        });
  }

  /** اسم Layout افتراضي مشتق من اسم الكلاس: MainActivity → activity_main. */
  private static String defaultLayoutNameFor(String className) {
    String base = className;
    if (base.endsWith("Activity") && base.length() > 8)
      base = base.substring(0, base.length() - 8);
    StringBuilder snake = new StringBuilder();
    for (int i = 0; i < base.length(); i++) {
      char c = base.charAt(i);
      if (Character.isUpperCase(c)) {
        if (snake.length() > 0) snake.append('_');
        snake.append(Character.toLowerCase(c));
      } else snake.append(c);
    }
    return snake.length() == 0 ? "main" : "activity_" + snake;
  }

  /** تنقية اسم مورد: أحرف صغيرة وأرقام و_ فقط — فارغ يعني اسمًا مرفوضًا. */
  private static String sanitizeResourceName(String name) {
    String cleaned = name == null ? "" : name.trim();
    if (cleaned.endsWith(".xml")) cleaned = cleaned.substring(0, cleaned.length() - 4);
    return cleaned.matches("[a-z_][a-z0-9_]*") ? cleaned : "";
  }

  /**
   * ‏1.0.197: صَفُّ «‏{@code Create class 'X'}» فِي لوحَةِ الأَخطَاءِ — نَفسُ طَرِيقِ الحِوارِ وَلكِن
   * بِلا حِوارٍ: ‏{@code kind = 0} (صِنفٌ صَرِيحٌ)، لا صَفحَةَ تَخطِيطٍ، ولا تَسنِيدَ فِي
   * ‏{@code AndroidManifest.xml}. ذَلِكَ هُوَ المَصدَرُ نَفسُهُ: صَفُّهُ مُعَلَّقٌ عَلى مُجَلَّدٍ لا
   * عَلى قَالَبٍ، وَلا ذِكرَ لِلمَنifestِ فِي تِلكَ السَّبيلِ — أمّا مُجَرَّدُ صِنفٍ «نَشَاطًا» فَلا
   * يَنبَغِي أن نَدَّعِيَهُ، فَإن أرَادَ أحَدُنَا نَشَاطًا فَحِوارُ المُتَصَفِّرِ يَعرِفُ أن يَكتُبَهُ.
   *
   * <p>لا نَكتُبُ حَتى يَتِمَّ التَّحقُّقُ: لا مُجَلَّدًا ظَاهِرًا، وَلا مُجَلَّدًا لا يَدُلُّ عَلى البَاقَةِ
   * الَّتي أَعلَنَهَا المِلَفُّ الحَامِلُ (كِبارِجِ Eclipseِ وَلا {@code java/} فِيهَا ← لا نَجرُؤُ)،
   * فَرَدُّ الصَّفِّ أنظَفُ مِن صِنفٍ ضَالٍّ. تُعيدُ {@code false} رَافِضَةً قَبلَ أن نُشغِلَ خَيطًا،
   * وَ{@code true} إذَا قُبِلَتِ المَهمَّةُ — وَالخَبَرُ عِندَ الفَراغِ فِي {@code onSettled}.
   */
  public boolean createClassForQuickFix(
      String dirPath, String className, String expectedPackage,
      java.util.function.Consumer<Boolean> onSettled) {
    if (dirPath == null || className == null || className.isEmpty() || expectedPackage == null)
      return false;
    if (!almlk.SourceLayout.isWritableDirectoryPath(dirPath)) return false;
    if (!expectedPackage.equals(almlk.SourceLayout.packageOfDirectory(dirPath))) return false;
    File dir = new File(dirPath);
    if (!dir.isDirectory()) return false;
    createClassArtifacts(dir, className, 0, false, false, "", onSettled);
    return true;
  }

  /** مهمة خلفية واحدة مرتبة: Layout (اختياري) → تسجيل المانيفست (اختياري) → ملف الكلاس. */
  private void createClassArtifacts(
      File parentDir,
      String className,
      int kind,
      boolean registerInManifest,
      boolean withLayout,
      String layoutName) {
    createClassArtifacts(parentDir, className, kind, registerInManifest, withLayout, layoutName, null);
  }

  /**
   * النسخةُ الَّتي تُخبِرُ مُطلِقَها أنَّ الأمرَ انتَهَى — {@code onSettled} تُستَدعَى عَلَى
   * الوَاجِهَةِ {@code true} إذَا وُضِعَ المِلَفُّ، وَ{@code false} إذَا رَفَضَ القَرسُ (وُجِدَ، أو
   * لَم يُمكِنَ). صَفُّ «‏{@code Create class}» فِي لوحَةِ الأَخطَاءِ لا يَقدِرُ أن يَقولَ «أُنشِئَ»
   * مِن قَبلِ أن يَنطِقَ القَرسُ، فَهُوَ مُحتَاجٌ إلَيهَا لا غَيرُهُ: الحِوارُ يَكفِيهِ أن يَرَى.
   */
  private void createClassArtifacts(
      File parentDir,
      String className,
      int kind,
      boolean registerInManifest,
      boolean withLayout,
      String layoutName,
      java.util.function.Consumer<Boolean> onSettled) {
    directoryReader.execute(
        () -> {
          String failure = null;
          File created = null;
          String body = null;
          try {
            if (!parentDir.isDirectory() && !parentDir.mkdirs())
              throw new java.io.IOException(ui("ui_error_create_subfolder"));
            String pkg = packageForDir(parentDir.getAbsolutePath().replace('\\', '/'));
            File manifest = findManifestAbove(parentDir);
            if (withLayout && manifest != null) {
              File layoutDir = new File(new File(manifest.getParentFile(), "res"), "layout");
              if (!layoutDir.isDirectory()) layoutDir.mkdirs();
              File layoutFile = new File(layoutDir, layoutName + ".xml");
              if (!layoutFile.exists())
                writeTextTo(layoutFile, xmlTemplateForFolder("layout"));
            }
            if (registerInManifest && manifest != null)
              registerComponentInManifest(manifest, pkg, className, kind);
            created = new File(parentDir, className + ".java");
            if (created.exists()) throw new java.io.IOException(ui("ui_file_already_exists"));
            body = classCodeFor(kind, pkg, className, withLayout && manifest != null, layoutName);
            writeTextTo(created, body);
          } catch (Exception error) {
            failure = UiStrings.message(getContext(), error);
            if (failure.isEmpty()) failure = ui("ui_create_failed_short");
          }
          final String problem = failure;
          final File result = created;
          final String written = body;
          mainHandler.post(
              () -> {
                if (problem != null) {
                  toast(problem);
                  // الخَبَرُ بَعدَ أن تَعلَمَ الوَاجِهَةُ كُلُّها: رَأيُنا «لَم يُنشَأ» وَحدَهُ.
                  if (onSettled != null) onSettled.accept(Boolean.FALSE);
                  return;
                }
                if (written != null && result != null && result.getName().endsWith(".java")) {
                  // كلُّ ما نَكتُبُهُ لا بُدَّ أن يَدخُلَ الحُكمَ قَبلَ أن نَتكَلَّمَ عَنهُ: فَهرَسَةُ
                  // سَطرٍ كَتَبنَاهُ آنِفًا أَحَقُّ مِن أن نَدَعَ المِلَفَّ الحَديثَ «مَجهُولَ النَّوعِ»
                  // مَرَّةً أُخرَى — وَهُوَ أَيضًا مَا يُسقِطُ صَفَّ «‏Create class» الَّذي دَعَانَا.
                  com.almlkid.kay.ui.ProjectSymbolIndex.registerSource(
                      result.getName(), result.getAbsolutePath(), written);
                }
                invalidateDirectory(fileCacheKey(parentDir));
                if (usingDocuments && currentDocument != null) {
                  invalidateDirectory(documentCacheKey(currentDocument.getUri()));
                  loadDocument(currentDocument, true);
                } else if (parentDir.equals(currentFile)) loadFile(parentDir);
                else if (currentFile != null) loadFile(currentFile);
                activate(
                    new Entry(
                        result.getName(), result, null, false, iconFor(result.getName()), 0, 0));
                // بَعدَ الفَهرَسَةِ وَالتَّحدِيثِ: مَن أَطلَقَنا يَراهُ الفَحصُ قَبلَ أن نَتكَلَّمَ عَنهُ.
                if (onSettled != null) onSettled.accept(Boolean.TRUE);
              });
        });
  }

  /** كتابة نص UTF-8 إلى ملف — مساعد خلفي صغير. */
  private static void writeTextTo(File target, String content) throws java.io.IOException {
    try (FileOutputStream out = new FileOutputStream(target)) {
      out.write(content.getBytes("UTF-8"));
    }
  }

  /** البحث صعودًا عن AndroidManifest.xml (بنية Gradle: main/ أو بنية Eclipse: الجذر). */
  private static File findManifestAbove(File dir) {
    File cursor = dir;
    for (int depth = 0; cursor != null && depth < 10; depth++) {
      File manifest = new File(cursor, "AndroidManifest.xml");
      if (manifest.isFile()) return manifest;
      cursor = cursor.getParentFile();
    }
    return null;
  }

  /** إدراج مكوّن قبل وسم إغلاق application — بالاسم المختصر إن تطابقت الحزمة وإلا الكامل. */
  private static void registerComponentInManifest(
      File manifest, String classPackage, String className, int kind)
      throws java.io.IOException {
    String text = readTextFrom(manifest);
    String closeTag = "</application>";
    int at = text.lastIndexOf(closeTag);
    if (at < 0) return; // مانيفست بلا application — لا إدراج قسريًا
    String manifestPackage = "";
    java.util.regex.Matcher m =
        java.util.regex.Pattern.compile("package\\s*=\\s*\"([^\"]+)\"").matcher(text);
    if (m.find()) manifestPackage = m.group(1);
    String reference =
        manifestPackage.equals(classPackage)
            ? "." + className
            : (classPackage.isEmpty() ? className : classPackage + "." + className);
    if (text.contains("\"" + reference + "\"")) return; // مسجل مسبقًا
    String tag = kind == 1 ? "activity" : kind == 4 ? "service" : "receiver";
    String entry = "        <" + tag + " android:name=\"" + reference + "\" />\n\n    ";
    writeTextTo(manifest, text.substring(0, at) + entry + text.substring(at));
  }

  /** قراءة ملف نصي UTF-8 — مساعد خلفي صغير. */
  private static String readTextFrom(File source) throws java.io.IOException {
    try (java.io.FileInputStream in = new java.io.FileInputStream(source)) {
      java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
      byte[] buffer = new byte[8192];
      int read;
      while ((read = in.read(buffer)) > 0) out.write(buffer, 0, read);
      return out.toString("UTF-8");
    }
  }


  /** توليد كود الكلاس حسب النوع — قوالبنا الخاصة بدلالات المرجع. ‏1.0.197: انتَقَلَ القَالَبُ إلى
   * {@link almlk.SourceTemplates} لِيَقرَأَهُ الفَحصُ كَمَا يَقرَؤُهُ المُتَصَفِّرُ — وَبَقِيَ النِّدَاءُ
   * هُنَا كَمَا هُوَ، فَالمُتَصَفِّرُ هُوَ المَسؤُولُ عَن أَسمَاءِ القَوَالِبِ وَرَقمِهَا فِي حِوارِهَا. */
  private static String classCodeFor(
      int kind, String pkg, String name, boolean withLayout, String layoutName) {
    return almlk.SourceTemplates.classCodeFor(kind, pkg, name, withLayout, layoutName);
  }

  /** قالب XML حسب بادئة اسم مجلد الموارد — بدلالات المرجع (xmlns:app وitem نموذجي). */
  private static String xmlTemplateForFolder(String folder) {
    if (folder.startsWith("layout"))
      return "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n"
          + "<LinearLayout\n"
          + "    xmlns:android=\"http://schemas.android.com/apk/res/android\"\n"
          + "    xmlns:app=\"http://schemas.android.com/apk/res-auto\"\n"
          + "    android:orientation=\"vertical\"\n"
          + "    android:layout_width=\"match_parent\"\n"
          + "    android:layout_height=\"match_parent\">\n\n"
          + "</LinearLayout>\n";
    if (folder.startsWith("menu"))
      return "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n"
          + "<menu xmlns:android=\"http://schemas.android.com/apk/res/android\"\n"
          + "    xmlns:app=\"http://schemas.android.com/apk/res-auto\">\n\n"
          + "    <item\n"
          + "        android:id=\"@+id/item\"\n"
          + "        android:title=\"Item\" />\n\n"
          + "</menu>\n";
    if (folder.startsWith("values"))
      return "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<resources>\n\n</resources>\n";
    return "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n";
  }

  /** حوار إنشاء XML: عنوان ديناميكي حسب مجلد الموارد + تحقق حي + قالب مطابق. */
  private void promptCreateXml(File dir) {
    String folder = dir.getName().toLowerCase(Locale.US);
    String base = folder.contains("-") ? folder.substring(0, folder.indexOf('-')) : folder;
    String title =
        base.isEmpty()
            ? ui("ui_create_xml_file_title")
            : uiFormat(
                "ui_create_xml_resource_title",
                Character.toUpperCase(base.charAt(0)) + base.substring(1));

    EditText input = new EditText(getContext());
    input.setHint(ui("ui_file_name_without_xml_hint"));
    input.setSingleLine(true);
    LinearLayout box = new LinearLayout(getContext());
    box.setOrientation(LinearLayout.VERTICAL);
    int pad = (int) (16 * getResources().getDisplayMetrics().density);
    box.setPadding(pad, pad / 2, pad, 0);
    box.addView(input);

    AlertDialog dialog =
        new AlertDialog.Builder(getContext())
            .setTitle(title)
            .setView(box)
            .setNegativeButton(ui("dialog_cancel"), null)
            .setPositiveButton(ui("ui_action_create"), null)
            .create();
    if (dialog.getWindow() != null)
      dialog.getWindow().setSoftInputMode(
          android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
    dialog.show();
    final Button createButton = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
    createButton.setEnabled(false);
    input.addTextChangedListener(
        new android.text.TextWatcher() {
          public void beforeTextChanged(CharSequence s, int a, int b, int c) {}

          public void onTextChanged(CharSequence s, int a, int b, int c) {}

          public void afterTextChanged(android.text.Editable s) {
            String name = sanitizeResourceName(s.toString());
            if (name.isEmpty()) {
              if (s.length() > 0) input.setError(ui("ui_resource_name_rules"));
              createButton.setEnabled(false);
              return;
            }
            if (new File(dir, name + ".xml").exists()) {
              input.setError(ui("ui_file_already_exists"));
              createButton.setEnabled(false);
              return;
            }
            createButton.setEnabled(true);
          }
        });
    createButton.setOnClickListener(
        v -> {
          String name = sanitizeResourceName(input.getText().toString());
          if (name.isEmpty()) return;
          dialog.dismiss();
          createTextFile(dir, name + ".xml", xmlTemplateForFolder(base));
        });
  }

  /** كتابة ملف نصي جديد ثم تحديث المجلد وفتحه في المحرر عبر مسار الفتح المعتاد نفسه. */
  private void createTextFile(File dir, String fileName, String content) {
    directoryReader.execute(
        () -> {
          boolean ok = false;
          String message = ui("ui_file_already_exists");
          File target = new File(dir, fileName);
          try {
            if (!target.exists()) {
              try (FileOutputStream out = new FileOutputStream(target)) {
                out.write(content.getBytes("UTF-8"));
              }
              ok = true;
            }
          } catch (Exception failure) {
            message = uiFormat("ui_create_failed", UiStrings.message(getContext(), failure));
          }
          final boolean success = ok;
          final String error = message;
          final File created = target;
          mainHandler.post(
              () -> {
                if (!success) {
                  toast(error);
                  return;
                }
                invalidateDirectory(fileCacheKey(dir));
                if (usingDocuments && currentDocument != null) {
                  invalidateDirectory(documentCacheKey(currentDocument.getUri()));
                  loadDocument(currentDocument, true);
                } else if (dir.equals(currentFile)) loadFile(dir);
                activate(new Entry(fileName, created, null, false, iconFor(fileName), 0, 0));
              });
        });
  }

  /** معاينة صورة فورية (المرجع): فك مصغّر في الخلفية ثم حوار عرض — بلا فتح في المحرر. */
  private void showImagePreview(Entry e) {
    final String title = e.name;
    final File file = e.file;
    final Uri uri = e.documentUri;
    iconLoader.execute(
        () -> {
          final Bitmap bitmap = decodeBitmap(file, uri, 1024);
          mainHandler.post(
              () -> {
                if (bitmap == null) {
                  toast(ui("ui_image_open_failed"));
                  return;
                }
                ImageView view = new ImageView(getContext());
                view.setImageBitmap(bitmap);
                view.setAdjustViewBounds(true);
                int pad = dp(16);
                view.setPadding(pad, pad, pad, pad);
                new AlertDialog.Builder(getContext())
                    .setTitle(title)
                    .setView(view)
                    .setPositiveButton(ui("ui_action_close"), null)
                    .show();
              });
        });
  }

  /** معلومات حزمة APK (المرجع): أيقونة واسم وحزمة وإصدار من أرشيف الملف نفسه. */
  private void showApkInfo(File file) {
    iconLoader.execute(
        () -> {
          PackageManager pm = getContext().getPackageManager();
          PackageInfo info = null;
          Drawable icon = null;
          CharSequence label = null;
          try {
            info = pm.getPackageArchiveInfo(file.getAbsolutePath(), 0);
            if (info != null && info.applicationInfo != null) {
              info.applicationInfo.sourceDir = file.getAbsolutePath();
              info.applicationInfo.publicSourceDir = file.getAbsolutePath();
              icon = info.applicationInfo.loadIcon(pm);
              label = info.applicationInfo.loadLabel(pm);
            }
          } catch (Throwable ignored) {
          }
          final PackageInfo packageInfo = info;
          final Drawable appIcon = icon;
          final CharSequence appLabel = label;
          mainHandler.post(
              () -> {
                if (packageInfo == null) {
                  toast(ui("ui_apk_info_failed"));
                  return;
                }
                String details =
                    uiFormat(
                        "ui_apk_package_details",
                        packageInfo.packageName,
                        packageInfo.versionName,
                        packageInfo.versionCode,
                        file.length() / 1024);
                AlertDialog.Builder builder =
                    new AlertDialog.Builder(getContext())
                        .setTitle(appLabel != null ? appLabel : file.getName())
                        .setMessage(details)
                        .setPositiveButton(ui("ui_action_close"), null);
                if (appIcon != null) builder.setIcon(appIcon);
                builder.show();
              });
        });
  }

  /** شارة المجلد: كاش فوري وإلا حلّ في الخلفية مع حارس tag ضد إعادة تدوير الصفوف. */
  private void bindFolderBadge(ImageView small, File dir) {
    final String key = dir.getAbsolutePath();
    small.setTag(key);
    Object cached = folderBadgeCache.get(key);
    if (cached instanceof Drawable) {
      small.setImageDrawable((Drawable) cached);
      small.setVisibility(VISIBLE);
      return;
    }
    if (cached != null) return; // فشل سابق مؤكد — لا إعادة فحص
    iconLoader.execute(
        () -> {
          Drawable badge = null;
          try {
            badge = resolveFolderBadge(dir);
          } catch (Throwable ignored) {
          }
          if (folderBadgeCache.size() > 256) folderBadgeCache.clear();
          folderBadgeCache.put(key, badge != null ? badge : NO_BADGE);
          final Drawable result = badge;
          if (result != null)
            mainHandler.post(
                () -> {
                  if (key.equals(small.getTag())) {
                    small.setImageDrawable(result);
                    small.setVisibility(VISIBLE);
                  }
                });
        });
  }

  /** مصغرة الملف: الصور تُفك مصغّرة، وAPK بأيقونته الحقيقية — تحل محل الأيقونة العامة. */
  private void bindFileIcon(ImageView icon, Entry e) {
    String lower = e.name.toLowerCase(Locale.US);
    boolean image = isImageName(lower);
    boolean apk = lower.endsWith(".apk");
    if (!image && !apk) return;
    final String key = e.file.getAbsolutePath() + "@" + e.modified;
    icon.setTag(key);
    Object cached = fileIconCache.get(key);
    if (cached instanceof Drawable) {
      icon.setImageDrawable((Drawable) cached);
      return;
    }
    if (cached != null) return;
    final File file = e.file;
    final boolean isApk = apk;
    iconLoader.execute(
        () -> {
          Drawable loaded = null;
          try {
            if (isApk) {
              PackageManager pm = getContext().getPackageManager();
              PackageInfo info = pm.getPackageArchiveInfo(file.getAbsolutePath(), 0);
              if (info != null && info.applicationInfo != null) {
                info.applicationInfo.sourceDir = file.getAbsolutePath();
                info.applicationInfo.publicSourceDir = file.getAbsolutePath();
                loaded = info.applicationInfo.loadIcon(pm);
              }
            } else {
              Bitmap bitmap = decodeBitmap(file, null, 64);
              if (bitmap != null) loaded = new BitmapDrawable(getResources(), bitmap);
            }
          } catch (Throwable ignored) {
          }
          if (fileIconCache.size() > 256) fileIconCache.clear();
          fileIconCache.put(key, loaded != null ? loaded : NO_BADGE);
          final Drawable result = loaded;
          if (result != null)
            mainHandler.post(
                () -> {
                  if (key.equals(icon.getTag())) icon.setImageDrawable(result);
                });
        });
  }

  /** حلّ شارة المجلد بقواعد المرجع: مجلد المشاريع → أيقونتنا؛ اسم حزمة مثبتة → أيقونتها؛ مشروع → أيقونة تطبيقه من المانيفست؛ مشروع جافا → أيقونة جافا. */
  private Drawable resolveFolderBadge(File dir) {
    String name = dir.getName();
    PackageManager pm = getContext().getPackageManager();
    if (name.equals("AppProjects") || name.equals("AideProjects")) {
      try {
        return pm.getApplicationIcon(getContext().getApplicationInfo());
      } catch (Throwable ignored) {
      }
    }
    if (name.indexOf('.') > 0 && name.length() >= 3) {
      try {
        return pm.getApplicationIcon(name);
      } catch (Throwable notInstalled) {
      }
    }
    File manifest = projectManifest(dir);
    if (manifest != null) {
      Drawable fromManifest = appIconFromManifest(manifest);
      if (fromManifest != null) return fromManifest;
    }
    if (new File(dir, ".classpath").isFile() && new File(dir, "src").isDirectory()) {
      try {
        return getContext().getDrawable(R.drawable.ic_launcher_java);
      } catch (Throwable ignored) {
      }
    }
    return null;
  }

  /** مانيفست المشروع بقواعد المرجع: Eclipse مباشرة، أو وحدات Gradle من settings.gradle/المجلدات. */
  private static File projectManifest(File dir) {
    File eclipse = new File(dir, "AndroidManifest.xml");
    if (eclipse.isFile() && new File(dir, "res").isDirectory()) return eclipse;
    File settings = new File(dir, "settings.gradle");
    boolean gradle = settings.isFile() || new File(dir, "build.gradle").isFile();
    if (!gradle) return null;
    ArrayList<File> modules = new ArrayList<>();
    if (settings.isFile()) {
      String text = readBoundedText(settings, 65536);
      java.util.regex.Matcher matcher =
          java.util.regex.Pattern.compile("['\"]:?([A-Za-z0-9_./:-]+)['\"]").matcher(text);
      while (matcher.find()) modules.add(new File(dir, matcher.group(1).replace(':', '/')));
    }
    modules.add(dir);
    File[] sub = dir.listFiles(File::isDirectory);
    if (sub != null) modules.addAll(Arrays.asList(sub));
    int checked = 0;
    for (File module : modules) {
      if (++checked > 14) break;
      File main = new File(module, "src/main/AndroidManifest.xml");
      if (main.isFile()) return main;
      File flat = new File(module, "AndroidManifest.xml");
      if (flat.isFile() && new File(module, "res").isDirectory()) return flat;
    }
    return null;
  }

  /** استخراج أيقونة التطبيق: android:icon من المانيفست ثم البحث في دلاء mipmap/drawable. */
  private Drawable appIconFromManifest(File manifest) {
    String text = readBoundedText(manifest, 262144);
    java.util.regex.Matcher matcher =
        java.util.regex.Pattern.compile(
                "android:icon\\s*=\\s*\"@(mipmap|drawable)/([A-Za-z0-9_.]+)\"")
            .matcher(text);
    if (!matcher.find()) return null;
    String iconName = matcher.group(2);
    File resRoot = new File(manifest.getParentFile(), "res");
    if (!resRoot.isDirectory()) return null;
    File[] buckets = resRoot.listFiles(File::isDirectory);
    if (buckets == null) return null;
    File best = null;
    int bestScore = -1;
    for (File bucket : buckets) {
      String bucketName = bucket.getName();
      if (!bucketName.startsWith("mipmap") && !bucketName.startsWith("drawable")) continue;
      int score =
          bucketName.contains("xxxhdpi")
              ? 5
              : bucketName.contains("xxhdpi")
                  ? 4
                  : bucketName.contains("xhdpi") ? 3 : bucketName.contains("hdpi") ? 2 : 1;
      if (score <= bestScore) continue;
      for (String ext : new String[] {".png", ".webp", ".jpg"}) {
        File candidate = new File(bucket, iconName + ext);
        if (candidate.isFile()) {
          best = candidate;
          bestScore = score;
          break;
        }
      }
    }
    if (best == null) return null;
    Bitmap bitmap = decodeBitmap(best, null, 96);
    return bitmap == null ? null : new BitmapDrawable(getResources(), bitmap);
  }

  /** قراءة نصية محدودة الحجم — آمنة للملفات الكبيرة أو المعطوبة. */
  private static String readBoundedText(File file, int max) {
    try (FileInputStream in = new FileInputStream(file)) {
      byte[] buffer = new byte[(int) Math.max(0, Math.min(file.length(), max))];
      int read = in.read(buffer);
      return read <= 0 ? "" : new String(buffer, 0, read, "UTF-8");
    } catch (Throwable failure) {
      return "";
    }
  }

  /** فكّ Bitmap بعينة مناسبة لحد الحجم — من ملف مباشر أو عبر مزوّد SAF. */
  private Bitmap decodeBitmap(File file, Uri uri, int maxSize) {
    try {
      BitmapFactory.Options bounds = new BitmapFactory.Options();
      bounds.inJustDecodeBounds = true;
      if (file != null) {
        BitmapFactory.decodeFile(file.getAbsolutePath(), bounds);
      } else if (uri != null) {
        try (InputStream in = getContext().getContentResolver().openInputStream(uri)) {
          BitmapFactory.decodeStream(in, null, bounds);
        }
      } else {
        return null;
      }
      int side = Math.max(bounds.outWidth, bounds.outHeight);
      if (side <= 0) return null;
      int sample = 1;
      while (side / sample > maxSize) sample *= 2;
      BitmapFactory.Options options = new BitmapFactory.Options();
      options.inSampleSize = sample;
      if (file != null) return BitmapFactory.decodeFile(file.getAbsolutePath(), options);
      try (InputStream in = getContext().getContentResolver().openInputStream(uri)) {
        return BitmapFactory.decodeStream(in, null, options);
      }
    } catch (Throwable failure) {
      return null;
    }
  }

  private class FolderAdapter extends BaseAdapter {
    public int getCount() {
      return entries.size();
    }

    public Object getItem(int p) {
      return entries.get(p);
    }

    public long getItemId(int p) {
      return p;
    }

    /** تقرير AIDE — المحوّل الاحترافي: ViewHolder يخزّن المراجع، فصفر findViewById بعد الإنشاء. */
    private final class EntryHolder {
      final ImageView icon;
      final ImageView small;
      final TextView name;
      final TextView info;

      EntryHolder(View v) {
        icon = v.findViewById(R.id.filebrowserEntryFileImage);
        small = v.findViewById(R.id.filebrowserEntrySmallImage);
        name = v.findViewById(R.id.filebrowserEntryName);
        info = v.findViewById(R.id.filebrowserEntryInfo);
      }
    }

    public View getView(int p, View v, ViewGroup parent) {
      EntryHolder holder;
      if (v == null) {
        v = LayoutInflater.from(getContext()).inflate(R.layout.filebrowser_entry, parent, false);
        holder = new EntryHolder(v);
        v.setTag(holder);
        v.setLayoutDirection(LAYOUT_DIRECTION_LTR);
        v.setMinimumHeight(dp(57));
        v.setBackgroundColor(Color.TRANSPARENT);
        holder.name.setTextDirection(TEXT_DIRECTION_LTR);
        holder.name.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
        holder.name.setSingleLine(false);
        holder.name.setMaxLines(2);
        holder.name.setEllipsize(android.text.TextUtils.TruncateAt.END);
      } else {
        holder = (EntryHolder) v.getTag();
        if (holder == null) {
          holder = new EntryHolder(v);
          v.setTag(holder);
        }
      }
      Entry e = entries.get(p);
      v.setPadding(dp(20 + e.depth * 18), dp(4), dp(10), dp(4));
      holder.icon.setImageResource(e.icon);
      holder.icon.setTag(null);
      holder.name.setText(e.name);
      holder.name.setTextColor(entryTheme().color(ThemeConfig.PLAIN));
      // سطر المعلومات الاختياري (المرجع): تاريخ وحجم — للملفات والمجلدات الحقيقية فقط.
      if (holder.info != null) {
        String details =
            showFileDetails() && e.action == 0 && !"..".equals(e.name)
                    && (e.file != null || e.documentUri != null)
                ? formatEntryInfo(e)
                : "";
        if (details.isEmpty()) {
          holder.info.setVisibility(GONE);
        } else {
          holder.info.setText(details);
          holder.info.setVisibility(VISIBLE);
        }
      }
      // تقرير «إظهار جميع الملفات» — لا خفوت ولا إخفاء: كل الصفوف بظهور كامل 100%؛
      // العلامة الوحيدة للمجلدات المبنية/النقطية هي أيقونة folder_hidden فقط.
      v.setAlpha(1.0f);
      // بنية المرجع: شارة مشروع فوق المجلد، ومصغرة حقيقية للصور وأيقونة APK.
      if (holder.small != null) {
        holder.small.setVisibility(GONE);
        holder.small.setTag(null);
        if (e.action == 0 && e.file != null) {
          if (e.folder) bindFolderBadge(holder.small, e.file);
          else bindFileIcon(holder.icon, e);
        }
      }
      // تمييز الملف المفتوح حاليًا في المحرر — خلفية accent شفافة كما في المرجع.
      boolean activeRow = !e.folder && e.action == 0 && isActiveEditorEntry(e);
      v.setBackgroundColor(activeRow ? Color.argb(46, 41, 182, 246) : Color.TRANSPARENT);
      return v;
    }
  }

  /** ThemeConfig واحد للمحوّل كله بدل إنشائه لكل صف (كان أثقل تكلفة عرض الصف). */
  private ThemeConfig entryTheme() {
    if (cachedEntryTheme == null) cachedEntryTheme = new ThemeConfig(getContext());
    return cachedEntryTheme;
  }

  @Override
  protected void onAttachedToWindow() {
    super.onAttachedToWindow();
    if (fileReader.isShutdown()) fileReader = Executors.newSingleThreadExecutor();
    if (directoryReader.isShutdown()) directoryReader = Executors.newFixedThreadPool(2);
    if (symbolWorker.isShutdown()) symbolWorker = Executors.newSingleThreadExecutor();
    if (projectDiagnosticsWorker.isShutdown()) projectDiagnosticsWorker = Executors.newSingleThreadExecutor();
    if (diagnosticsSnapshotWorker.isShutdown()) diagnosticsSnapshotWorker = Executors.newSingleThreadExecutor();
    if (symbolSearchWorker.isShutdown()) symbolSearchWorker = Executors.newFixedThreadPool(2);
    if (symbolIndexStore == null) symbolIndexStore = new PersistentSymbolIndexStore(getContext());
  }

  @Override
  protected void onDetachedFromWindow() {
    // تقرير فتح الملفات — جذر العطل: إغلاق الدرج يفصل هذه الواجهة لحظياً؛ كان القتل الجماعي
    // للخيوط ومسح الردود يضيع قراءة الملف معها فيعلق «جارٍ الفتح…» للأبد. الآن: التوليدات
    // تقدّم لتجاهل النتائج البالية فقط، والخدمة/الخيوط تعيش — ما يشبه خدمة المحرك في AIDE.
    openGeneration++;
    navigationGeneration++;
    if (symbolIndexStore != null) {
      symbolIndexStore.close();
      symbolIndexStore = null;
    }
    super.onDetachedFromWindow();
  }

  private int dp(int n) {
    return (int) (n * getResources().getDisplayMetrics().density + .5f);
  }
}
