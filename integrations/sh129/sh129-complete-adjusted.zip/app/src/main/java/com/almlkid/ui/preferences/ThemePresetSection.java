package com.almlkid.ui.preferences;

import almlk.EditorThemePalette;
import almlk.EditorThemePresets;
import almlk.ThemeNames;
import almlk.ThemePresetPreference;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.preference.Preference;
import android.preference.PreferenceCategory;
import android.widget.Toast;
import com.shima.demo.R;
import com.shima.demo.ThemeActivity;
import com.shima.demo.ThemeConfig;
import java.util.ArrayList;
import java.util.List;

/**
 * قسمُ الثيماتِ في شاشةِ الإعداداتِ نفسِها — لا شاشةً وسيطة: «الثيماتُ الفاتحةُ» حيثُ «الإعدادات»،
 * و«الثيماتُ الداكنةُ» حيثُ «الإعداداتُ المتقدمة» (طلبُ المستخدمِ في W15، وهو شكلُ المرجعِ أيضًا:
 * سطرُ {@code PreferenceTheme} عندهُ داخلُ مجموعةِ الثيمِ في شاشةِ الإعداداتِ المتقدمة، لا في معرضٍ
 * يُفتَحُ منها). تُزرَعُ الأسطرُ في {@link PreferenceCategory} مُعلَنةٍ في XML بمفتاحٍ، فيكونُ
 * **مكانُها** في التخطيطِ لا في الكود، وتُولَّدُ أسماؤُها من {@link EditorThemePresets} وحدَه — فلا
 * عددًا مكتوبًا في الشيفرةِ ولا ثيمًا منسيًّا.
 *
 * <p>سطرُ كلِّ ثيمٍ {@link ThemePresetPreference} (أي {@code android.preference.Preference}
 * بـ{@code widgetLayout}) فيرثُ العنوانَ والوصفَ والفاصلَ والخطَّ والحشوَ من ثيمِ الإعداداتِ كلِّه؛
 * والنقرُ **يُطبِّقُ** الثيمَ فورًا ثمَّ يُعيدُ بناءَ الشاشةِ إن قَلَبَتِ اللوحةُ لونَها، كما كان يفعلُ
 * المعرضُ — بسلوكٍ واحدٍ لا مسارَيْن. وأسفَلَ القسمِ سطرانِ يُبقيانِ قدرتينِ كانتا في قائمتِهِ:
 * مُحرِّرُ أدوارِ هذا الثيمِ ({@link ThemeActivity})، والعودةُ إلى لوحةِ المرجع.
 *
 * <p><b>قاعدةُ التَّسلسلِ (علّةُ 1.0.140):</b> لا تُبنَى مجموعةٌ ثمَّ تُرفَق — فمديرُ التفضيلاتِ ينزلُ
 * من أعلى الشجرةِ عندَ {@code addPreference}، ومجموعةٌ بلا أبٍ موصولٍ تمرُّ على
 * {@code Preference.onAttachedToHierarchy(null)} فتَنهارُ على {@code getNextId()}. هنا المجموعةُ
 * وصلتْ بنفسِها مع تضخيمِ XML قبلَ أن نُلحِقَ بها شيئًا، وهو ما تُثبِتُهُ البوابة.
 */
public final class ThemePresetSection {

  /** القسمُ وأسطرُهُ ومُلَخَّصُ سطرِ التخصيصِ — لتُحدَّثَ الحالةُ عندَ الرجوعِ لا عندَ البناءِ وحدَهُ. */
  public static final class Handle {

    private final ThemeConfig theme;
    private final List<String> codes = new ArrayList<>();
    private final List<ThemePresetPreference> rows = new ArrayList<>();
    private Preference reference; // سطرُ الثيمِ الافتراضيّ — اسمُهُ من موردِهِ كسائرِ الثيمات
    private Preference customize; // سطرُ مُحرِّرِ الأدوارِ — وُلِدَ بعدَ Handle فلا يُمرُّ في الباني

    private Handle(ThemeConfig theme) {
      this.theme = theme;
    }

    /** الشاشةُ تُعيدُ هذا بعدَ كلِّ رجوعٍ من مُحرِّرِ الألوانِ (onResume) فَيُوضَحُ «المُطبَّقُ». */
    public void refresh() {
      String active = theme.themeCode();
      for (int i = 0; i < rows.size(); i++) {
        String code = codes.get(i);
        rows.get(i)
            .setPreview(
                EditorThemePresets.previewColors(code), code.equals(active));
      }
      if (reference != null) {
        // النشِطُ يحملُ الاسمَ والوصفَ معًا، وغيرُهُ يبقى على دلالتِهِ: الرجوعُ إلى الأساسيةِ المسماةِ كاي أسود.
        boolean base = EditorThemePalette.DEFAULT_THEME_CODE.equals(active);
        reference.setTitle(
            ThemeNames.title(
                reference.getContext(),
                base ? active : EditorThemePalette.DEFAULT_THEME_CODE));
        reference.setSummary(
            reference
                .getContext()
                .getString(
                    base
                        ? R.string.theme_gallery_row_summary
                        : R.string.theme_gallery_reference,
                    ThemeNames.title(
                        reference.getContext(), EditorThemePalette.DEFAULT_THEME_CODE),
                    theme.schemeName(reference.getContext())));
      }
      if (customize != null) {
        customize.setSummary(
            customize
                .getContext()
                .getString(
                    R.string.theme_gallery_row_summary,
                    ThemeNames.title(customize.getContext(), active),
                    theme.schemeName(customize.getContext())));
      }
    }
  }

  private ThemePresetSection() {}

  /**
   * يملأُ مجموعةً مُعلَنةً في XML بأسطرِ لوحةٍ بعينِها، ويُرجِعُ ما يُحدِّثُ حالتَها. المجموعةُ يجبُ أن
   * تكونَ موصولةً بشاشةٍ حاملةِ مديرٍ — أي أن تكونَ من XML أو {@code addPreference} مسبقًا.
   */
  public static Handle fill(
      PreferenceCategory category, Context context, EditorThemePresets.Preset[] presets) {
    ThemeConfig theme = new ThemeConfig(context);
    Handle handle = new Handle(theme);
    for (EditorThemePresets.Preset preset : presets) {
      ThemePresetPreference row = new ThemePresetPreference(context);
      row.setTitle(ThemeNames.text(context, "theme_" + preset.code, preset.code));
      row.setSummary(ThemeNames.text(context, "theme_" + preset.code + "_summary", ""));
      row.setOnPreferenceClickListener(
          preference -> {
            apply(context, theme, handle, preset.code);
            return true;
          });
      handle.codes.add(preset.code);
      handle.rows.add(row);
      category.addPreference(row);
    }
    Preference customize = new Preference(context);
    customize.setTitle(R.string.theme_gallery_customize);
    customize.setOnPreferenceClickListener(
        preference -> {
          context.startActivity(new Intent(context, ThemeActivity.class));
          return true;
        });
    category.addPreference(customize);
    handle.customize = customize;
    Preference reference = new Preference(context);
    // لا «لوحةَ مرجعٍ» بلا اسمٍ: الثيمُ الافتراضيُّ الأسودُ اسمُهُ «كاي أسود» في كلِّ لغة، ويظهرُ هنا كما
    // يظهرُ في رأسِ شاشةِ الألوانِ — موردٌ واحدٌ اسمُهُ theme_default، لا اسمَ ثانٍ للوحةٍ واحدة.
    reference.setTitle(ThemeNames.title(context, EditorThemePalette.DEFAULT_THEME_CODE));
    reference.setOnPreferenceClickListener(
        preference -> {
          apply(context, theme, handle, EditorThemePalette.DEFAULT_THEME_CODE);
          Toast.makeText(context, R.string.theme_gallery_applied_reference, Toast.LENGTH_SHORT)
              .show();
          return true;
        });
    category.addPreference(reference);
    handle.reference = reference;
    handle.refresh();
    return handle;
  }

  /** التطبيقُ عندَ الاختيارِ نفسِه: وعاءُ الرمزِ ونمطُ التطبيق، ثمَّ إعادةُ بناءِ الشاشةِ إن قَلَبَتِ اللوحة. */
  private static void apply(Context context, ThemeConfig theme, Handle handle, String code) {
    boolean wasDark = theme.isDark();
    theme.applyTheme(code);
    if (!EditorThemePalette.DEFAULT_THEME_CODE.equals(code)) {
      Toast.makeText(context, context.getString(R.string.theme_gallery_applied,
              ThemeNames.title(context, code)), Toast.LENGTH_SHORT)
          .show();
    }
    if (theme.isDark() != wasDark && context instanceof Activity) {
      Activity host = (Activity) context;
      if (!host.isFinishing()) host.recreate(); // الشريطُ والأيقوناتُ والقوائمُ من اللوحةِ الجديدة
    } else {
      handle.refresh();
    }
  }
}
