package com.shima.projects;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.res.AssetManager;
import android.graphics.Color;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.BaseExpandableListAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ExpandableListView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import com.shima.demo.UiStrings;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import almlk.TemplateCatalog;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * معالج إنشاء المشاريع بدلالات المرجع: قوالب JSON مصنفة من assets، حوار اسم/حزمة
 * بتحقق حي واسم تلقائي App/App2، نسخ القالب مع استبدالات $package_name$/$project_name$،
 * ثم فتح ملفات البداية. كل الأعمال الثقيلة في خيوط خلفية.
 *
 * <p>الحوارُ الرئيسيُّ بأزرارِهِ الثلاثةِ كما في المرجعِ وصورةِ المستخدمِ: «GIT» (استنساخُ
 * مستودعٍ في مجلدِ المشاريعِ) و«CANCEL» و«MORE» (كشفُ الفئاتِ المخفيّةِ وتوسيعُ الكلِّ).
 * ونموذجُ القوالبِ وتحقُّقُهُ وقيمُ المُنتقياتِ كلُّها في {@link almlk.TemplateCatalog} الصافيِّ،
 * فيُختبَرُ العقدُ على المضيفِ قبلَ أيِّ لمسةٍ على الجهازِ.
 */
public final class ProjectWizard {

  /** يستلم نتيجة الإنشاء/الاستيراد على خيط الواجهة. */
  public interface Host {
    void onProjectCreated(File projectRoot, File mainModule, List<File> starterFiles);

    void onProjectImported(File targetDirectory);

    /**
     * استنساخُ مستودعٍ في `targetDirectory/<اسمِ المستودعِ>` ثمَّ إخطارُ المُستهلِكِ بالنتيجةِ.
     * المنفِّذُ يملكُ الصدفةَ وحدَهُ (و`run_as_root`)، فلا git هنا ولا مسارَ ظلٍّ ثانِيَ.
     */
    void cloneRepository(File targetDirectory, String url, CloneListener listener);
  }

  /** نتيجةُ الاستنساخِ على خيطِ الواجهةِ: null = نجحَ، غيرُها = سببٌ يُعرَضُ للمستخدمِ. */
  public interface CloneListener {
    void onCloneFinished(File clonedRoot, String failureMessage);
  }

  private ProjectWizard() {}

  private static String ui(Activity activity, String key) {
    return UiStrings.get(activity, key);
  }

  private static String uiFormat(Activity activity, String key, Object... values) {
    return UiStrings.format(activity, key, values);
  }

  // ===== الأيقوناتُ =====

  /** أيقوناتُ الحوارِ بدلالاتِ المرجعِ: الفئةُ ببوصلةِ الاستوديو، والأنواعُ بأيقوناتِها الخاصّةِ. */
  private static int iconResource(String name) {
    if ("ic_androidstudio".equals(name)) return com.shima.demo.R.drawable.ic_androidstudio;
    if ("ic_project_android".equals(name)) return com.shima.demo.R.drawable.ic_project_android;
    if ("ic_project_xposed".equals(name)) return com.shima.demo.R.drawable.ic_project_xposed;
    if ("ic_project_java".equals(name)) return com.shima.demo.R.drawable.file_type_java;
    if ("ic_tpl_admob".equals(name)) return com.shima.demo.R.drawable.ic_tpl_admob;
    if ("ic_tpl_firebase".equals(name)) return com.shima.demo.R.drawable.ic_tpl_firebase;
    if ("ic_tpl_kotlin".equals(name)) return com.shima.demo.R.drawable.ic_tpl_kotlin;
    if ("ic_tpl_gradle".equals(name)) return com.shima.demo.R.drawable.ic_tpl_gradle;
    if ("ic_tpl_rocket".equals(name)) return com.shima.demo.R.drawable.ic_tpl_rocket;
    return com.shima.demo.R.drawable.ic_project_android;
  }

  /** نقطةُ الدخولِ: فحصُ قابليةِ الكتابةِ ثمَّ حوارُ اختيارِ القالبِ — كما في المرجعِ. */
  public static void show(Activity activity, File targetDirectory, Host host) {
    show(activity, targetDirectory, host, false);
  }

  /**
   * الحوارُ نفسُهُ بحالتَيْهِ: `more=false` يُخفي الفئاتِ الثانويّةَ (كصورةِ المستخدمِ: أربعُ
   * فئاتٍ والأولى موسَّعةٌ)، و`more=true` يكشفُ كلَّ شيءٍ ويوسِّعُ الكلَّ — لا شاشةً ثانيةً.
   */
  private static void show(
      final Activity activity, final File targetDirectory, final Host host, final boolean more) {
    if (targetDirectory == null || !isWritableDirectory(targetDirectory)) {
      new AlertDialog.Builder(activity)
          .setTitle(ui(activity, "ui_project_wizard_alert"))
          .setMessage(
              ui(activity, "ui_project_wizard_cannot_write"))
          .setPositiveButton(ui(activity, "ui_action_ok"), null)
          .show();
      return;
    }
    final TemplateCatalog catalog = loadCatalog(activity);
    if (catalog.templateCount() == 0) {
      Toast.makeText(activity, ui(activity, "ui_project_creation_unavailable"), Toast.LENGTH_SHORT).show();
      return;
    }
    final List<TemplateCatalog.Category> categories =
        more ? catalog.categories() : catalog.categories(false);
    if (categories.isEmpty()) {
      Toast.makeText(activity, ui(activity, "ui_project_creation_unavailable"), Toast.LENGTH_SHORT).show();
      return;
    }
    final ExpandableListView listView = new ExpandableListView(activity);
    AlertDialog dialog =
        new AlertDialog.Builder(activity)
            .setTitle(ui(activity, "ui_project_wizard_title"))
            .setView(listView)
            .setNeutralButton(ui(activity, "ui_wizard_action_git"), null)
            .setNegativeButton(ui(activity, "dialog_cancel"), null)
            .setPositiveButton(ui(activity, more ? "ui_action_ok" : "ui_wizard_action_more"), null)
            .create();
    listView.setAdapter(new TemplateAdapter(activity, categories));
    listView.setOnChildClickListener(
        (parent, view, group, child, id) -> {
          dialog.dismiss();
          promptDetails(activity, targetDirectory, categories.get(group).entries.get(child), host);
          return true;
        });
    dialog.show();
    for (int i = 0; i < categories.size(); i++) {
      if (more || i == 0) listView.expandGroup(i);
    }
    if (more) {
      listView.post(() -> Toast.makeText(activity, ui(activity, "ui_project_wizard_more_hint"), Toast.LENGTH_SHORT).show());
    }
    // الزرُّ الإيجابِيُّ يُلغي الحوارَ وحدَهُ؛ هنا يُعادُ ربطُهُ ليكشفَ الفئاتِ ويُبقي السياقَ.
    dialog.getButton(AlertDialog.BUTTON_POSITIVE)
        .setOnClickListener(v -> {
          dialog.dismiss();
          if (!more) show(activity, targetDirectory, host, true);
        });
    dialog.getButton(AlertDialog.BUTTON_NEUTRAL)
        .setOnClickListener(v -> {
          dialog.dismiss();
          promptClone(activity, targetDirectory, host);
        });
  }

  /** زرُّ GIT: عنوانُ المستودعِ ثمَّ الاستنساخُ على صدفةِ المضيفِ (احترامُ run_as_root هناك). */
  private static void promptClone(final Activity activity, final File target, final Host host) {
    EditText input = new EditText(activity);
    input.setHint(ui(activity, "ui_wizard_git_url_hint"));
    input.setSingleLine(true);
    LinearLayout wrap = new LinearLayout(activity);
    int pad = dp(activity, 24);
    wrap.setPadding(pad, 0, pad, 0);
    wrap.addView(
        input,
        new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
    AlertDialog dialog =
        new AlertDialog.Builder(activity)
            .setTitle(ui(activity, "ui_wizard_git_title"))
            .setView(wrap)
            .setNegativeButton(ui(activity, "dialog_cancel"), null)
            .setPositiveButton(ui(activity, "ui_wizard_git_action"), null)
            .create();
    dialog.show();
    dialog.getButton(AlertDialog.BUTTON_POSITIVE)
        .setOnClickListener(
            v -> {
              String url = input.getText().toString().trim();
              if (url.isEmpty()) {
                input.setError(ui(activity, "ui_wizard_git_empty_url"));
                return;
              }
              dialog.dismiss();
              final AlertDialog progress =
                  new AlertDialog.Builder(activity)
                      .setMessage(uiFormat(activity, "ui_wizard_git_cloning", url))
                      .setCancelable(false)
                      .create();
              progress.show();
              host.cloneRepository(
                  target,
                  url,
                  (clonedRoot, failure) -> {
                    progress.dismiss();
                    if (failure != null) {
                      Toast.makeText(activity, uiFormat(activity, "ui_wizard_git_failed", failure), Toast.LENGTH_LONG)
                          .show();
                    } else {
                      Toast.makeText(activity, uiFormat(activity, "ui_wizard_git_done",
                              clonedRoot == null ? url : clonedRoot.getName()), Toast.LENGTH_SHORT)
                          .show();
                    }
                  });
            });
  }

  // ===== حوار بيانات المشروع: اسم/حزمة بتحقق حي (بنية المرجع) =====
  private static void promptDetails(
      Activity activity, File target, TemplateCatalog.Entry template, Host host) {
    LinearLayout layout = new LinearLayout(activity);
    layout.setOrientation(LinearLayout.VERTICAL);
    int pad = dp(activity, 24);
    layout.setPadding(pad, dp(activity, 12), pad, 0);

    // رأس المرجع createproject: نوع المشروع ثم الموقع بسطر صغير.
    TextView typeLabel = new TextView(activity);
    typeLabel.setText(ui(activity, template.titleKey));
    typeLabel.setTextSize(16);
    typeLabel.setTypeface(null, android.graphics.Typeface.BOLD);
    TextView locationLabel = new TextView(activity);
    locationLabel.setText(new File(target, "").getAbsolutePath());
    locationLabel.setTextSize(12);
    locationLabel.setTextColor(Color.GRAY);
    locationLabel.setPadding(0, dp(activity, 4), 0, dp(activity, 10));
    layout.addView(typeLabel);
    layout.addView(locationLabel);

    TextView nameLabel = new TextView(activity);
    nameLabel.setText(ui(activity, "ui_project_name_label"));
    EditText nameInput = new EditText(activity);
    nameInput.setSingleLine(true);
    TextView pkgLabel = new TextView(activity);
    pkgLabel.setText(ui(activity, "ui_project_package_label"));
    pkgLabel.setPadding(0, dp(activity, 10), 0, 0);
    EditText pkgInput = new EditText(activity);
    pkgInput.setSingleLine(true);
    layout.addView(nameLabel);
    layout.addView(nameInput);
    layout.addView(pkgLabel);
    layout.addView(pkgInput);

    AlertDialog dialog =
        new AlertDialog.Builder(activity)
            .setTitle(ui(activity, template.titleKey))
            .setView(layout)
            .setNegativeButton(ui(activity, "dialog_cancel"), null)
            .setPositiveButton(ui(activity, "ui_action_create"), null)
            .create();
    if (dialog.getWindow() != null)
      dialog.getWindow().setSoftInputMode(
          android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
    dialog.show();
    Button create = dialog.getButton(AlertDialog.BUTTON_POSITIVE);

    String defaultName = freeProjectName(target);
    // `advanced_setting_package_prefix`: البادئةُ من الإعداداتِ لا من نصٍّ ثابتٍ (كما في المرجعِ:
    // «Set the package name prefix of the project to be created. If left blank, the default
    // will be used»). والحقلُ يُعادُ تقديرُهُ مع كلِّ تعديلٍ للاسمِ ما لم يلمسْهُ المستخدمُ بيدِهِ.
    final String prefix = almlk.AppSettings.packagePrefix(activity);
    final boolean[] pkgTouched = {false};
    final boolean[] applyingPackage = {false};
    nameInput.setText(defaultName);
    pkgInput.setText(almlk.ProjectNaming.packageFor(prefix, defaultName));
    nameInput.addTextChangedListener(
        new TextWatcher() {
          public void beforeTextChanged(CharSequence s, int a, int b, int c) {}

          public void onTextChanged(CharSequence s, int a, int b, int c) {
            if (pkgTouched[0]) return;
            applyingPackage[0] = true;
            pkgInput.setText(almlk.ProjectNaming.packageFor(prefix, s.toString()));
            applyingPackage[0] = false;
          }

          public void afterTextChanged(Editable s) {}
        });
    pkgInput.addTextChangedListener(
        new TextWatcher() {
          public void beforeTextChanged(CharSequence s, int a, int b, int c) {}

          public void onTextChanged(CharSequence s, int a, int b, int c) {
            if (!applyingPackage[0]) pkgTouched[0] = true;
          }

          public void afterTextChanged(Editable s) {}
        });
    nameInput.selectAll();

    Runnable validate =
        () -> {
          String name = nameInput.getText().toString().trim();
          String pkg = pkgInput.getText().toString().trim();
          boolean ok = isValidProjectName(name);
          if (ok && new File(target, name).exists()) {
            nameInput.setError(ui(activity, "ui_project_name_exists"));
            ok = false;
          }
          if (ok && !isValidPackage(pkg)) ok = false;
          create.setEnabled(ok);
        };
    TextWatcher watcher =
        new TextWatcher() {
          public void beforeTextChanged(CharSequence s, int a, int b, int c) {}

          public void onTextChanged(CharSequence s, int a, int b, int c) {
            validate.run();
          }

          public void afterTextChanged(Editable s) {}
        };
    nameInput.addTextChangedListener(watcher);
    pkgInput.addTextChangedListener(watcher);
    validate.run();

    // ===== مُنتقياتُ الإصداراتِ: صفوفٌ تحتَ حقلِ الحزمةِ، بعددِ ما يعلنُهُ القالبُ نفسِهِ =====
    // المصدرُ واحدٌ: `versions[]` في templates.json عبرَ TemplateCatalog.spinners() — فلا جدولَ
    // مُنتقياتٍ في الجافا ولا قالبٌ يحتاجُ تعديلَ حوارٍ ليزيدَ إصدارًا. صفرُ مُنتقياتٍ = صفرُ
    // صفوفَ (ndk_app وxposed_app وjava_console كما كانتْ). والقيمةُ المختارةُ لا تُبدِّلُ شيئًا في
    // الحوارِ: تُقرأُ عندَ الضغطِ على «إنشاءِ» وتُمرَرُ إلى variablesFor وحدها (مسارُ استبدالٍ واحدٌ).
    final List<TemplateCatalog.VersionSpec> specs = template.spinners();
    final List<Spinner> pickers = new ArrayList<>();
    if (!specs.isEmpty()) {
      android.widget.ScrollView versions = new android.widget.ScrollView(activity);
      LinearLayout box = new LinearLayout(activity);
      box.setOrientation(LinearLayout.VERTICAL);
      for (TemplateCatalog.VersionSpec spec : specs) {
        if (spec.options.isEmpty()) continue;
        TextView label = new TextView(activity);
        label.setText(ui(activity, spec.labelKey));
        label.setTextSize(12);
        label.setTextColor(Color.GRAY);
        label.setPadding(0, dp(activity, 10), 0, 0);
        Spinner picker = new Spinner(activity);
        ArrayAdapter<String> adapter =
            new ArrayAdapter<>(
                activity, android.R.layout.simple_spinner_item, new ArrayList<>(spec.options));
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        picker.setAdapter(adapter);
        picker.setSelection(spec.defaultIndex);
        box.addView(label);
        box.addView(picker);
        pickers.add(picker);
      }
      versions.addView(box);
      LinearLayout.LayoutParams lp =
          new LinearLayout.LayoutParams(
              LinearLayout.LayoutParams.MATCH_PARENT,
              LinearLayout.LayoutParams.WRAP_CONTENT);
      versions.setLayoutParams(lp);
      layout.addView(versions);
    }

    create.setOnClickListener(
        v -> {
          Map<String, String> chosen = new LinkedHashMap<>();
          for (int i = 0; i < pickers.size() && i < specs.size(); i++) {
            Object selected = pickers.get(i).getSelectedItem();
            if (selected != null) chosen.put(specs.get(i).key + "_version", selected.toString());
          }
          dialog.dismiss();
          createProject(
              activity,
              target,
              template,
              nameInput.getText().toString().trim(),
              pkgInput.getText().toString().trim(),
              chosen,
              host);
        });
  }

  // ===== الإنشاء: نسخ القالب مع الاستبدالات في خيط خلفي (بنية المرجع) =====
  private static void createProject(
      Activity activity,
      File target,
      TemplateCatalog.Entry template,
      String name,
      String pkg,
      Map<String, String> chosen,
      Host host) {
    AlertDialog progress =
        new AlertDialog.Builder(activity)
            .setMessage(ui(activity, "ui_project_creating"))
            .setCancelable(false)
            .create();
    progress.show();
    new Thread(
            () -> {
              Exception failure = null;
              final File root = new File(target, name);
              File mainModule =
                  template.main == null || template.main.isEmpty()
                      ? root
                      : new File(root, template.main);
              try {
                copyAssetTree(
                    activity,
                    activity.getAssets(),
                    "templates/" + template.id,
                    root,
                    pkg.replace('.', '/'),
                    name,
                    pkg,
                    template,
                    template.variablesFor(chosen));
                // ثلاثُ لمساتٍ على القرصِ بعدَ النسخِ، كلها في almlk.ProjectScaffold (صافٍ مُختبَرٍ):
                // الحزمةُ في المانيفستِ، أسطرُ المُنتقياتِ الناقصةُ في dependencies{}، ودليلُ build.
                // المسارُ من قارئِ الطبقةِ الصافيةِ: ‏`src/main/` للتخطيطِ الحديثِ، وجذرُ
                // الوحدةِ لتخطيطِ ADT — فما يقرؤهُ التحليلُ هو ما نكتبُهُ لا غيرُهُ.
                almlk.ProjectScaffold.rewriteManifest(
                    almlk.AndroidManifestModel.find(mainModule),
                    pkg,
                    template.wantsManifestPackage());
                almlk.ProjectScaffold.injectDependencyLines(
                    almlk.GradleDependencyEditor.buildFileIn(mainModule),
                    template.dependencyLines(template.variablesFor(chosen)));
                almlk.ProjectScaffold.ensureBuildDirs(mainModule, root);
              } catch (Exception error) {
                failure = error;
              }
              final Exception error = failure;
              activity.runOnUiThread(
                  () -> {
                    progress.dismiss();
                    if (error != null) {
                      Toast.makeText(
                              activity, uiFormat(activity, "ui_project_create_failed", error.getMessage()), Toast.LENGTH_LONG)
                          .show();
                      return;
                    }
                    ArrayList<File> starters = new ArrayList<>();
                    for (String relative : template.open) {
                      File starter =
                          new File(root, relative.replace("$package_name$", pkg.replace('.', '/')));
                      if (starter.isFile()) starters.add(starter);
                    }
                    Toast.makeText(activity, uiFormat(activity, "ui_project_created", name), Toast.LENGTH_SHORT).show();
                    if (host != null) host.onProjectCreated(root, mainModule, starters);
                  });
            })
        .start();
  }

  /**
   * نسخ شجرة assets إلى القرص: مجلد «pkg» يتحول لمسار الحزمة، أسماء «dot_» تستعيد
   * نقطتها (aapt يقصي الملفات النقطية من assets)، والملفات النصية تمر بالاستبدالات.
   */
  private static void copyAssetTree(
      Activity activity,
      AssetManager assets,
      String source,
      File destination,
      String pkgPath,
      String name,
      String pkg,
      TemplateCatalog.Entry template,
      Map<String, String> variables)
      throws Exception {
    String[] children = assets.list(source);
    if (children != null && children.length > 0) {
      for (String child : children) {
        String childDest = child;
        if (child.equals("pkg")) childDest = pkgPath;
        else if (child.startsWith("dot_")) childDest = "." + child.substring(4);
        copyAssetTree(
            activity,
            assets,
            source + "/" + child,
            new File(destination, childDest),
            pkgPath,
            name,
            pkg,
            template,
            variables);
      }
      return;
    }
    File parent = destination.getParentFile();
    if (parent != null && !parent.exists() && !parent.mkdirs())
      throw new java.io.IOException(uiFormat(activity, "ui_create_failed_short", parent.getName()));
    try (InputStream in = assets.open(source)) {
      byte[] raw = readAll(in);
      // الاستبدالُ محكومٌ بـ`replaces` من مخطَّطِ القالبِ (لا كلُّ نصٍّ يُلمَسُ: ملفٌ ثنائيٌّ
      // أو LICENSE لا يجوزُ عبثُ الكتابةِ فيهِ)، ويطالُ طوابعَ المُنتقياتِ أيضًا.
      boolean substitutable = isTextTemplate(destination.getName())
          && (template == null || template.substitutes(destination.getName()));
      if (substitutable) {
        String text = new String(raw, "UTF-8");
        text =
            text.replace("$package_name$", pkg)
                .replace("$project_name$", name)
                .replace("$package_name_jni$", pkg.replace('.', '_'));
        if (variables != null) {
          for (Map.Entry<String, String> var : variables.entrySet()) {
            text = text.replace("$" + var.getKey() + "$", var.getValue());
          }
        }
        raw = text.getBytes("UTF-8");
      }
      try (FileOutputStream out = new FileOutputStream(destination)) {
        out.write(raw);
      }
    }
  }

  // ===== استيراد مشروع من ZIP (بنية المرجع) =====
  private static void promptImport(Activity activity, File target, Host host) {
    EditText input = new EditText(activity);
    input.setHint(ui(activity, "ui_new_file_path_hint"));
    input.setSingleLine(true);
    LinearLayout wrap = new LinearLayout(activity);
    int pad = dp(activity, 24);
    wrap.setPadding(pad, 0, pad, 0);
    wrap.addView(
        input,
        new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
    new AlertDialog.Builder(activity)
        .setTitle(ui(activity, "ui_import_project_title"))
        .setMessage(ui(activity, "ui_import_project_message"))
        .setView(wrap)
        .setNegativeButton(ui(activity, "dialog_cancel"), null)
        .setPositiveButton(
            ui(activity, "ui_action_import"),
            (d, w) -> {
              File zip = new File(input.getText().toString().trim());
              if (!zip.isFile()) {
                Toast.makeText(activity, ui(activity, "ui_project_imported_path_invalid"), Toast.LENGTH_SHORT).show();
                return;
              }
              importZip(activity, zip, target, host);
            })
        .show();
  }

  private static void importZip(Activity activity, File zip, File target, Host host) {
    AlertDialog progress =
        new AlertDialog.Builder(activity)
            .setMessage(ui(activity, "ui_project_importing"))
            .setCancelable(false)
            .create();
    progress.show();
    new Thread(
            () -> {
              Exception failure = null;
              try {
                unzip(activity, zip, target);
              } catch (Exception error) {
                failure = error;
              }
              final Exception error = failure;
              activity.runOnUiThread(
                  () -> {
                    progress.dismiss();
                    if (error != null) {
                      Toast.makeText(
                              activity, uiFormat(activity, "ui_project_import_failed", error.getMessage()), Toast.LENGTH_LONG)
                          .show();
                      return;
                    }
                    Toast.makeText(activity, ui(activity, "ui_project_imported"), Toast.LENGTH_SHORT).show();
                    if (host != null) host.onProjectImported(target);
                  });
            })
        .start();
  }

  /** فك آمن: حارس Zip-Slip يرفض أي مدخل يخرج عن المجلد الهدف. */
  private static void unzip(Activity activity, File zip, File target) throws Exception {
    String canonicalTarget = target.getCanonicalPath() + File.separator;
    try (ZipInputStream in = new ZipInputStream(new FileInputStream(zip))) {
      ZipEntry entry;
      byte[] buffer = new byte[16384];
      while ((entry = in.getNextEntry()) != null) {
        File out = new File(target, entry.getName());
        if (!out.getCanonicalPath().startsWith(canonicalTarget))
          throw new SecurityException(uiFormat(activity, "ui_error_unsafe_zip_entry", entry.getName()));
        if (entry.isDirectory()) {
          out.mkdirs();
          continue;
        }
        File parent = out.getParentFile();
        if (parent != null) parent.mkdirs();
        try (FileOutputStream stream = new FileOutputStream(out)) {
          int read;
          while ((read = in.read(buffer)) > 0) stream.write(buffer, 0, read);
        }
      }
    }
  }

  // ===== تحميل القوالب والمساعدات =====
  /** يقرأُ `templates/templates.json` عبرَ الكتالوجِ الصافيِّ، ويسجِّلُ ملاحظاتِ التحقُّقِ. */
  private static TemplateCatalog loadCatalog(Activity activity) {
    try (InputStream in = activity.getAssets().open("templates/templates.json")) {
      TemplateCatalog catalog = TemplateCatalog.parse(new String(readAll(in), "UTF-8"));
      if (!catalog.error().isEmpty()) {
        android.util.Log.w("ShimaTemplates", catalog.error());
      }
      return catalog;
    } catch (Exception failure) {
      android.util.Log.w("ShimaTemplates", String.valueOf(failure));
      return TemplateCatalog.parse("");
    }
  }

  /** أول اسم حر بنمط App/App2/App3 في المجلد الهدف — سلوك المرجع الحرفي. */
  private static String freeProjectName(File target) {
    for (int i = 1; i < 1000; i++) {
      String candidate = i == 1 ? "App" : "App" + i;
      if (!new File(target, candidate).exists()) return candidate;
    }
    return "App";
  }

  private static boolean isValidProjectName(String name) {
    return !name.isEmpty() && !name.matches(".*[\\\\/:*?\"<>|].*") && !name.startsWith(".");
  }

  private static boolean isValidPackage(String pkg) {
    // القاعدةُ في almlk.ProjectNaming وحدها: هي التي يطمئنُّ إليها دمجُ المانيفستِ أيضًا، فالحقلُ
    // لا يقبلُ ما يرفضُهُ الدمجُ بعدَ ثوانٍ من الضغطِ على «إنشاءِ».
    return almlk.ProjectNaming.isApplicationPackage(pkg);
  }

  private static boolean isWritableDirectory(File directory) {
    try {
      if (!directory.exists() && !directory.mkdirs()) return false;
      File probe = new File(directory, ".shima_write_probe");
      if (probe.createNewFile()) {
        probe.delete();
        return true;
      }
    } catch (Throwable ignored) {
    }
    return false;
  }

  private static boolean isTextTemplate(String name) {
    String lower = name.toLowerCase(java.util.Locale.US);
    return !(lower.endsWith(".png")
        || lower.endsWith(".jpg")
        || lower.endsWith(".webp")
        || lower.endsWith(".jar")
        || lower.endsWith(".zip"));
  }

  private static byte[] readAll(InputStream in) throws Exception {
    java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
    byte[] buffer = new byte[16384];
    int read;
    while ((read = in.read(buffer)) > 0) out.write(buffer, 0, read);
    return out.toByteArray();
  }

  private static int dp(Activity activity, int value) {
    return (int) (value * activity.getResources().getDisplayMetrics().density + 0.5f);
  }

  // ===== مهايئ قائمة القوالب: فئة قابلة للطي، وبند بعنوان ووصف (بنية المرجع) =====
  private static final class TemplateAdapter extends BaseExpandableListAdapter {
    private final Activity activity;
    private final List<TemplateCatalog.Category> categories;

    TemplateAdapter(Activity activity, List<TemplateCatalog.Category> categories) {
      this.activity = activity;
      this.categories = categories;
    }

    public int getGroupCount() {
      return categories.size();
    }

    public int getChildrenCount(int group) {
      return categories.get(group).entries.size();
    }

    public Object getGroup(int group) {
      return categories.get(group);
    }

    public Object getChild(int group, int child) {
      return categories.get(group).entries.get(child);
    }

    public long getGroupId(int group) {
      return group;
    }

    public long getChildId(int group, int child) {
      return group * 1000L + child;
    }

    public boolean hasStableIds() {
      return true;
    }

    public boolean isChildSelectable(int group, int child) {
      return true;
    }

    public View getGroupView(int group, boolean expanded, View convert, android.view.ViewGroup parent) {
      LinearLayout layout;
      if (convert instanceof LinearLayout) {
        layout = (LinearLayout) convert;
      } else {
        layout = new LinearLayout(activity);
        layout.setOrientation(LinearLayout.HORIZONTAL);
        layout.setGravity(Gravity.CENTER_VERTICAL);
        layout.setMinimumHeight(dp(activity, 56));
        layout.setPadding(dp(activity, 40), dp(activity, 4), dp(activity, 12), dp(activity, 4));
        android.widget.ImageView icon = new android.widget.ImageView(activity);
        icon.setLayoutParams(new LinearLayout.LayoutParams(dp(activity, 34), dp(activity, 34)));
        TextView title = new TextView(activity);
        title.setTextSize(17);
        title.setPadding(dp(activity, 14), 0, 0, 0);
        layout.addView(icon);
        layout.addView(title);
      }
      TemplateCatalog.Category category = categories.get(group);
      ((android.widget.ImageView) layout.getChildAt(0)).setImageResource(iconResource(category.icon));
      TextView title = (TextView) layout.getChildAt(1);
      title.setText(ui(activity, category.titleKey));
      // لا لونَ مُفرَضًا: لونُ النصِّ يأتي من الثيمِ (فرضُ الأبيضِ يَخرُقُ الشاشاتِ الفاتحةَ).
      title.setTypeface(null, android.graphics.Typeface.BOLD);
      return layout;
    }

    public View getChildView(
        int group, int child, boolean last, View convert, android.view.ViewGroup parent) {
      LinearLayout layout;
      if (convert instanceof LinearLayout) {
        layout = (LinearLayout) convert;
      } else {
        // بنية صف المرجع createproject_entry: أيقونة 40dp + عمود عنوان/وصف، ارتفاع 60dp.
        layout = new LinearLayout(activity);
        layout.setOrientation(LinearLayout.HORIZONTAL);
        layout.setGravity(Gravity.CENTER_VERTICAL);
        layout.setMinimumHeight(dp(activity, 60));
        layout.setPadding(dp(activity, 40), dp(activity, 5), dp(activity, 12), dp(activity, 5));
        android.widget.ImageView icon = new android.widget.ImageView(activity);
        icon.setLayoutParams(new LinearLayout.LayoutParams(dp(activity, 40), dp(activity, 40)));
        LinearLayout texts = new LinearLayout(activity);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.setPadding(dp(activity, 10), 0, 0, 0);
        TextView title = new TextView(activity);
        title.setTextSize(15);
        TextView description = new TextView(activity);
        description.setTextSize(12);
        description.setTextColor(Color.GRAY);
        description.setPadding(0, dp(activity, 2), 0, 0);
        texts.addView(title);
        texts.addView(description);
        layout.addView(icon);
        layout.addView(texts);
      }
      TemplateCatalog.Entry entry = categories.get(group).entries.get(child);
      ((android.widget.ImageView) layout.getChildAt(0)).setImageResource(iconResource(entry.icon));
      LinearLayout texts = (LinearLayout) layout.getChildAt(1);
      ((TextView) texts.getChildAt(0)).setText(ui(activity, entry.titleKey));
      ((TextView) texts.getChildAt(1)).setText(ui(activity, entry.descriptionKey));
      return layout;
    }
  }
}
