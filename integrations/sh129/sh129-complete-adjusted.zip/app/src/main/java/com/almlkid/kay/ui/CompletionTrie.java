package com.almlkid.kay.ui;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Lightweight case-insensitive prefix tree for zero-scan completion lookups. */
public final class CompletionTrie<T> {
  private final Node<T> root = new Node<>();

  public void clear() {
    root.children.clear();
    root.values.clear();
  }

  public void put(String key, T value) {
    if (key == null || key.isEmpty() || value == null) return;
    Node<T> node = root;
    String normalized = key.toLowerCase(Locale.US);
    for (int i = 0; i < normalized.length(); i++) {
      Character character = normalized.charAt(i);
      Node<T> child = node.children.get(character);
      if (child == null) {
        child = new Node<>();
        node.children.put(character, child);
      }
      node = child;
    }
    if (!node.values.contains(value)) node.values.add(value);
  }

  public List<T> prefix(String prefix, int limit) {
    int max = Math.max(1, limit);
    Node<T> node = root;
    String normalized = prefix == null ? "" : prefix.toLowerCase(Locale.US);
    for (int i = 0; i < normalized.length(); i++) {
      node = node.children.get(normalized.charAt(i));
      if (node == null) return new ArrayList<>();
    }
    ArrayList<T> result = new ArrayList<>();
    collect(node, result, max);
    return result;
  }

  private void collect(Node<T> node, List<T> result, int limit) {
    for (T value : node.values) {
      if (result.size() >= limit) return;
      result.add(value);
    }
    for (Node<T> child : node.children.values()) {
      if (result.size() >= limit) return;
      collect(child, result, limit);
    }
  }

  private static final class Node<T> {
    final java.util.LinkedHashMap<Character, Node<T>> children = new java.util.LinkedHashMap<>();
    final ArrayList<T> values = new ArrayList<>();
  }
}
