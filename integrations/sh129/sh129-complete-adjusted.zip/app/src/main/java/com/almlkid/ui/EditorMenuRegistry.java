package com.almlkid.ui;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;

/**
 * سجل أوامر سياق المحرر. شريط التحديد والجذر والفروع والقائمة المصغرة تستعلم التعريفات نفسها؛
 * الواجهة لا تنشئ صفوفًا موازية ولا تعيد شروط اللغة/الأهلية.
 */
public final class EditorMenuRegistry {
  public static final String PAGE_TOOLBAR = "toolbar";
  public static final String PAGE_ROOT = "root";
  public static final String PAGE_FIX = "fix";
  public static final String PAGE_TOOLS = "tools";
  public static final String PAGE_REFACTOR = "refactor";
  public static final String PAGE_CODE = "code";
  public static final String PAGE_FORMAT = "format";
  public static final String PAGE_FIND = "find";
  public static final String PAGE_SMALL = "small";

  /** مساهمة حية (Fix أو أداة تحديد)؛ لا تظهر إن لم يوردها المزود في لقطة السياق. */
  public static final class DynamicCommand {
    public final String id;
    public final String title;
    public final boolean enabled;
    public final String disabledReason;
    public final Runnable action;

    public DynamicCommand(
        String id, String title, boolean enabled, String disabledReason, Runnable action) {
      this.id = id;
      this.title = title;
      this.enabled = enabled;
      this.disabledReason = disabledReason == null ? "" : disabledReason;
      this.action = action;
    }
  }

  /** لقطة ذرية تُبنى قبل العرض/التحضير؛ لا تحتفظ بها الواجهة بين حدثين. */
  public static final class Context {
    public boolean xml;
    public boolean layoutXml;
    public boolean writable = true;
    public boolean hasOpenFile;
    public boolean hasSelection;
    public boolean hasText;
    public boolean hasFieldTarget;
    public boolean hasColor;
    public boolean hasClipboardText;
    public boolean canExpand;
    public List<DynamicCommand> fixes = Collections.emptyList();
    public List<DynamicCommand> tools = Collections.emptyList();
  }

  /** أمر محلول للعرض الآن، شامل سبب التعطيل والمسار الفرعي أو الفعل الديناميكي. */
  public static final class Entry {
    public final String id;
    public final String title;
    public final boolean enabled;
    public final String disabledReason;
    public final String subpage;
    public final Runnable dynamicAction;

    Entry(
        String id,
        String title,
        boolean enabled,
        String disabledReason,
        String subpage,
        Runnable dynamicAction) {
      this.id = id;
      this.title = title;
      this.enabled = enabled;
      this.disabledReason = disabledReason == null ? "" : disabledReason;
      this.subpage = subpage;
      this.dynamicAction = dynamicAction;
    }

    public boolean isSubmenu() {
      return subpage != null;
    }
  }

  private interface Rule {
    boolean test(Context context);
  }

  private interface Reason {
    String text(Context context);
  }

  private static final class Spec {
    final String id, title, subpage;
    final Rule visible, enabled;
    final Reason reason;

    Spec(
        String id,
        String title,
        String subpage,
        Rule visible,
        Rule enabled,
        Reason reason) {
      this.id = id;
      this.title = title;
      this.subpage = subpage;
      this.visible = visible;
      this.enabled = enabled;
      this.reason = reason;
    }
  }

  private static final Rule ALWAYS = context -> true;
  private final LinkedHashMap<String, ArrayList<Spec>> pages = new LinkedHashMap<>();

  public EditorMenuRegistry() {
    // شريط ActionMode: التعريف نفسه يضبط الأهلية الحية في onPrepareActionMode.
    // المرحلة 3: زر الإصلاح في الشريط نفسه (قبل ⛶) متى حمل التشخيص تحت التحديد إصلاحًا.
    add(PAGE_TOOLBAR, "fix", "command_fix", PAGE_FIX, c -> hasDisplayableDynamic(c.fixes), ALWAYS,
        c -> "");
    // زر التحديد الوحيد كالمرجع: ⛶ يظهر دائمًا (كلمة/سطر/كتلة/الملف) بتحديد أو بدونه.
    add(PAGE_TOOLBAR, "expand", "keybind_expand_selection", null, ALWAYS,
        c -> c.canExpand, c -> "ui_reason_no_larger_selection");
    add(PAGE_TOOLBAR, "cut", "command_cut", null, c -> c.hasSelection,
        c -> c.writable, c -> "ui_file_read_only");
    add(PAGE_TOOLBAR, "copy", "command_copy", null, c -> c.hasSelection, ALWAYS,
        c -> "");
    add(PAGE_TOOLBAR, "paste", "command_paste", null, ALWAYS,
        c -> c.hasClipboardText && c.writable,
        c -> !c.hasClipboardText ? "ui_reason_clipboard_empty" : "ui_file_read_only");
    add(PAGE_TOOLBAR, "more", "command_more", PAGE_ROOT, ALWAYS, ALWAYS, c -> "");

    // الجذر: Color أول عنصر إذا وفقط إذا حل الفهرس literal واحدًا.
    add(PAGE_ROOT, "color", "command_color", null, c -> c.hasColor, c -> c.writable,
        c -> "ui_file_read_only");
    add(PAGE_ROOT, "fix", "command_fix", PAGE_FIX, c -> hasDisplayableDynamic(c.fixes), ALWAYS,
        c -> "");
    add(PAGE_ROOT, "tools", "ui_selection_tools", PAGE_TOOLS, c -> hasDisplayableDynamic(c.tools), ALWAYS,
        c -> "");
    add(PAGE_ROOT, "select_all", "keybind_select_all", null, ALWAYS,
        c -> c.hasText, c -> "ui_reason_empty_document");
    // المرحلة السابعة: حل مراجع XML (@type/name) من فهرس موارد المشروع.
    add(PAGE_ROOT, "goto", "command_go_to", null, ALWAYS, ALWAYS, c -> "");
    // المرحلة السابعة: توثيق XML يستعلم بنوع المورد واسمه.
    add(PAGE_ROOT, "documentation", "command_documentation", null, ALWAYS, ALWAYS, c -> "");
    // المرحلة 5: نقطة توقف حقيقية (أعلام أسطر) — متاحة لملفات Java.
    add(PAGE_ROOT, "breakpoint", "command_breakpoint", null, ALWAYS, c -> !c.xml,
        c -> c.xml ? "ui_reason_breakpoint_xml_unavailable" : "");
    add(PAGE_ROOT, "refactor", "command_refactor", PAGE_REFACTOR, ALWAYS, ALWAYS, c -> "");
    add(PAGE_ROOT, "code", "command_code", PAGE_CODE, ALWAYS, ALWAYS, c -> "");
    add(PAGE_ROOT, "format", "command_format", PAGE_FORMAT, ALWAYS, ALWAYS, c -> "");
    add(PAGE_ROOT, "find", "command_find", PAGE_FIND, ALWAYS, ALWAYS, c -> "");
    add(PAGE_ROOT, "close", "command_close_file", null, ALWAYS, c -> c.hasOpenFile,
        c -> "ui_reason_no_open_file");

    // المرحلة 2: إعادة التسمية حقيقية (Renamer) — متاحة بتحديد وملف قابل للكتابة.
    add(PAGE_REFACTOR, "rename", "command_rename", null, ALWAYS,
        c -> c.hasSelection && c.writable,
        c -> !c.hasSelection ? "ui_reason_no_selection" : "ui_file_read_only");
    // المرحلة 3: أوامر إعادة البناء حقيقية (almlk/Refactor) — Java فقط بتحديد+كتابة.
    add(PAGE_REFACTOR, "inline", "command_inline_variable", null, ALWAYS,
        c -> !c.xml && c.hasSelection && c.writable,
        c -> c.xml ? "ui_reason_java_only" : !c.hasSelection ? "ui_reason_no_selection" : "ui_file_read_only");
    add(PAGE_REFACTOR, "introduce", "command_introduce_variable", null, ALWAYS,
        c -> !c.xml && c.hasSelection && c.writable,
        c -> c.xml ? "ui_reason_java_only" : !c.hasSelection ? "ui_reason_no_selection" : "ui_file_read_only");
    add(PAGE_REFACTOR, "extract_method", "command_extract_method", null, ALWAYS,
        c -> !c.xml && c.hasSelection && c.writable,
        c -> c.xml ? "ui_reason_java_only" : !c.hasSelection ? "ui_reason_no_selection" : "ui_file_read_only");

    add(PAGE_CODE, "organize_imports", "command_organize_imports", null, ALWAYS,
        c -> !c.xml && c.writable,
        c -> c.xml ? "ui_reason_java_only" : "ui_file_read_only");
    add(PAGE_CODE, "surround_try", "command_surround_with_trycatch", null, ALWAYS,
        c -> !c.xml && c.writable,
        c -> c.xml ? "ui_reason_java_only" : "ui_file_read_only");
    // المرحلة السادسة: التعليق وفكّه يعملان في XML عبر محرك almlk المستقل (وسوم <!-- --> لا //).
    add(PAGE_CODE, "comment", "command_outcomment_code", null, ALWAYS, c -> c.writable,
        c -> "ui_file_read_only");
    add(PAGE_CODE, "uncomment", "command_unoutcomment_code", null, ALWAYS, c -> c.writable,
        c -> "ui_file_read_only");
    // المرحلة 4: توليد الكود حقيقي (almlk/CodeGen).
    add(PAGE_CODE, "create_setters", "command_create_setters_and_getters", null, ALWAYS,
        c -> !c.xml && c.hasFieldTarget && c.writable,
        c -> c.xml ? "ui_reason_java_only"
            : !c.hasFieldTarget ? "ui_reason_field_target_required" : "ui_file_read_only");
    add(PAGE_CODE, "create_constructor", "command_create_constructor", null, ALWAYS,
        c -> !c.xml && c.writable,
        c -> c.xml ? "ui_reason_java_only" : "ui_file_read_only");
    add(PAGE_CODE, "extract_resources", "command_extract_resources", null, ALWAYS,
        c -> c.xml && c.hasSelection && c.writable,
        c -> !c.xml ? "ui_reason_xml_only" : !c.hasSelection ? "ui_reason_select_text" : "ui_file_read_only");
    add(PAGE_CODE, "replace", "menu_replace", null, ALWAYS,
        c -> c.hasSelection && c.writable,
        c -> !c.hasSelection ? "ui_reason_no_selection" : "ui_file_read_only");

    // المرحلة السادسة: منسق XML بنيوي مستقل (إعادة إزاحة فقط) بدل تعطيل التنسيق في XML.
    add(PAGE_FORMAT, "format_code", "command_format_code", null, ALWAYS, c -> c.writable,
        c -> "ui_file_read_only");
    // المرحلة 5: تعلم النمط يستدل الإزاحة ويحفظها — متاح بملف قابل للكتابة.
    add(PAGE_FORMAT, "learn_style", "command_learn_code_style", null, ALWAYS, c -> c.writable,
        c -> "ui_file_read_only");
    // المرحلة الثامنة: إعداد نمط الكود صار شاشة فعلية (CodeStyleActivity) — بلا سبب تعطيل.
    add(PAGE_FORMAT, "configure_style", "command_configure_code_style", null, ALWAYS, ALWAYS, c -> "");

    // المرحلة السابعة: استخدامات موارد XML عبر تثبيت المدى على اسم المورد.
    add(PAGE_FIND, "find_usages", "command_find_usages", null, ALWAYS, ALWAYS, c -> "");
    // المرحلة السابعة: تبقى على مسار find_usages نفسه كما في Java — لا دلالة مخترعة بلا مرجع.
    add(PAGE_FIND, "find_extended", "command_find_extended_usages", null, ALWAYS, ALWAYS, c -> "");
    add(PAGE_FIND, "find_text", "command_find_textually", null, ALWAYS, c -> c.hasSelection,
        c -> "ui_reason_no_selection");

    // القائمة المصغرة بلا تحديد تقرأ Fix الديناميكي نفسه ولا تحمل ستة عناصر صلبة.
    add(PAGE_SMALL, "edit", "command_edit", null, ALWAYS, c -> c.writable,
        c -> "ui_file_read_only");
    add(PAGE_SMALL, "fix", "command_fix", PAGE_FIX, c -> hasDisplayableDynamic(c.fixes), ALWAYS,
        c -> "");
    add(PAGE_SMALL, "design", "command_design", null, c -> c.layoutXml, c -> c.writable,
        c -> "ui_file_read_only");
  }

  private void add(
      String page,
      String id,
      String title,
      String subpage,
      Rule visible,
      Rule enabled,
      Reason reason) {
    ArrayList<Spec> specs = pages.get(page);
    if (specs == null) {
      specs = new ArrayList<>();
      pages.put(page, specs);
    }
    specs.add(new Spec(id, title, subpage, visible, enabled, reason));
  }

  public List<Entry> entries(String page, Context context) {
    if (PAGE_FIX.equals(page)) return dynamicEntries(context == null ? null : context.fixes, 6);
    if (PAGE_TOOLS.equals(page)) return dynamicEntries(context == null ? null : context.tools, Integer.MAX_VALUE);
    ArrayList<Spec> specs = pages.get(page);
    if (specs == null || context == null) return Collections.emptyList();
    ArrayList<Entry> result = new ArrayList<>();
    for (Spec spec : specs) {
      if (!spec.visible.test(context)) continue;
      boolean enabled = spec.enabled.test(context);
      result.add(new Entry(
          spec.id,
          spec.title,
          enabled,
          enabled ? "" : spec.reason.text(context),
          spec.subpage,
          null));
    }
    return result;
  }

  private static List<Entry> dynamicEntries(List<DynamicCommand> values, int maximum) {
    ArrayList<Entry> result = new ArrayList<>();
    List<DynamicCommand> source = safe(values);
    for (int i = 0; i < source.size() && result.size() < maximum; i++) {
      DynamicCommand item = source.get(i);
      if (!isDisplayable(item)) continue;
      result.add(new Entry(
          item.id,
          item.title,
          item.enabled,
          item.enabled ? "" : item.disabledReason,
          null,
          item.action));
    }
    return result;
  }

  private static boolean hasDisplayableDynamic(List<DynamicCommand> values) {
    for (DynamicCommand item : safe(values)) if (isDisplayable(item)) return true;
    return false;
  }

  private static boolean isDisplayable(DynamicCommand item) {
    return item != null && item.title != null && !item.title.trim().isEmpty();
  }

  private static <T> List<T> safe(List<T> values) {
    return values == null ? Collections.emptyList() : values;
  }

  public String titleForPage(String page) {
    if (PAGE_FIX.equals(page)) return "command_fix";
    if (PAGE_TOOLS.equals(page)) return "ui_selection_tools";
    if (PAGE_REFACTOR.equals(page)) return "command_refactor";
    if (PAGE_CODE.equals(page)) return "command_code";
    if (PAGE_FORMAT.equals(page)) return "command_format";
    if (PAGE_FIND.equals(page)) return "command_find";
    return null;
  }
}
