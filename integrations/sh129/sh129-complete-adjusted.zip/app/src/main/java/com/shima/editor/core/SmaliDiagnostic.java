package com.shima.editor.core;

import java.util.Locale;

public final class SmaliDiagnostic {
  public enum Severity { INFO, WARNING, ERROR }

  public final int offset;
  public final int end;
  public final int line;
  public final int column;
  public final Severity severity;
  public final String code;
  public final String message;
  public final String messageKey;
  public final Object[] messageArgs;

  public SmaliDiagnostic(
      int offset,
      int end,
      int line,
      int column,
      Severity severity,
      String code,
      String message) {
    this(offset, end, line, column, severity, code, message, null, new Object[0]);
  }

  private SmaliDiagnostic(
      int offset,
      int end,
      int line,
      int column,
      Severity severity,
      String code,
      String message,
      String messageKey,
      Object[] messageArgs) {
    this.offset = Math.max(0, offset);
    this.end = Math.max(this.offset + 1, end);
    this.line = Math.max(1, line);
    this.column = Math.max(1, column);
    this.severity = severity == null ? Severity.ERROR : severity;
    this.code = code == null ? "SMALI" : code;
    this.message = message == null ? "" : message;
    this.messageKey = messageKey;
    this.messageArgs = messageArgs == null ? new Object[0] : messageArgs.clone();
  }

  public static SmaliDiagnostic localized(
      int offset,
      int end,
      int line,
      int column,
      Severity severity,
      String code,
      String messageKey,
      String fallback,
      Object... arguments) {
    String message = fallback;
    try {
      if (arguments != null && arguments.length > 0) message = String.format(Locale.US, fallback, arguments);
    } catch (RuntimeException ignored) {
    }
    return new SmaliDiagnostic(
        offset, end, line, column, severity, code, message, messageKey, arguments);
  }
}
