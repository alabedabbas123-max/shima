package com.almlkid.kay.ui;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Fast lexical usage scanner. It preserves offsets while ignoring comments and string literals. */
public final class UsageSearchEngine {
  private UsageSearchEngine() {}

  public static List<Usage> findUsages(
      String fileName, String reference, String source, String symbol, int declarationOffset) {
    if (source == null || symbol == null || symbol.isEmpty()) return Collections.emptyList();
    String masked = mask(source);
    int[] lineStarts = lineStarts(source);
    ArrayList<Usage> result = new ArrayList<>();
    int from = 0;
    while (from <= masked.length() - symbol.length() && result.size() < 1000) {
      int offset = masked.indexOf(symbol, from);
      if (offset < 0) break;
      int end = offset + symbol.length();
      boolean left = offset > 0 && Character.isJavaIdentifierPart(masked.charAt(offset - 1));
      boolean right = end < masked.length() && Character.isJavaIdentifierPart(masked.charAt(end));
      if (!left && !right && (declarationOffset < 0 || offset != declarationOffset)) {
        int lineIndex = lineIndexAt(lineStarts, offset);
        int lineStart = lineStarts[lineIndex];
        int lineEnd = source.indexOf('\n', end);
        if (lineEnd < 0) lineEnd = source.length();
        String preview = source.substring(lineStart, Math.min(lineEnd, lineStart + 240)).trim();
        int next = end;
        while (next < masked.length() && Character.isWhitespace(masked.charAt(next))) next++;
        String kind = next < masked.length() && masked.charAt(next) == '(' ? "method" : "reference";
        result.add(
            new Usage(
                fileName,
                reference,
                offset,
                lineIndex + 1,
                offset - lineStart + 1,
                end - lineStart + 1,
                preview,
                kind));
      }
      from = offset + Math.max(1, symbol.length());
    }
    return result;
  }

  private static int[] lineStarts(String source) {
    int lines = 1;
    for (int i = 0; i < source.length(); i++) if (source.charAt(i) == '\n') lines++;
    int[] starts = new int[lines];
    int index = 1;
    starts[0] = 0;
    for (int i = 0; i < source.length(); i++) {
      if (source.charAt(i) == '\n' && index < starts.length) starts[index++] = i + 1;
    }
    return starts;
  }

  private static int lineIndexAt(int[] starts, int offset) {
    int low = 0, high = starts.length - 1;
    while (low < high) {
      int middle = (low + high + 1) >>> 1;
      if (starts[middle] <= offset) low = middle;
      else high = middle - 1;
    }
    return low;
  }

  /** Finds a declaration offset for a class, method, or field in one source file. */
  public static int findDeclarationOffset(String source, String symbol) {
    if (source == null || symbol == null || symbol.isEmpty()) return -1;
    String masked = mask(source);
    String quoted = Pattern.quote(symbol);
    Pattern[] declarations = {
      Pattern.compile("\\b(?:class|interface|enum|record)\\s+(" + quoted + ")\\b"),
      Pattern.compile("(?m)(?:^|[;{}])\\s*(?:[A-Za-z_$][A-Za-z0-9_$<>?,. \\t\\[\\]]*\\s+)+(" + quoted + ")\\s*\\("),
      Pattern.compile("(?m)(?:^|[;{}])\\s*(?:[A-Za-z_$][A-Za-z0-9_$<>?,. \\t\\[\\]]*\\s+)+(" + quoted + ")\\s*(?:=|;|\\[)")
    };
    for (Pattern declaration : declarations) {
      Matcher matcher = declaration.matcher(masked);
      if (matcher.find()) return matcher.start(1);
    }
    return -1;
  }

  public static String identifierAt(String source, int start, int end) {
    if (source == null || source.isEmpty()) return "";
    int left = Math.max(0, Math.min(start, source.length()));
    int right = Math.max(left, Math.min(end, source.length()));
    if (left == right && left < source.length() && !Character.isJavaIdentifierPart(source.charAt(left))) {
      if (left > 0) left--;
    }
    while (left > 0 && Character.isJavaIdentifierPart(source.charAt(left - 1))) left--;
    while (right < source.length() && Character.isJavaIdentifierPart(source.charAt(right))) right++;
    return left < right ? source.substring(left, right) : "";
  }

  public static String mask(String source) {
    StringBuilder out = new StringBuilder(source);
    boolean line = false, block = false, escape = false;
    char quote = 0;
    for (int i = 0; i < source.length(); i++) {
      char c = source.charAt(i);
      char next = i + 1 < source.length() ? source.charAt(i + 1) : 0;
      if (c == '\n') {
        line = false;
        escape = false;
        continue;
      }
      if (line) {
        out.setCharAt(i, ' ');
      } else if (block) {
        out.setCharAt(i, ' ');
        if (c == '*' && next == '/') {
          out.setCharAt(++i, ' ');
          block = false;
        }
      } else if (quote != 0) {
        out.setCharAt(i, ' ');
        if (escape) escape = false;
        else if (c == '\\') escape = true;
        else if (c == quote) quote = 0;
      } else if (c == '/' && next == '/') {
        out.setCharAt(i, ' ');
        out.setCharAt(++i, ' ');
        line = true;
      } else if (c == '/' && next == '*') {
        out.setCharAt(i, ' ');
        out.setCharAt(++i, ' ');
        block = true;
      } else if (c == '"' || c == '\'' || c == '`') {
        out.setCharAt(i, ' ');
        quote = c;
      }
    }
    return out.toString();
  }

  public static final class Usage {
    public final String fileName;
    public final String reference;
    public final int offset, line, column;
    /**
     * عمودٌ 1-based حصريٌّ يُغلقُ مَدَى الاستعمالِ على سطرِهِ. صفُّ الاستعمالِ يَعرِفُ مَدَاهُ
     * (المطابقةُ مَحسوبةُ الطرفينِ هنا)، والمرجعُ يَنقُلُهُ كلَّهُ إلى القفزةِ: ‏`m214j6(tl.Hw, tl.v5,
     * tl.Zo, tl.VH)` — لا «سطرٌ وعمودٌ ثمَّ حدِّدِ الكلمةَ تحتَ المؤشِّرِ». و‏`= column + الرمزُ طولًا`
     * لكلِّ استعمالٍ، فلا يُخمَّنُ شيءٌ عندَ العرضِ.
     */
    public final int endColumn;
    public final String preview, kind;

    public Usage(
        String fileName,
        String reference,
        int offset,
        int line,
        int column,
        int endColumn,
        String preview,
        String kind) {
      this.fileName = fileName == null ? "" : fileName;
      this.reference = reference == null ? "" : reference;
      this.offset = offset;
      this.line = line;
      this.column = column;
      this.endColumn = Math.max(column, endColumn);
      this.preview = preview == null ? "" : preview;
      this.kind = kind == null ? "reference" : kind;
    }

    @Override
    public String toString() {
      return fileName + ":" + line + ":" + column + "  " + preview;
    }
  }
}
