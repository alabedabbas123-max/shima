package com.shima.demo;

import android.content.Context;
import android.os.Bundle;
import android.preference.PreferenceActivity;

/**
 * PreferenceActivity base that resolves resources in the currently selected app locale and applies the
 * chrome style of the selected editor palette — the same {@code almlk.ChromeTheme} every other activity
 * obeys.
 *
 * <p>ولمَ كانَ هذا مطلوبًا؟ لأنَّ شاشةَ الإعداداتِ هي <em>موضعَ</em> اختيارِ الثيم: كانت ترثُ هذه القاعدةَ
 * التي تُمرِّرُ اللغةَ فقط، فأيُّ لوحةٍ تُختارُ من هنا تُبقِي شريطَ الإعداداتِ وخلفيةَهُ وقوائمَهُ سوداءَ
 * على بياضٍ في المحرِّر — وهو ما بلَّغَ عنهُ المستخدمُ في 1.0.143: «لا يتغيَّرُ لونُ شريطِ الأدواتِ والعناصرِ
 * كلِّها». ولا تُلوَّنُ السطورُ يدويًّا هنا أيضًا: النمطُ كلُّ ما يُطبَّق، ومثلهُ في {@link
 * LocaleAwareActivity} حرفيًّا.
 */
public abstract class LocaleAwarePreferenceActivity extends PreferenceActivity {
  private final almlk.ChromeTheme.Applied chrome = new almlk.ChromeTheme.Applied();

  @Override
  protected void attachBaseContext(Context base) {
    super.attachBaseContext(ShimaApplication.localize(base));
  }

  @Override
  protected void onCreate(Bundle state) {
    chrome.install(this, appChromeTheme());
    super.onCreate(state);
  }

  @Override
  protected void onResume() {
    super.onResume();
    chrome.follow(this);
  }

  /** صفرٌ لمن لهُ نمطُهُ الخاصُّ به. */
  protected int appChromeTheme() {
    return almlk.ChromeTheme.resolve(this);
  }
}
