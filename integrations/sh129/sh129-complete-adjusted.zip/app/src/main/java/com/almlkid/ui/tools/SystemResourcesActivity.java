package com.almlkid.ui.tools;

import android.app.AlertDialog;
import android.content.Intent;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.TextWatcher;
import android.text.style.ForegroundColorSpan;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import com.shima.demo.LocaleAwareActivity;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/**
 * أدوات › أخرى › عرض موارد النظام: android.R (String، Color، Theme، Drawable، TextAppearance)
 * بقوائم بحث مرقّمة يُبرز فيها التطابق، وحوار تفاصيل (المعرّف ومرجعا Java وXML) بقائمة نسخ،
 * ومعاينة السمة (حقل نص، وزر AlertDialog، وشريط SeekBar). نشاط واحد تحدد وضعه الإضافات.
 */
public final class SystemResourcesActivity extends LocaleAwareActivity {

  /** هذه الشاشةُ تختارُ ثيمَ معاينتِها نفسَها (setTheme قبلَ super.onCreate) فلا يُعادُ فوقَهُ قرارٌ: فلا يُمَسُّ نمطُها بنمطِ اللوحة. */
  @Override
  protected int appChromeTheme() {
    return 0;
  }


  static final String EXTRA_TYPE = "type";
  static final String EXTRA_PREVIEW_THEME = "preview_theme";
  static final String EXTRA_PREVIEW_NAME = "preview_name";
  static final String[] TYPES = {"string", "color", "theme", "drawable", "textappearance"};
  static final String[] TYPE_LABELS = {
    "tools_res_string", "tools_res_color", "tools_res_theme", "tools_res_drawable", "tools_res_textappearance"
  };

  /** مورد نظام: الاسم كما في R، والمعرّف. */
  static final class Entry {
    final String name;
    final int id;
    String value;

    Entry(String name, int id) {
      this.name = name;
      this.id = id;
    }
  }

  private String type;
  private final List<Entry> all = new ArrayList<>();
  private List<Entry> shown = new ArrayList<>();
  private String query = "";
  private int highlight;
  private final EntryAdapter adapter = new EntryAdapter();

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    int previewTheme = getIntent().getIntExtra(EXTRA_PREVIEW_THEME, 0);
    if (previewTheme != 0) setTheme(previewTheme);
    super.onCreate(savedInstanceState);
    if (getActionBar() != null) getActionBar().setDisplayHomeAsUpEnabled(true);
    TypedArray a = obtainStyledAttributes(new int[] {android.R.attr.colorAccent});
    highlight = a.getColor(0, 0xFF2196F3);
    a.recycle();
    if (previewTheme != 0) {
      showPreview(getIntent().getStringExtra(EXTRA_PREVIEW_NAME));
      return;
    }
    type = getIntent().getStringExtra(EXTRA_TYPE);
    if (type == null) {
      showCategories();
    } else {
      showList();
    }
  }

  private void showCategories() {
    setTitle(ToolDialogs.ui(this, "menu_view_system_resources"));
    ListView list = new ListView(this);
    String[] labels = new String[TYPES.length];
    for (int i = 0; i < labels.length; i++) labels[i] = ToolDialogs.ui(this, TYPE_LABELS[i]);
    list.setAdapter(new android.widget.ArrayAdapter<>(this, android.R.layout.simple_list_item_1, labels));
    list.setOnItemClickListener((p, v, position, id) ->
        startActivity(new Intent(this, SystemResourcesActivity.class).putExtra(EXTRA_TYPE, TYPES[position])));
    setContentView(list);
  }

  /** حقول android.R.&lt;class&gt; العامة الثابتة من نوع int، مرتبة بالاسم. */
  static List<Entry> fields(Class<?> owner, String prefix) {
    ArrayList<Entry> out = new ArrayList<>();
    for (Field f : owner.getFields()) {
      int m = f.getModifiers();
      if (!Modifier.isStatic(m) || f.getType() != int.class) continue;
      if (prefix != null && !f.getName().startsWith(prefix)) continue;
      try {
        out.add(new Entry(f.getName(), f.getInt(null)));
      } catch (IllegalAccessException ignored) {
        // حقل غير متاح.
      }
    }
    Collections.sort(out, (x, y) -> x.name.compareToIgnoreCase(y.name));
    return out;
  }

  private void showList() {
    int index = java.util.Arrays.asList(TYPES).indexOf(type);
    setTitle(ToolDialogs.ui(this, TYPE_LABELS[Math.max(0, index)]));
    switch (type) {
      case "string": all.addAll(fields(android.R.string.class, null)); break;
      case "color": all.addAll(fields(android.R.color.class, null)); break;
      case "drawable": all.addAll(fields(android.R.drawable.class, null)); break;
      case "theme": all.addAll(fields(android.R.style.class, "Theme")); break;
      default: all.addAll(fields(android.R.style.class, "TextAppearance")); break;
    }
    if ("string".equals(type)) {
      for (Entry e : all) {
        try {
          e.value = getString(e.id);
        } catch (RuntimeException missing) {
          e.value = "";
        }
      }
    }
    LinearLayout root = new LinearLayout(this);
    root.setOrientation(LinearLayout.VERTICAL);
    final EditText search = new EditText(this);
    search.setSingleLine(true);
    search.setHint(ToolDialogs.uiFormat(this, "tools_res_search", all.size()));
    int pad = ToolDialogs.dp(this, 8);
    LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2);
    sp.setMargins(pad, pad / 2, pad, 0);
    root.addView(search, sp);
    ListView list = new ListView(this);
    list.setFastScrollEnabled(true);
    list.setAdapter(adapter);
    list.setOnItemClickListener((p, v, position, id) -> showDetail(shown.get(position)));
    root.addView(list, new LinearLayout.LayoutParams(-1, 0, 1));
    setContentView(root);
    search.addTextChangedListener(new TextWatcher() {
      @Override public void beforeTextChanged(CharSequence s, int a1, int a2, int a3) {}
      @Override public void onTextChanged(CharSequence s, int a1, int a2, int a3) {}
      @Override public void afterTextChanged(Editable s) {
        query = s.toString().trim().toLowerCase(Locale.ROOT);
        filter();
      }
    });
    filter();
  }

  private void filter() {
    ArrayList<Entry> out = new ArrayList<>();
    for (Entry e : all) {
      if (query.isEmpty() || e.name.toLowerCase(Locale.ROOT).contains(query)
          || (e.value != null && e.value.toLowerCase(Locale.ROOT).contains(query))) {
        out.add(e);
      }
    }
    shown = out;
    adapter.notifyDataSetChanged();
  }

  private CharSequence marked(String text) {
    SpannableStringBuilder span = new SpannableStringBuilder(text);
    if (query.isEmpty()) return span;
    String lower = text.toLowerCase(Locale.ROOT);
    for (int at = lower.indexOf(query); at >= 0; at = lower.indexOf(query, at + query.length())) {
      span.setSpan(new ForegroundColorSpan(highlight), at, at + query.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
    }
    return span;
  }

  private Drawable drawable(Entry e) {
    try {
      return getDrawable(e.id);
    } catch (RuntimeException missing) {
      return null;
    }
  }

  private Drawable colorSwatch(Entry e) {
    int color;
    try {
      color = getColor(e.id);
    } catch (RuntimeException missing) {
      return null;
    }
    GradientDrawable d = new GradientDrawable();
    d.setColor(color);
    d.setStroke(ToolDialogs.dp(this, 1), 0x80808080);
    d.setCornerRadius(ToolDialogs.dp(this, 4));
    return d;
  }

  private final class EntryAdapter extends BaseAdapter {
    @Override public int getCount() { return shown.size(); }
    @Override public Object getItem(int position) { return shown.get(position); }
    @Override public long getItemId(int position) { return position; }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
      LinearLayout row = (LinearLayout) convertView;
      int pad = ToolDialogs.dp(SystemResourcesActivity.this, 12);
      if (row == null) {
        row = new LinearLayout(SystemResourcesActivity.this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(pad, pad, pad, pad);
        row.setMinimumHeight(ToolDialogs.dp(SystemResourcesActivity.this, 48));
        ImageView icon = new ImageView(SystemResourcesActivity.this);
        int s = ToolDialogs.dp(SystemResourcesActivity.this, 36);
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(s, s);
        ip.setMarginEnd(pad);
        row.addView(icon, ip);
        TextView text = new TextView(SystemResourcesActivity.this);
        row.addView(text, new LinearLayout.LayoutParams(0, -2, 1));
        View swatch = new View(SystemResourcesActivity.this);
        LinearLayout.LayoutParams wp = new LinearLayout.LayoutParams(s, s);
        wp.setMarginStart(pad);
        row.addView(swatch, wp);
      }
      Entry e = shown.get(position);
      ImageView icon = (ImageView) row.getChildAt(0);
      TextView text = (TextView) row.getChildAt(1);
      View swatch = row.getChildAt(2);
      SpannableStringBuilder label = new SpannableStringBuilder((position + 1) + ". ");
      label.append(marked(e.name));
      if ("string".equals(type)) label.append('\n').append(marked(e.value == null ? "" : e.value));
      text.setText(label);
      text.setTextAppearance(android.R.style.TextAppearance_Medium);
      if ("textappearance".equals(type)) {
        try {
          text.setTextAppearance(e.id);
        } catch (RuntimeException ignored) {
          // مظهر غير صالح لهذا الجهاز.
        }
      }
      icon.setVisibility("drawable".equals(type) ? View.VISIBLE : View.GONE);
      if ("drawable".equals(type)) icon.setImageDrawable(drawable(e));
      swatch.setVisibility("color".equals(type) ? View.VISIBLE : View.GONE);
      if ("color".equals(type)) swatch.setBackground(colorSwatch(e));
      return row;
    }
  }

  private String javaReference(Entry e) {
    return "android.R." + ("theme".equals(type) || "textappearance".equals(type) ? "style" : type) + "." + e.name;
  }

  private String xmlReference(Entry e) {
    boolean style = "theme".equals(type) || "textappearance".equals(type);
    return "@android:" + (style ? "style" : type) + "/" + (style ? e.name.replace('_', '.') : e.name);
  }

  private void showDetail(final Entry e) {
    final String hex = "0x" + Integer.toHexString(e.id);
    StringBuilder message = new StringBuilder();
    message.append(ToolDialogs.uiFormat(this, "tools_res_name", e.name)).append('\n')
        .append(ToolDialogs.uiFormat(this, "tools_res_id", e.id)).append('\n')
        .append(ToolDialogs.uiFormat(this, "tools_res_hex", hex)).append('\n')
        .append(ToolDialogs.uiFormat(this, "tools_res_java", javaReference(e))).append('\n')
        .append(ToolDialogs.uiFormat(this, "tools_res_xml", xmlReference(e)));
    if (e.value != null) message.append("\n\n").append(e.value);
    if ("color".equals(type)) {
      try {
        message.append("\n\n").append(String.format("#%08X", getColor(e.id)));
      } catch (RuntimeException ignored) {
        // لون غير متاح.
      }
    }
    AlertDialog.Builder builder = new AlertDialog.Builder(this)
        .setTitle(ToolDialogs.ui(this, "tools_res_detail"))
        .setMessage(message.toString())
        .setNegativeButton(android.R.string.cancel, null)
        .setPositiveButton(ToolDialogs.ui(this, "command_copy"), null);
    if ("drawable".equals(type)) builder.setIcon(drawable(e));
    if ("color".equals(type)) builder.setIcon(sized(colorSwatch(e)));
    boolean previewable = "theme".equals(type) && !e.name.contains("NoDisplay") && !e.name.contains("Translucent");
    if (previewable) builder.setNeutralButton(ToolDialogs.ui(this, "tools_res_preview"), (d, w) ->
        startActivity(new Intent(this, SystemResourcesActivity.class)
            .putExtra(EXTRA_PREVIEW_THEME, e.id).putExtra(EXTRA_PREVIEW_NAME, e.name)));
    final AlertDialog dialog = builder.show();
    final Button copy = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
    copy.setOnClickListener(v -> {
      android.widget.PopupMenu menu = new android.widget.PopupMenu(this, copy);
      menu.getMenu().add(0, 1, 0, ToolDialogs.ui(this, "tools_res_copy_name"));
      menu.getMenu().add(0, 2, 1, ToolDialogs.ui(this, "tools_res_copy_id"));
      menu.getMenu().add(0, 3, 2, ToolDialogs.ui(this, "tools_res_copy_java"));
      menu.getMenu().add(0, 4, 3, ToolDialogs.ui(this, "tools_res_copy_xml"));
      menu.setOnMenuItemClickListener(item -> {
        String text;
        switch (item.getItemId()) {
          case 1: text = e.name; break;
          case 2: text = hex; break;
          case 3: text = javaReference(e); break;
          default: text = xmlReference(e); break;
        }
        ToolDialogs.copy(this, text);
        return true;
      });
      menu.show();
    });
  }

  private Drawable sized(Drawable d) {
    if (d instanceof GradientDrawable) {
      int s = ToolDialogs.dp(this, 24);
      ((GradientDrawable) d).setSize(s, s);
    }
    return d;
  }

  /** معاينة السمة: النشاط نفسه بالسمة المختارة (setTheme قبل onCreate). */
  private void showPreview(String name) {
    setTitle(name == null ? ToolDialogs.ui(this, "tools_res_preview") : name.replace('_', '.'));
    LinearLayout box = new LinearLayout(this);
    box.setOrientation(LinearLayout.VERTICAL);
    int pad = ToolDialogs.dp(this, 16);
    box.setPadding(pad, pad, pad, pad);
    EditText edit = new EditText(this);
    edit.setHint(ToolDialogs.ui(this, "tools_res_preview_text"));
    box.addView(edit, new LinearLayout.LayoutParams(-1, -2));
    Button button = new Button(this);
    button.setText("AlertDialog");
    button.setOnClickListener(v -> new AlertDialog.Builder(this)
        .setTitle("AlertDialog")
        .setMessage(name == null ? "" : name.replace('_', '.'))
        .setPositiveButton(android.R.string.ok, null)
        .setNegativeButton(android.R.string.cancel, null)
        .show());
    box.addView(button, new LinearLayout.LayoutParams(-2, -2));
    SeekBar seek = new SeekBar(this);
    seek.setProgress(40);
    box.addView(seek, new LinearLayout.LayoutParams(-1, -2));
    ScrollView scroll = new ScrollView(this);
    scroll.addView(box);
    setContentView(scroll);
    if (getWindow() != null && getWindow().getDecorView().getBackground() == null) {
      getWindow().getDecorView().setBackgroundColor(Color.GRAY);
    }
  }

  @Override
  public boolean onOptionsItemSelected(MenuItem item) {
    if (item.getItemId() == android.R.id.home) {
      finish();
      return true;
    }
    return super.onOptionsItemSelected(item);
  }
}
