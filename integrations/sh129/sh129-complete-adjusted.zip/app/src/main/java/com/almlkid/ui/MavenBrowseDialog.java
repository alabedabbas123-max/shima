package com.almlkid.ui;

import android.content.Context;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import almlk.MavenIndex;
import almlk.MavenStore;
import almlk.MavenVersionSource;
import almlk.MavenResolver;
import almlk.MavenDownloader;
import almlk.AppSettings;
import com.shima.demo.UiStrings;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * «تصفُّحُ المستودعاتِ»: بحثٌ حيٌّ في مخازنِ Maven المحلّيّةِ ثمَّ قائمةُ إصداراتٍ مقروءةٌ من
 * {@code maven-metadata.xml} — لا جدولَ أسماءَ مُسبَقَ الصنعِ (W22/ب1).
 *
 * <p><b>ما يُصلِحُهُ:</b> كانَ حوارُ «إضافةَ اعتمادٍ» يعرضُ قائمتَي AndroidX/AppCompat المولَّدتَينِ من
 * {@code androidx-migration.idx.gz}، فلا يرى المستخدمُ أداةً ليست فيهما ولا إصداراتِ ما يراهُ، ويكتبُ
 *رقمَ الإصدارِ على الثقةِ. هنا يُسألُ المخبأُ ثمَّ المستودعاتُ، وتُرتَّبُ الإصداراتُ بـ{@code MavenVersion}،
 * ويُعلَّمُ المثبَّتُ والأحدثُ المستقرُّ.
 *
 * <p><b>لا خيطَ واجهةِ يمسُّ قرصًا ولا شبكةً:</b> كلُّ {@code listFiles}/{@code fetch} داخل {@code
 * HandlerThread("maven-browse")}، والنتائجُ تُنشَرُ بـ{@code Handler(mainLooper)}؛ والكتابةُ في الحقلِ
 * تُجمَعُ ب{@value #SEARCH_DEBOUNCE_MS}ms، وكلُّ طلبٍ سابقٍ يُلغى بزيادةِ الجيلِ — فلا طابورَ طلباتٍ
 * ولا «بحثٌ» يستمرُّ بعدَ إغلاقِ الحوارِ. النصُّ النهائيُّ يُسلَّمُ إلى {@link Listener} ليمرَّ بمسارِ
 * الكتابةِ القائمِ ({@code GradleDependencyEditor})؛ هذا الحوارُ لا يكتبُ قرصًا قطُّ.
 */
public final class MavenBrowseDialog {

  /** يُستدعى على خيطِ الواجهةِ بإحداثياتٍ صالحةٍ {@code group:artifact:version}. */
  public interface Listener {
    void onCoordinate(String coordinate);
  }

  private static final long SEARCH_DEBOUNCE_MS = 350;
  private static final int MAX_ROWS = MavenIndex.DEFAULT_LIMIT;

  private final Context context;
  private final Listener listener;
  private final MavenStore store;
  private final File projectDir;
  private Boolean androidxFlag;
  private final List<MavenResolver.Repo> repos;
  private final Handler main = new Handler(Looper.getMainLooper());
  private final HandlerThread thread = new HandlerThread("maven-browse");
  private Handler worker;

  private final AtomicInteger generation = new AtomicInteger();
  private volatile boolean dismissed;
  private boolean forceRefresh;

  private android.app.AlertDialog dialog;
  private EditText search;
  private TextView status;
  private ListView list;
  private RowsAdapter adapter;

  /** صَفُّ واحدٌ: نصُّهُ كما يُعرَضُ، وما يُرجَعُ عندَ النقرِ. */
  private static final class Row {
    final String label;
    final String coordinate;
    final Runnable action;

    Row(String label, String coordinate, Runnable action) {
      this.label = label;
      this.coordinate = coordinate;
      this.action = action;
    }
  }

  private final List<Row> rows = new ArrayList<Row>();
  private MavenIndex.Hit browsing; // غيرُ فارغٍ عندَ عرضِ إصداراتِ أداةٍ
  private String query = "";

  private MavenBrowseDialog(Context context, File projectDir, Listener listener) {
    this.context = context;
    this.projectDir = projectDir;
    this.listener = listener;
    this.store = AppSettings.mavenStore(context);
    this.repos = repositories(context);
  }

  /** المستودعاتُ كما يراهُما المحلِّلُ: إضافاتُ المستخدمِ أوَّلًا (بسياسةِ الإنقاذِ نفسِها)، ثمَّ المضمَنةُ احتياطًا. */
  private static List<MavenResolver.Repo> repositories(Context context) {
    List<MavenResolver.Repo> out = new ArrayList<MavenResolver.Repo>();
    for (String token : AppSettings.extraRepositories(context)) {
      String url = almlk.RepositoryPolicy.rescue(token);
      if (url != null) out.add(new MavenResolver.Repo("user", url, null, false));
    }
    out.add(new MavenResolver.Repo("google", almlk.GradleBuildModel.GOOGLE_URL, null, true));
    out.add(new MavenResolver.Repo("mavenCentral", almlk.GradleBuildModel.CENTRAL_URL, null, true));
    out.add(new MavenResolver.Repo("jitpack", almlk.GradleBuildModel.JITPACK_URL, null, true));
    return out;
  }

  public static void show(Context context, Listener listener) {
    show(context, null, listener);
  }

  /** {@code projectDir} مُخيَّرٌ: إن أُعطيَ، عُرضَ بديلُ AndroidX للأدواتِ القديمةِ فيهِ. */
  public static void show(Context context, File projectDir, Listener listener) {
    new MavenBrowseDialog(context, projectDir, listener).showBrowser();
  }

  // ═══════════════ الواجهةُ ═══════════════

  private void showBrowser() {
    thread.start();
    worker = new Handler(thread.getLooper());

    LinearLayout root = new LinearLayout(context);
    root.setOrientation(LinearLayout.VERTICAL);
    search = new EditText(context);
    search.setSingleLine(true);
    search.setHint(ui("ui_maven_browse_search_hint"));
    search.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
    LinearLayout.LayoutParams searchParams = new LinearLayout.LayoutParams(-1, -2);
    searchParams.setMargins(dp(16), dp(8), dp(16), 0);
    root.addView(search, searchParams);

    status = new TextView(context);
    status.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
    status.setPadding(dp(18), dp(4), dp(18), dp(2));
    status.setText(ui("ui_maven_browse_status_searching"));
    root.addView(status, new LinearLayout.LayoutParams(-1, -2));

    list = new ListView(context);
    list.setFastScrollEnabled(true);
    adapter = new RowsAdapter();
    list.setAdapter(adapter);
    list.setOnItemClickListener(
        (parent, view, position, id) -> {
          Row row = rows.get(position);
          if (row.action != null) {
            row.action.run();
            return;
          }
          pick(row.coordinate);
        });
    root.addView(list, new LinearLayout.LayoutParams(-1, 0, 1));

    search.addTextChangedListener(
        new TextWatcher() {
          public void beforeTextChanged(CharSequence s, int a, int b, int c) {}

          public void onTextChanged(CharSequence s, int a, int b, int c) {}

          public void afterTextChanged(Editable s) {
            query = s.toString().trim();
            browsing = null;
            status.setText(ui("ui_maven_browse_status_searching"));
            main.removeCallbacks(searchTask);
            main.postDelayed(searchTask, SEARCH_DEBOUNCE_MS);
          }
        });

    dialog =
        new android.app.AlertDialog.Builder(context)
            .setTitle(ui("ui_maven_browse_title"))
            .setView(root)
            .setNegativeButton(ui("dialog_cancel"), null)
            .setNeutralButton(ui("ui_maven_browse_refresh"), null)
            .create();
    dialog.setOnDismissListener(ignored -> stop());
    dialog.show();
    dialog
        .getButton(android.app.AlertDialog.BUTTON_NEUTRAL)
        .setOnClickListener(
            v -> {
              forceRefresh = true;
              if (browsing != null) loadVersions(browsing.group, browsing.artifact, browsing);
              else main.post(searchTask);
            });
    main.post(searchTask);
  }

  private final Runnable searchTask = this::runSearch;

  private void stop() {
    dismissed = true;
    generation.incrementAndGet();
    if (worker != null) worker.removeCallbacksAndMessages(null);
    thread.quitSafely();
  }

  private void pick(String coordinate) {
    if (dialog != null) dialog.dismiss();
    if (listener != null && coordinate != null && !coordinate.isEmpty()) listener.onCoordinate(coordinate);
  }

  // ═══════════════ العملُ الخلفيُّ ═══════════════

  private void runSearch() {
    if (dismissed) return;
    final int gen = generation.incrementAndGet();
    final String needle = query;
    worker.post(
        () -> {
          final List<MavenIndex.Hit> found = MavenIndex.search(needle, sources(), MAX_ROWS);
          final String typed = normalizeQuery(needle);
          main.post(
              () -> {
                if (dismissed || gen != generation.get()) return;
                rows.clear();
                for (final MavenIndex.Hit hit : found) {
                  rows.add(new Row(label(hit), hit.coordinate(), () -> loadVersions(hit.group, hit.artifact, hit)));
                }
                if (rows.isEmpty() && typed.indexOf(':') > 0) {
                  // «مجموعةٌ:أداةٌ» مكتوبةٌ بيدِهِ: لا حاجةَ إلى أن يكونَ في المخزنِ — اسألِ المستودعاتِ.
                  String[] parts = typed.split(":", 3);
                  rows.add(
                      new Row(
                          UiStrings.format(context, "ui_maven_browse_query_remote", parts[0] + ":" + parts[1]),
                          null,
                          () -> loadVersions(parts[0], parts[1], null)));
                }
                adapter.notifyDataSetChanged();
                status.setText(
                    found.isEmpty()
                        ? ui("ui_maven_browse_none")
                        : UiStrings.format(context, "ui_maven_browse_found", found.size()));
                if (dialog != null) dialog.setTitle(ui("ui_maven_browse_title"));
              });
        });
  }

  /** الأدواتُ من المخزنِ + مستودعاتِ المستخدمِ المحليّةِ + ‏{@code ~/.m2/repository} إن وُجِدَتْ. */
  private List<MavenIndex.Source> sources() {
    List<MavenIndex.Source> out = new ArrayList<>(MavenIndex.sources(store));
    File m2 = new File(android.os.Environment.getExternalStorageDirectory(), ".m2/repository");
    if (m2.isDirectory()) out.add(new MavenIndex.Source(m2, "local:m2"));
    return out;
  }

  private void loadVersions(String group, String artifact, MavenIndex.Hit hit) {
    if (dismissed) return;
    final int gen = generation.incrementAndGet();
    final String coordinate = group + ":" + artifact;
    status.setText(ui("ui_maven_browse_status_loading"));
    final boolean refresh = forceRefresh;
    worker.post(
        () -> {
          File artifactDir = new File(store.downloadDir(), group.replace('.', '/') + "/" + artifact);
          List<File> localRoots = store.localRepositories();
          MavenVersionSource.Result result =
              MavenVersionSource.load(
                  group, artifact, artifactDir, localRoots, repos, new MavenDownloader(), refresh,
                  () -> dismissed);
          // مشروعٌ يعملُ بـAndroidX لا يبنى مع مكتباتِ الدعمِ القديمةِ؛ فيُعرَضُ بديلُها من
          // الجدولِ المحمَّلِ أولَ سطرٍ — والنقرُ عليهِ يُدرِجُ الإحداثياتِ البديلةَ ذاتَها.
          final boolean useAndroidX = androidxFlag != null ? androidxFlag : (androidxFlag = almlk.AndroidXMigration.usesAndroidX(projectDir));
          almlk.AndroidXMigration.Artifact alternative =
              useAndroidX ? almlk.AndroidXMigration.oldToNew(coordinate) : null;
          final String substitute =
              alternative == null
                  ? null
                  : almlk.AndroidXMigration.coordinateFor(
                      alternative.newName, true,
                      almlk.MavenStore.installedSnapshot().get(alternative.newName));
          List<String> merged = new ArrayList<>();
          if (hit != null) merged.addAll(hit.versions);
          for (String version : result.versions) if (!merged.contains(version)) merged.add(version);
          // الأحدثُ أولًا — هو ما يبحثُ عنهُ المستخدمُ لا أوّلُ ما وُجِدَ.
          java.util.Collections.sort(
              merged,
              new java.util.Comparator<String>() {
                @Override
                public int compare(String x, String y) {
                  return almlk.MavenVersion.compare(y, x);
                }
              });
          final List<String> ordered = merged;
          final boolean fromCache = result.fromCache;
          final boolean asked = result.asked;
          final List<String> installed = new ArrayList<>();
          for (String version : ordered) {
            if (store.isInstalled(
                new MavenStore.Coordinate(group, artifact, version, null, null))) {
              installed.add(version);
            }
          }
          main.post(
              () -> {
                if (dismissed || gen != generation.get()) return;
                browsing = hit;
                rows.clear();
                rows.add(new Row(ui("ui_maven_browse_back"), null, this::showArtifactsAgain));
                if (substitute != null) {
                  rows.add(
                      new Row(
                          UiStrings.format(context, "ui_maven_browse_androidx_alt", substitute), substitute, null));
                }
                for (String version : ordered) {
                  StringBuilder label = new StringBuilder(version);
                  if (version.equals(result.newestStable)) label.append("  · ").append(ui("ui_maven_browse_stable"));
                  if (installed.contains(version)) label.append("  · ").append(ui("ui_maven_browse_installed"));
                  rows.add(new Row(label.toString(), coordinate + ":" + version, null));
                }
                adapter.notifyDataSetChanged();
                status.setText(
                    ordered.isEmpty()
                        ? ui("ui_maven_browse_none")
                        : ui(fromCache && !asked ? "ui_maven_browse_from_cache" : "ui_maven_browse_online"));
                if (dialog != null) {
                  dialog.setTitle(UiStrings.format(context, "ui_maven_browse_status_versions", coordinate));
                }
              });
        });
  }

  private void showArtifactsAgain() {
    browsing = null;
    main.post(searchTask);
  }

  private String label(MavenIndex.Hit hit) {
    StringBuilder out = new StringBuilder(hit.coordinate());
    if (!hit.versions.isEmpty()) {
      out.append("  ·  ").append(hit.versions.get(hit.versions.size() - 1));
      if (hit.versions.size() > 1) out.append(" (").append(hit.versions.size()).append(')');
    }
    if (!"store".equals(hit.origin)) out.append("  ·  ").append(hit.origin);
    return out.toString();
  }

  private static String normalizeQuery(String value) {
    return value == null ? "" : value.trim().replace('/', '.').toLowerCase(Locale.US);
  }

  private int dp(float value) {
    return Math.round(value * context.getResources().getDisplayMetrics().density);
  }

  private String ui(String key) {
    return UiStrings.get(context, key);
  }

  /** سطرٌ واحدٌ لكلِّ نتيجةٍ، وبلا CheckBox: النقرُ هنا يعني «هذهِ الأداةُ» لا «حدِّدْ عدةَ أشياءَ». */
  private final class RowsAdapter extends BaseAdapter {
    public int getCount() {
      return rows.size();
    }

    public Object getItem(int position) {
      return rows.get(position);
    }

    public long getItemId(int position) {
      return position;
    }

    public View getView(int position, View convertView, ViewGroup parent) {
      TextView text = convertView instanceof TextView ? (TextView) convertView : new TextView(context);
      text.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
      text.setPadding(dp(18), dp(10), dp(18), dp(10));
      text.setGravity(Gravity.CENTER_VERTICAL);
      text.setText(rows.get(position).label);
      return text;
    }
  }
}
