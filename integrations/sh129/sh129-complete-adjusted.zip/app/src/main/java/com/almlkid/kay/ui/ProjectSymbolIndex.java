package com.almlkid.kay.ui;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Thread-safe lightweight Java symbol index used for cross-file diagnostics and quick fixes. */
public final class ProjectSymbolIndex {
  private static final Map<String, Set<String>> METHODS = new HashMap<>();
  private static final Map<String, LinkedHashMap<String, String>> METHOD_RETURNS = new HashMap<>();
  private static final Map<String, LinkedHashMap<String, String>> METHOD_PARAMETERS = new HashMap<>();
  private static final Map<String, LinkedHashMap<String, String>> CLASS_FIELDS = new HashMap<>();
  private static final Map<String, String> PARENTS = new HashMap<>();
  private static final Map<String, String> CLASS_FILES = new HashMap<>();
  private static final Map<String, String> CLASS_REFERENCES = new HashMap<>();
  private static final Map<String, String> CLASS_PACKAGES = new HashMap<>();
  private static final Map<String, Integer> CLASS_OFFSETS = new HashMap<>();
  /** Stage 4: direct supertypes as written (extends + implements, implicit Object/Enum). */
  private static final Map<String, List<String>> SUPERTYPES = new HashMap<>();
  /** Stage 4: imports of the file declaring each class (a.b.C or a.b.*), shared per file. */
  private static final Map<String, List<String>> CLASS_IMPORTS = new HashMap<>();
  /** Stage 4: every name declared in the class file (fields, incl. multi/annotated declarators). */
  private static final Map<String, Set<String>> LOOSE_NAMES = new HashMap<>();
  private static final Set<String> TYPES_WITH_UNCERTAIN_NESTING = new HashSet<>();
  private static final Map<String, LinkedHashMap<String, Integer>> METHOD_OFFSETS = new HashMap<>();
  private static final Map<String, LinkedHashMap<String, Integer>> FIELD_OFFSETS = new HashMap<>();
  private static final CompletionTrie<String> CLASS_TRIE = new CompletionTrie<>();
  /**
   * W21′1 — bumped once for every changed declaration contract. The saved-findings snapshot is keyed
   * by it: after a structural change the pre-scan rows are dropped instead of being shown as if they
   * were fresh, and the next scan rewrites them under the new epoch. No per-file dependency graph is
   * kept in memory for that, because the whole point is to answer while typing.
   */
  private static long structureEpoch;
  /**
   * W21′1: file → member names whose declaration changed there since the dependents were last
   * swept. Keyed by file because the sweep must first make the model truthful (live buffer text)
   * before it asks the other files — that is what the reference's engine does with a modification.
   */
  private static final LinkedHashMap<String, ArrayList<String>> PENDING_DECLARATIONS =
      new LinkedHashMap<>();
  private static final int MAX_PENDING_FILES = 16;
  private static final int MAX_PENDING_NAMES = 128;

  /**
   * W21′2 — ملفٌّ في المشروعِ يُعيدُ تعريفَ صنفٍ تملكُهُ المنصّةُ أو مكتبةٌ (نسخةٌ ناقصةٌ
   * من {@code android.content.Context} مثلًا): لا يدخلُ الفهرسَ، ويُبلَّغُ عنهُ في اللوحةِ حتى
   * لا يُحسبَ الرفضُ عافيةً. القائمةُ محدودةٌ والأقدمُ يُسقَطُ مع عدَّادٍ بما زادَ، فملفُّ ظلٍّ
   * بعشراتِ الأصنافِ لا يملأُ اللوحةَ.
   */
  private static final LinkedHashMap<String, String> SHADOWED = new LinkedHashMap<>();
  private static final int MAX_SHADOWED = 24;
  private static int shadowedOverflow;
  private static final Pattern CLASS_PATTERN =
      Pattern.compile("\\b(?:class|interface|enum|record)\\s+([A-Za-z_$][A-Za-z0-9_$]*)");
  private static final Pattern METHOD_PATTERN =
      Pattern.compile(
          "(?m)(?:^|[;{}])\\s*(?:(?:public|protected|private|static|final|abstract|synchronized|native|default)\\s+)*(?:<[^>{}]+>\\s*)?([A-Za-z_$][A-Za-z0-9_$<>?,. \\t\\[\\]]*)\\s+([A-Za-z_$][A-Za-z0-9_$]*)\\s*\\(");
  private static final Pattern VARIABLE_PATTERN =
      Pattern.compile(
          "\\b([A-Z][A-Za-z0-9_$.]*(?:\\s*<[^;=(){}]+>)?(?:\\[\\])*)\\s+([a-zA-Z_$][A-Za-z0-9_$]*)\\b");
  private static final Pattern DIAGNOSTIC_VARIABLE_PATTERN =
      Pattern.compile(
          "(?m)(?:^|[;{}(,])\\s*(?:(?:public|protected|private|static|final|volatile|transient)\\s+)*"
              + "(?:@[A-Za-z_$][A-Za-z0-9_$.]*(?:\\([^\\n)]*\\))?\\s+)*"
              + "([A-Z][A-Za-z0-9_$.]*(?:\\s*<[^;=(){}]+?>)?(?:\\s*\\[\\])*)\\s+"
              + "([A-Za-z_$][A-Za-z0-9_$]*)\\s*(?==|;|,|\\)|\\[|:)");
  private static final Pattern FIELD_PATTERN =
      Pattern.compile(
          "(?m)(?:^|[;{}])\\s*(?:(?:public|protected|private|static|final|volatile|transient)\\s+)*"
              + "(?!(?:class|interface|enum|record)\\b)"
              + "((?:byte|short|int|long|float|double|boolean|char|String)|[A-Za-z_$][A-Za-z0-9_$.]*"
              + "(?:\\s*<[^;=(){}]+>)?(?:\\[\\])*)\\s+"
              + "([A-Za-z_$][A-Za-z0-9_$]*)\\s*(?:=|;|,)");
  private static final Pattern CALL_PATTERN =
      Pattern.compile("\\b([A-Za-z_$][A-Za-z0-9_$]*)\\s*\\.\\s*([A-Za-z_$][A-Za-z0-9_$]*)\\s*\\(");
  private static final Pattern CREATION_PATTERN =
      Pattern.compile("\\b([A-Za-z_$][A-Za-z0-9_$]*)\\s*=\\s*new\\s+([A-Z][A-Za-z0-9_$.]*)\\s*[<(]");
  private static final Pattern CAST_PATTERN =
      Pattern.compile("\\b([A-Za-z_$][A-Za-z0-9_$]*)\\s*=\\s*\\(\\s*([A-Z][A-Za-z0-9_$.]*)\\s*\\)");
  private static final Pattern IMPORT_PATTERN =
      Pattern.compile("(?m)^\\s*import\\s+(?!static\\s+)([A-Za-z_$][A-Za-z0-9_$.]*)(\\*)?\\s*;");
  // Memory guards: indexing is a best-effort background feature, so huge or generated files
  // must never be able to exhaust the heap while the symbol index is being built.
  private static final int MAX_INDEXED_CHARS = 600_000;
  private static final int MAX_MEMBERS_PER_FILE = 4_000;
  private static final int MAX_PARAMETERS_CHARS = 300;
  private static final int MAX_PAREN_SCAN_CHARS = 8_000;
  private static List<String> classNamesCache = Collections.emptyList();
  private static boolean classNamesDirty = true;

  static {
    seedBuiltIns();
  }

  private ProjectSymbolIndex() {}

  public static synchronized void clear() {
    PARSED.clear();
    almlk.JavaProjectModel.clear();
    METHODS.clear();
    METHOD_RETURNS.clear();
    METHOD_PARAMETERS.clear();
    CLASS_FIELDS.clear();
    PARENTS.clear();
    CLASS_FILES.clear();
    CLASS_REFERENCES.clear();
    CLASS_PACKAGES.clear();
    CLASS_OFFSETS.clear();
    SUPERTYPES.clear();
    CLASS_IMPORTS.clear();
    LOOSE_NAMES.clear();
    TYPES_WITH_UNCERTAIN_NESTING.clear();
    METHOD_OFFSETS.clear();
    FIELD_OFFSETS.clear();
    CLASS_TRIE.clear();
    PENDING_DECLARATIONS.clear();
    SHADOWED.clear();
    shadowedOverflow = 0;
    structureEpoch = 0L;
    classNamesCache = Collections.emptyList();
    classNamesDirty = true;
    seedBuiltIns();
  }

  private static synchronized void seedBuiltIns() {
    addBuiltIn("View", new String[][] {{"setVisibility", "void"}, {"getVisibility", "int"}, {"setOnClickListener", "void"}, {"findViewById", "View"}, {"requestLayout", "void"}, {"invalidate", "void"}, {"getContext", "Context"}});
    addBuiltIn("TextView", new String[][] {{"setText", "void"}, {"getText", "CharSequence"}, {"setTextColor", "void"}, {"setTextSize", "void"}, {"setGravity", "void"}, {"append", "void"}});
    addBuiltIn("EditText", new String[][] {{"setText", "void"}, {"getText", "Editable"}, {"setSelection", "void"}, {"setError", "void"}, {"requestFocus", "boolean"}});
    addBuiltIn("Activity", new String[][] {{"setContentView", "void"}, {"findViewById", "View"}, {"getIntent", "Intent"}, {"startActivity", "void"}, {"finish", "void"}, {"getResources", "Resources"}});
    addBuiltIn("Context", new String[][] {{"getResources", "Resources"}, {"getString", "String"}, {"getSystemService", "Object"}, {"getSharedPreferences", "SharedPreferences"}, {"startActivity", "void"}});
    addBuiltIn("String", new String[][] {{"length", "int"}, {"substring", "String"}, {"toLowerCase", "String"}, {"contains", "boolean"}, {"startsWith", "boolean"}, {"endsWith", "boolean"}, {"trim", "String"}, {"equals", "boolean"}});
    addBuiltIn("List", new String[][] {{"add", "boolean"}, {"get", "Object"}, {"size", "int"}, {"isEmpty", "boolean"}, {"clear", "void"}, {"remove", "Object"}});
    addBuiltIn("Map", new String[][] {{"put", "Object"}, {"get", "Object"}, {"containsKey", "boolean"}, {"keySet", "Set"}, {"values", "Collection"}, {"clear", "void"}});
    addBuiltIn("Intent", new String[][] {{"putExtra", "Intent"}, {"getStringExtra", "String"}, {"getData", "Uri"}, {"addFlags", "Intent"}});
    addBuiltIn("SharedPreferences", new String[][] {{"getString", "String"}, {"getBoolean", "boolean"}, {"getInt", "int"}, {"edit", "Editor"}, {"contains", "boolean"}});
    addBuiltIn("Bundle", new String[][] {{"putString", "void"}, {"getString", "String"}, {"putInt", "void"}, {"getInt", "int"}, {"containsKey", "boolean"}});
    inheritBuiltIn("TextView", "View");
    inheritBuiltIn("EditText", "TextView");
  }

  private static void inheritBuiltIn(String child, String parent) {
    LinkedHashMap<String, String> childMethods = METHOD_RETURNS.get(child);
    LinkedHashMap<String, String> parentMethods = METHOD_RETURNS.get(parent);
    if (childMethods != null && parentMethods != null) {
      for (Map.Entry<String, String> entry : parentMethods.entrySet())
        if (!childMethods.containsKey(entry.getKey())) childMethods.put(entry.getKey(), entry.getValue());
      METHODS.put(child, new HashSet<>(childMethods.keySet()));
      LinkedHashMap<String, String> childParameters = METHOD_PARAMETERS.get(child);
      LinkedHashMap<String, String> parentParameters = METHOD_PARAMETERS.get(parent);
      if (childParameters != null && parentParameters != null)
        for (Map.Entry<String, String> entry : parentParameters.entrySet())
          if (!childParameters.containsKey(entry.getKey()))
            childParameters.put(entry.getKey(), entry.getValue());
      PARENTS.put(child, parent);
    }
  }

  private static void addBuiltIn(String type, String[][] declarations) {
    LinkedHashMap<String, String> methods = new LinkedHashMap<>();
    for (String[] declaration : declarations) methods.put(declaration[0], declaration[1]);
    methods.put("toString", "String"); methods.put("hashCode", "int"); methods.put("equals", "boolean");
    METHOD_RETURNS.put(type, methods);
    LinkedHashMap<String, String> parameters = new LinkedHashMap<>();
    for (String method : methods.keySet()) parameters.put(method, "");
    METHOD_PARAMETERS.put(type, parameters);
    METHODS.put(type, new HashSet<>(methods.keySet()));
    CLASS_FIELDS.put(type, new LinkedHashMap<>());
    CLASS_TRIE.put(type, type);
    classNamesDirty = true;
  }

  public static synchronized void registerSource(String fileName, String source) {
    registerSource(fileName, fileName, source);
  }

  /** Registers a source file while retaining its stable path/SAF URI for exact cross-file opens. */
  public static synchronized void registerSource(
      String fileName, String reference, String source) {
    // R6: the textual parse depends on the text alone, so it is kept per file and content; a
    // re-registration of unchanged text (the project scan re-registers every file, a save only
    // changes one) just re-applies it — same index, same order, without the regex passes.
    String memoKey = (reference != null ? reference : "") + "|" + (fileName != null ? fileName : "");
    ParsedFile parsed = PARSED.get(memoKey);
    if (parsed == null || !parsed.sameText(source)) {
      parsed = parse(fileName, source);
      if (source != null) PARSED.put(memoKey, parsed);
      else PARSED.remove(memoKey);
    }
    // W21′2: الحُكمُ على ملفِّ الظلِّ قبلَ أن يلمسَ أيَّ نموذجٍ — وإلا بقيَ نصُّهُ في
    // JavaProjectModel فيُحسبُ {@code android.content} حزمةً للمشروعِ فتُقلَبُ أحكامُ التفضيلِ.
    // الرفضُ للفهرسِ وحدَهُ: الملفُّ يبقى في المتصفِّحِ والبحثِ والمحرِّرِ، يُقرأُ ويُعدَّلُ، لكنَّهُ
    // ليس تعريفَ ذلكَ الصنفِ — أصنافُ المنصّةِ والمكتبةِ أصدقُ من أسطُرٍ معدودةٍ نُسِخَت عنها.
    if (source != null && shadowsPlatform(parsed)) {
      noteShadowed(fileName, reference, parsed);
      return;
    }
    forgetShadowed(fileName, reference);
    almlk.JavaProjectModel.register(reference != null ? reference : fileName, source);
    apply(parsed, fileName, reference);
  }

  /** A file whose declared types all sit in a platform/library package is a shadow, not a source. */
  private static boolean shadowsPlatform(ParsedFile p) {
    return p != null
        && !p.classNames.isEmpty()
        && almlk.ProjectSourceRoots.platformOrLibraryPackage(p.sourcePackage);
  }

  private static void noteShadowed(String fileName, String reference, ParsedFile p) {
    String key = reference != null && !reference.isEmpty() ? reference : fileName;
    if (key == null || key.isEmpty()) return;
    StringBuilder names = new StringBuilder();
    for (int i = 0; i < p.classNames.size() && i < 3; i++) {
      if (names.length() > 0) names.append(", ");
      if (!p.sourcePackage.isEmpty()) names.append(p.sourcePackage).append('.');
      names.append(p.classNames.get(i));
    }
    if (p.classNames.size() > 3) names.append(" …");
    if (!SHADOWED.containsKey(key) && SHADOWED.size() >= MAX_SHADOWED) {
      Iterator<String> oldest = SHADOWED.keySet().iterator();
      if (oldest.hasNext()) {
        oldest.next();
        oldest.remove();
      }
      shadowedOverflow++;
    }
    SHADOWED.put(key, names.toString());
  }

  /** A file that no longer shadows the platform drops its notice (the next scan is authoritative). */
  private static void forgetShadowed(String fileName, String reference) {
    if (!SHADOWED.isEmpty()) SHADOWED.remove(reference != null && !reference.isEmpty() ? reference : fileName);
  }

  /** The refused shadows of this index: file reference → the types it tried to re-declare. */
  public static synchronized ArrayList<Map.Entry<String, String>> shadowedDefinitions() {
    return new ArrayList<Map.Entry<String, String>>(SHADOWED.entrySet());
  }

  /** How many shadows were refused in all — the list itself is capped on purpose. */
  public static synchronized int shadowedCount() {
    return SHADOWED.size() + shadowedOverflow;
  }

  /** The index rows one source file yields; pure function of its text. */
  private static final class ParsedFile {
    int length = -1, hash;
    String sourcePackage = "";
    final ArrayList<String> classNames = new ArrayList<>();
    final LinkedHashMap<String, Integer> classOffsets = new LinkedHashMap<>();
    /** Class → declared inside braces, in match order (the last occurrence wins, as before). */
    final ArrayList<Object[]> nesting = new ArrayList<>();
    final HashMap<String, String> parents = new HashMap<>();
    final HashMap<String, List<String>> supertypes = new HashMap<>();
    HashSet<String> methods;
    LinkedHashMap<String, String> returns, parameters, fields;
    LinkedHashMap<String, Integer> methodOffsets, fieldOffsets;
    Set<String> looseNames;
    List<String> imports;

    boolean sameText(String source) {
      return source != null && length == source.length() && hash == source.hashCode();
    }
  }

  private static final HashMap<String, ParsedFile> PARSED = new HashMap<>();

  private static ParsedFile parse(String fileName, String source) {
    ParsedFile out = new ParsedFile();
    if (source != null) {
      out.length = source.length();
      out.hash = source.hashCode();
    }
    String code = mask(source);
    if (code.length() > MAX_INDEXED_CHARS) code = code.substring(0, MAX_INDEXED_CHARS);
    out.sourcePackage = packageName(code);
    Matcher classes = CLASS_PATTERN.matcher(code);
    ArrayList<String> classNames = out.classNames;
    LinkedHashMap<String, Integer> classOffsets = out.classOffsets;
    // brace depth accumulated along the file (matches come in order) instead of recounted from
    // the start for every class — the same result in one pass.
    int depthAt = 0, depth = 0;
    while (classes.find()) {
      String className = classes.group(1);
      classNames.add(className);
      classOffsets.put(className, classes.start(1));
      for (int limit = Math.min(classes.start(), code.length()); depthAt < limit; depthAt++) {
        char c = code.charAt(depthAt);
        if (c == '{') depth++;
        else if (c == '}' && depth > 0) depth--;
      }
      out.nesting.add(new Object[] {className, depth > 0});
    }
    // every "class X … extends Y" of the file in one scan (first occurrence per class)
    Matcher parents = PARENT_PATTERN.matcher(code);
    while (parents.find()) out.parents.putIfAbsent(parents.group(1), simpleType(parents.group(2)));
    if (classNames.isEmpty() && fileName != null && fileName.endsWith(".java")) {
      String inferred = fileName.substring(0, fileName.length() - 5);
      classNames.add(inferred);
      classOffsets.put(inferred, 0);
    }
    HashSet<String> methods = new HashSet<>();
    LinkedHashMap<String, String> returns = new LinkedHashMap<>();
    LinkedHashMap<String, String> parameters = new LinkedHashMap<>();
    LinkedHashMap<String, Integer> methodOffsets = new LinkedHashMap<>();
    Matcher declarations = METHOD_PATTERN.matcher(code);
    while (declarations.find()) {
      if (methods.size() >= MAX_MEMBERS_PER_FILE) break;
      String returnType = declarations.group(1).trim().replaceAll("\\s+", " ");
      String methodName = declarations.group(2);
      methods.add(methodName);
      returns.put(methodName, returnType);
      methodOffsets.put(methodName, declarations.start(2));
      int open = declarations.end() - 1;
      int close = matchingParenthesis(code, open, MAX_PAREN_SCAN_CHARS);
      String args =
          close > open
              ? code.substring(open + 1, Math.min(close, open + 1 + MAX_PARAMETERS_CHARS))
                  .trim()
                  .replaceAll("\\s+", " ")
              : "";
      parameters.put(methodName, args);
    }
    returns.put("toString", "String");
    returns.put("hashCode", "int");
    returns.put("equals", "boolean");
    returns.put("clone", "Object");
    for (String method : returns.keySet())
      if (!parameters.containsKey(method)) parameters.put(method, "");
    methods.addAll(returns.keySet());
    LinkedHashMap<String, String> fields = new LinkedHashMap<>();
    LinkedHashMap<String, Integer> fieldOffsets = new LinkedHashMap<>();
    // Only declarations that begin after a class/member boundary are fields. The broader
    // VARIABLE_PATTERN is intentionally not used here because it would mistake method parameters
    // (for example String name) for fields.
    Matcher declaredFields = FIELD_PATTERN.matcher(code);
    while (declaredFields.find()) {
      if (fields.size() >= MAX_MEMBERS_PER_FILE) break;
      putFieldType(fields, declaredFields.group(2), simpleType(declaredFields.group(1)));
      fieldOffsets.putIfAbsent(declaredFields.group(2), declaredFields.start(2));
    }
    methods.addAll(classNames);
    // Loose declarations (annotated/same-line/multi-declarator members the strict patterns skip)
    // only ever widen "member exists": they can hide an error, never invent one.
    methods.addAll(declaredMethodNames(code));
    for (String className : classNames) {
      List<String> supertypes = supertypesOf(code, className);
      out.supertypes.put(className, supertypes);
      if (supertypes != null && supertypes.contains("java.lang.Enum")) {
        methods.add("values");
        methods.add("valueOf");
      }
    }
    out.methods = methods;
    out.returns = returns;
    out.parameters = parameters;
    out.methodOffsets = methodOffsets;
    out.fields = fields;
    out.fieldOffsets = fieldOffsets;
    out.looseNames = declaredNames(code);
    out.imports = importsOf(code);
    return out;
  }

  /**
   * Writes one file's rows into the index. All classes declared in one file share the same parsed
   * member data: the index is read-only after registration, so a single shared copy per structure
   * (instead of one copy per class) keeps large files from multiplying the heap footprint.
   */
  private static void apply(ParsedFile p, String fileName, String reference) {
    for (Object[] n : p.nesting) {
      if ((Boolean) n[1]) TYPES_WITH_UNCERTAIN_NESTING.add((String) n[0]);
      else TYPES_WITH_UNCERTAIN_NESTING.remove((String) n[0]);
    }
    for (String className : p.classNames) {
      Set<String> oldMethods = METHODS.get(className);
      LinkedHashMap<String, String> oldFields = CLASS_FIELDS.get(className);
      String oldParent = PARENTS.get(className);
      METHODS.put(className, p.methods);
      METHOD_RETURNS.put(className, p.returns);
      METHOD_PARAMETERS.put(className, p.parameters);
      CLASS_FIELDS.put(className, p.fields);
      METHOD_OFFSETS.put(className, p.methodOffsets);
      FIELD_OFFSETS.put(className, p.fieldOffsets);
      if (fileName != null) CLASS_FILES.put(className, fileName);
      if (reference != null) CLASS_REFERENCES.put(className, reference);
      CLASS_PACKAGES.put(className, p.sourcePackage);
      CLASS_OFFSETS.put(className, p.classOffsets.getOrDefault(className, 0));
      LOOSE_NAMES.put(className, p.looseNames);
      CLASS_IMPORTS.put(className, p.imports);
      List<String> supertypes = p.supertypes.get(className);
      if (supertypes == null) SUPERTYPES.remove(className);
      else SUPERTYPES.put(className, supertypes);
      String parent = p.parents.get(className);
      if (parent != null) PARENTS.put(className, parent);
      CLASS_TRIE.put(className, className);
      recordMemberDelta(
          className,
          fileName != null && !fileName.isEmpty()
              ? fileName
              : (reference != null && !reference.isEmpty()
                     ? reference.substring(reference.lastIndexOf('/') + 1)
                     : null),
          oldMethods,
          oldFields,
          p.methods,
          p.fields);
    }
    if (!p.classNames.isEmpty()) classNamesDirty = true;
  }

  /**
   * W21′1 — a member added or removed in a type is a change to every file that calls it. The changed
   * names go to the burst queue and the project's structural epoch moves, so the saved-findings
   * snapshot is dropped instead of being shown as if it were still true. First registration of a
   * type is not a change — a project-wide scan registers every file and must not flag the whole
   * project because of it.
   */
  private static void recordMemberDelta(
      String className,
      String fileKey,
      Set<String> oldMethods,
      Map<String, String> oldFields,
      Set<String> newMethods,
      Map<String, String> newFields) {
    if (oldMethods == null && oldFields == null) return;
    ArrayList<String> changed = new ArrayList<>(4);
    if (newMethods != null)
      for (String name : newMethods)
        if (oldMethods == null || !oldMethods.contains(name)) changed.add(name);
    if (oldMethods != null)
      for (String name : oldMethods)
        if (newMethods == null || !newMethods.contains(name)) changed.add(name);
    if (newFields != null)
      for (String name : newFields.keySet())
        if (oldFields == null || !oldFields.containsKey(name)) changed.add(name);
    if (oldFields != null)
      for (String name : oldFields.keySet())
        if (newFields == null || !newFields.containsKey(name)) changed.add(name);
    if (changed.isEmpty()) return;
    structureEpoch++;
    if (fileKey != null && !fileKey.isEmpty()) addPendingNames(fileKey, changed);
  }

  /** W21′1 — the burst queue: capped both ways; an overflow only ever widens the next sweep. */
  private static void addPendingNames(String fileKey, ArrayList<String> names) {
    ArrayList<String> held = PENDING_DECLARATIONS.get(fileKey);
    if (held == null) {
      if (PENDING_DECLARATIONS.size() >= MAX_PENDING_FILES) return;
      PENDING_DECLARATIONS.put(fileKey, held = new ArrayList<>(names.size()));
    }
    for (int i = 0; i < names.size() && held.size() < MAX_PENDING_NAMES; i++)
      if (!held.contains(names.get(i))) held.add(names.get(i));
  }

  /**
   * W21′1 — live buffer text: the same parse, only compared. Nothing is committed to the index, so
   * an unfinished keystroke cannot rewrite what the rest of the project resolves against; the
   * changed names it reports are enough to wake the files that use them. Runs outside the class lock
   * except for the short compare, so typing never waits on the index.
   */
  public static void noteLiveMembers(String fileName, String source) {
    applyLiveMembers(fileName, liveMembersOf(fileName, source));
  }

  /**
   * W23/1 — the parse half of {@link #noteLiveMembers}, split out so it can run in the analyzer
   * process while the index it compares against stays here. Pure read of {@code source}: nothing is
   * committed, no lock is taken, so the other process may call it safely on its own copy.
   */
  public static almlk.AnalyzerProtocol.Members liveMembersOf(String fileName, String source) {
    if (source == null || source.isEmpty()) return almlk.AnalyzerProtocol.Members.empty();
    ParsedFile parsed = parse(fileName, source);
    if (parsed.classNames.isEmpty()) return almlk.AnalyzerProtocol.Members.empty();
    String[] classNames = parsed.classNames.toArray(new String[0]);
    String[] methodNames =
        parsed.methods == null ? new String[0] : parsed.methods.toArray(new String[0]);
    java.util.LinkedHashMap<String, String> fields = parsed.fields;
    int count = fields == null ? 0 : fields.size();
    String[] fieldNames = new String[count];
    String[] fieldTypes = new String[count];
    if (fields != null) {
      int at = 0;
      for (java.util.Map.Entry<String, String> entry : fields.entrySet()) {
        fieldNames[at] = entry.getKey();
        fieldTypes[at] = entry.getValue() == null ? "" : entry.getValue();
        at++;
      }
    }
    return new almlk.AnalyzerProtocol.Members(classNames, methodNames, fieldNames, fieldTypes);
  }

  /**
   * W23/1 — the compare half: takes what {@link #liveMembersOf} found (here or across processes) and
   * records the delta against the index, exactly as {@link #noteLiveMembers} always did. Cheap set
   * work under the class lock, so it belongs on the UI side: the index stays one cache, not two.
   */
  public static void applyLiveMembers(
      String fileName, almlk.AnalyzerProtocol.Members members) {
    if (members == null || members.classNames.length == 0) return;
    java.util.HashSet<String> methods = new java.util.HashSet<>();
    java.util.Collections.addAll(methods, members.methodNames);
    java.util.LinkedHashMap<String, String> fields = new java.util.LinkedHashMap<>();
    int count = Math.min(members.fieldNames.length, members.fieldTypes.length);
    for (int i = 0; i < count; i++) fields.put(members.fieldNames[i], members.fieldTypes[i]);
    synchronized (ProjectSymbolIndex.class) {
      for (String className : members.classNames) {
        recordMemberDelta(
            className, fileName, METHODS.get(className), CLASS_FIELDS.get(className), methods, fields);
      }
    }
  }

  /** W21′1: a declaration changed and the files that use it have not been swept yet. */
  public static synchronized boolean hasPendingDeclarationChanges() {
    return !PENDING_DECLARATIONS.isEmpty();
  }

  /** W21′1: عددُ مرّاتِ تغيّرِ عقدِ صنفٍ منذَ مسحِ المشروعِ — مفتاحُ صلاحيةِ اللقطةِ الحافظةِ. */
  public static synchronized long structureEpoch() {
    return structureEpoch;
  }

  /** Drops the queue (project switched, editor detached): nothing is owed after this. */
  public static synchronized void clearPendingDeclarationChanges() {
    PENDING_DECLARATIONS.clear();
  }

  /** The files whose declarations changed, oldest first (capped): the sweep makes them truthful. */
  public static synchronized ArrayList<String> drainPendingDeclarationFiles(int limit) {
    ArrayList<String> out = new ArrayList<>(PENDING_DECLARATIONS.keySet());
    if (limit >= 0 && out.size() > limit) out = new ArrayList<>(out.subList(0, limit));
    return out;
  }

  /** The changed member names queued so far (not consumed: the sweep clears the queue itself). */
  public static synchronized ArrayList<String> pendingMemberNames() {
    LinkedHashSet<String> names = new LinkedHashSet<>();
    for (ArrayList<String> held : PENDING_DECLARATIONS.values()) names.addAll(held);
    ArrayList<String> out = new ArrayList<>(names);
    out.sort(null);
    return out;
  }


  private static final Pattern PARENT_PATTERN =
      Pattern.compile("\\b(?:class|interface)\\s+([A-Za-z_$][A-Za-z0-9_$]*)"
          + "(?:\\s*<[^>{}]+>)?\\s+extends\\s+([A-Za-z_$][A-Za-z0-9_$.]*)");

  /** Immutable parsed class snapshot used by the persistent project index. */
  public static final class CachedClass {
    public final String name, parent, fileName, reference, packageName;
    public final int offset;
    public final List<CachedMember> members;

    public CachedClass(
        String name,
        String parent,
        String fileName,
        String reference,
        int offset,
        List<CachedMember> members) {
      this(name, parent, fileName, reference, "", offset, members);
    }

    public CachedClass(
        String name,
        String parent,
        String fileName,
        String reference,
        String packageName,
        int offset,
        List<CachedMember> members) {
      this.name = name == null ? "" : name;
      this.parent = parent == null ? "" : parent;
      this.fileName = fileName == null ? "" : fileName;
      this.reference = reference == null ? "" : reference;
      this.packageName = packageName == null ? "" : packageName;
      this.offset = Math.max(0, offset);
      this.members = members == null ? Collections.emptyList() : new ArrayList<>(members);
    }
  }

  public static final class CachedMember {
    public final String name, returnType, parameters;
    public final int offset;
    public final boolean method;

    public CachedMember(
        String name, String returnType, String parameters, int offset, boolean method) {
      this.name = name == null ? "" : name;
      this.returnType = returnType == null ? "Object" : returnType;
      this.parameters = parameters == null ? "" : parameters;
      this.offset = Math.max(0, offset);
      this.method = method;
    }
  }

  /** Exports only classes belonging to one already parsed source file; no source rescan occurs. */
  public static synchronized List<CachedClass> cachedClassesForFile(
      String fileName, String reference) {
    ArrayList<CachedClass> result = new ArrayList<>();
    for (Map.Entry<String, String> entry : CLASS_FILES.entrySet()) {
      String owner = entry.getKey();
      if (!Objects.equals(entry.getValue(), fileName)
          || !Objects.equals(CLASS_REFERENCES.get(owner), reference)) continue;
      ArrayList<CachedMember> members = new ArrayList<>();
      LinkedHashMap<String, String> returns = METHOD_RETURNS.get(owner);
      LinkedHashMap<String, String> parameters = METHOD_PARAMETERS.get(owner);
      LinkedHashMap<String, Integer> offsets = METHOD_OFFSETS.get(owner);
      if (returns != null) {
        for (Map.Entry<String, String> method : returns.entrySet()) {
          if (method.getKey().equals("toString")
              || method.getKey().equals("hashCode")
              || method.getKey().equals("equals")
              || method.getKey().equals("clone")) continue;
          members.add(
              new CachedMember(
                  method.getKey(),
                  method.getValue(),
                  parameters == null ? "" : parameters.getOrDefault(method.getKey(), ""),
                  offsets == null ? 0 : offsets.getOrDefault(method.getKey(), 0),
                  true));
        }
      }
      LinkedHashMap<String, String> fields = CLASS_FIELDS.get(owner);
      LinkedHashMap<String, Integer> fieldOffsets = FIELD_OFFSETS.get(owner);
      if (fields != null) {
        for (Map.Entry<String, String> field : fields.entrySet()) {
          members.add(
              new CachedMember(
                  field.getKey(),
                  field.getValue(),
                  "",
                  fieldOffsets == null ? 0 : fieldOffsets.getOrDefault(field.getKey(), 0),
                  false));
        }
      }
      result.add(
          new CachedClass(
              owner,
              PARENTS.getOrDefault(owner, ""),
              fileName,
              reference,
              CLASS_PACKAGES.getOrDefault(owner, ""),
              CLASS_OFFSETS.getOrDefault(owner, 0),
              members));
    }
    return result;
  }

  private static void noteCachedShadow(CachedClass cached) {
    ParsedFile p = new ParsedFile();
    p.sourcePackage = cached.packageName == null ? "" : cached.packageName;
    p.classNames.add(cached.name);
    noteShadowed(cached.fileName, cached.reference, p);
  }

  /** Restores one parsed class directly into RAM without reading or parsing its source. */
  public static synchronized void registerCachedClass(CachedClass cached) {
    if (cached == null || cached.name.isEmpty()) return;
    // W21′2: سطرٌ على القرصِ من ملفٍّ ظلٍّ مرفوضٌ مثلُهُ حيًّا — وإلا عادَ الظلُّ بعدَ حذفِهِ من
    // المشروعِ لأنَّ تخزينَ البنيةِ يحتفظُ بأسطرِهِ القديمةِ حتى يُعادَ زيارتُها.
    if (almlk.ProjectSourceRoots.platformOrLibraryPackage(cached.packageName)) {
      noteCachedShadow(cached);
      return;
    }
    // Cache rows do not retain nesting/interface metadata; callers rehydrate complete sources
    // before diagnostics are published, so cached-only classes are not proof-grade yet.
    TYPES_WITH_UNCERTAIN_NESTING.add(cached.name);
    SUPERTYPES.remove(cached.name);
    LinkedHashMap<String, String> returns = new LinkedHashMap<>();
    LinkedHashMap<String, String> parameters = new LinkedHashMap<>();
    LinkedHashMap<String, Integer> methodOffsets = new LinkedHashMap<>();
    LinkedHashMap<String, String> fields = new LinkedHashMap<>();
    LinkedHashMap<String, Integer> fieldOffsets = new LinkedHashMap<>();
    HashSet<String> methods = new HashSet<>();
    for (CachedMember member : cached.members) {
      if (methods.size() + fields.size() >= MAX_MEMBERS_PER_FILE) break;
      if (member == null || member.name.isEmpty()) continue;
      if (member.method) {
        methods.add(member.name);
        returns.put(member.name, member.returnType);
        parameters.put(member.name, member.parameters);
        methodOffsets.put(member.name, member.offset);
      } else {
        putFieldType(fields, member.name, simpleType(member.returnType));
        fieldOffsets.put(member.name, member.offset);
      }
    }
    returns.put("toString", "String");
    returns.put("hashCode", "int");
    returns.put("equals", "boolean");
    returns.put("clone", "Object");
    for (String method : returns.keySet())
      if (!parameters.containsKey(method)) parameters.put(method, "");
    methods.addAll(returns.keySet());
    METHODS.put(cached.name, methods);
    METHOD_RETURNS.put(cached.name, returns);
    METHOD_PARAMETERS.put(cached.name, parameters);
    CLASS_FIELDS.put(cached.name, fields);
    METHOD_OFFSETS.put(cached.name, methodOffsets);
    FIELD_OFFSETS.put(cached.name, fieldOffsets);
    CLASS_FILES.put(cached.name, cached.fileName);
    CLASS_REFERENCES.put(cached.name, cached.reference);
    CLASS_PACKAGES.put(cached.name, cached.packageName);
    CLASS_OFFSETS.put(cached.name, cached.offset);
    if (!cached.parent.isEmpty()) PARENTS.put(cached.name, simpleType(cached.parent));
    CLASS_TRIE.put(cached.name, cached.name);
    classNamesDirty = true;
  }

  public static synchronized boolean knowsClass(String className) {
    return METHODS.containsKey(simpleType(className));
  }

  /** Snapshot of indexed project/library classes for strict `new Type` completion. */
  public static synchronized List<String> classNames() {
    if (classNamesDirty) {
      ArrayList<String> result = new ArrayList<>(METHODS.keySet());
      result.sort(String::compareToIgnoreCase);
      classNamesCache = Collections.unmodifiableList(result);
      classNamesDirty = false;
    }
    return classNamesCache;
  }

  /** Trie-backed class prefix lookup used by `new Type` completion. */
  public static synchronized List<String> classNamesMatching(String prefix, int maxResults) {
    return CLASS_TRIE.prefix(prefix, Math.max(1, Math.min(256, maxResults)));
  }

  /** قائمة مسارات ملفات Java المفهرسة — تُستخدم لإعادة التسمية عبر المشروع (المرحلة 2). */
  public static synchronized java.util.List<String> projectJavaFiles() {
    return new java.util.ArrayList<>(CLASS_FILES.values());
  }

  /** Returns the package captured when a project source was indexed, including from its cache. */
  public static synchronized String packageOf(String className) {
    String simpleName = simpleType(className);
    if (CLASS_PACKAGES.containsKey(simpleName)) return CLASS_PACKAGES.get(simpleName);
    String file = CLASS_FILES.get(simpleName);
    if (file == null) return null;
    try {
      java.io.File f = new java.io.File(file);
      if (!f.isFile()) return null;
      java.io.BufferedReader reader =
          new java.io.BufferedReader(new java.io.FileReader(f));
      try {
        String line;
        while ((line = reader.readLine()) != null) {
          String trimmed = line.trim();
          if (trimmed.startsWith("package ")) {
            int end = trimmed.indexOf(';');
            String value = trimmed.substring(8, end > 8 ? end : trimmed.length()).trim();
            CLASS_PACKAGES.put(simpleName, value);
            return value;
          }
          if (trimmed.startsWith("import ") || trimmed.startsWith("public ")
              || trimmed.startsWith("class ") || trimmed.startsWith("interface ")) break;
        }
      } finally {
        reader.close();
      }
    } catch (Exception ignored) {
    }
    return null;
  }

  /** Resolves a receiver variable using declarations, assignments, and simple casts. */
  public static synchronized String resolveVariableType(String source, String variable) {
    if (source == null || variable == null || variable.isEmpty()) return "";
    return variableTypes(mask(source)).getOrDefault(variable, "");
  }

  /**
   * Resolves a completion receiver such as a variable, a class name, this.field, or a short
   * chained expression. Class names are accepted as static receivers so `MyClass.` can expose the
   * indexed methods instead of returning an empty popup.
   */
  public static synchronized String resolveExpressionType(String source, String expression) {
    if (source == null || expression == null) return "";
    if (expression.trim().isEmpty()) return "";
    String code = mask(source);
    return resolveExpressionType(code, variableTypes(code), expression);
  }

  /**
   * Same resolution over an already masked source and its variable table (computed once per
   * expression).
   */
  private static synchronized String resolveExpressionType(
      String code, Map<String, String> variables, String expression) {
    String value = expression.trim();
    if (value.isEmpty()) return "";
    String[] parts = value.split("\\s*\\.\\s*");
    if (parts.length == 0) return "";
    String current;
    if ("this".equals(parts[0])) {
      Matcher owner = CLASS_PATTERN.matcher(code);
      current = owner.find() ? owner.group(1) : "";
    } else {
      current = variables.getOrDefault(parts[0], simpleType(parts[0]));
    }
    if (current == null || current.isEmpty() || !knowsClass(current)) return "";
    for (int i = 1; i < parts.length; i++) {
      String member = parts[i].trim();
      String next = memberType(current, member);
      if (next.isEmpty()) return "";
      current = next;
    }
    return simpleType(current);
  }

  private static String memberType(String type, String member) {
    String current = simpleType(type);
    HashSet<String> visited = new HashSet<>();
    while (!current.isEmpty() && visited.add(current)) {
      LinkedHashMap<String, String> fields = CLASS_FIELDS.get(current);
      if (fields != null && fields.containsKey(member)) return fields.get(member);
      LinkedHashMap<String, String> returns = METHOD_RETURNS.get(current);
      if (returns != null && returns.containsKey(member)) return returns.get(member);
      current = PARENTS.getOrDefault(current, "");
    }
    return "";
  }

  // ---------------- Stage 4: member lookup across project and platform types ----------------

  /** {@link #memberStatus} results. */
  public static final int MEMBER_FOUND = 1, MEMBER_ABSENT = 0, MEMBER_UNKNOWN = -1;

  /**
   * Whether {@code typeRef}, written in a file with {@code imports}/{@code packageName}, has the
   * member — walking project supertypes and finishing on platform types through {@link
   * almlk.PlatformMemberLookup}. Any link that cannot be proven (library type, cached-only or
   * nested project class, record, older platform than compileSdk) makes the answer UNKNOWN, and
   * callers never report UNKNOWN: zero false positives over coverage.
   */
  public static synchronized int memberStatus(
      String typeRef, List<String> imports, String packageName, String member, boolean method) {
    if (member == null || member.isEmpty()) return MEMBER_UNKNOWN;
    return memberStatus(typeRef, imports, packageName, member, method, new HashSet<>(), 0);
  }

  private static int memberStatus(
      String typeRef,
      List<String> imports,
      String packageName,
      String member,
      boolean method,
      HashSet<String> visited,
      int depth) {
    if (depth > 24) return MEMBER_UNKNOWN;
    String ref = almlk.PlatformMemberLookup.stripGenerics(typeRef);
    String simple = simpleType(ref);
    int origin = typeOrigin(ref, simple, imports);
    if (origin == ORIGIN_UNCERTAIN) return MEMBER_UNKNOWN;
    if (origin == ORIGIN_PROJECT) {
      if (!visited.add(simple)) return MEMBER_ABSENT;
      if (method) {
        Set<String> names = METHODS.get(simple);
        if (names != null && names.contains(member)) return MEMBER_FOUND;
      } else {
        LinkedHashMap<String, String> fields = CLASS_FIELDS.get(simple);
        Set<String> loose = LOOSE_NAMES.get(simple);
        if ((fields != null && fields.containsKey(member)) || (loose != null && loose.contains(member)))
          return MEMBER_FOUND;
      }
      List<String> supertypes = SUPERTYPES.get(simple);
      if (supertypes == null) return MEMBER_UNKNOWN;
      List<String> ownImports = CLASS_IMPORTS.getOrDefault(simple, Collections.<String>emptyList());
      String ownPackage = CLASS_PACKAGES.getOrDefault(simple, "");
      boolean unknown = false;
      for (String supertype : supertypes) {
        int status =
            memberStatus(supertype, ownImports, ownPackage, member, method, visited, depth + 1);
        if (status == MEMBER_FOUND) return MEMBER_FOUND;
        if (status == MEMBER_UNKNOWN) unknown = true;
      }
      return unknown ? MEMBER_UNKNOWN : MEMBER_ABSENT;
    }
    almlk.PlatformMemberLookup.Members platform =
        almlk.PlatformMemberLookup.resolve(ref, imports, packageName);
    if (platform == null) return MEMBER_UNKNOWN;
    if (method ? platform.hasMethod(member) : platform.hasField(member)) return MEMBER_FOUND;
    return almlk.PlatformMemberLookup.isAbsenceDefinitive(platform) ? MEMBER_ABSENT : MEMBER_UNKNOWN;
  }

  private static final int ORIGIN_PROJECT = 0, ORIGIN_OTHER = 1, ORIGIN_UNCERTAIN = 2;

  /** Project class, other (platform/library — the platform lookup decides) or uncertain. */
  private static int typeOrigin(String ref, String simple, List<String> imports) {
    if (simple.isEmpty()) return ORIGIN_UNCERTAIN;
    boolean project = CLASS_FILES.containsKey(simple);
    int dot = ref.lastIndexOf('.');
    if (dot > 0) {
      String qualifier = ref.substring(0, dot);
      if (project && qualifier.equals(CLASS_PACKAGES.getOrDefault(simple, "")))
        return TYPES_WITH_UNCERTAIN_NESTING.contains(simple) ? ORIGIN_UNCERTAIN : ORIGIN_PROJECT;
      String outer = simpleType(qualifier);
      return CLASS_FILES.containsKey(outer) || project ? ORIGIN_UNCERTAIN : ORIGIN_OTHER;
    }
    if (imports != null) {
      for (String imported : imports) {
        if (imported.endsWith(".*") || !imported.endsWith("." + simple)) continue;
        String importedPackage = imported.substring(0, imported.length() - simple.length() - 1);
        if (!project) return ORIGIN_OTHER;
        return importedPackage.equals(CLASS_PACKAGES.getOrDefault(simple, ""))
            ? (TYPES_WITH_UNCERTAIN_NESTING.contains(simple) ? ORIGIN_UNCERTAIN : ORIGIN_PROJECT)
            : ORIGIN_OTHER;
      }
    }
    if (!project) return ORIGIN_OTHER;
    return TYPES_WITH_UNCERTAIN_NESTING.contains(simple) ? ORIGIN_UNCERTAIN : ORIGIN_PROJECT;
  }

  /** Display name for messages: {@code com.example.ClipboardHelper} (simple name if unknown). */
  public static synchronized String qualifiedName(String simpleName) {
    String simple = simpleType(simpleName);
    String pkg = CLASS_PACKAGES.getOrDefault(simple, "");
    return pkg.isEmpty() ? simple : pkg + "." + simple;
  }

  /**
   * M4: a package declared by project sources, a parent of one, or below one (generated code such
   * as {@code com.app.databinding} lives under the project's packages).
   */
  public static synchronized boolean isProjectPackage(String pkg) {
    if (pkg == null || pkg.isEmpty()) return false;
    for (String declared : CLASS_PACKAGES.values()) {
      if (declared == null || declared.isEmpty()) continue;
      if (declared.equals(pkg) || declared.startsWith(pkg + ".") || pkg.startsWith(declared + ".")) return true;
    }
    return false;
  }

  /** M4: path (reference) of the file declaring a project class, or null when not indexed. */
  public static synchronized String fileOfClass(String simpleName) {
    return CLASS_REFERENCES.get(simpleType(simpleName));
  }

  /** True for a class parsed from project sources (the only kind a quick fix may edit). */
  public static synchronized boolean isProjectClass(String simpleName) {
    return CLASS_FILES.containsKey(simpleType(simpleName));
  }

  /** First segments of every indexed project package (for telling {@code pkg.Type} from x.y). */
  public static synchronized Set<String> packageRoots() {
    HashSet<String> roots = new HashSet<>();
    for (String pkg : CLASS_PACKAGES.values()) {
      if (pkg == null || pkg.isEmpty()) continue;
      int dot = pkg.indexOf('.');
      roots.add(dot < 0 ? pkg : pkg.substring(0, dot));
    }
    return roots;
  }

  /** Non-static imports of a (masked) file: {@code a.b.C} and {@code a.b.*}. */
  public static List<String> importsOf(String code) {
    ArrayList<String> result = new ArrayList<>();
    Matcher imports = IMPORT_PATTERN.matcher(code == null ? "" : code);
    while (imports.find()) {
      String imported = imports.group(1);
      if (imports.group(2) != null) {
        if (imported.endsWith(".")) imported = imported.substring(0, imported.length() - 1);
        result.add(imported + ".*");
      } else result.add(imported);
    }
    return Collections.unmodifiableList(result);
  }

  private static final Pattern LOOSE_DECLARATION =
      Pattern.compile(
          "(?<![\\w$.@])([A-Za-z_$][\\w$]*(?:\\s*\\.\\s*[A-Za-z_$][\\w$]*)*(?:\\s*<[^;(){}=]*?>)?"
              // `String[]args` / `List<String>items` need no space after `]` or `>`.
              + "(?:\\s*\\.\\s*[A-Za-z_$][\\w$]*)*(?:\\s*\\[\\s*\\])*)(?:\\s*\\.\\.\\.\\s*|\\s+|(?<=[\\]>])\\s*)"
              + "([A-Za-z_$][\\w$]*)\\s*(?=[=;,):\\[&|?]|->|$)");
  private static final Pattern LOOSE_SECONDARY_DECLARATOR =
      Pattern.compile(",\\s*([A-Za-z_$][\\w$]*)\\s*(?=[=;,])");
  private static final Pattern LOOSE_METHOD =
      Pattern.compile("([\\w$>\\]])\\s+([A-Za-z_$][\\w$]*)\\s*\\(");
  private static final Set<String> NON_TYPE_WORDS =
      new HashSet<>(Arrays.asList(
          "return", "throw", "new", "else", "case", "yield", "assert", "do", "goto", "break",
          "continue", "instanceof", "package", "import", "extends", "implements", "throws",
          "class", "interface", "enum", "record", "permits", "super", "this", "default",
          "public", "private", "protected", "static", "final", "abstract", "synchronized",
          "volatile", "transient", "native", "strictfp", "sealed"));

  /**
   * Every name that a (masked) file declares in any form — fields, locals, parameters, catch and
   * pattern variables, secondary declarators. Deliberately loose: used only to prove existence.
   */
  public static Set<String> declaredNames(String code) {
    HashSet<String> names = new HashSet<>();
    if (code == null) return names;
    Matcher declarations = LOOSE_DECLARATION.matcher(code);
    int from = 0;
    // Overlapping search: in "private Foo[] x" the first hit is ("private", "Foo"); the search
    // resumes at the name so that ("Foo[]", "x") is found as well.
    while (from < code.length() && declarations.find(from)) {
      if (!NON_TYPE_WORDS.contains(declarations.group(1))) names.add(declarations.group(2));
      from = declarations.start(2);
    }
    Matcher secondary = LOOSE_SECONDARY_DECLARATOR.matcher(code);
    while (secondary.find()) names.add(secondary.group(1));
    return names;
  }

  /** Every method/constructor name a (masked) file declares, loosely ({@code type name(}). */
  public static Set<String> declaredMethodNames(String code) {
    HashSet<String> names = new HashSet<>();
    if (code == null) return names;
    Matcher methods = LOOSE_METHOD.matcher(code);
    while (methods.find()) {
      int typeEnd = methods.end(1);
      int typeStart = typeEnd;
      while (typeStart > 0 && Character.isJavaIdentifierPart(code.charAt(typeStart - 1))) typeStart--;
      String word = code.substring(typeStart, typeEnd);
      if (NON_TYPE_WORDS.contains(word)) continue;
      names.add(methods.group(2));
    }
    return names;
  }

  private static final Pattern TYPE_HEADER_KEYWORD =
      Pattern.compile("(?<![\\w$.@])(class|interface|enum|record)\\s+");

  /**
   * Direct supertypes of {@code className} in a masked file, with the implicit ones: Object for
   * classes/interfaces, Enum for enums. Records return null (their accessors are not declared).
   */
  public static List<String> supertypesOf(String code, String className) {
    Matcher keyword = TYPE_HEADER_KEYWORD.matcher(code);
    while (keyword.find()) {
      int nameStart = keyword.end();
      if (!code.startsWith(className, nameStart)) continue;
      int nameEnd = nameStart + className.length();
      if (nameEnd < code.length() && Character.isJavaIdentifierPart(code.charAt(nameEnd))) continue;
      String kind = keyword.group(1);
      if ("record".equals(kind)) return null;
      int open = code.indexOf('{', nameEnd);
      if (open < 0) return null;
      String header = withoutTypeArguments(code.substring(nameEnd, open));
      ArrayList<String> result = new ArrayList<>();
      String extendsPart = clause(header, "extends");
      String implementsPart = clause(header, "implements");
      if (!extendsPart.isEmpty())
        for (String type : extendsPart.split(",")) if (!type.trim().isEmpty()) result.add(type.trim());
      if ("enum".equals(kind)) result.add("java.lang.Enum");
      else if (extendsPart.isEmpty() || "interface".equals(kind)) result.add("java.lang.Object");
      if (!implementsPart.isEmpty())
        for (String type : implementsPart.split(",")) if (!type.trim().isEmpty()) result.add(type.trim());
      return Collections.unmodifiableList(result);
    }
    return null;
  }

  /** Removes {@code <...>} (nested) but keeps the spacing between words. */
  private static String withoutTypeArguments(String text) {
    StringBuilder out = new StringBuilder();
    int depth = 0;
    for (int i = 0; i < text.length(); i++) {
      char c = text.charAt(i);
      if (c == '<') depth++;
      else if (c == '>') depth = Math.max(0, depth - 1);
      else if (depth == 0) out.append(Character.isWhitespace(c) ? ' ' : c);
    }
    return " " + out.toString().replaceAll("\\s*\\.\\s*", ".").replaceAll("\\s*,\\s*", ",");
  }

  private static String clause(String header, String word) {
    Matcher matcher =
        Pattern.compile("\\s" + word + "\\s+(.*?)(?=\\s(?:extends|implements|permits)\\s|$)")
            .matcher(header + " ");
    return matcher.find() ? matcher.group(1).trim() : "";
  }

  /** Typed completion for any file kind; delegates to the single completion pipeline. */
  public static List<CompletionItem> complete(
      String fileName, String source, int cursorOffset) {
    return KayStyleCompletionEngine.complete(fileName, source, cursorOffset);
  }

  /** Read-only view of a project class indexed from source, for code completion. */
  public static final class ProjectClass {
    public final String name, packageName, superName;
    public final List<String> supertypes, imports;
    public final Map<String, String> fields, methodReturns, methodParameters;

    ProjectClass(String name) {
      this.name = name;
      this.packageName = CLASS_PACKAGES.getOrDefault(name, "");
      this.superName = PARENTS.getOrDefault(name, "");
      List<String> sup = SUPERTYPES.get(name);
      this.supertypes = sup == null ? Collections.<String>emptyList() : new ArrayList<>(sup);
      List<String> imp = CLASS_IMPORTS.get(name);
      this.imports = imp == null ? Collections.<String>emptyList() : new ArrayList<>(imp);
      LinkedHashMap<String, String> f = CLASS_FIELDS.get(name);
      this.fields = f == null ? Collections.<String, String>emptyMap() : new LinkedHashMap<>(f);
      LinkedHashMap<String, String> r = METHOD_RETURNS.get(name);
      this.methodReturns = r == null ? Collections.<String, String>emptyMap() : new LinkedHashMap<>(r);
      LinkedHashMap<String, String> pa = METHOD_PARAMETERS.get(name);
      this.methodParameters = pa == null ? Collections.<String, String>emptyMap() : new LinkedHashMap<>(pa);
    }
  }

  /** The project class (from a project source, not a built-in seed) with this simple name. */
  public static synchronized ProjectClass projectClass(String simpleName) {
    if (simpleName == null || !CLASS_PACKAGES.containsKey(simpleName)) return null;
    return new ProjectClass(simpleName);
  }

  /** Simple names of project classes starting with {@code prefix} (built-in seeds excluded). */
  public static synchronized List<String> projectClassNamesMatching(String prefix, int maxResults) {
    ArrayList<String> out = new ArrayList<>();
    for (String name : CLASS_TRIE.prefix(prefix == null ? "" : prefix, 4096)) {
      if (CLASS_PACKAGES.containsKey(name)) out.add(name);
      if (out.size() >= maxResults) break;
    }
    return out;
  }

  /** AndroidIDE-style match levels: exact/prefix, camel-case subsequence, then fuzzy subsequence. */
  public static int matchScore(String value, String query) {
    if (value == null) return Integer.MAX_VALUE;
    String candidate = value.toLowerCase(Locale.US);
    String wanted = query == null ? "" : query.trim().toLowerCase(Locale.US);
    if (wanted.isEmpty()) return 0;
    if (candidate.equals(wanted)) return 0;
    if (candidate.startsWith(wanted)) return 10 + candidate.length() - wanted.length();
    if (candidate.contains(wanted)) return 40 + candidate.indexOf(wanted);
    int wantedAt = 0;
    int boundaryHits = 0;
    boolean previousWord = false;
    for (int i = 0; i < candidate.length() && wantedAt < wanted.length(); i++) {
      char c = candidate.charAt(i);
      boolean boundary = i == 0 || (!previousWord && Character.isLetterOrDigit(c)) || Character.isUpperCase(value.charAt(i));
      if (c == wanted.charAt(wantedAt)) {
        if (boundary) boundaryHits++;
        wantedAt++;
      }
      previousWord = Character.isLetterOrDigit(c) || c == '_' || c == '$';
    }
    if (wantedAt == wanted.length()) return (boundaryHits > 0 ? 20 : 60) + candidate.length() - wanted.length();
    return Integer.MAX_VALUE;
  }

  private static boolean matches(String value, String prefix) {
    return matchScore(value, prefix) != Integer.MAX_VALUE;
  }

  private static int[][] diagnosticScopes(String code) {
    int[] scopeAt = new int[code.length() + 1];
    int[] parentOfOpen = new int[code.length()];
    Arrays.fill(parentOfOpen, -1);
    ArrayDeque<Integer> stack = new ArrayDeque<>();
    for (int i = 0; i < code.length(); i++) {
      scopeAt[i] = stack.isEmpty() ? -1 : stack.peek();
      char c = code.charAt(i);
      if (c == '{') {
        parentOfOpen[i] = stack.isEmpty() ? -1 : stack.peek();
        stack.push(i);
      } else if (c == '}' && !stack.isEmpty()) {
        stack.pop();
      }
    }
    scopeAt[code.length()] = stack.isEmpty() ? -1 : stack.peek();
    return new int[][] {scopeAt, parentOfOpen};
  }

  private static boolean isScopeVisible(int declarationScope, int useScope, int[] parentOfOpen) {
    if (declarationScope < 0) return true;
    int scope = useScope;
    while (scope >= 0 && scope < parentOfOpen.length) {
      if (scope == declarationScope) return true;
      scope = parentOfOpen[scope];
    }
    return false;
  }

  private static int qualifiedReceiverStart(String code, int receiverStart) {
    int start = receiverStart;
    while (start > 0) {
      int dot = start - 1;
      while (dot >= 0 && Character.isWhitespace(code.charAt(dot))) dot--;
      if (dot < 0 || code.charAt(dot) != '.') break;
      int end = dot;
      int nameStart = end;
      while (nameStart > 0 && Character.isWhitespace(code.charAt(nameStart - 1))) nameStart--;
      end = nameStart;
      while (nameStart > 0 && Character.isJavaIdentifierPart(code.charAt(nameStart - 1))) nameStart--;
      if (nameStart == end) break;
      start = nameStart;
    }
    return start;
  }

  /**
   * Every explicitly typed declaration of a masked file, by name: {nameStart, effectiveScope} and
   * the written type. Built once per file — a scan per call site made large files quadratic.
   */
  private static Map<String, ArrayList<Object[]>> diagnosticDeclarations(String code, int[] scopeAt) {
    HashMap<String, ArrayList<Object[]>> table = new HashMap<>();
    Matcher declarations = DIAGNOSTIC_VARIABLE_PATTERN.matcher(code);
    while (declarations.find()) {
      String type = declarations.group(1).trim();
      if (!balancedTypeArguments(type)) continue; // "A<B, C<D>> x" split at ','
      int nameStart = declarations.start(2);
      int declarationScope = scopeAt[nameStart];
      // Parameters (method, catch, for, resources) belong to the body that follows them, not to
      // the enclosing scope — otherwise a same-named field elsewhere would get their type.
      int body = headerBodyOpen(code, nameStart);
      if (body >= 0 && body + 1 < scopeAt.length) declarationScope = scopeAt[body + 1];
      ArrayList<Object[]> list = table.get(declarations.group(2));
      if (list == null) table.put(declarations.group(2), list = new ArrayList<>());
      list.add(new Object[] {nameStart, declarationScope, type});
    }
    return table;
  }

  private static String diagnosticReceiverType(
      Map<String, ArrayList<Object[]>> table,
      String receiver,
      int useOffset,
      int[] scopeAt,
      int[] parentOfOpen) {
    ArrayList<Object[]> candidates = table.get(receiver);
    if (candidates == null) return null;
    String bestType = null;
    int bestOffset = -1;
    for (Object[] candidate : candidates) {
      int nameStart = (Integer) candidate[0];
      if (nameStart >= useOffset) break;
      if (!isScopeVisible((Integer) candidate[1], scopeAt[useOffset], parentOfOpen)) continue;
      if (nameStart > bestOffset) {
        bestOffset = nameStart;
        bestType = (String) candidate[2];
      }
    }
    return bestType;
  }

  private static boolean balancedTypeArguments(String type) {
    int depth = 0;
    for (int i = 0; i < type.length(); i++) {
      char c = type.charAt(i);
      if (c == '<') depth++;
      else if (c == '>' && --depth < 0) return false;
    }
    return depth == 0;
  }

  /** If {@code offset} is inside a header {@code (...)} followed by a block, that block's '{'. */
  private static int headerBodyOpen(String code, int offset) {
    int depth = 0, open = -1;
    for (int i = offset - 1; i >= 0; i--) {
      char c = code.charAt(i);
      if (c == ')') depth++;
      else if (c == '(') {
        if (depth == 0) {
          open = i;
          break;
        }
        depth--;
      } else if (c == ';' || c == '{' || c == '}') return -1;
    }
    if (open < 0) return -1;
    int close = matchingParenthesis(code, open);
    if (close < 0) return -1;
    int k = close + 1;
    while (k < code.length() && Character.isWhitespace(code.charAt(k))) k++;
    if (code.startsWith("throws", k)) {
      while (k < code.length() && code.charAt(k) != '{' && code.charAt(k) != ';') k++;
    } else if (code.startsWith("->", k)) {
      k += 2;
      while (k < code.length() && Character.isWhitespace(code.charAt(k))) k++;
    }
    return k < code.length() && code.charAt(k) == '{' ? k : -1;
  }

  private static final Pattern DECLARED_TYPE_PATTERN =
      Pattern.compile("\\b(?:class|interface|enum|record)\\s+([A-Za-z_$][\\w$]*)");

  /** Simple names of the types declared inside another type or block of masked {@code code}. */
  private static Set<String> nestedTypeNames(String code) {
    HashSet<String> names = new HashSet<>();
    Matcher matcher = DECLARED_TYPE_PATTERN.matcher(code);
    int depth = 0, scanned = 0;
    while (matcher.find()) {
      for (; scanned < matcher.start(); scanned++) {
        char c = code.charAt(scanned);
        if (c == '{') depth++;
        else if (c == '}') depth = Math.max(0, depth - 1);
      }
      if (depth > 0) names.add(matcher.group(1));
    }
    return names;
  }

  /** Parameters for a generated method from the call's argument list at {@code openParen}. */
  public static List<almlk.QuickFix.Param> inferQuickFixParams(String source, int openParen) {
    ArrayList<almlk.QuickFix.Param> result = new ArrayList<>();
    if (source == null || openParen < 0 || openParen >= source.length()
        || source.charAt(openParen) != '(') return result;
    int close = matchingParenthesis(source, openParen);
    if (close < 0) return result;
    List<String> parts = splitArguments(source.substring(openParen + 1, close));
    Map<String, String> variables = variableTypes(mask(source));
    for (int i = 0; i < parts.size(); i++) {
      String value = parts.get(i).trim();
      if (value.isEmpty()) continue;
      String type;
      if (value.startsWith("\"") && value.endsWith("\"")) type = "String";
      else if (value.startsWith("'") && value.endsWith("'")) type = "char";
      else if (value.equals("true") || value.equals("false")) type = "boolean";
      else if (value.matches("[-+]?\\d+[lL]")) type = "long";
      else if (value.matches("[-+]?(?:\\d+\\.\\d*|\\d*\\.\\d+)[fF]")) type = "float";
      else if (value.matches("[-+]?(?:\\d+\\.\\d*|\\d*\\.\\d+)(?:[dD])?")) type = "double";
      else if (value.matches("[-+]?\\d+")) type = "int";
      else if (value.equals("null")) type = "Object";
      else type = variables.getOrDefault(value, "Object");
      String name =
          value.matches("[A-Za-z_$][A-Za-z0-9_$]*") && !NON_TYPE_WORDS.contains(value)
                  && !"true".equals(value) && !"false".equals(value) && !"null".equals(value)
              ? value
              : "arg" + (i + 1);
      result.add(new almlk.QuickFix.Param(type, name));
    }
    return result;
  }

  /** Return type for a generated method: the declared type when the call initializes one. */
  public static String inferReturnType(String source, int callStart) {
    int statementStart = Math.max(source.lastIndexOf(';', callStart - 1), source.lastIndexOf('{', callStart - 1)) + 1;
    String prefix = source.substring(statementStart, callStart);
    Matcher declaration =
        Pattern.compile("\\b([A-Z][A-Za-z0-9_$<>?., \\t\\[\\]]*|boolean|byte|short|int|long|float|double|char)\\s+[A-Za-z_$][A-Za-z0-9_$]*\\s*=\\s*$")
            .matcher(prefix);
    return declaration.find() ? declaration.group(1).trim() : "void";
  }

  /** Comment/string blanking with identical offsets (public for the semantic checker). */
  public static String maskSource(String source) {
    return mask(source == null ? "" : source);
  }

  /** Builds a small in-memory symbol snapshot for the currently open file. */
  public static List<DefinitionTarget> extractSourceSymbols(
      String fileName, String reference, String source) {
    String code = mask(source == null ? "" : source);
    ArrayList<DefinitionTarget> output = new ArrayList<>();
    HashSet<String> seen = new HashSet<>();
    ArrayList<String> owners = new ArrayList<>();
    LinkedHashMap<String, Integer> ownerOffsets = new LinkedHashMap<>();
    Matcher classes = CLASS_PATTERN.matcher(code);
    while (classes.find()) {
      owners.add(classes.group(1));
      ownerOffsets.put(classes.group(1), classes.start(1));
    }
    if (owners.isEmpty() && fileName != null && fileName.endsWith(".java")) {
      String inferred = fileName.substring(0, fileName.length() - 5);
      owners.add(inferred);
      ownerOffsets.put(inferred, 0);
    }
    for (String owner : owners)
      output.add(new DefinitionTarget(fileName, owner, owner, null,
          ownerOffsets.getOrDefault(owner, 0), false, reference, DefinitionTarget.KIND_CLASS));

    Matcher methods = METHOD_PATTERN.matcher(code);
    while (methods.find()) {
      String owner = owners.isEmpty() ? "" : owners.get(0);
      addSourceSymbol(output, seen, fileName, reference, owner, methods.group(2),
          methods.start(2), DefinitionTarget.KIND_METHOD);
    }
    Matcher fields = FIELD_PATTERN.matcher(code);
    while (fields.find()) {
      String owner = owners.isEmpty() ? "" : owners.get(0);
      addSourceSymbol(output, seen, fileName, reference, owner, fields.group(2),
          fields.start(2), DefinitionTarget.KIND_FIELD);
    }
    output.sort((a, b) -> {
      int aOffset = a.offset, bOffset = b.offset;
      if (aOffset != bOffset) return Integer.compare(aOffset, bOffset);
      return (a.className + "." + a.symbol).compareToIgnoreCase(b.className + "." + b.symbol);
    });
    return output;
  }

  private static void addSourceSymbol(
      List<DefinitionTarget> output, Set<String> seen, String file, String reference,
      String owner, String symbol, int offset, int kind) {
    String key = owner + "." + symbol + "|" + offset;
    if (seen.add(key))
      output.add(new DefinitionTarget(file, owner, symbol, null, offset, false, reference, kind));
  }

  /** Filters an already parsed symbol snapshot without rescanning source text. */
  public static List<DefinitionTarget> filterSymbols(
      List<DefinitionTarget> symbols, String query, int maxResults) {
    String wanted = query == null ? "" : query.trim();
    if (symbols == null || wanted.isEmpty()) return Collections.emptyList();
    ArrayList<DefinitionTarget> result = new ArrayList<>();
    for (DefinitionTarget target : symbols) {
      if (target == null) continue;
      if (symbolScore(target, wanted) != Integer.MAX_VALUE) result.add(target);
    }
    sortSymbols(result, wanted);
    int limit = Math.max(1, Math.min(500, maxResults));
    return result.size() > limit ? new ArrayList<>(result.subList(0, limit)) : result;
  }

  private static void sortSymbols(List<DefinitionTarget> symbols, String query) {
    symbols.sort((a, b) -> {
      int aScore = symbolScore(a, query), bScore = symbolScore(b, query);
      if (aScore != bScore) return Integer.compare(aScore, bScore);
      if (a.system != b.system) return a.system ? 1 : -1;
      String aName = a.className + "." + a.symbol;
      String bName = b.className + "." + b.symbol;
      return aName.compareToIgnoreCase(bName);
    });
  }

  /**
   * Searches indexed classes, methods, and fields for the Go To Element palette. Results are
   * ranked by exact/prefix/camel-case/subsequence score and keep their source offsets, so opening
   * a result never requires another full-project scan.
   */
  public static synchronized List<DefinitionTarget> searchSymbols(String query, int maxResults) {
    return searchSymbols(query, maxResults, true);
  }

  public static synchronized List<DefinitionTarget> searchSymbols(
      String query, int maxResults, boolean includeSystem) {
    String wanted = query == null ? "" : query.trim();
    if (wanted.isEmpty()) return Collections.emptyList();
    int limit = Math.max(1, Math.min(500, maxResults));
    ArrayList<DefinitionTarget> results = new ArrayList<>();
    HashSet<String> seen = new HashSet<>();
    for (Map.Entry<String, String> entry : CLASS_FILES.entrySet()) {
      addSymbolResult(results, seen, entry.getKey(), entry.getKey(), entry.getValue(),
          CLASS_OFFSETS.getOrDefault(entry.getKey(), 0), false, wanted,
          DefinitionTarget.KIND_CLASS);
    }
    if (includeSystem) {
      for (String className : METHODS.keySet()) {
        if (CLASS_FILES.containsKey(className)) continue;
        addSymbolResult(results, seen, className, className, null,
            CLASS_OFFSETS.getOrDefault(className, 0), true, wanted,
            DefinitionTarget.KIND_CLASS);
      }
    }
    for (Map.Entry<String, LinkedHashMap<String, Integer>> entry : METHOD_OFFSETS.entrySet()) {
      String owner = entry.getKey();
      String file = CLASS_FILES.get(owner);
      for (Map.Entry<String, Integer> method : entry.getValue().entrySet())
        addSymbolResult(results, seen, owner, method.getKey(), file, method.getValue(), false,
            wanted, DefinitionTarget.KIND_METHOD);
    }
    for (Map.Entry<String, LinkedHashMap<String, Integer>> entry : FIELD_OFFSETS.entrySet()) {
      String owner = entry.getKey();
      String file = CLASS_FILES.get(owner);
      for (Map.Entry<String, Integer> field : entry.getValue().entrySet())
        addSymbolResult(results, seen, owner, field.getKey(), file, field.getValue(), false,
            wanted, DefinitionTarget.KIND_FIELD);
    }
    sortSymbols(results, wanted);
    return results.size() > limit ? new ArrayList<>(results.subList(0, limit)) : results;
  }

  private static void addSymbolResult(
      List<DefinitionTarget> output,
      Set<String> seen,
      String owner,
      String symbol,
      String file,
      int offset,
      boolean system,
      String query,
      int kind) {
    String qualified = owner == null || owner.isEmpty() ? symbol : owner + "." + symbol;
    if (matchScore(symbol, query) == Integer.MAX_VALUE
        && matchScore(qualified, query) == Integer.MAX_VALUE) return;
    String key = qualified + "|" + (file == null ? "system" : file) + "|" + offset;
    if (!seen.add(key)) return;
    if (system) {
      DefinitionTarget target = targetFor(owner, symbol);
      if (target != null) output.add(target);
    } else {
      output.add(new DefinitionTarget(
          file, owner, symbol, null, offset, false, CLASS_REFERENCES.get(owner), kind));
    }
  }

  private static int symbolScore(DefinitionTarget target, String query) {
    int symbol = matchScore(target.symbol, query);
    int qualified = matchScore(target.className + "." + target.symbol, query);
    return Math.min(symbol, qualified);
  }

  public static final class DefinitionTarget {
    /** نوع الرمز — لعرض أيقونة GoTo و«()» للدوال كما في المرجع. */
    public static final int KIND_OTHER = 0, KIND_CLASS = 1, KIND_METHOD = 2, KIND_FIELD = 3;

    public final String fileName, className, symbol, source, reference;
    public final int offset;
    public final boolean system;
    public final int kind;

    public DefinitionTarget(
        String file, String owner, String selected, String virtualSource, int at, boolean builtIn) {
      this(file, owner, selected, virtualSource, at, builtIn, null, KIND_OTHER);
    }

    public DefinitionTarget(
        String file,
        String owner,
        String selected,
        String virtualSource,
        int at,
        boolean builtIn,
        String stableReference) {
      this(file, owner, selected, virtualSource, at, builtIn, stableReference, KIND_OTHER);
    }

    public DefinitionTarget(
        String file,
        String owner,
        String selected,
        String virtualSource,
        int at,
        boolean builtIn,
        String stableReference,
        int symbolKind) {
      fileName = file;
      className = owner;
      symbol = selected;
      source = virtualSource;
      offset = Math.max(0, at);
      system = builtIn;
      reference = stableReference == null ? "" : stableReference;
      kind = symbolKind;
    }
  }

  public static synchronized DefinitionTarget resolveDefinition(
      String fileName, String source, int selectionStart, int selectionEnd) {
    int start = Math.max(0, Math.min(selectionStart, source.length()));
    int end = Math.max(start, Math.min(selectionEnd, source.length()));
    while (start < end && !Character.isJavaIdentifierStart(source.charAt(start))) start++;
    while (end > start && !Character.isJavaIdentifierPart(source.charAt(end - 1))) end--;
    if (start >= end) return null;
    String symbol = source.substring(start, end);
    String code = mask(source);
    definitionImports = importsOf(code);

    int dot = start - 1;
    while (dot >= 0 && Character.isWhitespace(source.charAt(dot))) dot--;
    if (dot >= 0 && source.charAt(dot) == '.') {
      int receiverEnd = dot, receiverStart = receiverEnd;
      while (receiverStart > 0
          && Character.isJavaIdentifierPart(source.charAt(receiverStart - 1))) receiverStart--;
      String receiver = source.substring(receiverStart, receiverEnd);
      String type = variableTypes(code).get(receiver);
      if (type == null
          && (METHODS.containsKey(simpleType(receiver))
              || CLASS_FILES.containsKey(simpleType(receiver))
              || almlk.LibraryClassSource.libraryClass(receiver, definitionImports) != null
              || SystemApiSourceProvider.canResolveType(receiver))) type = receiver;
      if (type != null) return targetFor(type, symbol);
    }

    // اسم صنف من مكتبة منزّلة (تصريح/استيراد/new/تحويل): يُحل باستيرادات الملف قبل البحث عن تصريح
    // محلي، وإلا التقط نمط التصريح «private DrawerLayout» فبقي الانتقال في الملف نفسه.
    if (!CLASS_FILES.containsKey(symbol) && Character.isUpperCase(symbol.charAt(0))) {
      DefinitionTarget library = libraryTypeTarget(symbol);
      if (library != null) return library;
    }

    Matcher local = VARIABLE_PATTERN.matcher(code);
    int nearest = -1;
    while (local.find()) {
      if (local.group(2).equals(symbol) && local.start(2) != start && local.start(2) <= start)
        nearest = local.start(2);
    }
    if (nearest < 0) {
      Matcher declaration =
          Pattern.compile(
                  "\\b(?:byte|short|int|long|float|double|boolean|char|var|[A-Za-z_$][A-Za-z0-9_$<>?,.\\[\\]]*)\\s+"
                      + Pattern.quote(symbol)
                      + "\\b")
              .matcher(code);
      while (declaration.find() && declaration.start() <= start)
        nearest = declaration.end() - symbol.length();
    }
    if (nearest >= 0) {
      int kind = declarationKindAt(code, symbol, nearest);
      return new DefinitionTarget(fileName, "", symbol, null, nearest, false, null, kind);
    }

    if (METHODS.containsKey(simpleType(symbol))) return targetFor(symbol, symbol);
    Matcher owner = CLASS_PATTERN.matcher(code);
    if (owner.find()) {
      DefinitionTarget target = targetFor(owner.group(1), symbol);
      if (target != null) return target;
    }
    return null;
  }

  private static int declarationKindAt(String code, String symbol, int offset) {
    Matcher classes = CLASS_PATTERN.matcher(code);
    while (classes.find())
      if (classes.start(1) == offset && classes.group(1).equals(symbol))
        return DefinitionTarget.KIND_CLASS;
    Matcher methods = METHOD_PATTERN.matcher(code);
    while (methods.find())
      if (methods.start(2) == offset && methods.group(2).equals(symbol))
        return DefinitionTarget.KIND_METHOD;
    Matcher fields = FIELD_PATTERN.matcher(code);
    while (fields.find())
      if (fields.start(2) == offset
          && fields.group(2).equals(symbol)
          && isClassMemberDeclaration(code, offset)) return DefinitionTarget.KIND_FIELD;
    return DefinitionTarget.KIND_OTHER;
  }

  private static boolean isClassMemberDeclaration(String code, int offset) {
    Matcher classes = CLASS_PATTERN.matcher(code);
    int latestClass = -1;
    int classBodyDepth = -1;
    while (classes.find() && classes.end(1) <= offset) {
      int open = code.indexOf('{', classes.end(1));
      if (open < 0 || open >= offset) continue;
      int depth = 0;
      int close = -1;
      for (int i = open; i < code.length(); i++) {
        char ch = code.charAt(i);
        if (ch == '{') depth++;
        else if (ch == '}' && --depth == 0) {
          close = i;
          break;
        }
      }
      if (close >= 0 && offset > close) continue;
      if (classes.start(1) > latestClass) {
        latestClass = classes.start(1);
        int baseDepth = 0;
        for (int i = 0; i < open; i++) {
          if (code.charAt(i) == '{') baseDepth++;
          else if (code.charAt(i) == '}') baseDepth--;
        }
        classBodyDepth = baseDepth + 1;
      }
    }
    if (classBodyDepth < 0) return false;
    int currentDepth = 0;
    for (int i = 0; i < offset; i++) {
      if (code.charAt(i) == '{') currentDepth++;
      else if (code.charAt(i) == '}') currentDepth--;
    }
    return currentDepth == classBodyDepth;
  }

  /**
   * Returns true only when the explicit selection is on the declaration that resolution found.
   * Go To uses this distinction for methods and fields: a declaration opens its usage list, while
   * a reference navigates to the declaration. Matching the file and exact identifier offset avoids
   * classifying calls or same-named symbols in another source file as declarations.
   */
  public static boolean isDefinitionSelection(
      String fileName,
      String source,
      int selectionStart,
      int selectionEnd,
      DefinitionTarget target) {
    if (fileName == null
        || source == null
        || target == null
        || target.system
        || target.source != null
        || (target.kind != DefinitionTarget.KIND_METHOD
            && target.kind != DefinitionTarget.KIND_FIELD)
        || target.fileName == null
        || !fileName.equals(target.fileName)
        || target.symbol == null
        || target.symbol.isEmpty()) return false;
    String lower = fileName.toLowerCase(Locale.US);
    if (!(lower.endsWith(".java") || lower.endsWith(".kt"))) return false;
    int from = Math.max(0, Math.min(Math.min(selectionStart, selectionEnd), source.length()));
    int to = Math.max(0, Math.min(Math.max(selectionStart, selectionEnd), source.length()));
    if (from == to) return false;
    while (from > 0 && Character.isJavaIdentifierPart(source.charAt(from - 1))) from--;
    while (to < source.length() && Character.isJavaIdentifierPart(source.charAt(to))) to++;
    int targetEnd = target.offset + target.symbol.length();
    return target.offset >= from
        && targetEnd <= to
        && source.regionMatches(target.offset, target.symbol, 0, target.symbol.length())
        && (target.offset == 0
            || !Character.isJavaIdentifierPart(source.charAt(target.offset - 1)))
        && (targetEnd == source.length()
            || !Character.isJavaIdentifierPart(source.charAt(targetEnd)));
  }

  private static DefinitionTarget targetFor(String requestedType, String symbol) {
    String type = simpleType(requestedType);
    String current = type;
    HashSet<String> visited = new HashSet<>();
    while (!current.isEmpty() && visited.add(current)) {
      if (symbol.equals(current) || symbol.equals(type)) {
        String file = CLASS_FILES.get(current);
        if (file != null)
          return new DefinitionTarget(
              file, current, symbol, null, CLASS_OFFSETS.getOrDefault(current, 0), false,
              CLASS_REFERENCES.get(current), DefinitionTarget.KIND_CLASS);
        if (!CLASS_FILES.containsKey(current)) {
          DefinitionTarget libraryClass = libraryTypeTarget(current);
          if (libraryClass != null) return libraryClass;
          DefinitionTarget platformClass = SystemApiSourceProvider.resolveType(current);
          if (platformClass != null) return platformClass;
        }
      }
      LinkedHashMap<String, Integer> methods = METHOD_OFFSETS.get(current);
      if (methods != null && methods.containsKey(symbol))
        return new DefinitionTarget(
            CLASS_FILES.get(current), current, symbol, null, methods.get(symbol), false,
            CLASS_REFERENCES.get(current), DefinitionTarget.KIND_METHOD);
      LinkedHashMap<String, Integer> fields = FIELD_OFFSETS.get(current);
      if (fields != null && fields.containsKey(symbol))
        return new DefinitionTarget(
            CLASS_FILES.get(current), current, symbol, null, fields.get(symbol), false,
            CLASS_REFERENCES.get(current), DefinitionTarget.KIND_FIELD);
      if (!CLASS_FILES.containsKey(current)) {
        DefinitionTarget libraryMember = libraryMemberTarget(current, symbol);
        if (libraryMember != null) return libraryMember;
        DefinitionTarget platformMember = SystemApiSourceProvider.resolveMember(current, symbol);
        if (platformMember != null) return platformMember;
      }
      current = PARENTS.getOrDefault(current, "");
    }
    DefinitionTarget platformMember = SystemApiSourceProvider.resolveMember(type, symbol);
    if (platformMember != null) return platformMember;
    if (!METHODS.containsKey(type)) return null;
    String virtual = systemSource(type);
    int offset = virtual.indexOf(" " + symbol + "(");
    if (offset >= 0) offset++;
    else {
      offset = virtual.indexOf(" " + symbol + ";");
      if (offset >= 0) offset++;
      else offset = Math.max(0, virtual.indexOf("class " + type) + 6);
    }
    return new DefinitionTarget(type + ".class", type, symbol, virtual, offset, true);
  }

  /** استيرادات الملف الذي طُلب منه الانتقال (لحلّ أسماء أصناف المكتبات بسياقه). */
  private static List<String> definitionImports = Collections.emptyList();

  /** صنف مكتبة منزّلة ← تبويب عرض للقراءة من فهرس المكتبات (نسخة المشروع لا نسخة تطبيقنا). */
  private static DefinitionTarget libraryTypeTarget(String type) {
    almlk.AndroidApiIndex.ClassInfo info = almlk.LibraryClassSource.libraryClass(type, definitionImports);
    almlk.LibraryClassSource source = almlk.LibraryClassSource.of(info);
    if (source == null) return null;
    return new DefinitionTarget(source.fileName, source.simpleName, source.simpleName, source.text,
        source.classOffset, true, null, DefinitionTarget.KIND_CLASS);
  }

  /**
   * عضو على صنف مكتبة: أقرب صنف مكتبة يعلنه في سلسلة الوراثة؛ وإن أعلنه صنف منصة (DrawerLayout ←
   * ViewGroup) يكمل مسار المنصة من أول صنف منصة في السلسلة.
   */
  private static DefinitionTarget libraryMemberTarget(String type, String symbol) {
    almlk.AndroidApiIndex.ClassInfo info = almlk.LibraryClassSource.libraryClass(type, definitionImports);
    if (info == null) return null;
    String[] platformOwner = new String[1];
    almlk.LibraryClassSource.MemberHit hit = almlk.LibraryClassSource.declaringMember(info, symbol, platformOwner);
    if (hit != null)
      return new DefinitionTarget(hit.source.fileName, hit.source.simpleName, symbol, hit.source.text,
          hit.offset, true, null, hit.field ? DefinitionTarget.KIND_FIELD : DefinitionTarget.KIND_METHOD);
    return platformOwner[0] == null ? null : SystemApiSourceProvider.resolveMember(platformOwner[0], symbol);
  }

  /** Source for a virtual system-class tab when restoring a metadata-only editor session. */
  public static synchronized String systemSourceForFile(String fileName) {
    almlk.LibraryClassSource library = almlk.LibraryClassSource.forFileName(fileName);
    if (library != null) return library.text;
    String source = SystemApiSourceProvider.sourceForFileName(fileName);
    if (source != null) return source;
    if (fileName == null) return null;
    String normalized = fileName.replace('\\', '/');
    if (!normalized.toLowerCase(Locale.US).endsWith(".class")) return null;
    String simple = normalized.substring(normalized.lastIndexOf('/') + 1,
        normalized.length() - ".class".length());
    return METHODS.containsKey(simple) ? systemSource(simple) : null;
  }

  private static String systemSource(String type) {
    StringBuilder out = new StringBuilder();
    // بند 2 — كلاسات النظام تعرض باسم الكلاس نفسه (ArrayList.class) لا بوسم «نظام».
    out.append("// ").append(type).append(".class — عرض للقراءة فقط\npublic class ")
        .append(type);
    String parent = PARENTS.get(type);
    if (parent != null && !parent.isEmpty()) out.append(" extends ").append(parent);
    out.append(" {");
    LinkedHashMap<String, String> fields = CLASS_FIELDS.get(type);
    if (fields != null)
      for (Map.Entry<String, String> field : fields.entrySet())
        out.append("\n    public ").append(field.getValue()).append(' ')
            .append(field.getKey()).append(';');
    LinkedHashMap<String, String> returns = METHOD_RETURNS.get(type);
    LinkedHashMap<String, String> parameters = METHOD_PARAMETERS.get(type);
    if (returns != null)
      for (Map.Entry<String, String> method : returns.entrySet())
        out.append("\n    public ").append(method.getValue()).append(' ')
            .append(method.getKey()).append('(')
            .append(parameters == null ? "" : parameters.getOrDefault(method.getKey(), ""))
            .append(") { } ");
    out.append("\n}\n");
    return out.toString();
  }

  private static Map<String, String> variableTypes(String code) {
    HashMap<String, String> values = new HashMap<>();
    Matcher variables = VARIABLE_PATTERN.matcher(code);
    while (variables.find()) values.put(variables.group(2), simpleType(variables.group(1)));
    Matcher creations = CREATION_PATTERN.matcher(code);
    while (creations.find()) values.put(creations.group(1), simpleType(creations.group(2)));
    Matcher casts = CAST_PATTERN.matcher(code);
    while (casts.find()) values.put(casts.group(1), simpleType(casts.group(2)));
    return values;
  }

  private static List<String> splitArguments(String text) {
    ArrayList<String> parts = new ArrayList<>();
    int start = 0, round = 0, square = 0, curly = 0;
    char quote = 0;
    boolean escape = false;
    for (int i = 0; i < text.length(); i++) {
      char c = text.charAt(i);
      if (quote != 0) {
        if (escape) escape = false;
        else if (c == '\\') escape = true;
        else if (c == quote) quote = 0;
      } else if (c == '"' || c == '\'') quote = c;
      else if (c == '(') round++;
      else if (c == ')') round--;
      else if (c == '[') square++;
      else if (c == ']') square--;
      else if (c == '{') curly++;
      else if (c == '}') curly--;
      else if (c == ',' && round == 0 && square == 0 && curly == 0) {
        parts.add(text.substring(start, i));
        start = i + 1;
      }
    }
    if (start < text.length()) parts.add(text.substring(start));
    return parts;
  }

  private static int matchingParenthesis(String text, int open) {
    return matchingParenthesis(text, open, text.length());
  }

  /** Variant that stops scanning after {@code scanLimit} characters so callers bounding
   *  their memory do not pay an unbounded scan cost on pathological sources. */
  private static int matchingParenthesis(String text, int open, int scanLimit) {
    int depth = 0;
    char quote = 0;
    boolean escape = false;
    int endLimit = Math.min(text.length(), open + Math.max(0, scanLimit));
    for (int i = open; i < endLimit; i++) {
      char c = text.charAt(i);
      if (quote != 0) {
        if (escape) escape = false;
        else if (c == '\\') escape = true;
        else if (c == quote) quote = 0;
      } else if (c == '"' || c == '\'') quote = c;
      else if (c == '(') depth++;
      else if (c == ')' && --depth == 0) return i;
    }
    return -1;
  }

  private static int[] positionAt(String source, int offset) {
    int line = 1, column = 1;
    for (int i = 0; i < offset; i++) {
      if (source.charAt(i) == '\n') {
        line++;
        column = 1;
      } else column++;
    }
    return new int[] {line, column};
  }

  private static String packageName(String code) {
    Matcher matcher = Pattern.compile(
        "(?m)^\\s*package\\s+([A-Za-z_$][A-Za-z0-9_$.]*)\\s*;").matcher(code);
    return matcher.find() ? matcher.group(1) : "";
  }

  /**
   * Records a field's type. One name seen with two different types (a nested class's field, or a
   * line-leading constructor parameter that looks like a field) gets an empty, i.e. unknown, type:
   * a chain through it then resolves to nothing instead of to the wrong class.
   */
  private static void putFieldType(Map<String, String> fields, String name, String type) {
    String previous = fields.get(name);
    if (previous == null) fields.put(name, type);
    else if (!previous.equals(type)) fields.put(name, "");
  }

  private static String simpleType(String type) {
    String value = type == null ? "" : type.trim();
    int generic = value.indexOf('<');
    if (generic >= 0) value = value.substring(0, generic);
    while (value.endsWith("[]")) value = value.substring(0, value.length() - 2);
    int dot = value.lastIndexOf('.');
    return dot >= 0 ? value.substring(dot + 1) : value;
  }

  private static String mask(String source) {
    StringBuilder out = new StringBuilder(source);
    boolean line = false, block = false, escape = false, textBlock = false;
    char quote = 0;
    for (int i = 0; i < source.length(); i++) {
      char c = source.charAt(i), next = i + 1 < source.length() ? source.charAt(i + 1) : 0;
      if (c == '\n') {
        line = false;
        escape = false;
        continue;
      }
      if (line) out.setCharAt(i, ' ');
      else if (block) {
        out.setCharAt(i, ' ');
        if (c == '*' && next == '/') {
          out.setCharAt(++i, ' ');
          block = false;
        }
      } else if (textBlock) {
        if (c == '"'
            && i + 2 < source.length()
            && source.charAt(i + 1) == '"'
            && source.charAt(i + 2) == '"'
            && !isEscaped(source, i)) {
          out.setCharAt(i, ' ');
          out.setCharAt(i + 1, ' ');
          out.setCharAt(i + 2, ' ');
          i += 2;
          textBlock = false;
        } else out.setCharAt(i, ' ');
      } else if (quote != 0) {
        out.setCharAt(i, ' ');
        if (escape) escape = false;
        else if (c == '\\') escape = true;
        else if (c == quote) quote = 0;
      } else if (c == '/' && next == '/') {
        out.setCharAt(i, ' ');
        out.setCharAt(++i, ' ');
        line = true;
      } else if (c == '/' && next == '*') {
        out.setCharAt(i, ' ');
        out.setCharAt(++i, ' ');
        block = true;
      } else if (c == '"'
          && i + 2 < source.length()
          && source.charAt(i + 1) == '"'
          && source.charAt(i + 2) == '"') {
        out.setCharAt(i, ' ');
        out.setCharAt(i + 1, ' ');
        out.setCharAt(i + 2, ' ');
        i += 2;
        textBlock = true;
      } else if (c == '"' || c == '\'' || c == '`') {
        out.setCharAt(i, ' ');
        quote = c;
      }
    }
    return out.toString();
  }

  private static boolean isEscaped(String source, int offset) {
    int backslashes = 0;
    for (int i = offset - 1; i >= 0 && source.charAt(i) == '\\'; i--) backslashes++;
    return (backslashes & 1) != 0;
  }

  public static final class CompletionItem {
    /**
     * Row kinds, rendered like the reference: METHOD = red cube, VARIABLE (fields, locals, XML
     * attributes) = blue cube, CLASS (classes, XML elements) = shapes, PACKAGE = package icon,
     * KEYWORD and VALUE = no icon (keywords/values in bold).
     */
    public static final int METHOD = 0, VARIABLE = 1, CLASS = 2, XML = 3, BUILD = 4, KEYWORD = 5,
        PACKAGE = 6, VALUE = 7;
    public final int kind;
    public final String label, insertText, detail;
    /** Light icon variant: inherited member, or a class that still needs an import. */
    public boolean secondary;
    /** Grey text after the name, e.g. "(Object obj) : boolean", " : String", " - android.content". */
    public String suffix;
    /** Grey second line, e.g. "Added in API level 8"; empty when none. */
    public String apiInfo = "";
    /** Struck-through name: the API was removed. */
    public boolean removed;
    /**
     * Fully qualified classes imported when the row is committed (null/empty = none). 1.0.189: a
     * list, because a generated override can carry three parameter types and none of them may be
     * left un-imported — the row states all of them and the editor writes them in one edit.
     */
    public java.util.List<String> importNames;
    /** Caret position counted back from the end of the inserted text (-1 = default rule). */
    public int caretBack = -1;
    /** Reopen the popup after committing (attribute → its values, package → its classes). */
    public boolean reopen;

    public CompletionItem(int kind, String label, String insertText, String detail) {
      this.kind = kind;
      this.label = label;
      this.insertText = insertText;
      this.detail = detail;
      this.suffix = detail == null || detail.isEmpty() ? "" : " : " + detail;
    }
  }
}
