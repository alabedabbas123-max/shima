package com.shima.editor.core;

import java.util.ArrayList;
import java.util.List;

/** Piece-table text storage. Edits append to the add buffer and splice small piece descriptors. */
public final class PieceTableDocument implements TextDocument {
  private final String uri;
  private final String original;
  private final StringBuilder additions = new StringBuilder();
  private final ArrayList<Piece> pieces = new ArrayList<>();
  private final LineIndex lineIndex;
  private final boolean readOnly;
  private long version;

  public PieceTableDocument(String uri, CharSequence initial) {
    this(uri, initial, false);
  }

  public PieceTableDocument(String uri, CharSequence initial, boolean readOnly) {
    this.uri = uri == null ? "" : uri;
    this.original = initial == null ? "" : initial.toString();
    this.readOnly = readOnly;
    if (!original.isEmpty()) pieces.add(new Piece(false, 0, original.length()));
    lineIndex = new LineIndex(original);
  }

  @Override
  public synchronized String uri() {
    return uri;
  }

  @Override
  public synchronized long length() {
    long result = 0L;
    for (Piece piece : pieces) result += piece.length;
    return result;
  }

  @Override
  public synchronized CharSequence readRange(long start, long end) {
    int size = (int) length();
    int from = clamp(start, size);
    int to = clamp(end, size);
    if (to < from) to = from;
    StringBuilder result = new StringBuilder(to - from);
    int cursor = 0;
    for (Piece piece : pieces) {
      int pieceEnd = cursor + piece.length;
      if (pieceEnd <= from) {
        cursor = pieceEnd;
        continue;
      }
      if (cursor >= to) break;
      int localStart = Math.max(0, from - cursor);
      int localEnd = Math.min(piece.length, to - cursor);
      if (localEnd > localStart) result.append(textOf(piece, localStart, localEnd));
      cursor = pieceEnd;
    }
    return result.toString();
  }

  @Override
  public synchronized String snapshot() {
    return readRange(0, length()).toString();
  }

  @Override
  public synchronized void insert(long offset, CharSequence text) {
    replace(offset, offset, text);
  }

  @Override
  public synchronized void delete(long start, long end) {
    replace(start, end, "");
  }

  @Override
  public synchronized void replace(long start, long end, CharSequence text) {
    ensureWritable();
    int size = (int) length();
    int from = clamp(start, size);
    int to = clamp(end, size);
    if (to < from) {
      int swap = from;
      from = to;
      to = swap;
    }
    String inserted = text == null ? "" : text.toString();
    if (from == to && inserted.isEmpty()) return;
    int first = splitAt(from);
    int last = splitAt(to);
    if (last > first) pieces.subList(first, last).clear();
    if (!inserted.isEmpty()) {
      int addStart = additions.length();
      additions.append(inserted);
      pieces.add(first, new Piece(true, addStart, inserted.length()));
    }
    mergeAdjacent();
    lineIndex.replace(from, to - from, inserted);
    version++;
  }

  /** Used by undo/redo so reversing a command does not create a second command. */
  public synchronized void replaceWithoutHistory(long start, long end, CharSequence text) {
    replace(start, end, text);
  }

  @Override
  public synchronized int lineOf(long offset) {
    return lineIndex.lineOf(offset);
  }

  @Override
  public synchronized long offsetOfLine(int line) {
    return lineIndex.offsetOfLine(line);
  }

  @Override
  public synchronized int lineCount() {
    return lineIndex.lineCount();
  }

  @Override
  public synchronized long version() {
    return version;
  }

  @Override
  public boolean isReadOnly() {
    return readOnly;
  }

  public synchronized long[] lineStarts() {
    return lineIndex.snapshot();
  }

  public synchronized List<String> pieces() {
    ArrayList<String> values = new ArrayList<>();
    for (Piece piece : pieces) values.add(textOf(piece, 0, piece.length));
    return values;
  }

  private int splitAt(int offset) {
    int cursor = 0;
    for (int i = 0; i < pieces.size(); i++) {
      Piece piece = pieces.get(i);
      if (offset == cursor) return i;
      if (offset < cursor + piece.length) {
        int leftLength = offset - cursor;
        int rightLength = piece.length - leftLength;
        pieces.set(i, new Piece(piece.add, piece.start, leftLength));
        pieces.add(i + 1, new Piece(piece.add, piece.start + leftLength, rightLength));
        return i + 1;
      }
      cursor += piece.length;
    }
    return pieces.size();
  }

  private void mergeAdjacent() {
    for (int i = pieces.size() - 1; i > 0; i--) {
      Piece left = pieces.get(i - 1);
      Piece right = pieces.get(i);
      if (left.add == right.add && left.start + left.length == right.start) {
        pieces.set(i - 1, new Piece(left.add, left.start, left.length + right.length));
        pieces.remove(i);
      }
    }
  }

  private String textOf(Piece piece, int from, int to) {
    CharSequence source = piece.add ? additions : original;
    return source.subSequence(piece.start + from, piece.start + to).toString();
  }

  private int clamp(long value, int size) {
    return (int) Math.max(0L, Math.min((long) size, value));
  }

  private void ensureWritable() {
    if (readOnly) throw new IllegalStateException("المستند للقراءة فقط");
  }

  private static final class Piece {
    final boolean add;
    final int start;
    final int length;

    Piece(boolean add, int start, int length) {
      this.add = add;
      this.start = start;
      this.length = length;
    }
  }
}
