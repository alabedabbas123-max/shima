package com.shima.demo;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;

/**
 * Activity base that applies the saved app locale before Android creates its views, and the chrome
 * style of the selected editor palette as soon as the window exists.
 *
 * <p><b>لمَ اللغةُ في {@code attachBaseContext} والثيمُ في {@code onCreate}؟</b> لأنَّ
 * {@code Activity.setTheme} يكتبُ في {@code mWindow}، و{@code Activity.attach} يُنادي
 * {@code attachBaseContext} ثمَّ يسنُدُ {@code mWindow} بعدَهُ — فأيُّ تثبيتِ ثيمٍ في الموضعِ
 * الأوّلِ انهيارٌ على «Window.setTheme(int) on a null object reference» عندَ أولِ سطرٍ من عُمرِ
 * النشاط: علّةُ 1.0.142 التي أُغلِقَ بها التطبيقُ عندَ اختيارِ ثيمٍ فاتحٍ ثمَّ عُلِّقَ في كلِّ تشغيلٍ
 * بعدَهُ، لأنَّ النمطَ محفوظٌ في التفضيلاتِ فالانهيارُ يسبقُ أيَّ شاشةٍ تُصلِحُهُ. اللغةُ وحدَها تصلحُ
 * هناك لأنَّها تُمرَّرُ في الـ{@code Context} نفسِهِ لا في النافذة.
 *
 * <p>أمّا في {@code onCreate} وقبلَ {@code super.onCreate} فالنافذةُ موجودةٌ والديكورُ لم يُولَدْ:
 * يُطبَّقُ النمطُ قبلَ تضخيمِ أيِّ سطرٍ فلا وميضَ ولا شاشةَ وسيطة — وهو نفسُ ما يفعلُهُ
 * {@code SystemResourcesActivity} بثيمِهِ المُعايَن.
 *
 * <p><b>ولمَ الفاتحُ والداكنُ معًا هنا لا الفاتحُ وحدَه؟</b> لأنَّ 1.0.143 كانَ يُبدِّلُ النمطَ اختيارًا
 * على كلِّ نشاطٍ بمفرده، فأعلنَهُ نشاطانِ من عشرةٍ فقط — وبقيتْ بقيّةُ الشاشاتِ (ومنها شاشةُ الإعداداتِ
 * التي تُختارُ منها اللوحة) على ما في المانيفستِ من نمطٍ داكنٍ واحد: لا الشريطُ ولا نصُّهُ ولا قوائمُهُ ولا
 * دايلوغاتُهُ تتحرّكُ مع الثيم. القرارُ الآنَ لكلِّ نشاطٍ في {@code almlk.ChromeTheme}، ومن لهُ نمطُهُ
 * الخاصُّ يُسقِطُ الإلزامَ بإرجاعِ صفرٍ من {@link #appChromeTheme()}.
 */
public abstract class LocaleAwareActivity extends Activity {
  private final almlk.ChromeTheme.Applied chrome = new almlk.ChromeTheme.Applied();

  @Override
  protected void attachBaseContext(Context base) {
    super.attachBaseContext(ShimaApplication.localize(base));
  }

  @Override
  protected void onCreate(Bundle state) {
    chrome.install(this, appChromeTheme());
    super.onCreate(state);
  }

  @Override
  protected void onResume() {
    super.onResume();
    chrome.follow(this);
  }

  /** نمطُ الشريطِ المفروضُ باللوحةِ المختارة؛ صفرٌ لمن لهُ نمطُهُ الخاصُّ (سبلاشٌ، إنقاذٌ، مُعاينةُ موارد، مُصمِّم). */
  protected int appChromeTheme() {
    return almlk.ChromeTheme.resolve(this);
  }
}
