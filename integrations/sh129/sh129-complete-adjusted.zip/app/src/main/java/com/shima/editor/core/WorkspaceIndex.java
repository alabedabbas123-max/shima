package com.shima.editor.core;

import java.util.List;

/** Project-wide symbol service. Implementations must call callbacks off the UI caller's stack. */
public interface WorkspaceIndex extends AutoCloseable {
  interface Callback<T> {
    void completed(T value, Throwable error);
  }

  void update(String file, CharSequence source, Callback<Boolean> callback);

  void remove(String file, Callback<Boolean> callback);

  void findDefinition(SymbolId symbol, Callback<SymbolLocation> callback);

  void findReferences(SymbolId symbol, Callback<List<SymbolLocation>> callback);

  void searchClasses(String prefix, int limit, Callback<List<SymbolId>> callback);

  @Override
  void close();
}
