package com.almlkid.kay.ui;

import com.shima.editor.core.SmaliDiagnostic;
import com.shima.editor.core.SmaliDiagnosticsEngine;
import com.shima.editor.core.SmaliToken;
import com.shima.editor.core.SmaliTokenKind;
import com.shima.editor.core.SmaliTokenizer;
import java.util.ArrayList;
import java.util.List;

/** Adapter from the editor-core Smali services to the existing Android editor span model. */
final class SmaliLanguageAdapter {
  private SmaliLanguageAdapter() {}

  static List<CodeLanguageTools.Range> highlight(String source) {
    ArrayList<CodeLanguageTools.Range> result = new ArrayList<>();
    for (SmaliToken token : SmaliTokenizer.tokenize(source))
      result.add(new CodeLanguageTools.Range(token.start, token.end, rangeType(token.kind)));
    return result;
  }

  static List<CodeLanguageTools.Diagnostic> inspect(String source) {
    ArrayList<CodeLanguageTools.Diagnostic> result = new ArrayList<>();
    for (SmaliDiagnostic item : SmaliDiagnosticsEngine.inspect(source))
      result.add(
          CodeLanguageTools.Diagnostic.localized(
              item.offset,
              item.end,
              item.line,
              item.column,
              severity(item.severity),
              item.code,
              item.messageKey,
              item.message,
              item.messageArgs));
    return result;
  }

  private static CodeLanguageTools.Diagnostic.Severity severity(SmaliDiagnostic.Severity value) {
    if (value == SmaliDiagnostic.Severity.INFO) return CodeLanguageTools.Diagnostic.Severity.INFO;
    if (value == SmaliDiagnostic.Severity.WARNING) return CodeLanguageTools.Diagnostic.Severity.WARNING;
    return CodeLanguageTools.Diagnostic.Severity.ERROR;
  }

  private static int rangeType(SmaliTokenKind kind) {
    if (kind == null) return CodeLanguageTools.IDENTIFIER;
    switch (kind) {
      case COMMENT:
        return CodeLanguageTools.COMMENT;
      case DIRECTIVE:
        return CodeLanguageTools.KEYWORD;
      case OPCODE:
        return CodeLanguageTools.FUNCTION;
      case REGISTER:
        return CodeLanguageTools.VARIABLE;
      case LABEL:
        return CodeLanguageTools.NUMBER;
      case TYPE_DESCRIPTOR:
        return CodeLanguageTools.NAMESPACE;
      case STRING:
        return CodeLanguageTools.STRING;
      case NUMBER:
        return CodeLanguageTools.NUMBER;
      case METHOD_NAME:
        return CodeLanguageTools.FUNCTION;
      case FIELD_NAME:
        return CodeLanguageTools.VARIABLE;
      case ANNOTATION:
        return CodeLanguageTools.ANNOTATION;
      case ERROR:
        return CodeLanguageTools.OPERATOR;
      default:
        return CodeLanguageTools.IDENTIFIER;
    }
  }
}
