package com.almlkid.ui;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.view.*;
import android.widget.*;
import com.almlkid.kay.ui.AlmlkEditor;
import com.almlkid.kay.ui.CodeLanguageTools;
import com.almlkid.kay.ui.EditorSearchEngine;
import com.almlkid.kay.ui.KayStyleCompletionEngine;
import com.almlkid.kay.ui.ProjectDiagnostic;
import com.almlkid.kay.ui.ProjectSymbolIndex;
import com.almlkid.kay.ui.SmaliDefinitionResolver;
import almlk.JavaImportOrganizer;
import com.shima.demo.R;
import com.shima.demo.UiStrings;
import com.shima.demo.ThemeConfig;
import com.shima.performance.EditorTextSnapshot;
import com.shima.performance.EncodingManager;
import com.shima.performance.FileSystemRepository;
import com.shima.performance.InstantSessionStore;
import com.shima.editor.core.AtomicSaveManager;
import com.shima.editor.core.SavePolicy;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Multi-tab editor with file header, line numbers and a keyboard-only quick-key bar. */
public class AIDEEditorPager extends LinearLayout {
  private static final int EXPAND_SELECTION = 0x53484D42;
  private static final int MORE_MENU = 0x53484D47;
  private static final int FIX_MENU = 0x53484D46;

  /** المرحلة 3: تنفيذ إصلاح مختار (التأكيد وتعديل الملف المستهدف عند المضيف). */
  public interface QuickFixListener {
    void applyQuickFix(almlk.QuickFix fix);
  }

  public interface SessionListener {
    void restored(boolean success);
  }

  public interface DefinitionListener {
    void requested(ProjectSymbolIndex.DefinitionTarget target);
  }

  public interface UsageListener {
    void requested(String fileName, String source, int selectionStart, int selectionEnd);
  }

  public interface DiagnosticsListener {
    void updated(String fileName, String reference, String source,
        List<CodeLanguageTools.Diagnostic> diagnostics);
  }

  public interface FileChangedListener {
    void changed(String fileName, String reference);
  }

  public interface ReplaceListener {
    void completed(int replacements);
  }

  /** مساهمة أداة اختيار حية؛ null يعني أن الأداة غير ظاهرة في السياق الحالي. */
  public interface SelectionToolContributor {
    EditorMenuRegistry.DynamicCommand contribute(EditorMenuRegistry.Context context);
  }

  public interface DefinitionRequestListener {
    void requested(String fileName, String source, int selectionStart, int selectionEnd);
  }

  private final LinkedHashMap<String, LinearLayout> tabs = new LinkedHashMap<>();
  private final LinkedHashMap<String, String> fileContents = new LinkedHashMap<>();
  // The legacy map is kept only so old sessions can be ignored safely; new sessions never write
  // source content to disk.
  private final LinkedHashMap<String, java.io.File> lazySessionFiles = new LinkedHashMap<>();
  private final LinkedHashMap<String, String> lazySessionReferences = new LinkedHashMap<>();
  private final LinkedHashMap<String, String> sessionReferences = new LinkedHashMap<>();
  private final LinkedHashMap<String, Integer> sessionCursors = new LinkedHashMap<>();
  private final LinkedHashMap<String, Integer> sessionScrollX = new LinkedHashMap<>();
  private final LinkedHashMap<String, Integer> sessionScrollY = new LinkedHashMap<>();
  private LinearLayout tabStrip;

  /** شريطُ الأدواتِ يملكُهُ النشاطُ ويسكنُ {@code mainQuickKeyBarContainer}؛ والمُحرِّرُ مُضيفُهُ. */
  private almlk.QuickKeyBar quickKeyBar;

  /**
   * يربطُ الشريطَ بالمُحرِّر: السلسلةُ تُبنى من نوعِ الملفِ النشِط، وكلُّ أداةٍ تُدرَجُ من منفذِ الكتابةِ نفسِه.
   * تُنادى مرّةً واحدةً من {@code MainActivity} بعد {@code setContentView} — لا شريطَ بغيرِ مُضيف.
   */
  public void attachQuickKeyBar(almlk.QuickKeyBar bar) {
    this.quickKeyBar = bar;
    if (bar == null) return;
    bar.setHost(new almlk.QuickKeyBar.Host() {
      @Override
      public void onQuickKeyToken(String actionToken) {
        applyQuickKeyToken(actionToken);
      }

      @Override
      public String currentFileName() {
        return activeFile;
      }
    });
    bar.rebuild();
    bar.setKeyboardVisible(keyboardVisible);
  }

  /**
   * الأداةُ المُنتقاةُ من الشريط: قرارُها في {@code QuickKeyToolPolicy} (خالصٌ مُختبَر) وتطبيقُها على الوثيقة
   * من {@code replaceRange}/{@code setSelection} — أي مسارُ الكتابةِ نفسِه، فيُسجَّلُ تراجعًا ويُحدَّثُ المُكمِّل
   * والتلوينُ كما لو كُتِبَت الحروف. والسهمُ لا يُحرّكُ المؤشّرَ بل يطلبُ إزاحةً بمنهجِ مفتاح Tab.
   */
  public void applyQuickKeyToken(String token) {
    if (code == null || token == null) return;
    almlk.QuickKeyToolPolicy.Edit edit =
        almlk.QuickKeyToolPolicy.plan(
            code.getText().toString(),
            code.getSelectionStart(),
            code.getSelectionEnd(),
            token,
            isXmlFile());
    if (edit.isIndent()) {
      code.insertTabOrSpaces();
    } else if (edit.movesCaretOnly()) {
      code.setSelection(edit.selectionStart);
    } else {
      code.replaceRange(edit.start, edit.end, edit.text);
      code.setSelection(edit.selectionStart, edit.selectionEnd);
    }
    code.requestFocus();
  }
  private View fileHeader;
  private View editorRow;
  private TextView headerName, headerPath;
  private ImageView headerIcon;
  private AlmlkEditor code;
  private String activeFile;
  private String loadingFile;
  // بند الإحلال: التراجع/الإعادة مدمجان في موديل almlk (UndoRedoStack) — لا تاريخ خارجي.
  /**
   * W27/1: حالةُ تسلِيحِ الفحصِ كما يَقرِرُها المضيفُ بملفٍّ جوهريٍّ (ملحقُ ‏W27/1). {@code false}
   * تَجعلُ كلَّ محرِّرٍ نائمًا ({@code analysisPaused}) — فالتصفُّحُ لا يُحرِّكُ المحرِّكَ ولا يَقلِبُ
   * السياقَ، والالوانُ والتلوينُ يَعمَلانِ لأنَّهُما لا يَمُرّانِ بهذهِ البوّابةِ.
   */
  private boolean analysisArmed = true;

  /**
   * يَضَعُ حالةَ التسلِيحِ ويُسقِطُها على المحرِّرِ النَّشِطِ فورًا: {@code false} تَوقِفُ الفحصَ،
   * و{@code true} تُعيدُهُ بلا إعادةِ قراءةِ نصٍّ ولا مِسكَةٍ بالمؤشِرِ والمِرناءِ.
   */
  public void setAnalysisArmed(boolean armed) {
    analysisArmed = armed;
    if (code == null) return;
    code.setAnalysisPaused(!armed);
    if (armed) code.post(code::refreshNow);
  }

  /** حالةُ التسلِيحِ الحاضرةُ (تُقرَأُ في البوّابةِ لا في قرارِ عرضٍ). */
  public boolean isAnalysisArmed() {
    return analysisArmed;
  }

  private boolean historyLocked;
  private boolean keyboardVisible;
  private QuickFixListener quickFixListener;
  private DefinitionListener definitionListener;
  private DefinitionRequestListener definitionRequestListener;
  private UsageListener usageListener;
  private DiagnosticsListener diagnosticsListener;
  private FileChangedListener fileChangedListener;
  private List<ProjectDiagnostic> projectDiagnostics = Collections.emptyList();
  private int definitionGeneration, goToGeneration;
  private final EditorMenuRegistry editorMenuRegistry = new EditorMenuRegistry();
  private final ArrayList<SelectionToolContributor> selectionToolContributors = new ArrayList<>();
  private PopupWindow completionWindow;
  private View completionList;
  private ListView completionListView;
  private EditorCompletionAdapter completionAdapter;
  private java.util.concurrent.ExecutorService completionWorker =
      java.util.concurrent.Executors.newSingleThreadExecutor();
  // Session restore/file reads use a separate lane so they never delay typing or completion.
  private java.util.concurrent.ExecutorService sessionWorker =
      java.util.concurrent.Executors.newSingleThreadExecutor();
  // Completion lookups must not queue behind session restore, file I/O, or definition requests.
  private java.util.concurrent.ExecutorService completionLookupWorker =
      java.util.concurrent.Executors.newSingleThreadExecutor();
  private FileSystemRepository fileRepository;
  private AtomicSaveManager autoSaveManager;
  private InstantSessionStore sessionStore;
  private java.util.concurrent.Future<?> autoSaveTask;
  private final Runnable autoSaveRunnable = this::queueAutoSave;
  private int completionGeneration;
  // The snapshot is updated by changed ranges on the UI thread and copied only on the worker.
  private final EditorTextSnapshot completionSnapshot = new EditorTextSnapshot();
  private final CompletionLookupCache completionCache = new CompletionLookupCache();
  private java.util.concurrent.Future<?> completionLookupFuture;
  private long lastEditorErrorTime;
  private final Runnable completionTask = this::showLiveCompletions;
  private int largestVisibleHeight;

  public AIDEEditorPager(Context c) {
    super(c);
    init();
  }

  public AIDEEditorPager(Context c, AttributeSet a) {
    super(c, a);
    init();
  }

  public AIDEEditorPager(Context c, AttributeSet a, int s) {
    super(c, a, s);
    init();
  }

  private void init() {
    // Platform knowledge for completion (SDK classes/members/API levels, XML attributes): the
    // asset is decoded once on a background thread so the first popup does not wait for it.
    final android.content.res.AssetManager completionAssets = getContext().getApplicationContext().getAssets();
    almlk.AndroidApiIndex.install(completionAssets::open);
    almlk.AndroidXMigration.install(completionAssets::open);
    almlk.AndroidApiIndex.warmUpAsync();
    fileRepository = new FileSystemRepository(getContext());
    autoSaveManager = new AtomicSaveManager(getContext());
    // Constructed from the worker below: SharedPreferences may initialize from disk once.
    setLayoutDirection(LAYOUT_DIRECTION_LTR);
    setOrientation(VERTICAL);
    setBackgroundColor(Color.BLACK);
    addTabs();
    addFileHeader();
    addEditor();
    applyTheme();
    watchKeyboard();
    setVisibility(GONE);
  }

  private void addTabs() {
    HorizontalScrollView scroll = new HorizontalScrollView(getContext());
    scroll.setHorizontalScrollBarEnabled(false);
    scroll.setFillViewport(true);
    scroll.setBackgroundColor(Color.rgb(34, 34, 34));
    tabStrip = new LinearLayout(getContext());
    tabStrip.setOrientation(HORIZONTAL);
    tabStrip.setLayoutDirection(LAYOUT_DIRECTION_LTR);
    scroll.addView(tabStrip, new HorizontalScrollView.LayoutParams(-2, -1));
    addView(scroll, new LayoutParams(-1, dp(46)));
  }

  private void addFileHeader() {
    LinearLayout header = new LinearLayout(getContext());
    header.setOrientation(HORIZONTAL);
    header.setGravity(Gravity.CENTER_VERTICAL);
    header.setPadding(dp(12), dp(5), dp(12), dp(5));
    header.setBackgroundColor(Color.BLACK);
    header.setLayoutDirection(LAYOUT_DIRECTION_LTR);
    headerIcon = new ImageView(getContext());
    headerIcon.setImageResource(R.drawable.file_type_java);
    headerIcon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
    header.addView(headerIcon, new LinearLayout.LayoutParams(dp(48), dp(48)));
    LinearLayout labels = new LinearLayout(getContext());
    labels.setOrientation(VERTICAL);
    labels.setPadding(dp(8), 0, 0, 0);
    headerName = text("MainActivity.java", 17, Color.WHITE);
    headerName.setTypeface(null, Typeface.BOLD);
    headerName.setSingleLine(false);
    headerName.setMaxLines(2);
    headerName.setEllipsize(android.text.TextUtils.TruncateAt.END);
    headerPath = text("/storage/emulated/0/AppProjects", 12, Color.LTGRAY);
    headerPath.setSingleLine(true);
    headerPath.setEllipsize(android.text.TextUtils.TruncateAt.START);
    labels.addView(headerName, new LinearLayout.LayoutParams(-1, 0, 1));
    labels.addView(headerPath, new LinearLayout.LayoutParams(-1, 0, 1));
    header.addView(labels, new LinearLayout.LayoutParams(0, -1, 1));
    fileHeader = header;
    addView(header, new LayoutParams(-1, dp(61)));
    View line = new View(getContext());
    line.setBackgroundColor(Color.rgb(41, 182, 246));
    addView(line, new LayoutParams(-1, dp(2)));
  }

  private void addEditor() {
    LinearLayout row = new LinearLayout(getContext());
    row.setOrientation(HORIZONTAL);
    row.setLayoutDirection(LAYOUT_DIRECTION_LTR);
    row.setBackgroundColor(Color.BLACK);
    editorRow = row;
    // بند الإحلال: أرقام الأسطر داخلية في لوحة الرسم (الجالتر) — لا View خارجية.
    code = new AlmlkEditor(getContext());
    // فقاعة المؤشر تُصلح من نفس دالة التطبيق التي يستعملها شريط «تحديد الإجراءات» — لا مسار ثانٍ.
    code.setQuickFixPickListener(fix -> applySelectedQuickFix(null, fix));
    applyEditorSettings();
    code.setLineSpacing(dp(3), 1);
    code.setChangeListener(version -> {
      if (!historyLocked && loadingFile == null) {
        removeCallbacks(autoSaveRunnable);
        postDelayed(autoSaveRunnable, 850L);
        FileChangedListener listener = fileChangedListener;
        if (listener != null && activeFile != null)
          listener.changed(activeFile, getActiveFileReference());
      }
    });
    code.setDiagnosticsListener(
        items -> {
          DiagnosticsListener listener = diagnosticsListener;
          if (listener != null && activeFile != null)
            listener.updated(
                activeFile,
                getActiveFileReference(),
                code.getText().toString(),
                items == null ? Collections.emptyList() : items);
        });
    code.setCustomSelectionActionModeCallback(
        new ActionMode.Callback() {
          private PopupWindow selectionMenu;
          private String selectionMenuPage;
          private boolean actionModeActive;

          @Override
          public boolean onCreateActionMode(ActionMode mode, android.view.Menu menu) {
            actionModeActive = true;
            code.normalizeSelectionToTouchedIdentifier();
            // بند 3 — فتح قائمة التحديد يجب ألا يهزّ لوحة المفاتيح: إن كانت ظاهرة قبل القائمة
            // تُعاد إلى وضعها فور بدء وضع الإجراء حتى لا تختفي ثم تعود.
            android.graphics.Rect imeFrame = new android.graphics.Rect();
            code.getWindowVisibleDisplayFrame(imeFrame);
            int imeHeightDiff = code.getRootView().getHeight() - imeFrame.bottom;
            boolean imeWasVisible =
                imeHeightDiff > getResources().getDisplayMetrics().density * 100;
            if (imeWasVisible) {
              final android.view.inputmethod.InputMethodManager imm =
                  (android.view.inputmethod.InputMethodManager)
                      getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
              if (imm != null) {
                code.postDelayed(
                    () -> {
                      if (actionModeActive && code.hasFocus()) imm.showSoftInput(code, 0);
                    },
                    80);
              }
            }
            // شريط التحديد كالمرجع: زر تحديد واحد ثابت (⛶ توسيع التحديد) بتحديد أو بدونه،
            // ثم قص/نسخ عند وجود مدى ولصق؛ «تحديد الكل» وبقية الأوامر في المزيد.
            mode.setTitle(UiStrings.get(getContext(), "ui_selection_title"));
            styleSelectionIcon(menu, almlk.CodeEditorView.ID_CUT, R.drawable.ic_vectoric_cut);
            styleSelectionIcon(menu, almlk.CodeEditorView.ID_COPY, R.drawable.ic_vectoric_copy);
            styleSelectionIcon(menu, almlk.CodeEditorView.ID_PASTE, R.drawable.ic_vectoric_paste);
            android.view.MenuItem builtinSelectAll =
                menu.findItem(almlk.CodeEditorView.ID_SELECT_ALL);
            if (builtinSelectAll != null) builtinSelectAll.setVisible(false);
            // زر الإصلاح (الحشرة) قبل ⛶ كالمرجع؛ يظهر فقط حين يحمل التشخيص تحت التحديد إصلاحًا.
            android.view.MenuItem fix = menu.add(0, FIX_MENU, 0, UiStrings.get(getContext(), "command_fix"));
            fix.setIcon(R.drawable.ic_vectoric_fix);
            fix.setShowAsAction(android.view.MenuItem.SHOW_AS_ACTION_ALWAYS);
            android.view.MenuItem expand = menu.add(0, EXPAND_SELECTION, 0, UiStrings.get(getContext(), "keybind_expand_selection"));
            expand.setIcon(R.drawable.ic_vectoric_expand);
            expand.setShowAsAction(android.view.MenuItem.SHOW_AS_ACTION_ALWAYS);
            android.view.MenuItem more = menu.add(0, MORE_MENU, 9, UiStrings.get(getContext(), "command_more"));
            more.setIcon(R.drawable.ic_vectoric_more);
            more.setShowAsAction(android.view.MenuItem.SHOW_AS_ACTION_ALWAYS);
            applySelectionToolbarState(menu);
            return true;
          }

          @Override
          public boolean onPrepareActionMode(ActionMode mode, android.view.Menu menu) {
            applySelectionToolbarState(menu);
            if (selectionMenu != null && selectionMenu.isShowing()) {
              final String page = selectionMenuPage;
              post(() -> {
                if (actionModeActive) showSelectionMenu(mode, page);
              });
            }
            return true;
          }

          /** نافذة مدمجة بعرض محتوى (~dp250) برأس أزرق للفرعية — شكل لقطات المرجع. */
          /**
           * معاملة اللون: لقطة نسخة/مدى عند الفتح، ثم تحقق ذري عند OK. الإلغاء لا يستدعي أي
           * كتابة، والتأكيد الناجح يمر باستبدال واحد فقط فتكون له خطوة Undo واحدة.
           */
          private void editSelectedColor(ActionMode mode) {
            if (!isActiveFileWritable()) {
              Toast.makeText(getContext(), UiStrings.get(getContext(), "ui_file_read_only"), Toast.LENGTH_SHORT).show();
              return;
            }
            final AlmlkEditor.ColorLiteralEdit edit = code.beginColorLiteralEdit();
            if (edit == null) return;
            net.margaritov.preference.colorpicker.ColorPickerDialog picker =
                new net.margaritov.preference.colorpicker.ColorPickerDialog(
                    getContext(), edit.originalArgb());
            picker.setTitle(UiStrings.get(getContext(), "command_color"));
            picker.setAlphaSliderVisible(true);
            picker.setHexValueEnabled(true);
            picker.setOnColorChangedListener(
                color -> {
                  if (!isActiveFileWritable()) {
                    Toast.makeText(getContext(), UiStrings.get(getContext(), "ui_read_only_no_change"), Toast.LENGTH_SHORT)
                        .show();
                    mode.finish();
                    return;
                  }
                  AlmlkEditor.ColorLiteralEditResult result =
                      code.applyColorLiteralEdit(edit, color);
                  if (result == AlmlkEditor.ColorLiteralEditResult.STALE) {
                    Toast.makeText(
                            getContext(),
                            UiStrings.get(getContext(), "ui_color_document_changed"),
                            Toast.LENGTH_LONG)
                        .show();
                  }
                  mode.finish();
                });
            picker.show();
          }

          private void showSelectionMenu(ActionMode mode, String page) {
            selectionMenuPage = page;
            if (selectionMenu != null) selectionMenu.dismiss();
            LayoutInflater inflater = LayoutInflater.from(getContext());
            LinearLayout container =
                (LinearLayout) inflater.inflate(R.layout.ide_overflow_menu, null, false);
            String headerKey = editorMenuRegistry.titleForPage(page);
            String header = headerKey == null ? null : UiStrings.get(getContext(), headerKey);
            if (header != null) {
              View headerRow = inflater.inflate(R.layout.ide_overflow_entry, container, false);
              TextView headerTitle = headerRow.findViewById(R.id.ideOverflowEntryTitle);
              headerRow.findViewById(R.id.ideOverflowEntryArrow).setVisibility(GONE);
              headerTitle.setText(header);
              headerTitle.setTextColor(Color.rgb(41, 182, 246));
              headerRow.setOnClickListener(
                  v -> showSelectionMenu(mode, EditorMenuRegistry.PAGE_ROOT));
              container.addView(headerRow);
            }
            EditorMenuRegistry.Context context = editorMenuContext(mode);
            for (EditorMenuRegistry.Entry entry : editorMenuRegistry.entries(page, context)) {
              View rowView = inflater.inflate(R.layout.ide_overflow_entry, container, false);
              TextView titleView = rowView.findViewById(R.id.ideOverflowEntryTitle);
              TextView arrowView = rowView.findViewById(R.id.ideOverflowEntryArrow);
              String localizedTitle = UiStrings.get(getContext(), entry.title);
              String localizedReason =
                  entry.disabledReason.isEmpty()
                      ? ""
                      : UiStrings.get(getContext(), entry.disabledReason);
              if (entry.enabled || localizedReason.isEmpty()) {
                titleView.setText(localizedTitle);
              } else {
                titleView.setMaxLines(2);
                titleView.setTextSize(14);
                titleView.setText(localizedTitle + "\n" + localizedReason);
              }
              arrowView.setVisibility(entry.isSubmenu() ? VISIBLE : GONE);
              rowView.setEnabled(entry.enabled);
              rowView.setAlpha(entry.enabled ? 1f : 0.48f);
              rowView.setContentDescription(
                  localizedReason.isEmpty()
                      ? localizedTitle
                      : localizedTitle + ": " + localizedReason);
              rowView.setOnClickListener(v -> {
                if (!v.isEnabled()) return;
                if (entry.isSubmenu()) {
                  showSelectionMenu(mode, entry.subpage);
                  return;
                }
                selectionMenu.dismiss();
                if (entry.dynamicAction != null) post(entry.dynamicAction);
                else post(() -> executeEditorMenuCommand(entry.id, mode));
              });
              container.addView(rowView);
            }
            selectionMenu =
                new PopupWindow(container, dp(250), ViewGroup.LayoutParams.WRAP_CONTENT, false);
            // عزل تام عن الكيبورد: غير focusable فلا تخطف التركيز ولا تُخفي الكيبورد،
            // ولا تُعاد قياسها عند تغيّر حالته — فلا رعشة ولا إغلاق فوري (علّة «المزيد»).
            selectionMenu.setInputMethodMode(PopupWindow.INPUT_METHOD_NOT_NEEDED);
            selectionMenu.setSoftInputMode(
                android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_UNCHANGED);
            selectionMenu.setBackgroundDrawable(
                new android.graphics.drawable.ColorDrawable(Color.rgb(48, 48, 48)));
            selectionMenu.setOutsideTouchable(true);
            selectionMenu.setElevation(dp(10));
            selectionMenu.setAnimationStyle(android.R.style.Animation_Dialog);
            selectionMenu.showAtLocation(
                AIDEEditorPager.this, Gravity.TOP | Gravity.END, dp(6), dp(30));
          }

          /** التنفيذ الوحيد للأوامر الثابتة؛ أوامر النطاق تنفذ قبل finish لأن teardown يمحو التحديد. */
          private void executeEditorMenuCommand(String id, ActionMode mode) {
            switch (id) {
              case "color":
                editSelectedColor(mode);
                break;
              case "goto":
                resolveDefinitionOnDemand(mode);
                break;
              case "select_all":
                code.selectAll();
                break;
              case "documentation":
                // التوثيق يقرأ التحديد الحالي؛ نبقي ActionMode كما في المسار السابق.
                runHostCommand("documentation");
                break;
              case "organize_imports":
                organizeImports();
                mode.finish();
                break;
              case "surround_try":
                surroundWithTryCatch();
                mode.finish();
                break;
              case "comment":
                commentLines();
                mode.finish();
                break;
              case "uncomment":
                uncommentLines();
                mode.finish();
                break;
              case "replace": {
                int from = code.getSelectionStart();
                int to = code.getSelectionEnd();
                String selectedText = almlk.CodeMenuCommands.selectedText(
                    code.getText().toString(), from, to);
                mode.finish();
                runHostCommand("replace", selectedText);
                break;
              }
              case "format_code":
                formatSource();
                mode.finish();
                break;
              case "configure_style":
                // المرحلة الثامنة: الإعدادات شاشة مضيف، فلا تُنفَّذ داخل المحرر.
                mode.finish();
                runHostCommand("configure_style");
                break;
              case "find_usages":
              case "find_extended":
                // مسار Java لكلا البندين؛ وفي XML يبحثان عن اسم المورد بعد تثبيت المدى (المرحلة السابعة).
                resolveUsagesOnDemand(mode);
                break;
              case "find_text":
                mode.finish();
                runHostCommand("find");
                break;
              case "rename":
                // التقط الرمز وافتح الحوار بينما المدى ما زال محفوظًا.
                renameCurrentSelection();
                mode.finish();
                break;
              case "inline":
                refactorInline();
                mode.finish();
                break;
              case "introduce":
                refactorIntroduce();
                mode.finish();
                break;
              case "extract_method":
                refactorExtract();
                mode.finish();
                break;
              case "breakpoint":
                mode.finish();
                boolean bpSet = code.toggleBreakpointAtCaret();
                Toast.makeText(
                        getContext(),
                        UiStrings.get(getContext(), bpSet ? "ui_breakpoint_added" : "ui_breakpoint_removed"),
                        Toast.LENGTH_SHORT)
                    .show();
                break;
              case "learn_style":
                mode.finish();
                runHostCommand("learn_style");
                break;
              case "create_setters": {
                int selectionStart = code.getSelectionStart();
                int selectionEnd = code.getSelectionEnd();
                mode.finish();
                codegenSetters(selectionStart, selectionEnd);
                break;
              }
              case "create_constructor": {
                int selectionStart = code.getSelectionStart();
                int selectionEnd = code.getSelectionEnd();
                mode.finish();
                codegenConstructor(selectionStart, selectionEnd);
                break;
              }
              case "extract_resources":
                codegenExtractResource();
                mode.finish();
                break;
              case "close":
                mode.finish();
                runHostCommand("close_file");
                break;
              default:
                break; // الأوامر غير المنفذة معطلة أصلًا في السجل مع سبب ظاهر.
            }
          }

          private void resolveDefinitionOnDemand(ActionMode mode) {
            final int rawSelectionStart = code.getSelectionStart();
            final int rawSelectionEnd = code.getSelectionEnd();
            final int selectionStart = Math.min(rawSelectionStart, rawSelectionEnd);
            final int selectionEnd = Math.max(rawSelectionStart, rawSelectionEnd);
            final String source = code.getText().toString();
            final String sourceFile = activeFile;
            mode.finish();
            final int request = ++definitionGeneration;
            completionWorker.execute(
                () -> {
                  try {
                    final ProjectSymbolIndex.DefinitionTarget target =
                        sourceFile.toLowerCase(java.util.Locale.US).endsWith(".smali")
                            ? SmaliDefinitionResolver.resolve(
                                sourceFile, source, selectionStart, selectionEnd)
                            : ProjectSymbolIndex.resolveDefinition(
                                sourceFile, source, selectionStart, selectionEnd);
                    post(
                        () -> {
                          if (request != definitionGeneration) return;
                          if (target != null && definitionListener != null) {
                            if (usageListener != null
                                && ProjectSymbolIndex.isDefinitionSelection(
                                    sourceFile, source, selectionStart, selectionEnd, target)) {
                              usageListener.requested(
                                  sourceFile, source, selectionStart, selectionEnd);
                            } else {
                              definitionListener.requested(target);
                            }
                          } else if (target == null && definitionRequestListener != null) {
                            definitionRequestListener.requested(
                                sourceFile, source, selectionStart, selectionEnd);
                          } else {
                            Toast.makeText(
                                    getContext(),
                                    UiStrings.get(getContext(), "ui_error_definition_not_found"),
                                    Toast.LENGTH_SHORT)
                                .show();
                          }
                        });
                  } catch (Throwable error) {
                    post(
                        () -> {
                          if (request == definitionGeneration) showEditorError(error);
                        });
                  }
                });
          }

          private void resolveUsagesOnDemand(ActionMode mode) {
            final String source = code.getText().toString();
            final int[] snapped = usageSelection(source, code.getSelectionStart(), code.getSelectionEnd());
            final int selectionStart = snapped[0];
            final int selectionEnd = snapped[1];
            final String sourceFile = activeFile;
            mode.finish();
            final int request = ++definitionGeneration;
            completionWorker.execute(
                () ->
                    post(
                        () -> {
                          if (request != definitionGeneration) return;
                          if (usageListener != null)
                            usageListener.requested(sourceFile, source, selectionStart, selectionEnd);
                        }));
          }

          @Override
          public boolean onActionItemClicked(ActionMode mode, android.view.MenuItem item) {
            int id = item.getItemId();
            if (id == android.R.id.selectAll
                || id == android.R.id.cut
                || id == android.R.id.copy
                || id == android.R.id.paste) {
              boolean handled = code.onTextContextMenuItem(id);
              if (handled && id != android.R.id.selectAll) mode.finish();
              return handled;
            }
            if (id == EXPAND_SELECTION) {
              expandCodeSelection();
              return true;
            }
            if (id == FIX_MENU) {
              showSelectionMenu(mode, EditorMenuRegistry.PAGE_FIX);
              return true;
            }
            if (id == MORE_MENU) {
              showSelectionMenu(mode, EditorMenuRegistry.PAGE_ROOT);
              return true;
            }
            return false;
          }

          @Override
          public void onDestroyActionMode(ActionMode mode) {
            actionModeActive = false;
            definitionGeneration++;
            if (selectionMenu != null) {
              selectionMenu.dismiss();
              selectionMenu = null;
            }
          }
        });
    code.addTextChangedListener(
        new android.text.TextWatcher() {
          public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            // التراجع/الإعادة مدمجان بموديل المحرك (بند الإحلال) — لا تتبع خارجي.
          }

          public void onTextChanged(CharSequence s, int start, int before, int count) {
            completionSnapshot.applyChange(s, start, before, count);
            cancelCompletionLookup();
            if (!historyLocked
                && isXmlFile()
                && count == 1
                && start > 0
                && start < s.length()
                && s.charAt(start - 1) == '<'
                && s.charAt(start) == '/') {
              final int marker = start + 1;
              post(() -> completeXmlClosingTag(marker));
            }
            pendingEdits = true;
            markActiveDirty(); // ج٤٢: العَلامَةُ على اللِّسانِ والرَّأسِ، ودُخُولٌ في «احفَظِ الكُلَّ»
            removeCallbacks(completionTask);
            completionGeneration++;
            if (!historyLocked) {
              boolean refreshCompletions = false;
              if (count > 0 && start + count <= s.length()) {
                char last = s.charAt(start + count - 1);
                boolean identLast = Character.isJavaIdentifierPart(last) && last != '.';
                refreshCompletions =
                    (identLast && almlk.AppSettings.completeAfterLetter(getContext()))
                        || (last == '.' && almlk.AppSettings.completeAfterDot(getContext()))
                        || last == '<'
                        || last == ':'
                        || last == '@';
              } else if (count == 0 && before > 0 && start > 0 && start <= s.length()) {
                char previous = s.charAt(start - 1);
                boolean identPrev = Character.isJavaIdentifierPart(previous) && previous != '.';
                refreshCompletions =
                    (identPrev && almlk.AppSettings.completeAfterLetter(getContext()))
                        || (previous == '.' && almlk.AppSettings.completeAfterDot(getContext()));
              }
              if (refreshCompletions) postDelayed(completionTask, 24);
              else dismissCompletions();
            } else dismissCompletions();
          }

          public void afterTextChanged(android.text.Editable e) {
            // كل تعديل قد يقلب أهلية التراجع/الإعادة — الشريط يلتقطها لحظيًا كالمرجع.
            notifyHistoryState();
          }
        });
    row.addView(code, new LinearLayout.LayoutParams(0, -1, 1));
    addView(row, new LayoutParams(-1, 0, 1));
  }

  /** مزود أدوات اختيار قابل للتوسعة؛ الأب «أدوات..» يختفي إن لم ينتج أي مساهم أمرًا ظاهرًا. */
  public void addSelectionToolContributor(SelectionToolContributor contributor) {
    if (contributor != null && !selectionToolContributors.contains(contributor))
      selectionToolContributors.add(contributor);
  }

  public void removeSelectionToolContributor(SelectionToolContributor contributor) {
    selectionToolContributors.remove(contributor);
  }

  private EditorMenuRegistry.Context editorMenuContext(ActionMode mode) {
    EditorMenuRegistry.Context context = new EditorMenuRegistry.Context();
    context.xml = isXmlFile();
    context.layoutXml = isActiveLayoutXml();
    context.writable = isActiveFileWritable();
    context.hasOpenFile = hasOpenFile();
    context.hasSelection = code != null && code.hasSelection();
    context.hasText = code != null && code.length() > 0;
    context.hasFieldTarget = code != null && !context.xml && activeFile != null
        && activeFile.toLowerCase(java.util.Locale.US).endsWith(".java")
        && almlk.CodeGen.hasFieldTarget(code.getText().toString(),
            code.getSelectionStart(), code.getSelectionEnd());
    context.hasColor = code != null && code.colorLiteralForSelection() != null;
    context.hasClipboardText = code != null && code.hasClipboardText();
    int[] expanded = expandedCodeSelectionRange();
    context.canExpand = expanded != null;

    ArrayList<EditorMenuRegistry.DynamicCommand> fixes = new ArrayList<>();
    List<almlk.QuickFix> available =
        almlk.JavaImportResolver.withFixImportsRow(
            code == null || context.xml
                ? Collections.<almlk.QuickFix>emptyList()
                : code.quickFixesAtSelection());
    java.util.HashSet<String> seenFixes = new java.util.HashSet<>();
    for (int i = 0; i < available.size() && fixes.size() < 6; i++) {
      final almlk.QuickFix fix = available.get(i);
      if (!seenFixes.add(fix.key())) continue;
      fixes.add(
          new EditorMenuRegistry.DynamicCommand(
              "fix." + fixes.size(),
              UiStrings.format(
                  getContext(), fix.menuKey(), fix.signature(), fix.targetClass),
              quickFixListener != null,
              "",
              () ->
                  // الإصلاح قد يعدّل صنفًا آخر؛ قابلية كتابة الملف المستهدف يفحصها المنفّذ نفسه.
                  applySelectedQuickFix(mode, fix)));
    }
    context.fixes = fixes;

    ArrayList<EditorMenuRegistry.DynamicCommand> tools = new ArrayList<>();
    for (int i = 0; i < selectionToolContributors.size(); i++) {
      try {
        EditorMenuRegistry.DynamicCommand command =
            selectionToolContributors.get(i).contribute(context);
        if (command != null) tools.add(command);
      } catch (Throwable ignored) {
        // مساهم خارجي معطوب لا يسقط قائمة المحرر ولا يولّد أبًا فارغًا.
      }
    }
    context.tools = tools;
    return context;
  }

  /**
   * التطبيق الوحيد للإصلاح السريع، من قائمتي شريط التحديد ومن فقاعة المؤشر معًا (بند الإحلال: لا
   * مساران). {@code mode} قد يكون null (الفقاعة لا تفتح وضع تحديد) فلا يُلمس شريط عند الحاجة إليه.
   */
  private void applySelectedQuickFix(android.view.ActionMode mode, almlk.QuickFix fix) {
    if (mode != null) mode.finish();
    QuickFixListener listener = quickFixListener;
    if (listener != null && fix != null) listener.applyQuickFix(fix);
  }

  private void applySelectionToolbarState(android.view.Menu menu) {
    EditorMenuRegistry.Context context = editorMenuContext(null);
    int[] toolbarIds = {
      FIX_MENU,
      EXPAND_SELECTION,
      almlk.CodeEditorView.ID_CUT,
      almlk.CodeEditorView.ID_COPY,
      almlk.CodeEditorView.ID_PASTE,
      MORE_MENU
    };
    for (int toolbarId : toolbarIds) {
      android.view.MenuItem item = menu.findItem(toolbarId);
      if (item != null) item.setVisible(false);
    }
    for (EditorMenuRegistry.Entry entry :
        editorMenuRegistry.entries(EditorMenuRegistry.PAGE_TOOLBAR, context)) {
      int itemId;
      switch (entry.id) {
        case "fix": itemId = FIX_MENU; break;
        case "expand": itemId = EXPAND_SELECTION; break;
        case "cut": itemId = almlk.CodeEditorView.ID_CUT; break;
        case "copy": itemId = almlk.CodeEditorView.ID_COPY; break;
        case "paste": itemId = almlk.CodeEditorView.ID_PASTE; break;
        case "more": itemId = MORE_MENU; break;
        default: continue;
      }
      android.view.MenuItem item = menu.findItem(itemId);
      if (item == null) continue;
      item.setVisible(true);
      item.setEnabled(entry.enabled);
      String localizedTitle = UiStrings.get(getContext(), entry.title);
      String localizedReason =
          entry.disabledReason.isEmpty() ? "" : UiStrings.get(getContext(), entry.disabledReason);
      item.setTitle(localizedTitle);
      item.setContentDescription(
            localizedReason.isEmpty() ? localizedTitle : localizedTitle + ": " + localizedReason);
    }
  }

  private boolean isActiveLayoutXml() {
    if (!isXmlFile()) return false;
    String reference = getActiveFileReference();
    String path = android.net.Uri.decode(reference == null || reference.isEmpty() ? activeFile : reference)
        .replace('\\', '/')
        .toLowerCase(java.util.Locale.US);
    if (!path.endsWith(".xml")) return false;
    int slash = path.lastIndexOf('/');
    if (slash <= 0) return false;
    int parentSlash = path.lastIndexOf('/', slash - 1);
    String parent = path.substring(parentSlash + 1, slash);
    return "layout".equals(parent) || parent.startsWith("layout-");
  }

  private boolean isActiveFileWritable() {
    return hasOpenFile() && isFileWritable(activeFile);
  }

  /** معيارُ الكتابةِ الواحدُ لكلِّ تبويبٍ مفتوحٍ (النشطِ وخاملِه): لا مسارَ ثانٍ للإصلاحِ. */
  private boolean isFileWritable(String name) {
    if (name == null || !tabs.containsKey(name)) return false;
    // Virtual Android/JDK classes are source views only, never editor destinations.
    if (name.toLowerCase(java.util.Locale.US).endsWith(".class")) return false;
    String reference = tabReference(name);
    if (reference == null || reference.isEmpty()) return true;
    try {
      android.net.Uri uri = android.net.Uri.parse(reference);
      if ("content".equalsIgnoreCase(uri.getScheme())) {
        androidx.documentfile.provider.DocumentFile file =
            androidx.documentfile.provider.DocumentFile.fromSingleUri(getContext(), uri);
        return file == null || file.canWrite();
      }
      String path = "file".equalsIgnoreCase(uri.getScheme()) ? uri.getPath() : reference;
      java.io.File file = new java.io.File(path == null ? reference : path);
      return !file.exists() || file.canWrite();
    } catch (Throwable ignored) {
      return true;
    }
  }

  /** مرجعُ تبويبٍ مفتوحٍ: الثابتُ أو اسمُه عند غيابِه — للفهرسةِ خارجَ التبويبِ النشطِ. */
  private String tabReference(String name) {
    String reference = sessionReferences.get(name);
    return reference == null ? "" : reference;
  }

  private int[] expandedCodeSelectionRange() {
    if (code == null) return null;
    String name = activeFile == null ? "" : activeFile.toLowerCase(java.util.Locale.US);
    boolean javaLike = name.endsWith(".java") || name.endsWith(".gradle") || name.endsWith(".kts");
    return almlk.SelectionExpansion.expand(code.getText().toString(),
        javaLike ? ProjectSymbolIndex::maskSource : null, code.getSelectionStart(), code.getSelectionEnd());
  }

  private void expandCodeSelection() {
    int[] range = expandedCodeSelectionRange();
    if (range != null) code.setSelection(range[0], range[1]);
  }

  private void watchKeyboard() {
    getViewTreeObserver()
        .addOnGlobalLayoutListener(
            () -> {
              Rect area = new Rect();
              getWindowVisibleDisplayFrame(area);
              int current = area.height();
              if (current > largestVisibleHeight) largestVisibleHeight = current;
              int total = getRootView().getHeight();
              boolean visible =
                  (largestVisibleHeight - current) > Math.max(dp(170), largestVisibleHeight / 6)
                      || (total - area.bottom) > Math.max(dp(170), total / 6);
              if (visible != keyboardVisible) {
                keyboardVisible = visible;
                if (visible) {
                  fileHeader.setVisibility(GONE);
                } else {
                  dismissCompletions();
                  fileHeader.setVisibility(VISIBLE);
                }
                if (quickKeyBar != null) quickKeyBar.setKeyboardVisible(visible);
              }
            });
  }

  private static final class SessionData {
    String selected;
    final LinkedHashMap<String, String> files = new LinkedHashMap<>();
  }

  public void restoreSessionAsync(SessionListener listener) {
    // Only metadata is read here. The selected file is loaded later, on demand.
    sessionWorker.execute(
        () -> {
          if (sessionStore == null) sessionStore = new InstantSessionStore(getContext());
          InstantSessionStore.Snapshot snapshot = sessionStore.load();
          if (snapshot.tabs.isEmpty()) {
            restoreSessionInBackground(listener); // one-time compatibility with old builds
            return;
          }
          post(() -> applyInstantSession(snapshot, listener));
        });
  }

  private void applyInstantSession(InstantSessionStore.Snapshot snapshot, SessionListener listener) {
    lazySessionReferences.clear();
    sessionReferences.clear();
    sessionCursors.clear();
    sessionScrollX.clear();
    sessionScrollY.clear();
    // تقرير فتح الملفات — مُطهّر الجلسة (checkOpenFile على طريقة AIDE): تُسقط التبويبات التي
    // مرجعها ملف محذوف — لكن فقط عندما يكون التحقق ممكنًا فعليًا (وصول مباشر للتخزين)،
    // وإلا بقيت المراجع محفوظة ليُعاد تحميلها بعد منح الإذن (لا ضياع للجلسة).
    final boolean canVerifyFiles = canVerifyFileExistence();
    int restored = 0;
    for (InstantSessionStore.Tab tab : snapshot.tabs) {
      if (canVerifyFiles
          && tab.reference != null
          && tab.reference.startsWith("/")
          && !new java.io.File(tab.reference).isFile()) {
        continue; // مرجع ميّت — لا تبويبات وهمية تتعطل لاحقًا.
      }
      if (!tabs.containsKey(tab.name)) addTab(tab.name);
      sessionReferences.put(tab.name, tab.reference);
      if (!tab.reference.isEmpty()) lazySessionReferences.put(tab.name, tab.reference);
      sessionCursors.put(tab.name, tab.cursor);
      sessionScrollX.put(tab.name, tab.scrollX);
      sessionScrollY.put(tab.name, tab.scrollY);
      restored++;
    }
    // دلالة checkOpenFile المرجعية: اللقطة المنقّاة تُكتب فورًا — لا عودة للمراجع الميتة.
    final boolean pruned = restored < snapshot.tabs.size();
    if (restored == 0) {
      if (pruned)
        sessionWorker.execute(
            () -> {
              if (sessionStore == null) sessionStore = new InstantSessionStore(getContext());
              sessionStore.clear();
            });
      if (listener != null) listener.restored(false);
      return;
    }
    String first =
        snapshot.selected != null && tabs.containsKey(snapshot.selected)
            ? snapshot.selected
            : tabs.keySet().iterator().next();
    setVisibility(VISIBLE);
    if (listener != null) listener.restored(true);
    postOnAnimation(
        () -> {
          selectFile(first);
          if (pruned) saveSession();
        });
  }

  /** التحقق من الوجود ممكن فقط مع وصول مباشر للتخزين (وإلا false-سلبي يقتل تبويبات سليمة). */
  private boolean canVerifyFileExistence() {
    if (android.os.Build.VERSION.SDK_INT < 30) return true;
    try {
      return android.os.Environment.isExternalStorageManager();
    } catch (Throwable ignored) {
      return false;
    }
  }

  private void restoreSessionInBackground(SessionListener listener) {
    java.io.File session = new java.io.File(getContext().getFilesDir(), "editor-session.bin");
    if (!session.isFile()) {
      if (listener != null) post(() -> listener.restored(false));
      return;
    }
    try (java.io.DataInputStream input =
        new java.io.DataInputStream(
            new java.io.BufferedInputStream(new java.io.FileInputStream(session)))) {
      int version = input.readInt();
      String selected = input.readUTF();
      int count = Math.min(12, Math.max(0, input.readInt()));
      if (version == 4 || version == 3) {
        LinkedHashMap<String, java.io.File> lazyFiles = new LinkedHashMap<>();
        LinkedHashMap<String, Integer> cursors = new LinkedHashMap<>();
        LinkedHashMap<String, Integer> scrollXs = new LinkedHashMap<>();
        LinkedHashMap<String, Integer> scrollYs = new LinkedHashMap<>();
        java.io.File directory = new java.io.File(getContext().getFilesDir(), "session-tabs");
        for (int i = 0; i < count; i++) {
          String name = input.readUTF();
          String storedName = input.readUTF();
          lazyFiles.put(name, new java.io.File(directory, storedName));
          if (version == 4) {
            cursors.put(name, Math.max(0, input.readInt()));
            scrollXs.put(name, Math.max(0, input.readInt()));
            scrollYs.put(name, Math.max(0, input.readInt()));
          }
        }
        post(() -> applyLazySession(selected, lazyFiles, cursors, scrollXs, scrollYs, listener));
        return;
      }
      if (version == 2 && count > 0) {
        String firstName = input.readUTF();
        String firstContent = readSessionContent(input);
        post(
            () -> {
              applyFirstSessionFile(firstName, firstContent);
              if (listener != null) listener.restored(true);
            });
        SessionData remaining = new SessionData();
        remaining.selected = selected;
        for (int i = 1; i < count; i++) {
          String name = input.readUTF();
          remaining.files.put(name, readSessionContent(input));
        }
        if (!remaining.files.isEmpty()) post(() -> appendSessionFiles(remaining));
        return;
      }
      if (version != 1) throw new java.io.IOException("Unsupported session version");
      SessionData legacy = new SessionData();
      legacy.selected = selected;
      for (int i = 0; i < count; i++) {
        String name = input.readUTF();
        legacy.files.put(name, readSessionContent(input));
      }
      post(
          () -> {
            boolean success = applyLegacySession(legacy);
            if (listener != null) listener.restored(success);
          });
    } catch (Exception error) {
      session.delete();
      post(
          () -> {
            if (listener != null) listener.restored(false);
          });
    }
  }

  private String readSessionContent(java.io.DataInputStream input) throws java.io.IOException {
    int length = input.readInt();
    if (length < 0 || length > 1200000) throw new java.io.IOException("Invalid session file");
    byte[] bytes = new byte[length];
    input.readFully(bytes);
    return EncodingManager.decodeUtf8(bytes);
  }

  private void applyLazySession(
      String selected,
      LinkedHashMap<String, java.io.File> files,
      LinkedHashMap<String, Integer> cursors,
      LinkedHashMap<String, Integer> scrollXs,
      LinkedHashMap<String, Integer> scrollYs,
      SessionListener listener) {
    if (files.isEmpty()) {
      if (listener != null) listener.restored(false);
      return;
    }
    lazySessionFiles.clear();
    lazySessionFiles.putAll(files);
    sessionCursors.clear();
    sessionCursors.putAll(cursors);
    sessionScrollX.clear();
    sessionScrollX.putAll(scrollXs);
    sessionScrollY.clear();
    sessionScrollY.putAll(scrollYs);
    for (String name : files.keySet()) if (!tabs.containsKey(name)) addTab(name);
    String first = files.containsKey(selected) ? selected : files.keySet().iterator().next();
    setVisibility(VISIBLE);
    if (listener != null) listener.restored(true);
    postOnAnimation(() -> selectFile(first));
  }

  private void applyFirstSessionFile(String name, String content) {
    if (!tabs.containsKey(name)) addTab(name);
    fileContents.put(name, content);
    selectFile(name);
    setVisibility(VISIBLE);
  }

  private void appendSessionFiles(SessionData data) {
    for (Map.Entry<String, String> entry : data.files.entrySet()) {
      if (!tabs.containsKey(entry.getKey())) addTab(entry.getKey());
      fileContents.put(entry.getKey(), entry.getValue());
    }
  }

  private boolean applyLegacySession(SessionData data) {
    if (data == null || data.files.isEmpty()) return false;
    for (Map.Entry<String, String> entry : data.files.entrySet()) {
      if (!tabs.containsKey(entry.getKey())) addTab(entry.getKey());
      fileContents.put(entry.getKey(), entry.getValue());
    }
    selectFile(tabs.containsKey(data.selected) ? data.selected : tabs.keySet().iterator().next());
    setVisibility(VISIBLE);
    return true;
  }

  private void queueAutoSave() {
    if (autoSaveManager == null || activeFile == null || code == null || loadingFile != null) return;
    String reference = sessionReferences.get(activeFile);
    if (reference == null || reference.isEmpty()) return;
    // The copy is delayed until the debounce has elapsed, so typing itself never copies the full
    // document or touches disk on the UI thread.
    String snapshot = code.getText().toString();
    autoSaveManager.requestSave(activeFile, reference, snapshot, SavePolicy.editorDefault(), null);
  }

  public void saveSession() {
    removeCallbacks(autoSaveRunnable);
    rememberActiveViewport();
    // تقرير فتح الملفات — لا نعيد كتابة نص الـ placeholder فوق محتوى الفتح المؤجل.
    if (activeFile != null
        && code != null
        && !activeFile.equals(loadingFile)
        && !openingFiles.contains(activeFile))
      fileContents.put(activeFile, code.getText().toString());
    final String selected = activeFile == null ? "" : activeFile;
    final ArrayList<InstantSessionStore.Tab> metadata = new ArrayList<>();
    for (String name : tabs.keySet()) {
      if (metadata.size() >= InstantSessionStore.MAX_TABS) break;
      metadata.add(
          new InstantSessionStore.Tab(
              name,
              sessionReferences.containsKey(name) ? sessionReferences.get(name) : "",
              sessionCursors.containsKey(name) ? sessionCursors.get(name) : 0,
              sessionScrollX.containsKey(name) ? sessionScrollX.get(name) : 0,
              sessionScrollY.containsKey(name) ? sessionScrollY.get(name) : 0));
    }
    final InstantSessionStore.Snapshot snapshot =
        new InstantSessionStore.Snapshot(selected, metadata);
    sessionWorker.execute(
        () -> {
          if (sessionStore == null) sessionStore = new InstantSessionStore(getContext());
          sessionStore.save(snapshot);
          // Remove content snapshots produced by pre-architecture versions.
          deleteQuietly(new java.io.File(getContext().getFilesDir(), "editor-session.bin"));
          deleteTree(new java.io.File(getContext().getFilesDir(), "session-tabs"));
        });
  }

  private void deleteQuietly(java.io.File file) {
    if (file != null) file.delete();
  }

  private void deleteTree(java.io.File file) {
    if (file == null || !file.exists()) return;
    if (file.isDirectory()) {
      java.io.File[] children = file.listFiles();
      if (children != null) for (java.io.File child : children) deleteTree(child);
    }
    file.delete();
  }

  // Legacy v1-v4 reader/writer retained only for one-time migration; saveSession() never calls it.
  private void writeSession(
      String selected,
      LinkedHashMap<String, String> snapshot,
      LinkedHashMap<String, Integer> cursors,
      LinkedHashMap<String, Integer> scrollXs,
      LinkedHashMap<String, Integer> scrollYs,
      LinkedHashMap<String, java.io.File> lazyFiles) {
    java.io.File target = new java.io.File(getContext().getFilesDir(), "editor-session.bin");
    java.io.File temporary = new java.io.File(getContext().getFilesDir(), "editor-session.tmp");
    java.io.File directory = new java.io.File(getContext().getFilesDir(), "session-tabs");
    if (snapshot.isEmpty()) {
      target.delete();
      temporary.delete();
      return;
    }
    directory.mkdirs();
    try (java.io.DataOutputStream output =
        new java.io.DataOutputStream(
            new java.io.BufferedOutputStream(new java.io.FileOutputStream(temporary)))) {
      output.writeInt(4);
      output.writeUTF(selected);
      output.writeInt(snapshot.size());
      for (Map.Entry<String, String> entry : snapshot.entrySet()) {
        String storedName = sessionFileName(entry.getKey());
        java.io.File storedFile = new java.io.File(directory, storedName);
        String content = entry.getValue();
        if (content != null) writeSessionTab(storedFile, content);
        else {
          java.io.File previous = lazyFiles.get(entry.getKey());
          if (!storedFile.isFile() && previous != null && previous.isFile())
            copyFile(previous, storedFile);
          if (!storedFile.isFile()) writeSessionTab(storedFile, "");
        }
        output.writeUTF(entry.getKey());
        output.writeUTF(storedName);
        output.writeInt(cursors.containsKey(entry.getKey()) ? cursors.get(entry.getKey()) : 0);
        output.writeInt(scrollXs.containsKey(entry.getKey()) ? scrollXs.get(entry.getKey()) : 0);
        output.writeInt(scrollYs.containsKey(entry.getKey()) ? scrollYs.get(entry.getKey()) : 0);
      }
    } catch (Exception error) {
      temporary.delete();
      return;
    }
    if (target.exists()) target.delete();
    temporary.renameTo(target);
  }

  private String sessionFileName(String name) {
    int forward = name.hashCode();
    int reverse = new StringBuilder(name).reverse().toString().hashCode();
    return Integer.toHexString(forward) + "-" + Integer.toHexString(reverse) + ".txt";
  }

  private void writeSessionTab(java.io.File target, String content) throws java.io.IOException {
    byte[] bytes = EncodingManager.encodeUtf8(content);
    if (bytes.length > 1200000) bytes = new byte[0];
    java.io.File temporary = new java.io.File(target.getParentFile(), target.getName() + ".tmp");
    try (java.io.FileOutputStream output = new java.io.FileOutputStream(temporary)) {
      output.write(bytes);
      output.flush();
    }
    if (target.exists()) target.delete();
    if (!temporary.renameTo(target)) throw new java.io.IOException("Session tab rename failed");
  }

  private void copyFile(java.io.File source, java.io.File target) throws java.io.IOException {
    try (java.io.FileInputStream input = new java.io.FileInputStream(source);
        java.io.FileOutputStream output = new java.io.FileOutputStream(target)) {
      byte[] buffer = new byte[8192];
      int read;
      while ((read = input.read(buffer)) >= 0) output.write(buffer, 0, read);
    }
  }

  public void openFile(String name) {
    openFile(name, null, "");
  }

  public void openFile(String name, String content) {
    openFile(name, content, "");
  }

  /** Opens a tab and associates it with a stable file path/SAF URI for metadata-only restore. */
  public void openFile(String name, String content, String reference) {
    if (name == null || name.trim().isEmpty()) return;
    name = uniqueTabNameFor(name, reference);
    if (!tabs.containsKey(name)) addTab(name);
    String safeReference = reference == null ? "" : reference;
    if (!safeReference.isEmpty()) sessionReferences.put(name, safeReference);
    lazySessionFiles.remove(name);
    lazySessionReferences.remove(name);
    openingFiles.remove(name);
    if (content != null) fileContents.put(name, content);
    else if (!fileContents.containsKey(name) && safeReference.isEmpty()) {
      String systemSource = ProjectSymbolIndex.systemSourceForFile(name);
      fileContents.put(name, systemSource == null ? sample(name) : systemSource);
    }
    selectFile(name);
    setVisibility(VISIBLE);
  }

  /**
   * تقرير فتح الملفات — «فتح فوري» على طريقة AIDE: التبويب يُنشأ ويُنتقل إليه لحظة النقرة
   * بمحتوى مؤقت «جارٍ فتح الملف…»، ثم تقرأ almlk.FileContentService (خدمة مستقرة لا تموت مع
   * إغلاق الدرج أو تبديل اللوحات) وتحقن المحتوى دون إعادة بناء التبويب.
   */
  public void openFilePending(String name, String reference) {
    if (name == null || name.trim().isEmpty()) return;
    final String tabName = uniqueTabNameFor(name, reference);
    if (!tabs.containsKey(tabName)) addTab(tabName);
    final String safeReference = reference == null ? "" : reference;
    if (!safeReference.isEmpty()) sessionReferences.put(tabName, safeReference);
    lazySessionFiles.remove(tabName);
    lazySessionReferences.remove(tabName);
    // ملف مفتوح من قبل ومحتواه حي → انتقال فوري بلا أي قراءة (أسرع مسار في AIDE).
    // لكن placeholder عتيق (من جولة غير مكتملة) لا يعدّ محتوى — يعاد فتحه.
    String existing = fileContents.get(tabName);
    if (existing != null && !PendingOpen.TEXT.equals(existing)) {
      selectFile(tabName);
      setVisibility(VISIBLE);
      return;
    }
    openingFiles.add(tabName);
    fileContents.put(tabName, PendingOpen.TEXT);
    selectFile(tabName);
    setVisibility(VISIBLE);
    almlk.FileContentService.get()
        .open(
            getContext(),
            tabName,
            safeReference,
            (fileName, success, content) -> {
              if (!tabName.equals(fileName)) return;
              openingFiles.remove(tabName);
              // النجاح فقط يُخزَّن محتوى؛ الفشل نصّ مرئي عابر حتى تبقى إعادة النقر
              // محاولة قراءة جديدة لا مشاهدة عطل قديم.
              if (success) fileContents.put(tabName, content);
              else fileContents.remove(tabName);
              if (!success) {
                // ‏W30 (ورقةُ هذهِ الجولةِ §١٫٤): تعذُّرُ التحميلِ يُعلَنُ كما يُعلِنُهُ المرجعُ —
                // توستٌ بمسارِ الملفِّ، لا حقنُ فراغٍ يُوهَمُ بأنَّهُ محتوى ملفٍّ فارغٍ. والقفلُ
                // مفكوكٌ في هذا المسارِ أيضًا: openingFiles أُطلِقَ فوقَ هذا السطرِ مباشرةً،
                // وhistoryLocked لم يُرفَعْ بعدُ فلا يُترَكُ رافعَهُ، واللوحةُ تبقى مفتوحةً.
                toastNotLoaded(tabName);
                return;
              }
              if (!tabName.equals(activeFile) || code == null) return;
              historyLocked = true;
              code.setHint(null);
              code.setText(content);
              historyLocked = false;
              restoreViewport(tabName);
              // W27/1: لا فحصَ قبلَ ملفٍّ جوهريٍّ — الاستعادةُ لا تُسلِّحُ المحرِّكَ وحدَها.
              code.setAnalysisPaused(!analysisArmed);
              // الجدولُ يُملَأُ وقتَ رَدِّ الخلفيةِ لا وقتَ النقرِ: القفزةُ المؤجَّلةُ تَجِدُهُ جاهزًا.
              code.jumpOffsets();
              code.post(code::refreshNow);
              if (tabName.equals(pendingMatchFile)) {
                final int line = pendingMatchLine, column = pendingMatchColumn;
                final int endColumn = pendingMatchEndColumn;
                final boolean actions = pendingMatchActions;
                final boolean token = pendingMatchToken;
                pendingMatchFile = null;
                code.post(
                    () -> goToDiagnostic(tabName, line, column, endColumn, actions, token));
              }
            });
  }

  /** عبارةُ الفشلِ كما نَطَقَها المرجعُ: ‏{@code path + " could not be loaded!"} — بلا زيادةٍ ولا نقصٍ. */
  private void toastNotLoaded(String path) {
    android.widget.Toast.makeText(
            getContext(),
            UiStrings.format(getContext(), "ui_error_file_not_loaded", String.valueOf(path)),
            android.widget.Toast.LENGTH_SHORT)
        .show();
  }

  private static final class PendingOpen {
    static final String TEXT = "\u0000shima-pending-open\u0000";
  }

  /** أسماء التبويبات في حالة فتح مؤجل — تقرّر عوضًا عنها الوصول الحقيقي للمحتوى. */
  private final java.util.HashSet<String> openingFiles = new java.util.HashSet<>();

  private void addTab(String name) {
    LinearLayout holder = new LinearLayout(getContext());
    holder.setOrientation(VERTICAL);
    TextView label = text(name, 14, tabLabelColor(false));
    label.setGravity(Gravity.CENTER);
    label.setSingleLine(false);
    label.setMaxLines(2);
    label.setEllipsize(android.text.TextUtils.TruncateAt.END);
    label.setPadding(dp(10), 0, dp(10), 0);
    holder.addView(label, new LinearLayout.LayoutParams(dp(175), 0, 1));
    View line = new View(getContext());
    holder.addView(line, new LinearLayout.LayoutParams(-1, dp(3)));
    holder.setOnClickListener(v -> selectFile(name));
    holder.setOnLongClickListener(
        v -> {
          showTabMenu(v, name);
          return true;
        });
    tabs.put(name, holder);
    tabStrip.addView(holder, new LinearLayout.LayoutParams(dp(175), -1));
  }

  // ======== قائمة الضغط المطول على التبويب — بهيكل filetab_menu المرجعي ========

  /** يُستدعى حين تفرغ التبويبات من قائمة التبويب — تضبطه MainActivity لإظهار الواجهة الفارغة. */
  private Runnable tabsClosedListener;

  public void setTabsClosedListener(Runnable listener) {
    tabsClosedListener = listener;
  }

  /** قائمة التبويب المرجعية: إغلاق (فرعية: إغلاق/إغلاق البقية/إغلاق الكل) + أوامر الجافا. */
  private void showTabMenu(View anchor, String name) {
    android.widget.PopupMenu menu = new android.widget.PopupMenu(getContext(), anchor);
    android.view.SubMenu close =
        menu.getMenu().addSubMenu(0, 401, 0, UiStrings.get(getContext(), "ui_action_close"));
    close.add(0, 402, 0, UiStrings.get(getContext(), "ui_action_close"));
    close.add(0, 403, 1, UiStrings.get(getContext(), "ui_close_others"));
    close.add(0, 404, 2, UiStrings.get(getContext(), "menu_close_all"));
    boolean javaTab = name.toLowerCase(java.util.Locale.US).endsWith(".java");
    if (javaTab) {
      menu.getMenu().add(0, 405, 1, UiStrings.get(getContext(), "command_organize_imports"));
      menu.getMenu().add(0, 406, 2, UiStrings.get(getContext(), "command_format_code"));
    }
    menu.setOnMenuItemClickListener(
        item -> {
          switch (item.getItemId()) {
            case 402:
              closeTab(name);
              return true;
            case 403:
              closeOthers(name);
              return true;
            case 404:
              closeAll();
              saveSession();
              if (tabsClosedListener != null) tabsClosedListener.run();
              return true;
            case 405:
              runOnTab(name, this::organizeImports);
              return true;
            case 406:
              runOnTab(name, this::formatSource);
              return true;
            default:
              return false;
          }
        });
    menu.show();
  }

  /** تنفيذ أمر على تبويب محدد: تحديده أولًا إن لم يكن النشط ثم التنفيذ بعد اكتمال التحميل. */
  private void runOnTab(String name, Runnable command) {
    if (name.equals(activeFile)) {
      command.run();
      return;
    }
    selectFile(name);
    post(
        () -> {
          if (!name.equals(activeFile)) return;
          if (!openingFiles.contains(name)) {
            command.run();
            return;
          }
          // تحميل كسول لم يكتمل بعد — محاولة أخيرة بعد مهلة قصيرة.
          postDelayed(
              () -> {
                if (name.equals(activeFile) && !openingFiles.contains(name)) command.run();
              },
              400);
        });
  }

  /** إغلاق تبويب محدد بالاسم — نفس تنظيف closeCurrent مع اختيار جارٍ للبقاء. */
  public void closeTab(String name) {
    if (name == null || !tabs.containsKey(name)) return;
    LinearLayout tab = tabs.remove(name);
    if (tab != null) tabStrip.removeView(tab);
    dirtyLedger.forget(name); // ج٤٢: لا يَبقَى اسمٌ في الدَّفْتَرِ لا لِسانَ لَهُ فَيدَّعي الحِفظُ نَقصًا
    fileContents.remove(name);
    lazySessionFiles.remove(name);
    lazySessionReferences.remove(name);
    sessionReferences.remove(name);
    sessionCursors.remove(name);
    sessionScrollX.remove(name);
    sessionScrollY.remove(name);
    openingFiles.remove(name);
    boolean wasActive = name.equals(activeFile);
    if (tabs.isEmpty()) {
      activeFile = null;
      code.setText("");
      setVisibility(GONE);
      saveSession();
      if (tabsClosedListener != null) tabsClosedListener.run();
      return;
    }
    if (wasActive) {
      activeFile = null;
      selectFile(tabs.keySet().iterator().next());
    }
    saveSession();
  }

  /** إغلاق كل التبويبات عدا المحدد — بند «إغلاق البقية» المرجعي. */
  public void closeOthers(String name) {
    if (name == null || !tabs.containsKey(name)) return;
    for (String other : new ArrayList<>(tabs.keySet())) {
      if (other.equals(name)) continue;
      LinearLayout tab = tabs.remove(other);
      if (tab != null) tabStrip.removeView(tab);
      fileContents.remove(other);
      lazySessionFiles.remove(other);
      lazySessionReferences.remove(other);
      sessionReferences.remove(other);
      sessionCursors.remove(other);
      sessionScrollX.remove(other);
      sessionScrollY.remove(other);
      openingFiles.remove(other);
    }
    if (!name.equals(activeFile)) {
      activeFile = null;
      selectFile(name);
    }
    saveSession();
  }

  // ======== تفريد أسماء التبويبات — ملفان بنفس الاسم لا يتصادمان (build.gradle الأب/الابن) ========

  /**
   * إن وجد تبويب بنفس الاسم لكن بمرجع مختلف، يُولَّد اسم عرض يتضمن المجلد الأب
   * (app/build.gradle) وصعودًا حتى التفرد، ولاحقة رقمية للمراجع غير المسارية.
   */
  private String uniqueTabNameFor(String name, String reference) {
    String safeReference = reference == null ? "" : reference;
    if (safeReference.isEmpty()) return name;
    if (!collides(name, safeReference)) return name;
    if (safeReference.startsWith("/")) {
      String[] parts = safeReference.replace('\\', '/').split("/");
      String candidate = name;
      for (int up = parts.length - 2; up >= 1; up--) {
        candidate = parts[up] + "/" + candidate;
        if (!collides(candidate, safeReference)) return candidate;
      }
    }
    for (int n = 2; n < 100; n++) {
      String candidate = name + " (" + n + ")";
      if (!collides(candidate, safeReference)) return candidate;
    }
    return name;
  }

  /** تصادم: تبويب موجود بهذا الاسم ومرجعه المعروف مختلف عن المطلوب فتحه. */
  private boolean collides(String name, String reference) {
    if (!tabs.containsKey(name)) return false;
    String existing = sessionReferences.get(name);
    return existing != null && !existing.isEmpty() && !existing.equals(reference);
  }

  private void rememberActiveViewport() {
    if (activeFile == null || code == null) return;
    sessionCursors.put(activeFile, Math.max(0, code.getSelectionStart()));
    sessionScrollX.put(activeFile, Math.max(0, code.getScrollX()));
    sessionScrollY.put(activeFile, Math.max(0, code.getScrollY()));
  }

  private void restoreViewport(String name) {
    int cursor = sessionCursors.containsKey(name) ? sessionCursors.get(name) : 0;
    int x = sessionScrollX.containsKey(name) ? sessionScrollX.get(name) : 0;
    int y = sessionScrollY.containsKey(name) ? sessionScrollY.get(name) : 0;
    code.post(
        () -> {
          if (!name.equals(activeFile)) return;
          code.setSelection(Math.min(Math.max(0, cursor), code.length()));
          code.scrollTo(x, y);
        });
  }

  private void selectFile(String name) {
    goToGeneration++;
    dismissCompletions();
    cancelCompletionLookup();
    // تبديل الملف قبل اكتمال قفزة بحث معلقة في ملف آخر يلغيها حتى لا تنفذ لاحقًا فجأة.
    if (pendingMatchFile != null && !pendingMatchFile.equals(name)) pendingMatchFile = null;
    completionCache.clear();
    rememberActiveViewport();
    if (name != null && !name.equals(activeFile)) pushNavigationPoint();
    // تقرير فتح الملفات — لا نعيد كتابة نص الـ placeholder فوق محتوى الفتح المؤجل.
    if (activeFile != null
        && code != null
        && !activeFile.equals(loadingFile)
        && !openingFiles.contains(activeFile))
      fileContents.put(activeFile, code.getText().toString());
    activeFile = name;
    if (quickKeyBar != null) quickKeyBar.rebuild();
    applyProjectDiagnosticsToActiveFile();
    notifyHistoryState(); // تبديل التبويب يحدّث شريط الأدوات (زر المعاينة/أهلية التراجع).
    for (String key : tabs.keySet()) {
      LinearLayout h = tabs.get(key);
      TextView label = (TextView) h.getChildAt(0);
      boolean active = key.equals(name);
      label.setTextColor(tabLabelColor(active));
      label.setTypeface(null, active ? Typeface.BOLD : Typeface.NORMAL);
      h.getChildAt(1).setBackgroundColor(active ? Color.rgb(41, 182, 246) : Color.TRANSPARENT);
    }
    // الرأس: الاسم القصير (بلا بادئة التفريد) + المسار الحقيقي للملف إن كان مرجعه معروفًا.
    String shortName = name == null ? "" : name.substring(name.lastIndexOf('/') + 1);
    headerName.setText(almlk.EditorDirtyLedger.decorate(shortName, dirtyLedger.isDirty(name)));
    headerIcon.setImageResource(iconForFile(name == null ? "" : name));
    String headerReference = name == null ? null : sessionReferences.get(name);
    if (headerReference != null && headerReference.startsWith("/")) {
      int cut = headerReference.lastIndexOf('/');
      headerPath.setText(cut > 0 ? headerReference.substring(0, cut) : headerReference);
    } else if (name != null
        && name.toLowerCase(java.util.Locale.US).endsWith(".class")) {
      int cut = name.lastIndexOf('/');
      String packageName = cut > 0 ? name.substring(0, cut).replace('/', '.') : "";
      headerPath.setText(
          packageName.isEmpty() ? "Android SDK" : "Android SDK · " + packageName);
    } else headerPath.setText("/storage/emulated/0/AppProjects/" + UiStrings.get(getContext(), "ui_default_project_folder_name") + "/" + shortName);
    historyLocked = true;
    String lazyReference = lazySessionReferences.get(name);
    java.io.File legacyLazyFile = lazySessionFiles.get(name);
    boolean lazyRestore =
        !fileContents.containsKey(name)
            && ((lazyReference != null && !lazyReference.isEmpty()) || legacyLazyFile != null);
    code.setAnalysisPaused(lazyRestore || !analysisArmed);
    code.setFileName(name);
    // Keep the core range model aligned with the currently visible tab before the next setText
    // callback applies the replacement incrementally.
    code.resetCoreModel(name, code.getText());
    if (lazyRestore) {
      loadingFile = name;
      code.setHint(R.string.session_restoring_file);
      code.setText("");
      loadLazySessionReference(
          name, lazyReference != null && !lazyReference.isEmpty()
              ? lazyReference
              : legacyLazyFile.getAbsolutePath());
    } else {
      loadingFile = null;
      code.setHint(null);
      String displayedContent = fileContents.get(name);
      if (PendingOpen.TEXT.equals(displayedContent))
        displayedContent = UiStrings.get(getContext(), "ui_pending_open_file");
      if (displayedContent == null) displayedContent = ProjectSymbolIndex.systemSourceForFile(name);
      code.setText(displayedContent != null ? displayedContent : sample(name));
      restoreViewport(name);
    }
    historyLocked = false;
    code.clearHistory();
    if (!lazyRestore) code.refreshNow();
    scheduleIdleSessionSave();
    lastFileSelectTime = System.currentTimeMillis();
  }

  // تقرير 03 — حفظ الجلسة عند الخمول: metadata فقط بعد 800ms من آخر تنقل بين التبويبات.
  private final Runnable idleSessionSave = this::saveSession;

  private void scheduleIdleSessionSave() {
    removeCallbacks(idleSessionSave);
    postDelayed(idleSessionSave, 800);
  }

  /** تقرير 01/03 — تحرير كاشات الذاكرة المؤقتة عند طلب النظام onTrimMemory. */
  public void trimMemoryCaches() {
    completionCache.clear();
    dismissCompletions();
  }

  /** المرحلة 4: رموز الشريط السريع من الإعداد (quick_key_symbol) أو الافتراضيات. */

  /** المرحلة 4: خط/خلفية/شريط سريع من الإعدادات المتقدمة. */
  public void applyAdvancedSettings() {
    if (code == null) return;
    android.content.SharedPreferences sp = almlk.AppSettings.prefs(getContext());
    code.setFontPath(sp.getString("advanced_setting_editor_font", ""));
    code.setBackgroundImagePath(sp.getString("advanced_setting_editor_bg", ""));
    if (quickKeyBar != null) quickKeyBar.rebuild();
  }

  /** المرحلة 1: تطبيق إعدادات المحرر (خط/حجم تبويب/شريط تبويبات) من المصدر الموحّد. */
  public void applyEditorSettings() {
    if (code == null) return;
    android.content.Context settingsCtx = getContext();
    code.setTextSizePx(
        getResources().getDisplayMetrics().scaledDensity
            * almlk.AppSettings.fontSizeSp(settingsCtx));
    code.setTabSizeChars(almlk.AppSettings.tabSize(settingsCtx));
    if (tabStrip != null)
      tabStrip.setVisibility(almlk.AppSettings.editorTabs(settingsCtx) ? VISIBLE : GONE);
  }

  private volatile boolean pendingEdits;

  /** ج٤٢: أيُّ لِسَانٍ علَيهِ ما لم يُحفَظْ — لا النَّشِطُ وَحدَهُ (حِفظُ الكلِّ والعَلامَةُ والفَحصُ القَبلِيُّ). */
  private final almlk.EditorDirtyLedger dirtyLedger = new almlk.EditorDirtyLedger();

  public boolean hasPendingEdits() {
    return pendingEdits;
  }

  /** لِساناتٌ فيها تَعدِيلٌ لم يُحفَظْ، بأَولَوِيَّةِ التَّغَيُّرِ (الحِفظُ الجُمَلِيُّ يَقرَأُها هَكَذا). */
  public java.util.List<String> dirtyTabs() {
    return dirtyLedger.dirtyTabs();
  }

  public boolean isTabDirty(String name) {
    return dirtyLedger.isDirty(name);
  }

  /**
   * نَصُّ اللِّسانِ كما هُوَ الآنَ: النَّشِطُ من المُحرِّرِ الحَيِّ، وغَيرُهُ من مُخَزَّنِهِ الذي
   * يُزاَمِنُهُ عندَ كُلِّ تَبديلٍ وحِفظٍ. وحِفظُ ما لا نَصَّ لَهُ آيَتُهُ null: يَنتَقِلُ الحافِظُ إلى
   * التَّالِي، فَلا نَكتُبُ فَرًا على القُرسِ ولا نُمحُو ما فيهِ.
   */
  public String textOf(String name) {
    if (name == null) return null;
    if (name.equals(activeFile) && code != null) return code.getText().toString();
    return fileContents.containsKey(name) ? fileContents.get(name) : null;
  }

  /** الاسمُ كما يُعرَضُ على اللِّسانِ والرَّأسِ — مِنبَرُ عَلامَةِ التَّغَيُّرِ الواحِدُ (‏EditorDirtyLedger`‏). */
  public String tabLabel(String name) {
    return almlk.EditorDirtyLedger.decorate(name, dirtyLedger.isDirty(name));
  }

  /** عِندَ أوَّلِ تَغيِيرٍ فَقط: فَلا مَسحَ نَصٍّ على اللَّوحَةِ معَ كُلِّ ضَغنَةِ مِفتاحٍ. */
  private void markActiveDirty() {
    if (activeFile == null || dirtyLedger.isDirty(activeFile)) return;
    dirtyLedger.mark(activeFile);
    refreshTabLabel(activeFile);
    if (headerName != null) headerName.setText(tabLabel(shortTabName(activeFile)));
  }

  private static String shortTabName(String name) {
    if (name == null) return "";
    int slash = name.lastIndexOf('/');
    return slash < 0 ? name : name.substring(slash + 1);
  }

  private void refreshTabLabel(String name) {
    LinearLayout holder = name == null ? null : tabs.get(name);
    if (holder == null || holder.getChildCount() == 0) return;
    if (holder.getChildAt(0) instanceof TextView)
      ((TextView) holder.getChildAt(0)).setText(tabLabel(name));
  }

  /** بَعدَ حِفظٍ قَرصِيٍّ (فَحصٌ أَصلَحَ مِلَفًّا، أو حِفظٌ جُمَلِيٌّ): تُرفَعُ العَلامَةُ عن لِسانِهِ. */
  public void markTabSaved(String name) {
    if (name == null || !dirtyLedger.isDirty(name)) return;
    dirtyLedger.clear(name);
    refreshTabLabel(name);
    notifyHistoryState();
    if (name.equals(activeFile) && headerName != null)
      headerName.setText(tabLabel(shortTabName(activeFile)));
  }

  /**
   * M5 «تحويل المشروع»: تحديث التبويبات المفتوحة بمحتوى كتبته أداة على القرص (المرجع ← النص)
   * دون إعادة فتح المشروع؛ التبويب النشط يحتفظ بموضعه ويُمسح سجل تراجعه لأن الأساس تغيّر.
   */
  public void reloadReferences(java.util.Map<String, String> contentByPath) {
    if (contentByPath == null || contentByPath.isEmpty()) return;
    for (java.util.Map.Entry<String, String> tab : new java.util.ArrayList<>(sessionReferences.entrySet())) {
      String content = contentByPath.get(tab.getValue());
      if (content == null) continue;
      String name = tab.getKey();
      fileContents.put(name, content);
      if (!name.equals(activeFile) || code == null) continue;
      rememberActiveViewport();
      historyLocked = true;
      code.setText(content);
      historyLocked = false;
      code.clearHistory();
      code.refreshNow();
      restoreViewport(name);
      pendingEdits = false;
      dirtyLedger.clear(name);
      refreshTabLabel(name);
    }
  }

  public void markSaved() {
    pendingEdits = false;
    if (activeFile == null) return;
    dirtyLedger.clear(activeFile);
    refreshTabLabel(activeFile);
    if (headerName != null) headerName.setText(tabLabel(shortTabName(activeFile)));
    notifyHistoryState(); // أهليةُ «احفَظِ الكُلَّ» تبدَّلتْ: قُلْ لِلَّوحَةِ، ولا تَدَعْها تَحدُسُ
  }

  /** بند 3 — إعادة لوحة المفاتيح إلى وضعها الظاهر بعد الانتقال أو القوائم دون اهتزاز. */
  public void ensureKeyboardVisible() {
    if (code == null) return;
    boolean hardKeyboard =
        getResources().getConfiguration().keyboard
            != android.content.res.Configuration.KEYBOARD_NOKEYS;
    if (hardKeyboard && !almlk.AppSettings.forceSoftKeyboard(getContext())) return;
    code.requestFocus();
    android.view.inputmethod.InputMethodManager imm =
        (android.view.inputmethod.InputMethodManager)
            getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
    imm.showSoftInput(code, 0);
  }

  // ===== سجل التنقل: «العودة» تعيد الكلاس والموضع السابق بعد الانتقال لعنصر أو تبديل ملف =====
  private static final class NavPoint {
    String file;
    int offset;
    int scrollY;
  }
  private final ArrayDeque<NavPoint> navigationBackStack = new ArrayDeque<>();
  private boolean navRestore;
  private long lastFileSelectTime;

  private void pushNavigationPoint() {
    if (!almlk.AppSettings.prefs(getContext()).getBoolean("experimental_nav_history", true)) return;
    if (navRestore || activeFile == null || code == null) return;
    int offset = Math.max(0, code.getSelectionStart());
    NavPoint top = navigationBackStack.peek();
    // لا تكرار لنفس الموضع تقريبًا حتى لا يضغط المستخدم «عودة» بلا أثر ظاهر.
    if (top != null
        && top.file != null
        && top.file.equals(activeFile)
        && Math.abs(top.offset - offset) < 40) return;
    NavPoint point = new NavPoint();
    point.file = activeFile;
    point.offset = offset;
    point.scrollY = code.getScrollY();
    navigationBackStack.push(point);
    while (navigationBackStack.size() > 50) navigationBackStack.removeLast();
  }

  /** يعيد آخر كلاس/موضع قبل الانتقال. true إن وُجدت نقطة رجوع. */
  public boolean navigateBack() {
    while (!navigationBackStack.isEmpty()) {
      final NavPoint point = navigationBackStack.pop();
      if (point == null || point.file == null || !tabs.containsKey(point.file)) continue;
      navRestore = true;
      try {
        if (!point.file.equals(activeFile)) selectFile(point.file);
        code.post(
            () -> {
              if (code == null) return;
              code.setSelection(Math.max(0, Math.min(point.offset, code.length())));
              code.scrollTo(code.getScrollX(), Math.max(0, point.scrollY));
            });
      } finally {
        code.post(() -> navRestore = false);
      }
      return true;
    }
    return false;
  }

  /** الانتقال الفوري: إن كان الملف مفتوحًا في تبويب يُفعَّل مباشرة — بلا قراءة ولا عمال. */
  public boolean activateTabIfOpen(String name) {
    if (name == null || !tabs.containsKey(name)) return false;
    selectFile(name);
    return true;
  }

  private void loadLazySessionReference(String name, String reference) {
    sessionWorker.execute(
        () -> {
          String restored = "";
          Throwable error = null;
          try {
            restored = fileRepository.readTextBlocking(reference, name, 8 * 1024 * 1024);
          } catch (Throwable failure) {
            error = failure;
          }
          final String value = restored;
          final Throwable failure = error;
          post(
              () -> {
                if (failure == null) {
                  lazySessionReferences.remove(name);
                  lazySessionFiles.remove(name);
                  fileContents.put(name, value);
                }
                // تقرير AIDE — بروتوكول CurrentFiles_: فشل القراءة (مثلًا غياب صلاحية التخزين)
                // لا يحذف مراجع الجلسة؛ تبقى قابلة للاسترجاع عبر retryLazySessionReferences().
                if (!name.equals(activeFile)) return;
                if (name.equals(loadingFile) && code.length() == 0) {
                  historyLocked = true;
                  code.setHint(failure == null ? null : UiStrings.get(getContext(), "ui_error_open_file_utf8"));
                  code.setText(
                      failure == null
                          ? value
                          : UiStrings.format(
                              getContext(), "ui_error_open_file_details", UiStrings.message(getContext(), failure)));
                  historyLocked = false;
                  loadingFile = null;
                  restoreViewport(name);
                  code.setAnalysisPaused(!analysisArmed);
                  // بند 1 — التلوين يطبق فور اكتمال الفتح، بلا تأخير.
                  code.post(code::refreshNow);
                  // قفزة نتيجة بحث مؤجلة: تنفذ بعد حقن المحتوى واستعادة العرض (ترتيب المرجع).
                  if (failure == null && name.equals(pendingMatchFile)) {
                    final int line = pendingMatchLine, column = pendingMatchColumn;
                    final int endColumn = pendingMatchEndColumn;
                    final boolean actions = pendingMatchActions;
                    pendingMatchFile = null;
                    code.post(() -> jumpToRange(line, column, endColumn, actions));
                  }
                } else if (name.equals(loadingFile)) {
                  loadingFile = null;
                  code.setHint(null);
                  code.setAnalysisPaused(false);
                  code.post(code::refreshNow);
                }
              });
        });
  }

  /**
   * تقرير AIDE — استعادة ما تعذّر فتحه (غياب إذن التخزين مثلًا): نعيد تحميل كل تبويب ما
   * تزال مراجعه محفوظة ولم يُملأ محتواه. آمنة التكرار وتستدعى بعد منح الصلاحية/عند العودة.
   */
  public void retryLazySessionReferences() {
    if (lazySessionReferences.isEmpty()) return;
    final ArrayList<String> pending = new ArrayList<>();
    final ArrayList<String> refs = new ArrayList<>();
    for (Map.Entry<String, String> pendingRef : lazySessionReferences.entrySet()) {
      if (fileContents.containsKey(pendingRef.getKey())) continue;
      pending.add(pendingRef.getKey());
      refs.add(pendingRef.getValue());
    }
    for (int i = 0; i < pending.size(); i++) {
      loadLazySessionReference(pending.get(i), refs.get(i));
    }
  }

  private boolean isXmlFile() {
    return almlk.XmlCodeFormatter.isXmlName(activeFile);
  }

  private void completeXmlClosingTag(int marker) {
    String text = code.getText().toString();
    if (text.isEmpty() || marker < 2 || marker > text.length()) return;
    if (text.charAt(marker - 2) != '<' || text.charAt(marker - 1) != '/') return;
    String tag = findUnclosedXmlTag(text, marker - 2);
    if (tag == null || tag.isEmpty()) return;
    historyLocked = true;
    if (marker < text.length() && text.charAt(marker) == '>') {
      code.replaceRange(marker, marker, tag);
      code.setSelection(marker + tag.length() + 1);
    } else {
      code.replaceRange(marker, marker, tag + ">");
      code.setSelection(marker + tag.length() + 1);
    }
    historyLocked = false;
  }

  private String findUnclosedXmlTag(CharSequence text, int limit) {
    ArrayDeque<String> stack = new ArrayDeque<>();
    int i = 0;
    while (i < limit) {
      int open = indexOf(text, '<', i, limit);
      if (open < 0 || open + 1 >= limit) break;
      if (startsWith(text, open, "<!--")) {
        int close = indexOf(text, "-->", open + 4, limit);
        i = close < 0 ? limit : close + 3;
        continue;
      }
      int close = xmlTagEnd(text, open + 1, limit);
      if (close < 0) {
        int nameStart = open + 1;
        while (nameStart < limit && Character.isWhitespace(text.charAt(nameStart))) nameStart++;
        int nameEnd = nameStart;
        while (nameEnd < limit && isXmlNameCharacter(text.charAt(nameEnd))) nameEnd++;
        if (nameEnd > nameStart) stack.push(text.subSequence(nameStart, nameEnd).toString());
        break;
      }
      char kind = text.charAt(open + 1);
      if (kind != '!' && kind != '?') {
        boolean closing = kind == '/';
        int nameStart = open + (closing ? 2 : 1);
        while (nameStart < close && Character.isWhitespace(text.charAt(nameStart))) nameStart++;
        int nameEnd = nameStart;
        while (nameEnd < close && isXmlNameCharacter(text.charAt(nameEnd))) nameEnd++;
        if (nameEnd > nameStart) {
          String name = text.subSequence(nameStart, nameEnd).toString();
          if (closing) {
            while (!stack.isEmpty()) {
              String current = stack.pop();
              if (current.equals(name)) break;
            }
          } else {
            int tail = close - 1;
            while (tail > nameEnd && Character.isWhitespace(text.charAt(tail))) tail--;
            if (text.charAt(tail) != '/') stack.push(name);
          }
        }
      }
      i = close + 1;
    }
    return stack.isEmpty() ? null : stack.peek();
  }

  private int xmlTagEnd(CharSequence text, int from, int limit) {
    char quote = 0;
    for (int i = from; i < limit; i++) {
      char value = text.charAt(i);
      if (quote != 0) {
        if (value == quote) quote = 0;
      } else if (value == '"' || value == '\'') quote = value;
      else if (value == '>') return i;
    }
    return -1;
  }

  private boolean isXmlNameCharacter(char value) {
    return Character.isLetterOrDigit(value)
        || value == '_'
        || value == '-'
        || value == ':'
        || value == '.';
  }

  private int indexOf(CharSequence text, char needle, int from, int limit) {
    for (int i = Math.max(0, from); i < Math.min(limit, text.length()); i++)
      if (text.charAt(i) == needle) return i;
    return -1;
  }

  private int indexOf(CharSequence text, String needle, int from, int limit) {
    int last = Math.min(limit, text.length()) - needle.length();
    for (int i = Math.max(0, from); i <= last; i++) {
      if (startsWith(text, i, needle)) return i;
    }
    return -1;
  }

  private boolean startsWith(CharSequence text, int offset, String value) {
    if (offset < 0 || offset + value.length() > text.length()) return false;
    for (int i = 0; i < value.length(); i++)
      if (text.charAt(offset + i) != value.charAt(i)) return false;
    return true;
  }

  public void applyTheme() {
    ThemeConfig theme = new ThemeConfig(getContext());
    int background = theme.color(ThemeConfig.BACKGROUND);
    int plain = theme.color(ThemeConfig.PLAIN);
    int chrome = theme.isDark() ? Color.rgb(34, 34, 34) : Color.rgb(238, 238, 238);
    setBackgroundColor(background);
    if (editorRow != null) editorRow.setBackgroundColor(background);
    if (fileHeader != null) fileHeader.setBackgroundColor(background);
    if (tabStrip != null) {
      tabStrip.setBackgroundColor(chrome);
      if (tabStrip.getParent() instanceof View)
        ((View) tabStrip.getParent()).setBackgroundColor(chrome);
    }
    if (headerName != null) headerName.setTextColor(plain);
    if (headerPath != null) headerPath.setTextColor(theme.isDark() ? Color.LTGRAY : Color.DKGRAY);
    if (code != null) code.applyTheme();
    for (LinearLayout holder : tabs.values()) {
      TextView label = (TextView) holder.getChildAt(0);
      label.setTextColor(tabLabelColor(holder == tabs.get(activeFile)));
    }
  }

  public boolean hasOpenFile() {
    return activeFile != null;
  }

  /** Go To يُسمح به فقط على عنصر اختاره المستخدم صراحةً في موضعه الحالي. */
  public boolean hasExplicitEditorSelection() {
    return code != null && code.getSelectionStart() != code.getSelectionEnd();
  }

  /** أهلية الكتابة الحية نفسها التي يستهلكها سجل أوامر المحرر. */
  public boolean isActiveFileWritableNow() {
    return isActiveFileWritable();
  }

  public String getActiveFile() {
    return activeFile;
  }

  /** استبدال محتوى التبويب النشط بنص المصمم — عبر موديل المحرك فيبقى قابلًا للتراجع ويُحفظ تلقائيًا. */
  /** يُدرج نصًا مكان التحديد/المؤشر (Json2Bean › إضافة إلى المحرر)؛ false بلا ملف قابل للكتابة. */
  public boolean insertAtCursor(String value) {
    if (code == null || value == null || activeFile == null || !isActiveFileWritable()) return false;
    int length = code.getText().length();
    int a = Math.max(0, Math.min(code.getSelectionStart(), length));
    int b = Math.max(0, Math.min(code.getSelectionEnd(), length));
    code.replaceRange(Math.min(a, b), Math.max(a, b), value);
    return true;
  }

  public void replaceActiveContent(String newText) {
    if (code == null || newText == null || activeFile == null || !isActiveFileWritable()) return;
    String current = code.getText().toString();
    if (current.equals(newText)) return;
    code.replaceRange(0, current.length(), newText);
  }

  /** نص التحديد إن وجد وإلا الكلمة تحت المؤشر — قناة أمر التوثيق المرجعي. */
  /**
   * استعلام التوثيق — المرحلة السابعة.
   *
   * <p>في XML يُقرأ مرجع المورد ويُستعلم بنوعه واسمه (فالاسم المجرّد وحده غامض)، وفي غير XML
   * تبقى الكلمة تحت المؤشر كما كانت.
   */
  public String documentationQuery() {
    if (code == null) return "";
    String text = code.getText().toString();
    if (isXmlFile() && text != null && !text.isEmpty()) {
      int offset = Math.max(0, Math.min(code.getSelectionStart(), text.length() - 1));
      almlk.XmlResourceReference reference = almlk.XmlResourceReference.at(text, offset);
      if (reference != null) {
        return reference.framework
            ? "android R." + reference.type + " " + reference.name
            : reference.type + " " + reference.name;
      }
    }
    return selectedOrCursorWord();
  }

  public String selectedOrCursorWord() {
    if (code == null) return "";
    String text = code.getText().toString();
    int start = Math.max(0, Math.min(code.getSelectionStart(), text.length()));
    int end = Math.max(0, Math.min(code.getSelectionEnd(), text.length()));
    if (start != end) return text.substring(Math.min(start, end), Math.max(start, end)).trim();
    int back = start;
    while (back > 0 && Character.isJavaIdentifierPart(text.charAt(back - 1))) back--;
    int forward = start;
    while (forward < text.length() && Character.isJavaIdentifierPart(text.charAt(forward)))
      forward++;
    return back < forward ? text.substring(back, forward) : "";
  }

  /** أسماء التبويبات المفتوحة بترتيبها — لقائمة «قائمة الملفات المفتوحة» المرجعية. */
  public java.util.List<String> openFileNames() {
    return new java.util.ArrayList<>(tabs.keySet());
  }

  /** تفعيل تبويب مفتوح بالاسم — قناة حوار الملفات المفتوحة. */
  public void showOpenFile(String name) {
    if (name != null && tabs.containsKey(name)) selectFile(name);
  }

  /** المرجع المستقر للتبويب النشط (مسار كامل أو SAF URI) — الاسم وحده لا يكفي لفحص الموقع. */
  public String getActiveFileReference() {
    if (activeFile == null) return "";
    String reference = sessionReferences.get(activeFile);
    return reference == null ? "" : reference;
  }

  public String getTextContent() {
    return code == null ? "" : code.getText().toString();
  }

  public void undoEdit() {
    if (code.undo()) code.requestFocus();
    notifyHistoryState();
  }

  public void redoEdit() {
    if (code.redo()) code.requestFocus();
    notifyHistoryState();
  }

  // ===== شريط وضع التحرير (دلالة المرجع): إشعار فوري بتغير أهلية التراجع/الإعادة =====
  private Runnable historyStateListener;

  public void setHistoryStateListener(Runnable listener) {
    historyStateListener = listener;
  }

  private void notifyHistoryState() {
    if (historyStateListener != null) historyStateListener.run();
  }

  /** حالة سجل التراجع للمحرك — تغذّي أهلية أمري undo/redo قبل عرض أي قائمة. */
  public boolean canUndoEdit() {
    return code != null && code.canUndo();
  }

  public boolean canRedoEdit() {
    return code != null && code.canRedo();
  }

  /** تعليق/إلغاء تعليق أسطر التحديد — استبدال واحد على موديل المحرك قابل للتراجع. */
  public void toggleLineComment() {
    applyLineComment(null);
  }

  /** أمر المرجع «Outcomment Code»: تعليق صريح لأسطر التحديد. */
  public void commentLines() {
    applyLineComment(Boolean.TRUE);
  }

  /** أمر المرجع «Un-Outcomment Code»: فك طبقة تعليق واحدة عن أسطر التحديد. */
  public void uncommentLines() {
    applyLineComment(Boolean.FALSE);
  }

  private void applyLineComment(Boolean force) {
    if (code == null || !isActiveFileWritable()) return;
    // XML has its own comment grammar; Java-style // is never inserted into markup.
    if (isXmlFile()) {
      applyXmlComment(force);
      return;
    }
    String text = code.getText().toString();
    almlk.CodeMenuCommands.Edit edit =
        almlk.CodeMenuCommands.commentLines(
            text, code.getSelectionStart(), code.getSelectionEnd(), force);
    if (edit == null) return;
    code.replaceRange(edit.start, edit.end, edit.replacement);
    code.setSelection(
        Math.min(edit.selectionStart, code.length()), Math.min(edit.selectionEnd, code.length()));
    code.refreshNow();
  }

  /**
   * تعليق/فك تعليق XML عبر محرك {@code almlk} — استبدال واحد قابل للتراجع.
   *
   * <p>الرفض يظهر سببًا صريحًا بدل الفشل الصامت، ولا تُكتب أي بايتة عند الرفض.
   */
  private void applyXmlComment(Boolean force) {
    String text = code.getText().toString();
    int selStart = code.getSelectionStart();
    int selEnd = code.getSelectionEnd();
    almlk.XmlCommentEditor.Outcome outcome =
        force == null
            ? almlk.XmlCommentEditor.toggle(text, selStart, selEnd)
            : force
                ? almlk.XmlCommentEditor.comment(text, selStart, selEnd)
                : almlk.XmlCommentEditor.uncomment(text, selStart, selEnd);
    if (outcome == null) return;
    if (!outcome.applies()) {
      Toast.makeText(getContext(), UiStrings.get(getContext(), outcome.rejection), Toast.LENGTH_SHORT).show();
      return;
    }
    if (outcome.start < 0 || outcome.end > code.length() || outcome.start > outcome.end) return;
    code.replaceRange(outcome.start, outcome.end, outcome.text);
    int caret = Math.min(outcome.start + outcome.text.length(), code.length());
    code.setSelection(outcome.start, caret);
    code.refreshNow();
  }

  /** ينظم imports فعلية ويضيف مرشّحات حزم المشروع دون تغيير جسم الملف خارج كتلة الترويسة. */
  public void organizeImports() {
    if (code == null || isXmlFile() || !isActiveFileWritable()) return;
    String text = code.getText().toString();
    // W5′: المرشَّحات كلها من JavaImportResolver (المشروع ← الكتلة المصونة ← فهرس المنصّة)،
    // فهي والقاعدة التي يلصق بها التشخيصُ إصلاحَه مصدرٌ واحد — لا حلقةَ فهرسٍ موازية.
    ArrayList<String> candidates = new ArrayList<>();
    for (String className : JavaImportOrganizer.classLikeIdentifiers(text)) {
      candidates.addAll(almlk.JavaImportResolver.candidatesFor(className));
    }
    String organized = JavaImportOrganizer.organize(
        text, candidates, almlk.CodeStyle.maxSingleImports(getContext()));
    if (organized == null || organized.equals(text)) {
      Toast.makeText(getContext(), UiStrings.get(getContext(), "ui_imports_already_organized"), Toast.LENGTH_SHORT).show();
      return;
    }
    // الإصلاحُ لا ينقلُ المؤشّرَ ولا الشاشةَ: ترويسةُ الاستيراداتِ وحدَها تُستبدَلُ (جسمُ الملفِّ
    // خارجُ كتلةِ الترويسةِ لا يمسُّهُ المنظِّمُ أصلًا)، والمؤشّرُ يُزاحُ مع نصِّهِ داخلَ سياسةِ
    // صونِ المؤشّرِ — فلا setSelection ولا كشفَ ولا قفزةَ إلى السطرِ الأولِ.
    int firstType = JavaImportOrganizer.firstTypeOffset(text);
    int newFirstType = JavaImportOrganizer.firstTypeOffset(organized);
    if (firstType >= 0
        && newFirstType >= 0
        && organized.substring(newFirstType).equals(text.substring(firstType))) {
      code.replaceRange(0, firstType, organized.substring(0, newFirstType), true);
    } else {
      code.replaceRange(0, text.length(), organized, true);
    }
    // والإصلاحُ لا يستأنفُ جولةَ تلوينٍ كلّيّةٍ: إشعارُ المستندِ يعيدُ الأكسَاءَ من سطرِ الترويسةِ
    // إلى آخرِ ملفٍ بنفسِهِ (فوقَهُ تُبطَلُ النتائجُ البائتةِ وتُعادُ)، فـ«refreshNow» كانت تلغي
    // الجولةَ الجاريةَ وتعيدُها من الصفرِ — عملٌ مضاعفٌ كلَّ تنظيمٍ بلا فائدةٍ، وهو ما كانَ يُبطِئُ
    // المواكبةَ بعدَ الإصلاحِ. وقناةُ الفحصِ صارتْ مستقلّةً عن قناةِ النحوِ بهذا المعنى.
    Toast.makeText(getContext(), UiStrings.get(getContext(), "ui_imports_organized"), Toast.LENGTH_SHORT).show();
  }

  /** «الإحاطة بـ try/catch»: يحول نطاق الأسطر إلى تعديل واحد قابل للتراجع. */
  public void surroundWithTryCatch() {
    if (code == null || isXmlFile() || !isActiveFileWritable()) return;
    String text = code.getText().toString();
    int indentSize = almlk.CodeStyle.indentSizeFor(getContext(), activeFile);
    StringBuilder indentUnit = new StringBuilder();
    for (int i = 0; i < indentSize; i++) indentUnit.append(' ');
    almlk.CodeMenuCommands.Edit edit = almlk.CodeMenuCommands.surroundWithTryCatch(
        text, code.getSelectionStart(), code.getSelectionEnd(), indentUnit.toString());
    if (edit == null) return;
    code.replaceRange(edit.start, edit.end, edit.replacement);
    code.setSelection(
        Math.min(edit.selectionStart, code.length()), Math.min(edit.selectionEnd, code.length()));
    code.refreshNow();
  }

  /** مستمع أوامر المضيف: عناصر القائمة التي تنفذ حوارات/أوامر IDE (بحث/استبدال/إغلاق). */
  public interface HostCommandListener {
    void run(String commandId);
    default void run(String commandId, String argument) { run(commandId); }
  }

  private HostCommandListener hostCommandListener;

  public void setHostCommandListener(HostCommandListener listener) {
    hostCommandListener = listener;
  }

  private void runHostCommand(String commandId) {
    HostCommandListener listener = hostCommandListener;
    if (listener != null) listener.run(commandId);
  }

  private void runHostCommand(String commandId, String argument) {
    HostCommandListener listener = hostCommandListener;
    if (listener != null) listener.run(commandId, argument == null ? "" : argument);
  }

  /** أمر «تحديد الكل» من الفهرس/القوائم — يمر عبر تحديد المحرك نفسه. */
  public void selectAllText() {
    if (code == null) return;
    code.requestFocus();
    code.selectAll();
  }

  /** يحوّل عنصر قائمة تحديد مدمجًا إلى أيقونة تولبار دائمة كما في تولبار المرجع. */
  private void styleSelectionIcon(android.view.Menu menu, int id, int iconRes) {
    android.view.MenuItem item = menu.findItem(id);
    if (item == null) return;
    item.setIcon(iconRes);
    item.setShowAsAction(android.view.MenuItem.SHOW_AS_ACTION_ALWAYS);
  }

  /** أيقونة القلم: دخول وضع التحرير مباشرة — تركيز المحرر وإظهار لوحة المفاتيح. */
  public boolean beginEditingSession() {
    if (code == null || activeFile == null) return false;
    code.requestFocus();
    android.view.inputmethod.InputMethodManager imm =
        (android.view.inputmethod.InputMethodManager)
            getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
    if (imm != null) imm.showSoftInput(code, 0);
    return true;
  }

  public boolean findText(String query) {
    return findText(query, false, false, false, true);
  }

  /** Finds the next local-document match without scanning the rest of the project. */
  public boolean findText(
      String query, boolean caseSensitive, boolean wholeWord, boolean regularExpression,
      boolean forward) {
    if (query == null || query.isEmpty() || code == null) return false;
    String text = code.getText().toString();
    EditorSearchEngine.Query search =
        new EditorSearchEngine.Query(query, caseSensitive, wholeWord, regularExpression);
    int at;
    int end;
    if (regularExpression) {
      List<EditorSearchEngine.Match> matches = EditorSearchEngine.findAll(text, search, 50000);
      EditorSearchEngine.Match selected = null;
      if (forward) {
        int from = Math.max(0, code.getSelectionEnd());
        for (EditorSearchEngine.Match match : matches) {
          if (match.start >= from) { selected = match; break; }
        }
        if (selected == null && !matches.isEmpty()) selected = matches.get(0);
      } else {
        int before = Math.max(0, code.getSelectionStart());
        for (EditorSearchEngine.Match match : matches) {
          if (match.start < before) selected = match;
          else break;
        }
        if (selected == null && !matches.isEmpty()) selected = matches.get(matches.size() - 1);
      }
      if (selected == null) return false;
      at = selected.start;
      end = selected.end;
    } else {
      at = forward
          ? EditorSearchEngine.findNext(text, search, Math.max(0, code.getSelectionEnd()), true)
          : EditorSearchEngine.findPrevious(text, search, Math.max(0, code.getSelectionStart()), true);
      if (at < 0) return false;
      end = Math.min(text.length(), at + query.length());
    }
    if (at < 0) return false;
    code.requestFocus();
    code.setSelection(at, end);
    final int destination = at;
    code.post(() -> code.bringPointIntoView(destination));
    return true;
  }

  public int replaceAll(String from, String to) {
    return replaceAll(from, to, false, false, false);
  }

  /** Replaces matches in the active document and keeps the cursor near its previous location. */
  public int replaceAll(
      String from, String to, boolean caseSensitive, boolean wholeWord, boolean regularExpression) {
    if (from == null || from.isEmpty() || code == null) return 0;
    String before = code.getText().toString();
    EditorSearchEngine.Query search =
        new EditorSearchEngine.Query(from, caseSensitive, wholeWord, regularExpression);
    List<EditorSearchEngine.Match> matches = EditorSearchEngine.findAll(before, search, 50000);
    if (matches.isEmpty()) return 0;
    int cursor = Math.max(0, code.getSelectionStart());
    String updated = EditorSearchEngine.replaceAll(before, search, to);
    historyLocked = true;
    code.setText(updated);
    historyLocked = false;
    code.setSelection(Math.min(cursor, code.length()));
    code.refreshNow();
    return matches.size();
  }

  /** Runs the expensive match/build phase away from the UI thread, then applies one edit. */
  public void replaceAllAsync(
      String from,
      String to,
      boolean caseSensitive,
      boolean wholeWord,
      boolean regularExpression,
      ReplaceListener listener) {
    if (code == null || from == null || from.isEmpty()) {
      if (listener != null) post(() -> listener.completed(0));
      return;
    }
    final String before = code.getText().toString();
    final int cursor = Math.max(0, code.getSelectionStart());
    final EditorSearchEngine.Query search =
        new EditorSearchEngine.Query(from, caseSensitive, wholeWord, regularExpression);
    completionLookupWorker.execute(
        () -> {
          List<EditorSearchEngine.Match> matches =
              EditorSearchEngine.findAll(before, search, 50000);
          if (matches.isEmpty()) {
            post(() -> { if (listener != null) listener.completed(0); });
            return;
          }
          final String updated = EditorSearchEngine.replaceAll(before, search, to);
          post(() -> {
            if (code == null || !before.equals(code.getText().toString())) {
              if (listener != null) listener.completed(0);
              return;
            }
            historyLocked = true;
            code.setText(updated);
            historyLocked = false;
            code.setSelection(Math.min(cursor, code.length()));
            code.refreshNow();
            if (listener != null) listener.completed(matches.size());
          });
        });
  }

  // ===== الانتقال الدقيق لنتيجة بحث: بالسطر/العمود على النص الحي كما في المرجع =====
  private String pendingMatchFile;
  private int pendingMatchLine, pendingMatchColumn;
  /** نهاية مدى التشخيص (عمود 1-based حصري) أو -1 لتحديد الكلمة عند الموضع (نتائج البحث). */
  private int pendingMatchEndColumn = -1;
  private boolean pendingMatchActions;
  /** ‏W27/2: القفزةُ المُضيَّقةُ إلى الرمزِ (مدىً أوسعُ من رمزٍ) — تُحفَظُ معَ المؤجَّلةِ ولا تَسقُطُ. */
  private boolean pendingMatchToken;

  /**
   * ينتقل لموضع تطابق (سطرٌ/عمودٌ/عمودٌ نهائيٌّ حصريٌّ) في ملفٍّ. إن كانَ محتوى الملفِّ قيدَ
   * التحميلِ الكسولِ تُؤجَّلُ القفزةُ حتى اكتمالَ الحقنِ — نفسَ ترتيبَ المرجعِ: الفتحَ يسبقُ القفزةَ دائمًا.
   * و‏{@code endColumn} مَدًى صفٍّ حقيقيٌّ من {@link com.almlkid.kay.ui.UsageSearchEngine.Usage}؛
   * لا قفزةً بلا مَدًى حيثُ كانَ المَدًى مَعلومًا (ورقةُ W31 §٥/٤).
   */
  public boolean goToMatch(String name, int line, int column, int endColumn) {
    // ‏W31: الصفُّ يَحملُ مَدَاهُ — لا ‏-1 الذي يَترُكُ القفزةَ بلا تحديدٍ ولا كلمةً تُخمَّنُ تحتَ
    // المؤشِّرِ؛ ومدًى فارغٌ (endColumn == column) يبقى توسيطًا بلا تحديدٍ، كقاعدةِ المرجعِ.
    return goToDiagnostic(name, line, column, endColumn, false);
  }

  /**
   * انتقال إلى تشخيص كما في المرجع: يحدد **المدى الكامل** للخطأ (لا الكلمة فقط) ويمرّر إليه، ومع
   * {@code showActions} يفتح شريط «تحديد الإجراءات» على المدى المحدد (الضغط المطوّل في اللوحة)،
   * وتظهر رسالة الخطأ في الفقاعة. {@code endColumn} عمود 1-based حصري، أو -1 لتحديد الكلمة.
   */
  public boolean goToDiagnostic(
      String name, int line, int column, int endColumn, boolean showActions) {
    return goToDiagnostic(name, line, column, endColumn, showActions, false);
  }

  /**
   * ‏W27/2 (ملحقُ ‏W27/2): {@code tokenOnly} يَجعَلُ التحديدَ على المُعرِّفِ عندَ بدايةِ التشخيصِ لا على
   * مداهُ كلُّهُ — طلبُ المستخدمِ «مع تحديدِ الرمزِ المُخطِئِ». والمَدى يَبقى هو المرجعُ للفقاعةِ
   * وشريطِ الإجراءاتِ، فلا يَفقدُ المُستَعمِلُ ما كانَ عندَهُ؛ والقفزةُ المؤجَّلةُ (ملفٌّ يُحمَلُ كسلًا)
   * تَحملُ العلامةَ معَها فلا تنقَلِبُ قفزةٌ عاديّةٌ عندَ اكتمالِ الحقنِ.
   */
  public boolean goToDiagnostic(
      String name,
      int line,
      int column,
      int endColumn,
      boolean showActions,
      boolean tokenOnly) {
    if (code == null || name == null) return false;
    if (!name.equals(activeFile) && !activateTabIfOpen(name)) return false;
    if (name.equals(loadingFile) || openingFiles.contains(name)) {
      pendingMatchFile = name;
      pendingMatchLine = line;
      pendingMatchColumn = column;
      pendingMatchEndColumn = endColumn;
      pendingMatchActions = showActions;
      pendingMatchToken = tokenOnly;
      return true;
    }
    pendingMatchFile = null;
    return jumpToRange(line, column, endColumn, showActions, tokenOnly);
  }

  /** يحسب الإزاحة من السطر/العمود على نص المحرر الحي وقت القفزة (قص العمود عند نهاية السطر). */
  private boolean jumpToRange(int line, int column, int endColumn, boolean showActions) {
    return jumpToRange(line, column, endColumn, showActions, false);
  }

  private boolean jumpToRange(
      int line, int column, int endColumn, boolean showActions, boolean tokenOnly) {
    if (code == null) return false;
    if (System.currentTimeMillis() - lastFileSelectTime > 400) pushNavigationPoint();
    // ‏W30: جدولُ الإزاحاتِ الطازجُ بدلَ نَسخِ المستندِ وعَدِّ الأسطرِ — القفزةُ تَقرَأُ ما جُهِّزَ وقتَ
    // رَدِّ الخلفيةِ، كما يَفعَلُ المرجعُ من جداولِ فواصلِهِ (§١٫٤ من ورقةِ هذهِ الجولةِ).
    almlk.LineOffsetTable offsets = code.jumpOffsets();
    final int lineIndex = Math.max(0, line - 1);
    final int lineStart = offsets.startOf(lineIndex);
    final int documentLength = code.length();
    final int lineEnd = Math.min(offsets.endOf(lineIndex), documentLength);
    final int target = Math.max(lineStart, Math.min(lineStart + Math.max(0, column - 1), lineEnd));
    final int selectionStart;
    final int selectionEnd;
    if (endColumn > column && !tokenOnly) {
      // مدى التشخيص الكامل على سطره (المرجع يحدد من البداية إلى النهاية؛ المدى الصفري = مؤشر).
      selectionStart = target;
      selectionEnd =
          Math.max(target, Math.min(Math.min(lineStart + endColumn - 1, lineEnd), documentLength));
    } else if (tokenOnly) {
      // ‏W27/2: تضييقٌ إلى المُعرِّفِ عندَ بدايةِ التشخيصِ — بمخزنِ السطرِ وحدَهُ، لا بنصِّ الملفِ.
      almlk.LineBuffer buffer = code.lineBufferAt(lineIndex);
      int length = buffer.length();
      int from = Math.max(0, Math.min(target - lineStart, length));
      int wordStart = from;
      int wordEnd = from;
      while (wordStart > 0 && Character.isJavaIdentifierPart(buffer.charAt(wordStart - 1)))
        wordStart--;
      while (wordEnd < length && Character.isJavaIdentifierPart(buffer.charAt(wordEnd))) wordEnd++;
      selectionStart = wordEnd > wordStart ? lineStart + wordStart : target;
      selectionEnd = wordEnd > wordStart ? lineStart + wordEnd : target;
    } else {
      // قاعدةُ المرجعِ في ‏`m214j6`: مَدىً فارغٌ (سطرٌ وعمودٌ واحدانِ) ⇒ توسيطٌ بلا تحديدٍ ولا مؤشرٍ.
      selectionStart = target;
      selectionEnd = target;
    }
    code.requestFocus();
    if (selectionEnd > selectionStart) code.setSelection(selectionStart, selectionEnd);
    // طلبُ رسمٍ واحدٌ لكلِّ دفعةٍ كما في ‏`m217j6` (‏`postDelayed(…, 10)`) بعدَ إطارِ قياسٍ واحدٍ:
    // لا ‏post و‏postDelayed(140) و‏postDelayed(300) — ثلاثَ دوراتٍ كانت تُرى قفزةً مُتقطِّعةً.
    final Runnable reveal =
        () -> {
          if (code == null) return;
          if (selectionEnd > selectionStart) code.setSelection(selectionStart, selectionEnd);
          code.bringPointIntoView(selectionEnd);
          if (endColumn > 0 || tokenOnly) {
            // الفقاعةُ ثمَّ شريطُ الإجراءاتِ في الإطارِ نفسِهِ: ‏W27/2 لم يَترُكِ الرسالةَ مشروطةً بمدًى.
            code.showDiagnosticMessageAtCaret();
            if (showActions && code.hasSelection()) code.showSelectionActions();
          }
        };
    code.postDelayed(reveal, 10L);
    return true;
  }

  /** مرجع الملف النشط من جلسة المحرر مباشرة — دقيق حتى مع أسماء التبويبات المفردة. */
  public String activeFileReference() {
    if (activeFile == null) return "";
    String reference = sessionReferences.get(activeFile);
    return reference == null ? "" : reference;
  }

  // ---------------- المرحلة 3: تطبيق الإصلاح السريع على تبويب مفتوح ----------------

  /**
   * التبويب المفتوح الذي يعرّف صنف الإصلاح بمحتوى حي: النشط أولًا (الصنف الحالي/صنف داخلي فيه)،
   * ثم التبويب المسمى باسم الصنف، ثم أي تبويب محمّل يعرّفه. التبويبات الكسولة غير المحمّلة تُترك
   * لمسار القرص لأن محتواها هو محتوى القرص نفسه. يعيد null إن لم يوجد.
   */
  public String openTabDeclaring(almlk.QuickFix fix) {
    if (fix == null || code == null) return null;
    if (activeFile != null && tabs.containsKey(activeFile) && isTabLive(activeFile)
        && fix.isDeclaredIn(code.getText().toString())) return activeFile;
    String byName = null;
    String byContent = null;
    for (String name : tabs.keySet()) {
      if (name.equals(activeFile) || !isTabLive(name)) continue;
      String content = fileContents.get(name);
      if (content == null || !fix.isDeclaredIn(content)) continue;
      if (name.endsWith("/" + fix.targetClass + ".java") || name.equals(fix.targetClass + ".java")) {
        byName = name;
        break;
      }
      if (byContent == null) byContent = name;
    }
    return byName != null ? byName : byContent;
  }

  private boolean isTabLive(String name) {
    if (name == null || name.equals(loadingFile) || openingFiles.contains(name)) return false;
    if (lazySessionReferences.containsKey(name) || lazySessionFiles.containsKey(name)) return false;
    if (name.equals(activeFile)) return true;
    String content = fileContents.get(name);
    return content != null && !PendingOpen.TEXT.equals(content);
  }

  /**
   * يطبّق الإصلاح داخل تبويب مفتوح في مكانه: لا تفعيلَ للتبويبِ ولا كشفَ لموضعِ الاسمِ. النشطُ
   * يُستبدَلُ في محرّرِه الحيِّ بسياسةِ صونِ المؤشّرِ والمنظرِ (خطوةُ تراجعٍ واحدةٍ)، والخاملُ
   * يُحدَّثُ مخزنُه الحيُّ وحالتُه المحفوظةُ. يعيد null عند النجاح أو مفتاح رسالة الفشل.
   */
  public String applyQuickFixInTab(String tab, almlk.QuickFix fix) {
    if (code == null || fix == null || tab == null || !tabs.containsKey(tab))
      return "ui_class_file_edit_failed";
    if (!isFileWritable(tab)) return "ui_file_read_only";
    if (!isTabLive(tab)) return "ui_class_file_edit_failed";
    boolean active = tab.equals(activeFile);
    String source = active ? code.getText().toString() : fileContents.get(tab);
    if (source == null) return "ui_class_file_edit_failed";
    withLiveImports(fix, source);
    almlk.QuickFix.Insertion plan = fix.planInsertion(source);
    if (plan == null)
      return fix.isDeclaredIn(source) ? fix.existsKey() : "ui_class_file_edit_failed";
    if (active) {
      code.replaceRange(plan.offset, plan.removeEnd, plan.text, true);
      ProjectSymbolIndex.registerSource(
          tab, referenceForIndex(tab), code.getText().toString());
    } else {
      String updated = plan.applyTo(source);
      fileContents.put(tab, updated);
      shiftSessionStateForEdit(tab, source, plan.offset, plan.removeEnd, plan.text);
      ProjectSymbolIndex.registerSource(tab, referenceForIndex(tab), updated);
    }
    return null;
  }

  /**
   * إصلاح "Insert 'x'"/«أضِفِ الاستيرادَ» النحويّ: يُدرَجُ الرمزُ الناقصُ في الملفِ النشطِ
   * باستبدالٍ واحدٍ قابلٍ للتراجعِ، والمؤشّرُ والمنظرُ يبقىانِ حيث هما (لا كشفَ لموضعِ الإدراجِ).
   */
  public String applyTokenInsertion(almlk.QuickFix fix) {
    if (code == null || fix == null || activeFile == null) return "ui_class_file_edit_failed";
    if (!isActiveFileWritable()) return "ui_file_read_only";
    String source = code.getText().toString();
    withLiveImports(fix, source);
    almlk.QuickFix.Insertion plan = fix.planInsertion(source);
    if (plan == null) return "ui_class_file_edit_failed";
    code.replaceRange(plan.offset, plan.removeEnd, plan.text, true);
    ProjectSymbolIndex.registerSource(
        activeFile, referenceForIndex(activeFile), code.getText().toString());
    return null;
  }

  /**
   * أسطرُ استيرادِ دَفعَةِ التغطيةِ تُصفَّى على النصِّ الحيِّ ههنا (‏1.0.191‏): المُحرِّكُ قالَ «ماذا
   * يَحتاجُ المولودُ» حيثُ الصنوفُ مَعلومةٌ، والملفُّ المفتوحُ يَقرِّرُ «أفيهِ سطرُهُ؟» — فما وُجِدَ
   * طُرِحَ، وما بَقِيَ نَزَلَ معَ الجِسمِ في عمليةٍ واحدةٍ. ولا يُمَسُّ ما لم تَطلُبْهُ الدَّفعَةُ: لا سطرَ
   * زورٍ من اقتراحِ استدعاءٍ عاديٍّ، ولا تَنفِيخَ لصنفٍ لا يَعرِفُهُ المُحرِّكُ.
   */
  private static void withLiveImports(almlk.QuickFix fix, String source) {
    if (fix == null || source == null || fix.importsToFetch.isEmpty()) return;
    java.util.List<String> pending =
        almlk.AbstractImplementationGap.pendingFetches(
            fix.importsToFetch, com.almlkid.kay.ui.ProjectSymbolIndex.importsOf(source));
    if (pending.size() != fix.importsToFetch.size()) fix.withImports(pending);
  }

  /** المرجعُ الثابتُ للتبويبِ إن وُجِدَ، واسمُه وإلّا (عنوانُ الفهرسةِ الواحدُ لكلِّ المساراتِ). */
  private String referenceForIndex(String tab) {
    String reference = tabReference(tab);
    return reference.isEmpty() ? tab : reference;
  }

  /**
   * بعدَ الكتابةِ القرصيّةِ للإصلاحِ: التبويبُ المفتوحُ يُحدَّثُ في مكانِه بالاستبدالِ نفسِه (خطوةُ
   * تراجعٍ واحدةٌ، والمؤشّرُ والمنظرُ ثابتانِ)، وخاملٌ يُحدَّثُ مخزنُه الحيُّ وحالتُه المحفوظةُ.
   * لا فتحَ ولا تنقّلَ ولا كشفَ — إحلالٌ كاملٌ لمسارِ «افتحِ الملفَّ وحدّدِ الاسمَ».
   */
  public void updateTabAfterDiskEdit(String name, String content, almlk.QuickFix.Insertion plan) {
    if (name == null || content == null || !tabs.containsKey(name)) return;
    if (!isTabLive(name)) {
      // تبويبٌ لم يُحمَّل بعدَ: لا نصَّ حيَّ يُزاحُ فيهِ، فتُطرَحُ لقطةُ الجلسةِ العتيقةُ التي كانت
      // تغطِّي الكتابةَ القرصيّةَ عندَ استعادةٍ متأخّرةٍ، ويُجعَلُ الجديدُ محتوى التبويبِ.
      lazySessionReferences.remove(name);
      lazySessionFiles.remove(name);
      fileContents.put(name, content);
      markTabSaved(name); // القُرسُ والمُخَزَّنُ سَواءٌ الآنَ: لا عَلامَةَ على ما لَم يَعدْ مُعَلَّقًا
      return;
    }
    if (name.equals(activeFile)) {
      if (code == null) return;
      if (plan != null) {
        code.replaceRange(plan.offset, plan.removeEnd, plan.text, true);
      } else {
        String source = code.getText().toString();
        if (source.equals(content)) return;
        code.replaceRange(0, source.length(), content, true);
      }
      return;
    }
    String source = fileContents.get(name);
    if (source == null) return;
    if (plan != null) {
      // أساسُ التحديثِ نصُّ التبويبِ نفسِهِ لا نسخةُ القرصِ: تعديلاتٌ لم تُحفَظ بعدَهُ تُحفَظُ معهُ.
      String updated = plan.applyTo(source);
      if (updated.equals(source)) return;
      fileContents.put(name, updated);
      shiftSessionStateForEdit(name, source, plan.offset, plan.removeEnd, plan.text);
      return;
    }
    if (!source.equals(content)) fileContents.put(name, content);
  }

  /**
   * يُزاحُ مؤشرُ التبويبِ الخاملِ وحدودُ نظرِه مع النصِّ المُدخَلِ، فلا ينفوِ المؤشّرُ ولا تنقلبَ
   * الشاشةُ حينَ يعودُ المستخدمُ إليهِ: التعويضُ الرأسيُّ كقاعدةِ المحرّرِ الحيِّ — أسطرٌ زادت
   * فوقَ أوّلِ سطرٍ ظاهرٍ تُدفَعُ في scrollY المحفوظِ.
   */
  private void shiftSessionStateForEdit(
      String tab, String source, int editStart, int editEnd, String inserted) {
    Integer cursor = sessionCursors.get(tab);
    Integer scrollY = sessionScrollY.get(tab);
    if (cursor == null && scrollY == null) return;
    int from = Math.max(0, Math.min(editStart, source.length()));
    int to = Math.max(from, Math.min(editEnd, source.length()));
    String removed = source.substring(from, to);
    int delta = inserted.length() - removed.length();
    if (cursor != null) {
      int value = cursor.intValue();
      if (value >= to) value += delta;
      else if (value > from) value = from;
      sessionCursors.put(tab, Integer.valueOf(Math.max(0, Math.min(value, source.length() + delta))));
    }
    if (scrollY == null || code == null) return;
    int lineDelta = newlinesOf(inserted) - newlinesOf(removed);
    float stride = code.lineStride();
    if (lineDelta == 0 || stride <= 0f) return;
    int editLine = 0;
    for (int i = 0; i < from; i++) if (source.charAt(i) == '\n') editLine++;
    if (editLine <= (int) (scrollY.intValue() / stride))
      sessionScrollY.put(
          tab, Integer.valueOf(Math.max(0, scrollY.intValue() + (int) (lineDelta * stride))));
  }

  private static int newlinesOf(String value) {
    int total = 0;
    for (int i = 0; i < value.length(); i++) if (value.charAt(i) == '\n') total++;
    return total;
  }

  /**
   * يفعّل تبويبًا مفتوحًا محتواه حي (غير كسول) بمرجعه الثابت — أو بالاسم عند غياب المرجع.
   * يعيد اسم التبويب المفعّل أو null. يمنع GoTo من إعادة حقن محتوى القرص فوق تعديلات حية.
   */
  public String selectIfOpenLive(String reference, String shortName) {
    String found = null;
    if (reference != null && !reference.isEmpty()) {
      for (Map.Entry<String, String> entry : sessionReferences.entrySet())
        if (almlk.FileReferences.same(reference, entry.getValue()) && tabs.containsKey(entry.getKey())) {
          found = entry.getKey();
          break;
        }
    }
    if (found == null
        && (reference == null || reference.isEmpty())
        && shortName != null
        && tabs.containsKey(shortName)) {
      found = shortName;
    }
    if (found == null) return null;
    // التحميل الكسول لم يكتمل = النص غير حي بعد — الفتح عبر القرص أسلم من قفزة على نص فارغ.
    if (lazySessionFiles.containsKey(found)
        || lazySessionReferences.containsKey(found)
        || found.equals(loadingFile)) return null;
    selectFile(found);
    return found;
  }

  /** Activates an already open tab by exact reference, including a tab whose lazy load is pending. */
  public String activateTabByReference(String reference, String shortName) {
    String found = null;
    if (reference != null && !reference.isEmpty()) {
      for (Map.Entry<String, String> entry : sessionReferences.entrySet())
        if (almlk.FileReferences.same(reference, entry.getValue()) && tabs.containsKey(entry.getKey())) {
          found = entry.getKey();
          break;
        }
    } else if (shortName != null && tabs.containsKey(shortName)) {
      found = shortName;
    }
    if (found == null) return null;
    selectFile(found);
    return found;
  }

  /**
   * قفزة GoTo المحصّنة ضد الإزاحات البائتة: تُحل الإزاحة المفهرسة على نص المحرر الحي وقت
   * القفزة — إن بقيت تشير إلى الرمز ككلمة كاملة فهي دقيقة، وإلا أقرب ظهور كلمة كاملة للرمز
   * (نفس مبدأ قفز نتائج البحث الحي في المرجع). تعيد الإزاحة النهائية أو ‎-1.
   */
  public int goToSymbol(String symbol, int indexedOffset) {
    if (code == null) return -1;
    if (System.currentTimeMillis() - lastFileSelectTime > 400) pushNavigationPoint();
    String text = code.getText().toString();
    int resolved = resolveLiveSymbolOffset(text, symbol, indexedOffset);
    final int target = Math.max(0, Math.min(resolved, code.length()));
    final int request = ++goToGeneration;
    final String requestedFile = activeFile;
    code.requestFocus();
    // A tab's posted restoreViewport used to run after this selection and collapse it to a caret.
    // Queue the identifier selection after all pending tab-restore work so every Go To arrival is
    // visibly distinguished, including asynchronously opened system-class source stubs.
    code.post(
        () -> {
          if (code == null
              || request != goToGeneration
              || !java.util.Objects.equals(requestedFile, activeFile)) return;
          String liveText = code.getText().toString();
          int liveTarget = Math.max(
              0, Math.min(resolveLiveSymbolOffset(liveText, symbol, target), code.length()));
          if (symbol != null && !symbol.isEmpty()
              && isWholeWordAt(liveText, liveTarget, symbol))
            code.setSelection(liveTarget, liveTarget + symbol.length());
          else
            code.setSelection(liveTarget);
          code.bringPointIntoView(liveTarget);
        });
    return target;
  }

  private static int resolveLiveSymbolOffset(String text, String symbol, int indexedOffset) {
    int clamped = Math.max(0, Math.min(indexedOffset, text.length()));
    if (symbol == null || symbol.isEmpty()) return clamped;
    if (isWholeWordAt(text, clamped, symbol)) return clamped;
    int best = -1;
    long bestDistance = Long.MAX_VALUE;
    int from = 0;
    while (true) {
      int at = text.indexOf(symbol, from);
      if (at < 0) break;
      if (isWholeWordAt(text, at, symbol)) {
        long distance = Math.abs((long) at - clamped);
        if (distance < bestDistance) {
          bestDistance = distance;
          best = at;
        }
      }
      from = at + 1;
    }
    return best >= 0 ? best : clamped;
  }

  private static boolean isWholeWordAt(String text, int at, String symbol) {
    int end = at + symbol.length();
    if (at < 0 || end > text.length()) return false;
    if (!text.regionMatches(at, symbol, 0, symbol.length())) return false;
    if (at > 0 && Character.isJavaIdentifierPart(text.charAt(at - 1))) return false;
    return end >= text.length() || !Character.isJavaIdentifierPart(text.charAt(end));
  }

  public boolean goToOffset(int offset) {
    if (code == null) return false;
    // سجّل الموضع الحالي قبل القفز لكن ليس مباشرة بعد تبديل ملف (قيد الاستعادة أو انتقال متسلسل).
    if (System.currentTimeMillis() - lastFileSelectTime > 400) pushNavigationPoint();
    int target = Math.max(0, Math.min(offset, code.length()));
    code.requestFocus();
    code.setSelection(target);
    code.post(() -> code.bringPointIntoView(target));
    return true;
  }

  public boolean goToLine(int line) {
    if (line < 1) return false;
    String text = code.getText().toString();
    int at = 0;
    for (int n = 1; n < line; n++) {
      at = text.indexOf('\n', at);
      if (at < 0) return false;
      at++;
    }
    code.requestFocus();
    final int target = Math.min(at, code.length());
    code.setSelection(target);
    // فحص القبول: الانتقال يجب أن يمرر العرض للسطر الهدف كما يفعل البحث تمامًا.
    code.post(() -> code.bringPointIntoView(target));
    return true;
  }

  public void formatSource() {
    if (code == null || !isActiveFileWritable()) return;
    // المرحلة السادسة: منسق XML بنيوي مستقل — إحلال كامل لتعطيل منسق جافا في XML.
    if (isXmlFile()) {
      formatXmlSource();
      return;
    }
    String original = code.getText().toString();
    String formatted = code.formatCode();
    if (original.equals(formatted)) return;
    int semanticCursor = semanticPosition(original, Math.max(0, code.getSelectionStart()));
    historyLocked = true;
    // التنسيق استبدال واحد قابل للتراجع داخل موديل المحرك (بند الإحلال).
    code.replaceRange(0, original.length(), formatted);
    code.setSelection(offsetForSemanticPosition(formatted, semanticCursor));
    historyLocked = false;
    code.refreshNow();
  }

  /**
   * تنسيق XML بنيوي: إعادة إزاحة فقط، فالمحتوى لا يُمس.
   *
   * <p>عقد التنفيذ المعتمد من دراسة المرجع: بوابة لغة → لقطة موضع → تنفيذ → استعادة موضع →
   * لا فشل صامت. ويُنفَّذ استبدالًا ذريًا واحدًا في موديل المحرك بدل الكتابة المباشرة على القرص
   * حتى يبقى التنسيق قابلًا للتراجع.
   */
  private void formatXmlSource() {
    String original = code.getText().toString();
    int indentSize = almlk.XmlCodeFormatter.resolveIndentSize(getContext());
    String formatted = almlk.XmlCodeFormatter.format(original, indentSize);
    if (original.equals(formatted)) {
      Toast.makeText(getContext(), UiStrings.get(getContext(), "ui_xml_already_formatted"), Toast.LENGTH_SHORT).show();
      return;
    }
    // التنسيق يغيّر المسافات البادئة فقط، فإسقاط المؤشر على عدّ المحارف غير المسافية يبقى صحيحًا.
    int semanticCursor = semanticPosition(original, Math.max(0, code.getSelectionStart()));
    historyLocked = true;
    code.replaceRange(0, original.length(), formatted);
    code.setSelection(offsetForSemanticPosition(formatted, semanticCursor));
    historyLocked = false;
    code.refreshNow();
  }

  private int semanticPosition(String text, int offset) {
    int count = 0;
    for (int i = 0; i < Math.min(offset, text.length()); i++)
      if (!Character.isWhitespace(text.charAt(i))) count++;
    return count;
  }

  private int offsetForSemanticPosition(String text, int semanticPosition) {
    int count = 0;
    for (int i = 0; i < text.length(); i++) {
      if (!Character.isWhitespace(text.charAt(i)) && count++ >= semanticPosition) return i;
    }
    return text.length();
  }

  public void setQuickFixListener(QuickFixListener listener) {
    quickFixListener = listener;
  }

  public void setDefinitionListener(DefinitionListener listener) {
    definitionListener = listener;
  }

  public void setDefinitionRequestListener(DefinitionRequestListener listener) {
    definitionRequestListener = listener;
  }

  public void setUsageListener(UsageListener listener) {
    usageListener = listener;
  }

  public void setDiagnosticsListener(DiagnosticsListener listener) {
    diagnosticsListener = listener;
  }

  /** 1.0.198: تُبلِغُ الصَّفحَةُ عَنِ المِلَفِّ الجَارِي لِوَحدَةِ الفَحصِ — المُستَمعُ يَملِكُهُ المُضيفُ. */
  public interface AnalyzerFocusListener {
    void onFocus(String fileName, String reference);
  }

  private AnalyzerFocusListener analyzerFocusListener;

  /**
   * ج٥٨: الحافَّةُ التِي تَمْنَعُ أن يَكونَ الرَّسمُ إِشرَاقًا. الصَّفحَةُ تَرسُمُ الوَسومَ مِرارًا،
   * وَإِعلَانُ «هٰذِهِ هِيَ الوَجهَةُ» بَعدَ كُلِّ رَسمٍ كَانَ هُوَ الحَلقَةَ التِي أَسقَطَتِ
   * الوَاجِهَةَ عِندَ الإِقلَاعِ (ج٥٤). راجِعۡ {@code almlk.EditorFocusEdge}.
   */
  private final almlk.EditorFocusEdge analyzerFocusEdge = new almlk.EditorFocusEdge();

  /**
   * المُستَمِعُ يُقرَأُ وَقۡتَ الإِعلَانِ لَا وَقۡتَ البِنَاءِ: فَصِلَةٌ وَاحدَةٌ لِلحافَّةِ
   * تُجاوِزُ المُستَمِعَ إِنْ لَم يَكُنۡ بَعدُ مَوصُولًا — وَتُبقِي عَلَى كَلِّ رَسمٍ صِفرَ
   * تَحَجُّزٍ، فَإِنَّ الرَّسمَ يَجۡرِي عَلى إِثرِ كُلِّ فَحصٍ.
   */
  private final almlk.EditorFocusEdge.Sink analyzerFocusSink = this::announceAnalyzerFocus;

  private void announceAnalyzerFocus(String fileName, String reference) {
    AnalyzerFocusListener listener = analyzerFocusListener;
    if (listener != null) listener.onFocus(fileName, reference);
  }

  public void setAnalyzerFocusListener(AnalyzerFocusListener listener) {
    analyzerFocusListener = listener;
    // وَاجِهَةٌ تُهَيَّأُ مِن جَدِيدٍ: لَا يَجُوزُ أن يُثبِتَ إِعلَانُ سَابِقَةٍ وَصفًا لَمۡ
    // يَسمَعۡهُ أحَدٌ بَعدُ — فَالحافَّةُ تُنۡسَىٰ ثُمَّ تُستَأنَفُ مِنَ التَّغَيُّرِ الجَارِي.
    analyzerFocusEdge.forget();
  }

  public void setFileChangedListener(FileChangedListener listener) {
    fileChangedListener = listener;
  }

  /** Updates current-editor markers from the complete, file-qualified project snapshot. */
  public void setProjectDiagnostics(List<ProjectDiagnostic> values) {
    projectDiagnostics =
        values == null || values.isEmpty()
            ? Collections.emptyList()
            : new ArrayList<>(values);
    applyProjectDiagnosticsToActiveFile();
  }

  private void applyProjectDiagnosticsToActiveFile() {
    if (code == null) return;
    ArrayList<ProjectDiagnostic> active = new ArrayList<>();
    String reference = null; // ‏1.0.198: يَخرُجُ مَعَ الإِشَارَةِ إِلَى الوَحدَةِ، فَهِيَ تَفتَحُ بِهِ
    if (activeFile != null) {
      // الجولةُ ‏33 (قـ٢): الهُويّةُ التامّةُ أو لا وسمَ في المحرِّرِ. كانَ الاسمُ المجرَّدُ يُقبَلُ حيثُ
      // لا مرجعَ للتبويبِ، فتُرسمُ بلاغاتُ نسخةٍ أخرى من المشروعِ (أو ملفٍّ شقيقٍ بنفسِ الاسمِ في وحدةٍ
      // أخرى) تحتَ ثوابتِ هذا الملفِّ ومعاملاتِها وسلاسلِ نصِّهِ وتعليقاتِهِ — «مئاتُ الأخطاءِ
      // العشوائيةِ» كلُّها. المرجعُ نفسُهُ لا يتساهلُ: عقدُ المحرّكِ قائمةُ أخطاءٍ لكلِّ مسارٍ
      // (mo769j6(path, SyntaxError[], done)) والمحرِّرُ يسألُ بمسارِهِ وحدَهُ.
      reference = resolvedActiveFileReference();
      for (ProjectDiagnostic item : projectDiagnostics) {
        if (item == null) continue;
        if (almlk.MarkBinding.binds(reference, item.reference)) active.add(item);
      }
    }
    code.setProjectDiagnostics(active);
    // ‏1.0.198 (ج٤٧): هُنَا وَحدَهُ تُعرَفُ الوَجهَةُ مَعًا (الاسمُ وَالمرجَعُ المُحَلَّلُ)، فَإِنَّمَا
    // تُرسَلُ الإِشارَةُ بَعدَ أن يَستَقِرَّ الوَسمُ — وَلا كِتابَةَ فِي المُحرِّرِ وَلا قُفلًا.
    // ‏1.2.8 (ج٥٨): الرِّسالَةُ بَاقِيَةٌ مِن هٰذَا المَوضِعِ الوَاحِدِ — وَلكِنَّهَا عَلى الحافَّةِ:
    // إِنْ لَمۡ يَتَغَيَّرۡ (الاسمُ، المرجَعُ) فَلَمۡ يَتَغَيَّرۡ شَيءٌ فَلا إِشرَاقَ؛ وَإِن تَغَيَّرَ
    // أُعلِنَ مَرَّةً وَاحدَةً. فَالدَّورَةُ (رَسمٌ ← إِشرَاقٌ ← نَشرٌ ← رَسمٌ) تَنتَهِي عِندَ
    // الوَصفِ نَفسِهِ، لَا عِندَ حَارِسٍ يَعرِفُ طَرِيقًا وَيَجهَلُ غَيرَهُ — فَكُلُّ نَشرٍ (إِقلَاعًا
    // عَلى «لا مَشرُوعَ»، أَو نَقرَةَ صَفحَةٍ، أَو حِفظًا) يَقَعُ تَحتَ الحافَّةِ نَفسِهَا.
    analyzerFocusEdge.announce(analyzerFocusSink, activeFile, reference);
  }

  /**
   * مرجعُ التبويبِ الجاريِ للوسمِ فقط: ما سُجِّلَ عندَ الفتحِ، وإلا مسارُهُ نفسُهُ إن كانَ ملفًّا
   * موجودًا (لا نَكتُبُ في sessionReferences فذلكَ state محفوظٌ لغيرِ الحاجةِ — شرطٌ دائمٌ ‏20).
   */
  private String resolvedActiveFileReference() {
    boolean isFile = false;
    if (activeFile != null && !activeFile.isEmpty() && activeFile.charAt(0) == '/') {
      try {
        isFile = new java.io.File(activeFile).isFile();
      } catch (RuntimeException malformed) {
        isFile = false;
      }
    }
    return almlk.MarkBinding.tabReference(getActiveFileReference(), activeFile, isFile);
  }

  public void requestUsageForCurrentSelection() {
    if (code == null || usageListener == null || activeFile == null) return;
    String text = code.getText().toString();
    int[] range = usageSelection(text, code.getSelectionStart(), code.getSelectionEnd());
    usageListener.requested(activeFile, text, range[0], range[1]);
  }

  /**
   * يثبّت مدى البحث على **اسم** المورد في XML — المرحلة السابعة.
   *
   * <p>بلا هذا التثبيت يُبحث في البادئة {@code @id/} كلها فلا توجد نتائج. وبما أن حدود الاسم
   * في {@code @id/x} و{@code R.id.x} ليست محارف معرفية، يجد المحرك القائم الصيغ كلها معًا
   * بلا محرك بحث جديد.
   */
  private int[] usageSelection(String text, int selStart, int selEnd) {
    if (!isXmlFile() || text == null || text.isEmpty()) return new int[] {selStart, selEnd};
    almlk.XmlResourceReference reference =
        almlk.XmlResourceReference.at(text, Math.max(0, Math.min(selStart, text.length() - 1)));
    return reference == null
        ? new int[] {selStart, selEnd}
        : new int[] {reference.nameStart, reference.nameEnd};
  }

  /** Entry point for the toolbar/menu Go To action, independent of ActionMode. */
  public void requestDefinitionForCurrentSelection() {
    if (code == null || activeFile == null) return;
    final int rawSelectionStart = code.getSelectionStart();
    final int rawSelectionEnd = code.getSelectionEnd();
    final int selectionStart = Math.min(rawSelectionStart, rawSelectionEnd);
    final int selectionEnd = Math.max(rawSelectionStart, rawSelectionEnd);
    if (selectionStart == selectionEnd) {
      Toast.makeText(
              getContext(),
              UiStrings.get(getContext(), "ui_error_symbol_selection_required"),
              Toast.LENGTH_SHORT)
          .show();
      return;
    }
    final String source = code.getText().toString();
    final int request = ++definitionGeneration;
    final String requestedFile = activeFile;
    completionWorker.execute(
        () -> {
          try {
            // المرحلة السابعة: مراجع XML (@type/name) يحلها المضيف من جذر المشروع، فلا
            // يُمرَّر XML إلى محلل رموز Java.
            final ProjectSymbolIndex.DefinitionTarget target =
                requestedFile.toLowerCase(java.util.Locale.US).endsWith(".smali")
                    ? SmaliDefinitionResolver.resolve(
                        requestedFile, source, selectionStart, selectionEnd)
                    : almlk.XmlCodeFormatter.isXmlName(requestedFile)
                        ? null
                        : ProjectSymbolIndex.resolveDefinition(
                            requestedFile, source, selectionStart, selectionEnd);
            post(
                () -> {
                  if (request != definitionGeneration) return;
                  if (target != null && definitionListener != null) {
                    if (usageListener != null
                        && ProjectSymbolIndex.isDefinitionSelection(
                            requestedFile, source, selectionStart, selectionEnd, target)) {
                      usageListener.requested(
                          requestedFile, source, selectionStart, selectionEnd);
                    } else {
                      definitionListener.requested(target);
                    }
                  } else if (definitionRequestListener != null) {
                    definitionRequestListener.requested(
                        requestedFile, source, selectionStart, selectionEnd);
                  } else {
                    Toast.makeText(
                            getContext(),
                            UiStrings.get(getContext(), "ui_error_definition_not_found"),
                            Toast.LENGTH_SHORT)
                        .show();
                  }
                });
          } catch (Throwable error) {
            post(() -> {
              if (request == definitionGeneration) showEditorError(error);
            });
          }
        });
  }

  public void refreshSemanticDiagnostics() {
    if (code != null && activeFile != null) code.refreshNow();
  }

  /**
   * W20′2: إعادةُ فحصِ الملفِّ النشِطِ وحدَهُ الآنَ (لا تلوينَ كلّيَّ ولا مسحَ مشروعٍ): يُنادى بعدَ
   * إصلاحٍ لم يمسَّ هذا النصَّ ولكنّهُ غيّرَ حكمَهُ — كدالةٍ أُنشِئَتْ في صنفٍ آخرَ للمنادي عليها.
   */
  public void reinspectActiveFileDiagnostics() {
    if (code != null && activeFile != null) code.reinspectNow();
  }

  /**
   * محتوى تبويبٍ مفتوحٍ كما يراهُ المحرِّرُ: النشِطُ من اللوحةِ الحيّةِ، والخاملُ من مخزنِهِ، null إن
   * لم يكنْ حيًّا (كسولٌ أو قيدَ الفتحِ) فيُقرأَ من القرصِ — مصدرُ النصِّ الواحدُ لإعادةِ الفحصِ.
   */
  public String tabContent(String name) {
    if (name == null) return null;
    if (code != null && name.equals(activeFile)) return code.getText().toString();
    String content = fileContents.get(name);
    return content == null || PendingOpen.TEXT.equals(content) ? null : content;
  }

  public java.util.List<com.almlkid.kay.ui.CodeLanguageTools.Diagnostic> diagnostics() {
    code.refreshNow();
    return code.getDiagnostics();
  }

  private void showLiveCompletions() {
    if (code == null || !code.hasFocus() || code.getSelectionStart() != code.getSelectionEnd())
      return;
    final String requestedFile = activeFile;
    final int cursor = code.getSelectionStart();
    final int request = ++completionGeneration;
    completionLookupFuture =
        completionLookupWorker.submit(
            () -> {
              try {
                // Copy the document on the worker, never from the key event/UI callback.
                EditorTextSnapshot.Value snapshot = completionSnapshot.copy();
                if (request != completionGeneration) return;
                final java.util.List<ProjectSymbolIndex.CompletionItem> items =
                    cachedOrComputeCompletions(requestedFile, snapshot.text, cursor);
                post(
                    () -> {
                      if (request != completionGeneration
                          || code.getSelectionStart() != cursor
                          || !java.util.Objects.equals(requestedFile, activeFile)) return;
                      displayLiveCompletions(items);
                    });
              } catch (Throwable error) {
                post(() -> showEditorError(error));
              }
            });
  }

  private List<ProjectSymbolIndex.CompletionItem> cachedOrComputeCompletions(
      String file, String source, int cursor) {
    int safeCursor = Math.max(0, Math.min(cursor, source.length()));
    int tokenStart = CodeLanguageTools.completionStart(source, safeCursor);
    String lowerFile = file == null ? "" : file.toLowerCase(java.util.Locale.US);
    if ((lowerFile.endsWith(".gradle") || lowerFile.endsWith(".gradle.kts"))
        && CodeLanguageTools.completionStart(file, source, safeCursor) != tokenStart) {
      // إحداثيات الاعتماد تُطابَق بالنص كله (contains) فلا تُضيَّق من نتيجة سابقة.
      List<ProjectSymbolIndex.CompletionItem> coordinates = KayStyleCompletionEngine.complete(file, source, safeCursor);
      return coordinates == null ? Collections.emptyList() : coordinates;
    }
    String prefix = source.substring(tokenStart, safeCursor);
    String context = source.substring(Math.max(0, tokenStart - 256), tokenStart);
    String after = source.substring(safeCursor);
    // Exclude the active prefix so typing the next character can reuse the same base result.
    int sourceHash = 31 * source.substring(0, tokenStart).hashCode() + after.hashCode();
    List<ProjectSymbolIndex.CompletionItem> cached =
        completionCache.lookup(file, prefix, context, after, sourceHash);
    if (cached != null) return cached;

    List<ProjectSymbolIndex.CompletionItem> computed =
        KayStyleCompletionEngine.complete(file, source, safeCursor);
    completionCache.store(file, prefix, context, after, sourceHash, computed);
    return computed == null ? Collections.emptyList() : computed;
  }

  private void cancelCompletionLookup() {
    if (completionLookupFuture != null) {
      completionLookupFuture.cancel(true);
      completionLookupFuture = null;
    }
  }

  private void displayLiveCompletions(
      java.util.List<ProjectSymbolIndex.CompletionItem> items) {
    if (items == null || items.isEmpty()) {
      dismissCompletions();
      return;
    }
    if (!almlk.AppSettings.completeAllTypes(getContext())) {
      // "Complete all types" off: only classes that are already visible (imported, same package,
      // local); unimported ones carry the import they would add.
      java.util.List<ProjectSymbolIndex.CompletionItem> filtered = new java.util.ArrayList<>();
      for (ProjectSymbolIndex.CompletionItem item : items)
        if (item.kind != ProjectSymbolIndex.CompletionItem.CLASS || item.importNames == null || item.importNames.isEmpty())
          filtered.add(item);
      items = filtered;
      if (items.isEmpty()) {
        dismissCompletions();
        return;
      }
    }
    if (completionAdapter == null) completionAdapter = new EditorCompletionAdapter(getContext());
    completionAdapter.setItems(items, typedCompletionPrefix());
    if (completionList == null) {
      // Reference popup: completion_list (inset dark rounded window, padded list, no dividers).
      completionList = LayoutInflater.from(getContext()).inflate(R.layout.completion_list, null, false);
      completionListView = completionList.findViewById(R.id.completionList);
      completionListView.setAdapter(completionAdapter);
      completionListView.setOnItemClickListener((parent, view, position, id) -> {
        if (completionAdapter == null || position >= completionAdapter.getCount()) return;
        ProjectSymbolIndex.CompletionItem chosen = completionAdapter.getItem(position);
        applyTypedCompletion(completionAdapter.getItem(position));
        dismissCompletions();
        // attribute="" → its values; package. → its classes (like the reference's chained popup)
        if (chosen.reopen) postDelayed(this::showCompletionPopup, 40);
      });
    } else {
      completionListView.setSelection(0);
    }
    Rect frame = new Rect();
    getWindowVisibleDisplayFrame(frame);
    float density = getResources().getDisplayMetrics().density;
    int screenWidth = frame.width() > 0 ? frame.width() : getResources().getDisplayMetrics().widthPixels;
    int screenHeight = frame.height() > 0 ? frame.height() : getResources().getDisplayMetrics().heightPixels;
    // Reference sizing: width min(max(500dp, w/2), w); height max(min(350dp, h/2, h-250dp), 90dp).
    int width = (int) Math.min(Math.max(500 * density, screenWidth / 2f), screenWidth);
    int maxHeight = (int) Math.max(Math.min(Math.min(350 * density, screenHeight / 2f), screenHeight - 250 * density), 90 * density);
    int content = dp(20 + 16); // inset of popup_complete_dark + list padding
    // نفسُ بوابةِ المحرِّرِ: إن أُقفِلَ «Display apiversion info» لا نُخصِّصُ سطرَهُ في الارتفاعِ.
    final boolean showApiInfo = almlk.AppSettings.showApiInfo(getContext());
    for (ProjectSymbolIndex.CompletionItem item : items) {
      content += dp(showApiInfo && item.apiInfo != null && !item.apiInfo.isEmpty() ? 58 : 44);
      if (content >= maxHeight) break;
    }
    int height = Math.min(maxHeight, content);
    // Reference placement: the window hangs from the bottom of the caret line (the line stays
    // visible); if the room above the symbol bar/keyboard is short the editor scrolls up first,
    // and only at the end of the file is the window shortened or moved above the line.
    int[] location = new int[2];
    code.getLocationOnScreen(location);
    Rect visibleFrame = new Rect();
    getWindowVisibleDisplayFrame(visibleFrame);
    int editorTop = location[1];
    int editorBottom = Math.min(location[1] + code.getHeight(), visibleFrame.bottom);
    View quickBarView = quickKeyBar == null ? null : quickKeyBar.peekView();
    if (quickBarView != null && quickBarView.getVisibility() == VISIBLE) {
      int[] quickLocation = new int[2];
      quickBarView.getLocationOnScreen(quickLocation);
      if (quickLocation[1] > editorTop) editorBottom = Math.min(editorBottom, quickLocation[1]);
    }
    int cursor = Math.max(0, Math.min(code.getSelectionStart(), code.length()));
    int stride = Math.round(code.lineStride());
    int[] position = code.offsetToViewPosition(cursor);
    int lineBottom = location[1] + position[1];
    int scroll = almlk.CompletionPopupPlacement.scrollNeeded(lineBottom - stride, lineBottom, editorTop, editorBottom, height);
    if (scroll > 0) {
      code.scrollByPixels(0, scroll);
      position = code.offsetToViewPosition(cursor);
      lineBottom = location[1] + position[1];
    }
    int minHeight = Math.min(height, dp(20 + 16) + 2 * dp(44));
    almlk.CompletionPopupPlacement.Placement placement = almlk.CompletionPopupPlacement.place(
        location[0] + position[0], lineBottom - stride, lineBottom, editorTop, editorBottom,
        visibleFrame.left, visibleFrame.right > visibleFrame.left ? visibleFrame.right : screenWidth,
        width, height, minHeight);
    height = placement.height;
    int x = placement.x;
    int y = placement.y;
    if (completionWindow == null) {
      completionWindow = new PopupWindow(completionList, width, height, false);
      completionWindow.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0));
      completionWindow.setOutsideTouchable(true);
      completionWindow.setTouchable(true);
    } else {
      completionWindow.setWidth(width);
      completionWindow.setHeight(height);
    }
    if (completionWindow.isShowing()) completionWindow.update(x, y, width, height);
    else completionWindow.showAtLocation(this, Gravity.NO_GRAVITY, x, y);
  }

  private void showEditorError(Throwable error) {
    long now = android.os.SystemClock.uptimeMillis();
    if (now - lastEditorErrorTime < 3000 || !isAttachedToWindow()) return;
    lastEditorErrorTime = now;
    dismissCompletions();
    new android.app.AlertDialog.Builder(getContext())
        .setTitle(UiStrings.get(getContext(), "ui_editor_error_title"))
        .setMessage(
            UiStrings.format(
                getContext(),
                "ui_editor_error_body",
                error.getClass().getSimpleName(),
                UiStrings.message(getContext(), error).isEmpty() ? "" : "\n" + UiStrings.message(getContext(), error)))
        .setPositiveButton(UiStrings.get(getContext(), "ui_action_ok"), null)
        .show();
  }

  private void dismissCompletions() {
    completionGeneration++;
    cancelCompletionLookup();
    if (completionWindow != null) {
      completionWindow.dismiss();
      completionWindow = null;
    }
  }

  /** The typed part painted in the accent colour (after "android:" for XML attributes). */
  private String typedCompletionPrefix() {
    if (code == null) return "";
    String text = code.currentText();
    int cursor = Math.max(0, Math.min(code.getSelectionStart(), text.length()));
    int start = Math.max(0, Math.min(CodeLanguageTools.completionStart(activeFile, text, cursor), cursor));
    String typed = text.substring(start, cursor);
    int colon = typed.lastIndexOf(':');
    return colon >= 0 ? typed.substring(colon + 1) : typed;
  }

  /** أمر «الإكمال» اليدوي: يعرض نفس النافذة الحية المنمطة دون شرط التركيز. */
  public void showCompletionPopup() {
    if (code == null || activeFile == null) return;
    final String requestedFile = activeFile;
    final int cursor = Math.max(0, code.getSelectionStart());
    final int request = ++completionGeneration;
    completionLookupFuture =
        completionLookupWorker.submit(
            () -> {
              try {
                EditorTextSnapshot.Value snapshot = completionSnapshot.copy();
                if (request != completionGeneration) return;
                final java.util.List<ProjectSymbolIndex.CompletionItem> items =
                    cachedOrComputeCompletions(requestedFile, snapshot.text, cursor);
                post(
                    () -> {
                      if (request == completionGeneration) displayLiveCompletions(items);
                    });
              } catch (Throwable error) {
                post(() -> showEditorError(error));
              }
            });
  }

  /** التزام منمط مفوّض إلى المحرر (المرحلة 3: توقيع + مؤشر + استيراد تلقائي). */
  public void applyTypedCompletion(ProjectSymbolIndex.CompletionItem item) {
    if (code != null) code.applyTypedCompletion(item);
  }
  /** المرحلة 2: إعادة تسمية حقيقية للرمز/المورد المحدد — الملف النشط ثم ملفات المشروع. */
  public void renameCurrentSelection() {
    if (code == null || !code.hasSelection()) {
      Toast.makeText(getContext(), UiStrings.get(getContext(), "ui_select_symbol_or_resource_first"), Toast.LENGTH_SHORT).show();
      return;
    }
    String text = code.getText().toString();
    String symbol = selectionToken(text, code.getSelectionStart(), code.getSelectionEnd());
    if (symbol == null || symbol.isEmpty()) {
      Toast.makeText(getContext(), UiStrings.get(getContext(), "ui_place_cursor_on_symbol_or_resource"), Toast.LENGTH_SHORT).show();
      return;
    }
    promptRename(symbol);
  }

  // ---------------- المرحلة 3: إعادة البناء (Inline/Introduce/Extract) ----------------
  public void refactorInline() {
    if (code == null || !code.hasSelection()) { Toast.makeText(getContext(), UiStrings.get(getContext(), "ui_select_variable_first"), Toast.LENGTH_SHORT).show(); return; }
    String text = code.getText().toString();
    String var = selectionToken(text, code.getSelectionStart(), code.getSelectionEnd());
    if (var == null) { Toast.makeText(getContext(), UiStrings.get(getContext(), "ui_select_variable_name"), Toast.LENGTH_SHORT).show(); return; }
    String result = almlk.Refactor.inlineVariable(text, var);
    if (result == null) {
      Toast.makeText(getContext(), UiStrings.format(getContext(), "ui_inline_variable_failed", var), Toast.LENGTH_LONG).show();
      return;
    }
    code.replaceRange(0, text.length(), result);
    Toast.makeText(getContext(), UiStrings.format(getContext(), "ui_inline_variable_done", var), Toast.LENGTH_SHORT).show();
  }

  public void refactorIntroduce() {
    if (code == null || !code.hasSelection()) {
      Toast.makeText(getContext(), UiStrings.get(getContext(), "ui_select_range_first"), Toast.LENGTH_SHORT).show();
      return;
    }
    final int selectionStart = code.getSelectionStart();
    final int selectionEnd = code.getSelectionEnd();
    final long documentVersion = code.getDocument().version();
    final String fileAtStart = activeFile;
    promptRefactorName(UiStrings.get(getContext(), "ui_new_variable_name_hint"), (name) -> {
      if (!java.util.Objects.equals(fileAtStart, activeFile)
          || code.getDocument().version() != documentVersion) {
        Toast.makeText(getContext(), UiStrings.get(getContext(), "ui_document_changed_during_dialog"), Toast.LENGTH_LONG).show();
        return;
      }
      String text = code.getText().toString();
      String result = almlk.Refactor.introduceVariable(text, selectionStart, selectionEnd, name);
      if (result == null) { Toast.makeText(
            getContext(),
            UiStrings.format(getContext(), "ui_invalid_symbol_selection", name),
            Toast.LENGTH_LONG)
            .show(); return; }
      code.replaceRange(0, text.length(), result);
    });
  }

  public void refactorExtract() {
    if (code == null || !code.hasSelection()) {
      Toast.makeText(getContext(), UiStrings.get(getContext(), "ui_select_range_first"), Toast.LENGTH_SHORT).show();
      return;
    }
    final int selectionStart = code.getSelectionStart();
    final int selectionEnd = code.getSelectionEnd();
    final long documentVersion = code.getDocument().version();
    final String fileAtStart = activeFile;
    promptRefactorName(UiStrings.get(getContext(), "ui_new_method_name_hint"), (name) -> {
      if (!java.util.Objects.equals(fileAtStart, activeFile)
          || code.getDocument().version() != documentVersion) {
        Toast.makeText(getContext(), UiStrings.get(getContext(), "ui_document_changed_during_dialog"), Toast.LENGTH_LONG).show();
        return;
      }
      String text = code.getText().toString();
      String result = almlk.Refactor.extractMethod(text, selectionStart, selectionEnd, name);
      if (result == null) { Toast.makeText(
            getContext(),
            UiStrings.format(getContext(), "ui_invalid_symbol_selection", name),
            Toast.LENGTH_LONG)
            .show(); return; }
      code.replaceRange(0, text.length(), result);
    });
  }

  private void promptRefactorName(String hint, java.util.function.Consumer<String> apply) {
    if (code == null || !code.hasSelection()) { Toast.makeText(getContext(), UiStrings.get(getContext(), "ui_select_range_first"), Toast.LENGTH_SHORT).show(); return; }
    final android.widget.EditText input = new android.widget.EditText(getContext());
    input.setHint(hint);
    new android.app.AlertDialog.Builder(getContext())
        .setTitle(hint)
        .setView(input)
        .setPositiveButton(UiStrings.get(getContext(), "ui_action_apply"), (d, w) -> {
          String name = input.getText().toString().trim();
          String reason = almlk.Renamer.validate("x", name);
          if (reason != null) {
            Toast.makeText(getContext(), UiStrings.get(getContext(), reason), Toast.LENGTH_LONG).show();
            return;
          }
          apply.accept(name);
        })
        .setNegativeButton(UiStrings.get(getContext(), "dialog_cancel"), null)
        .show();
  }

  /** يستخرج رمز/مورد التحديد؛ ولـXML يأخذ الجزء بعد آخر «/» (اسم المورد). */
  private String selectionToken(String text, int s, int e) {
    if (s < 0 || e > text.length() || s >= e) return null;
    String token = text.substring(s, e).trim();
    if (isXmlFile()) { int slash = token.lastIndexOf('/'); if (slash >= 0) token = token.substring(slash + 1); }
    for (int i = 0; i < token.length(); i++)
      if (!Character.isJavaIdentifierPart(token.charAt(i))) return null;
    return token.isEmpty() ? null : token;
  }

  private void promptRename(final String symbol) {
    final android.widget.EditText input = new android.widget.EditText(getContext());
    input.setText(symbol);
    input.selectAll();
    new android.app.AlertDialog.Builder(getContext())
        .setTitle(UiStrings.format(getContext(), "ui_rename_symbol_title", symbol))
        .setView(input)
        .setPositiveButton(UiStrings.get(getContext(), "ui_action_rename"), (d, w) -> {
          String reason = almlk.Renamer.validate(symbol, input.getText().toString());
          if (reason != null) {
            Toast.makeText(getContext(), UiStrings.get(getContext(), reason), Toast.LENGTH_LONG).show();
            return;
          }
          applyRename(symbol, input.getText().toString().trim());
        })
        .setNegativeButton(UiStrings.get(getContext(), "dialog_cancel"), null)
        .show();
  }

  /** يطبّق إعادة التسمية على الملف النشط (بتراجع واحد) ثم بقية ملفات المشروع على خيط خلفي. */
  private void applyRename(final String symbol, final String newName) {
    final String activeText = code.getText().toString();
    final boolean xml = isXmlFile();
    String newText = xml ? almlk.Renamer.renameResource(activeText, symbol, newName)
        : almlk.Renamer.renameAll(activeText, symbol, newName);
    if (!newText.equals(activeText)) code.replaceRange(0, activeText.length(), newText);
    final java.util.List<String> files = ProjectSymbolIndex.projectJavaFiles();
    final String active = activeFile;
    completionWorker.execute(() -> {
      int changed = 0;
      for (String path : files) {
        if (path == null || path.equals(active)) continue;
        try {
          String ref = com.shima.performance.FileSystemRepository.referenceForFile(new java.io.File(path));
          String content = fileRepository.readTextBlocking(ref, path, 8 * 1024 * 1024);
          if (content == null) continue;
          String updated = xml ? almlk.Renamer.renameResource(content, symbol, newName)
              : almlk.Renamer.renameAll(content, symbol, newName);
          if (!updated.equals(content)) { fileRepository.writeTextBlocking(ref, updated); changed++; }
        } catch (Throwable ignored) { }
      }
      final int n = changed;
      post(() -> Toast.makeText(getContext(),
          UiStrings.format(getContext(), "ui_rename_complete", symbol, newName, n + 1),
          Toast.LENGTH_LONG).show());
    });
  }


  // ---------------- توليد الأعضاء المستهدفة في Java ----------------
  private static int commonPrefixLength(String first, String second) {
    int limit = Math.min(first.length(), second.length());
    int offset = 0;
    while (offset < limit && first.charAt(offset) == second.charAt(offset)) offset++;
    return offset;
  }

  public void codegenSetters() {
    if (code == null) return;
    codegenSetters(code.getSelectionStart(), code.getSelectionEnd());
  }

  private void codegenSetters(int selectionStart, int selectionEnd) {
    if (code == null || !isActiveFileWritable()) return;
    String text = code.getText().toString();
    if (!almlk.CodeGen.hasFieldTarget(text, selectionStart, selectionEnd)) {
      Toast.makeText(getContext(), UiStrings.get(getContext(), "ui_select_field_or_name"), Toast.LENGTH_LONG).show();
      return;
    }
    String result = almlk.CodeGen.createSettersGetters(text, selectionStart, selectionEnd);
    if (result == null) {
      Toast.makeText(getContext(), UiStrings.get(getContext(), "ui_accessors_already_exist"), Toast.LENGTH_LONG).show();
      return;
    }
    int start = Math.max(0, Math.min(selectionStart, selectionEnd));
    int end = Math.max(start, Math.max(selectionStart, selectionEnd));
    int insertionPoint = commonPrefixLength(text, result);
    int delta = result.length() - text.length();
    if (start >= insertionPoint) start += delta;
    if (end >= insertionPoint) end += delta;
    code.replaceRange(0, text.length(), result);
    code.setSelection(Math.min(start, code.length()), Math.min(end, code.length()));
    code.refreshNow();
    Toast.makeText(getContext(), UiStrings.get(getContext(), "ui_field_accessors_generated"), Toast.LENGTH_SHORT).show();
  }

  public void codegenConstructor() {
    if (code == null) return;
    codegenConstructor(code.getSelectionStart(), code.getSelectionEnd());
  }

  private void codegenConstructor(int selectionStart, int selectionEnd) {
    if (code == null || !isActiveFileWritable()) return;
    String text = code.getText().toString();
    String result = almlk.CodeGen.createConstructor(text, selectionStart, selectionEnd);
    if (result == null) {
      Toast.makeText(getContext(), UiStrings.get(getContext(), "ui_constructor_exists_or_type_missing"), Toast.LENGTH_LONG).show();
      return;
    }
    int start = Math.max(0, Math.min(selectionStart, selectionEnd));
    int end = Math.max(start, Math.max(selectionStart, selectionEnd));
    int insertionPoint = commonPrefixLength(text, result);
    int delta = result.length() - text.length();
    if (start >= insertionPoint) start += delta;
    if (end >= insertionPoint) end += delta;
    code.replaceRange(0, text.length(), result);
    code.setSelection(Math.min(start, code.length()), Math.min(end, code.length()));
    code.refreshNow();
    Toast.makeText(getContext(), UiStrings.get(getContext(), "ui_constructor_generated"), Toast.LENGTH_SHORT).show();
  }

  public void codegenExtractResource() {
    if (code == null || !code.hasSelection()) { Toast.makeText(getContext(), UiStrings.get(getContext(), "ui_select_text_first"), Toast.LENGTH_SHORT).show(); return; }
    final String text = code.getText().toString();
    final int s0 = code.getSelectionStart(), e0 = code.getSelectionEnd();
    final String value = text.substring(s0, e0);
    final android.widget.EditText input = new android.widget.EditText(getContext());
    input.setHint(UiStrings.get(getContext(), "ui_resource_name_hint"));
    new android.app.AlertDialog.Builder(getContext())
        .setTitle(UiStrings.format(getContext(), "ui_extract_resource_title", value))
        .setView(input)
        .setPositiveButton(UiStrings.get(getContext(), "ui_action_extract"), (d, w) -> {
          String name = input.getText().toString().trim();
          String result = almlk.CodeGen.extractResource(text, s0, e0, name);
          if (result == null) { Toast.makeText(
            getContext(),
            UiStrings.format(getContext(), "ui_invalid_symbol_selection", name),
            Toast.LENGTH_LONG)
            .show(); return; }
          code.replaceRange(0, text.length(), result);
          appendStringResource(name, value);
        })
        .setNegativeButton(UiStrings.get(getContext(), "dialog_cancel"), null)
        .show();
  }

  /** يلحق {@code <string>} بـres/values/strings.xml ضمن جذر المشروع المشتق من الملف النشط. */
  private void appendStringResource(final String name, final String value) {
    final String active = activeFile;
    completionWorker.execute(() -> {
      try {
        java.io.File dir = active == null ? null : new java.io.File(active).getParentFile();
        while (dir != null && !(new java.io.File(dir, "res").isDirectory())) dir = dir.getParentFile();
        if (dir == null) return;
        java.io.File values = new java.io.File(dir, "res/values");
        values.mkdirs();
        java.io.File strings = new java.io.File(values, "strings.xml");
        String content = strings.exists()
            ? new String(java.nio.file.Files.readAllBytes(strings.toPath()), "UTF-8")
            : "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<resources>\n</resources>\n";
        int close = content.lastIndexOf("</resources>");
        if (close < 0) close = content.length();
        String updated = content.substring(0, close) + almlk.CodeGen.stringEntry(name, value) + content.substring(close);
        java.nio.file.Files.write(strings.toPath(), updated.getBytes("UTF-8"));
        post(
            () ->
                Toast.makeText(
                        getContext(),
                        UiStrings.format(getContext(), "ui_resource_added_to_strings", name),
                        Toast.LENGTH_SHORT)
                    .show());
      } catch (Throwable ignored) { }
    });
  }

  public java.util.List<String> completions() {
    java.util.List<ProjectSymbolIndex.CompletionItem> detailed =
        KayStyleCompletionEngine.complete(
            activeFile, code.getText().toString(), code.getSelectionStart());
    java.util.ArrayList<String> values = new java.util.ArrayList<>();
    for (ProjectSymbolIndex.CompletionItem item : detailed) values.add(item.insertText);
    return values;
  }

  public void applyCompletion(String value) {
    code.applyCompletion(value);
  }

  public void closeCurrent() {
    if (activeFile == null) return;
    LinearLayout tab = tabs.remove(activeFile);
    if (tab != null) tabStrip.removeView(tab);
    fileContents.remove(activeFile);
    lazySessionFiles.remove(activeFile);
    lazySessionReferences.remove(activeFile);
    sessionReferences.remove(activeFile);
    sessionCursors.remove(activeFile);
    sessionScrollX.remove(activeFile);
    sessionScrollY.remove(activeFile);
    activeFile = null;
    if (tabs.isEmpty()) {
      setVisibility(GONE);
      code.setText("");
    } else selectFile(tabs.keySet().iterator().next());
  }

  public void closeAll() {
    tabs.clear();
    fileContents.clear();
    lazySessionFiles.clear();
    lazySessionReferences.clear();
    sessionReferences.clear();
    sessionCursors.clear();
    sessionScrollX.clear();
    sessionScrollY.clear();
    loadingFile = null;
    tabStrip.removeAllViews();
    activeFile = null;
    code.setText("");
    setVisibility(GONE);
  }

  /** أيقونة شريط الملف المفتوح: من {@code almlk.FileTypeIcons} وحده (كانت نسخة موازية ناقصة csv). */
  private int iconForFile(String name) {
    return almlk.FileTypeIcons.forFile(name);
  }

  /**
   * لونُ نصِّ شريطِ الملفاتِ المفتوحة: **أسودُ على الثيمِ الفاتحِ وأبيضُ على الداكن** — كانَ التبديلُ
   * بينَ التبويباتِ يكتبُ WHITE/LTGRAY ثابتَينِ بعدَ كلِّ ثيمٍ فيختفي اسمُ الملفِ على الشريطِ الفاتح
   * (أو يبهتُ على الداكن). والباقي من اللونِ نفسِهِ بألفاٍ مخفوضٍ، فالحالةُ لا تُبدِّلُ الدرجة.
   */
  private int tabLabelColor(boolean active) {
    int foreground = ThemeConfig.foregroundFor(new ThemeConfig(getContext()).isDark());
    return active ? (foreground | 0xFF000000) : (0xB3000000 | (foreground & 0x00FFFFFF));
  }

  private TextView text(String value, int size, int color) {
    TextView t = new TextView(getContext());
    t.setText(value);
    t.setTextSize(size);
    t.setTextColor(color);
    return t;
  }

  @Override
  protected void onAttachedToWindow() {
    super.onAttachedToWindow();
    if (completionWorker.isShutdown())
      completionWorker = java.util.concurrent.Executors.newSingleThreadExecutor();
    if (sessionWorker.isShutdown())
      sessionWorker = java.util.concurrent.Executors.newSingleThreadExecutor();
    if (completionLookupWorker.isShutdown())
      completionLookupWorker = java.util.concurrent.Executors.newSingleThreadExecutor();
    if (fileRepository == null) fileRepository = new FileSystemRepository(getContext());
    if (autoSaveManager == null) autoSaveManager = new AtomicSaveManager(getContext());
  }

  @Override
  protected void onDetachedFromWindow() {
    removeCallbacks(completionTask);
    dismissCompletions();
    completionWorker.shutdownNow();
    sessionWorker.shutdownNow();
    completionLookupWorker.shutdownNow();
    if (fileRepository != null) {
      fileRepository.close();
      fileRepository = null;
    }
    if (autoSaveManager != null) {
      autoSaveManager.close();
      autoSaveManager = null;
    }
    super.onDetachedFromWindow();
  }

  private int dp(int n) {
    return (int) (n * getResources().getDisplayMetrics().density + .5f);
  }

  private String sample(String name) {
    if (name.endsWith(".xml"))
      return "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n"
          + "<LinearLayout xmlns:android=\"http://schemas.android.com/apk/res/android\"\n"
          + "    android:layout_width=\"match_parent\"\n"
          + "    android:layout_height=\"match_parent\" />";
    return "package com.example.myapp;\n\n"
        + "import android.app.Activity;\n"
        + "import android.os.Bundle;\n\n"
        + "public class "
        + name.replace(".java", "")
        + " extends Activity {\n"
        + "    @Override\n"
        + "    protected void onCreate(Bundle state) {\n"
        + "        super.onCreate(state);\n"
        + "    }\n"
        + "}";
  }
}
