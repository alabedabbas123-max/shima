package com.shima.demo;

import android.content.Context;
import android.content.res.Resources;
import com.shima.editor.core.LocalizedIOException;

/** Resolves stable string-resource names used by the platform-independent UI catalogues. */
public final class UiStrings {
  private UiStrings() {}

  public static String get(Context context, String resourceName) {
    Context resources = currentLocaleContext(context);
    int resourceId = resolve(resources, resourceName);
    return resourceId == 0 ? resourceName : resources.getString(resourceId);
  }

  public static String format(Context context, String resourceName, Object... arguments) {
    Context resources = currentLocaleContext(context);
    int resourceId = resolve(resources, resourceName);
    if (resourceId == 0) return resourceName;
    try {
      return resources.getResources().getString(resourceId, arguments);
    } catch (IllegalArgumentException mismatch) {
      // قالبٌ وحُجَّةٌ لا يَتَّفِقانِ («‏%1$d‏» بِسِلسِلَةٍ): الصَّفحَةُ تَعرِضُ الرِّسالةَ لا الانهيارَ.
      // الانهيارُ هُنا كانَ يَقعُ بعدَ نَجاحِ الإصلاحِ، أي أنَّ المُستَخدِمَ يَفقَدُ الخَبَرَ مَعَ أنَ
      // الشيفرَةَ تَمَّ تَعدِيلُها (جهازُ ٤١، ‏QuickFixExecutor.applyInTab:128‏). والحلُّ الجِذريُّ في
      // ‏QuickFix.createdArg‏ و‏ProjectDiagnosticsSnapshot‏؛ هذا الحارسُ يُبطِلُ الفِعلَةَ كلَّها.
      return almlk.UiFormat.substitute(resources.getResources().getString(resourceId), arguments);
    }
  }

  /** Returns a resource-backed I/O message in the app's selected locale, including nested causes. */
  public static String message(Context context, Throwable error) {
    for (Throwable current = error; current != null; current = current.getCause()) {
      if (current instanceof LocalizedIOException) {
        LocalizedIOException localized = (LocalizedIOException) current;
        return format(context, localized.resourceKey(), localized.arguments());
      }
    }
    return error == null || error.getMessage() == null ? "" : error.getMessage();
  }

  /** Application contexts survive Activity recreation; re-wrap them so deferred UI text uses the latest choice. */
  private static Context currentLocaleContext(Context context) {
    return context instanceof ShimaApplication ? ShimaApplication.localize(context) : context;
  }

  private static int resolve(Context context, String resourceName) {
    if (context == null || resourceName == null || resourceName.isEmpty()) return 0;
    Resources resources = context.getResources();
    return resources.getIdentifier(resourceName, "string", context.getPackageName());
  }
}
