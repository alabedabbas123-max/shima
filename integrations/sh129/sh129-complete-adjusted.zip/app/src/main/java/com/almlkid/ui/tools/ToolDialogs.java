package com.almlkid.ui.tools;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Typeface;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import com.shima.demo.UiStrings;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;

/** حوارات أدوات › تهريب الكود، ونافذة نص قابلة للنسخ، ومنتقي مجلد بسيط تشترك فيه الأدوات. */
public final class ToolDialogs {

  private ToolDialogs() {}

  static String ui(Context context, String key) {
    return UiStrings.get(context, key);
  }

  static String uiFormat(Context context, String key, Object... values) {
    return UiStrings.format(context, key, values);
  }

  static int dp(Context context, int value) {
    return Math.round(value * context.getResources().getDisplayMetrics().density);
  }

  public static void copy(Context context, CharSequence text) {
    ClipboardManager clipboard = (ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
    if (clipboard != null) clipboard.setPrimaryClip(ClipData.newPlainText("shima", text));
    Toast.makeText(context, ui(context, "tools_copied"), Toast.LENGTH_SHORT).show();
  }

  static LinearLayout column(Context context) {
    LinearLayout box = new LinearLayout(context);
    box.setOrientation(LinearLayout.VERTICAL);
    int pad = dp(context, 20);
    box.setPadding(pad, dp(context, 8), pad, 0);
    return box;
  }

  static EditText field(Context context, String hint, String text, boolean multiLine) {
    EditText input = new EditText(context);
    input.setHint(hint);
    if (text != null) input.setText(text);
    if (multiLine) {
      input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE
          | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
      input.setGravity(Gravity.TOP | Gravity.START);
      input.setMinLines(6);
      input.setMaxLines(12);
      input.setHorizontallyScrolling(false);
      input.setTypeface(Typeface.MONOSPACE);
    } else {
      input.setSingleLine(true);
    }
    return input;
  }

  /** تهريب Java: حقل نص وخيار appendLine؛ الأزرار لا تغلق الحوار (كالمرجع). */
  public static void showJavaEscape(final Activity activity) {
    showEscape(activity, true);
  }

  /** تهريب XML بالكيانات الخمسة وعكسها. */
  public static void showXmlEscape(final Activity activity) {
    showEscape(activity, false);
  }

  private static void showEscape(final Activity activity, final boolean java) {
    LinearLayout box = column(activity);
    final EditText input = field(activity, java ? "Java" : "XML", null, true);
    box.addView(input, new LinearLayout.LayoutParams(-1, -2));
    final CheckBox appendLine = new CheckBox(activity);
    appendLine.setText(ui(activity, "tools_append_line"));
    if (java) box.addView(appendLine);
    ScrollView scroll = new ScrollView(activity);
    scroll.addView(box);
    final AlertDialog dialog =
        new AlertDialog.Builder(activity)
            .setTitle(ui(activity, "tools_code_escape_title") + (java ? " · Java" : " · XML"))
            .setView(scroll)
            .setPositiveButton(ui(activity, "tools_escape"), null)
            .setNegativeButton(ui(activity, "tools_invert_escape"), null)
            .setNeutralButton(ui(activity, "command_copy"), null)
            .create();
    dialog.show();
    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
      String text = input.getText().toString();
      input.setText(java ? almlk.CodeEscaper.escapeJava(text, appendLine.isChecked()) : almlk.CodeEscaper.escapeXml(text));
    });
    dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener(v -> {
      String text = input.getText().toString();
      input.setText(java ? almlk.CodeEscaper.unescapeJava(text, appendLine.isChecked()) : almlk.CodeEscaper.unescapeXml(text));
    });
    dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v -> copy(activity, input.getText()));
  }

  /** نص طويل قابل للتحديد مع زر نسخ. */
  public static void showText(Activity activity, String title, final String text) {
    TextView view = new TextView(activity);
    view.setText(text);
    view.setTextIsSelectable(true);
    view.setTypeface(Typeface.MONOSPACE);
    view.setTextSize(12);
    int pad = dp(activity, 16);
    view.setPadding(pad, pad / 2, pad, pad / 2);
    ScrollView scroll = new ScrollView(activity);
    android.widget.HorizontalScrollView wide = new android.widget.HorizontalScrollView(activity);
    wide.addView(view);
    scroll.addView(wide);
    new AlertDialog.Builder(activity)
        .setTitle(title)
        .setView(scroll)
        .setPositiveButton(ui(activity, "command_copy"), (d, w) -> copy(activity, text))
        .setNegativeButton(android.R.string.cancel, null)
        .show();
  }

  /** منتقي مجلد: قائمة المجلدات الفرعية مع «..» للصعود، و«موافق» يختار المجلد الحالي. */
  public static void pickFolder(final Activity activity, File start, final Consumer<File> chosen) {
    File dir = start;
    while (dir != null && !dir.isDirectory()) dir = dir.getParentFile();
    if (dir == null) dir = activity.getFilesDir();
    showFolder(activity, dir, chosen);
  }

  private static void showFolder(final Activity activity, final File dir, final Consumer<File> chosen) {
    final List<File> entries = new ArrayList<>();
    final List<String> labels = new ArrayList<>();
    File parent = dir.getParentFile();
    if (parent != null && parent.canRead()) {
      entries.add(parent);
      labels.add("..");
    }
    File[] children = dir.listFiles(File::isDirectory);
    if (children != null) {
      Arrays.sort(children, (a, b) -> a.getName().compareToIgnoreCase(b.getName()));
      for (File c : children) {
        entries.add(c);
        labels.add(c.getName() + "/");
      }
    }
    ListView list = new ListView(activity);
    list.setAdapter(new ArrayAdapter<>(activity, android.R.layout.simple_list_item_1, labels));
    final AlertDialog dialog =
        new AlertDialog.Builder(activity)
            .setTitle(dir.getAbsolutePath())
            .setView(list)
            .setPositiveButton(android.R.string.ok, (d, w) -> chosen.accept(dir))
            .setNegativeButton(android.R.string.cancel, null)
            .show();
    list.setOnItemClickListener((p, v, position, id) -> {
      dialog.dismiss();
      showFolder(activity, entries.get(position), chosen);
    });
  }

  /** زر بعرض كامل داخل حوار. */
  static Button button(Context context, String text, View.OnClickListener click) {
    Button b = new Button(context);
    b.setText(text);
    b.setAllCaps(false);
    b.setOnClickListener(click);
    return b;
  }
}
