package com.almlkid.ui.preferences;

/** المرحلة 2: جسر أوامر Build & Run بين شظية الإعدادات والمضيف (MainActivity). */
public final class BuildActions {

  public interface Delegate {
    void refreshMaven();

    void ndkToggle();

    void applyEditorVisual();

    void writeProguardConfig();

    void configureGradle();

    /** W22/1: «Gradle completion» يفتحُ ملفَّ القواعدِ (يُنشَأُ برأسٍ مُعلَّقٍ إن غابَ). */
    void openGradleRules();
  }

  public static volatile Delegate delegate;

  private BuildActions() {}
}
