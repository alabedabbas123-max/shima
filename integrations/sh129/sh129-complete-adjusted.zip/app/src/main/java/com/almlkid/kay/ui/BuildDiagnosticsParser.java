package com.almlkid.kay.ui;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Parses file/line diagnostics emitted by Gradle, javac, AAPT, and Kotlin compilation. */
public final class BuildDiagnosticsParser {
  private static final Pattern JAVA_LOCATION =
      Pattern.compile(
          "^\\s*(?:e:\\s*)?(.+?\\.(?:java|kt|xml|gradle(?:\\.kts)?|kts))(?:['\\\"])?:(\\d+)(?::(\\d+))?:\\s*(?:(error|warning):\\s*)?(.*)$",
          Pattern.CASE_INSENSITIVE);
  private static final Pattern KOTLIN_LOCATION =
      Pattern.compile(
          "^\\s*e:\\s*(.+?\\.kt):\\s*\\((\\d+)\\s*,\\s*(\\d+)\\)\\s*:\\s*(.*)$",
          Pattern.CASE_INSENSITIVE);
  private static final Pattern GRADLE_SCRIPT_LOCATION =
      Pattern.compile(
          "^\\s*(?:Build|Script) file ['\"]?(.+?\\.gradle(?:\\.kts)?)['\"]?\\s+line:\\s*(\\d+)\\s*$",
          Pattern.CASE_INSENSITIVE);
  private static final Pattern GRADLE_COLON_LOCATION =
      Pattern.compile(
          "^\\s*(.+?\\.gradle(?:\\.kts)?)(?:['\\\"])?\\s*:\\s*(\\d+):\\s*(.*)$",
          Pattern.CASE_INSENSITIVE);
  private static final Pattern GRADLE_COLUMN =
      Pattern.compile("(?:@\\s*)?line\\s+\\d+\\s*,\\s*column\\s+(\\d+)", Pattern.CASE_INSENSITIVE);
  private static final Pattern SYMBOL_METHOD =
      Pattern.compile("\\bmethod\\s+([A-Za-z_$][A-Za-z0-9_$]*)\\s*\\(");
  private static final int MAX_ERRORS = 5000;

  private BuildDiagnosticsParser() {}

  public static final class BuildError {
    public final String fileName;
    public final int line;
    public final int column;
    public final boolean warning;
    public final String code;
    public final String message;
    public final String sourceLine;
    public final String symbol;

    private BuildError(
        String fileName,
        int line,
        int column,
        boolean warning,
        String code,
        String message,
        String sourceLine,
        String symbol) {
      this.fileName = normalizeFileName(fileName);
      this.line = Math.max(1, line);
      this.column = Math.max(1, column);
      this.warning = warning;
      this.code = code == null ? (warning ? "BUILD_WARNING" : "BUILD_ERROR") : code;
      this.message = trimMessage(message);
      this.sourceLine = sourceLine == null ? "" : sourceLine.trim();
      this.symbol = symbol == null ? "" : symbol;
    }

    @Override
    public String toString() {
      return fileName + ":" + line + ":" + column + ": " + message;
    }
  }

  public static ArrayList<BuildError> parse(String output) {
    LinkedHashMap<String, BuildError> unique = new LinkedHashMap<>();
    if (output == null || output.isEmpty()) return new ArrayList<>();
    String[] lines = output.replace("\r", "").split("\n", -1);
    for (int i = 0; i < lines.length && unique.size() < MAX_ERRORS; i++) {
      String raw = lines[i];
      Matcher kotlin = KOTLIN_LOCATION.matcher(raw);
      if (kotlin.matches()) {
        String details = kotlin.group(4).trim();
        String snippet = "";
        int column = parse(kotlin.group(3), 1);
        for (int n = i + 1; n < lines.length && n <= i + 4; n++) {
          String candidate = lines[n];
          int caret = candidate.indexOf('^');
          if (caret >= 0) {
            column = Math.max(1, caret + 1);
            snippet = n > i + 1 ? lines[n - 1].trim() : "";
            break;
          }
          if (candidate.trim().startsWith("symbol:")
              || candidate.trim().startsWith("location:")) details += " — " + candidate.trim();
        }
        add(
            unique,
            new BuildError(
                kotlin.group(1), parse(kotlin.group(2), 1), column, false, "KOTLIN_ERROR",
                details.isEmpty() ? "Kotlin compilation error." : details, snippet,
                findMethod(details)));
        continue;
      }

      Matcher location = JAVA_LOCATION.matcher(raw);
      if (location.matches()) {
        String file = location.group(1);
        int line = parse(location.group(2), 1);
        int column = parse(location.group(3), 1);
        boolean warning = "warning".equalsIgnoreCase(location.group(4));
        String severity = location.group(4);
        String message = location.group(5) == null ? "" : location.group(5).trim();
        // Some Kotlin/Gradle compilers omit an explicit `error:` label. The location line is still
        // diagnostic output if its body contains a known compiler error marker.
        if (severity == null && !looksLikeCompilerDiagnostic(message)) continue;
        String snippet = "";
        String symbol = findMethod(message);
        for (int n = i + 1; n < lines.length && n <= i + 9; n++) {
          String detail = lines[n].trim();
          if (detail.startsWith("symbol:")) {
            message = appendDetail(message, detail);
            String parsed = findMethod(detail);
            if (!parsed.isEmpty()) symbol = parsed;
          } else if (detail.startsWith("location:")) {
            message = appendDetail(message, detail);
          }
          int caret = lines[n].indexOf('^');
          if (caret >= 0) {
            column = Math.max(1, caret + 1);
            if (n > i + 1 && snippet.isEmpty()) snippet = lines[n - 1].trim();
          }
          if (n > i + 1
              && (detail.startsWith("error:") || detail.startsWith("warning:")
                  || detail.startsWith("FAILURE: ") || detail.startsWith("> Task "))) break;
        }
        if (isGradleFile(file)) column = gradleColumn(message, lines, i, column);
        String code = isGradleFile(file) ? "GRADLE_ERROR" : warning ? "BUILD_WARNING" : "BUILD_ERROR";
        add(
            unique,
            new BuildError(
                file, line, column, warning, code,
                message.isEmpty() ? "Build reported an error." : message, snippet, symbol));
        continue;
      }

      Matcher gradle = GRADLE_SCRIPT_LOCATION.matcher(raw);
      if (gradle.matches()) {
        String gradleFile = normalizeFileName(gradle.group(1));
        int gradleLine = parse(gradle.group(2), 1);
        if (hasSpecificGradleLocation(lines, i, gradleFile, gradleLine)) continue;
        String message = "Gradle script error";
        String snippet = "";
        for (int n = i + 1; n < lines.length && n <= i + 8; n++) {
          String detail = lines[n].trim();
          if (detail.startsWith("> ")) {
            message = detail.substring(2).trim();
            break;
          }
          if (detail.startsWith("* What went wrong:")) continue;
          if (detail.startsWith("line ") || detail.startsWith("* ")) break;
        }
        add(
            unique,
            new BuildError(
                gradleFile,
                gradleLine,
                gradleColumn(message, lines, i, 1),
                false,
                "GRADLE_ERROR",
                message,
                snippet,
                findMethod(message)));
        continue;
      }

      Matcher gradleColon = GRADLE_COLON_LOCATION.matcher(raw);
      if (gradleColon.matches() && looksLikeCompilerDiagnostic(gradleColon.group(3))) {
        String message = gradleColon.group(3).trim();
        add(
            unique,
            new BuildError(
                gradleColon.group(1),
                parse(gradleColon.group(2), 1),
                gradleColumn(message, lines, i, 1),
                false,
                "GRADLE_ERROR",
                message,
                "",
                findMethod(message)));
      }
    }
    return new ArrayList<>(unique.values());
  }

  private static boolean hasSpecificGradleLocation(
      String[] lines, int startIndex, String file, int line) {
    int end = Math.min(lines.length, startIndex + 13);
    for (int i = startIndex + 1; i < end; i++) {
      Matcher javaLocation = JAVA_LOCATION.matcher(lines[i]);
      if (javaLocation.matches()
          && isGradleFile(javaLocation.group(1))
          && parse(javaLocation.group(2), -1) == line
          && sameGradleFile(file, javaLocation.group(1))) return true;
      Matcher colonLocation = GRADLE_COLON_LOCATION.matcher(lines[i]);
      if (colonLocation.matches()
          && parse(colonLocation.group(2), -1) == line
          && sameGradleFile(file, colonLocation.group(1))) return true;
    }
    return false;
  }

  private static int gradleColumn(String message, String[] lines, int startIndex, int fallback) {
    Matcher inMessage = GRADLE_COLUMN.matcher(message == null ? "" : message);
    if (inMessage.find()) return Math.max(1, parse(inMessage.group(1), fallback));
    int end = Math.min(lines.length, startIndex + 9);
    for (int i = startIndex + 1; i < end; i++) {
      String detail = lines[i];
      Matcher inDetail = GRADLE_COLUMN.matcher(detail);
      if (inDetail.find()) return Math.max(1, parse(inDetail.group(1), fallback));
      int caret = detail.indexOf('^');
      if (caret >= 0) return Math.max(1, caret + 1);
      String trimmed = detail.trim();
      if (trimmed.startsWith("FAILURE:") || trimmed.startsWith("> Task ")) break;
    }
    return Math.max(1, fallback);
  }

  private static boolean isGradleFile(String file) {
    if (file == null) return false;
    String lower = file.toLowerCase(Locale.US);
    return lower.endsWith(".gradle") || lower.endsWith(".gradle.kts");
  }

  private static boolean sameGradleFile(String first, String second) {
    String a = normalizeFileName(first).replace('\\', '/').toLowerCase(Locale.US);
    String b = normalizeFileName(second).replace('\\', '/').toLowerCase(Locale.US);
    return !a.isEmpty()
        && !b.isEmpty()
        && (a.equals(b) || a.endsWith("/" + b) || b.endsWith("/" + a));
  }

  private static void add(LinkedHashMap<String, BuildError> values, BuildError item) {
    String key = item.fileName + "|" + item.line + "|" + item.column + "|" + item.code + "|" + item.message;
    if (!values.containsKey(key)) values.put(key, item);
  }

  private static boolean looksLikeCompilerDiagnostic(String message) {
    if (message == null || message.isEmpty()) return false;
    String lower = message.toLowerCase(Locale.US);
    return lower.contains("error")
        || lower.contains("cannot find symbol")
        || lower.contains("unresolved reference")
        || lower.contains("unexpected input")
        || lower.contains("could not compile")
        || lower.contains("failed to compile")
        || lower.contains("not a statement")
        || lower.contains("expected")
        || lower.contains("type mismatch");
  }

  private static String appendDetail(String message, String detail) {
    if (message == null || message.isEmpty()) return detail;
    return message.contains(detail) ? message : message + " — " + detail;
  }

  private static String findMethod(String text) {
    if (text == null || text.isEmpty()) return "";
    Matcher matcher = SYMBOL_METHOD.matcher(text);
    return matcher.find() ? matcher.group(1) : "";
  }

  private static int parse(String value, int fallback) {
    try {
      return Integer.parseInt(value);
    } catch (RuntimeException ignored) {
      return fallback;
    }
  }

  private static String normalizeFileName(String value) {
    if (value == null) return "";
    String path = value.trim().replace('\\', '/');
    int quoteAt = path.indexOf('\'');
    char quote = '\'';
    if (quoteAt < 0) {
      quoteAt = path.indexOf('"');
      quote = '"';
    }
    if (quoteAt >= 0) {
      String prefix = path.substring(0, quoteAt).trim().toLowerCase(Locale.US);
      int quoteEnd = path.lastIndexOf(quote);
      boolean pathPrefix =
          prefix.endsWith("build file") || prefix.endsWith("script file") || prefix.isEmpty();
      if (pathPrefix) {
        if (quoteEnd > quoteAt) path = path.substring(quoteAt + 1, quoteEnd);
        else path = path.substring(quoteAt + 1);
      }
    }
    if (path.startsWith("file://")) path = path.substring("file://".length());
    return path.trim();
  }

  private static String trimMessage(String value) {
    if (value == null) return "";
    String message = value.replace('\t', ' ').trim();
    if (message.length() > 600) message = message.substring(0, 597) + "...";
    return message;
  }
}
