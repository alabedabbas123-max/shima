package com.almlkid.ui;

import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Color;
import android.text.Editable;
import android.text.InputType;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.TextWatcher;
import android.text.style.BackgroundColorSpan;
import android.text.style.ForegroundColorSpan;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import com.shima.demo.UiStrings;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * «إضافة اعتماد»: قائمة مكتبات الدعم (AppCompat) أو AndroidX مع بحث وتحديد متعدد يبقى عبر
 * البحث وتبديل القائمة، ثم محرر الإحداثيات الذي يتحقق من كل سطر قبل تسليمه للكتابة.
 */
public final class AddDependencyDialog {

  /** يستلم أسطر الاعتماد الصالحة الجاهزة للكتابة في ملف البناء. */
  public interface Listener {
    void onDependencyLines(List<String> lines);
  }

  private final Context context;
  private final boolean kts;
  private final Listener listener;
  private final List<String> androidx = almlk.AndroidXMigration.androidxNames();
  private final List<String> appcompat = almlk.AndroidXMigration.appcompatNames();
  /** الاسم ← هل هو من قائمة AndroidX (للحفاظ على ترتيب التحديد). */
  private final LinkedHashMap<String, Boolean> selected = new LinkedHashMap<>();
  private final ArrayList<String> visible = new ArrayList<>();
  private boolean showAndroidX = true;
  private String query = "";
  private AlertDialog dialog;
  private Adapter adapter;

  private AddDependencyDialog(Context context, boolean kts, Listener listener) {
    this.context = context;
    this.kts = kts;
    this.listener = listener;
  }

  public static void show(Context context, boolean kts, Listener listener) {
    new AddDependencyDialog(context, kts, listener).showList();
  }

  private String ui(String key) {
    return UiStrings.get(context, key);
  }

  private int dp(float value) {
    return Math.round(value * context.getResources().getDisplayMetrics().density);
  }

  private void showList() {
    LinearLayout root = new LinearLayout(context);
    root.setOrientation(LinearLayout.VERTICAL);
    final EditText search = new EditText(context);
    search.setSingleLine(true);
    search.setHint(ui("ui_add_dependency_search_hint"));
    search.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
    LinearLayout.LayoutParams searchParams = new LinearLayout.LayoutParams(-1, -2);
    searchParams.setMargins(dp(16), dp(8), dp(16), 0);
    root.addView(search, searchParams);
    ListView list = new ListView(context);
    list.setFastScrollEnabled(true);
    adapter = new Adapter();
    list.setAdapter(adapter);
    list.setOnItemClickListener(
        (parent, view, position, id) -> {
          String name = visible.get(position);
          if (selected.containsKey(name)) selected.remove(name);
          else selected.put(name, showAndroidX);
          adapter.notifyDataSetChanged();
          updateTitle();
        });
    root.addView(list, new LinearLayout.LayoutParams(-1, 0, 1));
    search.addTextChangedListener(
        new TextWatcher() {
          public void beforeTextChanged(CharSequence s, int a, int b, int c) {}

          public void onTextChanged(CharSequence s, int a, int b, int c) {}

          public void afterTextChanged(Editable s) {
            query = s.toString().trim();
            filter();
          }
        });
    dialog =
        new AlertDialog.Builder(context)
            .setTitle(ui("ui_add_dependency_title"))
            .setView(root)
            .setPositiveButton(ui("ui_add_to_project_add"), null)
            .setNegativeButton(ui("dialog_cancel"), null)
            .setNeutralButton(ui("ui_add_dependency_more"), null)
            .create();
    filter();
    dialog.show();
    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> onAdd());
    final Button more = dialog.getButton(AlertDialog.BUTTON_NEUTRAL);
    more.setOnClickListener(v -> showListChoice(more));
  }

  private void showListChoice(View anchor) {
    PopupMenu popup = new PopupMenu(context, anchor);
    Menu menu = popup.getMenu();
    menu.add(1, 1, 0, "AppCompat").setCheckable(true).setChecked(!showAndroidX);
    menu.add(1, 2, 1, "AndroidX").setCheckable(true).setChecked(showAndroidX);
    menu.setGroupCheckable(1, true, true);
    // القائمةُ المضمَنةُ جدولُ أسماءَ؛ التصفُّحُ يسألُ المخبأَ والمستودعاتِ فعلًا — وكلاهما يبقى.
    menu.add(2, 3, 0, ui("ui_maven_browse_title"));
    popup.setOnMenuItemClickListener(
        item -> {
          if (item.getItemId() == 3) {
            if (dialog != null) dialog.dismiss();
            com.almlkid.ui.MavenBrowseDialog.show(context, this::showEditor);
            return true;
          }
          boolean androidxChosen = item.getItemId() == 2;
          if (androidxChosen != showAndroidX) {
            showAndroidX = androidxChosen;
            filter();
          }
          return true;
        });
    popup.show();
  }

  /** تصفية متزامنة (القائمة بضع مئات من الأسطر): مطابقة جزئية بلا حساسية لحالة الأحرف. */
  private void filter() {
    visible.clear();
    String needle = query.toLowerCase(Locale.US);
    for (String name : showAndroidX ? androidx : appcompat) {
      if (needle.isEmpty() || name.toLowerCase(Locale.US).contains(needle)) visible.add(name);
    }
    if (adapter != null) adapter.notifyDataSetChanged();
    updateTitle();
  }

  private void updateTitle() {
    if (dialog == null) return;
    dialog.setTitle(
        selected.isEmpty()
            ? ui("ui_add_dependency_title")
            : UiStrings.format(context, "ui_add_dependency_title_count", selected.size()));
  }

  private void onAdd() {
    StringBuilder text = new StringBuilder();
    if (selected.isEmpty()) {
      if (query.indexOf(':') < 0) {
        Toast.makeText(context, ui("ui_add_dependency_none"), Toast.LENGTH_SHORT).show();
        return;
      }
      text.append(query);
    } else {
      Map<String, List<String>> installed = almlk.MavenStore.installedSnapshot();
      for (Map.Entry<String, Boolean> entry : selected.entrySet()) {
        if (text.length() > 0) text.append('\n');
        text.append(
            almlk.AndroidXMigration.coordinateFor(
                entry.getKey(), entry.getValue(), installed.get(entry.getKey())));
      }
    }
    dialog.dismiss();
    showEditor(text.toString());
  }

  /** محرر الإحداثيات: سطر لكل اعتماد، ويبقى مفتوحًا مع علامة خطأ عند أول سطر غير صالح. */
  private void showEditor(String initial) {
    LinearLayout box = new LinearLayout(context);
    box.setOrientation(LinearLayout.VERTICAL);
    box.setPadding(dp(24), dp(10), dp(24), 0);
    TextView hint = new TextView(context);
    hint.setText(ui("ui_add_dependency_version_hint"));
    hint.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
    hint.setPadding(0, 0, 0, dp(5));
    box.addView(hint, new LinearLayout.LayoutParams(-1, -2));
    final EditText editor = new EditText(context);
    editor.setMinWidth(dp(300));
    editor.setSingleLine(false);
    editor.setHorizontallyScrolling(true);
    editor.setGravity(Gravity.TOP | Gravity.START);
    editor.setInputType(
        InputType.TYPE_CLASS_TEXT
            | InputType.TYPE_TEXT_FLAG_MULTI_LINE
            | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
    editor.setText(initial);
    editor.setSelection(editor.length());
    HorizontalScrollView horizontal = new HorizontalScrollView(context);
    horizontal.addView(editor, new ViewGroup.LayoutParams(-2, -2));
    ScrollView vertical = new ScrollView(context);
    vertical.addView(horizontal, new ViewGroup.LayoutParams(-1, -2));
    box.addView(vertical, new LinearLayout.LayoutParams(-1, -2));
    final AlertDialog edit =
        new AlertDialog.Builder(context)
            .setTitle(ui("ui_add_dependency_title"))
            .setView(box)
            .setPositiveButton(android.R.string.ok, null)
            .setNegativeButton(ui("dialog_cancel"), null)
            .create();
    edit.show();
    final Button ok = edit.getButton(AlertDialog.BUTTON_POSITIVE);
    ok.setEnabled(editor.getText().toString().trim().length() > 0);
    editor.addTextChangedListener(
        new TextWatcher() {
          public void beforeTextChanged(CharSequence s, int a, int b, int c) {}

          public void onTextChanged(CharSequence s, int a, int b, int c) {}

          public void afterTextChanged(Editable s) {
            ok.setEnabled(s.toString().trim().length() > 0);
            editor.setError(null);
          }
        });
    ok.setOnClickListener(
        v -> {
          ArrayList<String> lines = new ArrayList<>();
          for (String raw : editor.getText().toString().split("\n")) {
            String line = raw.trim();
            if (line.isEmpty()) continue;
            String dependency = almlk.GradleDependencyEditor.dependencyLine(line, kts);
            if (dependency == null) {
              editor.setError(ui("ui_add_to_project_maven_invalid") + "\n" + line);
              editor.requestFocus();
              return;
            }
            lines.add(dependency);
          }
          if (lines.isEmpty()) return;
          edit.dismiss();
          listener.onDependencyLines(lines);
        });
  }

  private final class Adapter extends BaseAdapter {
    private final int accent = resolveAccent();

    public int getCount() {
      return visible.size();
    }

    public Object getItem(int position) {
      return visible.get(position);
    }

    public long getItemId(int position) {
      return position;
    }

    public View getView(int position, View convertView, ViewGroup parent) {
      Row row = convertView instanceof Row ? (Row) convertView : new Row(context);
      String name = visible.get(position);
      String prefix = (position + 1) + ". ";
      SpannableStringBuilder label = new SpannableStringBuilder(prefix).append(name);
      if (!query.isEmpty()) {
        int at = name.toLowerCase(Locale.US).indexOf(query.toLowerCase(Locale.US));
        if (at >= 0) {
          int start = prefix.length() + at;
          int end = start + query.length();
          label.setSpan(new BackgroundColorSpan(accent), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
          label.setSpan(new ForegroundColorSpan(Color.WHITE), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
      }
      row.text.setText(label);
      row.check.setChecked(selected.containsKey(name));
      return row;
    }

    private int resolveAccent() {
      TypedValue value = new TypedValue();
      if (context.getTheme().resolveAttribute(android.R.attr.colorAccent, value, true)
          && value.type >= TypedValue.TYPE_FIRST_COLOR_INT
          && value.type <= TypedValue.TYPE_LAST_COLOR_INT) return value.data;
      return 0xFF2196F3;
    }
  }

  private final class Row extends LinearLayout {
    final CheckBox check;
    final TextView text;

    Row(Context c) {
      super(c);
      setOrientation(HORIZONTAL);
      setGravity(Gravity.CENTER_VERTICAL);
      setPadding(dp(16), dp(8), dp(16), dp(8));
      check = new CheckBox(c);
      check.setClickable(false);
      check.setFocusable(false);
      addView(check, new LayoutParams(-2, -2));
      text = new TextView(c);
      text.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
      text.setPadding(dp(10), 0, 0, 0);
      addView(text, new LayoutParams(0, -2, 1));
    }
  }
}
