package com.almlkid.kay.ui;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Resolves local Smali labels, fields, methods, and class declarations without loading DEX code. */
public final class SmaliDefinitionResolver {
  private static final Pattern CLASS = Pattern.compile("(?m)^\\s*\\.class\\s+[^\\s]+\\s+(L[^;]+;)");
  private static final Pattern METHOD = Pattern.compile("(?m)^\\s*\\.method\\s+(?:[^\\s]+\\s+)*([A-Za-z0-9_$<>]+)");
  private static final Pattern FIELD = Pattern.compile("(?m)^\\s*\\.field\\s+(?:[^\\s]+\\s+)*([A-Za-z0-9_$]+):");
  private static final Pattern LABEL = Pattern.compile("(?m)^\\s*:([A-Za-z0-9_.$-]+)");

  private SmaliDefinitionResolver() {}

  public static ProjectSymbolIndex.DefinitionTarget resolve(
      String fileName, String source, int selectionStart, int selectionEnd) {
    String text = source == null ? "" : source;
    int[] range = tokenRange(text, selectionStart, selectionEnd);
    if (range[0] >= range[1]) return null;
    String wanted = text.substring(range[0], range[1]);
    String owner = "";
    Matcher classMatcher = CLASS.matcher(text);
    if (classMatcher.find()) owner = classMatcher.group(1);
    ProjectSymbolIndex.DefinitionTarget target = find(METHOD, text, wanted, fileName, owner);
    if (target != null) return target;
    target = find(FIELD, text, wanted, fileName, owner);
    if (target != null) return target;
    target = find(LABEL, text, wanted.startsWith(":") ? wanted.substring(1) : wanted, fileName, owner);
    if (target != null) return target;
    if (owner.equals(wanted) || owner.endsWith("/" + wanted + ";"))
      return new ProjectSymbolIndex.DefinitionTarget(fileName, owner, wanted, null, classMatcher.start(1), false);
    return null;
  }

  private static ProjectSymbolIndex.DefinitionTarget find(
      Pattern pattern, String source, String wanted, String fileName, String owner) {
    Matcher matcher = pattern.matcher(source);
    while (matcher.find()) {
      String value = matcher.group(1);
      if (value.equals(wanted))
        return new ProjectSymbolIndex.DefinitionTarget(fileName, owner, value, null, matcher.start(1), false);
    }
    return null;
  }

  private static int[] tokenRange(String source, int start, int end) {
    int safeStart = Math.max(0, Math.min(source.length(), Math.min(start, end)));
    int safeEnd = Math.max(safeStart, Math.min(source.length(), Math.max(start, end)));
    if (safeStart == safeEnd && safeStart < source.length() && !isToken(source.charAt(safeStart))) {
      if (safeStart > 0 && isToken(source.charAt(safeStart - 1))) safeStart--;
      else return new int[] {safeStart, safeEnd};
    }
    while (safeStart > 0 && isToken(source.charAt(safeStart - 1))) safeStart--;
    while (safeEnd < source.length() && isToken(source.charAt(safeEnd))) safeEnd++;
    if (safeStart > 0 && source.charAt(safeStart - 1) == ':') safeStart--;
    return new int[] {safeStart, safeEnd};
  }

  private static boolean isToken(char value) {
    return Character.isLetterOrDigit(value) || value == '_' || value == '$' || value == '<' || value == '>' || value == '-' || value == '/';
  }
}
