package com.almlkid.kay.ui;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentHashMap;

/** Builds a read-only, syntax-highlightable Java API view for Android/Java platform classes. */
public final class SystemApiSourceProvider {
  private static final Map<String, String> TYPE_ALIASES = new LinkedHashMap<>();
  private static final ConcurrentHashMap<String, GeneratedSource> CACHE =
      new ConcurrentHashMap<>();
  private static final String[] SEARCH_PACKAGES = {
    "android.view.",
    "android.widget.",
    "android.app.",
    "android.content.",
    "android.content.res.",
    "android.os.",
    "android.net.",
    "android.graphics.",
    "android.graphics.drawable.",
    "android.text.",
    "android.util.",
    "android.database.",
    "android.location.",
    "android.media.",
    "java.lang.",
    "java.util.",
    "java.io.",
    "java.net.",
    "java.nio.",
    "java.math."
  };

  static {
    alias("View", "android.view.View");
    alias("ViewGroup", "android.view.ViewGroup");
    alias("Menu", "android.view.Menu");
    alias("MenuItem", "android.view.MenuItem");
    alias("LayoutInflater", "android.view.LayoutInflater");
    alias("TextView", "android.widget.TextView");
    alias("EditText", "android.widget.EditText");
    alias("Button", "android.widget.Button");
    alias("ImageView", "android.widget.ImageView");
    alias("LinearLayout", "android.widget.LinearLayout");
    alias("FrameLayout", "android.widget.FrameLayout");
    alias("Toast", "android.widget.Toast");
    alias("Activity", "android.app.Activity");
    alias("Context", "android.content.Context");
    alias("Intent", "android.content.Intent");
    alias("SharedPreferences", "android.content.SharedPreferences");
    alias("Bundle", "android.os.Bundle");
    alias("Handler", "android.os.Handler");
    alias("Looper", "android.os.Looper");
    alias("Resources", "android.content.res.Resources");
    alias("Uri", "android.net.Uri");
    alias("Canvas", "android.graphics.Canvas");
    alias("Paint", "android.graphics.Paint");
    alias("Color", "android.graphics.Color");
    alias("Bitmap", "android.graphics.Bitmap");
    alias("Drawable", "android.graphics.drawable.Drawable");
    alias("Rect", "android.graphics.Rect");
    alias("CharSequence", "java.lang.CharSequence");
    alias("String", "java.lang.String");
    alias("Object", "java.lang.Object");
    alias("List", "java.util.List");
    alias("ArrayList", "java.util.ArrayList");
    alias("Map", "java.util.Map");
    alias("HashMap", "java.util.HashMap");
    alias("Set", "java.util.Set");
    alias("HashSet", "java.util.HashSet");
  }

  private SystemApiSourceProvider() {}

  private static void alias(String simple, String qualified) {
    TYPE_ALIASES.put(simple, qualified);
  }

  /** True when a simple or fully-qualified name resolves to a platform class on this runtime. */
  public static boolean canResolveType(String typeName) {
    return loadType(typeName) != null;
  }

  /** Resolves a platform class declaration to its virtual source tab. */
  public static ProjectSymbolIndex.DefinitionTarget resolveType(String typeName) {
    Class<?> type = loadType(typeName);
    if (type == null) return null;
    GeneratedSource generated = sourceFor(type);
    if (generated == null) return null;
    return target(type, type.getSimpleName(), generated.classOffset,
        ProjectSymbolIndex.DefinitionTarget.KIND_CLASS, generated.text);
  }

  /** Resolves a public field or method to the class that actually declares it. */
  public static ProjectSymbolIndex.DefinitionTarget resolveMember(
      String requestedType, String symbol) {
    Class<?> requested = loadType(requestedType);
    return requested == null ? null : resolveMember(requested, symbol);
  }

  /** Overload exposed for the pure-Java regression suite and platform-specific callers. */
  public static ProjectSymbolIndex.DefinitionTarget resolveMember(
      Class<?> requested, String symbol) {
    if (requested == null || symbol == null || symbol.isEmpty()) return null;
    try {
      Field field = requested.getField(symbol);
      Class<?> owner = field.getDeclaringClass();
      GeneratedSource generated = sourceFor(owner);
      Integer offset = generated == null ? null : generated.fieldOffsets.get(symbol);
      if (offset != null)
        return target(owner, symbol, offset,
            ProjectSymbolIndex.DefinitionTarget.KIND_FIELD, generated.text);
    } catch (Throwable ignored) {
      // A missing or inaccessible field must not block method resolution.
    }

    try {
      ArrayList<Method> matches = new ArrayList<>();
      for (Method method : requested.getMethods())
        if (symbol.equals(method.getName()) && !method.isBridge() && !method.isSynthetic())
          matches.add(method);
      Collections.sort(
          matches,
          (left, right) -> {
            int leftDistance = inheritanceDistance(requested, left.getDeclaringClass());
            int rightDistance = inheritanceDistance(requested, right.getDeclaringClass());
            if (leftDistance != rightDistance) return Integer.compare(leftDistance, rightDistance);
            return methodKey(left).compareTo(methodKey(right));
          });
      for (Method method : matches) {
        Class<?> owner = method.getDeclaringClass();
        GeneratedSource generated = sourceFor(owner);
        Integer offset = generated == null ? null : generated.methodOffsets.get(symbol);
        if (offset != null)
          return target(owner, symbol, offset,
              ProjectSymbolIndex.DefinitionTarget.KIND_METHOD, generated.text);
      }
    } catch (Throwable ignored) {
      // Some vendor framework classes expose incomplete reflection metadata; use the index stub.
    }
    return null;
  }

  /** Recreates a system class tab after session restore (sessions intentionally store metadata only). */
  public static String sourceForFileName(String fileName) {
    if (fileName == null) return null;
    String path = fileName.replace('\\', '/');
    if (!path.toLowerCase(java.util.Locale.US).endsWith(".class")) return null;
    String qualified = path.substring(0, path.length() - ".class".length()).replace('/', '.');
    Class<?> type = loadType(qualified);
    if (type == null) {
      int dot = qualified.lastIndexOf('.');
      type = loadType(dot < 0 ? qualified : qualified.substring(dot + 1));
    }
    GeneratedSource generated = type == null ? null : sourceFor(type);
    return generated == null ? null : generated.text;
  }

  private static ProjectSymbolIndex.DefinitionTarget target(
      Class<?> owner, String symbol, int offset, int kind, String source) {
    String className = owner.getSimpleName();
    String fileName = owner.getName().replace('.', '/') + ".class";
    return new ProjectSymbolIndex.DefinitionTarget(
        fileName, className, symbol, source, offset, true, null, kind);
  }

  private static Class<?> loadType(String typeName) {
    if (typeName == null) return null;
    String name = typeName.trim();
    if (name.isEmpty()) return null;
    int generic = name.indexOf('<');
    if (generic >= 0) name = name.substring(0, generic);
    while (name.endsWith("[]")) name = name.substring(0, name.length() - 2);
    if (name.isEmpty()) return null;

    Class<?> loaded = tryLoad(name);
    if (loaded != null) return loaded;
    String simple = name.substring(name.lastIndexOf('.') + 1);
    String alias = TYPE_ALIASES.get(simple);
    loaded = alias == null ? null : tryLoad(alias);
    if (loaded != null) return loaded;
    if (name.indexOf('.') >= 0) return null;
    for (String prefix : SEARCH_PACKAGES) {
      loaded = tryLoad(prefix + name);
      if (loaded != null) return loaded;
    }
    return null;
  }

  private static Class<?> tryLoad(String name) {
    try {
      return Class.forName(name, false, SystemApiSourceProvider.class.getClassLoader());
    } catch (Throwable ignored) {
      return null;
    }
  }

  private static int inheritanceDistance(Class<?> requested, Class<?> declaring) {
    int distance = 0;
    for (Class<?> current = requested; current != null; current = current.getSuperclass()) {
      if (current == declaring) return distance;
      distance++;
    }
    return declaring.isInterface() ? 100 : 200;
  }

  private static String methodKey(Method method) {
    StringBuilder key = new StringBuilder(method.getName()).append('(');
    for (Class<?> parameter : method.getParameterTypes())
      key.append(parameter.getName()).append(';');
    return key.append(')').toString();
  }

  private static GeneratedSource sourceFor(Class<?> type) {
    if (type == null) return null;
    String key = type.getName();
    GeneratedSource cached = CACHE.get(key);
    if (cached != null) return cached;
    synchronized (CACHE) {
      cached = CACHE.get(key);
      if (cached != null) return cached;
      try {
        cached = generate(type);
        if (cached != null) CACHE.put(key, cached);
        return cached;
      } catch (Throwable ignored) {
        return null;
      }
    }
  }

  private static GeneratedSource generate(Class<?> type) {
    String packageName = type.getPackage() == null ? "" : type.getPackage().getName();
    ArrayList<Field> fields = new ArrayList<>();
    for (Field field : type.getDeclaredFields())
      if (isVisible(field.getModifiers())) fields.add(field);
    Collections.sort(fields, Comparator.comparing(Field::getName));

    ArrayList<Constructor<?>> constructors = new ArrayList<>();
    for (Constructor<?> constructor : type.getDeclaredConstructors())
      if (isVisible(constructor.getModifiers())) constructors.add(constructor);
    Collections.sort(constructors, Comparator.comparing(SystemApiSourceProvider::constructorKey));

    ArrayList<Method> methods = new ArrayList<>();
    for (Method method : type.getDeclaredMethods())
      if (isVisible(method.getModifiers()) && !method.isBridge() && !method.isSynthetic())
        methods.add(method);
    Collections.sort(methods, Comparator.comparing(SystemApiSourceProvider::methodKey));

    TreeSet<String> imports = new TreeSet<>();
    addImport(imports, type.getSuperclass(), packageName);
    for (Class<?> implemented : type.getInterfaces()) addImport(imports, implemented, packageName);
    for (Field field : fields) addImport(imports, field.getType(), packageName);
    for (Constructor<?> constructor : constructors)
      for (Class<?> parameter : constructor.getParameterTypes())
        addImport(imports, parameter, packageName);
    for (Method method : methods) {
      addImport(imports, method.getReturnType(), packageName);
      for (Class<?> parameter : method.getParameterTypes()) addImport(imports, parameter, packageName);
    }

    StringBuilder out = new StringBuilder(Math.max(4096, methods.size() * 96));
    if (!packageName.isEmpty()) out.append("package ").append(packageName).append(";\n\n");
    for (String imported : imports) out.append("import ").append(imported).append(";\n");
    if (!imports.isEmpty()) out.append('\n');
    out.append("// Android/JDK API declarations; implementation bodies are omitted.\n");

    String modifiers = Modifier.toString(type.getModifiers());
    if (!modifiers.isEmpty()) out.append(modifiers).append(' ');
    String kind = type.isAnnotation() ? "@interface" : type.isEnum() ? "enum" : type.isInterface() ? "interface" : "class";
    out.append(kind).append(' ');
    int classOffset = out.length();
    out.append(type.getSimpleName());

    Class<?> parent = type.getSuperclass();
    if (!type.isInterface() && parent != null && parent != Object.class)
      out.append(" extends ").append(sourceType(parent, packageName));
    Class<?>[] interfaces = type.getInterfaces();
    if (interfaces.length > 0) {
      out.append(type.isInterface() ? " extends " : " implements ");
      for (int i = 0; i < interfaces.length; i++) {
        if (i > 0) out.append(", ");
        out.append(sourceType(interfaces[i], packageName));
      }
    }
    out.append(" {\n");

    LinkedHashMap<String, Integer> fieldOffsets = new LinkedHashMap<>();
    for (Field field : fields) {
      out.append("    ");
      String fieldModifiers = Modifier.toString(field.getModifiers());
      if (!fieldModifiers.isEmpty()) out.append(fieldModifiers).append(' ');
      out.append(sourceType(field.getType(), packageName)).append(' ');
      fieldOffsets.put(field.getName(), out.length());
      out.append(field.getName());
      String initializer = constantInitializer(type, field);
      if (initializer != null) out.append(" = ").append(initializer);
      out.append(";\n");
    }

    if (!fields.isEmpty() && (!constructors.isEmpty() || !methods.isEmpty())) out.append('\n');
    for (Constructor<?> constructor : constructors) {
      out.append("    ");
      String constructorModifiers = Modifier.toString(constructor.getModifiers());
      if (!constructorModifiers.isEmpty()) out.append(constructorModifiers).append(' ');
      out.append(type.getSimpleName());
      appendParameters(out, constructor.getParameterTypes(), packageName);
      out.append(" { }\n");
    }
    if (!constructors.isEmpty() && !methods.isEmpty()) out.append('\n');

    LinkedHashMap<String, Integer> methodOffsets = new LinkedHashMap<>();
    for (Method method : methods) {
      out.append("    ");
      String methodModifiers = Modifier.toString(method.getModifiers());
      if (!methodModifiers.isEmpty()) out.append(methodModifiers).append(' ');
      out.append(sourceType(method.getReturnType(), packageName)).append(' ');
      methodOffsets.putIfAbsent(method.getName(), out.length());
      out.append(method.getName());
      appendParameters(out, method.getParameterTypes(), packageName);
      int flags = method.getModifiers();
      if (type.isInterface() || Modifier.isAbstract(flags) || Modifier.isNative(flags))
        out.append(";\n");
      else out.append(" { }\n");
    }
    out.append("}\n");
    return new GeneratedSource(out.toString(), classOffset, methodOffsets, fieldOffsets);
  }

  private static boolean isVisible(int modifiers) {
    return Modifier.isPublic(modifiers) || Modifier.isProtected(modifiers);
  }

  private static String constructorKey(Constructor<?> constructor) {
    StringBuilder key = new StringBuilder("(");
    for (Class<?> parameter : constructor.getParameterTypes()) key.append(parameter.getName()).append(';');
    return key.append(')').toString();
  }

  private static void addImport(Set<String> imports, Class<?> type, String currentPackage) {
    if (type == null) return;
    if (type.isArray()) {
      addImport(imports, type.getComponentType(), currentPackage);
      return;
    }
    if (type.isPrimitive()) return;
    Package pkg = type.getPackage();
    String packageName = pkg == null ? "" : pkg.getName();
    if (packageName.isEmpty() || packageName.equals("java.lang")
        || packageName.equals(currentPackage)) return;
    String canonical = type.getCanonicalName();
    if (canonical != null && !canonical.isEmpty()) imports.add(canonical);
    else imports.add(type.getName().replace('$', '.'));
  }

  private static String sourceType(Class<?> type, String currentPackage) {
    if (type.isArray()) return sourceType(type.getComponentType(), currentPackage) + "[]";
    if (type.isPrimitive()) return type.getName();
    if (type.getEnclosingClass() != null
        && type.getEnclosingClass().getPackage() != null
        && type.getEnclosingClass().getPackage().getName().equals(currentPackage))
      return type.getEnclosingClass().getSimpleName() + "." + type.getSimpleName();
    return type.getSimpleName();
  }

  private static void appendParameters(StringBuilder out, Class<?>[] parameters, String pkg) {
    out.append('(');
    for (int i = 0; i < parameters.length; i++) {
      if (i > 0) out.append(", ");
      out.append(sourceType(parameters[i], pkg)).append(" arg").append(i);
    }
    out.append(')');
  }

  private static String constantInitializer(Class<?> owner, Field field) {
    if (!Modifier.isStatic(field.getModifiers()) || !Modifier.isFinal(field.getModifiers())) return null;
    if ("android.view.View".equals(owner.getName()) && field.getType() == int.class) {
      if ("VISIBLE".equals(field.getName())) return "0";
      if ("INVISIBLE".equals(field.getName())) return "4";
      if ("GONE".equals(field.getName())) return "8";
    }
    Class<?> type = field.getType();
    if (type == boolean.class) return "false";
    if (type == char.class) return "'\\0'";
    if (type == byte.class || type == short.class || type == int.class) return "0";
    if (type == long.class) return "0L";
    if (type == float.class) return "0f";
    if (type == double.class) return "0d";
    if (type == String.class) return "\"\"";
    return "null";
  }

  private static final class GeneratedSource {
    final String text;
    final int classOffset;
    final Map<String, Integer> methodOffsets;
    final Map<String, Integer> fieldOffsets;

    GeneratedSource(
        String text,
        int classOffset,
        Map<String, Integer> methodOffsets,
        Map<String, Integer> fieldOffsets) {
      this.text = text;
      this.classOffset = classOffset;
      this.methodOffsets = methodOffsets;
      this.fieldOffsets = fieldOffsets;
    }
  }
}
