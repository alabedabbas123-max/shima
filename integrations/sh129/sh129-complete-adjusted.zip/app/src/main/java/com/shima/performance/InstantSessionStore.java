package com.shima.performance;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Metadata-only session store. It never writes source text: only references and viewport state are
 * persisted, so startup cannot be blocked by or allocate for large editor buffers.
 */
public final class InstantSessionStore {
  private static final String PREFS = "instant_editor_session";
  private static final String KEY = "snapshot_v1";
  public static final int MAX_TABS = 12;

  private final SharedPreferences preferences;

  public InstantSessionStore(Context context) {
    preferences = context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
  }

  public Snapshot load() {
    String raw = preferences.getString(KEY, "");
    if (raw == null || raw.trim().isEmpty()) return Snapshot.empty();
    try {
      JSONObject root = new JSONObject(raw);
      String selected = root.optString("selected", "");
      JSONArray values = root.optJSONArray("tabs");
      ArrayList<Tab> tabs = new ArrayList<>();
      if (values != null) {
        for (int i = 0; i < Math.min(MAX_TABS, values.length()); i++) {
          JSONObject item = values.optJSONObject(i);
          if (item == null) continue;
          String name = item.optString("name", "");
          String reference = item.optString("reference", "");
          if (!name.isEmpty())
            tabs.add(
                new Tab(
                    name,
                    reference,
                    Math.max(0, item.optInt("cursor", 0)),
                    Math.max(0, item.optInt("scrollX", 0)),
                    Math.max(0, item.optInt("scrollY", 0))));
        }
      }
      return tabs.isEmpty() ? Snapshot.empty() : new Snapshot(selected, tabs);
    } catch (Exception malformed) {
      preferences.edit().remove(KEY).apply();
      return Snapshot.empty();
    }
  }

  /** SharedPreferences.apply() schedules the disk write and keeps the UI thread non-blocking. */
  public void save(Snapshot snapshot) {
    if (snapshot == null || snapshot.tabs.isEmpty()) {
      clear();
      return;
    }
    try {
      JSONObject root = new JSONObject();
      root.put("version", 1);
      root.put("selected", snapshot.selected == null ? "" : snapshot.selected);
      JSONArray values = new JSONArray();
      int count = Math.min(MAX_TABS, snapshot.tabs.size());
      for (int i = 0; i < count; i++) {
        Tab tab = snapshot.tabs.get(i);
        JSONObject item = new JSONObject();
        item.put("name", tab.name);
        item.put("reference", tab.reference == null ? "" : tab.reference);
        item.put("cursor", Math.max(0, tab.cursor));
        item.put("scrollX", Math.max(0, tab.scrollX));
        item.put("scrollY", Math.max(0, tab.scrollY));
        values.put(item);
      }
      root.put("tabs", values);
      preferences.edit().putString(KEY, root.toString()).apply();
    } catch (Exception ignored) {
      // A failed session save must never affect editing or application startup.
    }
  }

  public void clear() {
    preferences.edit().remove(KEY).apply();
  }

  public static final class Snapshot {
    public final String selected;
    public final List<Tab> tabs;

    public Snapshot(String selected, List<Tab> tabs) {
      this.selected = selected == null ? "" : selected;
      this.tabs = Collections.unmodifiableList(new ArrayList<>(tabs));
    }

    public static Snapshot empty() {
      return new Snapshot("", Collections.emptyList());
    }
  }

  public static final class Tab {
    public final String name;
    public final String reference;
    public final int cursor;
    public final int scrollX;
    public final int scrollY;

    public Tab(String name, String reference, int cursor, int scrollX, int scrollY) {
      this.name = name == null ? "" : name;
      this.reference = reference == null ? "" : reference;
      this.cursor = Math.max(0, cursor);
      this.scrollX = Math.max(0, scrollX);
      this.scrollY = Math.max(0, scrollY);
    }
  }
}
