package com.almlkid.ui.preferences;

import android.os.Bundle;
import com.shima.demo.R;

/** قسم Dropbox — مفتاح المزامنة التلقائية. */
public class DropboxPreferencesFragment extends BasePreferenceFragment {
  @Override
  public void onCreate(Bundle state) {
    super.onCreate(state);
    addPreferencesFromResource(R.xml.preferences_dropbox);
  }
}
