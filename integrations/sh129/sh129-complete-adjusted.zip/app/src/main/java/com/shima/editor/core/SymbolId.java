package com.shima.editor.core;

import java.util.Objects;

public final class SymbolId {
  public final String owner;
  public final String name;
  public final String descriptor;

  public SymbolId(String owner, String name, String descriptor) {
    this.owner = owner == null ? "" : owner;
    this.name = name == null ? "" : name;
    this.descriptor = descriptor == null ? "" : descriptor;
  }

  @Override
  public boolean equals(Object other) {
    if (!(other instanceof SymbolId)) return false;
    SymbolId value = (SymbolId) other;
    return owner.equals(value.owner) && name.equals(value.name) && descriptor.equals(value.descriptor);
  }

  @Override
  public int hashCode() {
    return Objects.hash(owner, name, descriptor);
  }

  @Override
  public String toString() {
    return owner + "->" + name + descriptor;
  }
}
