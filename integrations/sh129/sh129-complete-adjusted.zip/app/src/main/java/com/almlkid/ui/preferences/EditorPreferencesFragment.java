package com.almlkid.ui.preferences;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Toast;
import com.shima.demo.R;

/** قسم Editor — خط/حفظ تلقائي/مسافات/لوحة/توثيق/إكمال، ومعالج تنزيل التوثيق. */
public class EditorPreferencesFragment extends BasePreferenceFragment {
  @Override
  public void onCreate(Bundle state) {
    super.onCreate(state);
    addPreferencesFromResource(R.xml.preferences_editor);
    // «تنزيل التوثيق»: يفتح مصدر التوثيق الرسمي في متصفح النظام.
    click(
        "download_doc",
        preference -> {
          try {
            startActivity(
                new Intent(Intent.ACTION_VIEW, Uri.parse("https://developer.android.com/docs")));
          } catch (Exception error) {
            Toast.makeText(getActivity(), com.shima.demo.UiStrings.get(getActivity(), "ui_open_docs_failed"), Toast.LENGTH_SHORT).show();
          }
          return true;
        });
  }
}
