package com.almlkid.ui.preferences;

import android.preference.Preference;
import android.preference.PreferenceFragment;

/** أساس مشترك لشظايا الإعدادات — ربط مساعد آمن (يتسامح مع غياب المفتاح). */
public abstract class BasePreferenceFragment extends PreferenceFragment {

  /** يربط معالج نقر إن وُجد المفتاح ويتجاهل غيابه بصمت. */
  protected void click(String key, Preference.OnPreferenceClickListener listener) {
    Preference preference = findPreference(key);
    if (preference != null) preference.setOnPreferenceClickListener(listener);
  }

  /** يربط معالج تغيّر إن وُجد المفتاح ويتجاهل غيابه بصمت. */
  protected void change(String key, Preference.OnPreferenceChangeListener listener) {
    Preference preference = findPreference(key);
    if (preference != null) preference.setOnPreferenceChangeListener(listener);
  }
}
