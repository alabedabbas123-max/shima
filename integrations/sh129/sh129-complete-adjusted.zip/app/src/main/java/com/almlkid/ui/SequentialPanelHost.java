package com.almlkid.ui;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.text.SpannableString;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.text.style.UnderlineSpan;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;
import com.almlkid.kay.ui.CodeLanguageTools;
import com.almlkid.kay.ui.ProjectDiagnostic;
import com.almlkid.kay.ui.UsageSearchEngine;
import com.almlkid.ui.browsers.BrowserPager;
import com.shima.demo.R;
import com.shima.demo.UiStrings;
import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * The single horizontal pager used by the left drawer. Its first page is the file browser and the
 * following pages are the persistent IDE panes, in the same order as the original drawer:
 * Files, Errors, Search Results, Debugger, and LogCat. Pages are created once, so list and editor
 * state is retained while the user swipes between them.
 */
public final class SequentialPanelHost extends LinearLayout {
  public enum Panel {
    ERRORS,
    SEARCH,
    BUILD,
    DEBUGGER,
    LOGCAT
  }

  public interface UsageClickListener {
    void clicked(UsageSearchEngine.Usage usage);
  }

  public interface ErrorClickListener {
    void clicked(ProjectDiagnostic diagnostic);

    /**
     * نقر **رأس الملف** (W2، كالمرجع تمامًا): المرجع يبني للترويسة {@code Tl(path,1,1,1,1)} فيفتح
     * الملف عند أول سطر **بلا تحديد ولا شريط إجراءات** — لا يقفز إلى أول خطأ فيه.
     */
    void fileRowClicked(String reference, String fileName);
  }

  /** Long-press on an error row: navigate to its full range and open the selection actions. */
  public interface ErrorActionsListener {
    void requested(ProjectDiagnostic diagnostic);
  }

  public interface CloseListener {
    void closed();
  }

  private final ArrayList<View> pages = new ArrayList<>();
  private final ArrayList<Panel> panelOrder = new ArrayList<>();
  private final EnumMap<Panel, Integer> panelIndexes = new EnumMap<>(Panel.class);
  private final ArrayList<UsageSearchEngine.Usage> usages = new ArrayList<>();
  // صفوف العرض بنمط المرجع: String = رأس ملف، Usage = سطر نتيجة تحته.
  private final ArrayList<Object> searchRows = new ArrayList<>();
  private String searchHighlight = "";
  private int[] syntaxPalette;
  private int syntaxPlain = Color.WHITE;
  private final ArrayList<ProjectDiagnostic> diagnostics = new ArrayList<>();
  private final ArrayList<Object> errorRows = new ArrayList<>();
  private final ArrayList<PanelHeader> headers = new ArrayList<>();
  private BrowserPager browser;
  private ViewPager pager;
  private ListView errorList, usageList;
  private TextView buildOutput, debuggerOutput, logcatOutput;
  private ImageView errorHeaderIcon;
  private TextView errorHeaderTitle;
  private UsageClickListener usageClickListener;
  private CloseListener closeListener;
  private UsageAdapter usageAdapter;
  private ErrorAdapter errorAdapter;
  private ErrorClickListener errorClickListener;
  private ErrorActionsListener errorActionsListener;
  /** عدد الأخطاء المعروض آخر مرة — يقرر سياسة التحديث الخفيف كالمرجع (تغيّر العدد وأقل من 100). */
  private int shownErrorCount = -1;
  /** ‏W27/2: عَدَّتا اللوحِ منفصلتانِ — أخطاءٌ للشارةِ وسطرِ الرأسِ، وتحذيراتٌ في قِطعةٍ تاليةٍ منهُ. */
  private int shownErrors = -1;
  private int shownWarnings;
  /** آخرُ بصمةٍ قَرَّرَ اللوحُ عليها — تُقَرَأُ في الاختبارِ كما يُقَرَأُ lastPulseCount. */
  long lastPulseSignature = almlk.ErrorBrowserPolicy.SIGNATURE_UNKNOWN;
  private List<ProjectDiagnostic> latestDiagnostics = Collections.emptyList();
  private String searchStatus = "";

  public SequentialPanelHost(Context context) {
    super(context);
    init();
  }

  /** Required by LayoutInflater for the XML drawer declaration. */
  public SequentialPanelHost(Context context, AttributeSet attrs) {
    super(context, attrs);
    init();
  }

  /** Required when the view is inflated with a style/theme attribute. */
  public SequentialPanelHost(Context context, AttributeSet attrs, int defStyleAttr) {
    super(context, attrs, defStyleAttr);
    init();
  }

  private void init() {
    setOrientation(VERTICAL);
    setBackgroundColor(almlk.ChromeTheme.panelBackground(getContext()));
    setFocusable(true);
    setFocusableInTouchMode(true);

    // Page zero is the real file browser. Keeping it inside this same ViewPager makes the drawer
    // transition continuous instead of opening a second overlay on top of the file drawer.
    browser = new BrowserPager(getContext());
    browser.setId(R.id.mainBrowserPager);
    pages.add(browser);

    // Do not insert BUILD into the swipe sequence: the requested visual order is exactly the five
    // pages shown by the reference screenshots. Build output remains available from the commands
    // menu and is placed after LogCat so it cannot disturb that sequence.
    addPanelPage(Panel.ERRORS, createErrorsPage());
    addPanelPage(Panel.SEARCH, createSearchPage());
    addPanelPage(Panel.DEBUGGER, createDebuggerPage());
    addPanelPage(Panel.LOGCAT, createLogcatPage());
    addPanelPage(Panel.BUILD, createBuildPage());

    // خط فاصل بين الأقسام + تبديل بعد تجاوز نصف العرض فقط.
    pager = new almlk.PanelSwipePager(getContext());
    pager.setOffscreenPageLimit(pages.size());
    pager.setAdapter(new PanelAdapter());
    addView(pager, new LayoutParams(-1, 0, 1));
    // تثبيت الجلسة على القسم المفتوح: كل تبديل يُحفظ فورًا، والإقلاع يستعيد آخر قسم.
    pager.addOnPageChangeListener(
        new ViewPager.SimpleOnPageChangeListener() {
          @Override
          public void onPageSelected(int position) {
            getContext()
                .getSharedPreferences("main_drawer", Context.MODE_PRIVATE)
                .edit()
                .putInt("last_page", position)
                .apply();
          }
        });
    int savedPage =
        getContext()
            .getSharedPreferences("main_drawer", Context.MODE_PRIVATE)
            .getInt("last_page", 0);
    if (savedPage > 0 && savedPage < pages.size()) pager.setCurrentItem(savedPage, false);
  }

  private void addPanelPage(Panel panel, View page) {
    panelOrder.add(panel);
    panelIndexes.put(panel, pages.size());
    pages.add(page);
  }

  public BrowserPager browser() {
    return browser;
  }

  /**
   * صفحة الأخطاء ببنية المرجع نفسها: {@code errorbrowser.xml} (حاوية + {@code CustomKeysListView}
   * بنمط {@code BrowserListView}) و{@code browser_header.xml} **رأسًا داخل القائمة** — فيتمّر مع
   * المحتوى كما في {@code ErrorBrowser.m24v5} — لا شريطًا ثابتًا فوقها. الفواصل والتمرير السريع
   * وألوان النصوص كلها من الأنماط نفسها بلا لون صلب هنا، وزر قائمة الرأس محجوب كما يحجبه المرجع.
   */
  private View createErrorsPage() {
    LayoutInflater inflater = LayoutInflater.from(getContext());
    View header = inflater.inflate(R.layout.browser_header, null, false);
    errorHeaderIcon = header.findViewById(R.id.browserHeaderIcon);
    errorHeaderTitle = header.findViewById(R.id.browserHeaderLabel);
    // المرجع يحجب زر القائمة في رأس متصفح الأخطاء صراحةً (setVisibility(8)).
    header.findViewById(R.id.browserHeaderMenuButton).setVisibility(View.GONE);

    LinearLayout root = new LinearLayout(getContext());
    root.setOrientation(VERTICAL);
    root.setBackgroundColor(almlk.ChromeTheme.panelBackground(getContext()));
    View body = inflater.inflate(R.layout.errorbrowser, root, false);
    errorList = body.findViewById(R.id.errorbrowserErrorList);
    errorAdapter = new ErrorAdapter();
    // الرأس غير قابل للتحديد (وسيط المرجع نفسه false): النقر عليه لا يزيح التحديد.
    errorList.addHeaderView(header, null, false);
    errorList.setAdapter(errorAdapter);
    // النقر (كالمرجع): صفوف الخطأ تنتقل إلى مداها الكامل؛ صفوف الرؤوس تفتح ملفها عند أول سطر.
    errorList.setOnItemClickListener(
        (parent, view, position, id) -> {
          if (errorClickListener == null) return;
          Object row = parent.getItemAtPosition(position);
          if (row instanceof ErrorFileHeader) {
            ErrorFileHeader fileRow = (ErrorFileHeader) row;
            // «خطأ عام بلا ملف» لا مسار له: لا نقر يفتح شيئًا (المرجع يبني له Tl بمسار فارغ).
            if (fileRow.hasFile && !fileRow.reference.isEmpty())
              errorClickListener.fileRowClicked(fileRow.reference, fileRow.name);
            return;
          }
          if (row instanceof ProjectDiagnostic)
            errorClickListener.clicked((ProjectDiagnostic) row);
        });
    // الضغط المطوّل لصفوف الخطأ فقط: انتقال + تحديد المدى + شريط «تحديد الإجراءات» — لا حوار.
    errorList.setOnItemLongClickListener(
        (parent, view, position, id) -> {
          Object row = parent.getItemAtPosition(position);
          if (!(row instanceof ProjectDiagnostic) || errorActionsListener == null) return false;
          errorActionsListener.requested((ProjectDiagnostic) row);
          return true;
        });
    // الرأس من آخر عدد معروف؛ والحقل يبدأ -1 («لم يُقَس بعد») فلا يجوز عرض عدد سالب قطّ.
    // لا نبضةَ عند بناءِ الصفحةِ: لا قطعَ معلومًا، فالسطرُ التالِي للرأسِ يَبقَى فارغًا.
    updateErrorHeader(Math.max(0, shownErrors), Math.max(0, shownWarnings), 0);
    root.addView(body, new LinearLayout.LayoutParams(-1, 0, 1));
    headers.add(new PanelHeader(root, errorHeaderIcon, errorHeaderTitle));
    return root;
  }

  private View createSearchPage() {
    usageList = new ListView(getContext());
    usageList.setBackgroundColor(almlk.ChromeTheme.panelBackground(getContext()));
    usageList.setDivider(null);
    usageList.setDividerHeight(0);
    usageAdapter = new UsageAdapter();
    usageList.setAdapter(usageAdapter);
    usageList.setOnItemClickListener(
        (parent, view, position, id) -> {
          if (usageClickListener == null || usages.isEmpty() || position >= searchRows.size())
            return;
          Object row = searchRows.get(position);
          if (row instanceof UsageSearchEngine.Usage) {
            usageClickListener.clicked((UsageSearchEngine.Usage) row);
            return;
          }
          // نقر رأس الملف يفتح أول نتيجة فيه — نفس سلوك المرجع.
          for (int i = position + 1; i < searchRows.size(); i++) {
            Object next = searchRows.get(i);
            if (next instanceof UsageSearchEngine.Usage) {
              usageClickListener.clicked((UsageSearchEngine.Usage) next);
              return;
            }
          }
        });
    PanelHeader page =
        panelPage(
            R.drawable.search,
            UiStrings.get(getContext(), "ui_search_results_title"),
            usageList);
    headers.add(page);
    return page.root;
  }

  private View createDebuggerPage() {
    debuggerOutput =
        infoBody(
            R.drawable.debugger_stopped,
            UiStrings.get(getContext(), "ui_debugger_hint"));
    PanelHeader page =
        panelPage(
            R.drawable.debugger_stopped,
            UiStrings.get(getContext(), "ui_debugger_not_running"),
            debuggerOutput);
    headers.add(page);
    return page.root;
  }

  private View createLogcatPage() {
    logcatOutput = textPage(UiStrings.get(getContext(), "ui_logcat_hint"));
    PanelHeader page =
        panelPage(
            R.drawable.file_type_unknown,
            UiStrings.get(getContext(), "command_logcat"),
            logcatOutput);
    headers.add(page);
    return page.root;
  }

  private View createBuildPage() {
    buildOutput = textPage(UiStrings.get(getContext(), "ui_build_not_started"));
    PanelHeader page =
        panelPage(
            R.drawable.file_type_unknown,
            UiStrings.get(getContext(), "ui_build_run_title"),
            buildOutput);
    headers.add(page);
    return page.root;
  }

  private PanelHeader panelPage(int iconResource, String caption, View body) {
    LinearLayout root = new LinearLayout(getContext());
    root.setOrientation(VERTICAL);
    root.setBackgroundColor(almlk.ChromeTheme.panelBackground(getContext()));

    LinearLayout header = new LinearLayout(getContext());
    header.setGravity(Gravity.CENTER_VERTICAL);
    header.setPaddingRelative(dp(16), 0, dp(4), 0);
    header.setBackgroundResource(R.drawable.browser_header_material);
    ImageView icon = new ImageView(getContext());
    icon.setImageResource(iconResource);
    icon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
    header.addView(icon, new LinearLayout.LayoutParams(dp(40), dp(56)));
    TextView title = label(caption, 16, Color.WHITE);
    title.setGravity(Gravity.CENTER_VERTICAL);
    title.setSingleLine(true);
    title.setTypeface(Typeface.DEFAULT, Typeface.NORMAL);
    LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(0, dp(56), 1);
    titleParams.setMarginStart(dp(5));
    header.addView(title, titleParams);
    root.addView(header, new LinearLayout.LayoutParams(-1, dp(56)));
    root.addView(body, new LinearLayout.LayoutParams(-1, 0, 1));
    return new PanelHeader(root, icon, title);
  }

  private TextView infoBody(int iconResource, String value) {
    TextView view = label(value, 16, Color.LTGRAY);
    view.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
    view.setPaddingRelative(dp(14), dp(12), dp(10), dp(12));
    view.setCompoundDrawablesWithIntrinsicBounds(iconResource, 0, 0, 0);
    view.setCompoundDrawablePadding(dp(12));
    return view;
  }

  private TextView textPage(String value) {
    TextView view = label(value, 14, Color.LTGRAY);
    view.setGravity(Gravity.TOP | Gravity.START);
    view.setPaddingRelative(dp(1), dp(2), dp(10), dp(16));
    view.setTypeface(Typeface.MONOSPACE, Typeface.NORMAL);
    view.setTextIsSelectable(true);
    return view;
  }

  public void showPage(Panel panel) {
    if (panel == null || pager == null) return;
    Integer index = panelIndexes.get(panel);
    if (index != null) pager.setCurrentItem(index, true);
  }

  /** Shows the file page before opening the drawer again. */
  public void showFilesPage() {
    if (pager != null) pager.setCurrentItem(0, true);
  }

  public Panel currentPanel() {
    int page = pager == null ? 0 : pager.getCurrentItem();
    for (Panel panel : panelOrder) {
      Integer index = panelIndexes.get(panel);
      if (index != null && index == page) return panel;
    }
    return null;
  }

  public void nextPage() {
    if (pager == null) return;
    int next = pager.getCurrentItem() + 1;
    if (next < pages.size()) pager.setCurrentItem(next, true);
  }

  /** Moves right to the previous drawer page; false means the drawer may close normally. */
  public boolean previousPageIfPossible() {
    if (pager == null || pager.getCurrentItem() <= 0) return false;
    pager.setCurrentItem(pager.getCurrentItem() - 1, true);
    return true;
  }

  public void setErrors(List<CodeLanguageTools.Diagnostic> values) {
    setErrors(values, "");
  }

  /** Compatibility entry point for one open file; project-wide callers use setProjectDiagnostics. */
  public void setErrors(List<CodeLanguageTools.Diagnostic> values, String source) {
    ArrayList<ProjectDiagnostic> wrapped = new ArrayList<>();
    if (values != null) {
      for (CodeLanguageTools.Diagnostic value : values) {
        ProjectDiagnostic item =
            ProjectDiagnostic.fromSource("Current file", "", source, value);
        if (item != null) wrapped.add(item);
      }
    }
    setProjectDiagnostics(wrapped);
  }

  /** إعادة بناء كاملة لصفحة الأخطاء (عند فتح اللوحة أو طلب صريح). */
  public void setProjectDiagnostics(List<ProjectDiagnostic> values) {
    latestDiagnostics = values == null ? Collections.emptyList() : new ArrayList<>(values);
    rebuildErrorRows();
  }

  /**
   * تحديث خفيف بعد تغيّر ملف واحد (سياسة المرجع ErrorBrowser.Hw): ‏W27/2 — لا حارسَينِ متتاليَينِ.
   * كانَ هذا الحارسُ يُسقِطُ كلَّ تحديثٍ لم يَتغيَّرْ فيهِ العددُ، وهو أكثرُ ما يَفعَلُهُ المحلِّلُ
   * الخلفيُّ (خطأٌ انتقلَ سطرًا، أو تحذيرٌ حلَّ محلَّ خطأٍ، أو صُحِّحَ صفٌّ فَبَقِيَ عَددُهُ)، فتبقى
   * اللوحةُ على قائمةٍ عفا عليها الزمنُ بلا سببٍ. القرارُ كلُّهُ الآنَ في {@link #rebuildErrorRows}:
   * عددٌ + بصمةُ نافذةِ العرضِ + سقفٌ، وهو نفسه قرارُ البناءِ الكاملِ فلا تَباعُدَ بينَ الطريقَينِ.
   */
  public void updateProjectDiagnostics(List<ProjectDiagnostic> values) {
    latestDiagnostics = values == null ? Collections.emptyList() : new ArrayList<>(values);
    rebuildErrorRows();
  }

  /** عدد الأخطاء الذي تعرضه اللوحة والشارة (الأخطاء فقط؛ الشارةُ لا تحمرُّ بتحذيرٍ). */
  public static int countErrors(List<ProjectDiagnostic> values) {
    int count = 0;
    if (values != null)
      for (ProjectDiagnostic value : values) if (isPanelError(value)) count++;
    return count;
  }


  /**
   * W6: قاعدةُ العرض الوحيدة للوحة كلها (العدّ والصفوف) في {@code JavaDiagnosticCodes.showsInPanel}.
   * التحذيرات **مستثناة صراحةً**: اللوحة «errors» برأسها وبأيقونتها ({@code project_errors} لكل
   * صفوف المرجع)، فلا مزجَ للعائلتين؛ ولا نُثبت عن المرجع أكثر من ذلك (قائمته في {@code U.we()}).
   */
  private static boolean isPanelError(ProjectDiagnostic value) {
    return value != null && value.diagnostic != null
        && almlk.JavaDiagnosticCodes.showsInPanel(
            value.diagnostic.code, value.diagnostic.severity);
  }

  /**
   * ‏W27/2: صنفُ اللوحِ غيرُ عَدِّ الشارةِ — الخطأُ والتحذيرُ يَجلِسانِ تحتَ اسمِ ملفِّهما (نصُّ
   * الملحقِ)، وما دونَ التحذيرِ يَبقى في فقاعةِ المحرِّرِ. وكانَ استثناءُ التحذيرِ من اللوحِ قرارًا من
   * ‏W6 اقتِداءً بالمرجعِ؛ فصارَ عرضُها طلبًا مُعلَنًا من المستخدمِ، وبقيَ العدُّ على حالِهِ.
   */
  private static boolean isPanelRow(ProjectDiagnostic value) {
    return value != null && value.diagnostic != null
        && almlk.ErrorBrowserPolicy.listsInPanel(severityOf(value),
            value.diagnostic.code, value.diagnostic.messageKey);
  }

  /** تحذيرٌ لا خطأٌ: للفرزِ في سطرِ الرأسِ ولأيقونةِ الصفِّ. */
  private static boolean isPanelWarning(ProjectDiagnostic value) {
    return value != null && value.diagnostic != null
        && severityOf(value) == almlk.AnalyzerProtocol.SEVERITY_WARNING;
  }

  /** الرتبةُ عددًا؛ وما لا رتبةَ لهُ خطأٌ — كما يَفصِلُهُ ‏AnalyzerWire في الاتجاهَينِ. */
  private static int severityOf(ProjectDiagnostic value) {
    CodeLanguageTools.Diagnostic.Severity severity = value.diagnostic.severity;
    return severity == null ? almlk.AnalyzerProtocol.SEVERITY_ERROR : severity.ordinal();
  }

  /** بصمةُ صفٍّ: ما يَراهُ اللوحُ لا ما يَقرَؤُهُ المحرِّرُ — ملفٌّ وموضِعٌ ورتبةٌ ومفتاحُ رسالةٍ. */
  private static long signatureOf(ProjectDiagnostic value) {
    CodeLanguageTools.Diagnostic item = value.diagnostic;
    String message = item.messageKey == null ? item.message : item.messageKey;
    return almlk.ErrorBrowserPolicy.rowSignature(
        value.groupKey().hashCode(),
        Math.max(0, item.line),
        Math.max(0, item.column),
        severityOf(value),
        message == null ? 0 : message.hashCode());
  }

  private void rebuildErrorRows() {
    boolean hadFocus = errorList != null && errorList.hasFocus();
    // ‏W27/2 (ملحقُ ‏W27/2): الصُّوفةُ كلُّها أولًا (أخطاءٌ + تحذيراتٌ) ثمَّ ترتيبُها بالمِلكِ فالسطرِ،
    // والتجميعُ تحتَ أسماءِ الملفاتِ يَبني على ما بَعدَ القطعِ لا على ما قبلَهُ: في ‏1.0.177 كانَ
    // القطعُ بالسقفِ يَجري بعدَ بناءِ errorRows فتَبقَى الصفوفُ الزائدةُ مرئيّةً مع سطرِ «لم يُعرَضْ».
    diagnostics.clear();
    for (ProjectDiagnostic value : latestDiagnostics)
      if (isPanelRow(value)) diagnostics.add(value);
    diagnostics.sort(
        (a, b) -> {
          int file = a.groupKey().compareToIgnoreCase(b.groupKey());
          if (file != 0) return file;
          int line = Integer.compare(a.diagnostic.line, b.diagnostic.line);
          return line != 0 ? line : Integer.compare(a.diagnostic.column, b.diagnostic.column);
        });
    // البصمةُ على نافذةِ العرضِ وحدَها: ما وراءَ السقفِ لا يُزعِجُ اللوحَ ولا يُبطِئُهُ.
    int window = Math.min(diagnostics.size(), almlk.ErrorBrowserPolicy.MAX_LISTED_ERRORS);
    long signature = almlk.ErrorBrowserPolicy.foldBegin();
    for (int i = 0; i < window; i++) {
      signature = almlk.ErrorBrowserPolicy.fold(signature, signatureOf(diagnostics.get(i)));
    }
    int counted = diagnostics.size();
    // ج٥٧: مَا قَطَعَهُ سَقۡفُ الوَحدَةِ قَبلَ أَنۡ يَصِلَ إِلَيۡنَا — «n of k» لَا «n» وَحدَهَا.
    // يُطۡرَأُ عَلَى البَصۡمَةِ أَيۡضًا: لَوۡ تَغَيَّرَ المَقطُوعُ وَحۡدَهُ (صَفٌّ سَقَطَ مِن مِلَفٍّ آخَر)
    // فَبِدُونِ ذَلِك يَبقَى الرَّأسُ عَلى كَذِبِهِ حَتىٰ تَتَغَيَّرَ الصُّفُوفُ المَنۡشُورَة.
    int analyzerTrimmed = Math.max(0, almlk.AnalyzerErrorUnit.trimmedRowCount());
    signature = almlk.ErrorBrowserPolicy.fold(signature, analyzerTrimmed);
    // حارسُ المرجعِ مُصحَّحًا: لا إعادةَ بناءٍ لنافذةٍ لم تَتغيَّرْ، وتُعادُ لو تساوى العددُ وتغيَّرَ
    // المحتوى — وهو الفرقُ بينَ «مُحدَّثةٌ» و«مُحدَّثةٌ فورًا».
    almlk.ErrorBrowserPolicy.Decision policy =
        almlk.ErrorBrowserPolicy.decide(
            lastPulseCount, counted, hadFocus, lastPulseSignature, signature);
    if (!policy.rebuilds()) {
      return; // القرارُ صمتٌ مُسبَّبٌ: لا مِسكَ عرضٍ ولا إعادةَ بناءٍ
    }
    lastPulseCount = counted;
    lastPulseSignature = signature;
    int[] severityOfRows = new int[counted];
    for (int i = 0; i < counted; i++) severityOfRows[i] = severityOf(diagnostics.get(i));
    int[] counts = almlk.ErrorBrowserPolicy.countBySeverity(severityOfRows);
    int errors = counts[0];
    int warnings = counts[1];
    headerKey = almlk.ErrorBrowserPolicy.headerKey(errors);
    while (diagnostics.size() > policy.listed) {
      diagnostics.remove(diagnostics.size() - 1); // المقطوعُ مَعْدودٌ في السطرِ، لا مُختَفٍ
    }
    errorRows.clear();
    LinkedHashMap<String, ArrayList<ProjectDiagnostic>> grouped = new LinkedHashMap<>();
    for (ProjectDiagnostic item : diagnostics) {
      ArrayList<ProjectDiagnostic> group = grouped.get(item.groupKey());
      if (group == null) {
        group = new ArrayList<>();
        grouped.put(item.groupKey(), group);
      }
      group.add(item);
    }
    for (Map.Entry<String, ArrayList<ProjectDiagnostic>> entry : grouped.entrySet()) {
      ArrayList<ProjectDiagnostic> group = entry.getValue();
      if (group.isEmpty()) continue;
      ProjectDiagnostic first = group.get(0);
      errorRows.add(new ErrorFileHeader(first.displayName(), first.reference, first.fileName));
      errorRows.addAll(group);
    }
    shownErrorCount = diagnostics.size();
    shownErrors = errors;
    shownWarnings = warnings;
    updateErrorHeader(shownErrors, shownWarnings, policy.dropped + analyzerTrimmed);
    if (errorAdapter != null) errorAdapter.notifyDataSetChanged();
    if (hadFocus && errorList != null) errorList.requestFocus();
  }

  /**
   * رأس المرجع: «لا توجد أخطاء» / «خطأ واحد» / «N أخطاء» مع تبدّل الأيقونة وسطرِ القطعِ.
   *
   * <p>ج٥٧: سَطۡرُ «لم يُعرَض» صَارَ يَجمَعُ سَقۡفَيۡنِ — سَقۡفَ اللُّوحَةِ (‏100 كَمَا عِندَ المُرجَعِ‏)
   * وَسَقۡفَ وَحدَةِ الفَحصِ (‏{@code AnalyzerErrorUnit.MAX_ROWS_PER_FILE}‏) — لِأَنَّ «k» عِندَ المُسَتخدِمِ
   * هُوَ كُلُّ مَا وُجِد، لَا كُلُّ مَا وُضِعَ أَمَامَهُ. وَلمۡ نَزدۡ مِفۡتَاحَ سِلۡسِلَةٍ جَدِيدًا:
   * بَابُ اللُّغَةِ يُلزِمُ تُرجُمَةَ كُلِّ مِفۡتَاحٍ فِي كُلِّ لِسَانٍ، وَابتِدَاعُ نَصٍّ ثَمَّةَ أَسوَأُ مِنۡ
   * قِطۡعَتَيۡنِ مَقۡرُوءَتَيۡنِ هُنَا.
   */
  private void updateErrorHeader(int errors, int warnings, int dropped) {
    if (errorHeaderIcon != null)
      errorHeaderIcon.setImageResource(
          almlk.ErrorBrowserPolicy.badgeHidden(errors + warnings)
              ? R.drawable.project_no_errors
              : R.drawable.project_errors);
    if (errorHeaderTitle == null) return;
    String text =
        errors == 0
            ? UiStrings.get(getContext(), "ui_errors_title")
            : errors == 1
                ? UiStrings.get(getContext(), "ui_errors_one")
                : UiStrings.format(getContext(), "ui_errors_count", errors);
    // «لا توجد أخطاء» لا تَمحوها تحذيراتٌ تَحتَها: عددُ التحذيراتِ قِطعةٌ مُستقلةٌ من السطرِ، والأيقونةُ
    // تُعلِنُ أنَّ اللوحَ ليسَ فارغًا وإن لم يكن فيهِ خطأٌ واحدٌ.
    String warningsSegment = almlk.ErrorBrowserPolicy.warningsSegmentKey(warnings);
    if (!warningsSegment.isEmpty())
      text = text + " · " + UiStrings.format(getContext(), warningsSegment, warnings);
    errorHeaderTitle.setText(
        dropped > 0
            ? text + " · " + UiStrings.format(getContext(), "ui_errors_capped", dropped)
            : text);
  }

  /** آخرُ عددٍ رآهُ اللوحُ (‏-1 قبلَ أولِ بناءٍ) — هو مِقياسُ حارسِ «لم يتغيَّرْ». */
  int lastPulseCount = -1;

  /** مفتاحُ سلسلةِ الرأسِ المُستعمَلُ في آخرِ قرارٍ: يُثبِتُ أنَّ التقسيمَ Three-way لا مزيجٌ. */
  String headerKey = almlk.ErrorBrowserPolicy.HEADER_NONE;

  public void setErrorClickListener(ErrorClickListener listener) {
    errorClickListener = listener;
  }

  public void setErrorActionsListener(ErrorActionsListener listener) {
    errorActionsListener = listener;
  }

  public void setSearchResults(List<UsageSearchEngine.Usage> values) {
    setSearchResults(values, searchHighlight);
  }

  /** نتائج بنمط المرجع: تجميع حسب الملف وإبراز الرمز المبحوث بخط سفلي داخل سطر ملوّن. */
  public void setSearchResults(List<UsageSearchEngine.Usage> values, String highlightTerm) {
    usages.clear();
    if (values != null) usages.addAll(values);
    searchHighlight = highlightTerm == null ? "" : highlightTerm;
    searchRows.clear();
    String currentFile = null;
    for (UsageSearchEngine.Usage usage : usages) {
      if (!usage.fileName.equals(currentFile)) {
        currentFile = usage.fileName;
        searchRows.add(currentFile);
      }
      searchRows.add(usage);
    }
    if (usageAdapter != null) usageAdapter.notifyDataSetChanged();
  }

  public void setSearchStatus(String status) {
    searchStatus = status == null ? "" : status;
    if (usageAdapter != null) usageAdapter.notifyDataSetChanged();
  }

  public void setBuildOutput(String output) {
    if (buildOutput != null) buildOutput.setText(output == null ? "" : output);
  }

  public void appendBuildOutput(String line) {
    if (buildOutput != null) buildOutput.append((line == null ? "" : line) + "\n");
  }

  public void setDebuggerState(String output) {
    if (debuggerOutput != null) debuggerOutput.setText(output == null ? "" : output);
  }

  public void setLogcat(String output) {
    if (logcatOutput != null) logcatOutput.setText(output == null ? "" : output);
  }

  public void setUsageClickListener(UsageClickListener listener) {
    usageClickListener = listener;
  }

  public void setCloseListener(CloseListener listener) {
    closeListener = listener;
  }

  private TextView label(String value, int size, int color) {
    TextView result = new TextView(getContext());
    result.setText(value);
    result.setTextSize(size);
    result.setTextColor(color);
    return result;
  }

  private int dp(int value) {
    return (int) (value * getResources().getDisplayMetrics().density + .5f);
  }

  private final class PanelAdapter extends PagerAdapter {
    @Override
    public int getCount() {
      return pages.size();
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
      return view == object;
    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {
      View page = pages.get(position);
      if (page.getParent() != container) {
        if (page.getParent() instanceof ViewGroup) ((ViewGroup) page.getParent()).removeView(page);
        container.addView(page);
      }
      return page;
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
      if (object instanceof View && ((View) object).getParent() == container)
        container.removeView((View) object);
    }
  }

  private static final class ErrorFileHeader {
    final String name;
    final String reference;
    final boolean hasFile;

    ErrorFileHeader(String name, String reference, String fileName) {
      this.name = name == null ? "" : name;
      this.reference = reference == null ? "" : reference;
      // خطأ عام بلا ملف (مثل فشل Gradle العام) يُعرض بأيقونة المجلد كالمرجع.
      this.hasFile = !(this.reference.isEmpty() && (fileName == null || fileName.isEmpty()));
    }
  }

  /**
   * صفوف المرجع من {@code errorbrowser_entry.xml}: صف الملف (أيقونة النوع + الاسم، 16sp، إزاحة
   * 20dp) وصف الخطأ (أيقونة الخطأ + الرسالة فقط، 14sp، إزاحة 40dp). نوعان منفصلان لإعادة الاستخدام.
   */
  private final class ErrorAdapter extends BaseAdapter {
    private static final int TYPE_FILE = 0, TYPE_DIAGNOSTIC = 1;

    @Override
    public int getCount() {
      return errorRows.size();
    }

    @Override
    public Object getItem(int position) {
      return errorRows.get(position);
    }

    @Override
    public long getItemId(int position) {
      return position;
    }

    @Override
    public int getViewTypeCount() {
      return 2;
    }

    @Override
    public int getItemViewType(int position) {
      return errorRows.get(position) instanceof ErrorFileHeader ? TYPE_FILE : TYPE_DIAGNOSTIC;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
      View row = convertView;
      if (row == null)
        row = LayoutInflater.from(getContext()).inflate(R.layout.errorbrowser_entry, parent, false);
      View fileRow = row.findViewById(R.id.errorbrowserEntryFile);
      View errorRow = row.findViewById(R.id.errorbrowserEntryError);
      Object item = errorRows.get(position);
      if (item instanceof ErrorFileHeader) {
        ErrorFileHeader header = (ErrorFileHeader) item;
        fileRow.setVisibility(View.VISIBLE);
        errorRow.setVisibility(View.GONE);
        ((ImageView) row.findViewById(R.id.errorbrowserEntryFileImage))
            .setImageResource(header.hasFile ? fileTypeIcon(header.name) : R.drawable.folder);
        TextView name = row.findViewById(R.id.errorbrowserEntryFileName);
        name.setText(header.name);
        // لا لون صلبًا: «BrowserLabelLarge» يمنحها ?color_browser_label كما في المرجع (يثبت في
        // الثيم الفاتح والداكن معًا)، بعكس تلوين أبيض مقنّن كان يكسر الفاتح.
        row.setContentDescription(header.name);
        return row;
      }
      ProjectDiagnostic project = (ProjectDiagnostic) item;
      fileRow.setVisibility(View.GONE);
      errorRow.setVisibility(View.VISIBLE);
      // ‏W27/2: التحذيرُ يُعرَفُ من أيقونتِهِ لا من لونٍ مُقنَّنٍ (الفاتحُ والداكِنُ معًا كما هو مُصَمَّمٌ).
      ((ImageView) row.findViewById(R.id.errorbrowserEntryImage))
          .setImageResource(
              isPanelWarning(project)
                  ? R.drawable.ic_error_outline_white_24dp
                  : R.drawable.project_errors);
      TextView message = row.findViewById(R.id.errorbrowserEntryMessage);
      String text = diagnosticMessage(project.diagnostic);
      message.setText(text);
      // و«BrowserLabelSmall» تتكفّل بلون الرسالة (نفس مصدر المرجع)، فلا لون مقنَّن هنا.
      // الضغط المطوّل يبقى ملك ListView لكل صف.
      message.setTextIsSelectable(false);
      row.setContentDescription(project.displayName() + ", " + text);
      return row;
    }
  }

  private String diagnosticMessage(CodeLanguageTools.Diagnostic diagnostic) {
    if (diagnostic.messageKey != null)
      return UiStrings.format(getContext(), diagnostic.messageKey, diagnostic.messageArgs);
    return diagnostic.message == null || diagnostic.message.isEmpty()
        ? UiStrings.get(getContext(), "ui_error_generic")
        : diagnostic.message;
  }

  /** لوحة ألوان الرموز من إعدادات الثيم نفسها التي يرسم بها المحرر (تُبنى مرة واحدة). */
  private void ensureSyntaxPalette() {
    if (syntaxPalette != null) return;
    com.shima.demo.ThemeConfig theme = new com.shima.demo.ThemeConfig(getContext());
    syntaxPlain = theme.color(com.shima.demo.ThemeConfig.PLAIN);
    int[] palette = new int[almlk.EditorSyntaxRoles.PALETTE_SIZE];
    for (int styleId = 0; styleId < palette.length; styleId++) {
      palette[styleId] =
          theme.color(almlk.EditorSyntaxRoles.paletteKey(styleId), !theme.isLight());
    }
    syntaxPalette = palette;
  }

  private int colorForType(int type) {
    return syntaxPalette != null && type >= 0 && type < syntaxPalette.length
        ? syntaxPalette[type]
        : syntaxPlain;
  }

  /** سطر النتيجة كما في المرجع: تلوين نحوي كامل وخط سفلي تحت كل ظهور للرمز المبحوث. */
  private CharSequence styledPreview(UsageSearchEngine.Usage usage) {
    String text = usage.preview;
    SpannableString span = new SpannableString(text);
    ensureSyntaxPalette();
    List<CodeLanguageTools.Range> ranges;
    try {
      ranges = CodeLanguageTools.highlight(usage.fileName, text);
    } catch (Throwable error) {
      ranges = Collections.emptyList();
    }
    for (CodeLanguageTools.Range range : ranges) {
      int start = Math.max(0, range.start), end = Math.min(text.length(), range.end);
      if (start < end)
        span.setSpan(
            new ForegroundColorSpan(colorForType(range.type)),
            start,
            end,
            Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
    }
    if (!searchHighlight.isEmpty()) {
      int at = text.indexOf(searchHighlight);
      while (at >= 0) {
        span.setSpan(
            new UnderlineSpan(),
            at,
            at + searchHighlight.length(),
            Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        at = text.indexOf(searchHighlight, at + searchHighlight.length());
      }
    }
    return span;
  }

  private static String shortFileName(String path) {
    int slash = Math.max(path.lastIndexOf('/'), path.lastIndexOf('\\'));
    return slash < 0 ? path : path.substring(slash + 1);
  }

  /** أيقونة رأس الملف: تُقرأ من {@code almlk.FileTypeIcons} وحده — لا خريطة ثانية هنا. */
  private static int fileTypeIcon(String name) {
    return almlk.FileTypeIcons.forFile(name);
  }

  private final class UsageAdapter extends BaseAdapter {
    private static final int TYPE_STATUS = 0, TYPE_FILE = 1, TYPE_MATCH = 2;

    @Override
    public int getViewTypeCount() {
      return 3;
    }

    @Override
    public int getItemViewType(int position) {
      if (usages.isEmpty()) return TYPE_STATUS;
      return searchRows.get(position) instanceof String ? TYPE_FILE : TYPE_MATCH;
    }

    @Override
    public int getCount() {
      return usages.isEmpty() ? (searchStatus.isEmpty() ? 0 : 1) : searchRows.size();
    }

    @Override
    public Object getItem(int position) {
      return usages.isEmpty() ? null : searchRows.get(position);
    }

    @Override
    public long getItemId(int position) {
      return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
      int type = getItemViewType(position);
      if (type == TYPE_STATUS) {
        TextView view =
            convertView instanceof TextView ? (TextView) convertView : label("", 13, Color.LTGRAY);
        view.setPaddingRelative(dp(14), dp(10), dp(8), dp(10));
        view.setText(searchStatus);
        return view;
      }
      if (type == TYPE_FILE) {
        LinearLayout row;
        if (convertView instanceof LinearLayout) {
          row = (LinearLayout) convertView;
        } else {
          row = new LinearLayout(getContext());
          row.setOrientation(HORIZONTAL);
          row.setGravity(Gravity.CENTER_VERTICAL);
          row.setPaddingRelative(dp(14), dp(12), dp(10), dp(4));
          ImageView icon = new ImageView(getContext());
          row.addView(icon, new LinearLayout.LayoutParams(dp(20), dp(20)));
          TextView name = label("", 15, Color.WHITE);
          name.setPaddingRelative(dp(10), 0, 0, 0);
          row.addView(name);
        }
        String fileName = (String) searchRows.get(position);
        // أيقونة بنوع الملف كما في المرجع: ملفات الجافا بأيقونتها لا بأيقونة كود عامة.
        ((ImageView) row.getChildAt(0)).setImageResource(fileTypeIcon(fileName));
        ((TextView) row.getChildAt(1)).setText(shortFileName(fileName));
        return row;
      }
      TextView view;
      if (convertView instanceof TextView) {
        view = (TextView) convertView;
      } else {
        view = label("", 13, Color.WHITE);
        view.setTypeface(Typeface.MONOSPACE);
        view.setPaddingRelative(dp(40), dp(4), dp(10), dp(8));
      }
      view.setText(styledPreview((UsageSearchEngine.Usage) searchRows.get(position)));
      return view;
    }
  }

  private static final class PanelHeader {
    final LinearLayout root;
    final ImageView icon;
    final TextView title;

    PanelHeader(LinearLayout root, ImageView icon, TextView title) {
      this.root = root;
      this.icon = icon;
      this.title = title;
    }
  }
}
