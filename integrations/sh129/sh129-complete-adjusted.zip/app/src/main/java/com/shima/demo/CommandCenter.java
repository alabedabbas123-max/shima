package com.shima.demo;

import java.util.*;

/**
 * The IDE command catalogue. UI controls only submit an id; eligibility, dynamic titles and
 * execution routing live inside the command objects — the same command serves the palette,
 * the cascading menus, toolbar icons and shortcuts without duplicated menu code.
 */
public final class CommandCenter {
  public interface Host {
    boolean hasProject();

    boolean hasEditor();

    /** Selection gate for symbol navigation; a caret word alone is not a Go To request. */
    boolean hasExplicitEditorSelection();

    boolean canUndo();

    boolean canRedo();

    /** لغة الملف الحي لضمان ألا تنفذ أوامر Java النصية على XML قبل توفير بدائل XML الآمنة. */
    boolean isXmlEditor();

    /** حالة الكتابة الحية للملف النشط. */
    boolean isEditorWritable();

    /**
     * ج٤٢: هل في أيِّ لِسَانٍ تَعدِيلٌ لم يُحفَظْ؟ «احفَظِ الكُلَّ» يَعمَلُ على الدَّفْتَرِ لا على النَّشِطِ،
     * فَأَهلِيَّتُهُ تُقالُ منهُ: لا عُنصَرٌ مَفتُوحٌ لا يَفعَلُ شَيئًا، ولا مُعطَّلٌ وشَيءٌ يَنتَظِرُ.
     */
    default boolean hasPendingEdits() {
      return false;
    }

    /** هل التبويب الحالي ملف تخطيط XML يدعمه المصمم. */
    boolean isLayoutXmlEditor();

    boolean panelsShowing();

    /** مشروع Gradle (build.gradle/‎.kts) — شرط «تحويل المشروع» كالمرجع. */
    default boolean hasGradleProject() {
      return hasProject();
    }

    void execute(String id);
  }

  /** Per-command live condition evaluated right before a menu or palette is displayed. */
  public interface StateCheck {
    boolean test(Host h);
  }

  /** Dynamic title provider (reference pattern: items such as show/hide panels flip text). */
  public interface TitleProvider {
    String title(Host h);
  }

  public static final class Command {
    public final String id, title, group;
    public final boolean needsProject, needsEditor;
    final StateCheck liveState;
    final TitleProvider dynamicTitle;

    Command(String i, String t, String g, boolean p, boolean e, StateCheck s, TitleProvider d) {
      id = i;
      title = t;
      group = g;
      needsProject = p;
      needsEditor = e;
      liveState = s;
      dynamicTitle = d;
    }

    public boolean enabled(Host h) {
      return (!needsProject || h.hasProject())
          && (!needsEditor || h.hasEditor())
          && (liveState == null || liveState.test(h));
    }

    /** Title shown right now; falls back to the static title when no provider is attached. */
    public String titleFor(Host h) {
      return dynamicTitle == null ? title : dynamicTitle.title(h);
    }
  }

  private final LinkedHashMap<String, Command> all = new LinkedHashMap<>();
  private final LinkedHashMap<String, String[]> menus = new LinkedHashMap<>();

  public CommandCenter() {
    add("run", "command_run", "ui_group_build", true, false);
    add("build_debug", "menu_build_debug", "ui_group_build", true, false);
    add("build_release", "menu_build_release", "ui_group_build", true, false);
    add("clean", "menu_clean", "ui_group_build", true, false);
    add("terminal", "menu_terminal", "ui_group_build", true, false);
    add("save", "command_save", "ui_group_editor", true, true, Host::isEditorWritable, null);
    add("save_all", "command_save_all", "ui_group_editor", true, true, Host::hasPendingEdits, null);
    add("undo", "command_undo", "ui_group_editor", false, true, Host::canUndo, null);
    add("redo", "command_redo", "ui_group_editor", false, true, Host::canRedo, null);
    add("find", "command_find", "ui_group_editor", false, true);
    add("replace", "menu_replace", "ui_group_editor", false, true, Host::isEditorWritable, null);
    add("goto_line", "command_goto_line", "ui_group_editor", false, true);
    add("goto_definition", "command_go_to_definition", "ui_group_editor", false, true,
        Host::hasExplicitEditorSelection, null);
    add("design", "command_design", "ui_group_editor", false, true,
        h -> h.isLayoutXmlEditor() && h.isEditorWritable(), null);
    // المرحلة السادسة: التنسيق والتعليق يعملان في XML أيضًا بمحركَي almlk المستقلين.
    add("format", "command_format", "ui_group_editor", false, true, Host::isEditorWritable, null);
    add("comment", "ui_command_toggle_comment", "ui_group_editor", false, true, Host::isEditorWritable, null);
    add("select_all", "keybind_select_all", "ui_group_editor", false, true);
    add("analyze", "menu_diagnostics", "ui_group_editor", false, true);
    add("complete", "menu_completion", "ui_group_editor", false, true);
    add("find_usages", "command_find_usages", "ui_group_editor", false, true);
    add("goto_element", "command_go_to_element", "ui_group_editor", false, true,
        Host::hasExplicitEditorSelection, null);
    add(
        "panels",
        "ui_command_show_panels",
        "ui_group_view",
        false,
        false,
        null,
        h -> h.panelsShowing() ? "ui_command_hide_panels" : "ui_command_show_panels");
    add("show_errors", "command_show_errors", "ui_group_view", false, false);
    add("show_search_results", "command_search_results", "ui_group_view", false, false);
    add("show_build_output", "command_build_output", "ui_group_view", false, false);
    add("show_debugger", "command_debugger", "ui_group_view", false, false);
    add("show_logcat", "command_logcat", "ui_group_view", false, false);
    add("close_file", "menu_close_file", "ui_group_editor", false, true);
    add("close_all", "menu_close_all", "ui_group_editor", false, true);
    add("files", "command_files", "ui_group_files", false, false);
    add("new_file", "command_files_create_new_file", "ui_group_files", true, false);
    add("new_folder", "command_files_create_new_folder", "ui_group_files", true, false);
    add("refresh", "ui_command_refresh_project_tree", "ui_group_files", false, false);
    add("git_status", "ui_command_git_status", "ui_group_git", true, false);
    add("git_log", "ui_command_git_log", "ui_group_git", true, false);
    add("git_add", "ui_command_git_add", "ui_group_git", true, false);
    add("git_commit", "command_git_commit", "ui_group_git", true, false);
    add("git_pull", "command_git_pull", "ui_group_git", true, false);
    add("git_push", "command_git_push", "ui_group_git", true, false);
    add("theme", "menu_color_scheme", "ui_group_general", false, false);
    add("permissions", "menu_permissions", "ui_group_general", false, false);
    add("settings", "command_settings", "ui_group_general", false, false);
    // المرحلة الثامنة: إعدادات نمط الكود شاشة فعلية — لا تحتاج مشروعًا ولا ملفًا مفتوحًا.
    add("configure_style", "command_configure_code_style", "ui_group_general", false, false);
    add("about", "menu_about", "ui_group_general", false, false);
    // المرحلة 1 (اكتمال القائمة الرئيسية): أوامر المرجع الناقصة تُسجَّل بأهلية حية صريحة.
    add("exit", "command_exit", "ui_group_general", false, false);
    add("close_project", "command_close_project", "ui_group_general", true, false);
    add("publish_project", "command_publish_project", "ui_group_build", true, false);
    add("select_build_variant", "command_build_variants", "ui_group_build", true, false);
    // M5: تحديث البناء، وأدوات › أخرى (تحويل المشروع، الانتقال إلى مجلد).
    add("refresh_build", "command_refresh_build", "ui_group_build", true, false);
    add("convert_project", "command_convert_project", "ui_group_build", true, false,
        h -> h.hasGradleProject(), null);
    add("go_to_directory", "command_go_to_directory", "ui_group_general", false, false);
    // M6: بقية أدوات المرجع — أيقونات Material، وتلوين الصياغة، وتهريب الكود، و«أخرى...».
    add("material_icons", "menu_material_icon", "ui_group_general", false, false);
    add("syntax_highlighting", "menu_syntax_highlighting", "ui_group_general", false, false);
    add("escape_java", "tools_escape_java_command", "ui_group_general", false, false);
    add("escape_xml", "tools_escape_xml_command", "ui_group_general", false, false);
    add("batch_replace", "menu_batch_replace", "ui_group_general", false, false);
    add("json2bean", "menu_json2bean", "ui_group_general", false, false);
    add("system_resources", "menu_view_system_resources", "ui_group_general", false, false);
    // «للأمام» معطَّل صراحةً حتى يوجد سجل تنقّل (لا يُعرض كعنصر ميت صامت).
    add("forward", "command_forward", "ui_group_editor", false, true, h -> false, null);
    add("rename", "command_rename", "ui_group_editor", false, true);
    add("inline", "command_inline_variable", "ui_group_editor", false, true);
    add("introduce", "command_introduce_variable", "ui_group_editor", false, true);
    add("extract_method", "command_extract_method", "ui_group_editor", false, true);
    add("create_setters", "command_create_setters_and_getters", "ui_group_editor", false, true);
    add("create_constructor", "command_create_constructor", "ui_group_editor", false, true);
    add("extract_resources", "command_extract_resources", "ui_group_editor", false, true);
    add("organize_imports", "command_organize_imports", "ui_group_editor", false, true, Host::isEditorWritable, null);
    add("surround_try", "command_surround_with_trycatch", "ui_group_editor", false, true, Host::isEditorWritable, null);
    add("learn_style", "command_learn_code_style", "ui_group_general", false, true, Host::isEditorWritable, null);

    // سياقات القوائم المتدرجة — نفس الأمر يظهر في أكثر من سياق كما في سجل المرجع.
    menus.put("code", new String[] {
      "analyze", "complete", "format", "configure_style", "comment", "select_all", "goto_line",
      "goto_definition", "close_file", "close_all"
    });
    menus.put("view", new String[] {
      "files", "panels", "show_errors", "show_search_results", "show_build_output",
      "show_debugger", "show_logcat", "theme"
    });
    menus.put("find", new String[] {"find", "replace", "find_usages", "goto_element", "goto_line"});
    menus.put("project", new String[] {
      "refresh_build", "run", "build_debug", "build_release", "clean", "select_build_variant", "publish_project",
      "close_project", "new_file", "new_folder", "refresh", "files"
    });
    menus.put("git", new String[] {
      "git_status", "git_log", "git_add", "git_commit", "git_pull", "git_push"
    });
    menus.put("tools", new String[] {
      "terminal", "permissions", "theme", "material_icons", "format", "syntax_highlighting", "escape_java",
      "escape_xml", "about", "batch_replace", "json2bean", "convert_project", "system_resources", "go_to_directory"
    });
  }

  private void add(String i, String t, String g, boolean p, boolean e) {
    add(i, t, g, p, e, null, null);
  }

  private void add(
      String i, String t, String g, boolean p, boolean e, StateCheck s, TitleProvider d) {
    all.put(i, new Command(i, t, g, p, e, s, d));
  }

  public Command get(String id) {
    return all.get(id);
  }

  public List<String> groups() {
    LinkedHashSet<String> s = new LinkedHashSet<>();
    for (Command c : all.values()) s.add(c.group);
    return new ArrayList<>(s);
  }

  public List<Command> inGroup(String group) {
    ArrayList<Command> r = new ArrayList<>();
    for (Command c : all.values()) if (c.group.equals(group)) r.add(c);
    return r;
  }

  /** Commands registered for one cascading-menu context, in display order. */
  public List<Command> inMenu(String menuId) {
    ArrayList<Command> r = new ArrayList<>();
    String[] ids = menus.get(menuId);
    if (ids != null) for (String id : ids) if (all.containsKey(id)) r.add(all.get(id));
    return r;
  }

  public boolean dispatch(String id, Host host) {
    Command c = all.get(id);
    if (c == null || !c.enabled(host)) return false;
    host.execute(id);
    return true;
  }
}
