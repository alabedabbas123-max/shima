package com.shima.performance;

import com.almlkid.kay.ui.CodeLanguageTools;
import com.almlkid.kay.ui.ProjectDiagnostic;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * R6: the last complete project diagnostics, persisted per project so a reopened project shows
 * its errors at once — as the reference does — while the real scan runs behind them. Every file's
 * findings carry the file's stamp (modification time and size); a file whose stamp changed loses
 * its stale findings at load time. Plain files only (no Android types), so it is unit-tested.
 */
public final class ProjectDiagnosticsSnapshot {
  /** Current stamp of a referenced file; null when it cannot be told cheaply (kept as is). */
  public interface StampSource {
    String stampOf(String reference);
  }

  private static final String HEADER = "shima-diagnostics-v1";
  private static final int MAX_ROWS = 2000;
  private final File dir;

  public ProjectDiagnosticsSnapshot(File dir) {
    this.dir = dir;
  }

  /** Stamp of a plain file reference: modification time and length; null for other references. */
  public static String fileStamp(String reference) {
    if (reference == null || reference.isEmpty() || reference.startsWith("content:")) return null;
    File f = new File(reference);
    if (!f.isAbsolute()) return null;
    return f.isFile() ? f.lastModified() + ":" + f.length() : "missing";
  }

  private File fileFor(String projectKey) {
    try {
      MessageDigest md = MessageDigest.getInstance("SHA-1");
      byte[] digest = md.digest(projectKey.getBytes(StandardCharsets.UTF_8));
      StringBuilder name = new StringBuilder();
      for (int i = 0; i < 10; i++) name.append(String.format("%02x", digest[i] & 0xff));
      return new File(dir, name + ".tsv");
    } catch (Exception e) {
      return new File(dir, Integer.toHexString(projectKey.hashCode()) + ".tsv");
    }
  }

  /**
   * Saves {@code diagnostics} (source findings only) with each file's stamp from {@code stamps}.
   * Written to a temporary file then renamed: a crash never leaves a half snapshot.
   */
  public synchronized void save(String projectKey, List<ProjectDiagnostic> diagnostics, StampSource stamps) {
    save(projectKey, diagnostics, stamps, 0L);
  }

  /**
   * {@code structureEpoch} — عددُ مرّاتِ تغيّرِ عقودِ الأصنافِ منذَ المسحِ (W21′1). يُكتبُ في السطرِ
   * الأولِ ويُقابَلُ عندَ القراءةِ، فلا تُستعادَ صفوفٌ حُفِظَت قبلَ حذفِ عضوٍ أو إضافتِه وتُعرَضَ كأنَّها
   * طريّةٌ؛ الصفرُ يعني «لا قيدَ»، وهو ما تكتبُهُ الطبقاتُ التي لا تعرفُ البنيةَ.
   */
  public synchronized void save(
      String projectKey, List<ProjectDiagnostic> diagnostics, StampSource stamps, long structureEpoch) {
    if (dir == null || projectKey == null || projectKey.isEmpty()) return;
    if (!dir.isDirectory() && !dir.mkdirs()) return;
    File target = fileFor(projectKey);
    File temp = new File(dir, target.getName() + ".tmp");
    HashMap<String, String> stampCache = new HashMap<>();
    int rows = 0;
    try (Writer out = new OutputStreamWriter(new FileOutputStream(temp), StandardCharsets.UTF_8)) {
      out.write(HEADER + "\t" + escape(projectKey) + "\t" + structureEpoch + "\n");
      for (ProjectDiagnostic p : diagnostics == null ? Collections.<ProjectDiagnostic>emptyList() : diagnostics) {
        if (p == null || p.fromBuild || p.diagnostic == null || rows >= MAX_ROWS) continue;
        String stamp = stampCache.get(p.reference);
        if (stamp == null && !stampCache.containsKey(p.reference)) {
          stamp = stamps == null ? null : stamps.stampOf(p.reference);
          stampCache.put(p.reference, stamp);
        }
        CodeLanguageTools.Diagnostic d = p.diagnostic;
        StringBuilder args = new StringBuilder();
        for (int i = 0; i < d.messageArgs.length; i++) {
          if (i > 0) args.append('\u001f');
          appendArg(args, d.messageArgs[i]);
        }
        String[] fields = {
          p.fileName, p.reference, stamp == null ? "" : stamp, p.preview, p.symbol,
          Integer.toString(p.endColumn), Integer.toString(d.offset), Integer.toString(d.end),
          Integer.toString(d.line), Integer.toString(d.column), d.severity.name(), d.code,
          d.message == null ? "" : d.message, d.messageKey == null ? "" : d.messageKey, args.toString()
        };
        StringBuilder line = new StringBuilder();
        for (int i = 0; i < fields.length; i++) {
          if (i > 0) line.append('\t');
          line.append(escape(fields[i]));
        }
        out.write(line.append('\n').toString());
        rows++;
      }
    } catch (Exception e) {
      temp.delete();
      return;
    }
    if (!temp.renameTo(target)) {
      target.delete();
      if (!temp.renameTo(target)) temp.delete();
    }
  }

  /** The saved findings still valid for their files; empty when there is no snapshot. */
  public synchronized List<ProjectDiagnostic> load(String projectKey, StampSource stamps) {
    return load(projectKey, stamps, 0L);
  }

  /** اللقطةُ صالحةٌ فقطْ إن كُتِبَت تحتَ عرسةِ البنيةِ نفسِها (W21′1). */
  public synchronized List<ProjectDiagnostic> load(
      String projectKey, StampSource stamps, long structureEpoch) {
    if (dir == null || projectKey == null || projectKey.isEmpty()) return Collections.emptyList();
    File source = fileFor(projectKey);
    if (!source.isFile()) return Collections.emptyList();
    ArrayList<ProjectDiagnostic> result = new ArrayList<>();
    HashMap<String, Boolean> fresh = new HashMap<>();
    try (BufferedReader in =
        new BufferedReader(new InputStreamReader(new FileInputStream(source), StandardCharsets.UTF_8))) {
      String header = in.readLine();
      if (header == null
          || !header.equals(HEADER + "\t" + escape(projectKey) + "\t" + structureEpoch))
        return Collections.emptyList();
      String line;
      while ((line = in.readLine()) != null && result.size() < MAX_ROWS) {
        String[] f = line.split("\t", -1);
        if (f.length != 15) continue;
        for (int i = 0; i < f.length; i++) f[i] = unescape(f[i]);
        String reference = f[1];
        Boolean ok = fresh.get(reference);
        if (ok == null) {
          String now = stamps == null ? null : stamps.stampOf(reference);
          ok = now == null || now.equals(f[2]);
          fresh.put(reference, ok);
        }
        if (!ok) continue;
        CodeLanguageTools.Diagnostic.Severity severity;
        try {
          severity = CodeLanguageTools.Diagnostic.Severity.valueOf(f[10]);
        } catch (IllegalArgumentException e) {
          continue;
        }
        Object[] args = f[14].isEmpty() ? new Object[0] : splitArgs(f[14]);
        CodeLanguageTools.Diagnostic d =
            CodeLanguageTools.Diagnostic.restored(Integer.parseInt(f[6]), Integer.parseInt(f[7]),
                Integer.parseInt(f[8]), Integer.parseInt(f[9]), severity, f[11], f[12],
                f[13].isEmpty() ? null : f[13], args);
        ProjectDiagnostic p = ProjectDiagnostic.restored(f[0], reference, f[3], f[4], Integer.parseInt(f[5]), d);
        if (p != null) result.add(p);
      }
    } catch (Exception e) {
      return Collections.emptyList();
    }
    return result;
  }

  /** Removes a project's snapshot (used when its findings can no longer be trusted). */
  public synchronized void clear(String projectKey) {
    if (dir != null && projectKey != null && !projectKey.isEmpty()) fileFor(projectKey).delete();
  }

  /**
   * الحُجَّةُ تُكتَبُ بوِسمِ نَوعِها: ‏`ui_diagnostic_requires_api`‏ و‏`ui_toast_abstract_methods`‏
   * تَطلُبُ ‏`%2$d`‏ و‏`%1$d`‏، ولو رَجَعَتِ الرقْمُ سِلسِلَةً من القرصِ رَمَتِ الصَّفحَةُ
   * ‏IllegalFormatConversionException`‏ عندَ نَسْقِ الرِّسالةِ (وهو ما كانَ يَحدُثُ لِلُّقطةِ المَحمُولَةِ
   * عِندَ فَتحِ المَشرُوعِ). والأَوسامُ سِلسِلَةٌ قَبلَ الحَرفِ، فلا تَتَّدِخُ معَ ‏escape`‏ ولا تَمنَعُ
   * لُقطةً قَديمَةً بلا وِسامٍ (تُقرَأُ سِلسِلَةً كما كُتِبَت).
   */
  private static void appendArg(StringBuilder out, Object arg) {
    if (arg instanceof Integer) out.append("#i").append(arg);
    else if (arg instanceof Long) out.append("#l").append(arg);
    else if (arg instanceof Boolean) out.append("#b").append(arg);
    else out.append("#s").append(arg == null ? "" : String.valueOf(arg));
  }

  /** ‏`#i12`‏ ⇒ ‏Integer(12)`‏؛ وغيارُ الوِسمِ أو سَيِّئُهُ يَترُكُ النَّصَّ كما هُوَ — لا تُرمَى اللُّقطةُ. */
  private static Object[] splitArgs(String field) {
    String[] parts = field.split("\u001f", -1);
    Object[] args = new Object[parts.length];
    for (int i = 0; i < parts.length; i++) args[i] = argOf(parts[i]);
    return args;
  }

  private static Object argOf(String text) {
    if (text.length() >= 2 && text.charAt(0) == '#' && "ilbs".indexOf(text.charAt(1)) >= 0) {
      String body = text.substring(2);
      try {
        switch (text.charAt(1)) {
          case 'i':
            return Integer.valueOf(body);
          case 'l':
            return Long.valueOf(body);
          case 'b':
            return Boolean.valueOf(body);
          default:
            return body;
        }
      } catch (NumberFormatException malformed) {
        return body;
      }
    }
    return text;
  }

  private static String escape(String s) {
    if (s == null) return "";
    StringBuilder b = new StringBuilder(s.length() + 8);
    for (int i = 0; i < s.length(); i++) {
      char c = s.charAt(i);
      if (c == '\\') b.append("\\\\");
      else if (c == '\t') b.append("\\t");
      else if (c == '\n') b.append("\\n");
      else if (c == '\r') b.append("\\r");
      else b.append(c);
    }
    return b.toString();
  }

  private static String unescape(String s) {
    if (s.indexOf('\\') < 0) return s;
    StringBuilder b = new StringBuilder(s.length());
    for (int i = 0; i < s.length(); i++) {
      char c = s.charAt(i);
      if (c == '\\' && i + 1 < s.length()) {
        char n = s.charAt(++i);
        b.append(n == 't' ? '\t' : n == 'n' ? '\n' : n == 'r' ? '\r' : n);
      } else b.append(c);
    }
    return b.toString();
  }

  /** Map form of {@link StampSource} (tests and callers holding precomputed stamps). */
  public static StampSource of(Map<String, String> stamps) {
    return reference -> stamps.get(reference);
  }
}
