package com.almlkid.kay.ui;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

/**
 * Bounded, cancellation-friendly text search used by the editor and project browser.
 *
 * <p>Literal queries use String.indexOf, which is substantially cheaper than compiling a regular
 * expression for every file. Regex is compiled once per file, while line/column information is
 * calculated incrementally instead of rescanning the complete prefix for every match.
 */
public final class ProjectSearchEngine {
  public static final int DEFAULT_MAX_RESULTS = 2000;
  public static final int DEFAULT_MAX_FILE_BYTES = 8 * 1024 * 1024;

  private ProjectSearchEngine() {}

  public interface Cancellation {
    boolean isCancelled();
  }

  public static final Cancellation NEVER_CANCELLED = () -> false;

  public static final class Query {
    public final String text;
    public final boolean caseSensitive;
    public final boolean wholeWord;
    public final boolean regularExpression;
    public final int maxResults;

    public Query(
        String text,
        boolean caseSensitive,
        boolean wholeWord,
        boolean regularExpression,
        int maxResults) {
      this.text = text == null ? "" : text;
      this.caseSensitive = caseSensitive;
      this.wholeWord = wholeWord;
      this.regularExpression = regularExpression;
      this.maxResults = Math.max(1, Math.min(10000, maxResults));
    }

    public boolean isEmpty() {
      return text.trim().isEmpty();
    }
  }

  /** Searches one text file and returns at most query.maxResults matches. */
  public static List<UsageSearchEngine.Usage> search(
      String fileName,
      String reference,
      String source,
      Query query,
      Cancellation cancellation) {
    if (source == null || query == null || query.isEmpty()) return Collections.emptyList();
    Cancellation stop = cancellation == null ? NEVER_CANCELLED : cancellation;
    if (stop.isCancelled() || containsBinaryControl(source)) return Collections.emptyList();

    ArrayList<UsageSearchEngine.Usage> result = new ArrayList<>();
    LineCursor lines = new LineCursor(source);
    if (query.regularExpression) {
      searchRegex(fileName, reference, source, query, stop, lines, result);
    } else {
      searchLiteral(fileName, reference, source, query, stop, lines, result);
    }
    return result;
  }

  private static void searchLiteral(
      String fileName,
      String reference,
      String source,
      Query query,
      Cancellation stop,
      LineCursor lines,
      ArrayList<UsageSearchEngine.Usage> result) {
    String needle = query.caseSensitive ? query.text : query.text.toLowerCase(Locale.ROOT);
    String haystack = query.caseSensitive ? source : source.toLowerCase(Locale.ROOT);
    if (needle.isEmpty()) return;

    int from = 0;
    int length = needle.length();
    CharBoyerMoore matcher = new CharBoyerMoore(needle);
    while (from <= haystack.length() - length && result.size() < query.maxResults) {
      if ((result.size() & 63) == 0 && stop.isCancelled()) return;
      int at = matcher.indexOf(haystack, from);
      if (at < 0) return;
      int end = at + length;
      if (!query.wholeWord || isWholeWord(source, at, end)) {
        appendResult(result, fileName, reference, source, at, end, "match", lines);
      }
      // Move by one to preserve overlapping matches; normal queries remain linear because
      // String.indexOf performs the optimized search internally.
      from = at + 1;
    }
  }

  private static void searchRegex(
      String fileName,
      String reference,
      String source,
      Query query,
      Cancellation stop,
      LineCursor lines,
      ArrayList<UsageSearchEngine.Usage> result) {
    int flags = query.caseSensitive ? 0 : Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE;
    final Pattern pattern;
    try {
      pattern = Pattern.compile(query.text, flags);
    } catch (PatternSyntaxException invalid) {
      return;
    }
    Matcher matcher = pattern.matcher(source);
    while (matcher.find() && result.size() < query.maxResults) {
      if ((result.size() & 63) == 0 && stop.isCancelled()) return;
      int start = matcher.start();
      int end = matcher.end();
      if (end == start) {
        if (start < source.length()) end = start + 1;
        else break;
      }
      if (!query.wholeWord || isWholeWord(source, start, end))
        appendResult(result, fileName, reference, source, start, end, "regex", lines);
    }
  }

  private static void appendResult(
      ArrayList<UsageSearchEngine.Usage> result,
      String fileName,
      String reference,
      String source,
      int start,
      int end,
      String kind,
      LineCursor lines) {
    lines.moveTo(start);
    int lineEnd = source.indexOf('\n', end);
    if (lineEnd < 0) lineEnd = source.length();
    int previewEnd = Math.min(lineEnd, lines.lineStart + 240);
    String preview = source.substring(lines.lineStart, previewEnd).trim();
    // ‏W31: المطابقةُ قد تَتَّسِعُ إلى أسطرٍ (regex متعددُ الأسطرِ)، فالمُدخلُ إلى القفزةِ مدىً
    // محصورٌ في سطرِ البدايةِ — لا «العمودُ الأخيرُ من السطرِ كلِّهِ» على سطرٍ آخرَ يُنسَبُ إليه.
    int startLineEnd = source.indexOf('\n', start);
    if (startLineEnd < 0) startLineEnd = source.length();
    result.add(
        new UsageSearchEngine.Usage(
            fileName,
            reference,
            start,
            lines.line,
            start - lines.lineStart + 1,
            Math.min(end, startLineEnd) - lines.lineStart + 1,
            preview,
            kind));
  }

  private static boolean isWholeWord(String source, int start, int end) {
    boolean left = start > 0 && Character.isJavaIdentifierPart(source.charAt(start - 1));
    boolean right = end < source.length() && Character.isJavaIdentifierPart(source.charAt(end));
    return !left && !right;
  }

  private static boolean containsBinaryControl(String source) {
    int limit = Math.min(source.length(), 4096);
    for (int i = 0; i < limit; i++) {
      char c = source.charAt(i);
      if (c == 0 || (c < 9 && c != '\n' && c != '\r' && c != '\t')) return true;
    }
    return false;
  }

  /**
   * Bad-character Boyer-Moore matcher for literal queries. The AndroidIDE search implementation
   * uses the same family of skip-table algorithms; this char version preserves UTF-16 offsets so
   * editor navigation remains exact.
   */
  private static final class CharBoyerMoore {
    private final String pattern;
    private final int[] skip = new int[256];

    CharBoyerMoore(String pattern) {
      this.pattern = pattern;
      int length = pattern.length();
      java.util.Arrays.fill(skip, length);
      for (int i = 0; i < length - 1; i++) {
        char value = pattern.charAt(i);
        if (value < skip.length) skip[value] = length - 1 - i;
      }
    }

    int indexOf(String text, int from) {
      int length = pattern.length();
      if (length == 0) return Math.max(0, from);
      int end = Math.min(text.length(), from + length - 1);
      while (end < text.length()) {
        int patternAt = length - 1;
        int textAt = end;
        while (patternAt >= 0 && pattern.charAt(patternAt) == text.charAt(textAt)) {
          patternAt--;
          textAt--;
        }
        if (patternAt < 0) return textAt + 1;
        // Horspool shifts from the character aligned with the last pattern position, not the
        // earlier mismatch position.
        char bad = text.charAt(end);
        end += bad < skip.length ? Math.max(1, skip[bad]) : length;
      }
      return -1;
    }
  }

  /** Monotonic line cursor: each source character is visited at most once per search. */
  private static final class LineCursor {
    final String source;
    int line = 1;
    int lineStart;
    int nextLineBreak;

    LineCursor(String source) {
      this.source = source;
      nextLineBreak = source.indexOf('\n');
    }

    void moveTo(int offset) {
      int target = Math.max(0, Math.min(offset, source.length()));
      while (nextLineBreak >= 0 && target > nextLineBreak) {
        line++;
        lineStart = nextLineBreak + 1;
        nextLineBreak = source.indexOf('\n', lineStart);
      }
    }
  }
}
