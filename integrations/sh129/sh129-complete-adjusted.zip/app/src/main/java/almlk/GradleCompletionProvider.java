package almlk;

import com.almlkid.kay.ui.ProjectSymbolIndex.CompletionItem;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

/**
 * Build-file completion presented exactly like Java rows: DSL blocks and functions are methods
 * (red cube with their signature), properties are fields (blue cube with their type), plus the
 * Groovy keywords. Inside {@code JavaVersion.} the enum constants are offered.
 */
public final class GradleCompletionProvider {

  private GradleCompletionProvider() {}

  /** name → {kind, suffix}; kind M = method, F = property, C = class, K = keyword. */
  private static final LinkedHashMap<String, String[]> DSL = new LinkedHashMap<>();

  private static void m(String name, String params, String ret) {
    DSL.put(name, new String[] {"M", "(" + params + ") : " + ret});
  }

  private static void f(String name, String type) {
    DSL.put(name, new String[] {"F", " : " + type});
  }

  static {
    for (String block : new String[] {"plugins", "android", "defaultConfig", "buildTypes", "release", "debug",
        "dependencies", "repositories", "compileOptions", "sourceSets", "signingConfigs", "packagingOptions",
        "packaging", "lintOptions", "lint", "buildFeatures", "kotlinOptions", "productFlavors", "allprojects",
        "buildscript", "subprojects", "pluginManagement", "dependencyResolutionManagement", "externalNativeBuild",
        "testOptions", "aaptOptions", "androidResources", "splits", "main", "configurations", "java", "jniLibs",
        "resources", "manifest", "flavorDimensions"})
      m(block, "Closure configure", "void");
    for (String config : new String[] {"implementation", "api", "compileOnly", "runtimeOnly", "testImplementation",
        "androidTestImplementation", "debugImplementation", "releaseImplementation", "annotationProcessor",
        "kapt", "classpath", "coreLibraryDesugaring"})
      m(config, "Object dependencyNotation", "Dependency");
    m("id", "String id", "PluginDependencySpec");
    m("version", "String version", "PluginDependencySpec");
    m("google", "", "MavenArtifactRepository");
    m("mavenCentral", "", "MavenArtifactRepository");
    m("mavenLocal", "", "MavenArtifactRepository");
    m("jcenter", "", "MavenArtifactRepository");
    m("maven", "Closure configure", "MavenArtifactRepository");
    m("gradlePluginPortal", "", "ArtifactRepository");
    m("url", "Object path", "void");
    m("fileTree", "Map args", "ConfigurableFileTree");
    m("files", "Object... paths", "ConfigurableFileCollection");
    m("project", "String path", "Project");
    m("platform", "Object notation", "Dependency");
    m("proguardFiles", "Object... files", "void");
    m("getDefaultProguardFile", "String name", "File");
    m("buildConfigField", "String type, String name, String value", "void");
    m("resValue", "String type, String name, String value", "void");
    m("useLibrary", "String name", "void");
    m("apply", "Map options", "void");
    m("task", "String name", "Task");
    m("include", "String... projectPaths", "void");
    m("exclude", "Map excludeProperties", "void");
    m("abiFilters", "String... abis", "void");
    m("storeFile", "File file", "void");
    m("file", "Object path", "File");
    f("namespace", "String");
    f("compileSdk", "int");
    f("compileSdkVersion", "int");
    f("buildToolsVersion", "String");
    f("applicationId", "String");
    f("applicationIdSuffix", "String");
    f("minSdk", "int");
    f("minSdkVersion", "int");
    f("targetSdk", "int");
    f("targetSdkVersion", "int");
    f("versionCode", "int");
    f("versionName", "String");
    f("versionNameSuffix", "String");
    f("minifyEnabled", "boolean");
    f("shrinkResources", "boolean");
    f("debuggable", "boolean");
    f("multiDexEnabled", "boolean");
    f("viewBinding", "boolean");
    f("dataBinding", "boolean");
    f("buildConfig", "boolean");
    f("sourceCompatibility", "JavaVersion");
    f("targetCompatibility", "JavaVersion");
    f("jvmTarget", "String");
    f("signingConfig", "SigningConfig");
    f("testInstrumentationRunner", "String");
    f("storePassword", "String");
    f("keyAlias", "String");
    f("keyPassword", "String");
    f("abortOnError", "boolean");
    f("checkReleaseBuilds", "boolean");
    f("ndkVersion", "String");
    f("rootProject", "Project");
    DSL.put("JavaVersion", new String[] {"C", ""});
    for (String keyword : new String[] {"true", "false", "null", "def", "if", "else", "return", "new", "plugin",
        "from", "into", "ext"})
      DSL.put(keyword, new String[] {"K", ""});
  }

  /**
   * قواعدُ المستخدمِ («سطرٌ لكلِّ قاعدةٍ» — `gradle_comple` في الإعداداتِ المتقدمةِ): تُحمَلُ من ملفٍّ
   * وتُحقَنُ من {@link almlk.AppSettings#applyGradleCompletionRules} مرّةً لكلِّ نسخةٍ من الملفِّ،
   * فلا قراءةَ قرصٍ داخلَ مسارِ الإكمالِ. والمفتاحُ `enable_gradle_comple` يُسقِطُها كلَّها.
   */
  public static volatile CompletionRules USER_RULES = CompletionRules.EMPTY;
  public static volatile boolean USER_RULES_ENABLED = true;

  /** تُضافُ القواعدُ أمامَ نتائجِ DSL (لا تُستبدَلُ بها): المكتمَلُ من القاعدَةِ أولَى بالمستخدمِ. */
  private static void prependRules(ArrayList<CompletionItem> out, String prefix) {
    if (!USER_RULES_ENABLED || USER_RULES.isEmpty()) return;
    for (CompletionRules.Item rule : USER_RULES.matching(prefix)) {
      CompletionItem item =
          new CompletionItem(CompletionItem.BUILD, rule.trigger, rule.insertText,
              rule.detail.isEmpty() ? "gradle rule" : rule.detail);
      out.add(0, item);
    }
  }

  private static final String[] JAVA_VERSIONS = {"VERSION_1_7", "VERSION_1_8", "VERSION_11", "VERSION_17", "VERSION_21"};

  public static List<CompletionItem> complete(String source, int cursor) {
    String text = source == null ? "" : source;
    int at = Math.max(0, Math.min(cursor, text.length()));
    int start = at;
    while (start > 0 && Character.isJavaIdentifierPart(text.charAt(start - 1))) start--;
    String prefix = text.substring(start, at);
    int coordinateStart = dependencyStringStart(text, at);
    if (coordinateStart >= 0) return coordinateItems(text.substring(coordinateStart, at));
    if (insideStringOrComment(text, start)) return new ArrayList<>();
    ArrayList<CompletionItem> out = new ArrayList<>();
    if (start > 0 && text.charAt(start - 1) == '.') {
      int r = start - 1;
      int rs = r;
      while (rs > 0 && Character.isJavaIdentifierPart(text.charAt(rs - 1))) rs--;
      if (text.substring(rs, r).equals("JavaVersion"))
        for (String v : JAVA_VERSIONS)
          if (CompletionMatcher.matches(v, prefix)) {
            CompletionItem item = new CompletionItem(CompletionItem.VARIABLE, v, v, "JavaVersion");
            out.add(item);
          }
      return out;
    }
    if (prefix.isEmpty()) {
      prependRules(out, prefix);
      return out;
    }
    for (java.util.Map.Entry<String, String[]> e : DSL.entrySet()) {
      String name = e.getKey();
      if (!CompletionMatcher.matches(name, prefix)) continue;
      String kind = e.getValue()[0];
      CompletionItem item;
      switch (kind) {
        case "M":
          item = new CompletionItem(CompletionItem.METHOD, name, name, "");
          item.suffix = e.getValue()[1];
          break;
        case "F":
          item = new CompletionItem(CompletionItem.VARIABLE, name, name, "");
          item.suffix = e.getValue()[1];
          break;
        case "C":
          item = new CompletionItem(CompletionItem.CLASS, name, name, "");
          break;
        default:
          item = new CompletionItem(CompletionItem.KEYWORD, name, name, "");
          break;
      }
      out.add(item);
    }
    out.sort((a, b) -> {
      int ra = CompletionMatcher.rank(a.label, prefix) >= 3 ? 1 : 0;
      int rb = CompletionMatcher.rank(b.label, prefix) >= 3 ? 1 : 0;
      if (ra != rb) return Integer.compare(ra, rb);
      int ka = a.kind == CompletionItem.KEYWORD ? 1 : 0;
      int kb = b.kind == CompletionItem.KEYWORD ? 1 : 0;
      return ka != kb ? Integer.compare(ka, kb) : a.label.compareToIgnoreCase(b.label);
    });
    prependRules(out, prefix);
    return out;
  }

  // ═══════════════ إحداثيات الاعتماد داخل النص (M5) ═══════════════

  private static final java.util.regex.Pattern DEPENDENCY_CALL = java.util.regex.Pattern.compile(
      "(?:^|[\\s{;(])(implementation|api|compileOnly|runtimeOnly|annotationProcessor|kapt|ksp|compile|provided"
          + "|[a-z][A-Za-z0-9]*(?:Implementation|Api|CompileOnly|RuntimeOnly|AnnotationProcessor))\\s*\\(?\\s*$");
  static final int COORDINATE_LIMIT = 100;

  /** بداية الاستبدال لإكمال الإحداثيات (بعد علامة الاقتباس)، أو بداية المعرّف خارجها. */
  public static int completionStart(String text, int cursor) {
    String value = text == null ? "" : text;
    int at = Math.max(0, Math.min(cursor, value.length()));
    int coordinateStart = dependencyStringStart(value, at);
    if (coordinateStart >= 0) return coordinateStart;
    int start = at;
    while (start > 0 && Character.isJavaIdentifierPart(value.charAt(start - 1))) start--;
    return start;
  }

  /**
   * إن كان المؤشر داخل نص اعتماد ({@code implementation 'g:a}، {@code api("g}) يعيد موضع ما بعد
   * علامة الاقتباس، وإلا -1.
   */
  static int dependencyStringStart(String text, int cursor) {
    int lineStart = text.lastIndexOf('\n', Math.max(0, cursor - 1)) + 1;
    if (cursor > 0 && text.charAt(cursor - 1) == '\n') lineStart = cursor;
    char quote = 0;
    int open = -1;
    for (int i = lineStart; i < cursor; i++) {
      char c = text.charAt(i);
      if (quote != 0) {
        if (c == '\\') i++;
        else if (c == quote) quote = 0;
      } else if (c == '"' || c == '\'') {
        quote = c;
        open = i;
      } else if (c == '/' && i + 1 < cursor && text.charAt(i + 1) == '/') {
        return -1;
      }
    }
    if (quote == 0 || open < 0) return -1;
    for (int i = open + 1; i < cursor; i++) {
      char c = text.charAt(i);
      if (!(Character.isLetterOrDigit(c) || c == '.' || c == ':' || c == '-' || c == '_' || c == '+')) return -1;
    }
    return DEPENDENCY_CALL.matcher(text.substring(lineStart, open)).find() ? open + 1 : -1;
  }

  /** «group:artifact:version» من المخزن المحلي ومن قائمة AndroidX، ثم الإصدارات بعد «g:a:». */
  static List<CompletionItem> coordinateItems(String typed) {
    ArrayList<CompletionItem> out = new ArrayList<>();
    java.util.Map<String, List<String>> installed = MavenStore.installedSnapshot();
    int firstColon = typed.indexOf(':');
    int secondColon = firstColon < 0 ? -1 : typed.indexOf(':', firstColon + 1);
    if (secondColon > 0) {
      String ga = typed.substring(0, secondColon);
      String partial = typed.substring(secondColon + 1);
      java.util.LinkedHashSet<String> versions = new java.util.LinkedHashSet<>();
      List<String> local = installed.get(ga);
      if (local != null) for (int i = local.size() - 1; i >= 0; i--) versions.add(local.get(i));
      String base = AndroidXMigration.baseVersion(ga);
      if (base != null) versions.add(base);
      versions.add("+");
      for (String v : versions) {
        if (!v.startsWith(partial)) continue;
        CompletionItem item = new CompletionItem(CompletionItem.VALUE, v, ga + ":" + v, "");
        item.suffix = local != null && local.contains(v) ? " - local" : "";
        out.add(item);
      }
      return out;
    }
    String needle = typed.toLowerCase(java.util.Locale.US);
    java.util.TreeSet<String> names = new java.util.TreeSet<>(installed.keySet());
    names.addAll(AndroidXMigration.androidxNames());
    ArrayList<String[]> ranked = new ArrayList<>();
    for (String ga : names) {
      String lower = ga.toLowerCase(java.util.Locale.US);
      int rank;
      if (needle.isEmpty() || lower.startsWith(needle)) rank = 0;
      else if (lower.substring(lower.indexOf(':') + 1).startsWith(needle)) rank = 1;
      else if (lower.contains(needle)) rank = 2;
      else continue;
      ranked.add(new String[] {ga, String.valueOf(installed.containsKey(ga) ? rank : rank + 3)});
    }
    ranked.sort((a, b) -> a[1].equals(b[1]) ? a[0].compareTo(b[0]) : a[1].compareTo(b[1]));
    for (String[] r : ranked) {
      if (out.size() >= COORDINATE_LIMIT) break;
      String ga = r[0];
      List<String> local = installed.get(ga);
      String coordinate = AndroidXMigration.baseVersion(ga) != null
          ? AndroidXMigration.coordinateFor(ga, true, local)
          : ga + ":" + newestStable(local);
      CompletionItem item = new CompletionItem(CompletionItem.PACKAGE, coordinate, coordinate, "");
      item.suffix = local != null ? " - local" : "";
      out.add(item);
    }
    return out;
  }

  private static String newestStable(List<String> versions) {
    if (versions == null || versions.isEmpty()) return "+";
    for (int i = versions.size() - 1; i >= 0; i--) if (MavenVersion.isStable(versions.get(i))) return versions.get(i);
    return versions.get(versions.size() - 1);
  }

  private static boolean insideStringOrComment(String text, int offset) {
    int lineStart = text.lastIndexOf('\n', Math.max(0, offset - 1)) + 1;
    char quote = 0;
    for (int i = lineStart; i < offset; i++) {
      char c = text.charAt(i);
      if (quote != 0) {
        if (c == '\\') i++;
        else if (c == quote) quote = 0;
      } else if (c == '"' || c == '\'') quote = c;
      else if (c == '/' && i + 1 < offset && text.charAt(i + 1) == '/') return true;
    }
    return quote != 0;
  }
}
