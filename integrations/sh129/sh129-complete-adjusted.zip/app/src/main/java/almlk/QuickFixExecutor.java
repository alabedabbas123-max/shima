package almlk;

import android.app.Activity;
import android.app.AlertDialog;
import android.widget.Toast;
import com.almlkid.ui.AIDEEditorPager;
import com.almlkid.ui.browsers.BrowserPager;
import com.shima.demo.UiStrings;

/**
 * Applies a {@link QuickFix} chosen from the selection toolbar (Stage 3 of error checking).
 *
 * <p>Flow, matching the reference app: resolve the file that declares the target class, ask "Modify
 * files" naming that file, and only after Yes edit it — in place. The editor is never navigated to
 * the created member: an applied fix changes text and nothing else, so the caret and the viewport
 * stay exactly where the reader left them.
 *
 * <ul>
 *   <li>Target already open with live content (the current class, an inner class of the current
 *       file, or another open tab): the edit goes through the editor model as one undoable step, so
 *       unsaved text in that tab is never overwritten from disk.
 *   <li>Otherwise the class file is located through the project symbol index, re-read at apply
 *       time, written atomically and re-indexed; a tab already open on it is refreshed in place, and
 *       no tab is opened just to show what was created.
 * </ul>
 *
 * Both paths end by re-inspecting only the files whose verdict this edit can change (the edited one,
 * the file the reported error belongs to, and other files blaming the same symbol), updating the error
 * panel rows in place — so the red underline and the panel entry of the call site disappear without
 * rescanning the project and without closing the panel.
 */
public final class QuickFixExecutor {

  /** What the executor needs from the hosting activity. */
  public interface Host {
    Activity activity();

    AIDEEditorPager editor();

    BrowserPager browser();

    /**
     * W20′2: إعادةُ فحصٍ موضعيّةٌ بعدَ الإصلاحِ — الملفاتُ التي يَتغيَّرُ حكمُها وحدَها وتبديلُ صفوفِها
     * في اللوحةِ في مكانِها. {@code editedFile} اسمُ التبويبِ/الملفِّ الذي مَسَّهُ التعديلُ (null إذا
     * كانَ النشِطَ وحدَهُ). لا إعادةَ مسحٍ للمشروعِ كلِّهِ ولا إغلاقَ للوحةِ ولا هدمَ لصفحتِها.
     */
    void quickFixApplied(QuickFix fix, String editedFile);

    /**
     * 1.0.175: جَلبُ اعتمادٍ طلبَهُ القارئُ من تشخيصٍ. يعيدُ {@code true} إذا قَبِلَ طابورُ المشروعِ المهمّةَ.
     * لا حوارَ ولا {@code ProgressDialog}: المرجعُ يَكتُبُ سطرَ الاعتمادِ ثمَّ يَضَعُ سطرَ حالةٍ (‏{@code
     * Kj.DW}) ويُنهي برسالةِ ختامٍ (‏{@code com.aide.common.ma})، فلا سببَ لإشغالِ المُحرِّرِ بمحاوِرِ انتظٍارٍ.
     */
    default boolean fetchDependency(QuickFix fix) {
      return false;
    }

    /**
     * ‏1.0.197: بِناءُ صِنفٍ مَجهُولٍ فِي باقَةِ المِلَفِّ الفَحصِيِّ — يَقبَلُ المُضيفُ المَهمَّةَ
     * ({@code true}) إذا كانَ عِندَهُ مُجَلَّدٌ يُوثَقُ مِنهُ وَكَتْبٌ يَجُوزُ، وَيُخبِرُ هُوَ بِنَتيجَتِها
     * عِندَ الفَراغِ. أَمّا {@code false} فَتَكونُ عِذرًا ظَاهِرًا لِلعَينِ (لا تابٍ وَلا كِتابَةٌ)، فَلا
     * صَفَّ مُزيَّفًا وَلا وَعْدًا بِأَثَرٍ لا يَجيءُ. عَلى المُضيفِ أن لا يَنطِقَ إِلا بَعدَ الكِتابَةِ،
     * وَأَن يُعِيدَ الفَحصَ فَتَسقُطُ الصُّفُوفُ الَّتي دَعَته — ذلِكَ هُوَ وَجهُ الصَّوابِ فِي هذِهِ
     * الجَولَةِ: لا شَيءَ فِي اللوحَةِ يَبقَى بَعدَ أن نَفِيَ مَا يُزِيلُهُ.
     */
    default boolean createType(QuickFix fix) {
      return false;
    }
  }

  private final Host host;

  public QuickFixExecutor(Host host) {
    this.host = host;
  }

  public void execute(QuickFix fix) {
    AIDEEditorPager editor = host.editor();
    if (fix == null || editor == null) return;
    if (fix.kind == QuickFix.Kind.FIX_IMPORTS) {
      // «Fix imports» = منظّم الاستيرادات القائم بحرفه (وله رسالتاه: نُظّمت / لا تغيير) — لا نسخة ثانية.
      editor.organizeImports();
      host.quickFixApplied(fix, null);
      return;
    }
    if (fix.kind == QuickFix.Kind.REMOVE_IMPORTS) {
      // دفعةُ حذفِ الاستيراداتِ: نفسُ مسارِ «Insert 'x'» — نصٌّ حيٌّ، عمليةٌ واحدةٌ، خطوةُ تراجعٍ واحدةٌ،
      // والمؤشِرُ والمِرناءُ لا يَتزاحانِ (W20/3)، فلا حاجةَ بمسارِ كتابةٍ ثانٍ هنا.
      String failure = editor.applyTokenInsertion(fix);
      if (failure != null) toast(text(failure));
      else {
        toast(UiStrings.format(host.activity(), "ui_imports_removed", String.valueOf(fix.importPlan.removedLines())));
        host.quickFixApplied(fix, null);
      }
      return;
    }
    if (fix.kind == QuickFix.Kind.INSERT_TOKEN
        || fix.kind == QuickFix.Kind.EDIT_TEXT
        || fix.kind == QuickFix.Kind.ADD_IMPORT) {
      // The reference's "Insert 'x'"/"Add 'import x'": a direct edit of the file being checked, no dialog.
      String failure = editor.applyTokenInsertion(fix);
      if (failure != null) toast(text(failure));
      else host.quickFixApplied(fix, null);
      return;
    }
    if (fix.kind == QuickFix.Kind.CREATE_TYPE) {
      // ‏1.0.197: بِناءُ صِنفٍ لا تَعدِيلُ نَصٍّ — العَملُ كُلُّهُ عَلى المُضيفِ: لا نِطاقَ نَفتَحُهُ
      // فِي المِحرِّرِ، وَلا خُطوَةَ تَراجُعٍ نَعِدُ بِهَا (ما مِن سِجلَّةٍ لِصَفحَةٍ لَم تَكُن قَبلَ
      // ذلِكَ: صَفحَةٌ لا سَطَرُ {@code REPLACE_TEXT_REGION} فِيهَا)، وَلا قَولَ «أُنشِئَ» قَبلَ أن
      // يُنشَأ: الكاتِبُ يَعِدُ بِخَبَرِهِ لَمّا يَفرُغُ، كَـ«جَلبِ المَكتَبَةِ» قَبلَهُ.
      if (!host.createType(fix)) toast(text("ui_create_class_unavailable"));
      return;
    }
    if (fix.kind == QuickFix.Kind.FETCH_DEPENDENCY) {
      // لا يَمسُّ نصَّ الملفِّ المفتوحِ ولا يُزِيحُ المؤشرَ ولا يُحدِّثُ صفوفَ اللوحةِ هنا: إعادةُ الفحصِ
      // هي التي تُسقِطُ التشخيصَ بعدَ أن تَثبُتَ الإحداثيّةُ في ملفِّ البناءِ (Band W20/3: بقاءُ الموضعِ).
      if (!host.fetchDependency(fix)) toast(text("ui_fetch_status_no_build_file"));
      return;
    }
    String tab = editor.openTabDeclaring(fix);
    if (tab != null) {
      confirm(displayName(tab), () -> applyInTab(tab, fix));
      return;
    }
    BrowserPager browser = host.browser();
    if (browser == null) return;
    browser.locateClassSource(
        fix.targetClass,
        (success, fileName, content, message) -> {
          if (!success) {
            toast(message);
            return;
          }
          if (content == null || fix.planInsertion(content) == null) {
            toast(text(fix.existsKey()));
            return;
          }
          confirm(displayName(fileName), () -> applyOnDisk(fix));
        });
  }

  private void applyInTab(String tab, QuickFix fix) {
    String failure = host.editor().applyQuickFixInTab(tab, fix);
    if (failure != null) {
      toast(text(failure));
      return;
    }
    toast(UiStrings.format(host.activity(), fix.createdKey(), fix.createdArg()));
    host.quickFixApplied(fix, tab);
  }

  private void applyOnDisk(QuickFix fix) {
    final QuickFix.Insertion[] applied = new QuickFix.Insertion[1];
    host.browser()
        .editClassSource(
            fix.targetClass,
            source -> {
              QuickFix.Insertion plan = fix.planInsertion(source);
              applied[0] = plan;
              return plan == null ? null : plan.applyTo(source);
            },
            (success, fileName, content, message) -> {
              if (!success) {
                toast(message);
                return;
              }
              // المرجعُ لا يكشفُ موضعَ الإضافةِ بعدَ الإصلاحِ: لا فتحَ ولا تنقّلَ ولا تحديدَ للاسمِ —
              // التبويبُ المفتوحُ يُحدَّثُ في مكانِه إن كانَ مفتوحًا، والكتابةُ القرصيّةُ تكفي غيرَهُ.
              if (host.editor() != null)
                host.editor().updateTabAfterDiskEdit(fileName, content, applied[0]);
              toast(UiStrings.format(host.activity(), fix.createdKey(), fix.createdArg()));
              host.quickFixApplied(fix, fileName);
            });
  }

  private void confirm(String fileName, Runnable onYes) {
    Activity activity = host.activity();
    if (activity == null || activity.isFinishing()) return;
    new AlertDialog.Builder(activity)
        .setTitle(text("ui_create_missing_member_title"))
        .setMessage(UiStrings.format(activity, "ui_create_missing_member_message", fileName))
        .setNegativeButton(text("ui_action_no"), null)
        .setPositiveButton(text("ui_action_yes"), (dialog, which) -> onYes.run())
        .show();
  }

  private static String displayName(String tab) {
    return tab == null ? "" : tab.substring(tab.lastIndexOf('/') + 1);
  }

  private String text(String key) {
    return UiStrings.get(host.activity(), key);
  }

  private void toast(String message) {
    if (message == null || message.isEmpty() || host.activity() == null) return;
    Toast.makeText(host.activity(), message, Toast.LENGTH_SHORT).show();
  }
}
