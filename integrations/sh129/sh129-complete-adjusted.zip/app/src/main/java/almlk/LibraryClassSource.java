package almlk;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;
import java.util.WeakHashMap;

/**
 * مصدر عرض للقراءة فقط لصنف من المكتبات المنزّلة (JAR/AAR)، يُبنى من فهرس المكتبات نفسه الذي
 * يغذّي الفحص والإكمال. فيعرض الانتقال (Go To) نسخة المكتبة التي يعتمدها المشروع بإصدارها، لا نسخة
 * مضمّنة في تطبيقنا. الأسلوب مطابق لعرض أصناف المنصة: package وimports ثم الرأس، فالحقول،
 * فالمُنشئات، فالدوال بلا أجسام. الملف باسم {@code androidx/drawerlayout/widget/DrawerLayout.class}.
 */
public final class LibraryClassSource {
  public final String text;
  public final String fileName;
  public final String simpleName;
  public final String qualifiedName;
  public final int classOffset;
  public final Map<String, Integer> methodOffsets;
  public final Map<String, Integer> fieldOffsets;

  private static final Map<AndroidApiIndex.ClassInfo, LibraryClassSource> CACHE = new WeakHashMap<>();

  private LibraryClassSource(AndroidApiIndex.ClassInfo info, String text, int classOffset,
      Map<String, Integer> methods, Map<String, Integer> fields) {
    this.text = text;
    this.qualifiedName = info.qualifiedName;
    this.simpleName = info.simpleName;
    this.fileName = fileNameOf(info);
    this.classOffset = classOffset;
    this.methodOffsets = Collections.unmodifiableMap(methods);
    this.fieldOffsets = Collections.unmodifiableMap(fields);
  }

  /** {@code a/b/Outer$Inner.class} على نهج المرجع (الأصناف الداخلية بـ $). */
  static String fileNameOf(AndroidApiIndex.ClassInfo info) {
    String pkg = info.packageName;
    String local = pkg.isEmpty() ? info.qualifiedName : info.qualifiedName.substring(pkg.length() + 1);
    return (pkg.isEmpty() ? "" : pkg.replace('.', '/') + "/") + local.replace('.', '$') + ".class";
  }

  /**
   * صنف مكتبة مرئي لاسم مكتوب (بسيط أو مؤهَّل) وفق استيرادات الملف؛ null إن كان الاسم صنف منصة
   * أو غير معروف (فيبقى لمسار المنصة).
   */
  public static AndroidApiIndex.ClassInfo libraryClass(String written, List<String> imports) {
    if (written == null || written.isEmpty() || AndroidApiIndex.libraryClassCount() == 0) return null;
    AndroidApiIndex.ClassInfo info = AndroidApiIndex.resolve(written,
        imports == null ? Collections.<String>emptyList() : imports);
    return info != null && info.library && !info.hidden ? info : null;
  }

  /** مصدر الصنف (مخزَّن ما دام فهرس المكتبات نفسه قائمًا). */
  public static LibraryClassSource of(AndroidApiIndex.ClassInfo info) {
    if (info == null || !info.library) return null;
    synchronized (CACHE) {
      LibraryClassSource cached = CACHE.get(info);
      if (cached == null) {
        cached = generate(info);
        CACHE.put(info, cached);
      }
      return cached;
    }
  }

  /** إعادة تبويب عرض بعد استعادة الجلسة: من اسم الملف {@code a/b/C.class}. */
  public static LibraryClassSource forFileName(String fileName) {
    if (fileName == null) return null;
    String path = fileName.replace('\\', '/');
    if (!path.toLowerCase(java.util.Locale.US).endsWith(".class") || AndroidApiIndex.libraryClassCount() == 0)
      return null;
    String qualified = path.substring(0, path.length() - ".class".length()).replace('/', '.').replace('$', '.');
    AndroidApiIndex.ClassInfo info = AndroidApiIndex.classByQualifiedName(qualified);
    return info != null && info.library ? of(info) : null;
  }

  /** نتيجة البحث عن عضو: مصدر الصنف المعلِن وموضع الاسم فيه. */
  public static final class MemberHit {
    public final LibraryClassSource source;
    public final int offset;
    public final boolean field;

    MemberHit(LibraryClassSource source, int offset, boolean field) {
      this.source = source;
      this.offset = offset;
      this.field = field;
    }
  }

  /**
   * أول صنف مكتبة في سلسلة الوراثة يعلن العضو (الأقرب أولًا). يعيد null حين يُعلنه صنف منصة أو لا
   * يوجد، و{@code platformOwner} يحمل حينها أول صنف منصة في السلسلة ليُكمل مسار المنصة منه.
   */
  public static MemberHit declaringMember(AndroidApiIndex.ClassInfo start, String symbol, String[] platformOwner) {
    if (start == null || symbol == null || symbol.isEmpty()) return null;
    for (AndroidApiIndex.ClassInfo type : AndroidApiIndex.hierarchy(start)) {
      if (!type.library) {
        if (platformOwner != null && platformOwner.length > 0 && platformOwner[0] == null)
          platformOwner[0] = type.qualifiedName;
        continue;
      }
      for (AndroidApiIndex.Member member : AndroidApiIndex.declaredMembers(type)) {
        if (!symbol.equals(member.name)) continue;
        LibraryClassSource source = of(type);
        boolean field = member.kind == AndroidApiIndex.Member.FIELD;
        Integer offset = field ? source.fieldOffsets.get(symbol) : source.methodOffsets.get(symbol);
        if (offset != null) return new MemberHit(source, offset, field);
      }
    }
    return null;
  }

  private static LibraryClassSource generate(AndroidApiIndex.ClassInfo info) {
    String pkg = info.packageName;
    List<AndroidApiIndex.Member> fields = new ArrayList<>();
    List<AndroidApiIndex.Member> methods = new ArrayList<>();
    for (AndroidApiIndex.Member member : AndroidApiIndex.declaredMembers(info)) {
      if (member.kind == AndroidApiIndex.Member.FIELD) fields.add(member);
      else if (member.kind == AndroidApiIndex.Member.METHOD) methods.add(member);
    }
    List<AndroidApiIndex.Member> constructors = AndroidApiIndex.constructors(info);

    TreeSet<String> imports = new TreeSet<>();
    addImport(imports, info.superName, pkg);
    for (String implemented : info.interfaces) addImport(imports, implemented, pkg);
    for (AndroidApiIndex.Member field : fields) addImport(imports, field.type, pkg);
    for (AndroidApiIndex.Member method : methods) addImport(imports, method.type, pkg);

    StringBuilder out = new StringBuilder(Math.max(2048, (fields.size() + methods.size()) * 80));
    if (!pkg.isEmpty()) out.append("package ").append(pkg).append(";\n\n");
    for (String imported : imports) out.append("import ").append(imported).append(";\n");
    if (!imports.isEmpty()) out.append('\n');
    out.append("// Library API declarations (").append(fileNameOf(info))
        .append("); implementation bodies are omitted.\n");

    boolean isInterface = info.isInterface();
    String kind = info.kind.equals("a") ? "@interface" : info.kind.equals("e") ? "enum"
        : isInterface ? "interface" : "class";
    out.append("public ");
    if (info.isNested()) out.append("static ");
    if (info.kind.equals("b")) out.append("abstract ");
    out.append(kind).append(' ');
    int classOffset = out.length();
    out.append(info.simpleName);
    if (info.typeParameters.length > 0) out.append('<').append(String.join(", ", info.typeParameters)).append('>');
    String parent = info.superName == null ? "" : info.superName;
    if (!isInterface && !info.kind.equals("e") && !parent.isEmpty() && !parent.equals("java.lang.Object"))
      out.append(" extends ").append(AndroidApiIndex.simpleTypeText(parent));
    if (info.interfaces.length > 0) {
      out.append(isInterface ? " extends " : " implements ");
      for (int i = 0; i < info.interfaces.length; i++) {
        if (i > 0) out.append(", ");
        out.append(AndroidApiIndex.simpleTypeText(info.interfaces[i]));
      }
    }
    out.append(" {\n");

    LinkedHashMap<String, Integer> fieldOffsets = new LinkedHashMap<>();
    for (AndroidApiIndex.Member field : fields) {
      out.append("    ").append(field.isProtected ? "protected " : "public ");
      if (field.isStatic) out.append("static ");
      out.append(field.displayType()).append(' ');
      fieldOffsets.putIfAbsent(field.name, out.length());
      out.append(field.name).append(";\n");
    }
    if (!fields.isEmpty() && (!constructors.isEmpty() || !methods.isEmpty())) out.append('\n');
    for (AndroidApiIndex.Member constructor : constructors) {
      out.append("    ").append(constructor.isProtected ? "protected " : "public ").append(info.simpleName)
          .append('(').append(constructor.parameters).append(") { }\n");
    }
    if (!constructors.isEmpty() && !methods.isEmpty()) out.append('\n');
    LinkedHashMap<String, Integer> methodOffsets = new LinkedHashMap<>();
    for (AndroidApiIndex.Member method : methods) {
      out.append("    ").append(method.isProtected ? "protected " : "public ");
      if (method.isStatic) out.append("static ");
      out.append(method.displayType()).append(' ');
      methodOffsets.putIfAbsent(method.name, out.length());
      out.append(method.name).append('(').append(method.parameters).append(')')
          .append(isInterface && !method.isStatic ? ";\n" : " { }\n");
    }
    out.append("}\n");
    return new LibraryClassSource(info, out.toString(), classOffset, methodOffsets, fieldOffsets);
  }

  /** استيراد نوع مؤهَّل ليس من java.lang ولا من الحزمة نفسها (الوسائط العامة والمصفوفات تُجرَّد). */
  private static void addImport(TreeSet<String> imports, String type, String pkg) {
    if (type == null || type.isEmpty()) return;
    String name = AndroidApiIndex.stripGenerics(type).replace("[]", "").replace("...", "").trim();
    int dot = name.lastIndexOf('.');
    if (dot <= 0) return;
    AndroidApiIndex.ClassInfo info = AndroidApiIndex.classByQualifiedName(name);
    String owner = info != null ? info.packageName : name.substring(0, dot);
    if (owner.equals("java.lang") || owner.equals(pkg) || owner.isEmpty()) return;
    if (info != null && info.isNested()) {
      // يُستورد الصنف الحاوي الأعلى كي يبقى Outer.Inner مقروءًا.
      String local = info.qualifiedName.substring(owner.length() + 1);
      imports.add(owner + "." + local.substring(0, local.indexOf('.') < 0 ? local.length() : local.indexOf('.')));
    } else {
      imports.add(name);
    }
  }
}
