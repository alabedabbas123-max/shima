package almlk;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * سياسةُ المستودعاتِ — طبقةٌ صافيةٌ واحدةٌ بين ما يعلنُهُ المشروعُ وما يُفتَّشُ عليهِ فعلًا.
 *
 * <p>نطاقُها: ما يكتبُهُ <b>المستخدمُ</b> في صفِّ «مستودعاتٌ إضافيةٌ» فقطْ — لا عناوينُ المشروعِ
 * نفسِهِ (تلكَ تُترَكُ كما كُتِبَتْ: قد تكونُ مرآةً خاصّةً، و`jcenter()` المجمَّدُ للقراءةِ يُجرَّبُ
 * عندَ عنوانِهِ ثمَّ يلحقُهُ Central احتياطًا أصلًا). وبذلكَ تُقبَلُ مكاتبُ الأمسِ ومكاتبُ اليومِ
 * بانبوبٍ واحدٍ وبلا مفتاحٍ: اسمٌ مستعارٌ (`jcenter`/`central`/`google`/`jitpack`) ← عنوانُهُ
 * الحقيقيُّ، `http` ← `https`، مضيفٌ ماتَ (JCenter/Bintray) ← Maven Central، مسارٌ مطلقٌ ← `file:`،
 * وكلُّ ما لا يُفهَمُ ← يُسقَطُ بدلَ أن يُجرَّبَ كلَّ مرةٍ. 
 *
 * <p>لا حالةَ هنا: القائمةُ الداخلةُ لا تُعدَّلُ، والمُخرَجُ قائمةٌ عناوينَ موثَّقةٍ بـ`/` أخيرةٍ.
 */
public final class RepositoryPolicy {

  /** Maven Central (الاسمانِ متحدانٍ: repo1 وrepo.maven). */
  public static final String MAVEN_CENTRAL = "https://repo1.maven.org/maven2/";

  /** مستودعُ Google الرسميُّ (بديلُ `maven.google.com` المقروءِ عند المرجعِ). */
  public static final String GOOGLE = "https://dl.google.com/dl/android/maven2/";

  /** JitPack — ما بقيَ حيًّا من قائمةِ القالبِ القديمِ. */
  public static final String JITPACK = "https://jitpack.io/";

  /** مفتاحُ الإعداداتِ: مستودعاتٌ إضافيةٌ يفصلُ بينَها `;` (نفسُ اصطلاحِ المرجعِ). */
  public static final String KEY_EXTRA_REPOSITORIES = "advanced_setting_extra_repositories";

  /** مستودعُ المستخدمِ المركزيُّ عند المرجعِ — يبقى احتياطًا أخيرًا. */
  public static final String KEY_LOCAL_REPOSITORIES = "user_m2repositories";

  private RepositoryPolicy() {}

  /** هل العنوانُ على مضيفٍ أُغلِقَ فعلًا؟ (Bintray/JCenter ماتا؛ و`maven.google.com` اسمٌ قديمٌ حيٌّ) */
  public static boolean isDead(String url) {
    String host = host(url);
    if (host == null) return false;
    return host.equals("jcenter.bintray.com")
        || host.endsWith(".jcenter.bintray.com")
        || host.endsWith(".bintray.com")
        || host.equals("bintray.com")
        || host.equals("dl.bintray.com")
        || host.equals("api.bintray.com")
        ;
  }

  /**
   * عنوانٌ مُستعمَلٌ بعدَ الإصلاحِ: `http` ← `https`، والمضيفُ الميتُ ← Central، والعنوانُ الفارغُ
   * ← null. لا تُختلَعُ عناوينُ لم تضِفْها السياسةِ: مُخرَجُهُ إمّا مدخلٌ مُطبَّعٌ أو Central أو null.
   */
  public static String rescue(String url) {
    String trimmed = url == null ? "" : url.trim();
    if (trimmed.isEmpty()) return null;
    String alias = alias(trimmed);
    if (alias != null) return alias;
    if (trimmed.equals("mavenLocal") || trimmed.equals("local")) return null;
    if (trimmed.startsWith("file:") || (trimmed.startsWith("/") && trimmed.length() > 1)) {
      // مسارٌ مطلقٌ أو file:-uri: لا يُقطَعُ منهُ إلّا المِخططُ نفسُهُ، فـ/sdcard/m2 ليس مِخططًا
      String path = trimmed.startsWith("file:") ? trimmed.substring(trimmed.indexOf(':') + 1) : trimmed;
      while (path.startsWith("//")) path = path.substring(1); // file:///sdcard/m2 ← /sdcard/m2
      if (!path.startsWith("/")) path = "/" + path;
      if (path.endsWith("/")) path = path.substring(0, path.length() - 1);
      return path.length() < 2 ? null : "file:" + path + "/";
    }
    if (trimmed.regionMatches(true, 0, "http://", 0, 7)) trimmed = "https://" + trimmed.substring(7);
    if (!trimmed.regionMatches(true, 0, "https://", 0, 8)) return null;
    if (isDead(trimmed)) return MAVEN_CENTRAL;
    return trimmed.endsWith("/") ? trimmed : trimmed + "/";
  }

  /** الأسماءُ التي تكتبُها المشاريعُ القديمةُ والحديثةُ على حدٍّ سواءٍ. */
  private static String alias(String token) {
    String t = token.toLowerCase(Locale.US);
    if (t.equals("jcenter") || t.equals("jcenterBintray".toLowerCase(Locale.US)) || t.equals("mavencentral")
        || t.equals("central")) return MAVEN_CENTRAL;
    if (t.equals("google") || t.equals("dlgoogle") || t.equals("maven.google.com")) return GOOGLE;
    if (t.equals("jitpack")) return JITPACK;
    return null;
  }

  /** هويةُ المقارنةِ: مضيفٌ صغيرٌ، بلا `/` أخيرةٍ، وبلا تفرقةٍ بينَ اسمَيِ Central. */
  public static String identity(String url) {
    String rescued = rescue(url);
    if (rescued == null) return "";
    String s = rescued.toLowerCase(Locale.US);
    int scheme = s.indexOf("://");
    if (scheme < 0) return strip(s);
    String host = s.substring(scheme + 3);
    int slash = host.indexOf('/');
    String path = slash < 0 ? "" : host.substring(slash);
    host = slash < 0 ? host : host.substring(0, slash);
    if (host.equals("repo.maven.apache.org") || host.equals("repo1.maven.org")) return "maven-central";
    if (host.equals("maven.google.com") && (path.isEmpty() || path.equals("/"))) {
      return "dl.google.com/dl/android/maven2"; // maven.google.com اسمٌ قديمٌ للمرفأِ نفسِهِ، والهُويّةُ مضيفٌ+مسارٌ
    }
    return strip(host + path);
  }

  /**
   * الترتيبُ النهائيُّ: معلَنُ المشروعِ ← إضافاتُ المستخدمِ من الإعداداتِ ← الاحتياطياتُ المدمَجةُ،
   * وكلُّها مُصلَحةٌ، بلا تكرارٍ (الأولُ يفوزُ)، وبلا مستودعٍ ميِّتٍ يبقى وحدَهُ في القائمةِ.
   */
  public static List<String> order(List<String> declared, List<String> extras, List<String> fallbacks) {
    List<String> out = new ArrayList<>();
    Set<String> seen = new LinkedHashSet<>();
    append(out, seen, declared);
    append(out, seen, extras);
    append(out, seen, fallbacks);
    return out;
  }

  /** تفصيلُ قائمةٍ بفاصلِ `;` (ويُقبَلُ `,` تسهيلًا): مسافاتٌ مهملةٌ، وسلاسلُ فارغةٌ مُسقطةٌ. */
  public static List<String> split(String value) {
    List<String> out = new ArrayList<>();
    if (value == null) return out;
    for (String part : value.split("[;,]")) {
      String t = part.trim();
      if (!t.isEmpty()) out.add(t);
    }
    return out;
  }

  private static void append(List<String> out, Set<String> seen, List<String> in) {
    if (in == null) return;
    for (String raw : in) {
      String rescued = rescue(raw);
      if (rescued == null) continue;
      if (seen.add(identity(rescued))) out.add(rescued);
    }
  }

  private static String host(String url) {
    if (url == null) return null;
    int scheme = url.indexOf("://");
    if (scheme < 0) return null;
    String rest = url.substring(scheme + 3);
    int end = rest.length();
    for (int i = 0; i < rest.length(); i++) {
      char c = rest.charAt(i);
      if (c == '/' || c == '?' || c == '#') {
        end = i;
        break;
      }
    }
    String h = rest.substring(0, end);
    int at = h.lastIndexOf('@');
    if (at >= 0) h = h.substring(at + 1);
    int colon = h.indexOf(':');
    if (colon > 0) h = h.substring(0, colon);
    return h.toLowerCase(Locale.US);
  }

  private static String strip(String s) {
    return s.endsWith("/") ? s.substring(0, s.length() - 1) : s;
  }
}
