package almlk;

/**
 * جدولُ إزاحاتِ الأسطرِ للمستندِ كلِّهِ — مرةً واحدةً لكلِّ إصدارٍ من النصِّ، وقراءةٌ بـ‏O(1) لكلِّ
 * قفزةٍ بعدها.
 *
 * <p><b>لماذا؟</b> كانتِ القفزةُ من لوحِ الأخطاءِ تَفعَلُ ما يَفعَلُهُ بحثٌ في الملفِ كلِّهِ:
 * {@code code.getText().toString()} ثمَّ عَدُّ {@code '\n'} سطرًا سطرًا حتى السطرِ المطلوبِ
 * (‏{@code AIDEEditorPager.jumpToRange} قبلَ هذهِ الجولةِ). المرجعُ لا يَفعَلُ ذلكَ: القفزةُ تَقرَأُ
 * من جداولِ الفواصلِ التي مُلِئَت لحظةَ رَدِّ الخلفيةِ (ورقةُ هذهِ الجولةِ §١٫٤) — فصارَ عندَنا
 * جدولٌ واحدٌ مبنيٌّ من نفسِ المستندِ، يُعادُ بناؤُهُ فقط إذا تبدَّلَ إصدارُهُ، ويَقرَأُ منهُ كلُّ
 * مُستَهلِكٍ (القفزةُ، والتوسيطُ، وتحديدُ المَدَى) بلا نَسخٍ ولا عَدٍّ.
 *
 * <p>نقاءٌ تامٌّ: لا {@code android.*} ولا خيطَ؛ البناءَ يَقرَأُ أطوالَ السطورِ من
 * {@link LineDocument} تحتَ قفلِهِ، والفواصلُ حسابيَّةٌ (سطرٌ أخيرٌ بلا {@code '\n'} كما في
 * {@link LineDocument#toString()}).
 */
public final class LineOffsetTable {

  private final int[] lineStarts;
  private final int lineCount;
  private final int totalLength;
  private final long documentVersion;

  private LineOffsetTable(
      int[] lineStarts, int lineCount, int totalLength, long documentVersion) {
    this.lineStarts = lineStarts;
    this.lineCount = lineCount;
    this.totalLength = totalLength;
    this.documentVersion = documentVersion;
  }

  /** سطرًا سطرًا مرةً واحدةً: لا عَدَّ لكلِّ نقرةٍ بعدَ اليومَ. */
  public static LineOffsetTable build(LineDocument document) {
    if (document == null) return new LineOffsetTable(new int[] {0}, 0, 0, -1L);
    int lines = Math.max(0, document.lineCount());
    int[] starts = new int[lines + 1];
    int offset = 0;
    for (int i = 0; i < lines; i++) {
      starts[i] = offset;
      offset += document.lineLength(i);
      if (i + 1 < lines) offset++; // الفاصلُ «\n» بينَ سطرَينِ، لا بعدَ الأخيرِ
    }
    starts[lines] = offset;
    return new LineOffsetTable(starts, lines, offset, document.version());
  }

  /** هل هذا الجدولُ للإصدارِ الجاري؟ (بهُ يقرِّرُ المُحرِّرُ أن يُعيدَ البناءَ أو يَكفَّ) */
  public boolean isFreshFor(long version) {
    return documentVersion == version;
  }

  public long documentVersion() {
    return documentVersion;
  }

  public int lineCount() {
    return lineCount;
  }

  /** طولُ المستندِ بالأحرفِ — للقصِّ قبلَ استعمالِ إزاحةٍ قديمةٍ بعدَ حذفٍ مفاجئٍ. */
  public int totalLength() {
    return totalLength;
  }

  /** إزاحةُ بدايةِ سطرٍ (‏0‑based)؛ القيمُ خارجَ النطاقِ تُثبَّتُ لا تُرفَضُ. */
  public int startOf(int line) {
    if (lineCount == 0) return 0;
    int clamped = Math.max(0, Math.min(line, lineCount - 1));
    return lineStarts[clamped];
  }

  /** إزاحةُ ما بعدَ آخرِ حرفٍ في السطرِ (بلا «‏\n») — سقفُ كلِّ عمودٍ في هذا السطرِ. */
  public int endOf(int line) {
    if (lineCount == 0) return 0;
    int clamped = Math.max(0, Math.min(line, lineCount - 1));
    int boundary = lineStarts[clamped + 1];
    return clamped + 1 < lineCount ? Math.max(lineStarts[clamped], boundary - 1) : boundary;
  }

  /** إزاحةُ (سطرٍ، عمودٍ) بعمودٍ ‏0‑based مقصوصٍ إلى نهايةِ السطرِ — بلا استثناءٍ ولا صرخةٍ. */
  public int offsetFor(int line, int column) {
    int start = startOf(line);
    int end = endOf(line);
    if (column <= 0) return start;
    return Math.min(start + column, end);
  }

  /** سطرُ إزاحةٍ ببحثٍ ثنائيٍّ على الجدولِ نفسِهِ: O(log lines) لا O(lines). */
  public int lineFor(int offset) {
    if (lineCount == 0) return 0;
    int target = Math.max(0, Math.min(offset, totalLength));
    int lo = 0;
    int hi = lineCount - 1;
    while (lo < hi) {
      int mid = (lo + hi + 1) >>> 1;
      if (lineStarts[mid] <= target) lo = mid;
      else hi = mid - 1;
    }
    return lo;
  }

  /** عددُ الإزاحاتِ التي يَحفَظُها الجدولُ — للبوَّابةِ: سطرٌ واحدٌ زائدٌ يعني بناءً خاطئًا. */
  public int storedRows() {
    return lineStarts.length;
  }
}
