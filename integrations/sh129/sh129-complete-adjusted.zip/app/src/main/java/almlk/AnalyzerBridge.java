package almlk;

import android.content.Context;
import com.shima.analyzer.AnalysisHandle;
import com.shima.analyzer.CodeAnalyzer;
import com.shima.analyzer.core.AnalysisConfig;
import com.shima.analyzer.core.AnalysisResult;
import com.shima.analyzer.core.Language;
import com.shima.analyzer.editor.EditorAdapter;
import java.util.ArrayList;
import java.util.List;

/**
 * جِسْرُ المُستَهلِكِ لِوَحدَةِ الفَحصِ وَالرَّسمِ — ‏1.0.198 (ج٤٧).
 *
 * <p>سَببُ وُجُودِهِ: وَجهُ المَكتَبَةِ يَطلُبُ (١) نَصًّا آخِرًا عِندَ الطَّلَبِ، (٢) إِخطَارًا
 * بِالتَّغَيُّرِ، (٣) خَيطَ الوَاجِهَةِ لِـ{@code start}/{@code requestAnalysis}/{@code close} —
 * وَكُلُّ ذلِكَ عِندَنَا فِي {@code AIDEEditorPager}، لَا فِي {@code EditText} صَافٍ. فَهذَا
 * الصِّنفُ يَحَمِلُ وَجهَ المَكتَبَةِ (‏{@link EditorAdapter}‏) وَيَبقَى المُحرِّرُ بِلَا عِلْمٍ بِهِ:
 * لَا سَطْرَ فِي وَجهَةِ المُحرِّرِ يَسأَلُ المَكتَبَةَ شَيئًا، وَلَا قُفلَ يَنتَظِرُهَا، وَلَا كَتَابَةَ
 * عَلَى النَّصِّ مِن قَبلِهَا — الكِتَابَةُ كُلُّهَا تَجرِي مِن صُفوفِ {@link almlk.QuickFix}
 * عَلى مَسَارِ الإِصلاحِ الوَاحدِ عِندَنَا.
 *
 * <p><b>عَهدُ الخَيطِ</b>: صِفْرُ عَمَلٍ عَلى خَيطِ العَمَلِ. المَكتَبَةُ تَنشُرُ عَلَى خَيطِهَا
 * (نَحْوٌ وَفَحصٌ فِي «‏shima-analyzer‏» ذِي الأَولَوِيَّةِ الخَافِضَةِ)، وَتُرسِلُ النَّتِيجَةَ
 * إِلَى الوَاجِهَةِ؛ وَالحَدُّ هُنَا: حَجمُ مُسَوَّدَةٍ وَاحدَةٍ (‏{@code maxDocumentChars}‏) وَزَمَنٌ
 * قَطَعٌ (‏{@code timeoutMillis}‏) — فَإن جَاوَزَهُمَا فَيلٌ يَر جَعُ {@code PARTIAL}، وَتَقُولُ
 * الوَحدَةُ ذلِكَ عَلَى صَفٍّ، وَلَا تَدَّعِي سَلَامَةً.
 *
 * <p><b>سَقَطَ الجِذرُ؟</b>: يَنبَغِي أن يُعلَنَ. أَوَّلُ لَمسَةٍ لِـ{@code NativeBridge} تَرمِي
 * {@link LinkageError} إِنَّ لَم يُوجَدِ ‏{@code libshima_analyzer.so} لِلمِعمَارِيَّةِ؛ نَكتَشِفُ
 * ذلِكَ مَرَّةً وَاحدَةً (بِلَا إِعادَةٍ عِندَ كُلِّ حَرفٍ) وَنَنشُرُ سَبَبَهُ صَفًّا، ثُمَّ نَسكُتُ
 * عَنِ المَكتَبَةِ دُونَ أن نُسكِتَ عَنِ السَّبَبِ.
 */
public final class AnalyzerBridge {

  /** صَاحِبُ النَّصِّ الحَيِّ: وَجهَةُ المُحرِّرِ، فَلا نَسخَ عَلَى القُرصِ عِندَنَا. */
  public interface TextSource {
    /** نَصُّ التبويبِ، أَو {@code null} إِنَّ لَم يُوجَد — تُترَكُ الصُّفوفُ كَمَا هِيَ. */
    String textOf(String reference);
  }

  /** طَلَبُ إِعادَةِ النَّشرِ (عِندَ المُضيفِ: {@code publishProjectDiagnostics(false)}). */
  public interface Publisher {
    void publish();
  }

  /**
   * مَا يَعرِفُهُ المُضيفُ عَنِ المِشرُوعِ: مُجلَّدُ الوَحدَةِ (‏app/‏) وَوَصفُ حِزمَتِهَا. الجَولَةُ
   * الجَمعِيَّةُ لَا تَطلُبُ أَكثَرَ مِن ذلِكَ — لَا Gradle، لَا فَتحًا لِمانيفست، لَا قَيدَ بِنَاءٍ:
   * كُلَّمَا قَلَّ مَا يَعرِفُهُ المُساعِدُ قَلَّ مَا يَستَطِيعُ أن يُخطِئَ فِيهِ.
   */
  public interface ProjectHost {
    /** مُجلَّدُ الوَحدَةِ، أو {@code null} إِنَّ لَم يُفتَتَحْ مِشرُوعٌ (فَيَكتَفِي الجِسْرُ بِالتَّبويِبِ). */
    java.io.File moduleDir();

    /** ‏namespace‏/‏applicationId‏؛ قَد يَكونُ فَارِغًا أَو غَيرَ صَالِحٍ — نُتجَاهَلُهُ وَلَا نَرمِيهِ. */
    String namespace();

    /** Exact artifacts selected by the host resolver for the active project/variant. */
    default List<java.io.File> classpath() { return java.util.Collections.emptyList(); }

    /** True only after dependency resolution for this exact project/variant has completed. */
    default boolean classpathComplete() { return false; }
  }

  private final Context appContext;
  private final TextSource source;
  private final Publisher publisher;
  private final List<Runnable> changeListeners = new ArrayList<>();

  /** أَقلُّ فَاصِلَةٍ بَينَ جَولَتَينِ جَمعِيَّتَينِ: المِحرِّرُ يُكتَبُ، وَالعَقلُ الجَمعِيُّ يَرتَاحُ. */
  public static final long PROJECT_PASS_INTERVAL_MS = 2000L;
  /**
   * مِرجَعُ صَفِّ «الفَحصُ الجَمعِيُّ نَاقِصٌ»: لَيسَ مِلَفًّا فَلا يُنسَبُ إِلَى سَطْرٍ وَلَا يُلوَّنُ،
   * وَلكِنَّهُ يَظهَرُ فِي اللَّوحَةِ — فَالتَّسمِيَةُ تُغني عَنِ الكِتمَانِ.
   */
  public static final String PROJECT_NOTE_REFERENCE = "shima:workspace";

  private ProjectHost projectHost;
  private java.util.concurrent.ExecutorService projectWorker;
  private final android.os.Handler projectMain =
      new android.os.Handler(android.os.Looper.getMainLooper());
  private final Runnable projectKick =
      new Runnable() {
        @Override public void run() {
          startProjectPass();
        }
      };
  private final List<String> projectWritten = new ArrayList<>();
  private volatile boolean projectRunning;
  private volatile boolean projectQueued;
  private volatile long projectLastStart;
  private volatile long projectRevision;
  private volatile long classpathRevision;
  private volatile com.shima.analyzer.core.Analyzer activeProjectAnalyzer;
  // The following cache is owned exclusively by projectWorker; the immutable symbol list is also read on main.
  private com.shima.analyzer.core.Analyzer cachedProjectAnalyzer;
  private AnalysisConfig cachedProjectConfig;
  private String cachedClasspathKey = "";
  private long cachedClasspathRevision = -1;
  private com.shima.analyzer.dependencies.ClasspathSymbols.Result cachedClasspath;
  private volatile List<String> editorClasspathSymbols = java.util.Collections.emptyList();
  private String observedText;

  private AnalysisHandle handle;
  private String reference;
  private String fileName;
  private boolean probed;
  private boolean nativeReady;
  private String nativeReason = "";

  /**
   * الحِرسُ ضِدَّ الدَّورَةِ: نَشرُنَا يُؤَدِّي بِالحَامِلِ إِلَى رَسمِ الصَّفحَةِ، وَالرَّسمُ
   * يُطلِعُنَا عَلَى الوَجهَةِ (‏{@code onFocus}‏) — فَإِنۡ لَبَّينَا ذٰلِكَ الإِشرَاقَ عُدۡنَا
   * نَنشُرُ، فَدَورَةٌ لَا نِهَايَةَ لَهَا سَقَطَتۡ عَلَيهَا الوَاجِهَةُ
   * بِ‏{@link StackOverflowError} قَبلَ أن تَظهَرَ تَاجاتُ المَشارِيعِ (ج٥٤، عَلى الجِهَازِ).
   * الحَارِسُ خَيطٌ لَا عَلَامَةٌ: نَتَائِجُ المَكتَبَةِ تَأتِي مِن خَيطِهَا، فَحَظرُ عَلَامَةٍ
   * عَامَّةٍ كَانَ يَسُدُّ طَرِيقَ النَّتَائِجِ بَعۡدَ كُلِّ نَشرٍ.
   */
  private Thread publishOwner;
  /** طَلَبَاتٌ جَاءَتۡ أَثۡنَاءَ الرَّسمِ: نَظرَةٌ وَاحدَةٌ بَعۡدَ أن تَسۡتَقِرَّ الصَّفحَةُ. */
  private boolean publishAgain;

  public AnalyzerBridge(Context context, TextSource textSource, Publisher publish) {
    this.appContext = context == null ? null : context.getApplicationContext();
    this.source = textSource;
    this.publisher = publish;
  }

  /** هَلِ الجِذرُ هُنَا؟ مَرَّةً وَاحدَةً، وَبِالحُكمِ عَلَى نَفسِهِ لَا عَلى ظَنِّنَا. */
  private boolean nativeAvailable() {
    if (probed) return nativeReady;
    probed = true;
    try {
      Class.forName("com.shima.analyzer.core.NativeBridge", true, NativeBridgeLoader.loader());
      nativeReady = true;
    } catch (Throwable failure) {
      nativeReady = false;
      nativeReason = failure.getClass().getSimpleName()
          + (failure.getMessage() == null ? "" : ": " + failure.getMessage());
    }
    return nativeReady;
  }

  /** التَّبويِبُ الجَارِي هُوَ المَفحوصُ وَحدَهُ؛ إِنَّ تَغَيَّرَتِ الوَجهَةُ أُغلِقَ الكُلُّ وَأُعيِدَ. */
  public void focus(String tabFileName, String tabReference) {
    if (echoing()) return; // صَدَىٰ رَسمٍ: لَا فَتحَ لِوَحدَةٍ وَلَا إِغلَاقًا مِن دَاخِلِهِ
    String next = tabReference == null ? "" : tabReference;
    if (!isSupported(next)) {
      detachEditor(false);
      return;
    }
    if (handle != null && next.equals(reference)) {
      requestAnalysis();
      return;
    }
    detachEditor(false);
    // Keep ownership of the unavailable row too, so release/switch clears it.
    fileName = tabFileName;
    reference = next;
    observedText = text();
    attachActive();
  }

  private void attachActive() {
    final String next = reference, tabFileName = fileName;
    final long contextGeneration = classpathRevision;
    final boolean contextComplete = projectHost != null && projectHost.classpathComplete();
    if (next == null) return;
    if (!nativeAvailable()) {
      AnalyzerErrorUnit.putUnavailable(next, tabFileName, text(), new IllegalStateException(nativeReason));
      notifyPublisher();
      return;
    }
    try {
      handle = CodeAnalyzer.with(appContext)
          .attachTo(new BridgeAdapter())
          .sourceId(next)
          .language(languageOf(next))
          .config(editorConfig(text()))
          .debounceMillis(250)
          .onResult(new CodeAnalyzer.ResultListener() {
            @Override public void onResult(AnalysisResult result) {
              if (contextGeneration != classpathRevision || !next.equals(reference)
                  || result == null || !next.equals(result.getSourceId())) return;
              AnalyzerErrorUnit.put(reference, fileName, text(), result, contextComplete);
              notifyPublisher();
            }
          })
          .onError(new CodeAnalyzer.ErrorListener() {
            @Override public void onError(Throwable error) {
              if (contextGeneration != classpathRevision || !next.equals(reference)) return;
              AnalyzerErrorUnit.putUnavailable(reference, fileName, text(), error);
              notifyPublisher();
            }
          })
          .start();
    } catch (RuntimeException | LinkageError failure) {
      handle = null;
      nativeReady = false;
      nativeReason = failure.getClass().getSimpleName()
          + (failure.getMessage() == null ? "" : ": " + failure.getMessage());
      AnalyzerErrorUnit.putUnavailable(next, tabFileName, text(), failure);
      notifyPublisher();
    }
  }

  /**
   * إِشرَاقُ التبويبِ وَتَغَيُّرُهُ عَلى سَبيلٍ وَاحدٍ: إِنَّ تَغَيَّرَتِ الوَجهَةُ أُغلِقَ مَا قَبلَهَا
   * وَفُتِحَ الجَدِيدُ، وَإِلَّا جُدوِلَ الفَحصُ بِتَرَدُّدِ المَكتَبَةِ — لا فَحصَ مُتَزَامِنًا مَعَ
   * كُلِّ حَرفٍ، وَلَا قَرَارًا عَلى نَصٍّ قَديمٍ.
   */
  public void onEditorSignal(String tabFileName, String tabReference) {
    if (echoing()) return; // الحَامِلُ يُعلِمُنَا بِمَا رَسَمهُ نَشرُنَا — فَذَاكَ إِعدَادٌ لَا إِشرَاقٌ
    if (tabReference == null || !tabReference.equals(reference)) {
      focus(tabFileName, tabReference);
      return;
    }
    textChanged();
  }

  /** المُحرِّرُ قَال: تَغَيَّرَ النَّصُّ. لَا قِرَاءَةَ هُنَا وَلَا فَحصًا — إِخطَارٌ فَقط. */
  public void textChanged() {
    if (echoing()) return; // الكِتَابَةُ أَثۡنَاءَ النَّشرِ لَا تُعِيدُ الفَحصَ
    markEditorEdited(fileName, reference);
    for (Runnable listener : new ArrayList<>(changeListeners)) listener.run();
    if (handle == null && reference != null && nativeAvailable()) focus(fileName, reference);
  }

  /** Main-thread edit notification, before queued results have a chance to publish. */
  public void markEditorEdited(String name, String ref) {
    if (ref != null && ref.equals(reference)) {
      String now = text();
      if (now != null && !now.equals(observedText)) {
        if (observedText != null) AnalyzerErrorUnit.markPending(ref, observedText, now);
        observedText = now;
        invalidateProjectPass();
      } else if (now == null) {
        invalidateProjectPass();
      }
    } else {
      invalidateProjectPass();
    }
  }

  private void invalidateProjectPass() {
    projectRevision++;
    if (projectRunning) projectQueued = true;
    com.shima.analyzer.core.Analyzer running = activeProjectAnalyzer;
    if (running != null) running.cancel();
  }

  /** Call when files changed on disk outside the focused buffer, e.g. a save. */
  public void projectFilesChanged() { invalidateProjectPass(); requestProjectPass(); }

  /** Resolved artifacts/platform changed. Re-index in the background and then refresh the editor. */
  public void projectContextChanged() {
    classpathRevision++;
    invalidateProjectPass();
    editorClasspathSymbols = java.util.Collections.emptyList();
    if (reference != null) AnalyzerErrorUnit.markEditorPending(reference);
    for (String previous : projectWritten) AnalyzerErrorUnit.markProjectPending(previous);
    refreshEditorContext();
    notifyPublisher();
    requestProjectPass();
  }

  private void refreshEditorContext() {
    if (reference == null || handle == null) return;
    try { handle.close(); } catch (RuntimeException ignored) { }
    handle = null;
    changeListeners.clear();
    attachActive();
  }

  /** طَلَبُ فَحصٍ مُبَاشِرٌ (بَعدَ الحِفظِ قَبلَ البِنَاءِ: النَّافِذَةُ تَقرَأُ آخِرَ مَا كُتِبَ). */
  public void requestAnalysis() {
    if (handle != null) handle.requestAnalysis();
  }

  /** بِذلِكَ يَعرِفُ المَمَرُّ الجَمعِيُّ أَينَ يَمشِي؛ {@code null} تُلغِي الجَمعَ وَتُبقِي فَحصَ التبويبِ. */
  public void setProjectHost(ProjectHost host) {
    invalidateProjectPass();
    classpathRevision++;
    projectHost = host;
    editorClasspathSymbols = java.util.Collections.emptyList();
    if (reference != null) AnalyzerErrorUnit.markEditorPending(reference);
    refreshEditorContext();
    if (host == null) {
      projectMain.removeCallbacks(projectKick);
      clearProjectRows();
    }
  }

  /**
   * جَدوَلَةُ مَمَرٍّ جَمعِيٍّ: إِنْ كَانَ وَاحِدٌ جَارِيًا فَنَضعُ عَلَمَ قُفلٍ وَاحدًا (لَا طَابُورًا
   * يَنمُو مَعَ كُلِّ حِفظٍ)، وَإِن مَضَى عَلَيهِ زَمَنٌ قَصيرٌ نُؤَجِّلُ بِمُهَلَةِ الوَاجِهَةِ لَا
   * بِنَومٍ — فَخَيطُ العَمَلِ لَا يَنَامُ عِندَنَا، وَلَا يَقرَأُ القُرصَ أَصلاً.
   */
  public void requestProjectPass() {
    if (projectHost == null || !nativeAvailable()) return;
    if (projectRunning) {
      projectQueued = true;
      return;
    }
    long since = android.os.SystemClock.uptimeMillis() - projectLastStart;
    if (since < PROJECT_PASS_INTERVAL_MS) {
      projectMain.removeCallbacks(projectKick);
      projectMain.postDelayed(projectKick, PROJECT_PASS_INTERVAL_MS - Math.max(0L, since));
      return;
    }
    startProjectPass();
  }

  private void startProjectPass() {
    if (projectRunning || projectHost == null || !nativeAvailable()) return;
    final java.io.File module = projectHost.moduleDir();
    if (module == null || !module.isDirectory()) return;
    if (projectWorker == null) {
      projectWorker = java.util.concurrent.Executors.newSingleThreadExecutor(task -> {
        Thread worker = new Thread(task, "shima-project");
        worker.setDaemon(true); worker.setPriority(Thread.MIN_PRIORITY); return worker;
      });
    }
    final String focusRef = reference, focusText = text();
    final boolean classpathComplete = projectHost.classpathComplete();
    final String namespace = classpathComplete ? projectHost.namespace() : null;
    final ProjectPlatform platform = classpathComplete ? ProjectPlatform.current() : ProjectPlatform.unknown();
    final long generation = projectRevision, dependencyGeneration = classpathRevision;
    List<java.io.File> supplied = classpathComplete ? projectHost.classpath() : java.util.Collections.emptyList();
    final List<java.io.File> classpath = supplied == null ? java.util.Collections.emptyList()
        : new ArrayList<>(new java.util.LinkedHashSet<>(supplied));
    projectRunning = true;
    projectLastStart = android.os.SystemClock.uptimeMillis();
    try {
      projectWorker.submit(() -> runProjectPass(module, focusRef, focusText, namespace,
          platform, classpath, classpathComplete, generation, dependencyGeneration));
    } catch (RuntimeException rejection) {
      projectRunning = false;
      projectQueued = false;
    }
  }

  private static final int MAX_PROJECT_ROWS = 25_000;
  private static final class PassOutput {
    final java.util.LinkedHashMap<String, List<AnalyzerErrorUnit.Row>> rows = new java.util.LinkedHashMap<>();
    final java.util.LinkedHashSet<String> unreadable = new java.util.LinkedHashSet<>();
    final java.util.LinkedHashMap<String, List<String>> partial = new java.util.LinkedHashMap<>();
    int rowCount, droppedRows, readDrops, feedSkipped;
    boolean resourceIncomplete, projectIncomplete, enumerationIncomplete, failed;
    String note;
    List<String> symbols = java.util.Collections.emptyList();
  }

  private boolean current(long generation) { return generation == projectRevision; }

  /** Collect on the worker, publish atomically on main only if its generation is still current. */
  private void runProjectPass(java.io.File module, String focusRef, String focusText, String namespace,
      ProjectPlatform platform, List<java.io.File> classpath, boolean classpathComplete,
      long generation, long dependencyGeneration) {
    PassOutput out = new PassOutput();
    try {
      StringBuilder signature = new StringBuilder();
      for (java.io.File file : classpath) if (file != null)
        signature.append(file.getAbsolutePath()).append(':').append(file.length()).append(':')
            .append(file.lastModified()).append('\n');
      String key = signature.toString();
      if (cachedClasspath == null || cachedClasspathRevision != dependencyGeneration || !cachedClasspathKey.equals(key)) {
        cachedClasspath = com.shima.analyzer.dependencies.ClasspathSymbols.scan(classpath);
        cachedClasspathKey = key; cachedClasspathRevision = dependencyGeneration;
      }
      out.symbols = cachedClasspath.getSymbols();
      if (!classpathComplete) out.note = appendSentence(out.note,
          "لم يكتمل حل اعتمادات المشروع/المتغير؛ توقفت الأحكام التي تعتمد على الغياب");
      if (!cachedClasspath.isComplete())
        out.note = appendSentence(out.note, "تعذرت فهرسة بعض ملفات الاعتمادات ("
            + cachedClasspath.getIssues().size() + ")؛ اقتراحات الاستيراد محدودة");
      AnalyzerWorkspacePlan.BatchPlan plan = AnalyzerWorkspacePlan.batches(module);
      for (AnalyzerWorkspacePlan.Entry entry : plan.oversized) out.unreadable.add(entry.reference(module));
      if (plan.skippedTooLarge > 0)
        out.note = appendSentence(out.note, plan.skippedTooLarge + " ملفات تجاوزت حد حجم الملف ("
            + AnalyzerWorkspacePlan.MAX_FILE_CHARS + " حرف)");
      if (plan.skippedDirectories > 0) {
        out.enumerationIncomplete = true;
        out.note = appendSentence(out.note,
            "تعذر مسح " + plan.skippedDirectories + " مجلدات أو روابط خارج المشروع");
      }
      boolean batched = plan.batches.size() > 1;
      if (batched && cachedProjectAnalyzer != null) {
        cachedProjectAnalyzer.close(); cachedProjectAnalyzer = null; cachedProjectConfig = null;
      }
      if (batched) out.note = appendSentence(out.note,
          "المشروع فُحص في " + plan.batches.size() + " دفعات؛ بعض الفحوص العابرة للملفات متوقفة لعدم اكتمال الفهرس الموحد");
      boolean liveHandled = false;
      for (AnalyzerWorkspacePlan.Plan batch : plan.batches) {
        if (!current(generation)) break;
        java.util.HashMap<String, String> texts = new java.util.HashMap<>(), resourceTexts = new java.util.HashMap<>();
        ArrayList<com.shima.analyzer.core.SourceFile> files = new ArrayList<>(), otherXml = new ArrayList<>();
        ArrayList<com.shima.analyzer.core.ResourceFile> resources = new ArrayList<>();
        for (AnalyzerWorkspacePlan.Entry entry : batch.sources) {
          String id = entry.reference(module);
          String text;
          if (id.equals(focusRef) && focusText != null) { text = focusText; liveHandled = true; }
          else {
            AnalyzerWorkspacePlan.Read read = AnalyzerWorkspacePlan.read(module, entry);
            if (!read.usable()) { out.readDrops++; out.unreadable.add(id); continue; }
            text = read.text;
          }
          if (text.length() > AnalyzerWorkspacePlan.MAX_FILE_CHARS) { out.readDrops++; out.unreadable.add(id); continue; }
          files.add(new com.shima.analyzer.core.SourceFile(id, kindOf(entry.kind), text));
          texts.put(id, text);
        }
        for (AnalyzerWorkspacePlan.Entry entry : batch.resources) {
          String id = entry.reference(module);
          if (entry.kind == AnalyzerWorkspacePlan.Kind.RESOURCE) {
            resources.add(new com.shima.analyzer.core.ResourceFile(entry.relativePath, null));
            continue;
          }
          String text;
          if (id.equals(focusRef) && focusText != null) { text = focusText; liveHandled = true; }
          else {
            AnalyzerWorkspacePlan.Read read = AnalyzerWorkspacePlan.read(module, entry);
            if (!read.usable()) { out.readDrops++; out.unreadable.add(id); continue; }
            text = read.text;
          }
          if (text.length() > AnalyzerWorkspacePlan.MAX_FILE_CHARS) { out.readDrops++; out.unreadable.add(id); continue; }
          if (isAndroidResource(entry.relativePath)) {
            resources.add(new com.shima.analyzer.core.ResourceFile(entry.relativePath, text));
            resourceTexts.put(entry.relativePath, text);
          } else {
            // Manifest and other XML are documents, not res/<type>/ resource declarations.
            otherXml.add(new com.shima.analyzer.core.SourceFile(id, Language.XML, text));
            texts.put(id, text);
          }
        }
        com.shima.analyzer.core.WorkspaceSnapshot.Builder builder =
            com.shima.analyzer.core.WorkspaceSnapshot.builder().resourceIndexComplete(false)
                .projectIndexComplete(classpathComplete && cachedClasspath.isComplete() && !batched
                    && plan.skippedTooLarge == 0 && plan.skippedDirectories == 0 && out.readDrops == 0);
        if (namespace != null && namespace.matches("[A-Za-z_$][A-Za-z0-9_$]*(?:\\.[A-Za-z_$][A-Za-z0-9_$]*)*"))
          builder.namespace(namespace);
        if (batch.idsRelativePath != null && batch.idsRelativePath.matches("(?:[A-Za-z0-9_.-]+/)*res/values/ids\\.xml"))
          builder.idsFile(batch.idsRelativePath);
        for (com.shima.analyzer.core.SourceFile file : files) builder.addSource(file);
        for (com.shima.analyzer.core.ResourceFile file : resources) builder.addResource(file);
        ArrayList<String> feed = new ArrayList<>(texts.values()); feed.addAll(resourceTexts.values());
        FedConfig fed = projectConfig(feed, platform, out.symbols);
        out.feedSkipped += fed.skipped;
        com.shima.analyzer.core.Analyzer analyzer;
        boolean reusable = !batched;
        if (reusable) {
          if (cachedProjectAnalyzer == null || !fed.config.equals(cachedProjectConfig)) {
            if (cachedProjectAnalyzer != null) cachedProjectAnalyzer.close();
            cachedProjectAnalyzer = new com.shima.analyzer.core.Analyzer(fed.config);
            cachedProjectConfig = fed.config;
          }
          analyzer = cachedProjectAnalyzer;
        } else analyzer = new com.shima.analyzer.core.Analyzer(fed.config);
        try {
          activeProjectAnalyzer = analyzer;
          if (!current(generation)) break;
          com.shima.analyzer.core.WorkspaceResult result = analyzer.analyzeWorkspace(builder.build());
          if (!current(generation)) break;
          for (java.util.Map.Entry<String, AnalysisResult> one : result.getSources().entrySet())
            stage(out, one.getKey(), texts.get(one.getKey()), one.getValue());
          for (java.util.Map.Entry<String, AnalysisResult> one : result.getResources().entrySet())
            stage(out, new java.io.File(module, one.getKey()).getAbsolutePath(), resourceTexts.get(one.getKey()), one.getValue());
          for (com.shima.analyzer.core.SourceFile xml : otherXml) {
            if (!current(generation)) break;
            stage(out, xml.getId(), xml.getText(), analyzer.analyze(xml));
          }
        } finally {
          activeProjectAnalyzer = null;
          if (!reusable) analyzer.close();
        }
      }
      // An unsaved new file may not yet be on disk. The focused editor still analyzes it independently;
      // do not inject it into every batch and overflow a project's budget.
      if (focusRef != null && focusText != null && !liveHandled && isSupported(focusRef))
        out.note = appendSentence(out.note, "الملف النشط غير موجود في قائمة القرص؛ فحصه الحي مستقل عن جولة المشروع");
      if (out.resourceIncomplete) out.note = appendSentence(out.note,
          "فهرس الموارد غير مكتمل للمتغير والاعتمادات؛ لم يُحكم بغياب الموارد غير المعروفة");
      if (out.projectIncomplete && !batched) out.note = appendSentence(out.note,
          "فهرس أصناف المشروع غير مكتمل؛ تعطلت بعض الفحوص التي تعتمد على غياب التعريفات");
      if (out.readDrops > 0) out.note = appendSentence(out.note, "تعذرت قراءة أو فحص " + out.readDrops + " ملفات");
      if (out.droppedRows > 0) out.note = appendSentence(out.note,
          "حُدّد تخزين نتائج المشروع عند " + MAX_PROJECT_ROWS + " صف؛ لم يُخزّن " + out.droppedRows + " صف");
      out.note = withApiAssumption(withFeedCap(out.note, out.feedSkipped), platform);
    } catch (RuntimeException | LinkageError failure) {
      out.failed = true;
      out.note = "تعذرت جولة فحص المشروع: " + failure.getClass().getSimpleName()
          + (failure.getMessage() == null ? "" : ": " + failure.getMessage());
    }
    publishProjectPass(out, module, generation);
  }

  private static boolean isAndroidResource(String path) {
    return path != null && path.replace('\\', '/').matches("(?:.*/)?res/[^/]+/[^/]+\\.xml");
  }

  private static void stage(PassOutput out, String id, String text, AnalysisResult result) {
    if (result.getIncompleteReasons().contains("RESOURCE_INDEX_INCOMPLETE")) out.resourceIncomplete = true;
    if (result.getIncompleteReasons().contains("PROJECT_INDEX_INCOMPLETE")) out.projectIncomplete = true;
    if (result.getStatus() == AnalysisResult.Status.CANCELLED) { out.unreadable.add(id); return; }
    if (result.getStatus() == AnalysisResult.Status.PARTIAL) out.partial.put(id, result.getIncompleteReasons());
    List<AnalyzerErrorUnit.Row> rows = AnalyzerErrorUnit.map(nameOf(id), id, text, result);
    int allowed = Math.max(0, MAX_PROJECT_ROWS - out.rowCount);
    int take = Math.min(allowed, rows.size());
    if (take < rows.size()) {
      ArrayList<String> reasons = new ArrayList<>();
      if (out.partial.containsKey(id)) reasons.addAll(out.partial.get(id));
      reasons.add("PROJECT_ROW_LIMIT");
      out.partial.put(id, reasons);
    }
    out.droppedRows += rows.size() - take;
    ArrayList<AnalyzerErrorUnit.Row> compact = new ArrayList<>(take);
    for (int i = 0; i < take; i++) {
      AnalyzerErrorUnit.Row row = rows.get(i);
      // The QA-only fully applied text would otherwise retain whole document copies per fix.
      compact.add(new AnalyzerErrorUnit.Row(row.diagnostic, row.fix, row.workspaceFixCount, null, row.trimmedBehind, row.statusOnly));
    }
    out.rowCount += take; out.rows.put(id, compact);
  }

  private void publishProjectPass(final PassOutput out, final java.io.File module, final long generation) {
    projectMain.post(() -> {
      try {
      if (current(generation) && projectHost != null && module.equals(projectHost.moduleDir())) {
        if (!out.failed) {
          java.util.HashSet<String> keep = new java.util.HashSet<>(out.rows.keySet());
          keep.addAll(out.unreadable);
          for (String previous : new ArrayList<>(projectWritten)) {
            if (!keep.contains(previous)) {
              if (out.enumerationIncomplete) {
                // A failed directory scan cannot establish that an unseen file was deleted.
                AnalyzerErrorUnit.markProjectPending(previous);
                keep.add(previous);
              } else AnalyzerErrorUnit.clearProject(previous);
            }
          }
          for (java.util.Map.Entry<String, List<AnalyzerErrorUnit.Row>> row : out.rows.entrySet())
            AnalyzerErrorUnit.putProjectRows(row.getKey(), row.getValue(), out.partial.get(row.getKey()));
          for (String id : out.unreadable) AnalyzerErrorUnit.markProjectPending(id);
          projectWritten.clear(); projectWritten.addAll(keep);
          if (!editorClasspathSymbols.equals(out.symbols)) {
            editorClasspathSymbols = out.symbols;
            refreshEditorContext();
          }
        } else {
          for (String previous : projectWritten) AnalyzerErrorUnit.markProjectPending(previous);
        }
        if (out.note == null) AnalyzerErrorUnit.clearProject(PROJECT_NOTE_REFERENCE);
        else {
          AnalyzerErrorUnit.Row row = AnalyzerErrorUnit.budgetRow(module.getName(), PROJECT_NOTE_REFERENCE, out.note);
          AnalyzerErrorUnit.putProjectRows(PROJECT_NOTE_REFERENCE,
              row == null ? java.util.Collections.emptyList() : java.util.Collections.singletonList(row));
        }
        notifyPublisher();
      }
      } finally {
        projectRunning = false;
        if (projectQueued) { projectQueued = false; requestProjectPass(); }
      }
    });
  }

  private void clearProjectRows() {
    for (String previous : new ArrayList<>(projectWritten)) AnalyzerErrorUnit.clearProject(previous);
    projectWritten.clear();
    AnalyzerErrorUnit.clearProject(PROJECT_NOTE_REFERENCE);
  }

  private static Language kindOf(AnalyzerWorkspacePlan.Kind kind) {
    return kind == AnalyzerWorkspacePlan.Kind.KOTLIN ? Language.KOTLIN : Language.JAVA;
  }

  private static String nameOf(String reference) {
    String path = reference == null ? "" : reference.replace('\\', '/');
    int slash = path.lastIndexOf('/');
    return slash < 0 ? path : path.substring(slash + 1);
  }

  /**
   * بَابُ النَّشرِ الوَاحِدُ: إِنۡ كُنَّا دَاخِلَ نَشرٍ فَالطَّلَبُ مُجَمَّعٌ (نَظرَةٌ وَاحِدَةٌ
   * بَعۡدَ الفَرَاغِ) لَا مُتَتَالٍ — فَالقَطۡعُ هُنَا، إِذۡ لَا مَعۡنَىٰ لأنۡ يُنشِئَ نَشرٌ نَشرًا.
   */
  private void notifyPublisher() {
    if (publisher == null) return;
    // A project-pass failure can reach here on the worker, but the publisher
    // updates Android views and all focus/paint guards belong to the main thread.
    if (android.os.Looper.myLooper() != android.os.Looper.getMainLooper()) {
      projectMain.post(this::notifyPublisher);
      return;
    }
    if (publishOwner == Thread.currentThread()) {
      publishAgain = true;
      return;
    }
    publishOwner = Thread.currentThread();
    try {
      publisher.publish();
      if (publishAgain) {
        publishAgain = false;
        publisher.publish();
      }
    } finally {
      publishAgain = false;
      publishOwner = null;
    }
  }

  /** هَلۡ إِشرَاقُنَا الحَالِيُّ صَدَىٰ رَسمٍ نَشَرۡنَاهُ نَحنُ؟ فَلَيسَ مِن حَقِّنَا تَلۡبِيَتُهُ. */
  private boolean echoing() {
    return publishOwner == Thread.currentThread();
  }

  public void release() { detachEditor(true); }

  /** Final Activity shutdown: cancel now, then close native trees on their owning worker. */
  public void shutdown() {
    detachEditor(true);
    projectHost = null;
    projectQueued = false;
    projectMain.removeCallbacks(projectKick);
    java.util.concurrent.ExecutorService worker = projectWorker;
    projectWorker = null;
    if (worker != null) {
      try {
        worker.execute(() -> {
          if (cachedProjectAnalyzer != null) {
            try { cachedProjectAnalyzer.close(); } catch (RuntimeException ignored) { }
            cachedProjectAnalyzer = null; cachedProjectConfig = null;
          }
          cachedClasspath = null;
        });
      } finally { worker.shutdown(); }
    }
  }

  private void detachEditor(boolean closeProject) {
    boolean hadState = handle != null || reference != null || fileName != null
        || !changeListeners.isEmpty() || (closeProject && !projectWritten.isEmpty());
    invalidateProjectPass();
    if (handle != null) {
      try { handle.close(); } catch (RuntimeException ignored) { }
      handle = null;
    }
    changeListeners.clear();
    if (closeProject) {
      projectMain.removeCallbacks(projectKick);
      clearProjectRows();
    }
    if (reference != null) AnalyzerErrorUnit.clearEditor(reference);
    reference = null; fileName = null; observedText = null;
    if (hadState) notifyPublisher();
  }

  /** مَا يَرَاهُ الشَّريطُ/البَوَّابَةُ: لَا «سَلِيمٌ» عِندَمَا لَم يَنظُرْ أحَدٌ. */
  public String status() {
    if (!probed) return "IDLE";
    if (!nativeReady) return "UNAVAILABLE_NATIVE(" + nativeReason + ")";
    String tab = handle == null ? "READY_NO_TAB" : "READY";
    if (projectRunning) return tab + "+PROJECT_PASS";
    return projectWritten.isEmpty() ? tab : tab + "+PROJECT_" + projectWritten.size();
  }

  private String text() {
    return source == null || reference == null ? null : source.textOf(reference);
  }

  /**
   * الجَاوَا وَكُوتلِنُ وَ‏xml‏: الأَوَّلَانِ بِالشَّجَرَةِ، وَالثَّالِثُ بِـ‏XmlAnalyzer‏ — قَرَأتُ
   * ‏AnalysisHandle:83-90‏ فَوَجَدتُ المَكتَبَةَ نَفسَهَا تَفتَحُ ‏Language.XML‏ عَلى فَحصِ الوَثيقَةِ
   * (بِلَا نَحوٍ طَبيعِيٍّ وَلَا قَيدِ مُستَهلِكٍ)، فَوَضعُ التبويبِ عَلَيهَا كَاذِبٌ بَعدَ اليَومِ.
   * أَمَّا مَا بَينَ ذلِكَ (قِيَمُ ‏@drawable‏ المُعلَّقَةِ وَتَناسُقُ الأَسمَاءِ) فَغَيرُ مَفتُوحٍ
   * عِندَهُم — وَلَا نَدَّعِيهِ.
   */
  private static boolean isSupported(String path) {
    return path.endsWith(".java") || path.endsWith(".kt") || path.endsWith(".xml");
  }

  /** لُغَةٌ وَاحِدَةٌ لِلطَّرِيقَينِ: إِنْ تَزَحزَحَت إحدَاهُمَا عَنِ الأُخرَى فَصَارَ التَّبويبُ يُفحَصُ بِلِسَانٍ غَلَطٍ. */
  private static Language languageOf(String path) {
    String p = path == null ? "" : path;
    if (p.endsWith(".xml")) return Language.XML;
    return p.endsWith(".kt") ? Language.KOTLIN : Language.JAVA;
  }

  /**
   * تَركِيبَةُ فَحصِ التبويبِ: مُستَوَيَا المِشرُوعِ لَا مُستَوَيَا الجِهَازِ — لِأَنَّ
   * «مَهجُورٌ مُنذُ ٢٦» عِندَهُم لَا تُقَالُ إِلَّا إِذَا كَانَ ‏deprecated ≤ compileApi‏
   * (‏SemanticRules:127‏). قِسنَاهُ: نَفسُ المِلَفِّ مَعَ ‏compileApi=25‏ صَمتٌ، وَمَعَهُ ٣٧
   * صَفُّ ‏ANDROID_DEPRECATED‏ — فَالجِهَازُ يُسكِتُ الحَقَّ.
   */
  private AnalysisConfig editorConfig(String text) {
    boolean ready = projectHost != null && projectHost.classpathComplete();
    ProjectPlatform platform = ready ? ProjectPlatform.current() : ProjectPlatform.unknown();
    AnalysisConfig.Builder builder =
        AnalysisConfig.builder()
            .minApi(platform.analyzerMinApi())
            .compileApi(platform.analyzerCompileApi(android.os.Build.VERSION.SDK_INT));
    // صِفْرُ إِعلَانٍ عَنِ الحِصَّةِ هُنَا عَمدًا: تبويبٌ وَاحدٌ لَا يَبلُغُ ‏8192‏ مُدخَلًا،
    // وَمَا يَحدُثُ عَلى المِشرُوعِ كُلِّهِ يُقالُ عَلَى صَفِّ الجَمعِ.
    if (ready) {
      feedAndroidTypes(builder, java.util.Collections.singletonList(text));
      for (String symbol : editorClasspathSymbols) builder.addSymbol(symbol);
    }
    return builder.build();
  }

  /** نَتِيجَةُ تَركِيبَةِ الجَمعِ: المِخدَعُ + مَا تُرِكَ مِنَ التَّغمِيذِ (لَا يُكتمُ السَّقَطُ). */
  private static final class FedConfig {
    final AnalysisConfig config;
    final int skipped;

    FedConfig(AnalysisConfig config, int skipped) {
      this.config = config;
      this.skipped = skipped;
    }
  }

  /** تَركِيبَةُ الجَمعِ: الحُدُودُ أَدنَى مِن سَقَفِهِم دَائِمًا — وَإِلَّا فَهُوَ رَفعُ استِثنَاءٍ لَا ‏PARTIAL‏. */
  private static FedConfig projectConfig(java.util.Collection<String> texts, ProjectPlatform platform, List<String> symbols) {
    AnalysisConfig.Builder builder =
        AnalysisConfig.builder()
            .minApi(platform.analyzerMinApi())
            .compileApi(platform.analyzerCompileApi(android.os.Build.VERSION.SDK_INT))
            .maxProjectFiles(AnalyzerWorkspacePlan.MAX_FILES + 8)
            .maxProjectChars(AnalyzerWorkspacePlan.MAX_TOTAL_CHARS + AnalyzerWorkspacePlan.MAX_FILE_CHARS)
            .maxDocumentChars(AnalyzerWorkspacePlan.MAX_FILE_CHARS)
            .maxCachedFiles(128);
    for (String symbol : symbols) builder.addSymbol(symbol);
    int skipped = feedAndroidTypes(builder, texts);
    return new FedConfig(builder.build(), skipped);
  }

  /**
   * كَتالُوجُهُم قَصْدًا تِسعَةُ أَصنَافٍ (‏ApiCatalog:16-24‏: «المَجهُولُ لَا يَستَحقُّ دَعوَى»)،
   * وَفَهرَسُنَا المَحمِيُّ عَنِ الأَصلَابِ أَوسَعُ — فَنَحنُ نَغذُوهُ بِمَا ذُكِرَ فِي المِلَفِّ
   * فَحَسبُ (مِن سُطُورِ ‏import android.‏): قَدرٌ مَحدُودٌ، وَلَا دَعوَى عَلَى صِنفٍ لَم نَرَ
   * مُستَوَاهُ. وَمَا لَا يَقبَلُونَهُ يُترَكُ — صِفْرُ صُفوفٍ أَصدَقُ مِن صَفٍّ مَبنِيٍّ عَلَى
   * تَفسِيرٍ لَا يُطِيقُونَهُ.
   */
  private static final int MAX_FED_TYPES = 4096;
  /** حِصَّةٌ وَاحدَةٌ لِلأَنوَاعِ وَالسَّاكِنَاتِ جَمِيعًا — سَقفُهُم ‏50_000‏ يَجمَعُهُمَا (‏AnalysisConfig:30‏). */
  private static final int MAX_FED_ENTRIES = 8192;

  /** يَرجِعُ عَدَدَ مَا تُرِكَ مِن أَجلِ الحِصَّةِ — يُعلَنُ عَلَى صَفِّ النَّقصِ، وَلَا يُكتمُ. */
  private static int feedAndroidTypes(
      AnalysisConfig.Builder builder, java.util.Collection<String> texts) {
    if (texts == null || texts.isEmpty()) return 0;
    if (!almlk.AndroidApiIndex.isLoaded()) return 0; // الفَهرَسُ لَم يُحمَّل بَعدُ: لَا شَيءَ نُثبِتُهُ
    java.util.LinkedHashSet<String> wanted = new java.util.LinkedHashSet<String>();
    for (String text : texts) {
      collectAndroidImports(text, wanted);
      if (wanted.size() >= MAX_FED_TYPES) break;
    }
    int fed = 0;
    int skipped = 0;
    for (String fqcn : wanted) {
      almlk.AndroidApiIndex.ClassInfo info = almlk.AndroidApiIndex.classByQualifiedName(fqcn);
      if (info == null || info.library || info.hidden || info.provisional || info.since <= 0) continue;
      // Only known, public platform metadata supplies API levels; libraries are not Android APIs.
      almlk.AnalyzerSymbolFeed.Feed feed = almlk.AnalyzerSymbolFeed.of(
          fqcn, info.since, info.deprecated, membersOf(info), MAX_FED_ENTRIES - fed);
      if (feed == null) {
        skipped++; // حِصَّةٌ لَا تَبقَى لَهَا: الصِّنفُ كُلُّهُ يُترَكُ — وَيُذكَرُ أَنَّهُ تُرِكَ
        continue;
      }
      if (feed.entries == 0) {
        skipped++;
        continue; // الحِصَّةُ انقَضَت: هذَا الصِّنفُ لَا يُغذَّى نِصفًا
      }
      fed += feed.entries;
      try {
        builder.addAndroidApiType(feed.type, feed.since, feed.deprecated);
      } catch (RuntimeException rejected) {
        // رَفضَهُم (مَثَلًا صِنفٌ لَيسَ ‏android.*‏): يَمضِي الفَحصُ بِدُونِهِ.
        skipped++;
      }
      for (java.util.Map.Entry<String, int[]> one : feed.statics.entrySet()) {
        try {
          builder.addAndroidApiStaticMethod(feed.type, one.getKey(), one.getValue()[0],
              one.getValue()[1]);
        } catch (RuntimeException rejected) {
          skipped++; // الاِسمُ رُبَّمَا كَسَرَ حِدَّهِم: العُضوُ وَحدَهُ يُترَكُ، لَا المِلَفُّ كُلُّهُ
        }
      }
    }
    return skipped;
  }

  /**
   * مَا يُمكِنُ للإِرسَالِ أَن يُبَنِىَ عَلَيهِ: ‏isStatic‏ مَعلُومٌ عِندَنَا (‏AndroidApiIndex:102‏)،
   * وَهُوَ الفَصلُ عِندَهُم — قِسنَا أَنَّ المِفْتَاحَ ‏owner#name‏ لَا يُدرِكُ النِّدَاءَ عَبرَ
   * مُتَغَيِّرٍ، فَالسَّاكِنُ فَحَسبُ هُوَ الَّذي لَا يَضَعُ حُكمًا فِى غَيرِ مَوضِعِهِ.
   * وَ‏ownLevels‏ يَستَبعِدُ مَا وَرِثَهُ العُضوُ عَنِ الصِّنفِ (فَهرَسُنَا يَملاُ بِهِ، قَيدٌ عَلى ‏:117‏).
   */
  private static java.util.List<almlk.AnalyzerSymbolFeed.Member> membersOf(
      almlk.AndroidApiIndex.ClassInfo info) {
    java.util.ArrayList<almlk.AnalyzerSymbolFeed.Member> out =
        new java.util.ArrayList<almlk.AnalyzerSymbolFeed.Member>();
    for (almlk.AndroidApiIndex.Member m : almlk.AndroidApiIndex.declaredMembers(info)) {
      if (m == null) continue;
      boolean own = m.since != info.since || m.deprecated != info.deprecated;
      out.add(new almlk.AnalyzerSymbolFeed.Member(
          m.name, m.isStatic, m.kind == almlk.AndroidApiIndex.Member.METHOD,
          m.since, m.deprecated, own));
    }
    return out;
  }

  /** سُطُورُ ‏import android.…;‏ فَحَسبُ — لِأنَّ ‏addAndroidApiType‏ عِندَهُم يَشرُطُ بَادِئَةَ ‏android.‏. */
  private static final java.util.regex.Pattern ANDROID_IMPORT = java.util.regex.Pattern.compile(
      "(?m)^[ \t]*import[ \t]+(?:static[ \t]+)?(android\\.[A-Za-z_$][A-Za-z0-9_$]*(?:\\.[A-Za-z_$][A-Za-z0-9_$]*)*)[ \t]*(?:;|(?:as[ \t]+[A-Za-z_$][A-Za-z0-9_$]*)?[ \t]*$)");

  private static void collectAndroidImports(String text, java.util.LinkedHashSet<String> out) {
    if (text == null) return;
    java.util.regex.Matcher matcher = ANDROID_IMPORT.matcher(text);
    while (out.size() < MAX_FED_TYPES && matcher.find()) out.add(matcher.group(1));
  }

  /** إِذَا اُفتُرِضَ شَيءٌ فَذلِكَ مَكتُوبٌ فِي اللَّوحَةِ: قَرَارٌ عَلَى مُستَوًى لَم نَقرَؤُهُ لَا يُنسَبُ إِلَينَا. */
  private static String withApiAssumption(String note, ProjectPlatform platform) {
    if (platform == null || !platform.analyzerApiAssumed()) return note;
    return appendSentence(note,
        "minSdk أو compileSdk غير معروف للمشروع؛ عُطّلت أحكام الإصدار التي تحتاج القيمة المجهولة ولم يُستخدم إصدار الجهاز");
  }

  /** حِصَّةُ التَّغمِيذِ إِذَا انقَضَت تُذكَرُ: فَالنَّاقِصُ المَكتُومُ أَخطَرُ مِنَ الكَثِيرِ المُتَأَخِّرِ. */
  private static String withFeedCap(String note, int skipped) {
    if (skipped <= 0) return note;
    return appendSentence(note, skipped + " صِنفًا تُرِكَ عَن تَغمِيذِ المُحرِّكِ (بَلَغَ حِصَّتَهُ) — "
        + "فَمَا قِيلَ فِيهَا مِن «مَهجُورٍ» وَ«مُستَوًى» يَحتَمِلُ الزِّيَادَةَ لَو تَمَّ الإِرسَالُ");
  }

  /** جُمَلَةُ النَّقصِ وَاحدَةُ البِنَاءِ: تُفتَحُ إِنْ لَم يَكُن شَيءٌ، وَتُلحَقُ قَبلَ الذَّيلِ إِنْ كَانَ. */
  private static String appendSentence(String note, String extra) {
    if (note == null || note.isEmpty()) {
      return "الفَحصُ الجَمعِيُّ: " + extra + "؛ فَصَمتِي عَمَّا لَم أَصِلْ إِلَيهِ لَيسَ بَرَاءَةً.";
    }
    int tail = note.lastIndexOf(" — فَصَمتِي");
    if (tail < 0) return note + " وَ" + extra + "؛";
    return note.substring(0, tail) + " وَ" + extra + "؛" + note.substring(tail);
  }

  /** مَسَارٌ مُطلَقٌ إِلَى نِسبِيٍّ دَاخِلَ الوَحدَةِ، أَو {@code null} — لِتَبدِيلِ المَوَارِدِ الحَيَّةِ. */
  private static String relativeIn(java.io.File module, String reference) {
    if (module == null || reference == null) return null;
    String root = module.getAbsolutePath().replace('\\', '/');
    String path = reference.replace('\\', '/');
    if (!path.startsWith(root + "/") || path.length() <= root.length() + 1) return null;
    return path.substring(root.length() + 1);
  }

  /** مُحمِّلٌ وَاحدٌ لِلتَّحقُّقِ مِن وُجُودِ الصِّنفِ قَبلَ أن يَكتَشِفَهُ المُحرِّرُ نَفسُهُ. */
  private static final class NativeBridgeLoader {
    static ClassLoader loader() { return AnalyzerBridge.class.getClassLoader(); }
  }

  /** وَجهَةُ المَكتَبَةِ إِلَى نَصِّنَا: قِرَاءَةٌ، وَإِخطَارٌ، وَلَا كِتَابَةَ — صَفُّ الإِصلاحِ يَفِي بِكُلِّ شَيءٍ. */
  private final class BridgeAdapter implements EditorAdapter {
    @Override public String getText() {
      String value = text();
      return value == null ? "" : value;
    }

    @Override public void replace(int startOffset, int endOffset, String replacement) {
      // لَا سَبِيلَ إِلَى هُنَا فِي تَطرِيقَتِنَا: الإِصلاحُ يَمرُّ عَلى صَفِّ {@link almlk.QuickFix}
      // فَيَأخُذُ التَّراجُعَ وَالاتَّسَاخَ وَالحِفظَ قَبلَ البِنَاءِ وَدَورَةَ المُكتَبَاتِ كُلَّهَا.
      // لَو تَغَيَّرَ ذلِكَ يَومًا فَالسَّقطةُ هُنَا أَصدَقُ مِن كِتَابَةٍ نِصفَ مَسمُوعَةٍ.
      throw new UnsupportedOperationException(
          "Apply analyzer fixes through almlk.QuickFix rows (undo, dirty and save are theirs).");
    }

    @Override public Subscription subscribe(Runnable onChange) {
      changeListeners.add(onChange);
      return new Subscription() {
        @Override public void close() {
          changeListeners.remove(onChange);
        }
      };
    }
  }
}
