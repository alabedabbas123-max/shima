package almlk;

import java.io.File;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/**
 * قواعدُ إكمالِ Gradle بالمفاتيحِ: «سطرٌ لكلِّ قاعدةٍ» كما في المرجعِ، بصيغةٍ صريحةٍ:
 *
 * <pre>
 * # تعليقٌ
 * nb => new Bundle()                      ← الزنادُ ثمَّ النصُّ المُدرَجُ
 * viewbinding => buildFeatures { viewBinding true } :: تفعيلُ ViewBinding
 * </pre>
 *
 * <p>الفواصلُ المقبولةُ بينَ الزنادِ والمُدرَجِ: `=&gt;` أو `=` أو `->`؛ و`::` تفصلُ تفصيلًا
 * يُعرَضُ في العمودِ الأيمنِ. سطرٌ بلا فاصلٍ يُدرِجُ نصَّهُ نفسَهُ. تُهمَلُ الأسطرُ الفارغةُ
 * وأولُ {@value #MAX_RULES} قاعدةً فقطْ — ملفٌّ بلا حدٍّ لا يوقفُ المحرِّرَ.
 */
public final class CompletionRules {

  /** أقصى عددِ قواعدَ تُقبَلُ من الملفِّ (حِمايةٌ من ملفٍّ ضخمٍ أو دوّارٍ). */
  public static final int MAX_RULES = 512;

  /** قاعدةٌ واحدةٌ: ما يُكتَبُ، وما يُدرَجُ، وما يظهرُ تفصيلًا. */
  public static final class Item {
    public final String trigger;
    public final String insertText;
    public final String detail;

    Item(String trigger, String insertText, String detail) {
      this.trigger = trigger;
      this.insertText = insertText;
      this.detail = detail;
    }
  }

  public static final CompletionRules EMPTY =
      new CompletionRules(Collections.<Item>emptyList(), Collections.unmodifiableList(new ArrayList<String>()), "");

  private final List<Item> items;
  private final List<String> triggersLower;
  private final String stamp;

  private CompletionRules(List<Item> items, List<String> triggersLower, String stamp) {
    this.items = items;
    this.triggersLower = triggersLower;
    this.stamp = stamp;
  }

  /** يحلَّلُ نصُّ الملفِّ كلُّهُ مرةً واحدةً؛ الطابعُ للاستظهارِ (لا قراءةَ القرصِ كلَّ ضغطةِ مفتاحٍ). */
  public static CompletionRules parse(String text, String stamp) {
    List<Item> items = new ArrayList<>();
    List<String> lower = new ArrayList<>();
    if (text != null) {
      int line = 0;
      for (String raw : text.split("\n")) {
        line++;
        String s = raw.replace('\r', ' ').trim();
        if (s.isEmpty() || s.startsWith("#") || s.startsWith("//")) continue;
        String[] parts = splitRule(s);
        if (parts == null) continue;
        String trigger = parts[0];
        String insert = parts[1];
        String detail = parts[2];
        if (insert.isEmpty()) insert = trigger;
        if (trigger.isEmpty()) continue;
        if (items.size() >= MAX_RULES) break;
        items.add(new Item(trigger, insert, detail));
        lower.add(trigger.toLowerCase(Locale.US));
      }
    }
    return new CompletionRules(
        Collections.unmodifiableList(items), Collections.unmodifiableList(lower), stamp == null ? "" : stamp);
  }

  public static CompletionRules parse(String text) {
    return parse(text, "");
  }

  /** ملفُّ القواعدِ: غائبٌ أو مقروءٌ بلا قواعدَ ← EMPTY (وليس خطأً: المفتاحُ اختياريٌّ). */
  public static CompletionRules load(File file) {
    if (file == null || !file.isFile()) return EMPTY;
    try {
      byte[] raw = Files.readAllBytes(file.toPath());
      String stamp = file.getAbsolutePath() + "|" + file.length() + "|" + file.lastModified();
      return parse(new String(raw, Charset.forName("UTF-8")), stamp);
    } catch (Exception quiet) {
      return EMPTY;
    }
  }

  /** القواعدُ التي تبدأُ بما كتَبَهُ المستخدمُ (مطابقةُ بادئةٍ، بلا حالةٍ)، بحدِّ عشرٍ. */
  public List<Item> matching(String typed) {
    if (items.isEmpty()) return Collections.emptyList();
    String key = typed == null ? "" : typed.trim().toLowerCase(Locale.US);
    List<Item> out = new ArrayList<>();
    for (int i = 0; i < items.size() && out.size() < 10; i++) {
      String t = triggersLower.get(i);
      if (key.isEmpty() || t.startsWith(key)) out.add(items.get(i)); // المطابقةُ التامّةُ تُعرَضُ: الزنادُ نفسُهُ ما طُلِبَ
    }
    return out;
  }

  public List<Item> items() {
    return items;
  }

  public int size() {
    return items.size();
  }

  public boolean isEmpty() {
    return items.isEmpty();
  }

  public String stamp() {
    return stamp;
  }

  /**
   * تفصيلُ سطرِ قاعدةٍ إلى {الزنادُ، المُدرَجُ، التفصيلُ}؛ القواعدُ: `=&gt;` أو `->` أو `=` عاريٌ
   * (لا `==` ولا `>=` ولا `<=` ولا `!=` ولا `+=`)، و`::` قبلَها تفصيلٌ. السطرُ الفارغُ أو التعليقُ
   * أو غيرُ القابلِ للتحليلِ ← null.
   */
  static String[] splitRule(String line) {
    if (line == null) return null;
    String s = line.trim();
    if (s.isEmpty() || s.startsWith("#") || s.startsWith("//")) return null;
    int detailAt = s.indexOf("::");
    String detail = "";
    if (detailAt >= 0) {
      detail = s.substring(detailAt + 2).trim();
      s = s.substring(0, detailAt).trim();
    }
    int sep = -1;
    int sepLen = 0;
    int arrow = firstArrow(s);
    if (arrow >= 0) {
      sep = arrow;
      sepLen = 2;
    } else {
      for (int i = 0; i < s.length(); i++) {
        if (s.charAt(i) != '=') continue;
        char prev = i > 0 ? s.charAt(i - 1) : '\0';
        char next = i + 1 < s.length() ? s.charAt(i + 1) : '\0';
        if (prev == '=' || prev == '!' || prev == '<' || prev == '>' || prev == '+' || prev == '-'
            || prev == '*' || prev == '/' || next == '=') continue;
        sep = i;
        sepLen = 1;
        break;
      }
    }
    if (sep < 0) return isToken(s) ? new String[] {s, "", detail} : null;
    String trigger = s.substring(0, sep).trim();
    String insert = s.substring(sep + sepLen).trim();
    if (insert.startsWith("=") || insert.startsWith(">") || insert.startsWith("<") || insert.startsWith("!")) {
      return null; // «bad = = =» سطرٌ فاسدٌ لا قاعدةٌ: المُدرَجُ لا يبدأُ بعاملٍ
    }
    if (trigger.isEmpty() || !isToken(trigger)) return null;
    return new String[] {trigger, insert, detail};
  }

  /** الزنادُ رمزٌ واحدٌ قابلٌ للكتابةِ: حروفٌ/أرقامٌ/`.`/`_`/`-`/`:`/`(`/`)`. */
  private static boolean isToken(String s) {
    if (s == null || s.isEmpty()) return false;
    for (int i = 0; i < s.length(); i++) {
      char c = s.charAt(i);
      boolean ok = (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9')
          || c == '.' || c == '_' || c == '-' || c == ':' || c == '(' || c == ')';
      if (!ok) return false;
    }
    return true;
  }

  /** أولُ موضعٍ لـ`=&gt;` أو `->` (أيهما أسبقُ)، أو -1. */
  private static int firstArrow(String s) {
    int a = s.indexOf("=>");
    int b = s.indexOf("->");
    if (a < 0) return b;
    if (b < 0) return a;
    return Math.min(a, b);
  }
}
