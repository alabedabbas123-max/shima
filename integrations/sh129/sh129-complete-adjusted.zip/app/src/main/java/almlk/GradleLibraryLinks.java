package almlk;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * ربطُ مشروعِ مكتبةٍ محليٍّ بوحدةِ المشروعِ المفتوحِ وفصلُهُ عنهُ (W22/4ب٢).
 *
 * <p><b>ما يُطابقُهُ من المرجعِ:</b> قائمةُ الضغطِ المطوّلِ في متصفّحِ الملفاتِ عندَ AIDE تحملُ
 * {@code filebrowserMenuAddLibrary} («Add library to project») و{@code filebrowserMenuRemoveLibrary}
 * («Remove library from project»)، ويُسألُ المستخدمُ تأكيدًا واحدًا ثمَّ يُعلَنُ الأمرُ بإشعارٍ قصيرٍ
 * («Library has been added»). لا شاشةَ إعداداتٍ ولا مساعدَ في هذا المسارِ، ولا تنزيلَ: المكتبةُ
 * المحليّةُ تُقرأُ من القرصِ كما هيَ.
 *
 * <p><b>ما يكتبُهُ الربطُ فعلًا:</b> سطرَ وحدةٍ في {@code settings.gradle}
 * ({@code include ':name'})، ومعَهُ سطرَ {@code project(':name').projectDir = …} حينَ لا يسكنُ
 * مجلدُ الوحدةِ مباشرةً تحتَ جذرِ المشروعِ؛ وسطرَ اعتمادٍ داخلَ كتلةِ {@code dependencies} من
 * وحدةِ التطبيقِ ({@code implementation project(':name')}). الصياغةُ تتبعُ نوعَ الملفِّ: Groovy
 * بالاقتباسِ المفردِ، و{@code .kts} بالاقتباسِ المزدوجِ والأقواسِ.
 *
 * <p><b>لا يخربُ ما كتبتَهُ يدويًّا:</b> التحريرُ نصّيٌّ واعيُ الأسطرِ — يُزَالُ سطرُ إدراجِ الوحدةِ
 * و{@code projectDir} الخاصَّ بها وسطرُ اعتمادِها وحدَهُ؛ وإنْ حمَلَ سطرُ الإدراجِ وحداتٍ أخرى بقيتْ
 * وتُجُرِّدَ اسمُها منهُ. الربطُ لا يُنشئُ مجلدًا ولا ينقلُ ملفًّا ولا يحذفُ من القرصِ شيئًا.
 *
 * <p><b>جافا خالصةٌ:</b> لا {@code android.*} ولا شبكةَ ولا خيطَ جديدًا هنا. الدعّاءُ ينفّذُ هذا
 * العملَ على خيطِهِ العاملِ (في المتصفّحِ: {@code fileReader}) ثمَّ يبلّغُ المضيفَ بإعادةِ دورةِ
 * الاعتماداتِ الصامتةِ، فتُدخَلُ الوحدةُ في الحلِّ والفهرسةِ بلا انتظارٍ ولا تنزيلٍ زائدٍ.
 */
public final class GradleLibraryLinks {

  /** تمَّ ما طُلِبَ. */
  public static final int DONE = 0;
  /** الوحدةُ مرتبطةٌ بهذا الاسمِ سلفًا (أو المجلدُ مدرَجٌ بوصفٍ آخرَ). */
  public static final int ALREADY_LINKED = 1;
  /** لم يكنْ مرتبطًا: لا شيءَ يُزَالُ ولا خطأَ في ذلكَ. */
  public static final int NOT_LINKED = 2;
  /** المجلدُ ليسَ وحدةَ Gradleَ: لا {@code build.gradle} فيهِ ولا في {@code app/} التابِعِ لَهُ. */
  public static final int NOT_A_MODULE = 3;
  /** المجلدُ هوَ المشروعُ المفتوحُ نفسُهُ أو داخلَهُ: لا يُربَطُ المشروعُ بنفسِهِ. */
  public static final int IS_OPEN_PROJECT = 4;
  /** اسمُ المجلدِ لا يصلحُ مُعرِّفَ وحدةٍ (يبدأُ برقمٍ، أو فيهِ مسافةٌ أو رمزٌ). */
  public static final int BAD_NAME = 5;
  /** لا مشروعَ مفتوحًا، أو لا ملفَّ بناءَ لوحدةٍ فيهِ. */
  public static final int NO_PROJECT = 6;
  /** تعذّرَتِ الكتابةُ على القرصِ (صلاحيةٌ مفقودةٌ أو موضعٌ غيرُ قابلٍ للكتابةِ). */
  public static final int IO_ERROR = 7;

  private static final int MAX_FILE_BYTES = 1 << 20;

  /** وحدةٌ مدرَجةٌ في {@code settings.gradle}. */
  public static final class Link {
    /** المُعرِّفُ كما بعدَ النقطتينِ في {@code include ':name'}. */
    public final String name;
    /** مجلدُ الوحدةِ: المُعلَنُ في {@code projectDir} أو الافتراضيُّ {@code جذر/name}. */
    public final File dir;
    /** هل صرّحَ الملفُّ بمجلدٍ خاصٍّ لهذهِ الوحدةِ؟ */
    public final boolean declaredDir;

    Link(String name, File dir, boolean declaredDir) {
      this.name = name;
      this.dir = dir;
      this.declaredDir = declaredDir;
    }

    @Override
    public String toString() {
      return ":" + name + (declaredDir ? " -> " + dir : "");
    }
  }

  /** نتيجةُ ربطٍ أو فصلٍ: حالةٌ + ما كُتِبَ فعلًا + سببٌ مسمًّى عندَ الرفضِ. */
  public static final class Result {
    public final int status;
    public final String name;
    public final boolean settingsChanged;
    public final boolean buildChanged;
    public final String detail;

    public Result(
        int status, String name, boolean settingsChanged, boolean buildChanged, String detail) {
      this.status = status;
      this.name = name == null ? "" : name;
      this.settingsChanged = settingsChanged;
      this.buildChanged = buildChanged;
      this.detail = detail == null ? "" : detail;
    }

    public boolean done() {
      return status == DONE;
    }

    public boolean changedAnything() {
      return settingsChanged || buildChanged;
    }
  }

  private GradleLibraryLinks() {}

  // ═══════════════ القراءةُ: ما المرتبطُ الآنَ؟ ═══════════════

  /** {@code settings.gradle} ثمَّ {@code settings.gradle.kts} في الجذرِ، أو null. */
  public static File settingsFileIn(File projectRoot) {
    if (projectRoot == null) return null;
    File groovy = new File(projectRoot, "settings.gradle");
    if (groovy.isFile()) return groovy;
    File kts = new File(projectRoot, "settings.gradle.kts");
    return kts.isFile() ? kts : null;
  }

  /** الوحداتُ المدرَجةُ في ملفِّ الإعداداتِ — فارغٌ إن لم يكنْ ملفٌّ أو لم يُدرِجْ شيئًا. */
  public static List<Link> includedModules(File projectRoot) {
    File settings = settingsFileIn(projectRoot);
    if (settings == null || projectRoot == null) return Collections.emptyList();
    try {
      return parseIncludes(read(settings), settings.getName().endsWith(".kts"), projectRoot);
    } catch (IOException failure) {
      return Collections.emptyList();
    }
  }

  /** تحليلٌ نصّيٌّ بلا تنفيذِ Groovy: {@code include} بأشكالِها و{@code projectDir} التابعُ لَهَا. */
  static List<Link> parseIncludes(String text, boolean kts, File projectRoot) {
    List<Link> out = new ArrayList<>();
    if (text == null || text.isEmpty() || projectRoot == null) return out;
    List<String> lines = stripComments(text);
    for (String line : lines) {
      int at = indexOfKeyword(line, "include");
      if (at < 0) continue;
      List<String> quoted = new ArrayList<>();
      collectQuoted(line, at + "include".length(), quoted);
      for (String raw : quoted) {
        if (raw == null || raw.isEmpty()) continue;
        String name = raw.startsWith(":") ? raw.substring(1) : raw;
        if (name.isEmpty()) continue;
        File declared = normalize(new File(projectRoot, name.replace(':', File.separatorChar)));
        File override = projectDirOverride(lines, name, projectRoot);
        out.add(new Link(name, override == null ? declared : override, override != null));
      }
    }
    return out;
  }

  /** {@code project(':x').projectDir = new File('…')} (Groovy) أو {@code file("…")} (‏kts). */
  private static File projectDirOverride(List<String> lines, String name, File projectRoot) {
    for (String line : lines) {
      if (line.indexOf("projectDir") < 0) continue;
      if (!mentionsName(line, name)) continue;
      int eq = line.indexOf('=');
      if (eq < 0) continue;
      List<String> quoted = new ArrayList<>();
      collectQuoted(line, eq + 1, quoted);
      for (String path : quoted) {
        if (path == null || path.isEmpty() || path.equals(name) || path.equals(":" + name)) continue;
        File f = new File(path.replace('\\', '/'));
        return normalize(f.isAbsolute() ? f : new File(projectRoot, path.replace('\\', '/')));
      }
    }
    return null;
  }

  /** هل يشيرُ السطرُ إلى هذهِ الوحدةِ بالاسمِ (مع أو بلا النقطتينِ)؟ */
  private static boolean mentionsName(String line, String name) {
    return line.contains("':" + name + "'")
        || line.contains("\":" + name + "\"")
        || line.contains("'" + name + "'")
        || line.contains("\"" + name + "\"");
  }

  // ═══════════════ القرارُ: هل يُربَطُ هذا المجلدُ؟ ═══════════════

  /** مجلدُ الوحدةِ: المجلدُ نفسُهُ إن كانَ فيهِ ملفُّ بناءٍ، وإلا {@code app/} إن كانَ فيهِ. */
  public static File moduleDirOf(File folder) {
    if (folder == null) return null;
    if (GradleDependencyEditor.buildFileIn(folder) != null) return folder;
    File app = new File(folder, "app");
    return app.isDirectory() && GradleDependencyEditor.buildFileIn(app) != null ? app : null;
  }

  /** حكمٌ بلا كتابةٍ: {@link #DONE} عندَ الصلاحيّةِ، وسببٌ مسمًّى عندَ الرفضِ. */
  public static int check(File projectRoot, File folder) {
    if (projectRoot == null || !projectRoot.isDirectory()) return NO_PROJECT;
    if (GradleDependencyEditor.moduleBuildFile(projectRoot) == null) return NO_PROJECT;
    if (folder == null || !folder.isDirectory()) return NOT_A_MODULE;
    String root = canonical(projectRoot);
    String candidate = canonical(folder);
    if (root.equals(candidate) || candidate.startsWith(root + File.separator)) return IS_OPEN_PROJECT;
    if (!isSafeName(folder.getName())) return BAD_NAME;
    if (moduleDirOf(folder) == null) return NOT_A_MODULE;
    for (Link link : includedModules(projectRoot)) {
      if (link.name.equals(folder.getName()) || canonical(link.dir).equals(candidate)) return ALREADY_LINKED;
    }
    return DONE;
  }

  /** اسمُ وحدةٍ مقبولٌ: يبدأُ بحرفٍ أو {@code _}، ولا يحملُ إلّا حروفًا وأرقامًا و{@code _ . -}. */
  public static boolean isSafeName(String name) {
    if (name == null || name.isEmpty() || name.length() > 64) return false;
    char first = name.charAt(0);
    if (!((first >= 'a' && first <= 'z') || (first >= 'A' && first <= 'Z') || first == '_')) return false;
    for (int i = 0; i < name.length(); i++) {
      char c = name.charAt(i);
      boolean ok = (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9')
          || c == '_' || c == '-' || c == '.';
      if (!ok) return false;
    }
    return true;
  }

  // ═══════════════ الكتابةُ ═══════════════

  /** ربطُ مجلدٍ مكتبةً بوحدةِ المشروعِ المفتوحِ. لا استثناءاتٍ تُرمى على المستدعي. */
  public static Result link(File projectRoot, File folder) {
    String name = folder == null ? "" : folder.getName();
    int verdict = check(projectRoot, folder);
    if (verdict != DONE) return new Result(verdict, name, false, false, reason(verdict));
    File moduleDir = moduleDirOf(folder);
    File settings = settingsFileIn(projectRoot);
    File buildFile = GradleDependencyEditor.moduleBuildFile(projectRoot);
    boolean settingsChanged = false;
    boolean buildChanged = false;
    try {
      boolean settingsKts = settings != null && settings.getName().endsWith(".kts");
      String settingsText = settings != null ? read(settings) : "";
      // الوحدةُ تحتاجُ projectDir إن لم تكنِ الابنَ المباشرَ للجذرِ تحتَ اسمِها، أو كانَ اسمُها مختلفًا.
      String relative = needDirLine(projectRoot, name, moduleDir) ? relativeTo(projectRoot, moduleDir) : null;
      String updatedSettings = withInclude(settingsText, name, relative, settingsKts);
      if (!updatedSettings.equals(settingsText)) {
        write(settings != null ? settings : new File(projectRoot, "settings.gradle"), updatedSettings);
        settingsChanged = true;
      }
      String buildText = read(buildFile);
      String updatedBuild =
          GradleDependencyEditor.addDependency(buildText, dependencyLine(name, buildFile.getName().endsWith(".kts")));
      if (!updatedBuild.equals(buildText)) {
        write(buildFile, updatedBuild);
        buildChanged = true;
      }
    } catch (IOException failure) {
      String message = failure.getMessage() == null ? failure.getClass().getSimpleName() : failure.getMessage();
      return new Result(IO_ERROR, name, settingsChanged, buildChanged, message);
    }
    if (!settingsChanged && !buildChanged) return new Result(ALREADY_LINKED, name, false, false, reason(ALREADY_LINKED));
    return new Result(DONE, name, settingsChanged, buildChanged, "");
  }

  /** فصلُ وحدةٍ: يمسحُ سطرَ إدراجِها و{@code projectDir} الخاصَّ بها وسطرَ اعتمادِها فقطْ. */
  public static Result unlink(File projectRoot, String name) {
    if (projectRoot == null || !projectRoot.isDirectory()) return new Result(NO_PROJECT, name, false, false, reason(NO_PROJECT));
    if (!isSafeName(name)) return new Result(BAD_NAME, name, false, false, reason(BAD_NAME));
    File settings = settingsFileIn(projectRoot);
    if (settings == null) return new Result(NOT_LINKED, name, false, false, reason(NOT_LINKED));
    File buildFile = GradleDependencyEditor.moduleBuildFile(projectRoot);
    boolean settingsChanged = false;
    boolean buildChanged = false;
    try {
      String text = read(settings);
      String updated = withoutInclude(text, name, settings.getName().endsWith(".kts"));
      if (!updated.equals(text)) {
        write(settings, updated);
        settingsChanged = true;
      }
      if (buildFile != null) {
        String buildText = read(buildFile);
        String updatedBuild =
            GradleDependencyEditor.removeDependency(buildText, dependencyLine(name, buildFile.getName().endsWith(".kts")));
        if (!updatedBuild.equals(buildText)) {
          write(buildFile, updatedBuild);
          buildChanged = true;
        }
      }
    } catch (IOException failure) {
      String message = failure.getMessage() == null ? failure.getClass().getSimpleName() : failure.getMessage();
      return new Result(IO_ERROR, name, settingsChanged, buildChanged, message);
    }
    if (!settingsChanged && !buildChanged) return new Result(NOT_LINKED, name, false, false, reason(NOT_LINKED));
    return new Result(DONE, name, settingsChanged, buildChanged, "");
  }

  /** هل يلزمُ سطرُ {@code projectDir}؟ حينَ لا يكونُ المجلدُ {@code جذر/name} هوَ موضعَ الوحدةِ. */
  static boolean needDirLine(File projectRoot, String name, File moduleDir) {
    if (projectRoot == null || moduleDir == null) return true;
    return !canonical(new File(projectRoot, name)).equals(canonical(moduleDir));
  }

  /** سطرُ اعتمادِ الوحدةِ بصيغةِ الملفِّ. */
  public static String dependencyLine(String name, boolean kts) {
    return kts ? "implementation(project(\":" + name + "\"))" : "implementation project(':" + name + "')";
  }

  /** للحوارِ: أسماءُ الوحداتِ المرتبطةِ مرتّبةً. */
  public static List<String> names(List<Link> links) {
    List<String> out = new ArrayList<>();
    if (links != null) for (Link link : links) if (link != null) out.add(link.name);
    Collections.sort(out);
    return out;
  }

  /** سببٌ مسمًّى للحالةِ — يراهُ المستدعي في إشعارٍ، بلا استثناءاتٍ. */
  public static String reason(int status) {
    switch (status) {
      case ALREADY_LINKED: return "already linked";
      case NOT_LINKED: return "not linked";
      case NOT_A_MODULE: return "no build file in folder";
      case IS_OPEN_PROJECT: return "the open project itself";
      case BAD_NAME: return "unsafe module name";
      case IO_ERROR: return "write failed";
      case NO_PROJECT: return "no open project";
      default: return "ok";
    }
  }

  // ═══════════════ أدواتُ النصِّ ═══════════════

  /** يضيفُ سطرَ الإدراجِ (ومعَهُ {@code projectDir} إن لزمَ) — بلا تكرارٍ ولا مسٍّ بغيرِهِ. */
  static String withInclude(String text, String name, String relativeDir, boolean kts) {
    String body = text == null ? "" : text;
    StringBuilder add = new StringBuilder();
    if (!mentionsInclude(body, name)) add.append(includeLine(name, kts));
    if (relativeDir != null && !declaresProjectDir(body, name)) add.append(projectDirLine(name, relativeDir, kts));
    if (add.length() == 0) return body;
    String prefix = body.isEmpty() || body.endsWith("\n") ? body : body + "\n";
    return prefix + "\n" + add;
  }

  /** يحذفُ إدراجَ الوحدةِ و{@code projectDir} الخاصَّ بها، ويُبقي كلَّ ما عداها. */
  static String withoutInclude(String text, String name, boolean kts) {
    String body = text == null ? "" : text;
    if (!mentionsInclude(body, name)) return body;
    String[] lines = body.split("\n", -1);
    StringBuilder out = new StringBuilder();
    for (String line : lines) {
      if (line.indexOf("projectDir") >= 0 && mentionsName(line, name)) continue;
      int at = indexOfKeyword(line, "include");
      if (at < 0) {
        out.append(line).append('\n');
        continue;
      }
      List<String> quoted = new ArrayList<>();
      collectQuoted(line, at + "include".length(), quoted);
      List<String> kept = new ArrayList<>();
      for (String candidate : quoted) {
        if (candidate == null) continue;
        String simple = candidate.startsWith(":") ? candidate.substring(1) : candidate;
        if (!simple.equals(name)) kept.add(candidate);
      }
      if (kept.isEmpty()) continue;
      if (kept.size() == quoted.size()) {
        out.append(line).append('\n');
        continue;
      }
      StringBuilder rebuilt = new StringBuilder(kts ? "include(" : "include ");
      for (int j = 0; j < kept.size(); j++) {
        if (j > 0) rebuilt.append(", ");
        rebuilt.append(quote(kept.get(j), kts));
      }
      if (kts) rebuilt.append(')');
      out.append(rebuilt).append('\n');
    }
    while (out.length() > 0 && out.charAt(out.length() - 1) == '\n') out.setLength(out.length() - 1);
    out.append('\n');
    return out.toString();
  }

  private static String includeLine(String name, boolean kts) {
    return kts ? "include(" + quote(":" + name, true) + ")\n" : "include " + quote(":" + name, false) + "\n";
  }

  private static String projectDirLine(String name, String relativeDir, boolean kts) {
    String path = relativeDir.replace('\\', '/');
    return kts
        ? "project(" + quote(name, true) + ").projectDir = file(" + quote(path, true) + ")\n"
        : "project(" + quote(name, false) + ").projectDir = new File('" + path + "')\n";
  }

  private static String quote(String value, boolean kts) {
    return kts ? "\"" + value + "\"" : "'" + value + "'";
  }

  private static boolean mentionsInclude(String text, String name) {
    for (String included : parseIncludeNames(text)) if (included.equals(name)) return true;
    return false;
  }

  private static boolean declaresProjectDir(String text, String name) {
    for (String line : stripComments(text == null ? "" : text)) {
      if (line.indexOf("projectDir") >= 0 && mentionsName(line, name)) return true;
    }
    return false;
  }

  private static List<String> parseIncludeNames(String text) {
    List<String> out = new ArrayList<>();
    if (text == null || text.isEmpty()) return out;
    for (String line : stripComments(text)) {
      int at = indexOfKeyword(line, "include");
      if (at < 0) continue;
      List<String> quoted = new ArrayList<>();
      collectQuoted(line, at + "include".length(), quoted);
      for (String name : quoted) {
        if (name == null || name.isEmpty()) continue;
        out.add(name.startsWith(":") ? name.substring(1) : name);
      }
    }
    return out;
  }

  /** موضعُ كلمةٍ مفتاحيّةٍ خارجَ النصوصِ المحصورَةِ، أو -1. */
  private static int indexOfKeyword(String line, String keyword) {
    boolean inSingle = false;
    boolean inDouble = false;
    for (int i = 0; i + keyword.length() <= line.length(); i++) {
      char c = line.charAt(i);
      if (c == '\'') inSingle = !inSingle;
      else if (c == '"') inDouble = !inDouble;
      if (inSingle || inDouble) continue;
      if (line.startsWith(keyword, i)
          && (i == 0 || !isIdent(line.charAt(i - 1)))
          && !isIdent(line.charAt(i + keyword.length()))) return i;
    }
    return -1;
  }

  private static boolean isIdent(char c) {
    return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '_' || c == '.';
  }

  /** يجمعُ ما بينَ علاماتِ الاقتباسِ من الموضعِ المُعطى فصاعدًا. */
  private static void collectQuoted(String line, int from, List<String> out) {
    int n = line.length();
    int i = Math.max(0, Math.min(Math.max(0, from), n));
    while (i < n) {
      char open = line.charAt(i);
      if (open != '\'' && open != '"') {
        i++;
        continue;
      }
      int end = line.indexOf(open, i + 1);
      if (end < 0) return;
      out.add(line.substring(i + 1, end));
      i = end + 1;
    }
  }

  /** الأسطرُ بلا تعليقاتٍ (‏{@code //} و{@code /* … *}) مع الحفاظِ على عددِها وترتيبِها. */
  private static List<String> stripComments(String text) {
    List<String> out = new ArrayList<>();
    boolean block = false;
    for (String raw : text.split("\n", -1)) {
      if (raw.trim().startsWith("#")) {
        out.add("");
        continue;
      }
      StringBuilder line = new StringBuilder();
      for (int i = 0; i < raw.length(); i++) {
        char c = raw.charAt(i);
        if (block) {
          if (c == '*' && i + 1 < raw.length() && raw.charAt(i + 1) == '/') {
            block = false;
            i++;
          }
          continue;
        }
        if (c == '/' && i + 1 < raw.length() && raw.charAt(i + 1) == '/') break;
        if (c == '/' && i + 1 < raw.length() && raw.charAt(i + 1) == '*') {
          block = true;
          i++;
          continue;
        }
        if (c == '\'' || c == '"') {
          int end = raw.indexOf(c, i + 1);
          if (end < 0) {
            line.append(raw.substring(i));
            break;
          }
          line.append(raw, i, end + 1);
          i = end;
          continue;
        }
        line.append(c);
      }
      out.add(line.toString());
    }
    return out;
  }

  /** مسارٌ نسبيٌّ من {@code from} إلى {@code to} بفواصلَ أماميّةٍ، أو null إنِ اختلافُ الجذرَيْنِ. */
  public static String relativeTo(File from, File to) {
    if (from == null || to == null) return null;
    String[] a = canonical(from).replace(File.separatorChar, '/').split("/");
    String[] b = canonical(to).replace(File.separatorChar, '/').split("/");
    int common = 0;
    while (common < a.length && common < b.length && a[common].equals(b[common])) common++;
    if (common == 0) return null;
    StringBuilder out = new StringBuilder();
    for (int i = common; i < a.length; i++) out.append(out.length() == 0 ? ".." : "/..");
    for (int i = common; i < b.length; i++) out.append(out.length() == 0 ? "" : "/").append(b[i]);
    return out.length() == 0 ? "." : out.toString();
  }

  /** مسارٌ بلا {@code ..} ولا {@code .} — يُقرأُ ويُقارَنُ بوضوحٍ في الرسائلِ والفحصِ. */
  private static File normalize(File file) {
    return file.getAbsoluteFile().toPath().normalize().toFile();
  }

  private static String canonical(File file) {
    try {
      return file.getCanonicalFile().getAbsolutePath();
    } catch (IOException fallback) {
      return file.getAbsoluteFile().toPath().normalize().toString();
    }
  }

  // ═══════════════ القرصُ ═══════════════

  private static String read(File file) throws IOException {
    try (InputStream in = new FileInputStream(file)) {
      ByteArrayOutputStream out = new ByteArrayOutputStream();
      byte[] buffer = new byte[8192];
      int total = 0;
      int n;
      while ((n = in.read(buffer)) > 0) {
        total += n;
        if (total > MAX_FILE_BYTES) throw new IOException("file too large: " + file.getName());
        out.write(buffer, 0, n);
      }
      return new String(out.toByteArray(), "UTF-8");
    }
  }

  private static void write(File file, String text) throws IOException {
    File parent = file.getParentFile();
    if (parent != null && !parent.isDirectory() && !parent.mkdirs()) throw new IOException("cannot create " + parent);
    try (OutputStream out = new FileOutputStream(file)) {
      out.write(text.getBytes("UTF-8"));
    }
  }
}
