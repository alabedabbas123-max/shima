package almlk;

import com.shima.demo.R;

/**
 * مصدر واحد لخريطة أيقونة الملف/المجلد حسب الامتداد.
 *
 * <p>كانت الخريطة مكرّرة في ثلاثة أماكن (رؤوس نتائج البحث والمتصفح وشريط المحرر) بنُسَخ غير متطابقة:
 * نسخة المتصفح تعرف html/js/css/c++/zip/... ونسخة المحرر تعرف class/smali، بينما نسخة اللوحة كانت
 * أقلّهما فتُظهر «مجهول» لأنواع يعرفها التطبيق. الجَمع هنا union كامل فلا تفقد أي واجهة ميزة كانت
 * تعرضها، والفرق الوحيد المقصود أن اللوحة صارت تُظهر الأيقونة الصحيحة لما كانت تجهله.
 *
 * <p>الأسماء تُقارَن بالنهايات بعد تطبيعها؛ والمدخل الفارغ أو الخالي يبقى «مجهولًا» لا استثناءً.
 */
public final class FileTypeIcons {

  private FileTypeIcons() {}

  /** أيقونة ملف حسب امتداده، و{@code R.drawable.file_type_unknown} عند عدم المعرفة. */
  public static int forFile(String name) {
    String n = name == null ? "" : name.toLowerCase(java.util.Locale.US);
    if (n.endsWith(".java") || n.endsWith(".kt") || n.endsWith(".class")) {
      return R.drawable.file_type_java;
    }
    if (n.endsWith(".xml")) return R.drawable.file_type_xml;
    if (n.endsWith(".gradle") || n.endsWith(".gradle.kts")) return R.drawable.project_properties;
    if (n.endsWith(".html") || n.endsWith(".htm")) return R.drawable.file_type_html;
    if (n.endsWith(".js") || n.endsWith(".ts")) return R.drawable.file_type_js;
    if (n.endsWith(".css")) return R.drawable.file_type_css;
    if (n.endsWith(".c")) return R.drawable.file_type_c;
    if (n.endsWith(".cpp") || n.endsWith(".cc") || n.endsWith(".cxx")) {
      return R.drawable.file_type_cpp;
    }
    if (n.endsWith(".h") || n.endsWith(".hpp")) return R.drawable.file_type_h;
    if (n.endsWith(".zip")
        || n.endsWith(".jar")
        || n.endsWith(".aar")
        || n.endsWith(".apk")
        || n.endsWith(".dex")) {
      return R.drawable.file_type_zip;
    }
    if (n.endsWith(".txt")
        || n.endsWith(".md")
        || n.endsWith(".markdown")
        || n.endsWith(".properties")
        || n.endsWith(".json")
        || n.endsWith(".csv")
        || n.endsWith(".yaml")
        || n.endsWith(".yml")
        || n.endsWith(".toml")
        || n.endsWith(".ini")
        || n.endsWith(".cfg")
        || n.endsWith(".sh")
        || n.endsWith(".py")
        || n.endsWith(".smali")) {
      return R.drawable.file_type_txt;
    }
    return R.drawable.file_type_unknown;
  }

  /** أيقونة مجلد: المخفي ومجلدات الأدوات تُعلَّم بأيقونة مغايرة كما في متصفح الملفات. */
  public static int forFolder(String name) {
    String n = name == null ? "" : name.toLowerCase(java.util.Locale.US);
    if (n.equals("build") || n.equals("bin") || n.equals("obj") || n.startsWith(".")) {
      return R.drawable.folder_hidden;
    }
    return R.drawable.folder;
  }
}
