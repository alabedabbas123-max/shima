package almlk;

import com.almlkid.kay.ui.CodeLanguageTools.Diagnostic;
import java.util.ArrayList;
import java.util.List;

/**
 * Checking while typing: the scheduling policy of the editor's background analysis and the mapping
 * of a result computed on an older snapshot onto the text as it is now.
 *
 * <p>A run starts {@link #TYPING_DELAY_MS} after the last keystroke, but continuous typing can never
 * postpone it beyond {@link #MAX_WAIT_MS}; a result that arrives after further edits is not thrown
 * away — the findings outside the edited region are moved onto the current text.
 */
public final class LiveDiagnostics {
  public static final long TYPING_DELAY_MS = 250;
  public static final long MAX_WAIT_MS = 700;
  /** An analysis that has not answered for this long is considered lost (detached view). */
  public static final long STALE_RUN_MS = 8000;
  /**
   * W21′1 — leading edge of a burst: the first edit after quiet is answered almost at once, so a
   * marker appears (or goes away) the moment the user stops for a blink, the way the reference's
   * engine answers the modification it was just fed.
   */
  public static final long FIRST_RUN_DELAY_MS = 60;
  /** Quiet longer than this many typing debounces starts a new burst. */
  public static final long BURST_GAP_MS = TYPING_DELAY_MS * 3;

  private LiveDiagnostics() {}

  /**
   * Delay of the next run when edits have been pending since {@code pendingSince} (0 = none).
   */
  public static long delayFor(long now, long pendingSince, long requested) {
    if (pendingSince <= 0) return Math.max(0, requested);
    long left = MAX_WAIT_MS - (now - pendingSince);
    return Math.max(0, Math.min(requested, left));
  }

  /**
   * The caller's requested delay, lowered to {@link #FIRST_RUN_DELAY_MS} when this edit opens a
   * burst ({@code lastEditAt} is 0 or older than {@link #BURST_GAP_MS}). Keystrokes inside one burst
   * keep the requested debounce, so typing never queues an analysis per character.
   */
  public static long delayForBurst(long now, long lastEditAt, long requested) {
    if (requested <= 0) return 0; // an explicit "now" (reinspectNow) is never slowed down
    if (lastEditAt > 0 && now - lastEditAt < BURST_GAP_MS) return requested;
    return Math.min(requested, FIRST_RUN_DELAY_MS);
  }

  /** Visible status for a previous snapshot: never treat it as proof or offer its old fixes. */
  public static final String PENDING_SUFFIX = " — بانتظار إعادة الفحص";

  public static boolean isPending(Diagnostic diagnostic) {
    return diagnostic != null && diagnostic.message != null && diagnostic.message.endsWith(PENDING_SUFFIX);
  }

  /** A fast editor can supply its existing line index instead of rescanning the document. */
  public interface LineLocator {
    int lineForOffset(int offset);
    int lineStartOffset(int line);
  }

  /** Keep even overlapping findings pending; do not offer any old quick fix. */
  public static List<Diagnostic> remap(List<Diagnostic> found, String analysed, String current) {
    if (found == null || found.isEmpty() || analysed == null || current == null) return new ArrayList<>();
    if (analysed.equals(current)) return new ArrayList<>(found);
    int a = analysed.length(), c = current.length();
    int prefix = 0, max = Math.min(a, c);
    while (prefix < max && analysed.charAt(prefix) == current.charAt(prefix)) prefix++;
    int suffix = 0;
    while (suffix < a - prefix && suffix < c - prefix
        && analysed.charAt(a - 1 - suffix) == current.charAt(c - 1 - suffix)) suffix++;
    final int[] starts = lineStarts(current);
    LineLocator locator = new LineLocator() {
      public int lineForOffset(int offset) { return lineOf(starts, offset); }
      public int lineStartOffset(int line) { return starts[line]; }
    };
    return remapRange(found, c, prefix, a - suffix, c - suffix, locator);
  }

  /** The editor already knows its exact replacement and line index; avoid a whole-text diff per key. */
  public static List<Diagnostic> remapEdit(List<Diagnostic> found, String before, String after,
      int start, int removed, int inserted, LineLocator locator) {
    if (found == null || found.isEmpty() || before == null || after == null) return new ArrayList<>();
    if (locator == null || start < 0 || removed < 0 || inserted < 0
        || (long) start + removed > before.length() || (long) start + inserted > after.length()
        || (long) before.length() - removed + inserted != after.length()) return remap(found, before, after);
    if (removed == 0 && inserted == 0) return new ArrayList<>(found);
    return remapRange(found, after.length(), start, start + removed, start + inserted, locator);
  }

  private static List<Diagnostic> remapRange(List<Diagnostic> found, int length, int editStart,
      int oldEnd, int newEnd, LineLocator locator) {
    int delta = newEnd - oldEnd;
    ArrayList<Diagnostic> moved = new ArrayList<>(found.size());
    for (Diagnostic d : found) {
      if (d == null) continue;
      int start = d.offset, end = d.end;
      if (oldEnd <= start) { start += delta; end += delta; }
      else if (editStart < end) {
        start = Math.min(start, editStart);
        end = Math.max(newEnd, end > oldEnd ? end + delta : newEnd);
      }
      start = Math.max(0, Math.min(length, start));
      end = Math.max(start, Math.min(length, end));
      int line = locator.lineForOffset(start);
      String message = d.message == null ? "" : d.message;
      if (!message.endsWith(PENDING_SUFFIX)) message += PENDING_SUFFIX;
      String code = JavaDiagnosticCodes.isUnused(d.code, d.messageKey) ? "UNUSED_EDITOR" : d.code;
      moved.add(Diagnostic.restored(start, end, line + 1, start - locator.lineStartOffset(line) + 1,
          d.severity, code, message, null, null));
    }
    return moved;
  }

  /** Keep old findings when a result is partial, adding current findings without stale fixes. */
  public static List<Diagnostic> mergePartial(List<Diagnostic> previous, List<Diagnostic> current) {
    ArrayList<Diagnostic> merged = new ArrayList<>();
    if (current != null) for (Diagnostic d : current) if (d != null) merged.add(d);
    if (previous == null) return merged;
    for (Diagnostic old : previous) {
      if (old == null) continue;
      boolean confirmed = false;
      for (Diagnostic fresh : merged) {
        if (fresh.offset == old.offset && fresh.end == old.end
            && java.util.Objects.equals(fresh.code, old.code)
            && java.util.Objects.equals(fresh.messageKey, old.messageKey)) { confirmed = true; break; }
      }
      if (!confirmed && merged.size() < AnalyzerProtocol.MAX_FINDINGS) merged.add(pending(old));
    }
    return merged;
  }

  /** Remap project markers shown in this editor; the project store is updated separately. */
  public static List<com.almlkid.kay.ui.ProjectDiagnostic> remapProjectEdit(
      List<com.almlkid.kay.ui.ProjectDiagnostic> rows, String before, String after,
      int start, int removed, int inserted, LineLocator locator) {
    ArrayList<com.almlkid.kay.ui.ProjectDiagnostic> originals = new ArrayList<>();
    ArrayList<Diagnostic> diagnostics = new ArrayList<>();
    if (rows != null) for (com.almlkid.kay.ui.ProjectDiagnostic row : rows) {
      if (row == null || row.diagnostic == null) continue;
      originals.add(row); diagnostics.add(row.diagnostic);
    }
    List<Diagnostic> moved = remapEdit(diagnostics, before, after, start, removed, inserted, locator);
    ArrayList<com.almlkid.kay.ui.ProjectDiagnostic> result = new ArrayList<>();
    for (int i = 0; i < moved.size(); i++) {
      com.almlkid.kay.ui.ProjectDiagnostic old = originals.get(i);
      result.add(old.withDiagnostic(moved.get(i)));
    }
    return result;
  }

  /** Mark a row pending when its original full text is not available for safe offset mapping. */
  public static Diagnostic pending(Diagnostic d) {
    if (d == null) return null;
    String message = d.message == null ? "" : d.message;
    if (!message.endsWith(PENDING_SUFFIX)) message += PENDING_SUFFIX;
    String code = JavaDiagnosticCodes.isUnused(d.code, d.messageKey) ? "UNUSED_EDITOR" : d.code;
    return Diagnostic.restored(d.offset, d.end, d.line, d.column, d.severity, code, message, null, null);
  }

  private static int[] lineStarts(String s) {
    int count = 1;
    for (int i = 0; i < s.length(); i++) if (s.charAt(i) == '\n') count++;
    int[] starts = new int[count];
    int k = 1;
    for (int i = 0; i < s.length(); i++) if (s.charAt(i) == '\n') starts[k++] = i + 1;
    return starts;
  }

  private static int lineOf(int[] starts, int offset) {
    int lo = 0, hi = starts.length - 1;
    while (lo < hi) {
      int mid = (lo + hi + 1) >>> 1;
      if (starts[mid] <= offset) lo = mid;
      else hi = mid - 1;
    }
    return lo;
  }
}
