package almlk;

/**
 * Where the completion window goes relative to the line being typed (pure, screen pixels).
 *
 * <p>Same rule as the reference window: its top edge sits on the bottom of the caret line so the
 * typed line stays visible, and when the room left above the keyboard/symbol bar is too small the
 * editor is scrolled up first (keeping the line inside the editor) so the whole window fits below
 * it. Only when the editor cannot scroll any further (end of file, tiny window) is the window
 * shortened, and if even that leaves too little room it opens above the line instead. The window
 * never overlaps the line and never extends past {@code editorBottom}.
 */
public final class CompletionPopupPlacement {

  /** Final window rectangle: {@code x, y} top-left, plus its height. */
  public static final class Placement {
    public final int x;
    public final int y;
    public final int height;
    public final boolean above;

    Placement(int x, int y, int height, boolean above) {
      this.x = x;
      this.y = y;
      this.height = height;
      this.above = above;
    }
  }

  private CompletionPopupPlacement() {}

  /**
   * Pixels the editor should scroll down (content moves up) so a window of {@code height} fits
   * between the caret line and {@code editorBottom}; never more than keeps the line below
   * {@code editorTop}. Zero when it already fits.
   */
  public static int scrollNeeded(int lineTop, int lineBottom, int editorTop, int editorBottom, int height) {
    int missing = lineBottom + height - editorBottom;
    if (missing <= 0) return 0;
    int lineRoom = Math.max(0, lineTop - editorTop);
    return Math.min(missing, lineRoom);
  }

  /**
   * Places a window of {@code width × height} for the caret line (after any scrolling).
   *
   * @param caretX caret x on screen; the window starts there like the reference, pulled back so it
   *     does not cross {@code screenRight}
   * @param minHeight smallest useful window (a couple of rows); below that the side with more room
   *     wins
   */
  public static Placement place(int caretX, int lineTop, int lineBottom, int editorTop, int editorBottom,
      int screenLeft, int screenRight, int width, int height, int minHeight) {
    int x = Math.max(screenLeft, Math.min(caretX, screenRight - width));
    int below = Math.max(0, editorBottom - lineBottom);
    int wanted = Math.max(0, height);
    if (below >= Math.min(wanted, minHeight)) return new Placement(x, lineBottom, Math.min(wanted, below), false);
    int aboveRoom = Math.max(0, lineTop - editorTop);
    if (aboveRoom > below) {
      int h = Math.min(wanted, aboveRoom);
      return new Placement(x, lineTop - h, h, true);
    }
    return new Placement(x, lineBottom, Math.min(wanted, below), false);
  }
}
