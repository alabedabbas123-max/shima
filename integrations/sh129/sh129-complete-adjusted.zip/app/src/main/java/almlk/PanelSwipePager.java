package almlk;

import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.view.MotionEvent;
import androidx.viewpager.widget.ViewPager;

/**
 * حاوية تمرير الأقسام (الملفات، الأخطاء، البحث…): خط فاصل أسود بين الأقسام كما في المرجع،
 * والتبديل لا يقع إلا إذا سُحب القسم أكثر من نصف عرضه — السحب الأقصر يعيده لمكانه مهما
 * كانت سرعة الإفلات.
 */
public class PanelSwipePager extends ViewPager {

  /** نسبة السحب اللازمة للتبديل. */
  public static final float SWITCH_FRACTION = 0.5f;

  public PanelSwipePager(Context context) {
    super(context);
    int margin = Math.max(1, Math.round(context.getResources().getDisplayMetrics().density));
    setPageMargin(margin);
    setPageMarginDrawable(new ColorDrawable(0xFF000000));
  }

  /** الصفحة الهدف بعد الإفلات: المجاورة فقط إذا تجاوز الإزاحة النصف، وإلا الحالية. */
  public static int targetPage(int current, int scrollX, int pageWidth, int count) {
    if (pageWidth <= 0 || count <= 0) return current;
    float offset = (scrollX - current * (float) pageWidth) / pageWidth;
    int target = current;
    if (offset > SWITCH_FRACTION) target = current + 1;
    else if (offset < -SWITCH_FRACTION) target = current - 1;
    return Math.max(0, Math.min(count - 1, target));
  }

  @Override
  public boolean onTouchEvent(MotionEvent event) {
    int action = event.getActionMasked();
    if (action == MotionEvent.ACTION_UP && getAdapter() != null) {
      int pageWidth = getWidth() - getPaddingLeft() - getPaddingRight() + getPageMargin();
      int current = getCurrentItem();
      if (pageWidth > 0 && getScrollX() != current * pageWidth) {
        int target = targetPage(current, getScrollX(), pageWidth, getAdapter().getCount());
        // إنهاء السحب داخليًا بلا قرار السرعة، ثم الانتقال الناعم إلى الهدف المحسوب.
        MotionEvent cancel = MotionEvent.obtain(event);
        cancel.setAction(MotionEvent.ACTION_CANCEL);
        super.onTouchEvent(cancel);
        cancel.recycle();
        setCurrentItem(target, true);
        return true;
      }
    }
    return super.onTouchEvent(event);
  }
}
