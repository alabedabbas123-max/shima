package almlk;

import static almlk.JavaSyntaxTree.*;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Recursive-descent Java parser of the analysis engine (E1), Java 21 grammar.
 *
 * <p>The parser never throws on bad input: an unexpected token records an error and the caller
 * either skips it or synchronises at {@code ;} / {@code }}, so every loop makes progress and the
 * rest of the file is still analysed. Ambiguities (cast or parenthesis, lambda, local declaration
 * or expression, generic type or less-than) are settled by allocation-free look-ahead scanners
 * over the token arrays.
 *
 * <p>{@link #parseSkeleton} skips method, constructor and initializer bodies by brace matching; it
 * is what {@link JavaProjectModel} uses to index every project file quickly.
 */
public final class JavaParser {

  private static final int MAX_DEPTH = 200;
  private static final int MAX_ERRORS = 100;

  private final JavaLexer lx;
  private final int[] kind;
  private final int[] start;
  private final int[] end;
  private final String[] text;
  private final int last;
  private final boolean skeleton;
  private final Unit unit = new Unit();
  private int p;
  private int depth;

  private JavaParser(String source, boolean skeleton) {
    lx = JavaLexer.tokenize(source);
    kind = lx.kind;
    start = lx.start;
    end = lx.end;
    text = lx.text;
    last = lx.count - 1;
    this.skeleton = skeleton;
  }

  public static Unit parse(String source) {
    return new JavaParser(source, false).compilationUnit();
  }

  public static Unit parseSkeleton(String source) {
    return new JavaParser(source, true).compilationUnit();
  }

  // ───────────────────────────── token helpers ─────────────────────────────

  private int at(int q) {
    return q < 0 ? 0 : q > last ? last : q;
  }

  private int k(int i) {
    return kind[at(p + i)];
  }

  private String t(int i) {
    String s = text[at(p + i)];
    return s == null ? "" : s;
  }

  private String tx(int q) {
    String s = text[at(q)];
    return s == null ? "" : s;
  }

  private boolean is(String s) {
    return text[at(p)] == s;
  }

  private boolean isAt(int i, String s) {
    return text[at(p + i)] == s;
  }

  private boolean accept(String s) {
    if (text[at(p)] == s) {
      p++;
      return true;
    }
    return false;
  }

  private boolean eof() {
    return kind[at(p)] == JavaLexer.EOF;
  }

  private int pos() {
    return start[at(p)];
  }

  private int prevEnd() {
    return p > 0 ? end[at(p - 1)] : 0;
  }

  private boolean adjacent(int q) {
    return end[at(q)] == start[at(q + 1)];
  }

  private void expect(String s) {
    if (!accept(s)) error(prevEnd(), prevEnd() + 1, "Missing '" + s + "'");
  }

  private void error(int from, int to, String message) {
    if (unit.errorMessages.size() >= MAX_ERRORS) return;
    unit.errorRanges.add(new int[] {from, Math.max(from + 1, to)});
    unit.errorMessages.add(message);
  }

  private void unexpected() {
    if (eof()) error(pos(), pos() + 1, "Unexpected end of file");
    else error(pos(), end[at(p)], "Unexpected '" + lx.text(at(p)) + "'");
  }

  private String ident() {
    if (k(0) == JavaLexer.IDENT) {
      String s = text[at(p)];
      p++;
      return s;
    }
    error(pos(), end[at(p)], "Expected identifier");
    return "";
  }

  private static boolean isPrimitive(String s) {
    return s == "int" || s == "boolean" || s == "long" || s == "double" || s == "float"
        || s == "char" || s == "byte" || s == "short";
  }

  private void skipBalanced() {
    if (!is("{")) return;
    int level = 0;
    while (!eof()) {
      if (is("{")) level++;
      else if (is("}")) {
        level--;
        if (level == 0) {
          p++;
          return;
        }
      }
      p++;
    }
  }

  // ───────────────────────────── look-ahead scanners ─────────────────────────────

  private int skipAnnotationsScan(int q) {
    while (tx(q) == "@" && tx(q + 1) != "interface") {
      q++;
      if (kind[at(q)] != JavaLexer.IDENT) return q;
      q++;
      while (tx(q) == "." && kind[at(q + 1)] == JavaLexer.IDENT) q += 2;
      if (tx(q) == "(") {
        int level = 0;
        while (q < last) {
          String s = tx(q);
          if (s == "(") level++;
          else if (s == ")" && --level == 0) {
            q++;
            break;
          }
          q++;
        }
      }
    }
    return q;
  }

  /** Index after a type starting at {@code q}, or -1. */
  private int scanType(int q) {
    q = skipAnnotationsScan(q);
    if (kind[at(q)] == JavaLexer.KEYWORD && isPrimitive(tx(q))) {
      q++;
    } else if (kind[at(q)] == JavaLexer.IDENT) {
      q++;
      while (true) {
        if (tx(q) == "<") {
          q = scanTypeArgs(q);
          if (q < 0) return -1;
        }
        if (tx(q) == "." && (kind[at(q + 1)] == JavaLexer.IDENT || tx(q + 1) == "@")) {
          q = skipAnnotationsScan(q + 1);
          if (kind[at(q)] != JavaLexer.IDENT) return -1;
          q++;
          continue;
        }
        break;
      }
    } else {
      return -1;
    }
    while (true) {
      int r = skipAnnotationsScan(q);
      if (tx(r) == "[" && tx(r + 1) == "]") q = r + 2;
      else break;
    }
    return q;
  }

  private int scanTypeArgs(int q) {
    q++;
    if (tx(q) == ">") return q + 1;
    while (q < last) {
      q = skipAnnotationsScan(q);
      if (tx(q) == "?") {
        q++;
        if (tx(q) == "extends" || tx(q) == "super") {
          q = scanType(q + 1);
          if (q < 0) return -1;
        }
      } else {
        q = scanType(q);
        if (q < 0) return -1;
      }
      while (tx(q) == "&") {
        q = scanType(q + 1);
        if (q < 0) return -1;
      }
      if (tx(q) == ",") {
        q++;
        continue;
      }
      if (tx(q) == ">") return q + 1;
      return -1;
    }
    return -1;
  }

  private boolean isTypeStart() {
    if (is("class") || is("interface") || is("enum")) return true;
    if (is("@") && isAt(1, "interface")) return true;
    return k(0) == JavaLexer.IDENT && t(0).equals("record") && k(1) == JavaLexer.IDENT
        && (isAt(2, "(") || isAt(2, "<"));
  }

  private boolean isLocalVarDecl() {
    if (k(0) == JavaLexer.IDENT && t(0).equals("var") && k(1) == JavaLexer.IDENT) return true;
    int q = scanType(p);
    return q > 0 && kind[at(q)] == JavaLexer.IDENT;
  }

  private boolean lambdaAhead() {
    if (k(0) == JavaLexer.IDENT && isAt(1, "->")) return true;
    if (!is("(")) return false;
    int level = 0;
    for (int q = p; q < last; q++) {
      String s = tx(q);
      if (s == "(") level++;
      else if (s == ")") {
        if (--level == 0) return tx(q + 1) == "->";
      } else if (s == ";" || s == "{" || s == "}" || s == "->") return false;
    }
    return false;
  }

  private boolean castAhead() {
    int q = scanType(p + 1);
    if (q < 0) return false;
    while (tx(q) == "&") {
      q = scanType(q + 1);
      if (q < 0) return false;
    }
    if (tx(q) != ")") return false;
    if (kind[at(p + 1)] == JavaLexer.KEYWORD && isPrimitive(tx(p + 1))) return true;
    int n = q + 1;
    int nk = kind[at(n)];
    if (nk == JavaLexer.IDENT || nk >= JavaLexer.INT && nk <= JavaLexer.TEXT_BLOCK) return true;
    String s = tx(n);
    if (nk == JavaLexer.KEYWORD)
      return s == "this" || s == "super" || s == "new" || s == "true" || s == "false"
          || s == "null" || s == "switch" || isPrimitive(s) || s == "void";
    return s == "(" || s == "!" || s == "~";
  }

  // ───────────────────────────── compilation unit ─────────────────────────────

  private Unit compilationUnit() {
    unit.start = 0;
    unit.end = lx.src.length();
    if (k(0) == JavaLexer.IDENT && (t(0).equals("module") || t(0).equals("open"))
        && (k(1) == JavaLexer.IDENT)) return unit;
    Modifiers pending = modifiers();
    if (is("package")) {
      p++;
      unit.packageStart = pos();
      unit.packageName = qualifiedName(null);
      unit.packageEnd = prevEnd();
      expect(";");
      pending = null;
    }
    while (is("import") || is(";")) {
      if (accept(";")) continue;
      importDecl();
    }
    while (!eof()) {
      if (accept(";")) continue;
      int before = p;
      Modifiers m = pending != null ? pending : modifiers();
      pending = null;
      if (isTypeStart()) {
        unit.types.add(typeDecl(m, false));
      } else if (is("import")) {
        importDecl();
      } else {
        unexpected();
        if (is("{")) skipBalanced();
        else p++;
      }
      if (p == before) p++;
    }
    return unit;
  }

  private String qualifiedName(List<Integer> starts) {
    StringBuilder b = new StringBuilder();
    if (starts != null) starts.add(pos());
    b.append(ident());
    while (is(".") && k(1) == JavaLexer.IDENT) {
      p++;
      if (starts != null) starts.add(pos());
      b.append('.').append(ident());
    }
    return b.toString();
  }

  private void importDecl() {
    Import im = new Import();
    im.start = pos();
    p++;
    if (accept("static")) im.isStatic = true;
    im.nameStart = pos();
    im.name = qualifiedName(im.segmentStarts);
    im.nameEnd = prevEnd();
    if (is(".") && isAt(1, "*")) {
      p += 2;
      im.onDemand = true;
    }
    expect(";");
    im.end = prevEnd();
    if (!im.name.isEmpty()) unit.imports.add(im);
  }

  // ───────────────────────────── modifiers & annotations ─────────────────────────────

  private Modifiers modifiers() {
    Modifiers m = new Modifiers();
    while (true) {
      if (is("@") && !isAt(1, "interface")) {
        if (m.annotations.isEmpty()) m.annotations = new ArrayList<>();
        m.annotations.add(annotation());
        continue;
      }
      int flag = 0;
      if (k(0) == JavaLexer.KEYWORD) {
        String s = t(0);
        if (s == "public") flag = PUBLIC;
        else if (s == "private") flag = PRIVATE;
        else if (s == "protected") flag = PROTECTED;
        else if (s == "static") flag = STATIC;
        else if (s == "final") flag = FINAL;
        else if (s == "abstract") flag = ABSTRACT;
        else if (s == "native") flag = NATIVE;
        else if (s == "synchronized" && !isAt(1, "(")) flag = SYNCHRONIZED;
        else if (s == "transient") flag = TRANSIENT;
        else if (s == "volatile") flag = VOLATILE;
        else if (s == "strictfp") flag = STRICTFP;
        else if (s == "default" && !isAt(1, ":") && !isAt(1, "->")) flag = DEFAULT;
      } else if (k(0) == JavaLexer.IDENT) {
        if (t(0).equals("sealed") && (k(1) == JavaLexer.KEYWORD || isAt(1, "@")
            || k(1) == JavaLexer.IDENT && t(1).equals("record"))) flag = SEALED;
        else if (t(0).equals("non") && isAt(1, "-") && t(2).equals("sealed")
            && adjacent(p) && adjacent(p + 1)) {
          p += 3;
          m.flags |= NON_SEALED;
          continue;
        }
      }
      if (flag == 0) break;
      m.flags |= flag;
      p++;
    }
    return m;
  }

  private Annotation annotation() {
    Annotation a = new Annotation();
    a.start = pos();
    p++;
    a.type = new TypeRef();
    a.type.start = pos();
    while (true) {
      a.type.nameStarts.add(pos());
      a.type.names.add(ident());
      a.type.args.add(null);
      if (is(".") && k(1) == JavaLexer.IDENT) {
        p++;
        continue;
      }
      break;
    }
    a.type.end = prevEnd();
    if (accept("(")) {
      if (!is(")")) {
        if (k(0) == JavaLexer.IDENT && isAt(1, "=")) {
          do {
            if (k(0) != JavaLexer.IDENT) break;
            a.names.add(ident());
            expect("=");
            a.values.add(elementValue());
          } while (accept(","));
        } else {
          a.names.add(null);
          a.values.add(elementValue());
        }
      }
      expect(")");
    }
    a.end = prevEnd();
    return a;
  }

  private Expr elementValue() {
    if (is("@")) {
      ErrorExpr e = new ErrorExpr();
      e.start = pos();
      annotation();
      e.end = prevEnd();
      return e;
    }
    if (is("{")) {
      ArrayInit init = new ArrayInit();
      init.start = pos();
      p++;
      while (!is("}") && !eof()) {
        int before = p;
        init.elements.add(elementValue());
        if (!accept(",")) break;
        if (p == before) p++;
      }
      expect("}");
      init.end = prevEnd();
      return init;
    }
    return conditional();
  }

  private void skipAnnotations() {
    while (is("@") && !isAt(1, "interface")) annotation();
  }

  // ───────────────────────────── types ─────────────────────────────

  private TypeRef type() {
    TypeRef r = new TypeRef();
    skipAnnotations();
    r.start = pos();
    if (k(0) == JavaLexer.KEYWORD && (isPrimitive(t(0)) || is("void"))) {
      r.primitive = t(0);
      p++;
    } else if (k(0) == JavaLexer.IDENT) {
      while (true) {
        r.nameStarts.add(pos());
        r.names.add(ident());
        r.args.add(is("<") ? typeArgs() : null);
        if (is(".") && (k(1) == JavaLexer.IDENT || isAt(1, "@"))) {
          p++;
          skipAnnotations();
          continue;
        }
        break;
      }
    } else {
      error(pos(), end[at(p)], "Expected a type");
      r.end = pos();
      return r;
    }
    while (true) {
      int save = p;
      skipAnnotations();
      if (is("[") && isAt(1, "]")) {
        p += 2;
        r.dims++;
      } else {
        p = save;
        break;
      }
    }
    r.end = prevEnd();
    return r;
  }

  private List<TypeRef> typeArgs() {
    p++; // '<'
    if (accept(">")) return Collections.emptyList();
    ArrayList<TypeRef> list = new ArrayList<>();
    while (!eof()) {
      int before = p;
      skipAnnotations();
      if (is("?")) {
        TypeRef w = new TypeRef();
        w.start = pos();
        p++;
        w.wildcard = 1;
        if (accept("extends")) {
          w.wildcard = 2;
          w.bound = type();
        } else if (accept("super")) {
          w.wildcard = 3;
          w.bound = type();
        }
        w.end = prevEnd();
        list.add(w);
      } else {
        list.add(type());
      }
      while (accept("&")) type();
      if (accept(",")) continue;
      if (p == before) p++;
      break;
    }
    expect(">");
    return list;
  }

  private void typeParams(List<TypeParam> into) {
    p++; // '<'
    while (!eof() && !is(">")) {
      int before = p;
      skipAnnotations();
      TypeParam tp = new TypeParam();
      tp.start = pos();
      tp.nameStart = pos();
      tp.name = ident();
      if (accept("extends")) {
        tp.bounds.add(type());
        while (accept("&")) tp.bounds.add(type());
      }
      tp.end = prevEnd();
      into.add(tp);
      if (!accept(",")) break;
      if (p == before) p++;
    }
    expect(">");
  }

  private void typeList(List<TypeRef> into) {
    do {
      into.add(type());
    } while (accept(","));
  }

  // ───────────────────────────── declarations ─────────────────────────────

  private TypeDecl typeDecl(Modifiers m, boolean local) {
    TypeDecl d = new TypeDecl();
    d.mods = m;
    d.local = local;
    d.start = m.annotations.isEmpty() ? pos() : m.annotations.get(0).start;
    if (accept("class")) d.kind = CLASS;
    else if (accept("interface")) d.kind = INTERFACE;
    else if (accept("enum")) d.kind = ENUM;
    else if (is("@")) {
      p += 2;
      d.kind = ANNOTATION;
    } else {
      p++; // record
      d.kind = RECORD;
    }
    d.nameStart = pos();
    d.name = ident();
    if (is("<")) typeParams(d.typeParams);
    if (d.kind == RECORD && accept("(")) {
      while (!is(")") && !eof()) {
        int before = p;
        VarDecl v = new VarDecl();
        v.start = pos();
        v.mods = modifiers();
        v.type = type();
        if (accept("...")) v.type.varargs = true;
        v.nameStart = pos();
        v.name = ident();
        v.end = prevEnd();
        d.recordComponents.add(v);
        if (!accept(",")) break;
        if (p == before) p++;
      }
      expect(")");
    }
    if (accept("extends")) {
      if (d.kind == INTERFACE) typeList(d.interfaces);
      else {
        d.superclass = type();
        while (accept(",")) d.interfaces.add(type()); // invalid, kept for analysis
      }
    }
    if (accept("implements")) typeList(d.interfaces);
    if (k(0) == JavaLexer.IDENT && t(0).equals("permits")) {
      p++;
      typeList(new ArrayList<TypeRef>());
    }
    classBody(d);
    d.end = prevEnd();
    return d;
  }

  private void classBody(TypeDecl d) {
    if (!is("{")) {
      error(prevEnd(), prevEnd() + 1, "Missing '{'");
      d.bodyStart = d.bodyEnd = prevEnd();
      return;
    }
    d.bodyStart = pos();
    p++;
    if (++depth > MAX_DEPTH) {
      p--;
      skipBalanced();
      depth--;
      d.bodyEnd = prevEnd();
      return;
    }
    if (d.kind == ENUM) enumConstants(d);
    while (!is("}") && !eof()) {
      int before = p;
      member(d);
      if (p == before) p++;
    }
    d.bodyEnd = is("}") ? end[at(p)] : pos();
    expect("}");
    depth--;
  }

  private void enumConstants(TypeDecl d) {
    while (k(0) == JavaLexer.IDENT || is("@")) {
      int before = p;
      EnumConstant c = new EnumConstant();
      c.start = pos();
      c.mods = modifiers();
      c.nameStart = pos();
      c.name = ident();
      if (is("(")) {
        c.args = new ArrayList<>();
        arguments(c.args);
      }
      if (is("{")) {
        TypeDecl body = new TypeDecl();
        body.anonymous = true;
        body.kind = CLASS;
        body.start = pos();
        classBody(body);
        body.end = prevEnd();
        c.body = body;
      }
      c.end = prevEnd();
      d.constants.add(c);
      if (p == before) p++;
      if (!accept(",")) break;
    }
    accept(";");
  }

  private void member(TypeDecl d) {
    if (accept(";")) return;
    if (is("{") || is("static") && isAt(1, "{")) {
      Initializer init = new Initializer();
      init.start = pos();
      init.isStatic = accept("static");
      init.body = body();
      init.end = prevEnd();
      d.members.add(init);
      return;
    }
    int memberStart = pos();
    Modifiers m = modifiers();
    if (isTypeStart()) {
      d.members.add(typeDecl(m, false));
      return;
    }
    List<TypeParam> tps = null;
    if (is("<")) {
      tps = new ArrayList<>();
      typeParams(tps);
    }
    if (k(0) == JavaLexer.IDENT && isAt(1, "(")) {
      d.members.add(method(m, tps, null, memberStart));
      return;
    }
    if (d.kind == RECORD && k(0) == JavaLexer.IDENT && isAt(1, "{") && t(0).equals(d.name)) {
      MethodDecl md = new MethodDecl();
      md.start = memberStart;
      md.mods = m;
      md.constructor = true;
      md.compact = true;
      md.nameStart = pos();
      md.name = ident();
      for (VarDecl v : d.recordComponents) md.params.add(v);
      md.body = body();
      md.bodySkipped = skeleton;
      md.end = prevEnd();
      d.members.add(md);
      return;
    }
    if (!is("void") && scanType(p) < 0) {
      unexpected();
      skipMember();
      return;
    }
    TypeRef type = type();
    if (k(0) == JavaLexer.IDENT && isAt(1, "(")) {
      d.members.add(method(m, tps, type, memberStart));
      return;
    }
    if (k(0) != JavaLexer.IDENT) {
      unexpected();
      skipMember();
      return;
    }
    FieldDecl f = new FieldDecl();
    f.start = memberStart;
    f.mods = m;
    f.type = type;
    declarators(f.vars, m, type);
    expect(";");
    f.end = prevEnd();
    d.members.add(f);
  }

  private void declarators(List<VarDecl> into, Modifiers m, TypeRef type) {
    do {
      VarDecl v = new VarDecl();
      v.start = pos();
      v.mods = m;
      v.type = type;
      v.nameStart = pos();
      v.name = ident();
      while (is("[") && isAt(1, "]")) {
        p += 2;
        v.extraDims++;
      }
      if (accept("=")) v.init = is("{") ? arrayInit() : expression();
      v.end = prevEnd();
      into.add(v);
      if (v.name.isEmpty()) break;
    } while (accept(","));
  }

  private void skipMember() {
    while (!eof()) {
      if (is(";")) {
        p++;
        return;
      }
      if (is("}")) return;
      if (is("{")) {
        skipBalanced();
        return;
      }
      p++;
    }
  }

  private Block body() {
    if (skeleton && is("{")) {
      Block b = new Block();
      b.start = pos();
      skipBalanced();
      b.end = prevEnd();
      return b;
    }
    return block();
  }

  private MethodDecl method(Modifiers m, List<TypeParam> tps, TypeRef result, int memberStart) {
    MethodDecl md = new MethodDecl();
    md.start = memberStart;
    md.mods = m;
    if (tps != null) md.typeParams.addAll(tps);
    md.result = result;
    md.constructor = result == null;
    md.nameStart = pos();
    md.name = ident();
    expect("(");
    while (!is(")") && !eof()) {
      int before = p;
      VarDecl v = new VarDecl();
      v.start = pos();
      v.mods = modifiers();
      v.type = type();
      if (accept("...")) v.type.varargs = true;
      if (is("this")) {
        p++; // receiver parameter
      } else if (k(0) == JavaLexer.IDENT && isAt(1, ".") && isAt(2, "this")) {
        p += 3;
      } else {
        v.nameStart = pos();
        v.name = ident();
        while (is("[") && isAt(1, "]")) {
          p += 2;
          v.extraDims++;
        }
        v.end = prevEnd();
        md.params.add(v);
      }
      if (!accept(",")) break;
      if (p == before) p++;
    }
    expect(")");
    while (is("[") && isAt(1, "]")) {
      p += 2;
      if (md.result != null) md.result.dims++;
    }
    if (accept("throws")) typeList(md.thrown);
    if (accept("default")) md.defaultValue = elementValue();
    if (is("{")) {
      md.body = body();
      md.bodySkipped = skeleton;
    } else {
      expect(";");
    }
    md.end = prevEnd();
    return md;
  }

  // ───────────────────────────── statements ─────────────────────────────

  private Block block() {
    Block b = new Block();
    b.start = pos();
    if (!accept("{")) {
      error(prevEnd(), prevEnd() + 1, "Missing '{'");
      b.end = prevEnd();
      return b;
    }
    if (++depth > MAX_DEPTH) {
      p--;
      skipBalanced();
      depth--;
      b.end = prevEnd();
      return b;
    }
    while (!is("}") && !eof()) {
      int before = p;
      Stmt s = blockStatement();
      if (s != null) b.stmts.add(s);
      if (p == before) p++;
    }
    expect("}");
    depth--;
    b.end = prevEnd();
    return b;
  }

  private Stmt blockStatement() {
    if (is("@") && !isAt(1, "interface") || is("final") || is("abstract") || is("strictfp")
        || is("static") && !isAt(1, "{")) {
      int s = pos();
      Modifiers m = modifiers();
      if (isTypeStart()) return localClass(m, s);
      return localVars(m, s, true);
    }
    if (isTypeStart()) return localClass(new Modifiers(), pos());
    if (k(0) == JavaLexer.IDENT && t(0).equals("yield") && isYieldStatement()) {
      Yield y = new Yield();
      y.start = pos();
      p++;
      y.value = expression();
      expect(";");
      y.end = prevEnd();
      return y;
    }
    if ((k(0) == JavaLexer.IDENT || k(0) == JavaLexer.KEYWORD && isPrimitive(t(0))) && isLocalVarDecl())
      return localVars(new Modifiers(), pos(), true);
    return statement();
  }

  private boolean isYieldStatement() {
    String n = t(1);
    if (k(1) == JavaLexer.EOF) return false;
    return !(n == "=" || n == "." || n == "[" || n == "++" || n == "--" || n == "->" || n == "+="
        || n == "-=" || n == "*=" || n == "/=" || n == "%=" || n == "&=" || n == "|=" || n == "^="
        || n == "<<=" || n == ";" || n == ":");
  }

  private Stmt localClass(Modifiers m, int s) {
    LocalClass lc = new LocalClass();
    lc.start = s;
    lc.decl = typeDecl(m, true);
    lc.end = prevEnd();
    return lc;
  }

  private LocalVars localVars(Modifiers m, int s, boolean semicolon) {
    LocalVars lv = new LocalVars();
    lv.start = s;
    lv.mods = m;
    if (k(0) == JavaLexer.IDENT && t(0).equals("var") && k(1) == JavaLexer.IDENT) {
      TypeRef r = new TypeRef();
      r.start = pos();
      r.inferred = true;
      r.names.add("var");
      r.nameStarts.add(pos());
      r.args.add(null);
      p++;
      r.end = prevEnd();
      lv.type = r;
    } else {
      lv.type = type();
    }
    declarators(lv.vars, m, lv.type);
    if (semicolon) expect(";");
    lv.end = prevEnd();
    return lv;
  }

  private Stmt statement() {
    int s = pos();
    if (is("{")) return block();
    if (k(0) == JavaLexer.KEYWORD) {
      String w = t(0);
      if (w == "if") {
        If st = new If();
        st.start = s;
        p++;
        st.cond = parenExpr();
        st.then = statement();
        if (accept("else")) st.otherwise = statement();
        st.end = prevEnd();
        return st;
      }
      if (w == "while") {
        While st = new While();
        st.start = s;
        p++;
        st.cond = parenExpr();
        st.body = statement();
        st.end = prevEnd();
        return st;
      }
      if (w == "do") {
        DoWhile st = new DoWhile();
        st.start = s;
        p++;
        st.body = statement();
        expect("while");
        st.cond = parenExpr();
        expect(";");
        st.end = prevEnd();
        return st;
      }
      if (w == "for") return forStatement();
      if (w == "try") return tryStatement();
      if (w == "switch" && !switchIsExpression()) {
        Switch st = new Switch();
        st.start = s;
        p++;
        st.selector = parenExpr();
        switchBody(st.cases);
        st.end = prevEnd();
        return st;
      }
      if (w == "return") {
        Return st = new Return();
        st.start = s;
        p++;
        if (!is(";")) st.value = expression();
        expect(";");
        st.end = prevEnd();
        return st;
      }
      if (w == "break" || w == "continue") {
        Jump st = new Jump();
        st.start = s;
        st.isBreak = w == "break";
        p++;
        if (k(0) == JavaLexer.IDENT) {
          st.labelStart = pos();
          st.label = ident();
        }
        expect(";");
        st.end = prevEnd();
        return st;
      }
      if (w == "throw") {
        Throw st = new Throw();
        st.start = s;
        p++;
        st.value = expression();
        expect(";");
        st.end = prevEnd();
        return st;
      }
      if (w == "synchronized") {
        Synchronized st = new Synchronized();
        st.start = s;
        p++;
        st.lock = parenExpr();
        st.body = block();
        st.end = prevEnd();
        return st;
      }
      if (w == "assert") {
        Assert st = new Assert();
        st.start = s;
        p++;
        st.cond = expression();
        if (accept(":")) st.message = expression();
        expect(";");
        st.end = prevEnd();
        return st;
      }
      if (w == "else" || w == "catch" || w == "finally" || w == "case" || w == "default") {
        unexpected();
        p++;
        return null;
      }
    }
    if (is(";")) {
      Empty e = new Empty();
      e.start = s;
      p++;
      e.end = prevEnd();
      return e;
    }
    if (k(0) == JavaLexer.IDENT && isAt(1, ":")) {
      Labeled st = new Labeled();
      st.start = s;
      st.labelStart = s;
      st.label = ident();
      p++;
      st.body = is("}") ? null : statement();
      st.end = prevEnd();
      return st;
    }
    if (is("}") || eof()) {
      unexpected();
      return null;
    }
    ExprStmt st = new ExprStmt();
    st.start = s;
    st.expr = expression();
    if (st.expr instanceof ErrorExpr && prevEnd() <= s) {
      unexpected();
      p++;
      return null;
    }
    expect(";");
    st.end = prevEnd();
    return st;
  }

  /** {@code switch (x) { ... }.foo()} or {@code switch ... ;} used as an expression statement. */
  private boolean switchIsExpression() {
    return false;
  }

  private Expr parenExpr() {
    expect("(");
    Expr e = expression();
    expect(")");
    return e;
  }

  private Stmt forStatement() {
    int s = pos();
    p++;
    expect("(");
    int save = p;
    Modifiers m = is("final") || is("@") ? modifiers() : new Modifiers();
    boolean each = false;
    if (k(0) == JavaLexer.IDENT && t(0).equals("var") && k(1) == JavaLexer.IDENT && isAt(2, ":"))
      each = true;
    else {
      int q = scanType(p);
      each = q > 0 && kind[at(q)] == JavaLexer.IDENT && tx(q + 1) == ":";
    }
    if (each) {
      ForEach fe = new ForEach();
      fe.start = s;
      VarDecl v = new VarDecl();
      v.start = pos();
      v.mods = m;
      if (t(0).equals("var") && k(1) == JavaLexer.IDENT && isAt(2, ":")) {
        TypeRef r = new TypeRef();
        r.start = pos();
        r.inferred = true;
        r.names.add("var");
        r.nameStarts.add(pos());
        r.args.add(null);
        p++;
        r.end = prevEnd();
        v.type = r;
      } else {
        v.type = type();
      }
      v.nameStart = pos();
      v.name = ident();
      v.end = prevEnd();
      fe.var = v;
      expect(":");
      fe.iterable = expression();
      expect(")");
      fe.body = statement();
      fe.end = prevEnd();
      return fe;
    }
    For f = new For();
    f.start = s;
    if (!is(";")) {
      if (m.flags != 0 || !m.annotations.isEmpty() || isLocalVarDecl()) {
        f.init.add(localVars(m, pos(), false));
      } else {
        p = save;
        do {
          ExprStmt es = new ExprStmt();
          es.start = pos();
          es.expr = expression();
          es.end = prevEnd();
          f.init.add(es);
        } while (accept(","));
      }
    }
    expect(";");
    if (!is(";")) f.cond = expression();
    expect(";");
    if (!is(")")) {
      do {
        f.update.add(expression());
      } while (accept(","));
    }
    expect(")");
    f.body = statement();
    f.end = prevEnd();
    return f;
  }

  private Stmt tryStatement() {
    Try st = new Try();
    st.start = pos();
    p++;
    if (accept("(")) {
      while (!is(")") && !eof()) {
        int before = p;
        if (is("final") || is("@") || isLocalVarDecl()) {
          int s = pos();
          Modifiers m = modifiers();
          LocalVars lv = localVars(m, s, false);
          st.resources.addAll(lv.vars);
        } else {
          st.resources.add(expression());
        }
        if (!accept(";")) break;
        if (p == before) p++;
      }
      expect(")");
    }
    st.body = block();
    while (is("catch")) {
      Catch c = new Catch();
      c.start = pos();
      p++;
      expect("(");
      c.mods = modifiers();
      c.types.add(type());
      while (accept("|")) c.types.add(type());
      c.nameStart = pos();
      c.name = ident();
      expect(")");
      c.body = block();
      c.end = prevEnd();
      st.catches.add(c);
    }
    if (accept("finally")) st.fin = block();
    st.end = prevEnd();
    return st;
  }

  private void switchBody(List<Case> cases) {
    if (!accept("{")) {
      error(prevEnd(), prevEnd() + 1, "Missing '{'");
      return;
    }
    if (++depth > MAX_DEPTH) {
      p--;
      skipBalanced();
      depth--;
      return;
    }
    while (!is("}") && !eof()) {
      int before = p;
      if (is("case") || is("default") && (isAt(1, ":") || isAt(1, "->"))) {
        cases.add(caseClause());
      } else {
        Stmt s = blockStatement();
        if (s != null && !cases.isEmpty()) cases.get(cases.size() - 1).body.add(s);
      }
      if (p == before) p++;
    }
    expect("}");
    depth--;
  }

  private Case caseClause() {
    Case c = new Case();
    c.start = pos();
    if (accept("default")) {
      c.isDefault = true;
    } else {
      p++;
      do {
        if (accept("default")) c.isDefault = true;
        else c.labels.add(caseLabel());
      } while (accept(","));
      if (k(0) == JavaLexer.IDENT && t(0).equals("when")) {
        p++;
        c.guard = expression();
      }
    }
    if (accept("->")) {
      c.arrow = true;
      if (is("{")) c.body.add(block());
      else if (is("throw")) c.body.add(statement());
      else {
        ExprStmt es = new ExprStmt();
        es.start = pos();
        es.expr = expression();
        expect(";");
        es.end = prevEnd();
        c.body.add(es);
      }
    } else {
      expect(":");
      while (!is("case") && !(is("default") && (isAt(1, ":") || isAt(1, "->"))) && !is("}")
          && !eof()) {
        int before = p;
        Stmt s = blockStatement();
        if (s != null) c.body.add(s);
        if (p == before) p++;
      }
    }
    c.end = prevEnd();
    return c;
  }

  private Expr caseLabel() {
    int q = scanType(p);
    if (q > 0 && (kind[at(q)] == JavaLexer.IDENT || tx(q) == "(" && k(0) == JavaLexer.IDENT
        && Character.isUpperCase(t(0).charAt(0)) && isRecordPatternAhead(q))) return pattern();
    return conditional();
  }

  private boolean isRecordPatternAhead(int q) {
    // Point(int x, ...) / Point(var x) / Point(Inner(...)): first element is a type or ')'.
    int r = q + 1;
    if (tx(r) == ")") return true;
    int s = scanType(r);
    return s > 0 && (kind[at(s)] == JavaLexer.IDENT || tx(s) == "(");
  }

  private Pattern pattern() {
    Pattern pt = new Pattern();
    pt.start = pos();
    accept("final");
    if (k(0) == JavaLexer.IDENT && t(0).equals("var") && k(1) == JavaLexer.IDENT) {
      TypeRef r = new TypeRef();
      r.start = pos();
      r.inferred = true;
      r.names.add("var");
      r.nameStarts.add(pos());
      r.args.add(null);
      p++;
      r.end = prevEnd();
      pt.type = r;
    } else {
      pt.type = type();
    }
    if (accept("(")) {
      pt.nested = new ArrayList<>();
      while (!is(")") && !eof()) {
        int before = p;
        pt.nested.add(pattern());
        if (!accept(",")) break;
        if (p == before) p++;
      }
      expect(")");
      if (k(0) == JavaLexer.IDENT && !t(0).equals("when")) {
        pt.bindingStart = pos();
        pt.binding = ident();
      }
    } else if (k(0) == JavaLexer.IDENT) {
      pt.bindingStart = pos();
      pt.binding = ident();
    }
    pt.end = prevEnd();
    return pt;
  }

  // ───────────────────────────── expressions ─────────────────────────────

  private Expr expression() {
    if (++depth > MAX_DEPTH) {
      depth--;
      ErrorExpr e = new ErrorExpr();
      e.start = e.end = pos();
      skipExpressionTokens();
      return e;
    }
    Expr e = assignment();
    depth--;
    return e;
  }

  private void skipExpressionTokens() {
    int level = 0;
    while (!eof()) {
      String s = t(0);
      if (s == "(" || s == "[" || s == "{") level++;
      else if (s == ")" || s == "]" || s == "}") {
        if (level == 0) return;
        level--;
      } else if ((s == ";" || s == ",") && level == 0) return;
      p++;
    }
  }

  private Expr assignment() {
    if (lambdaAhead()) return lambda();
    Expr lhs = conditional();
    String op = null;
    int n = 1;
    String s = t(0);
    if (s == "=" || s == "+=" || s == "-=" || s == "*=" || s == "/=" || s == "%=" || s == "&="
        || s == "|=" || s == "^=" || s == "<<=") op = s;
    else if (s == ">" && adjacent(p)) {
      if (isAt(1, ">=")) {
        op = ">>=";
        n = 2;
      } else if (isAt(1, ">") && adjacent(p + 1) && isAt(2, ">=")) {
        op = ">>>=";
        n = 3;
      }
    }
    if (op == null) return lhs;
    p += n;
    Assign a = new Assign();
    a.start = lhs.start;
    a.op = op;
    a.target = lhs;
    a.value = expression();
    a.end = prevEnd();
    return a;
  }

  private Expr lambda() {
    Lambda l = new Lambda();
    l.start = pos();
    if (k(0) == JavaLexer.IDENT) {
      VarDecl v = new VarDecl();
      v.start = v.nameStart = pos();
      v.name = ident();
      v.end = prevEnd();
      l.params.add(v);
    } else {
      p++; // '('
      if (k(0) == JavaLexer.IDENT && (isAt(1, ",") || isAt(1, ")"))) {
        while (k(0) == JavaLexer.IDENT) {
          VarDecl v = new VarDecl();
          v.start = v.nameStart = pos();
          v.name = ident();
          v.end = prevEnd();
          l.params.add(v);
          if (!accept(",")) break;
        }
      } else {
        while (!is(")") && !eof()) {
          int before = p;
          VarDecl v = new VarDecl();
          v.start = pos();
          v.mods = modifiers();
          if (k(0) == JavaLexer.IDENT && t(0).equals("var") && k(1) == JavaLexer.IDENT) {
            p++; // implicit type
          } else {
            v.type = type();
            if (accept("...")) v.type.varargs = true;
          }
          v.nameStart = pos();
          v.name = ident();
          v.end = prevEnd();
          l.params.add(v);
          if (!accept(",")) break;
          if (p == before) p++;
        }
      }
      expect(")");
    }
    expect("->");
    l.body = is("{") ? block() : expression();
    l.end = prevEnd();
    return l;
  }

  private Expr conditional() {
    Expr c = binary(1);
    if (!is("?")) return c;
    p++;
    Conditional e = new Conditional();
    e.start = c.start;
    e.cond = c;
    e.whenTrue = lambdaAhead() ? lambda() : conditionalInner();
    expect(":");
    e.whenFalse = lambdaAhead() ? lambda() : conditionalInner();
    e.end = prevEnd();
    return e;
  }

  private Expr conditionalInner() {
    if (++depth > MAX_DEPTH) {
      depth--;
      ErrorExpr e = new ErrorExpr();
      e.start = e.end = pos();
      skipExpressionTokens();
      return e;
    }
    Expr e = conditional();
    depth--;
    return e;
  }

  private static int precedence(String op) {
    switch (op) {
      case "||":
        return 1;
      case "&&":
        return 2;
      case "|":
        return 3;
      case "^":
        return 4;
      case "&":
        return 5;
      case "==":
      case "!=":
        return 6;
      case "<":
      case ">":
      case "<=":
      case ">=":
      case "instanceof":
        return 7;
      case "<<":
      case ">>":
      case ">>>":
        return 8;
      case "+":
      case "-":
        return 9;
      case "*":
      case "/":
      case "%":
        return 10;
      default:
        return 0;
    }
  }

  private int opLength;

  private String binaryOp() {
    opLength = 1;
    String s = t(0);
    if (k(0) == JavaLexer.KEYWORD) return s == "instanceof" ? s : null;
    if (k(0) != JavaLexer.OP) return null;
    if (s == ">") {
      if (adjacent(p) && isAt(1, ">")) {
        if (adjacent(p + 1) && isAt(2, ">")) {
          if (adjacent(p + 2) && (isAt(3, ">=") || isAt(3, ">"))) return null;
          opLength = 3;
          return ">>>";
        }
        if (adjacent(p + 1) && isAt(2, ">=")) return null; // >>>=
        opLength = 2;
        return ">>";
      }
      if (adjacent(p) && isAt(1, ">=")) return null; // >>=
      return ">";
    }
    return precedence(s) > 0 ? s : null;
  }

  private Expr binary(int minPrec) {
    if (++depth > MAX_DEPTH) {
      depth--;
      ErrorExpr e = new ErrorExpr();
      e.start = e.end = pos();
      skipExpressionTokens();
      return e;
    }
    Expr left = unary();
    while (true) {
      String op = binaryOp();
      if (op == null) break;
      int prec = precedence(op);
      if (prec < minPrec) break;
      p += opLength;
      if (op == "instanceof") {
        InstanceOf io = new InstanceOf();
        io.start = left.start;
        io.operand = left;
        accept("final");
        int q = scanType(p);
        if (q > 0 && (kind[at(q)] == JavaLexer.IDENT || tx(q) == "(")) {
          io.pattern = pattern();
          io.type = io.pattern.type;
        } else {
          io.type = type();
        }
        io.end = prevEnd();
        left = io;
        continue;
      }
      Expr right = binary(prec + 1);
      Binary b = new Binary();
      b.start = left.start;
      b.op = op;
      b.left = left;
      b.right = right;
      b.end = prevEnd();
      left = b;
    }
    depth--;
    return left;
  }

  private Expr unary() {
    int s = pos();
    String w = t(0);
    if (k(0) == JavaLexer.OP && (w == "++" || w == "--" || w == "+" || w == "-" || w == "!"
        || w == "~")) {
      p++;
      Unary u = new Unary();
      u.start = s;
      u.op = w;
      u.operand = unaryNested();
      u.end = prevEnd();
      return u;
    }
    if (w == "(" && castAhead()) {
      Cast c = new Cast();
      c.start = s;
      p++;
      c.type = type();
      while (accept("&")) c.extraBounds.add(type());
      expect(")");
      c.operand = lambdaAhead() ? lambda() : unaryNested();
      c.end = prevEnd();
      return c;
    }
    return postfix(primary());
  }

  private Expr unaryNested() {
    if (++depth > MAX_DEPTH) {
      depth--;
      ErrorExpr e = new ErrorExpr();
      e.start = e.end = pos();
      skipExpressionTokens();
      return e;
    }
    Expr e = unary();
    depth--;
    return e;
  }

  private Expr primary() {
    int s = pos();
    int kd = k(0);
    if (kd >= JavaLexer.INT && kd <= JavaLexer.TEXT_BLOCK) {
      Literal l = new Literal();
      l.start = s;
      switch (kd) {
        case JavaLexer.INT:
          l.kind = LIT_INT;
          break;
        case JavaLexer.LONG:
          l.kind = LIT_LONG;
          break;
        case JavaLexer.FLOAT:
          l.kind = LIT_FLOAT;
          break;
        case JavaLexer.DOUBLE:
          l.kind = LIT_DOUBLE;
          break;
        case JavaLexer.CHAR:
          l.kind = LIT_CHAR;
          break;
        default:
          l.kind = LIT_STRING;
          break;
      }
      p++;
      l.end = prevEnd();
      return l;
    }
    if (kd == JavaLexer.ERROR) {
      ErrorExpr e = new ErrorExpr();
      e.start = s;
      p++;
      e.end = prevEnd();
      return e;
    }
    String w = t(0);
    if (kd == JavaLexer.KEYWORD) {
      if (w == "true" || w == "false" || w == "null") {
        Literal l = new Literal();
        l.start = s;
        l.kind = w == "null" ? LIT_NULL : LIT_BOOLEAN;
        p++;
        l.end = prevEnd();
        return l;
      }
      if (w == "this") {
        p++;
        if (is("(")) {
          Call c = new Call();
          c.start = s;
          c.name = "this";
          c.nameStart = s;
          arguments(c.args);
          c.argsEnd = prevEnd();
          c.end = prevEnd();
          return c;
        }
        This t = new This();
        t.start = s;
        t.end = prevEnd();
        return t;
      }
      if (w == "super") {
        p++;
        Super sup = new Super();
        sup.start = s;
        sup.end = prevEnd();
        if (is("(")) {
          Call c = new Call();
          c.start = s;
          c.name = "super";
          c.nameStart = s;
          arguments(c.args);
          c.argsEnd = prevEnd();
          c.end = prevEnd();
          return c;
        }
        return sup; // '.' and '::' are handled by postfix
      }
      if (w == "new") return creator(null);
      if (w == "switch") {
        SwitchExpr se = new SwitchExpr();
        se.start = s;
        p++;
        se.selector = parenExpr();
        switchBody(se.cases);
        se.end = prevEnd();
        return se;
      }
      if (isPrimitive(w) || w == "void") {
        TypeRef type = type();
        if (is(".") && isAt(1, "class")) {
          p += 2;
          ClassLit cl = new ClassLit();
          cl.start = s;
          cl.type = type;
          cl.end = prevEnd();
          return cl;
        }
        TypeExpr te = new TypeExpr();
        te.start = s;
        te.type = type;
        te.end = prevEnd();
        if (!is("::")) error(s, te.end, "Unexpected type");
        return te;
      }
    }
    if (w == "(" && kd == JavaLexer.OP) {
      Paren pe = new Paren();
      pe.start = s;
      p++;
      pe.inner = expression();
      expect(")");
      pe.end = prevEnd();
      return pe;
    }
    if (kd == JavaLexer.IDENT) {
      if (isAt(1, "<") || isAt(1, "[") && isAt(2, "]") || isAt(1, ".")) {
        int q = scanType(p);
        if (q > 0) {
          boolean hasGenericsOrDims = false;
          for (int i = p; i < q; i++)
            if (tx(i) == "<" || tx(i) == "[") {
              hasGenericsOrDims = true;
              break;
            }
          if (hasGenericsOrDims && tx(q) == "::") {
            TypeExpr te = new TypeExpr();
            te.start = s;
            te.type = type();
            te.end = prevEnd();
            return te;
          }
          if (hasGenericsOrDims && tx(q) == "." && tx(q + 1) == "class" && tx(q - 1) == "]") {
            TypeRef type = type();
            p += 2;
            ClassLit cl = new ClassLit();
            cl.start = s;
            cl.type = type;
            cl.end = prevEnd();
            return cl;
          }
        }
      }
      String id = ident();
      if (is("(")) {
        Call c = new Call();
        c.start = s;
        c.name = id;
        c.nameStart = s;
        arguments(c.args);
        c.argsEnd = prevEnd();
        c.end = prevEnd();
        return c;
      }
      Name n = new Name();
      n.start = s;
      n.id = id;
      n.end = prevEnd();
      return n;
    }
    unexpected();
    ErrorExpr e = new ErrorExpr();
    e.start = e.end = s;
    return e;
  }

  private Expr postfix(Expr e) {
    while (true) {
      if (is(".")) {
        p++;
        if (is("new")) {
          e = creator(e);
        } else if (is("this")) {
          p++;
          This t = new This();
          t.start = e.start;
          t.qualifier = e;
          t.end = prevEnd();
          e = t;
        } else if (is("class")) {
          p++;
          ClassLit cl = new ClassLit();
          cl.start = e.start;
          cl.type = typeOf(e);
          cl.end = prevEnd();
          e = cl;
        } else if (is("super")) {
          p++;
          Super sup = new Super();
          sup.start = e.start;
          sup.qualifier = e;
          sup.end = prevEnd();
          e = sup;
        } else {
          List<TypeRef> typeArgs = is("<") ? typeArgs() : null;
          int ns = pos();
          String name = ident();
          if (name.isEmpty()) {
            Select sel = new Select();
            sel.start = e.start;
            sel.target = e;
            sel.name = "";
            sel.nameStart = ns;
            sel.end = prevEnd();
            return sel;
          }
          if (is("(")) {
            Call c = new Call();
            c.start = e.start;
            c.target = e;
            c.typeArgs = typeArgs;
            c.name = name;
            c.nameStart = ns;
            arguments(c.args);
            c.argsEnd = prevEnd();
            c.end = prevEnd();
            e = c;
          } else {
            Select sel = new Select();
            sel.start = e.start;
            sel.target = e;
            sel.name = name;
            sel.nameStart = ns;
            sel.end = prevEnd();
            e = sel;
          }
        }
      } else if (is("[")) {
        p++;
        Index ix = new Index();
        ix.start = e.start;
        ix.array = e;
        ix.index = expression();
        expect("]");
        ix.end = prevEnd();
        e = ix;
      } else if (is("++") || is("--")) {
        Unary u = new Unary();
        u.start = e.start;
        u.op = t(0);
        u.postfix = true;
        u.operand = e;
        p++;
        u.end = prevEnd();
        e = u;
      } else if (is("::")) {
        p++;
        MethodRef mr = new MethodRef();
        mr.start = e.start;
        if (e instanceof TypeExpr) mr.typeTarget = ((TypeExpr) e).type;
        else mr.target = e;
        if (is("<")) typeArgs();
        mr.nameStart = pos();
        if (accept("new")) mr.name = "new";
        else mr.name = ident();
        mr.end = prevEnd();
        e = mr;
      } else {
        return e;
      }
    }
  }

  /** {@code a.b.C} written as an expression, reinterpreted as a type (for {@code .class}). */
  private static TypeRef typeOf(Expr e) {
    TypeRef r = new TypeRef();
    r.start = e.start;
    r.end = e.end;
    ArrayList<Expr> chain = new ArrayList<>();
    Expr x = e;
    while (x instanceof Select) {
      chain.add(0, x);
      x = ((Select) x).target;
    }
    if (x instanceof Name) {
      r.names.add(((Name) x).id);
      r.nameStarts.add(x.start);
      r.args.add(null);
    } else if (x instanceof TypeExpr) {
      return ((TypeExpr) x).type;
    }
    for (Expr s : chain) {
      r.names.add(((Select) s).name);
      r.nameStarts.add(((Select) s).nameStart);
      r.args.add(null);
    }
    return r;
  }

  private void arguments(List<Expr> into) {
    p++; // '('
    while (!is(")") && !eof()) {
      int before = p;
      into.add(expression());
      if (!accept(",")) break;
      if (p == before) p++;
    }
    expect(")");
  }

  private Expr creator(Expr outer) {
    int s = outer != null ? outer.start : pos();
    p++; // new
    if (is("<")) typeArgs();
    skipAnnotations();
    TypeRef type;
    if (k(0) == JavaLexer.KEYWORD && isPrimitive(t(0))) {
      type = new TypeRef();
      type.start = pos();
      type.primitive = t(0);
      p++;
      type.end = prevEnd();
    } else if (k(0) == JavaLexer.IDENT) {
      type = new TypeRef();
      type.start = pos();
      while (true) {
        type.nameStarts.add(pos());
        type.names.add(ident());
        type.args.add(is("<") ? typeArgs() : null);
        if (is(".") && k(1) == JavaLexer.IDENT) {
          p++;
          continue;
        }
        break;
      }
      type.end = prevEnd();
    } else {
      unexpected();
      ErrorExpr e = new ErrorExpr();
      e.start = s;
      e.end = prevEnd();
      return e;
    }
    if (is("[")) {
      NewArray na = new NewArray();
      na.start = s;
      na.elementType = type;
      while (is("[")) {
        p++;
        if (accept("]")) {
          na.dims++;
        } else {
          na.dimExprs.add(expression());
          expect("]");
          na.dims++;
        }
      }
      if (is("{")) na.init = arrayInit();
      na.end = prevEnd();
      return na;
    }
    NewObject no = new NewObject();
    no.start = s;
    no.outer = outer;
    no.type = type;
    if (is("(")) arguments(no.args);
    else error(prevEnd(), prevEnd() + 1, "Missing '('");
    if (is("{")) {
      TypeDecl body = new TypeDecl();
      body.anonymous = true;
      body.kind = CLASS;
      body.start = pos();
      body.superclass = type;
      classBody(body);
      body.end = prevEnd();
      no.body = body;
    }
    no.end = prevEnd();
    return no;
  }

  private ArrayInit arrayInit() {
    ArrayInit init = new ArrayInit();
    init.start = pos();
    p++; // '{'
    while (!is("}") && !eof()) {
      int before = p;
      init.elements.add(is("{") ? arrayInit() : expression());
      if (!accept(",")) break;
      if (p == before) p++;
    }
    expect("}");
    init.end = prevEnd();
    return init;
  }
}
