package almlk;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * الأفعالُ التي تَحذِفُ الاستيراداتِ السقيمةَ: سِجلُّ عملياتٍ مَحدودةِ النطاقِ، تُطبَّقُ دفعةً واحدةً أو لا
 * تُطبَّقُ. الشكلُ مُستوحًى من سجلِّ الإصلاحِ عندَ المرجعِ (‏{@code com.aide.engine.Modification} بنوعِ
 * {@code REPLACE_TEXT_REGION(ملفٌّ:ن:ن:ن:ن)to(بديلٌ)}): المُحرِّكُ لا يَكتُبُ الملفَّ من جديدٍ بل يقولُ
 * «اِستبدِلْ هذا النطاقَ»، والموضِعُ مُرافِقٌ للسِجلِّ لا يُستَرَجَّعُ بعدَهُ.
 *
 * <p>حِراسةُ النصِّ الحيِّ: كلُّ عمليةٍ تَحمِلُ ما يجبُ أن يوجدَ عندَها بالضبطِ، فمتى تحرَّكَ السطرُ بينَ الفحصِ
 * والتنفيذِ رُفِضَت الخطةُ كلُّها (المرجعُ يَفعَلُ ذلكَ بحقلِ {@code expected} لإصلاحِ الصيغةِ؛ نُعمِّمُهُ على
 * ‏n عمليةٍ لأنَّ نصفَ دفعةٍ مَرفوضةٍ أضرُّ من كلِّها).
 *
 * <p>نقِيٌّ: لا {@code android.*}، ولا قرصَ — يَختبِرُهُ {@code qa.sh} فوقَ {@code almlk/} وحدَها.
 */
public final class ImportFixActions {

  /** كمَّ عمليةٍ في الدفعةِ؛ الزائدُ يُعَدُّ في {@link Plan#overflow} ويُطرَدُ. */
  public static final int MAX_OPS = 64;
  /** فوقَهُ لا يُخطَّطُ: النصُّ كبيرٌ، والقاعدةُ أُعيدَ تشغيلُها كاملةً أفضلُ من نصفِ دفعةٍ. */
  public static final int MAX_SOURCE_CHARS = 2 << 20;

  public static final String MODE_REMOVE = "remove";
  public static final String MODE_ORGANIZE = "organize";

  private ImportFixActions() {}

  /** عمليةٌ واحدةٌ: {@code [start,end)} تُستبدَلُ ب‏{@code text}، ولا تُطبَّقُ إلّا إذا وُجِدَ {@code expected}. */
  public static final class Op {
    public final int start;
    public final int end;
    public final String text;
    public final String expected;
    /** سببٌ قصيرٌ مُسمًّى: {@code unused}, {@code duplicate}, {@code redundant}, {@code organize}. */
    public final String reason;

    Op(int start, int end, String text, String expected, String reason) {
      this.start = Math.max(0, start);
      this.end = Math.max(this.start, end);
      this.text = text == null ? "" : text;
      this.expected = expected == null ? "" : expected;
      this.reason = reason == null ? "" : reason;
    }

    public int removedLength() {
      return end - start;
    }

    public int delta() {
      return text.length() - removedLength();
    }

    /** هل {@code source} لا يَزالُ يحملُ ما كُنَّاهُ سَنَ مسحَهُ؟ (البوابةُ كلُّها على هذا الشرطِ). */
    public boolean isConsistent(String source) {
      if (source == null || end > source.length()) return false;
      return source.regionMatches(start, expected, 0, expected.length())
          && start + expected.length() == end;
    }

    @Override
    public String toString() {
      return start + ".." + end + "→\"" + text + "\"(" + reason + ")";
    }
  }

  /** الدفعةُ: عملياتٌ مرتَّبةٌ صاعدةً لا تَتداخَلُ، وحالاتُها مُسمّاةٌ. */
  public static final class Plan {
    public final List<Op> ops;
    public final int dropped;
    public final int overflow;
    /** {@code empty}، {@code ok}، {@code too_large}، {@code overlapping}، {@code stale}، {@code no_source}. */
    public final String state;

    Plan(List<Op> ops, int dropped, int overflow, String state) {
      this.ops =
          ops == null
              ? Collections.<Op>emptyList()
              : Collections.unmodifiableList(new ArrayList<Op>(ops));
      this.dropped = Math.max(0, dropped);
      this.overflow = Math.max(0, overflow);
      this.state = state == null ? "empty" : state;
    }

    public boolean isEmpty() {
      return ops.isEmpty();
    }

    public int size() {
      return ops.size();
    }

    public boolean isApplicable() {
      return !ops.isEmpty() && "ok".equals(state);
    }

    /** هل تُنجِزُ الخطةُ شيئًا فعلًا؟ (نصٌّ بلا تغيُّرٍ لا يُسمَّى إصلاحًا). */
    public boolean changesText(String source) {
      if (!isApplicable()) return false;
      String applied = apply(source);
      return applied != null && !applied.equals(source);
    }

    /** النصُّ الجديدُ، أو {@code source} كما هو عندَ أيِّ انعدامِ تطابُقٍ — لا دفعةٌ جزئيّةٌ أبدًا. */
    public String apply(String source) {
      if (source == null || !isApplicable()) return source;
      for (Op op : ops) {
        if (!op.isConsistent(source)) return source;
      }
      StringBuilder out = new StringBuilder(source);
      for (int i = ops.size() - 1; i >= 0; i--) {
        Op op = ops.get(i);
        out.replace(op.start, op.end, op.text);
      }
      return out.toString();
    }

    /** صافيُ إزاحةِ {@code offset} بعدَ الدفعةِ (تُستعمَلُ لضبطِ المِرناءِ، فالمؤشِرُ يُضبَطُ بـ{@link #caretAfter}). */
    public int deltaBefore(int offset) {
      return caretAfter(offset) - offset;
    }

    /** أينَ يصيرُ {@code caret} بعدَ الدفعةِ؟ داخلَ مَحوٍ يَثبُتُ على أولِ المَحوِ، وخارجَهُ يَنزلقُ بقدرِهِ. */
    public int caretAfter(int caret) {
      int out = caret;
      for (Op op : ops) {
        if (out >= op.end) out += op.delta();
        else if (out > op.start) out = op.start;
      }
      return Math.max(0, out);
    }

    /**
     * دمجُ الدفعةِ في عمليةٍ واحدةٍ على {@code source}: النطاقُ هو union الأسطرِ المَسحوبةِ بعدَ تَخلِيصِ
     * البادئةِ واللواحقِ المشتركةِ — فيُطبَّقُ بخطوةِ تراجعٍ واحدةٍ من المسارِ القائمِ {@code applyTokenInsertion}.
     */
    public QuickFix.Insertion asInsertion(String source) {
      if (!isApplicable() || source == null) return null;
      for (Op op : ops) {
        if (!op.isConsistent(source)) return null;
      }
      int first = ops.get(0).start;
      int last = ops.get(ops.size() - 1).end;
      String before = source.substring(first, last);
      StringBuilder built = new StringBuilder(before);
      for (int i = ops.size() - 1; i >= 0; i--) {
        Op op = ops.get(i);
        built.replace(op.start - first, op.end - first, op.text);
      }
      String after = built.toString();
      int lead = 0;
      while (lead < before.length() && lead < after.length() && before.charAt(lead) == after.charAt(lead)) lead++;
      int tail = 0;
      while (tail < before.length() - lead
          && tail < after.length() - lead
          && before.charAt(before.length() - 1 - tail) == after.charAt(after.length() - 1 - tail)) tail++;
      int start = first + lead;
      int end = last - tail;
      String middle = after.substring(lead, after.length() - tail);
      if (start == end && middle.isEmpty()) return null;
      return new QuickFix.Insertion(start, end, middle, start, start + middle.length());
    }

    /** خلاصةٌ للقائمةِ: عددُ الأسطرِ التي تَمسَحُها الدفعةُ (بلا نصِّ مستخدمٍ: الموردُ عندَ الواجهةِ). */
    public int removedLines() {
      int out = 0;
      for (Op op : ops) {
        if (op.text.isEmpty() && op.removedLength() > 0) out++;
      }
      return out;
    }

    public List<String> reasons() {
      ArrayList<String> out = new ArrayList<String>();
      for (Op op : ops) out.add(op.reason);
      return Collections.unmodifiableList(out);
    }

    @Override
    public String toString() {
      return state + "(" + ops.size() + " ops, dropped=" + dropped + ", overflow=" + overflow + ")";
    }
  }

  /** عددُ ما يُحسَبُ من حالاتٍ؛ كلُّ سقْفٍ يَمَسُّ عملًا يُعَدُّ هُنا فلا يُبطَلُ بلا أثَرٍ. */
  public static final class Tally {
    public int considered;
    public int removable;
    public int keptFirstDuplicate;
    public int outsideRegion;
    public int overlapping;
    public int overflow;

    public int planned() {
      return removable;
    }
  }

  /** نطاقُ السطرِ كاملًا من أولِهِ إلى ما بعدَ فاصلِهِ (فلا يبقى سطرٌ فارغٌ بعدَ المسحِ). */
  public static int[] lineRange(CharSequence source, int offset) {
    if (source == null || source.length() == 0) return new int[] {0, 0};
    int n = source.length();
    int at = Math.max(0, Math.min(n, offset));
    int start = at;
    while (start > 0 && source.charAt(start - 1) != '\n') start--;
    int end = at;
    while (end < n && source.charAt(end) != '\n') end++;
    if (end < n) end++;
    return new int[] {start, end};
  }

  /** هل لهذا القسمِ فعلَ حذفٍ؟ (الباقي يَحمِلُ صَفَّ الجَلبِ أو «Fix imports» القائمَ). */
  public static boolean isRemovable(int kind) {
    return kind == ImportSoundness.KIND_UNUSED
        || kind == ImportSoundness.KIND_DUPLICATE
        || kind == ImportSoundness.KIND_REDUNDANT;
  }

  /**
   * الخطةُ من حالاتِ الفحصِ: سطرٌ كاملٌ لكلِّ {@code unused}/{@code redundant}، ولِكلِّ {@code duplicate}
   * عدا أولِ ظهورٍ (الأولُ هو المَصدَرُ، والمسحُ كلُّهُ دفعةٌ واحدةٌ).
   */
  public static Plan planForIssues(String source, List<ImportSoundness.Issue> issues, Tally tally) {
    return planForIssues(source, issues, tally, 0, source == null ? 0 : source.length());
  }

  /** {@code from}/{@code to} نطاقُ الفحصِ التدريجيِّ: خارجَهُ تُرفَضُ الحالاتُ بعدَّها (لا صامتًا). */
  public static Plan planForIssues(
      String source, List<ImportSoundness.Issue> issues, Tally tally, int from, int to) {
    if (source == null || source.isEmpty()) return new Plan(null, 0, 0, "no_source");
    if (source.length() > MAX_SOURCE_CHARS) {
      if (tally != null) tally.overflow++;
      return new Plan(null, 0, 1, "too_large");
    }
    if (issues == null || issues.isEmpty()) return new Plan(null, 0, 0, "empty");
    int regionFrom = Math.max(0, Math.min(from, to));
    int regionTo = Math.max(regionFrom, Math.max(from, to));
    boolean partial = regionFrom > 0 || regionTo < source.length();
    ArrayList<Op> ops = new ArrayList<Op>();
    ArrayList<Integer> starts = new ArrayList<Integer>();
    int seen = 0;
    int dropped = 0;
    int overflow = 0;
    int overlapping = 0;
    for (ImportSoundness.Issue issue : issues) {
      if (issue == null) continue;
      if (tally != null) tally.considered++;
      if (!isRemovable(issue.kind)) continue;
      if (issue.kind == ImportSoundness.KIND_DUPLICATE) {
        seen++;
        if (seen <= 1) {
          if (tally != null) tally.keptFirstDuplicate++;
          continue;
        }
      }
      if (partial && !(issue.start >= regionFrom && issue.end <= regionTo)) {
        dropped++;
        if (tally != null) tally.outsideRegion++;
        continue;
      }
      int[] range = lineRange(source, issue.start);
      if (range[1] <= range[0] || range[1] > source.length()) {
        dropped++;
        continue;
      }
      if (ops.size() >= MAX_OPS) {
        overflow++;
        if (tally != null) tally.overflow++;
        continue;
      }
      if (intersects(ops, range[0], range[1])) {
        overlapping++;
        dropped++;
        if (tally != null) tally.overlapping++;
        continue;
      }
      ops.add(new Op(range[0], range[1], "", source.substring(range[0], range[1]), reason(issue.kind)));
      if (tally != null) tally.removable++;
    }
    if (ops.isEmpty()) {
      return new Plan(null, dropped, overflow, overlapping > 0 ? "overlapping" : "empty");
    }
    Collections.sort(ops, java.util.Comparator.comparingInt((Op op) -> op.start));
    return new Plan(ops, dropped, overflow, "ok");
  }

  static String reason(int kind) {
    if (kind == ImportSoundness.KIND_DUPLICATE) return "duplicate";
    if (kind == ImportSoundness.KIND_REDUNDANT) return "redundant";
    return "unused";
  }

  static boolean intersects(List<Op> ops, int start, int end) {
    for (Op op : ops) {
      if (start < op.end && op.start < end) return true;
    }
    return false;
  }

  /**
   * «Organize imports» بعدَ الجَلبِ: لا نسخةَ ثانيةً من المنسِّقِ — يُنادى {@link
   * JavaImportOrganizer#organize} ثمَّ يُغلَّفُ الناتجُ في عمليةٍ واحدةٍ. فإن لم يَتغيَّرْ شيءٌ فالحالةُ
   * {@code empty} بلا فعلٍ، ولا يُخطَّطُ لمِلفٍّ ناقصِ القراءةِ.
   */
  public static Plan organizeInto(String source, List<String> projectCandidates, int collapseThreshold) {
    if (source == null || source.isEmpty()) return new Plan(null, 0, 0, "no_source");
    if (source.length() > MAX_SOURCE_CHARS) return new Plan(null, 0, 1, "too_large");
    String organized = JavaImportOrganizer.organize(source, projectCandidates, collapseThreshold);
    return diff(source, organized == null ? source : organized, "organize");
  }

  /** أدنى عمليةٍ تُمَثِّلُ الفرقَ (تَخلِيصُ البادئةِ واللَّاحقةِ المشتركتينِ). */
  public static Plan diff(String before, String after, String reason) {
    String left = before == null ? "" : before;
    String right = after == null ? "" : after;
    if (left.equals(right)) return new Plan(null, 0, 0, "empty");
    int lead = 0;
    while (lead < left.length() && lead < right.length() && left.charAt(lead) == right.charAt(lead)) lead++;
    int tail = 0;
    while (tail < left.length() - lead && tail < right.length() - lead
        && left.charAt(left.length() - 1 - tail) == right.charAt(right.length() - 1 - tail)) tail++;
    int start = lead;
    int end = left.length() - tail;
    String text = right.substring(lead, right.length() - tail);
    String expected = left.substring(start, end);
    ArrayList<Op> ops = new ArrayList<Op>();
    ops.add(new Op(start, end, text, expected, reason == null ? "organize" : reason));
    return new Plan(ops, 0, 0, "ok");
  }
}
