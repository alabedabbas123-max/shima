package almlk;

import java.util.Arrays;

/**
 * متتبّع نطاقات جافا للتلوين — يميّز المتغيرات المحلية والبراميترات عن الحقول أثناء مرور الملوّن
 * السطري نفسه، بلا تحليل إضافي للملف.
 *
 * <p>مثل المرجع: الحقول «Identifier» (عنبري)، أما البراميترات والمتغيرات المحلية واسم الباني في
 * تعريفه فـ«Plain» — نفس لون أسماء الدوال في تعريفها.
 *
 * <p>الحالة تعبر الأسطر كلقطة ثابتة {@link State} تُحفظ مع نتيجة كل سطر، فتعمل آلية التقارب في
 * {@link LineStyler} كما هي: يُعاد تلوين ما بعد التعديل حتى تتطابق الحالة (مثلًا حتى نهاية الدالة
 * عند تغيير اسم براميتر).
 */
public final class JavaLocalScope {

  /** دور المعرّف بعد التصنيف. */
  public static final int ROLE_NONE = 0;
  /** براميتر أو متغير محلي (تعريفًا أو استعمالًا) — يُرسم Plain. */
  public static final int ROLE_LOCAL = 1;
  /** اسم الباني في تعريفه — يُرسم Plain مثل أسماء الدوال المعرَّفة. */
  public static final int ROLE_CONSTRUCTOR = 2;

  private static final int KIND_CLASS = 0;
  private static final int KIND_CODE = 1;
  private static final int KIND_LAMBDA_EXPR = 2;

  private static final int LAST_OTHER = 0;
  private static final int LAST_IDENT = 1; // معرف أو نوع بدائي
  private static final int LAST_TYPE_CLOSE = 2; // > الأنواع العامة، [] أو ...
  private static final int LAST_DOT = 3;
  private static final int LAST_CLOSE_PAREN = 4;
  private static final int LAST_NEW = 5;

  private static final int HEADER_NONE = 0;
  private static final int HEADER_METHOD = 1; // براميترات دالة/باني
  private static final int HEADER_STATEMENT = 2; // for / catch / try(...)

  private static final String[] NO_NAMES = new String[0];

  /** إطار أقواس ثابت (سلسلة مرتبطة غير قابلة للتعديل). */
  static final class Frame {
    final Frame parent;
    final int kind;
    final String[] names;
    final String className;
    final int parenBase;

    Frame(Frame parent, int kind, String[] names, String className, int parenBase) {
      this.parent = parent;
      this.kind = kind;
      this.names = names;
      this.className = className;
      this.parenBase = parenBase;
    }

    Frame withName(String name) {
      for (String existing : names) if (existing.equals(name)) return this;
      String[] grown = Arrays.copyOf(names, names.length + 1);
      grown[names.length] = name;
      return new Frame(parent, kind, grown, className, parenBase);
    }

    static boolean same(Frame a, Frame b) {
      while (a != b) {
        if (a == null || b == null) return false;
        if (a.kind != b.kind
            || a.parenBase != b.parenBase
            || !Arrays.equals(a.names, b.names)
            || !java.util.Objects.equals(a.className, b.className)) return false;
        a = a.parent;
        b = b.parent;
      }
      return true;
    }
  }

  /** لقطة ثابتة لحالة المتتبع في نهاية سطر. */
  public static final class State {
    final Frame top;
    final int parenDepth;
    final int lastKind;
    final boolean lastWasYield;
    final int headerKind;
    final boolean headerArmed;
    final boolean headerAwaitingBody;
    final int headerDepth;
    final String[] headerNames;
    final boolean classArmed;
    final String className;
    final boolean newArmed;
    final int newParenDepth;
    final boolean anonymousBodyNext;
    final String[] lambdaBodyNames;
    final boolean caseLabel;
    final boolean declaring;
    final boolean declaratorNext;

    State(JavaLocalScope s) {
      top = s.top;
      parenDepth = s.parenDepth;
      lastKind = s.lastKind;
      lastWasYield = s.lastWasYield;
      headerKind = s.headerKind;
      headerArmed = s.headerArmed;
      headerAwaitingBody = s.headerAwaitingBody;
      headerDepth = s.headerDepth;
      headerNames = s.headerNames;
      classArmed = s.classArmed;
      className = s.className;
      newArmed = s.newArmed;
      newParenDepth = s.newParenDepth;
      anonymousBodyNext = s.anonymousBodyNext;
      lambdaBodyNames = s.lambdaBodyNames;
      caseLabel = s.caseLabel;
      declaring = s.declaring;
      declaratorNext = s.declaratorNext;
    }

    /** تطابق بنيوي — شرط التقارب في الملوّن. */
    public static boolean same(State a, State b) {
      if (a == b) return true;
      if (a == null || b == null) return false;
      return a.parenDepth == b.parenDepth
          && a.lastKind == b.lastKind
          && a.lastWasYield == b.lastWasYield
          && a.headerKind == b.headerKind
          && a.headerArmed == b.headerArmed
          && a.headerAwaitingBody == b.headerAwaitingBody
          && a.headerDepth == b.headerDepth
          && Arrays.equals(a.headerNames, b.headerNames)
          && a.classArmed == b.classArmed
          && java.util.Objects.equals(a.className, b.className)
          && a.newArmed == b.newArmed
          && a.newParenDepth == b.newParenDepth
          && a.anonymousBodyNext == b.anonymousBodyNext
          && Arrays.equals(a.lambdaBodyNames, b.lambdaBodyNames)
          && a.caseLabel == b.caseLabel
          && a.declaring == b.declaring
          && a.declaratorNext == b.declaratorNext
          && Frame.same(a.top, b.top);
    }
  }

  // ---------------- الحالة القابلة للتعديل أثناء السطر ----------------
  private Frame top;
  private int parenDepth;
  private int lastKind = LAST_OTHER;
  private boolean lastWasYield;
  private int headerKind = HEADER_NONE;
  private boolean headerArmed;
  private boolean headerAwaitingBody;
  private int headerDepth = -1;
  private String[] headerNames = NO_NAMES;
  private boolean classArmed;
  private String className;
  private boolean newArmed;
  private int newParenDepth = -1;
  private boolean anonymousBodyNext;
  private String[] lambdaBodyNames;
  private boolean caseLabel;
  /** داخل جملة تعريف محلي: «,» في مستوى الجملة تفتح اسمًا تاليًا (int i = 0, n = 5;). */
  private boolean declaring;
  private boolean declaratorNext;

  // ---------------- سجلّ السطر الحالي (لإعادة تلوين براميترات lambda) ----------------
  private int[] styles;
  private int[] identStart = new int[16];
  private int[] identEnd = new int[16];
  private int[] identDepth = new int[16];
  private char[] identNext = new char[16];
  private String[] identWord = new String[16];
  private int identCount;
  private int[] groupOpen = new int[8];
  private int groupCount;
  private int lastGroupFrom = -1;
  private int lastGroupTo = -1;
  private int lastGroupDepth = -1;
  private int skipChars;

  /** بداية سطر: تحميل حالة نهاية السطر السابق (null = بداية الملف). */
  public void beginLine(State entry, int[] lineStyles) {
    styles = lineStyles;
    identCount = 0;
    groupCount = 0;
    lastGroupFrom = lastGroupTo = lastGroupDepth = -1;
    skipChars = 0;
    if (entry == null) {
      top = null;
      parenDepth = 0;
      lastKind = LAST_OTHER;
      lastWasYield = false;
      headerKind = HEADER_NONE;
      headerArmed = headerAwaitingBody = false;
      headerDepth = -1;
      headerNames = NO_NAMES;
      classArmed = false;
      className = null;
      newArmed = false;
      newParenDepth = -1;
      anonymousBodyNext = false;
      lambdaBodyNames = null;
      caseLabel = false;
      declaring = declaratorNext = false;
      return;
    }
    top = entry.top;
    parenDepth = entry.parenDepth;
    lastKind = entry.lastKind;
    lastWasYield = entry.lastWasYield;
    headerKind = entry.headerKind;
    headerArmed = entry.headerArmed;
    headerAwaitingBody = entry.headerAwaitingBody;
    headerDepth = entry.headerDepth;
    headerNames = entry.headerNames;
    classArmed = entry.classArmed;
    className = entry.className;
    newArmed = entry.newArmed;
    newParenDepth = entry.newParenDepth;
    anonymousBodyNext = entry.anonymousBodyNext;
    lambdaBodyNames = entry.lambdaBodyNames;
    caseLabel = entry.caseLabel;
    declaring = entry.declaring;
    declaratorNext = entry.declaratorNext;
  }

  /** نهاية سطر: لقطة ثابتة تُحفظ مع نتيجته. */
  public State endLine() {
    styles = null;
    return new State(this);
  }

  // ---------------- الأحداث ----------------

  /** كلمة مفتاحية (غير الأنواع البدائية). */
  public void keyword(String word) {
    boolean afterDot = lastKind == LAST_DOT;
    resolvePending('k', word);
    if (afterDot) { // Foo.class / this / super بعد نقطة
      lastKind = LAST_IDENT;
      return;
    }
    switch (word) {
      case "class":
      case "interface":
      case "enum":
      case "record":
        classArmed = true;
        className = null;
        break;
      case "for":
      case "catch":
      case "try":
        if (inCode()) {
          headerKind = HEADER_STATEMENT;
          headerArmed = true;
          headerNames = NO_NAMES;
        }
        break;
      case "new":
        newArmed = true;
        newParenDepth = -1;
        lastKind = LAST_NEW;
        lastWasYield = false;
        return;
      case "case":
      case "default":
        if (inCode()) caseLabel = true;
        break;
      default:
        break;
    }
    // var: نوع محلي مستنتج — ما بعده اسم متغير.
    lastKind = "var".equals(word) ? LAST_IDENT : LAST_OTHER;
    lastWasYield = false;
  }

  /**
   * كلمة سياقية (record/var/yield/sealed/permits) مستعملة اسمًا: بعد نوع أو نقطة، مثل
   * «void record(…)» أو «x.record» — تُعامل معرّفًا لا كلمة مفتاحية.
   */
  public boolean usedAsName(String word) {
    switch (word) {
      case "record":
      case "var":
      case "yield":
      case "sealed":
      case "permits":
        return lastKind == LAST_IDENT || lastKind == LAST_TYPE_CLOSE || lastKind == LAST_DOT;
      default:
        return false;
    }
  }

  /** نوع بدائي (int/void/…) — يُعامل كنوع يسبق اسمًا. */
  public void primitiveType() {
    resolvePending('t', null);
    lastKind = LAST_IDENT;
    lastWasYield = false;
  }

  /**
   * معرّف غير مفتاحي في [start,end) من السطر. يعيد دوره: محلي/براميتر، اسم باني، أو لا شيء.
   */
  public int identifier(char[] chars, int start, int end, String word) {
    resolvePending('i', word);
    int nextAt = skipSpaces(chars, end);
    char next = nextAt < chars.length ? chars[nextAt] : 0;
    char next2 = nextAt + 1 < chars.length ? chars[nextAt + 1] : 0;
    boolean afterDot = lastKind == LAST_DOT;
    boolean typeBefore = (lastKind == LAST_IDENT && !lastWasYield) || lastKind == LAST_TYPE_CLOSE;
    int role = ROLE_NONE;
    boolean continuation = declaratorNext;
    declaratorNext = false;
    if (continuation && !afterDot && (next == '=' && next2 != '=' || next == ',' || next == ';')) {
      // الاسم التالي في قائمة تعريف: «, n = …» في جملة أو في رأس for.
      if (inHeaderParams()) headerNames = append(headerNames, word);
      else if (inCode()) top = top.withName(word);
      recordIdentifier(start, end, word, next);
      lastKind = LAST_IDENT;
      lastWasYield = false;
      return ROLE_LOCAL;
    }

    if (classArmed && className == null && !afterDot) {
      className = word;
    } else if (next == 0 && !afterDot && classLevel()
        && (typeBefore || top != null && word.equals(top.className) && lastKind != LAST_NEW)) {
      // تعريف دالة/باني أقواسه في السطر التالي: يُسلَّح الرأس ويُلغى إن لم يأتِ «(».
      armMethodHeader();
      if (!typeBefore) role = ROLE_CONSTRUCTOR;
    } else if (next == '(') {
      if (!afterDot && classLevel()) {
        if (typeBefore) {
          armMethodHeader(); // تعريف دالة: «Type name(»
        } else if (top != null && word.equals(top.className) && lastKind != LAST_NEW) {
          armMethodHeader(); // تعريف باني: اسمه = اسم الصنف المحيط
          role = ROLE_CONSTRUCTOR;
        }
      }
    } else if (!afterDot && typeBefore && inHeaderParams()) {
      if (next == ',' || next == ')' || next == '=' || next == ':' || next == ';' || next == 0) {
        headerNames = append(headerNames, word);
        role = ROLE_LOCAL;
        declaring = headerKind == HEADER_STATEMENT;
      }
    } else if (!afterDot && typeBefore && inCode() && isDeclarationFollower(next, next2)) {
      // متغير محلي: «Type name =» أو «Type name;» … داخل جسم كود. داخل أقواس لا تُقبل «,»
      // (براميترات lambda المكتوبة تُعالج عند ->)، وتُقبل «)» و«&» لمطابقة instanceof.
      boolean insideParens = parenDepth > top.parenBase;
      if (!insideParens || next == ')' || next == '&' || next == 0) {
        top = top.withName(word);
        role = ROLE_LOCAL;
        declaring = !insideParens;
      }
    }
    if (role == ROLE_NONE && !afterDot && next != '(' && isLocalName(word)) role = ROLE_LOCAL;

    recordIdentifier(start, end, word, next);
    lastKind = LAST_IDENT;
    lastWasYield = "yield".equals(word);
    return role;
  }

  /** نص/رقم/تعليق توضيحي — رمز لا يسبق تعريفًا. */
  public void literal() {
    resolvePending('l', null);
    lastKind = LAST_OTHER;
    lastWasYield = false;
  }

  /** حرف ترقيم/عامل في الموضع i من السطر. */
  public void punctuation(char[] chars, int i) {
    if (skipChars > 0) {
      skipChars--;
      return;
    }
    char c = chars[i];
    char next = i + 1 < chars.length ? chars[i + 1] : 0;
    if (c == '-' && next == '>') {
      skipChars = 1;
      arrow(chars, i + 2);
      return;
    }
    if (c == '.' && next == '.' && i + 2 < chars.length && chars[i + 2] == '.') {
      skipChars = 2;
      resolvePending('.', null);
      lastKind = LAST_TYPE_CLOSE; // varargs: «String... args»
      return;
    }
    resolvePending(c, null);
    switch (c) {
      case '{':
        declaring = false;
        openBrace();
        lastKind = LAST_OTHER;
        break;
      case '}':
        declaring = false;
        closeBrace();
        lastKind = LAST_OTHER;
        break;
      case '(':
        if (headerArmed) {
          headerArmed = false;
          headerDepth = parenDepth;
          headerNames = NO_NAMES;
        }
        if (newArmed && newParenDepth < 0) newParenDepth = parenDepth;
        pushGroup();
        parenDepth++;
        lastKind = LAST_OTHER;
        break;
      case ')':
        parenDepth = Math.max(0, parenDepth - 1);
        popGroup();
        popLambdaExpressions(true);
        if (headerKind != HEADER_NONE && !headerArmed && !headerAwaitingBody
            && parenDepth == headerDepth) headerAwaitingBody = true;
        if (newArmed && newParenDepth == parenDepth) {
          newArmed = false;
          newParenDepth = -1;
          anonymousBodyNext = true;
        }
        lastKind = LAST_CLOSE_PAREN;
        break;
      case ';':
        declaring = false;
        if (!inHeaderParams()) {
          popLambdaExpressions(false);
          clearHeader();
          classArmed = false;
          newArmed = false;
          caseLabel = false;
        }
        lastKind = LAST_OTHER;
        break;
      case ',':
        popLambdaExpressions(false);
        if (declaring && (inHeaderParams() ? headerKind == HEADER_STATEMENT
            : inCode() && parenDepth == top.parenBase)) declaratorNext = true;
        lastKind = LAST_OTHER;
        break;
      case ':':
        if (next == ':') { // مرجع دالة «Type::new» / «obj::name»: ما بعده عضو كما بعد النقطة
          skipChars = 1;
          lastKind = LAST_DOT;
          break;
        }
        caseLabel = false;
        lastKind = LAST_OTHER;
        break;
      case '.':
        lastKind = LAST_DOT;
        break;
      case ']':
        lastKind = previousNonSpace(chars, i) == '[' ? LAST_TYPE_CLOSE : LAST_OTHER;
        break;
      case '>':
        lastKind = isGenericClose(chars, i) ? LAST_TYPE_CLOSE : LAST_OTHER;
        break;
      default:
        lastKind = LAST_OTHER;
        break;
    }
    lastWasYield = false;
  }

  // ---------------- منطق داخلي ----------------

  /** أول رمز بعد رأس انتهى/«new (…)»/«->»: يقرر الجسم المنتظر. */
  private void resolvePending(char token, String word) {
    if (headerAwaitingBody && token != '{') {
      if (headerKind == HEADER_METHOD) {
        // throws X, Y / default قيمة ⇒ ما زلنا ننتظر؛ «;» ⇒ دالة مجردة بلا جسم.
        if (token == ';' || token == '}' || token == '=') clearHeader();
      } else {
        // for/catch بلا أقواس: البراميتر مرئي في الإطار الحالي.
        if (top != null) for (String name : headerNames) top = top.withName(name);
        clearHeader();
      }
    }
    if (anonymousBodyNext && token != '{') anonymousBodyNext = false;
    if (lambdaBodyNames != null && token != '{') lambdaBodyNames = null;
    if (headerArmed && token != '(') clearHeader(); // «try {» أو رأس لم يُفتح
  }

  private void openBrace() {
    if (headerAwaitingBody) {
      push(KIND_CODE, headerNames, null);
      clearHeader();
    } else if (classArmed) {
      push(KIND_CLASS, NO_NAMES, className);
      classArmed = false;
      className = null;
    } else if (anonymousBodyNext) {
      anonymousBodyNext = false;
      push(KIND_CLASS, NO_NAMES, null);
    } else if (lambdaBodyNames != null) {
      String[] names = lambdaBodyNames;
      lambdaBodyNames = null;
      push(KIND_CODE, names, null);
    } else {
      push(KIND_CODE, NO_NAMES, null); // كتلة، تهيئة static، مصفوفة، switch…
    }
    caseLabel = false;
  }

  private void closeBrace() {
    while (top != null && top.kind == KIND_LAMBDA_EXPR) top = top.parent;
    if (top != null) top = top.parent;
    clearHeader();
    classArmed = false;
    newArmed = false;
    anonymousBodyNext = false;
    lambdaBodyNames = null;
    caseLabel = false;
  }

  private void push(int kind, String[] names, String name) {
    top = new Frame(top, kind, names, name, parenDepth);
  }

  /** «->»: براميترات lambda من آخر مجموعة أقواس أو من المعرف السابق، ثم الجسم. */
  private void arrow(char[] chars, int after) {
    if (caseLabel) { // case X -> … ليس lambda
      caseLabel = false;
      lastKind = LAST_OTHER;
      return;
    }
    String[] names = NO_NAMES;
    if (lastKind == LAST_CLOSE_PAREN && lastGroupFrom >= 0) {
      for (int k = lastGroupFrom; k < lastGroupTo; k++) {
        if (identDepth[k] != lastGroupDepth) continue;
        if (identNext[k] != ',' && identNext[k] != ')') continue;
        names = append(names, identWord[k]);
        paintPlain(identStart[k], identEnd[k]);
      }
    } else if (lastKind == LAST_IDENT && identCount > 0) {
      int k = identCount - 1;
      names = append(names, identWord[k]);
      paintPlain(identStart[k], identEnd[k]);
    }
    int bodyAt = skipSpaces(chars, after);
    if (bodyAt < chars.length && chars[bodyAt] == '{') {
      lambdaBodyNames = names;
    } else if (names.length > 0 && top != null) {
      push(KIND_LAMBDA_EXPR, names, null); // جسم تعبيري: ينتهي عند , أو ; أو ) المحيطة
    }
    lastKind = LAST_OTHER;
    lastWasYield = false;
  }

  private void popLambdaExpressions(boolean closingParen) {
    while (top != null && top.kind == KIND_LAMBDA_EXPR
        && (closingParen ? parenDepth < top.parenBase : parenDepth <= top.parenBase))
      top = top.parent;
  }

  private void armMethodHeader() {
    headerKind = HEADER_METHOD;
    headerArmed = true;
    headerAwaitingBody = false;
    headerNames = NO_NAMES;
  }

  private void clearHeader() {
    headerKind = HEADER_NONE;
    headerArmed = false;
    headerAwaitingBody = false;
    headerDepth = -1;
    headerNames = NO_NAMES;
  }

  private boolean inHeaderParams() {
    return headerKind != HEADER_NONE && !headerArmed && !headerAwaitingBody
        && parenDepth == headerDepth + 1;
  }

  private boolean inCode() {
    return top != null && top.kind != KIND_CLASS;
  }

  private boolean classLevel() {
    return top == null || top.kind == KIND_CLASS;
  }

  /**
   * هل الاسمُ محلِّيٌّ معلنٌ في النطاقِ الحالي؟ يُسألُ هذا عندَ ما بعدَ النقطة: فحقلُ المحلِّي سادةٌ
   * عندَ المصدرِ لا معرِّفٌ عنبري («conf.locale» بيضاء)، بخلافِ حقلِ الصنفِ و«this.x» فهما معرِّفان.
   */
  public boolean isLocal(String word) {
    return word != null && isLocalName(word);
  }

  private boolean isLocalName(String word) {
    if (headerKind == HEADER_STATEMENT)
      for (String name : headerNames) if (name.equals(word)) return true; // for (int i…; i < n…
    for (Frame frame = top; frame != null; frame = frame.parent)
      for (String name : frame.names) if (name.equals(word)) return true;
    return false;
  }

  private static boolean isDeclarationFollower(char next, char next2) {
    switch (next) {
      case '=':
        return next2 != '=';
      case ':':
        return next2 != ':';
      case ';':
      case ',':
      case ')':
      case '&':
      case 0: // «Type name» في آخر السطر داخل كود: تعريف يكمل في السطر التالي
        return true;
      case '[':
        return next2 == ']'; // صيغة C: «int tab[] = …»
      default:
        return false;
    }
  }

  /** «>» ينهي نوعًا عامًا إن التصق بما قبله ولم يلتصق بمعرف بعده (a>b تبقى مقارنة). */
  private static boolean isGenericClose(char[] chars, int i) {
    int run = i;
    while (run > 0 && chars[run - 1] == '>') run--; // سلسلة >> : العبرة بما قبلها كلها
    if (run == 0) return false;
    char before = chars[run - 1];
    if (!(Character.isJavaIdentifierPart(before) || before == '?' || before == ']'))
      return false; // «a >> b» مسبوقة بمسافة: إزاحة لا نوع
    if (i + 1 >= chars.length) return true;
    char after = chars[i + 1];
    return after == ' ' || after == '\t' || after == '>' || after == '(' || after == '['
        || after == ',' || after == ')' || after == '.';
  }

  private static char previousNonSpace(char[] chars, int i) {
    for (int k = i - 1; k >= 0; k--) if (chars[k] != ' ' && chars[k] != '\t') return chars[k];
    return 0;
  }

  private static int skipSpaces(char[] chars, int from) {
    int k = from;
    while (k < chars.length && (chars[k] == ' ' || chars[k] == '\t')) k++;
    return k;
  }

  private static String[] append(String[] names, String name) {
    for (String existing : names) if (existing.equals(name)) return names;
    String[] grown = Arrays.copyOf(names, names.length + 1);
    grown[names.length] = name;
    return grown;
  }

  private void paintPlain(int start, int end) {
    if (styles == null) return;
    for (int k = Math.max(0, start); k < end && k < styles.length; k++) styles[k] = 0;
  }

  private void recordIdentifier(int start, int end, String word, char next) {
    if (identCount == identStart.length) {
      int size = identCount * 2;
      identStart = Arrays.copyOf(identStart, size);
      identEnd = Arrays.copyOf(identEnd, size);
      identDepth = Arrays.copyOf(identDepth, size);
      identNext = Arrays.copyOf(identNext, size);
      identWord = Arrays.copyOf(identWord, size);
    }
    identStart[identCount] = start;
    identEnd[identCount] = end;
    identDepth[identCount] = parenDepth;
    identNext[identCount] = next;
    identWord[identCount] = word;
    identCount++;
  }

  private void pushGroup() {
    if (groupCount == groupOpen.length) groupOpen = Arrays.copyOf(groupOpen, groupCount * 2);
    groupOpen[groupCount++] = identCount;
  }

  private void popGroup() {
    if (groupCount == 0) { // فُتحت في سطر سابق: لا مواضع لإعادة التلوين في هذا السطر
      lastGroupFrom = lastGroupTo = lastGroupDepth = -1;
      return;
    }
    lastGroupFrom = groupOpen[--groupCount];
    lastGroupTo = identCount;
    lastGroupDepth = parenDepth + 1;
  }
}
