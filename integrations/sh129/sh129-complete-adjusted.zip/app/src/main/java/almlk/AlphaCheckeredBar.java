package almlk;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.drawable.ColorDrawable;

/**
 * شريطُ اللونِ في سطرِ الدورِ بمُحرِّرِ الألوان: اللونُ نفسُهُ فوقَ **رقعةِ تعشيبٍ** رماديةٍ
 * وكاسية — وهي الآليّةُ التي بها تُظهِرُ صورةُ المصدرِ قيمةً شبهَ شفّافةٍ مثلَ {@code #10200000}
 * سطرًا مُرقَّطًا بدلَ أن تختفيَ على خلفيةِ الشاشة. قبلَ هذا كانَ السطرُ يضعُ اللونَ مباشرةً
 * ({@code setBackgroundColor}) فيُفقَدُ أثرُ الشفّافيةِ من العينِ ومن الصورة.
 *
 * <p>الرقعةُ تُرسَمُ أوّلًا ثمَّ يعلوها اللونُ بـ{@code super.draw}، لأنَّ الأبَ {@link ColorDrawable}
 * يعرفُ كيفَ يملأُ الحدودَ بالقيمةِ الجاريةِ وحده — فلا نسخةَ ثانيةً من منطقِ التلوين ولا مسارَ رسمٍ
 * غيرَ مسارِ الدهّانِ الواحد (البند 3.4). أمّا القرارُ — الحجمُ والتناوبُ ومتى تُرسَمُ الرقعةُ —
 * فمُجرَّدُ دوالَّ خالصةٍ في {@link AlphaCheckerPattern} تُختبَرُ بلا Android.
 */
public final class AlphaCheckeredBar extends ColorDrawable {

  private final Paint checker = new Paint();

  public AlphaCheckeredBar(int color) {
    super(color);
    checker.setStyle(Paint.Style.FILL);
    checker.setAntiAlias(false);
  }

  @Override
  public void draw(Canvas canvas) {
    int left = getBounds().left;
    int top = getBounds().top;
    int right = getBounds().right;
    int bottom = getBounds().bottom;
    int cell = AlphaCheckerPattern.cellSizeFor(bottom - top);
    if (cell > 0) {
      for (int y = top, row = 0; y < bottom; y += cell, row++) {
        for (int x = left, column = 0; x < right; x += cell, column++) {
          checker.setColor(AlphaCheckerPattern.cellColor(row, column));
          canvas.drawRect(x, y, Math.min(x + cell, right), Math.min(y + cell, bottom), checker);
        }
      }
    }
    super.draw(canvas);
  }

}
