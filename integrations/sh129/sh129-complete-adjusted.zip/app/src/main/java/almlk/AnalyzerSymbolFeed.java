package almlk;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

/**
 * تَجمِيعُ مَا نَبعَثُ بِهِ إِلَى ‏AnalysisConfig.addAndroidApiStaticMethod‏ — وَحدَهُ.
 *
 * <p>لِمَ هذَا الصِّنفُ وَحدَهُ: لِأنَّ الفِكرَةَ هُنَا لَا فِي ‏AnalyzerBridge‏ (الَّذي لَا
 * يُترجَمُ عَلى المُستَوضِفِ لِأنَّهُ يَحمِلُ ‏android.os‏)، وَالبَوَّابَةُ تَقيسُ هذِهِ
 * الجَدوَلَةَ بِعَينِهَا. قِسنَا قَبلَ الكِتَابَةِ (ج٥٠): قَرَارُهُم عَلى النِّدَاءِ يَبحَثُ
 * ‏owner#name‏ إِذَا كَانَ ‏owner‏ اِسمَ صِنفٍ (‏SemanticRules:105-109‏)، وَأَمّا النِّدَاءُ
 * عَبرَ مُتَغَيِّرٍ فَصَمتٌ — مُغَذًّى أَو لَا (‏m.toggleSoftInput(...)‏ أَرجَعَ صِفرًا بَعدَ
 * التَّغمِيذِ). فَالعَدلُ أَن نَغذُوَ بِالسَّاكِنِ فَحَسبُ، وَلَا نَمنَحَهُم حُكمًا عَلى صِيغَةٍ
 * لَا تُعنِيهِم.
 *
 * <p>ثَلاثَةُ احتِيَاطَاتٍ لِئَلَّا يَكونَ صَفُّنَا أَجرَأَ مِنَ المَعلُومِ:
 * <ol>
 *   <li><b>الحِملُ وَاحدٌ عَلى الاِسمِ</b>: هُم لَا يُمَيِّزُونَ تَحمِيلَاتِ الاِسمِ (overloads).
 *       لِذَلِكَ ‏since‏ = أَصغَرُهَا (أَضعَفُ دعوَى «يَطلُبُ مُستَوًى»)، وَإِن خَلَا تَحمِيلٌ
 *       مِنَ التَّركِ فَالدعوَى كُلُّهَا تَسقُطُ (‏deprecated = 0‏)، وَإِن تَعدَّدَت فَأكبَرُهَا
 *       (أَضعَفُ دعوَى «مَهجُورٌ»). تَحمِيلَانِ ‏(since 21, dep 0)‏ وَ‏(since 30, dep 33)‏
 *       ← «مَهجُورٌ» لَا تُقالُ، وَ«يَطلُبُ ٢١» تُقالُ — لَا العَكسَ.</li>
 *   <li><b>مَا وَرِثَهُ العُضوُ عَنِ الصِّنفِ لَيسَ خَبَرًا عَنهُ</b>: فَهرَسُنَا يَملاُ
 *       ‏member.deprecated‏ بِقَيمَةِ صَاحِبِهِ إِذَا لَم يُذكَر؛ فَإِرسَالُهَا صَفَّانِ عَلى
 *       نَفسِ الصَّفِّ (صِنفٌ مَهجُورٌ + عُضوٌ مَهجُورٌ). وَالتَّدبِيرُ: نَترُكُ إِرثَ الصِّنفِ
 *       وَحدَهُ — صَفٌّ عِندَ مَوضِعِ الاِستِعمَالِ بِقَدرِ مَا قَالَتِ المَكتَبَةُ.</li>
 *   <li><b>سَقفُهُم قَبلَ رَفعِهِم</b>: ‏sinceApi ∈ [1,10000]‏ و‏deprecatedApi ∈ [since,10000]‏
 *       (‏AnalysisConfig:98‏) — فَالمَجهُولُ (صِفرٌ) يُجعَلُ ١ لَا ٠، وَالحَدُّ يُقَصُّ، وَمَا
 *       انفَكَّ يُترَكُ لَا يُجرَّبُ.</li>
 * </ol>
 */
public final class AnalyzerSymbolFeed {

  /** سُطرٌ مِن فَهرَسِنَا، بِالشَّكلِ الَّذي يَقرَؤُهُ الجِسْرُ — بِلَا ‏AndroidApiIndex‏ هُنَا. */
  public static final class Member {
    public final String name;
    public final boolean isStatic;
    public final boolean isMethod;
    public final int since;
    public final int deprecated;
    /** هَل كُتِبَت هذِهِ المُستَوَيَاتُ لِلعُضوِ نَفسِهِ، أَم وَرِثَهَا عَنِ الصِّنفِ؟ */
    public final boolean ownLevels;

    public Member(String name, boolean isStatic, boolean isMethod, int since, int deprecated,
        boolean ownLevels) {
      this.name = name;
      this.isStatic = isStatic;
      this.isMethod = isMethod;
      this.since = since;
      this.deprecated = deprecated;
      this.ownLevels = ownLevels;
    }
  }

  /** صِنفٌ وَاحدٌ مُغَذًّى: مُستَوَيَاهُ + مَا صَحَّ مِن سَاكِنَاتِهِ. */
  public static final class Feed {
    public final String type;
    public final int since;
    public final int deprecated;
    /** ‏name → {since, deprecated}‏ بِالتَّجمِيعِ المُتَحَفِّظِ أعلَاهُ. */
    public final LinkedHashMap<String, int[]> statics;
    /** كَم عُدَّ مِن مُدخَلٍ (أَنوَاعٌ + سَاكِنَاتٌ) — لِلحِصَّةِ. */
    public final int entries;

    Feed(String type, int since, int deprecated, LinkedHashMap<String, int[]> statics, int entries) {
      this.type = type;
      this.since = since;
      this.deprecated = deprecated;
      this.statics = statics;
      this.entries = entries;
    }
  }

  public static final int MAX_API_LEVEL = 10_000;

  /** دَاخِلِيَّةٌ: تَحمِيلٌ بِلَا تَغمِيذٍ — يُبطِلُ دَعوَى التَّركِ عَلى الاِسمِ كُلِّهِ. */
  private static final int VOIDED = -1;

  /**
   * @param budget مَا بَقِيَ مِنَ الحِصَّةِ لِلمَجْمُوعِ (سَقفُهُم ٥٠ أَلفًا لِلأَنوَاعِ
   *     وَالسَّاكِنَاتِ جَمِيعًا)؛ ‏≤ 0‏ يَعنِي «لَا شَيءَ يُرسَلُ مِن هذَا الصِّنفِ».
   */
  public static Feed of(String fqcn, int ownerSince, int ownerDeprecated, List<Member> members,
      int budget) {
    if (fqcn == null || fqcn.isEmpty() || budget <= 0) return null;
    int since = clampLevel(ownerSince);
    int deprecated = clampDeprecated(ownerDeprecated, since);
    LinkedHashMap<String, int[]> statics = aggregate(members, since);
    int used = 1 + statics.size();
    if (used > budget) {
      // الحِصَّةُ تُغقِلُ البَابَ وَلَا تَقطَعُ وِسطَ الصِّنفِ: أَنوَاعٌ قَلِيلَةٌ كَامِلَةٌ
      // أَصدَقُ مِن صِنفٍ نِصفُ مَعلُومَاتِهِ — فَنِصفُ المَعلُومَةِ يَنقُصُ وَلا يُعلَنُ.
      return new Feed(fqcn, since, deprecated, new LinkedHashMap<String, int[]>(), 0);
    }
    return new Feed(fqcn, since, deprecated, statics, used);
  }

  /** تَجمِيعُ التَّحمِيلَاتِ عَلى الاِسمِ — الخَوَارِزمِيَّةُ كُلُّهَا هُنَا، لِتُقَاسَ وَحدَهَا. */
  public static LinkedHashMap<String, int[]> aggregate(List<Member> members, int ownerSince) {
    LinkedHashMap<String, int[]> out = new LinkedHashMap<String, int[]>();
    if (members == null) return out;
    for (Member m : members) {
      if (m == null || m.name == null || m.name.isEmpty()) continue;
      if (!m.isStatic || !m.isMethod) continue;
      if (!m.ownLevels) continue; // إِرثٌ مِنَ الصِّنفِ: صَفُّهُ يُقَالُ عِندَ الاِستِعمَالِ دُونَهُ
      int memberSince = clampLevel(m.since < ownerSince ? ownerSince : m.since);
      // ‏VOIDED‏ عَلَامَةٌ مُنفَصِلَةٌ عَنِ الصِّفرِ: بَطلَانُ الدَّعوَى لَا يَزُولُ بِتَدْفِيعَةٍ تَأتي
      // بَعدَها — وَإِلَّا رَجَعَ اللَّومُ مِمَّنْ اختَارَ التَّحمِيلَ الآمِنَ، وَهُوَ كَذِبٌ عَلَينَا.
      int[] acc = out.get(m.name);
      if (acc == null) {
        out.put(m.name,
            new int[] {memberSince, m.deprecated > 0 ? clampLevel(m.deprecated) : VOIDED});
        continue;
      }
      if (memberSince < acc[0]) acc[0] = memberSince;
      if (m.deprecated <= 0) {
        acc[1] = VOIDED;
      } else if (acc[1] != VOIDED) {
        int d = clampLevel(m.deprecated);
        if (d > acc[1]) acc[1] = d;
      }
    }
    for (java.util.Map.Entry<String, int[]> e : out.entrySet()) {
      int[] acc = e.getValue();
      acc[1] = clampDeprecated(acc[1] == VOIDED ? 0 : acc[1], acc[0]);
    }
    return out;
  }

  /** ٠ (مَجهُولٌ) ← ١؛ وَمَا فَوقَ حِدِّهِم ← الحِدُّ: لِأنَّ رَفعَهُم أَغلَظُ مِنَ الجَهَالَةِ. */
  public static int clampLevel(int value) {
    if (value <= 1) return 1;
    return value > MAX_API_LEVEL ? MAX_API_LEVEL : value;
  }

  /** ‏deprecated‏ عِندَهُم لَا يَنزِلُ عَنِ ‏since‏ — فَإِن نَزَلَ فَالمَعلُومَةُ مُتناقِضَةٌ: صِفرٌ. */
  public static int clampDeprecated(int value, int since) {
    if (value <= 0) return 0;
    int floor = clampLevel(since);
    if (value < floor) return 0;
    return value > MAX_API_LEVEL ? MAX_API_LEVEL : value;
  }

  /** مَا يُستَحقُّ الإِرسَالُ فَقط: صِفْرُ دَعوًى لَا تُطِيقُهَا وَاجِهَتُهُم. */
  public static List<String> describe(Feed feed) {
    ArrayList<String> out = new ArrayList<String>();
    if (feed == null) return out;
    out.add("T " + feed.type + " " + feed.since + " " + feed.deprecated);
    for (java.util.Map.Entry<String, int[]> e : feed.statics.entrySet()) {
      out.add("M " + feed.type + "#" + e.getKey() + " " + e.getValue()[0] + " " + e.getValue()[1]);
    }
    return out;
  }

  private AnalyzerSymbolFeed() {}
}
