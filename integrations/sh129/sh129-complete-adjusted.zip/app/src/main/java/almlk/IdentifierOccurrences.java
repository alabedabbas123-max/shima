package almlk;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * كلُّ مواضعَ الاسمِ لا موضعُهُ الأولُ — طبقةٌ صافيةٌ للجولةِ ‏24/2 (البندُ الذي طلبَهُ المصدرُ: «إشارةُ
 * الخطإِ على العنصرِ المكرَّرِ في جميعِ مواضعِ تواجدهِ لا في موضعٍ واحدٍ»).
 *
 * <p>من المرجعِ أُخِذَ التمييزُ بينَ أنواعِ المواضعِ: جدولُ أدوارِهِ {@code EnumC0058m} يَفصِلُ
 * {@code READ_ACCESS} عن {@code WRITE_ACCESS} عن التعريفِ، و{@code FileHighlightings} يَحمِلُ لكلِّ ملفٍّ
 * أربعةَ صفوفٍ مُتوازيةِ (سطرُ بدايةٍ، عمودُ بدايةٍ، سطرُ نهايةٍ، عمودُ نهايةٍ) معَ رقمِ مُنجِزٍ — أي أنَّ
 * العلامةَ عندهُ **مَداها** لا سطرُ الخطإِ وحدَهُ، وأنَّ المواضعَ كلَّها تُرسَلُ طائفةً واحدةً. ونحنُ نُبقي
 * البنيةَ نفسَها: صفوفٌ مُتوازيةٌ بأربعةِ أرقامٍ + دورٌ، لا كائناتٌ مُتفرقةٌ.
 *
 * <p>ولِذا تُطلَبُ هُنا المعرفةُ الصحيحةُ بالوراثةِ والمكتباتِ (البندُ الثاني من طلبِ الجولةِ): اسمٌ مَحلِّيّ
 * لا يُعَدُّ تكرارًا إذا كانَ لأبيهِ مثلُهُ، وصنفٌ مستوردٌ من مكتبةٍ مُحمَّلةٍ لا يَجبُ أن يُبلَغَ عن
 * استيرادِهِ «غيرَ موجودٍ»؛ فتُقبَلُ في {@link ImportSoundness} حَلُّوا أسماءَ من ثلاثِ طبقاتٍ: المشروعُ
 * والفهرسَ والمكتباتُ. هذا الملفُّ لا يَعرِفُ شيئًا من ذلكَ — حسابٌ على نصٍّ فقط، وهو ما يُبقيهِ صافيًا
 * ومُختبَرًا على {@code JVM}.
 *
 * <p>السقوفُ معلَنةٌ: {@link #MAX_SITES} موضعًا لكلِّ اسمٍ، و{@link #MAX_PROBLEMS} سِجلًّا؛ والزيادةُ
 * تُعدُّ ({@link #droppedCount()}) وتُسجَّلُ، لا تُطرَدُ صمتًا.
 */
public final class IdentifierOccurrences {

  /** موضعُ التعريفِ (اسمٌ يسبقُ قوسَ دالةٍ، أو نوعٌ قبلَهُ، أو حقلٌ بعدَهُ {@code =} أو {@code ;}). */
  public static final int OCC_DECLARATION = 0;
  /** قراءةٌ (الاسمُ لا يَليهِ {@code =} ولا {@code ++}/{@code --} ولا قوسُ نداءٍ). */
  public static final int OCC_READ = 1;
  /** كتابةٌ أو نداءٌ: {@code name =}، {@code name++}، {@code name(}. */
  public static final int OCC_WRITE = 2;

  public static final int MAX_SITES = 64;
  public static final int MAX_PROBLEMS = 4;
  /** أقصى ما يُمسَحُ من النصِّ في الطلبِ الواحدِ (فوقَهُ يُعلَنُ النطاقُ لا الصمتُ). */
  public static final int MAX_SCANNED_CHARS = 2 * 1024 * 1024;

  private IdentifierOccurrences() {}

  /** موضعٌ واحدٌ: إزاحتانِ ودورٌ — مُسطَّحٌ لأنَّ الجدولَ الذي يَستقبِلُهُ صفوفٌ أربعةٌ مُتوازيةٌ. */
  public static final class Site {
    public final int start;
    public final int end;
    public final int kind;

    Site(int start, int end, int kind) {
      this.start = start;
      this.end = end;
      this.kind = kind;
    }
  }

  /**
   * كلُّ مواضعِ {@code name} في {@code [from,to)}: يتخطى النصوصَ الحرفيةَ والتعليقاتِ (وإلا صارَ لكلِّ
   * كلمةٍ داخلَ تعليقٍ موضعٌ مُزيَّنٌ)، ويستعملُ حدودَ {@code IdentifierBounds} فلا يَقسِمُ {@code foo_bar}
   * إلى {@code foo}.
   *
   * @return ثلاثياتٌ مُسطَّحةٌ {@code {start,end,kind, …}}، فارغةٌ عندَ انعدامِ المواضعِ
   */
  public static int[] findAll(CharSequence text, String name, int from, int to) {
    return scan(text, name, from, to, 0).flat;
  }

  /** العددُ وحدَهُ، حينَ لا حاجةَ إلى المواضعِ (بوّابةُ «لا تكرارَ» تَكتفي بهِ). */
  public static int count(CharSequence text, String name) {
    return scan(text, name, 0, text == null ? 0 : text.length(), 0).count;
  }

  /** نتيجةُ مسحٍ: مواضعُ مُسطَّحةٌ، وعدٌّ، وسِجلّاتٌ إن قُطِعَ السقفُ. */
  public static final class Result {
    public final int[] flat;
    public final int count;
    public final List<String> problems;

    Result(int[] flat, int count, List<String> problems) {
      this.flat = flat == null ? new int[0] : flat;
      this.count = count;
      this.problems =
          problems == null
              ? Collections.<String>emptyList()
              : Collections.unmodifiableList(new ArrayList<>(problems));
    }

    public boolean isClipped() {
      return !problems.isEmpty();
    }
  }

  /** {@code limit} سقفٌ اختياريٌّ (صِفرٌ = {@link #MAX_SITES}). */
  public static Result scan(CharSequence text, String name, int from, int to, int limit) {
    List<String> notes = new ArrayList<>(2);
    ArrayList<int[]> found = new ArrayList<>(8);
    if (text == null || name == null || name.isEmpty()) return new Result(new int[0], 0, null);
    int cap = limit > 0 ? Math.min(limit, MAX_SITES) : MAX_SITES;
    int length = text.length();
    int start = Math.max(0, Math.min(from, length));
    int end = Math.max(start, Math.min(to, length));
    if (end - start > MAX_SCANNED_CHARS) {
      notes.add("occurrences limited to " + MAX_SCANNED_CHARS + " chars");
      end = start + MAX_SCANNED_CHARS;
    }
    int i = start;
    int skipped = 0;
    while (i < end) {
      char c = text.charAt(i);
      if (c == '/' && i + 1 < end && text.charAt(i + 1) == '/') {
        while (i < end && text.charAt(i) != '\n') i++;
        continue;
      }
      if (c == '/' && i + 1 < end && text.charAt(i + 1) == '*') {
        int close = text.toString().indexOf("*/", i + 2);
        i = close < 0 || close > end ? end : close + 2;
        continue;
      }
      if (c == '"' || c == '\'') {
        i = skipLiteral(text, i, end);
        continue;
      }
      if (!IdentifierBounds.isStart(c)) {
        i++;
        continue;
      }
      int tokenEnd = i + 1;
      while (tokenEnd < end && IdentifierBounds.isPart(text.charAt(tokenEnd))) tokenEnd++;
      if (tokenEnd - i == name.length() && matches(text, i, name)) {
        if (found.size() >= cap) {
          skipped++;
        } else {
          found.add(new int[] {i, tokenEnd, classify(text, i, tokenEnd, end)});
        }
      }
      i = tokenEnd;
    }
    if (skipped > 0) {
      notes.add("occurrences capped at " + cap + " (" + skipped + " dropped)");
    }
    int[] flat = new int[found.size() * 3];
    for (int k = 0; k < found.size(); k++) {
      flat[k * 3] = found.get(k)[0];
      flat[k * 3 + 1] = found.get(k)[1];
      flat[k * 3 + 2] = found.get(k)[2];
    }
    return new Result(flat, found.size() + skipped, notes);
  }

  /**
   * الكتابةُ والقراءةُ بمَا يَلي الاسمَ ({@code =} غيرَ {@code ==}، {@code ++}، قوسُ نداءٍ)، والتعريفُ
   * بمَا قبلَهُ: معرِّفُ نوعٍ أو واصفٌ يسبقُ الاسمَ مباشرةً لا {@code =} ولا نقطةٌ، والكلماتُ الحجزيةُ
   * مستثناةٌ (‏{@code return dup;} قراءةٌ لا تعريفٌ). الدورُ زينةٌ وتجميعٌ لا حكمُ ترجمةٍ: الخطأُ نفسَهُ
   * يقولُهُ الفاحصُ لا هذا الجدولُ، فالتسامحُ هنا مقصودٌ.
   */
  private static int classify(CharSequence text, int at, int after, int end) {
    if (looksLikeDeclaration(text, at)) return OCC_DECLARATION;
    int i = after;
    while (i < end && (text.charAt(i) == ' ' || text.charAt(i) == '\t')) i++;
    if (i >= end) return OCC_READ;
    char c = text.charAt(i);
    if (c == '(' || c == '[' || c == '.') return OCC_WRITE;
    if (c == '=') return i + 1 < end && text.charAt(i + 1) == '=' ? OCC_READ : OCC_WRITE;
    if (c == '+' || c == '-' || c == '!' || c == '&' || c == '|' || c == '^' || c == '*' || c == '%') {
      return i + 1 < end && (text.charAt(i + 1) == '=' || c == text.charAt(i + 1)) ? OCC_WRITE : OCC_READ;
    }
    if (c == ';') return OCC_DECLARATION;
    if (c == ',' || c == ':') return OCC_READ;
    if (c == '{' || c == '}') return OCC_DECLARATION;
    return OCC_READ;
  }

  /** هل يسبقُ الاسمَ معرِّفٌ ليس بكلمةٍ حجزيةٍ ولا نقطةً؟ إذنَا هذا موضعُ تعريفِهِ. */
  private static boolean looksLikeDeclaration(CharSequence text, int at) {
    int i = at - 1;
    while (i >= 0 && (text.charAt(i) == ' ' || text.charAt(i) == '\t' || text.charAt(i) == '\r')) i--;
    if (i < 0 || !IdentifierBounds.isPart(text.charAt(i))) return false;
    int wordEnd = i + 1;
    while (i >= 0 && IdentifierBounds.isPart(text.charAt(i))) i--;
    if (i >= 0 && text.charAt(i) == '.') return false; // x.dup استعلامٌ عن عضوٍ، لا إعلانٌ
    String word = text.subSequence(i + 1, wordEnd).toString();
    return !word.isEmpty() && !isDeclarationKeyword(word);
  }

  /** ما يَسبِقُ الاسمَ ولا يَجعلُهُ تعريفًا: كلماتُ الحجزِ التي تَليها تعبيراتٌ لا أنواعٌ. */
  private static boolean isDeclarationKeyword(String word) {
    switch (word) {
      case "return": case "if": case "while": case "for": case "else": case "case": case "new":
      case "instanceof": case "throws": case "throw": case "do": case "switch": case "catch":
      case "extends": case "implements": case "import": case "package": case "assert": case "in":
        return true;
      default:
        return false;
    }
  }

  /** تخطِّي نصٍّ حرفيٍّ (بما فيهِ \" ثلاثيُّ الأسطرِ) معَ احترامِ الشرطِ المائلةِ العكسيّةِ. */
  private static int skipLiteral(CharSequence text, int at, int end) {
    char quote = text.charAt(at);
    int i = at + 1;
    if (quote == '"' && i + 1 < end && text.charAt(i) == '"' && text.charAt(i + 1) == '"') {
      i += 2;
      while (i + 2 < end) {
        if (text.charAt(i) == '\\' && text.charAt(i + 1) == '"') {
          i += 2;
          continue;
        }
        if (text.charAt(i) == '"' && text.charAt(i + 1) == '"' && text.charAt(i + 2) == '"') return i + 3;
        i++;
      }
      return end;
    }
    while (i < end) {
      char c = text.charAt(i);
      if (c == '\\') {
        i += 2;
        continue;
      }
      if (c == '\n') return i; // نصٌّ غيرُ مُغلَقٍ: لا نبتلعُ الملفَّ كلَّهُ
      if (c == quote) return i + 1;
      i++;
    }
    return end;
  }

  private static boolean matches(CharSequence text, int at, String name) {
    for (int i = 0; i < name.length(); i++) {
      if (text.charAt(at + i) != name.charAt(i)) return false;
    }
    return true;
  }

  /**
   * تحويلُ المواضعِ إلى علاماتٍ جاهزةٍ للجدولِ: {@code {role,line,startColumn,endColumn,group}} لكلِّ موضعٍ
   * (السطرُ والعمودانِ بترقيمٍ واحدٍ أساسُهُ كما في {@code CodeLanguageTools.Diagnostic}). السطرُ يُحسَبُ من
   * جدولِ الأسطرِ نفسِهِ الذي يبنيهِ المُلوِّنُ، فلا انزياحَ بينَ ما يُرسَمُ وما يُختبَرُ.
   */
  public static int[] toMarks(CharSequence text, int[] flat, int role, int group) {
    if (flat == null || flat.length < 3) return new int[0];
    int[] out = new int[(flat.length / 3) * 5];
    int line = 1;
    int lineStart = 0;
    int at = 0;
    for (int k = 0; k < flat.length; k += 3) {
      int start = flat[k];
      while (at < start && at < text.length()) {
        if (text.charAt(at) == '\n') {
          line++;
          lineStart = at + 1;
        }
        at++;
      }
      int end = Math.max(start, flat[k + 1]);
      int endLine = line;
      int endLineStart = lineStart;
      int i = at;
      while (i < end && i < text.length()) {
        if (text.charAt(i) == '\n') {
          endLine++;
          endLineStart = i + 1;
        }
        i++;
      }
      int o = (k / 3) * 5;
      out[o] = role;
      out[o + 1] = line - 1;
      out[o + 2] = start - lineStart + 1;
      out[o + 3] = Math.max(out[o + 2] + 1, endLine == line ? end - lineStart + 1 : i - endLineStart + 1);
      out[o + 4] = group;
    }
    return out;
  }
  /**
   * النسخةُ المطابقةُ لحِملِ التشخيصِ: {@code starts}/{@code ends} مُتوازَيانِ بدلَ ثلاثياتٍ مُسطَّحةٍ،
   * لأنَّ المواضعَ تصلُ هكذا من عمليةِ التحليلِ. يمسحُ النصَّ مرةً واحدةً، فيبقى تحويلُ الإزاحاتِ إلى
   * أسطرٍ وأعمدةٍ على خيطِ الردِّ رخيصًا حتى في الملفِّ الكبيرِ.
   */
  public static int[] toMarks(CharSequence text, int[] starts, int[] ends, int role, int group) {
    if (text == null || starts == null || ends == null) return new int[0];
    int count = Math.min(starts.length, ends.length);
    if (count <= 0) return new int[0];
    int[] flat = new int[count * 3];
    for (int i = 0; i < count; i++) {
      flat[i * 3] = Math.max(0, Math.min(starts[i], text.length()));
      flat[i * 3 + 1] = Math.max(flat[i * 3] + 1, Math.min(ends[i], text.length()));
      flat[i * 3 + 2] = OCC_READ;
    }
    return toMarks(text, flat, role, group);
  }
}
