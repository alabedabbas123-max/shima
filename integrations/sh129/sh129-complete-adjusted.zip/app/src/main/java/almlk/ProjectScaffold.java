package almlk;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * هيكلُ المشروعِ عندَ الإنشاءِ — صافٍ ليُختبَرَ على المضيفِ لا بالعينِ على الجهازِ.
 *
 * <p>ثلاثُ مسائلَ أُغلِقَتْ هنا (طلبُ المستخدمِ على لقطةِ 1.0.157):
 * <ol>
 *   <li><b>الحزمةُ في المانيفستِ</b>: المرجعُ يكتبُ {@code package="com.my.app"} في وسمِ
 *       {@code <manifest>}، فاسمُ {@code .MainActivity} النسبيُّ يُحَلُّ منهُ، وتقرأُ أداتُنا نفسَها
 *       ذلكَ الوسمَ احتياطًا حينَ لا يكونُ {@code namespace} مُعرَّفًا
 *       (وسمُ `package` هو المسارُ الثاني للقراءةِ عندَ غيبةِ `namespace`). القالبُ لا يحملُ
 *       الطابعَ {@code $package_name$} هنا عمدًا: الدمجُ <b>مسارٌ واحدٌ</b> هو {@link
 *       #mergeManifestPackage} — فلا صيغةُ قالبٍ تُهمَلُ إن فُتِحَ المانيفستُ يدويًّا ولا ازدواجَ
 *       بينَ استبدالِ النصِّ وبينَ تصحيحِ البنيةِ.
 *   <li><b>وحدةُ المكتبةِ لا تُدمَجُ</b>: {@code ProcessLibraryManifest} في AGP 8 يُخطِئُ أيَّ
 *       {@code package=} في مانيفستِ مكتبةٍ («Setting the namespace via the package attribute … is
 *       no longer supported»)، بينما وحدةُ التطبيقِ تكتفي بتعليقِ إهمالٍ إذا ساوى {@code
 *       namespace}. فالقرارُ مُعلَنٌ لا مُضمَرٌ: {@link #wantsManifestPackage}.
 *   <li><b>دليلُ {@code build}</b>: المرجعُ يُريهُ في شجرةِ الوحدةِ؛ ومُخرَجُنا القياسيُّ {@code
 *       app/build/outputs/apk/<variant>} الذي يفتشُ فيهِ {@link BuildOutputLocator}، فخلقه عندَ
 *       الإنشاءِ يُزيحُ الفرقَ البصريَّ ولا يُغيِّرُ قرارَ البناءِ (AGP يُمسِكُ الدليلَ نفسَهُ).
 * </ol>
 *
 * <p>أمّا أسطرُ اعتمادياتِ المُنتقياتِ فمَسؤوليةُ {@link #missingDependencyLines}: تُعيدُ ما ليسَ
 * موجودًا فقطْ، والحقنُ نفسُهُ بـ{@link GradleDependencyEditor} — كاتبٌ واحدٌ لكتلةِ {@code
 * dependencies {}}، لا كاتبٌ ثانٍ في المعالجِ.
 */
public final class ProjectScaffold {

  private ProjectScaffold() {}

  /** هل يستحقُّ هذا القالبُ حزمةً في مانيفستِه؟ المكتبةُ (و«java» بلا مانيفستٍ) لا. */
  public static boolean wantsManifestPackage(String templateType) {
    if (templateType == null) return true; // قوالبُ قديمةٌ في JSON بلا حقلِ type: سلوكُ التطبيقِ
    String type = templateType.trim().toLowerCase(Locale.US);
    return !type.equals("library") && !type.equals("lib") && !type.equals("java");
  }

  /**
   * ادمجْ {@code package="pkg"} في وسمِ {@code <manifest …>} الافتتاحيِّ: أُدرِجَ إن غابَ، وصُحِّحَ
   * إن خالفَ، وتُُرِكَ النصُّ كما هو إن لم يكنْ مانيفستًا أو كانتِ الحزمةُ غيرَ صالحةٍ. عائدٌ idempotent:
   * استدعاءٌ ثانٍ لا يُكرِّرُ السمةَ ولا يُبدِّلُ شيئًا.
   */
  public static String mergeManifestPackage(String manifest, String pkg) {
    if (manifest == null || manifest.isEmpty()) return manifest;
    if (pkg == null || !ProjectNaming.isApplicationPackage(pkg)) return manifest;
    String wanted = pkg.trim();
    int tag = manifest.indexOf("<manifest");
    if (tag < 0) return manifest;
    int open = tag + "<manifest".length();
    int end = endOfOpenTag(manifest, open); // «>» داخل قيمةٍ مقتبسةٍ لا تُنهي الوسمَ
    if (end < 0) return manifest;
    String openTag = manifest.substring(open, end);
    String fixed = mergeIntoOpenTag(openTag, wanted);
    if (fixed.equals(openTag)) return manifest;
    return manifest.substring(0, open) + fixed + manifest.substring(end);
  }

  /** الصيغةُ الصحيحةُ لداخلِ وسمِ {@code <manifest …>} مع حزمةٍ بعينِها: إدراجٌ أو تصحيحٌ أو لا. */
  static String mergeIntoOpenTag(String openTag, String pkg) {
    int at = attributeAt(openTag, "package");
    if (at < 0) {
      String pad = openTag.isEmpty() || openTag.endsWith(" ") || openTag.endsWith("\n")
          || openTag.endsWith("\t") ? "" : " ";
      return pad + "package=\"" + pkg + "\"" + openTag;
    }
    int eq = openTag.indexOf('=', at + "package".length());
    if (eq < 0) return openTag;
    int i = eq + 1;
    while (i < openTag.length() && Character.isWhitespace(openTag.charAt(i))) i++;
    if (i >= openTag.length()) return openTag;
    char mark = openTag.charAt(i);
    if (mark == '"' || mark == '\'') {
      int close = openTag.indexOf(mark, i + 1);
      if (close < 0) return openTag;
      if (openTag.substring(i + 1, close).equals(pkg)) return openTag;
      return openTag.substring(0, i + 1) + pkg + openTag.substring(close);
    }
    int stop = i;
    while (stop < openTag.length()
        && !Character.isWhitespace(openTag.charAt(stop))
        && openTag.charAt(stop) != '>' && openTag.charAt(stop) != '/') stop++;
    // قيمةٌ بلا اقتباسٍ (مانيفستاتٌ يدويّةٌ قديمةٌ): تُكتَبُ مُقتبَسةً دائمًا — فقارئَا الأداتِ
    // و‏`almlk.AndroidManifestModel` — قارئُ الحزمةِ الوحيدُ — يطلبُ الاقتباسَ، وإلا
    // دُمِجَتِ الحزمةُ ولم تقرأْها أداتُها. وكونُها مُقتبَسةً صحيحةً من قبلُ = لا كتابةَ ثانيةً.
    String current = openTag.substring(i, stop);
    if (current.equals("\"" + pkg + "\"")) return openTag;
    return openTag.substring(0, i) + "\"" + pkg + "\"" + openTag.substring(stop);
  }

  /** {@code '>'} الواضحُ لهذا الوسمِ الافتتاحيِّ، أو -1 إن لم يُغلَقْ في النصِّ. */
  private static int endOfOpenTag(String text, int from) {
    boolean quote = false;
    char mark = 0;
    for (int i = from; i < text.length(); i++) {
      char c = text.charAt(i);
      if (quote) {
        if (c == mark) quote = false;
        continue;
      }
      if (c == '"' || c == '\'') {
        quote = true;
        mark = c;
      } else if (c == '>') return i;
    }
    return -1;
  }

  /** موضعُ بدايةِ اسمِ السمةِ {@code name} داخلَ نصِّ الوسمِ، أو -1 (الكلمةُ جزءٌ من اسمٍ أطولَ لا). */
  private static int attributeAt(String openTag, String name) {
    int from = 0;
    while (true) {
      int at = openTag.indexOf(name, from);
      if (at < 0) return -1;
      boolean leftOk = at == 0 || (!Character.isJavaIdentifierPart(openTag.charAt(at - 1))
          && openTag.charAt(at - 1) != ':');
      int after = at + name.length();
      boolean rightOk = after < openTag.length()
          && (Character.isWhitespace(openTag.charAt(after)) || openTag.charAt(after) == '=');
      if (leftOk && rightOk) return at;
      from = at + 1;
    }
  }

  /** أدلّةُ البناءِ القياسيّةُ للوحدةِ والجذرِ (بترتيبِ الخلقِ، وكلُّها تحتَ {@code build/}). */
  public static File[] buildDirs(File moduleDir, File projectRoot) {
    if (moduleDir == null) return new File[0];
    List<File> out = new ArrayList<File>();
    File moduleBuild = new File(moduleDir, "build");
    out.add(new File(moduleBuild, "outputs/apk/debug"));
    out.add(new File(moduleBuild, "outputs/apk/release"));
    out.add(new File(moduleBuild, "intermediates"));
    if (projectRoot != null && !projectRoot.equals(moduleDir)) {
      File rootBuild = new File(projectRoot, "build");
      out.add(new File(rootBuild, "outputs/apk/debug"));
      out.add(new File(rootBuild, "outputs/apk/release"));
    }
    return out.toArray(new File[out.size()]);
  }

  /** يُنشِئُها؛ العائدُ عددُ ما كانَ موجودًا قبلَها (0 = كلُّها جديدةٌ) — بوّابةُ العدِّ لا العينُ. */
  public static int ensureBuildDirs(File moduleDir, File projectRoot) {
    int existing = 0;
    for (File dir : buildDirs(moduleDir, projectRoot)) {
      if (dir.isDirectory()) {
        existing++;
        continue;
      }
      if (!dir.mkdirs() && !dir.isDirectory()) {
        // سباقٌ أو قرصٌ للقراءةِ فقطْ: لا يُفشَلُ إنشاءُ المشروعِ لأنَّ دليلَ مخرجاتٍ لم يُخلَقْ.
        continue;
      }
    }
    return existing;
  }

  // ===== مواضعُ القرصِ: يقرؤُها المعالجُ بعدَ نسخِ القالبِ، وتقرؤُها البوابةُ على مجلدٍ مؤقتٍ =====

  /** نصُّ الملفِّ بـUTF-8؛ سلسلةٌ فارغةٌ إن غابَ أو تعذَّرَ القراءةُ (لا استثناءَ يُفشِلُ الإنشاءَ). */
  public static String readText(File file) {
    if (file == null || !file.isFile()) return "";
    try (java.io.InputStream in = new java.io.FileInputStream(file)) {
      java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream((int) file.length() + 16);
      byte[] buf = new byte[8192];
      int n;
      while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
      return new String(out.toByteArray(), "UTF-8");
    } catch (Exception ignored) {
      return "";
    }
  }

  /** كتابةٌ بـUTF-8؛ false عندَ الفشلِ (القرصُ للقراءةِ فقطْ لا يُبطِلُ مشروعًا أُنشِئَ). */
  public static boolean writeText(File file, String text) {
    if (file == null) return false;
    File parent = file.getParentFile();
    if (parent != null && !parent.isDirectory()) parent.mkdirs();
    try (java.io.FileOutputStream out = new java.io.FileOutputStream(file)) {
      out.write(text.getBytes("UTF-8"));
      return true;
    } catch (Exception ignored) {
      return false;
    }
  }

  /**
   * الدمجُ الفعليُّ: اقرَأْ مانيفستَ الوحدةِ، وادمجْ {@code package=} بحزمةِ المشروعِ، واكتبِ
   * النتيجةَ إن تغيَّرتْ فقطْ. {@code wanted=false} (وحدةُ مكتبةٍ) ← لا مسَّ للملفِّ إطلاقًا.
   * العائدُ true إن كُتِبَ ملفٌّ.
   */
  public static boolean rewriteManifest(File manifest, String pkg, boolean wanted) {
    if (!wanted || manifest == null || !manifest.isFile()) return false;
    String text = readText(manifest);
    if (text.isEmpty()) return false;
    String merged = mergeManifestPackage(text, pkg);
    if (merged.equals(text)) return false;
    return writeText(manifest, merged);
  }

  /**
   * حقنُ أسطرِ المُنتقياتِ في {@code dependencies {}} بـ{@link GradleDependencyEditor} كاتبًا
   * وحدَهُ؛ يُتجَاهَلُ كلُّ سطرٍ موجودٍ، فلا يُلمَسُ الملفُّ إن لم ينقُصْ شيءٌ. العائدُ true إن كُتِبَ.
   */
  public static boolean injectDependencyLines(File buildFile, List<String> lines) {
    if (buildFile == null || !buildFile.isFile() || lines == null || lines.isEmpty()) return false;
    String text = readText(buildFile);
    if (text.isEmpty()) return false;
    List<String> missing = missingDependencyLines(text, lines, false);
    if (missing.isEmpty()) return false;
    return writeText(buildFile, GradleDependencyEditor.addDependencies(text, missing));
  }

  /** أسطرُ المُنتقياتِ التي لا وجودَ لها في نصِّ {@code build.gradle} — بلا تكرارٍ وبلا تغييرِ ترتيبٍ. */
  public static List<String> missingDependencyLines(
      String buildText, List<String> lines, boolean kts) {
    List<String> out = new ArrayList<String>();
    if (lines == null || lines.isEmpty()) return out;
    for (String line : lines) {
      if (line == null || line.trim().isEmpty()) continue;
      if (buildText != null && GradleDependencyEditor.containsDependency(buildText, line)) continue;
      out.add(line);
    }
    return out;
  }
}
