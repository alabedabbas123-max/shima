package almlk;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * مقارنة إصدارات Maven واختيار الإصدار الديناميكي (M2).
 *
 * <p>الترتيب على نهج Gradle/Maven: الأجزاء الرقمية تُقارن عدديًا، والمؤهّلات بالرتبة
 * dev &lt; alpha &lt; beta &lt; milestone &lt; rc &lt; snapshot &lt; (final/ga/release) &lt; sp، والمؤهّل
 * المجهول بعد الإصدار النهائي. «1.0» = «1.0.0»، و«1.0-alpha» &lt; «1.0» &lt; «1.0.1».
 * جافا خالصة بلا Android.
 */
public final class MavenVersion {

  private MavenVersion() {}

  /** سالب إن كان a أقدم من b، وصفر عند التساوي، وموجب إن كان أحدث. */
  public static int compare(String a, String b) {
    List<Object> x = tokens(a), y = tokens(b);
    int n = Math.max(x.size(), y.size());
    for (int i = 0; i < n; i++) {
      Object p = i < x.size() ? x.get(i) : null;
      Object q = i < y.size() ? y.get(i) : null;
      int c = compareItem(p, q);
      if (c != 0) return c;
    }
    return 0;
  }

  /** طلب ديناميكي يحتاج قائمة الإصدارات: {@code +} أو {@code 1.2.+} أو نطاق أو latest.*. */
  public static boolean isDynamic(String requested) {
    if (requested == null) return false;
    String r = requested.trim();
    if (exactRange(r) != null) return false;
    return r.endsWith("+") || r.startsWith("[") || r.startsWith("(") || r.equals("latest.release")
        || r.equals("latest.integration");
  }

  /**
   * {@code [1.2.3]} في Maven تعني «هذا الإصدار بالضبط» (نمط Play Services وFirebase القديمة)، فلا تحتاج
   * maven-metadata؛ يعيد الإصدار، أو null لغيرها.
   */
  public static String exactRange(String requested) {
    if (requested == null) return null;
    String r = requested.trim();
    if (r.length() < 3 || r.charAt(0) != '[' || r.charAt(r.length() - 1) != ']') return null;
    String inner = r.substring(1, r.length() - 1).trim();
    return inner.isEmpty() || inner.indexOf(',') >= 0 ? null : inner;
  }

  /** إصدار مستقر: لا alpha/beta/rc/snapshot/dev/milestone/preview/eap. */
  public static boolean isStable(String version) {
    for (Object token : tokens(version)) {
      if (token instanceof String && rank((String) token) < RANK_RELEASE) return false;
    }
    return true;
  }

  /**
   * يختار من القائمة الإصدار المطابق للطلب: {@code +}، أو {@code 1.2.+}، أو نطاق
   * {@code [1.0,2.0)}، أو {@code latest.release/integration}، أو إصدار ثابت كما هو. يُفضَّل
   * المستقر الأعلى، وإلا الأعلى عمومًا. null إن لم يطابق شيء.
   */
  public static String select(String requested, List<String> available) {
    if (requested == null) return null;
    String r = requested.trim();
    String bestStable = null, best = null;
    boolean integration = r.equals("latest.integration");
    for (String version : available) {
      if (!matches(r, version)) continue;
      if (best == null || compare(version, best) > 0) best = version;
      if (isStable(version) && (bestStable == null || compare(version, bestStable) > 0)) bestStable = version;
    }
    if (integration) return best;
    return bestStable != null ? bestStable : best;
  }

  /** هل يحقق الإصدار الطلبَ الديناميكي (أو يساويه إن كان ثابتًا)؟ */
  public static boolean matches(String requested, String version) {
    String r = requested.trim();
    if (r.equals("+") || r.equals("latest.integration")) return true;
    if (r.equals("latest.release")) return isStable(version);
    if (r.endsWith("+")) return version.startsWith(r.substring(0, r.length() - 1));
    if (r.startsWith("[") || r.startsWith("(")) return inRange(r, version);
    return compare(r, version) == 0;
  }

  /** نطاقات Maven: [a,b] [a,b) (a,b] (,b] [a,) و[a] الدقيق، ومجموعات مفصولة بفاصلة. */
  static boolean inRange(String range, String version) {
    // مجموعة نطاقات: [1,2),[3,4)
    List<String> parts = new ArrayList<>();
    int depth = 0, last = 0;
    for (int i = 0; i < range.length(); i++) {
      char c = range.charAt(i);
      if (c == '[' || c == '(') depth++;
      else if (c == ']' || c == ')') {
        depth--;
        if (depth == 0) {
          parts.add(range.substring(last, i + 1).trim());
          last = i + 1;
          while (last < range.length() && (range.charAt(last) == ',' || range.charAt(last) == ' ')) last++;
          i = last - 1;
        }
      }
    }
    for (String part : parts) if (inSingleRange(part, version)) return true;
    return false;
  }

  private static boolean inSingleRange(String range, String version) {
    if (range.length() < 2) return false;
    boolean lowerInclusive = range.charAt(0) == '[';
    boolean upperInclusive = range.charAt(range.length() - 1) == ']';
    String body = range.substring(1, range.length() - 1);
    int comma = body.indexOf(',');
    if (comma < 0) return compare(body.trim(), version) == 0; // [1.5]
    String lower = body.substring(0, comma).trim();
    String upper = body.substring(comma + 1).trim();
    if (!lower.isEmpty()) {
      int c = compare(version, lower);
      if (c < 0 || (c == 0 && !lowerInclusive)) return false;
    }
    if (!upper.isEmpty()) {
      int c = compare(version, upper);
      if (c > 0 || (c == 0 && !upperInclusive)) return false;
    }
    return true;
  }

  // ═══════════════ التقطيع والرتب ═══════════════

  private static final int RANK_RELEASE = 6;

  /** رتبة المؤهّل؛ المجهول بعد sp ثم يُقارن معجميًا. */
  static int rank(String qualifier) {
    switch (qualifier) {
      case "dev":
        return 0;
      case "a":
      case "alpha":
      case "eap":
      case "preview":
      case "pre":
        return 1;
      case "b":
      case "beta":
        return 2;
      case "m":
      case "milestone":
        return 3;
      case "rc":
      case "cr":
        return 4;
      case "snapshot":
        return 5;
      case "":
      case "final":
      case "ga":
      case "release":
        return RANK_RELEASE;
      case "sp":
        return 7;
      default:
        return 8;
    }
  }

  /** «1.2.0-beta01» → [1, 2, 0, beta, 1]. الفواصل . - _ + وانتقال رقم/حرف. */
  static List<Object> tokens(String version) {
    List<Object> out = new ArrayList<>();
    if (version == null) return out;
    String v = version.trim().toLowerCase(Locale.US);
    StringBuilder current = new StringBuilder();
    Boolean digits = null;
    for (int i = 0; i <= v.length(); i++) {
      char c = i < v.length() ? v.charAt(i) : '.';
      boolean separator = c == '.' || c == '-' || c == '_' || c == '+';
      boolean isDigit = Character.isDigit(c);
      if (separator || (digits != null && isDigit != digits && current.length() > 0)) {
        if (current.length() > 0) out.add(item(current.toString(), digits));
        current.setLength(0);
        digits = null;
        if (separator) continue;
      }
      current.append(c);
      digits = isDigit;
    }
    // إزالة الأصفار والإصدار النهائي الزائدة في الذيل: 1.0.0 = 1 ، 1.0-final = 1
    while (!out.isEmpty()) {
      Object tail = out.get(out.size() - 1);
      if ((tail instanceof BigInteger && ((BigInteger) tail).signum() == 0)
          || (tail instanceof String && rank((String) tail) == RANK_RELEASE)) {
        out.remove(out.size() - 1);
      } else {
        break;
      }
    }
    return out;
  }

  private static Object item(String text, Boolean digits) {
    if (Boolean.TRUE.equals(digits)) return new BigInteger(text);
    return text;
  }

  /** null = غياب الجزء (ذيل الإصدار الأقصر). */
  private static int compareItem(Object p, Object q) {
    if (p == null && q == null) return 0;
    if (p == null) return -compareItem(q, null);
    if (q == null) {
      if (p instanceof BigInteger) return ((BigInteger) p).signum() > 0 ? 1 : 0;
      return Integer.compare(rank((String) p), RANK_RELEASE); // 1.0-alpha < 1.0 < 1.0-sp
    }
    if (p instanceof BigInteger && q instanceof BigInteger) return ((BigInteger) p).compareTo((BigInteger) q);
    if (p instanceof BigInteger) return 1; // 1.0.1 > 1.0-rc
    if (q instanceof BigInteger) return -1;
    String a = (String) p, b = (String) q;
    int c = Integer.compare(rank(a), rank(b));
    return c != 0 ? c : a.compareTo(b);
  }
}
