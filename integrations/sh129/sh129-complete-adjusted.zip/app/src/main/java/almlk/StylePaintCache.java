package almlk;

import android.graphics.Paint;
import android.graphics.Typeface;
import java.util.HashMap;

/**
 * بند almlk ← دور حقول OConsole «f503VH / f534gn»: دهانات تُبنَى مرة واحدة لكل نمط
 * وتُستعمل في كل إطار — لا إنشاء Paint داخل onDraw إطلاقًا (واحد من أعمق أسباب سلاسة AIDE).
 */
public final class StylePaintCache {

  private final Typeface typeface;
  private final float textSize;
  private final HashMap<Long, Paint> byColorAndStyle = new HashMap<>();

  private final Paint gutter;
  private final Paint caret;
  private final Paint currentLine;
  private final Paint selection;
  private final Paint foldDot;
  private final Paint colorDecoration;

  private static final int STYLE_PLAIN = 0;
  private static final int STYLE_BOLD = 1;
  private static final int STYLE_UNDERLINE = 2;

  public StylePaintCache(Typeface typeface, float textSizePx) {
    this.typeface = typeface;
    this.textSize = textSizePx;
    gutter = decorate(new Paint(Paint.ANTI_ALIAS_FLAG), 0);
    caret = decorate(new Paint(), 0);
    currentLine = decorate(new Paint(), 0);
    selection = decorate(new Paint(), 0);
    foldDot = decorate(new Paint(), 0);
    colorDecoration = decorate(new Paint(Paint.ANTI_ALIAS_FLAG), 0);
  }

  private Paint decorate(Paint paint, int flags) {
    paint.setTypeface(typeface);
    paint.setTextSize(textSize);
    paint.setStyle(Paint.Style.FILL);
    return paint;
  }

  /**
   * دهانُ نصٍّ بلونٍ وعلامتَيهِ ({@link EditorSyntaxRoles#FLAG_BOLD} / {@link EditorSyntaxRoles#FLAG_ITALIC})
   * — كما في المصدر: غمقٌ مصطنعٌ {@code setFakeBoldText} وميلٌ {@code setTextSkewX} على خطِّ المحرِّرِ نفسه،
   * لا عائلةُ خطٍّ أخرى تُخِلُّ بعرضِ المحارفِ فيصطفُّ العمودُ خطأً. مُخزَّنٌ مفتاحُهُ لونٌ+علامةٌ فلا يُبنى
   *Paint داخلُ الرسمِ إطلاقًا.
   */
  public Paint text(int argb, int flags) {
    long key = (((long) flags) << 32) | (argb & 0xFFFFFFFFL);
    Paint paint = byColorAndStyle.get(Long.valueOf(key));
    if (paint == null) {
      paint = decorate(new Paint(Paint.ANTI_ALIAS_FLAG), flags);
      // كما في C0034x: أولًا نمطُ الخطِّ الحقيقيُّ للعائلة (Typeface.create)، ولا يُستدعى
      // المصطنعُ — غمقٌ أو ميلٌ بلا خطٍّ آخر — إلا حيث لا يوفرُ الخطُّ نفسُه ذلك النمطَ.
      // القرارُ كلُّه في {@link EditorEmphasisPolicy} الخالص، فيُختبرُ بلا Android.
      int style = EditorEmphasisPolicy.typefaceStyleFor(flags);
      if (style != EditorEmphasisPolicy.TYPEFACE_NORMAL) {
        paint.setTypeface(Typeface.create(typeface, style));
      }
      paint.setFakeBoldText(
          EditorEmphasisPolicy.useFakeBold(flags, typeface != null && typeface.isBold()));
      paint.setTextSkewX(
          EditorEmphasisPolicy.skewFor(flags, typeface != null && typeface.isItalic()));
      byColorAndStyle.put(Long.valueOf(key), paint);
    }
    paint.setColor(argb);
    return paint;
  }

  /** دهان خلفية ملوّنة (أشرطة أعلام السطور / التحديد): نمط واحد لكل لون. */
  public Paint fill(int argb) {
    int key = argb ^ STYLE_UNDERLINE;
    Paint paint = byColorAndStyle.get(key);
    if (paint == null) {
      paint = decorate(new Paint(), 0);
      byColorAndStyle.put(Long.valueOf(key), paint);
    }
    paint.setColor(argb);
    return paint;
  }

  public Paint gutter(int argb) {
    gutter.setColor(argb);
    return gutter;
  }

  public Paint caret(int argb) {
    caret.setColor(argb);
    return caret;
  }

  public Paint currentLine(int argb) {
    currentLine.setColor(argb);
    return currentLine;
  }

  public Paint selection(int argb) {
    selection.setColor(argb);
    return selection;
  }

  public Paint foldDot(int argb) {
    foldDot.setColor(argb);
    return foldDot;
  }

  /** دهان تعبئة لزخارف اللون؛ يبقى متاحًا لطبقات الرسم الممتلئة. */
  public Paint colorDecoration(int argb) {
    colorDecoration.setStyle(Paint.Style.FILL);
    colorDecoration.setColor(argb);
    return colorDecoration;
  }

  /**
   * دهان واحد متغير اللون لرسم خط تحت قيمة XML نفسها، بلا إنشاء Paint داخل onDraw.
   * يعاد ضبط النمط والعرض في كل استدعاء لأن الدهان مشترك بين كل القيم المرئية.
   */
  public Paint colorUnderline(int argb, float strokeWidthPx) {
    colorDecoration.setStyle(Paint.Style.STROKE);
    colorDecoration.setStrokeCap(Paint.Cap.BUTT);
    colorDecoration.setStrokeWidth(Math.max(1f, strokeWidthPx));
    colorDecoration.setColor(argb);
    return colorDecoration;
  }

  /** ينظّف الذاكرة المخزنة عند ضغط النظام — تُعاد البنية عند الطلب. */
  public void clear() {
    byColorAndStyle.clear();
  }
}
