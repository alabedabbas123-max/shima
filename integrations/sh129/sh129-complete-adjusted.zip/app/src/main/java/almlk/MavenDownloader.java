package almlk;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.util.Locale;

/**
 * نقل ملفات Maven عبر HTTP(S) أو من مجلد محلي (M2). بلا مكتبات: {@link HttpURLConnection} من
 * المنصة.
 *
 * <ul>
 *   <li>الكتابة إلى {@code .part} ثم إعادة تسمية ذرّية — لا ملف نصف منزَّل في المخزن أبدًا.
 *   <li>404/410/401/403 = «غير موجود في هذا المستودع» (يُجرَّب التالي)؛ غير ذلك خطأ شبكة يُعاد
 *       حتى مرتين.
 *   <li>تحقق {@code .sha1} للملفات الثنائية إن نشره المستودع.
 *   <li>الإلغاء يُفحص أثناء القراءة ويحذف {@code .part}.
 *   <li>قاطع دائرة: مضيف لا يُتّصل به (DNS أو رفض أو مهلة اتصال أو TLS) يُعلَّم ميتًا لبقية الجولة،
 *       فيُتخطى فورًا بدل 15 ثانية × 3 محاولات لكل ملف.
 *   <li>http العام يُجرَّب عبر https أولًا (Android يحجب النص الصريح)، ثم http الأصلي إن تعذّر.
 * </ul>
 */
public final class MavenDownloader implements MavenResolver.Fetcher {

  private static final int MAX_REDIRECTS = 5;
  /** فشلا اتصال على مستوى المضيف يكفيان لتعليمه ميتًا (DNS المجهول يكفي وحده). */
  private static final int DEAD_AFTER = 2;

  /** المضيف لا يُتّصل به في هذه الجولة: لا إعادة محاولة ولا انتظار. */
  static final class HostUnavailable extends IOException {
    HostUnavailable(String message) {
      super(message);
    }
  }

  /** آمن للخيوط (الحالة المشتركة متزامنة)، فيُسمح للمحلّل بأربعة تنزيلات معًا. */
  @Override
  public int parallelism() {
    return 4;
  }

  private final java.util.concurrent.ConcurrentHashMap<String, Integer> hostFailures =
      new java.util.concurrent.ConcurrentHashMap<>();
  private final java.util.Set<String> plainHttpHosts =
      java.util.Collections.newSetFromMap(new java.util.concurrent.ConcurrentHashMap<String, Boolean>());
  private final int connectTimeoutMs;
  private final int readTimeoutMs;
  private final int retries;

  public MavenDownloader() {
    this(15000, 30000, 2);
  }

  public MavenDownloader(int connectTimeoutMs, int readTimeoutMs, int retries) {
    this.connectTimeoutMs = connectTimeoutMs;
    this.readTimeoutMs = readTimeoutMs;
    this.retries = retries;
  }

  @Override
  public boolean fetch(String url, File target, boolean verify, MavenResolver.Progress progress) throws IOException {
    IOException last = null;
    for (int attempt = 0; attempt <= retries; attempt++) {
      checkCancelled(progress);
      try {
        if (!download(url, target, progress)) return false;
        if (!verify || matchesChecksum(url, target, progress)) return true;
        target.delete();
        last = new IOException("checksum mismatch: " + url);
      } catch (MavenResolver.Cancelled cancelled) {
        throw cancelled;
      } catch (HostUnavailable dead) {
        throw dead;
      } catch (IOException error) {
        last = error;
      }
      pause(progress, 400L * (attempt + 1));
    }
    throw last == null ? new IOException("download failed: " + url) : last;
  }

  /** نص صغير (sha1/metadata) في الذاكرة؛ null إن لم يوجد. */
  public byte[] fetchBytes(String url, MavenResolver.Progress progress) throws IOException {
    if (isLocal(url)) {
      File file = localFile(url);
      return file.isFile() ? readAll(new FileInputStream(file), -1, progress) : null;
    }
    HttpURLConnection connection = open(url, progress);
    if (connection == null) return null;
    try (InputStream in = connection.getInputStream()) {
      return readAll(in, connection.getContentLength(), progress);
    } finally {
      connection.disconnect();
    }
  }

  // ═══════════════ التنزيل ═══════════════

  private boolean download(String url, File target, MavenResolver.Progress progress) throws IOException {
    File parent = target.getParentFile();
    if (parent != null && !parent.isDirectory() && !parent.mkdirs()) throw new IOException("cannot create " + parent);
    File part = new File(target.getPath() + ".part");
    if (isLocal(url)) {
      File source = localFile(url);
      if (!source.isFile()) return false;
      copy(new FileInputStream(source), part, source.length(), progress);
      commit(part, target);
      return true;
    }
    HttpURLConnection connection = open(url, progress);
    if (connection == null) return false;
    try {
      copy(connection.getInputStream(), part, connection.getContentLength(), progress);
    } finally {
      connection.disconnect();
    }
    commit(part, target);
    return true;
  }

  /** يفتح الاتصال؛ http العام عبر https أولًا ثم الأصلي إن تعذّر الاتصال الآمن. */
  private HttpURLConnection open(String url, MavenResolver.Progress progress) throws IOException {
    String secure = secureVariant(url);
    if (secure == null) return openFollowing(url, progress);
    try {
      return openFollowing(secure, progress);
    } catch (MavenResolver.Cancelled cancelled) {
      throw cancelled;
    } catch (IOException insecureOnly) {
      plainHttpHosts.add(hostOf(url));
      return openFollowing(url, progress);
    }
  }

  /** نسخة https لعنوان http عام (لا للشبكة المحلية، ولا لمضيف ثبت أنه http فقط)؛ وإلا null. */
  public String secureVariant(String url) {
    if (!url.regionMatches(true, 0, "http://", 0, 7)) return null;
    String host = hostOf(url);
    if (host.isEmpty() || plainHttpHosts.contains(host) || isPrivateHost(host)) return null;
    return "https://" + url.substring(7);
  }

  public static boolean isPrivateHost(String host) {
    if (host.equals("localhost") || host.endsWith(".local") || host.startsWith("127.") || host.startsWith("10.")
        || host.startsWith("192.168.") || host.equals("[::1]") || host.indexOf('.') < 0) return true;
    if (host.startsWith("172.")) {
      String[] parts = host.split("\\.");
      try {
        int second = Integer.parseInt(parts[1]);
        return second >= 16 && second <= 31;
      } catch (RuntimeException notNumeric) {
        return false;
      }
    }
    return false;
  }

  /** نقطة الاتصال للقاطع: المضيف مع المنفذ الفعلي، فإغلاق 443 لا يُميت http على 80 للمضيف نفسه. */
  static String endpointOf(String url) {
    int scheme = url.indexOf("://");
    if (scheme < 0) return "";
    int start = scheme + 3;
    int end = start;
    while (end < url.length() && "/?#".indexOf(url.charAt(end)) < 0) end++;
    String authority = url.substring(start, end).toLowerCase(Locale.ROOT);
    int at = authority.lastIndexOf('@');
    if (at >= 0) authority = authority.substring(at + 1);
    int colon = authority.lastIndexOf(':');
    if (colon > 0 && authority.indexOf(']') < colon) return authority;
    return authority + (url.regionMatches(true, 0, "https", 0, 5) ? ":443" : ":80");
  }

  static String hostOf(String url) {
    int scheme = url.indexOf("://");
    if (scheme < 0) return "";
    int start = scheme + 3;
    int end = start;
    while (end < url.length() && "/?#".indexOf(url.charAt(end)) < 0) end++;
    String host = url.substring(start, end).toLowerCase(Locale.ROOT);
    int at = host.lastIndexOf('@');
    if (at >= 0) host = host.substring(at + 1);
    int colon = host.lastIndexOf(':');
    if (colon > 0 && host.indexOf(']') < colon) host = host.substring(0, colon);
    return host;
  }

  /** المضيف معلَّم ميتًا في هذه الجولة. */
  boolean isDead(String host) {
    Integer failures = hostFailures.get(host);
    return failures != null && failures >= DEAD_AFTER;
  }

  private void hostFailed(String host, IOException error) {
    // تعذّر الوصول نفسه (اسم مجهول، رفض، لا مسار، مهلة اتصال) يكفي مرة واحدة؛ أما بطء الرد فيُحتمل مرة.
    boolean readTimeout = error instanceof java.net.SocketTimeoutException
        && String.valueOf(error.getMessage()).toLowerCase(java.util.Locale.ROOT).contains("read");
    int weight = readTimeout ? 1 : DEAD_AFTER;
    hostFailures.merge(host, weight, Integer::sum);
  }

  /** فشل على مستوى الوصول للمضيف (لا رمز HTTP). */
  private static boolean isConnectFailure(IOException error) {
    return error instanceof java.net.UnknownHostException || error instanceof java.net.ConnectException
        || error instanceof java.net.NoRouteToHostException || error instanceof java.net.SocketTimeoutException
        || error instanceof javax.net.ssl.SSLException || error instanceof java.net.PortUnreachableException;
  }

  /** يفتح الاتصال ويتبع إعادة التوجيه (ومنها http↔https)؛ null = غير موجود. */
  private HttpURLConnection openFollowing(String url, MavenResolver.Progress progress) throws IOException {
    String current = url;
    for (int hop = 0; hop <= MAX_REDIRECTS; hop++) {
      checkCancelled(progress);
      String host = endpointOf(current);
      if (isDead(host)) throw new HostUnavailable("host unavailable: " + host);
      HttpURLConnection connection = (HttpURLConnection) new URL(current).openConnection();
      connection.setConnectTimeout(connectTimeoutMs);
      connection.setReadTimeout(readTimeoutMs);
      connection.setInstanceFollowRedirects(false);
      connection.setRequestProperty("User-Agent", "Shima-Maven/1.0");
      connection.setRequestProperty("Accept-Encoding", "identity");
      int code;
      try {
        code = connection.getResponseCode();
      } catch (IOException unreachable) {
        connection.disconnect();
        if (!isConnectFailure(unreachable)) throw unreachable;
        hostFailed(host, unreachable);
        if (isDead(host)) throw new HostUnavailable("host unavailable: " + host + " (" + unreachable + ")");
        throw unreachable;
      }
      hostFailures.remove(host);
      if (code == HttpURLConnection.HTTP_OK) return connection;
      if (code >= 300 && code < 400 && connection.getHeaderField("Location") != null) {
        current = new URL(new URL(current), connection.getHeaderField("Location")).toString();
        connection.disconnect();
        continue;
      }
      connection.disconnect();
      if (code == 404 || code == 410 || code == 401 || code == 403) return null;
      throw new IOException("HTTP " + code + " " + current);
    }
    throw new IOException("too many redirects: " + url);
  }

  private boolean matchesChecksum(String url, File target, MavenResolver.Progress progress) throws IOException {
    byte[] published;
    try {
      published = fetchBytes(url + ".sha1", progress);
    } catch (MavenResolver.Cancelled cancelled) {
      throw cancelled;
    } catch (IOException unavailable) {
      return true; // المستودع لم ينشر sha1 أو تعذّر جلبه: لا يُرفض الملف لأجله
    }
    if (published == null) return true;
    String expected = new String(published, "UTF-8").trim();
    int space = expected.indexOf(' ');
    if (space > 0) expected = expected.substring(0, space);
    if (!expected.matches("[0-9a-fA-F]{40}")) return true;
    return expected.toLowerCase(Locale.US).equals(sha1(target));
  }

  static String sha1(File file) throws IOException {
    try (InputStream in = new FileInputStream(file)) {
      MessageDigest digest = MessageDigest.getInstance("SHA-1");
      byte[] buffer = new byte[16384];
      int n;
      while ((n = in.read(buffer)) > 0) digest.update(buffer, 0, n);
      StringBuilder hex = new StringBuilder();
      for (byte b : digest.digest()) hex.append(String.format(Locale.US, "%02x", b));
      return hex.toString();
    } catch (java.security.NoSuchAlgorithmException impossible) {
      throw new IOException(impossible);
    }
  }

  /**
   * يُنهِضُ الملفَ المؤقَّتَ ولا يُسلِّمُهُ قبلَ أن يستوفيَ الطولَ المُعلَنَ: إغلاقٌ مبكّرٌ من خادمٍ
   * بعدَ آخرِ مِئراتِ البايتاتِ كانَ يُخْرِجُ ملفًّا **ناقصًا** باسمِ المكتبةِ نفسِهِ، فيُقبَلُ في
   * المخزنِ أبدَ الدهرِ وتُعلَنُ المكتبةُ «جاهزةً» وهوَ لا يُفتَتَحُ. أمّا بلا طولٍ مُعلَنٍ (chunked)
   * فالحُكمُ لفحصِ الأرشيفِ نفسِهِ في `LibraryInstallState` لا للطولِ وحدَهُ.
   */
  private static void copy(InputStream input, File part, long total, MavenResolver.Progress progress) throws IOException {
    boolean ok = false;
    long done = 0;
    try (InputStream in = input; OutputStream out = new FileOutputStream(part)) {
      byte[] buffer = new byte[32768];
      int n;
      while ((n = in.read(buffer)) > 0) {
        checkCancelled(progress);
        out.write(buffer, 0, n);
        done += n;
        if (progress != null) progress.bytes(done, total);
      }
      ok = true;
    } finally {
      if (!ok) part.delete();
    }
    if (total >= 0 && done != total) {
      part.delete();
      throw new IOException("incomplete download: " + done + " of " + total + " bytes");
    }
  }

  private static void commit(File part, File target) throws IOException {
    if (target.exists() && !target.delete()) {
      part.delete();
      throw new IOException("cannot replace " + target);
    }
    if (!part.renameTo(target)) {
      part.delete();
      throw new IOException("cannot move " + part + " → " + target);
    }
  }

  private static byte[] readAll(InputStream input, long total, MavenResolver.Progress progress) throws IOException {
    try (InputStream in = input) {
      ByteArrayOutputStream out = new ByteArrayOutputStream();
      byte[] buffer = new byte[8192];
      int n;
      while ((n = in.read(buffer)) > 0) {
        checkCancelled(progress);
        out.write(buffer, 0, n);
        if (out.size() > 8 * 1024 * 1024) throw new IOException("response too large");
      }
      return out.toByteArray();
    }
  }

  private static boolean isLocal(String url) {
    return url.startsWith("file:") || url.startsWith("/");
  }

  private static File localFile(String url) {
    return new File(url.startsWith("file:") ? url.replaceFirst("^file:(//)?", "") : url);
  }

  private static void checkCancelled(MavenResolver.Progress progress) {
    if ((progress != null && progress.cancelled()) || Thread.currentThread().isInterrupted()) {
      throw new MavenResolver.Cancelled();
    }
  }

  private static void pause(MavenResolver.Progress progress, long millis) {
    long end = System.currentTimeMillis() + millis;
    while (System.currentTimeMillis() < end) {
      checkCancelled(progress);
      try {
        Thread.sleep(50);
      } catch (InterruptedException interrupted) {
        Thread.currentThread().interrupt();
        throw new MavenResolver.Cancelled();
      }
    }
  }
}
