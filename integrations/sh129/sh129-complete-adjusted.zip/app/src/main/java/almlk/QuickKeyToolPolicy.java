package almlk;

/**
 * سياسةُ أداةِ الشريط: ماذا يحدثُ للمحرّر حين تُنقَرُ أداة.
 *
 * <p>الفصلُ بين «أيُّ نصٍّ يُكتَب» و«كيفَ يُطبَّقُ على الوثيقة» مقصودٌ: القرارُ هنا خالصٌ قابلٌ للقياس،
 * والتطبيقُ في المحرّر عبرَ {@code replaceRange} و{@code setSelection} — أي **نفسُ مسارِ الكتابة**، فلا يبقى
 * للشريطِ طريقٌ وللّوحةِ طريقٌ (وهو القصدُ من نقرِ المصدرِ الذي كان يُركِّبُ أحداثَ مفاتيح ولا يُدرجُ نصًّا).
 *
 * <p>القرارُ المنقولُ من {@code smartInsert} في المُغلِّف (بعد أن كان مسارًا موازيًا): الإقرانُ للأقواس،
 * والإقرانُ لفتحةِ الوسمِ في ملفاتِ الوسومِ وحدَها، وتخطّي القافِلِ الجاهز، والambangُ بينِ اقتباسين، وتخطّي
 * الهارب. **فرقٌ واحدٌ مُقصَد**: السهمُ لم يعد يحركُ المؤشّر خانةً، بل يطلبُ إزاحةٍ (Tab) كما في المصدر.
 */
public final class QuickKeyToolPolicy {

  /** استبدالٌ في الوثيقة ثم وضعُ المؤشّر. */
  public static final int KIND_INSERT = 0;

  /** تحريكُ المؤشّر فقط: لا نصَّ يُكتَب ولا خطوةُ تراجعٍ تُسجَّل. */
  public static final int KIND_MOVE_CARET = 1;

  /** السهم: إزاحةُ السطر/الكتلة — تُطبَّقُ بمنهَجِ مفتاح Tab في المحرّر نفسِه. */
  public static final int KIND_INDENT = 2;

  /** نتيجةُ القرار: ما يُستبَدَلُ وما يُدرَجُ وأين يستقرُّ المؤشّر. */
  public static final class Edit {
    public final int kind;
    public final int start;
    public final int end;
    public final String text;
    public final int selectionStart;
    public final int selectionEnd;

    Edit(int kind, int start, int end, String text, int selectionStart, int selectionEnd) {
      this.kind = kind;
      this.start = start;
      this.end = end;
      this.text = text;
      this.selectionStart = selectionStart;
      this.selectionEnd = selectionEnd;
    }

    public boolean isIndent() {
      return kind == KIND_INDENT;
    }

    public boolean movesCaretOnly() {
      return kind == KIND_MOVE_CARET;
    }
  }

  private QuickKeyToolPolicy() {}

  /**
   * @param text كاملُ نصِّ الوثيقة
   * @param rawStart أحدُ طرَفَيِ التحديد (قد يكون أكبرَ من الآخر)
   * @param rawEnd الطرفُ الآخر
   * @param token ما يُدرَج (رمزٌ من السلسلة، أو {@link QuickKeySequences#TAB_TOKEN} للسهم)
   * @param pairAngleBrackets هل تُعامَلُ {@code <} كفتحةِ وسمٍ تُقرَن — أي في ملفاتِ الوسومِ فقط
   */
  public static Edit plan(String text, int rawStart, int rawEnd, String token, boolean pairAngleBrackets) {
    int length = text == null ? 0 : text.length();
    // الحَدُّ الأعلى لازمٌ: التحديدُ قد يُقرأ بعدَ تعديلٍ قصَّ النصَّ، فلا يُترَكُ فهرسٌ يتجاوزُ طولَهُ.
    int start = Math.min(Math.max(0, Math.min(rawStart < 0 ? 0 : rawStart, rawEnd < 0 ? 0 : rawEnd)), length);
    int end = Math.min(Math.max(start, Math.max(rawStart, rawEnd)), length);
    if (token == null || token.isEmpty()) return caret(start);
    if (QuickKeySequences.TAB_TOKEN.equals(token)) {
      return new Edit(KIND_INDENT, start, end, "", start, start);
    }
    String closer = closerFor(token, pairAngleBrackets);
    if (closer != null) {
      boolean quote = token.equals("\"");
      if (quote && start == end && isEscaped(text, start)) return insert(start, start, token, start + 1, start + 1);
      if (quote && start == end && insideDoubleQuote(text, start)) {
        if (start < length && text.charAt(start) == '"') return caret(start + 1);
        return insert(start, start, token, start + 1, start + 1);
      }
      String selected = text == null ? "" : text.substring(start, end);
      String body = token + selected + closer;
      int inner = start + token.length();
      return insert(start, end, body, inner, inner + selected.length());
    }
    if (start == end
        && token.length() == 1
        && "})]>\"".indexOf(token.charAt(0)) >= 0
        && start < length
        && text.charAt(start) == token.charAt(0)) {
      return caret(start + 1);
    }
    return insert(start, end, token, start + token.length(), start + token.length());
  }

  /** القافِلُ الذي يُقرَنُ به الرمز، أو {@code null} إن لم تكن للأداة قرينة. */
  public static String closerFor(String token, boolean pairAngleBrackets) {
    if (token == null || token.length() != 1) return null;
    switch (token.charAt(0)) {
      case '{': return "}";
      case '(': return ")";
      case '[': return "]";
      case '"': return "\"";
      case '<': return pairAngleBrackets ? ">" : null;
      default: return null;
    }
  }

  /** هل الموضعُ خلفَ شرطةٍ مائلةٍ هاربةٍ (مفردةً كانت أو مزدوجةً)؟ */
  public static boolean isEscaped(CharSequence text, int offset) {
    int from = Math.min(Math.max(0, offset), text.length());
    int slashes = 0;
    for (int i = from - 1; i >= 0 && text.charAt(i) == '\\'; i--) slashes++;
    return (slashes & 1) != 0;
  }

  /** هل الموضعُ داخلُ زوجِ اقتباسٍ في سطرِهِ؟ (يُسبَقُ برسمِ التهرّب) */
  public static boolean insideDoubleQuote(CharSequence text, int offset) {
    boolean quoted = false;
    boolean escaped = false;
    int lineStart = Math.min(Math.max(0, offset), text.length());
    while (lineStart > 0 && text.charAt(lineStart - 1) != '\n') lineStart--;
    for (int i = lineStart; i < offset; i++) {
      char value = text.charAt(i);
      if (escaped) escaped = false;
      else if (value == '\\') escaped = true;
      else if (value == '"') quoted = !quoted;
    }
    return quoted;
  }

  private static Edit insert(int start, int end, String text, int selectionStart, int selectionEnd) {
    return new Edit(KIND_INSERT, start, end, text, selectionStart, selectionEnd);
  }

  private static Edit caret(int position) {
    return new Edit(KIND_MOVE_CARET, position, position, "", position, position);
  }
}
