package almlk;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * الاستبدال الجماعي (أدوات › أخرى › استبدال جماعي): يستبدل نصًا حرفيًا في ملف أو شجرة مجلد،
 * بمرشّح لواحق مفصول بـ «|»، ويتخطى مجلدات البناء والملفات الثنائية والكبيرة، ويكتب ذريًا.
 */
public final class BatchReplacer {

  private BatchReplacer() {}

  public static final long MAX_FILE_BYTES = 4L * 1024 * 1024;
  private static final Set<String> SKIPPED_DIRS =
      new HashSet<>(Arrays.asList(".git", ".gradle", ".idea", "build", ".kotlin", ".cxx"));

  /** نتيجة العملية: الملفات المعدّلة بمحتواها الجديد، وعدد المرات، والزمن. */
  public static final class Result {
    public final Map<File, String> changed = new LinkedHashMap<>();
    public int occurrences;
    public int scanned;
    public long millis;
    public final List<String> failures = new ArrayList<>();
  }

  /** «.java|.xml» ← [".java", ".xml"]؛ الفارغ = كل الملفات. */
  public static List<String> parseSuffixes(String filter) {
    ArrayList<String> out = new ArrayList<>();
    if (filter == null) return out;
    for (String part : filter.split("\\|")) {
      String s = part.trim().toLowerCase(Locale.ROOT);
      if (s.startsWith("*")) s = s.substring(1);
      if (!s.isEmpty()) out.add(s);
    }
    return out;
  }

  public static boolean accepts(String name, List<String> suffixes) {
    if (suffixes.isEmpty()) return true;
    String lower = name.toLowerCase(Locale.ROOT);
    for (String s : suffixes) if (lower.endsWith(s)) return true;
    return false;
  }

  public static Result replace(File target, String oldText, String newText, String filter, boolean subdirectories)
      throws IOException {
    if (oldText == null || oldText.isEmpty()) throw new IllegalArgumentException("Nothing to replace");
    if (target == null || !target.exists()) throw new IOException("Path does not exist");
    long start = System.nanoTime();
    Result result = new Result();
    List<String> suffixes = parseSuffixes(filter);
    String replacement = newText == null ? "" : newText;
    if (target.isFile()) {
      // الملف المحدد صراحةً يُعالَج حتى لو لم يطابق المرشّح.
      process(target, oldText, replacement, result);
    } else {
      walk(target, oldText, replacement, suffixes, subdirectories, result);
    }
    result.millis = (System.nanoTime() - start) / 1_000_000L;
    return result;
  }

  private static void walk(File dir, String oldText, String newText, List<String> suffixes, boolean recursive,
      Result result) {
    File[] children = dir.listFiles();
    if (children == null) return;
    Arrays.sort(children);
    for (File child : children) {
      if (Files.isSymbolicLink(child.toPath())) continue;
      if (child.isDirectory()) {
        if (recursive && !SKIPPED_DIRS.contains(child.getName())) {
          walk(child, oldText, newText, suffixes, true, result);
        }
      } else if (accepts(child.getName(), suffixes)) {
        process(child, oldText, newText, result);
      }
    }
  }

  private static void process(File file, String oldText, String newText, Result result) {
    if (file.length() > MAX_FILE_BYTES) return;
    result.scanned++;
    try {
      String text = readUtf8(file);
      if (text == null || !text.contains(oldText)) return;
      int count = 0;
      for (int at = text.indexOf(oldText); at >= 0; at = text.indexOf(oldText, at + oldText.length())) count++;
      String updated = text.replace(oldText, newText);
      writeAtomically(file, updated);
      result.occurrences += count;
      result.changed.put(file, updated);
    } catch (IOException e) {
      result.failures.add(file.getPath() + ": " + e.getMessage());
    }
  }

  /** UTF-8 صارم؛ null للملف الثنائي (ترميز غير صالح أو بايت صفري). */
  static String readUtf8(File file) throws IOException {
    byte[] bytes = Files.readAllBytes(file.toPath());
    for (byte b : bytes) if (b == 0) return null;
    try {
      return StandardCharsets.UTF_8.newDecoder()
          .onMalformedInput(CodingErrorAction.REPORT)
          .onUnmappableCharacter(CodingErrorAction.REPORT)
          .decode(ByteBuffer.wrap(bytes))
          .toString();
    } catch (CharacterCodingException binary) {
      return null;
    }
  }

  static void writeAtomically(File file, String text) throws IOException {
    File temp = new File(file.getParentFile(), "." + file.getName() + ".replace");
    try (FileOutputStream out = new FileOutputStream(temp)) {
      out.write(text.getBytes(StandardCharsets.UTF_8));
      out.getFD().sync();
    }
    if (!temp.renameTo(file)) {
      Files.write(file.toPath(), text.getBytes(StandardCharsets.UTF_8));
      temp.delete();
    }
  }
}
