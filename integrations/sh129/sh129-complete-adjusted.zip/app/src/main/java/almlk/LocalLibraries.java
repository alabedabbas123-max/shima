package almlk;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/**
 * ما في `libs/` من الوحدة: تُرصَدُ فيزيائيًّا وتُفهرَسُ محلّيًّا فورًا — بلا شبكةٍ ولا دورةِ
 * تنزيلٍ ولا انتظارِ `build.gradle`.
 *
 * <p>المكتبةُ التي يُلقيها المستخدمُ في `libs/` كانتْ لا تدخلُ المعرفةَ بالإكمالِ إلا إذا كتبَ
 * سطرَ `fileTree(dir: 'libs', …)` أو `files('libs/x.jar')`: أي أنَّ نصفَ العملِ (وضعُ الملفِّ)
 * كانَ ينتظرُ نصفَهُ الثاني (تحريرَ ملفِّ البناءِ)، مع أنَّ القرصَ قد أعطانا كلَّ ما يلزمُ
 * لمعرفةِ ما في الأرشيفِ. هنا تُقرأ `libs/` مباشرةً، ويُفرَزُ ما يصلُ للتحليلِ (jar وأرشيفاتِ
 * aar بمكوِّناتِها) عمّا لا يصلُهُ (نسخُ المصادرِ والتوثيقِ والملفاتُ الغريبةُ)، وتُعرَفُ
 * المكتبةُ التي لم يذكرْها `build.gradle` فلا تُباعَ للمستخدمِ على أنَّها في البناءِ.
 *
 * <p>عقدُ السرعةِ (محورُ «الخفّةِ» في طلبِ الجولةِ): لا اتصالَ بشيءٍ هنا إطلاقًا — لا HTTP ولا
 * `MavenDownloader` ولا Gradle؛ عملُ القرصِ الوحيدُ قائمةُ `libs/` ثمَّ فتحُ جدولِ وسطِ الأرشيفاتِ
 * عندَ الحاجةِ فقطْ؛ وبصمةُ الأسماءِ/الأحجامِ/أزمنةِ التعديلِ تحفظُ النتيجةَ فلا يُعادُ الفحصُ
 * ما لم يتغيّرِ القرصُ؛ والعدُّ محدودٌ بـ{@link #MAX_ENTRIES} فلا تُجمِّدُ مجلدًا فيه ألفُ أداةٍ
 * واجهةَ المحرِّرِ. فكُّ aar محليٍّ يمرُّ بـ{@link AarExploder} نفسِهِ — فيُستخدَمُ العقدُ نفسُهُ
 * في كلِّ مشروعٍ يُلقي بهِ ولا يُكرَرُ.
 *
 * <p>جافا خالصةٌ: تُترجِمُها `qa.sh` في خطِّ الصافيِّ، وتُقاسُ البوّاباتُ على قرصٍ مؤقَّتٍ.
 */
public final class LocalLibraries {

  /** سقْفُ ما يُقرأُ من `libs/` في الدورةِ الواحدةِ (الباقي مُعلَنٌ كمتروكٍ، لا مسكوتٌ عنهُ). */
  public static final int MAX_ENTRIES = 200;
  /** جذرُ العقدِ المحليّةِ داخلَ الوحدةِ — مجلدُ بناءٍ لا يلوّثُ شجرةَ المصدرِ. */
  public static final String EXPLODE_ROOT = "build/shima-libs";

  public static final int JAR = 0;
  public static final int AAR = 1;
  public static final int IGNORED = 2;

  /**
   * اصطلاحُ المرجعِ لمكتبةٍ تُرى للفحصِ ولا تُحمَلُ للتشغيلِ (‏`io.github.zeroaicy.aide.CompileOnlyJar`‏
   * بنَفسِ السُّؤالِ عنِ الاسمِ): ‏`libs/foo_compileonly.jar`‏ يُفهَرَسُ ويُبصَرُ في نِداءاتِ الشيفرةِ،
   * ولا يُدَّعَى أنَّهُ دَخَلَ البِناءَ — فبِهِ يُغلَقُ بابُ «الرمزُ مَجهولٌ لأنَّ المكتبةَ للتَّجرِبةِ
   * فقطْ»، بلا أن يَنزِلَ في APKِ ما لا يَنبَغي أن يَنزِلَ. والحُكمُ بالاسمِ لا بقِراءةِ ‏`build.gradle`‏.
   */
  public static final String COMPILE_ONLY_SUFFIX = "_compileonly.";

  public static final String REASON_SOURCE_OR_DOC = "sources/javadoc";
  public static final String REASON_NOT_ARCHIVE = "not a jar/aar";
  public static final String REASON_TOO_SMALL = "empty file";
  public static final String REASON_TOO_MANY = "over the scan limit";

  /** ماذا تعنيه الحالةُ للمحلِّلِ: لا خطأَ ولا تحذيرَ، بل حُكمٌ على ما يُفهرَسُ. */
  public static final class Entry {
    public final File file;
    public final int kind;
    public final String reason;
    /** ذُكِرَتْ في `build.gradle` (بسطرِ `files(...)` أو بـ`fileTree` يشملُ `libs/`). */
    public final boolean inBuildFile;

    Entry(File file, int kind, String reason, boolean inBuildFile) {
      this.file = file;
      this.kind = kind;
      this.reason = reason == null ? "" : reason;
      this.inBuildFile = inBuildFile;
    }

    public boolean indexed() {
      return kind != IGNORED;
    }

    /** في `libs/` ولا ذكرَ لها في ملفِّ البناءِ: تُعرَفُ، ولا تُدَّعَى ضمنَ البناءِ. */
    public boolean unlisted() {
      return indexed() && !inBuildFile;
    }

    /** ‏`*_compileonly.jar/aar`‏: للفحصِ والفهرسةِ، ولا تُنسَبُ إلى البِناءِ (اصطلاحُ المرجعِ). */
    public boolean compileOnly() {
      return indexed()
          && file.getName().toLowerCase(java.util.Locale.ROOT).contains(COMPILE_ONLY_SUFFIX);
    }

    @Override
    public String toString() {
      return file.getName() + "/" + (kind == JAR ? "jar" : kind == AAR ? "aar" : "ignored:" + reason)
          + (compileOnly() ? "/compileOnly" : "");
    }
  }

  /** اسمُ العِلَّةِ كما قالَهَا الفحصُ: رسالةُ ‏IOException أو نوعُها إن لم يُكطَبْ لها وصفٌ. */
  static String reasonOf(Throwable error) {
    if (error == null) return "unreadable";
    String text = error.getMessage();
    return text == null || text.trim().isEmpty() ? error.getClass().getSimpleName() : text.trim();
  }

  /** نتيجةُ دورةِ رصدٍ واحدةٍ: ما يُضافُ إلى classpathِ التحليلِ، وما يُترَكُ ولماذا — بالاسمِ. */
  public static final class Finding {
    public final List<Entry> entries;
    /** jar مباشرٌ + ما خرجَ من عقدِ aar (classes.jar وlibs/*.jar). */
    public final List<File> classpath;
    /** عقدُ aar المفكوكةُ (للقيمِ و`R.txt` و`res/`) بعدَ `AarExploder.ensure`. */
    public final List<File> aarNodes;
    public final int ignored;
    public final int unlisted;
    public final int overLimit;
    public final String signature;
    /**
     * W32: الأرشيفاتُ المَرفوضةُ باسمِها وسببِها («‏foo.aar — truncated zip»). كانَ المَرفوضُ يُزادُ معَهُ
     * عدَّادٌ واحدٌ فيُقالُ «تُُرِكَ ١» بلا اسمٍ، فلا يَدريَ المستخدمُ أيُّ مكتبةٍ ميِّتةٌ ولا مَجرى
     * إصلاحِها. تُعرَضُ في اللوحةِ والرسالةِ، وتُبطلُ قولَ «كلُّ مكتبةٍ تامَّةٌ»، ولا تَحكُمُ على صنفٍ.
     */
    public final List<String> integrity;

    Finding(List<Entry> entries, List<File> classpath, List<File> aarNodes, int ignored, int unlisted,
        int overLimit, String signature, List<String> integrity) {
      this.entries = Collections.unmodifiableList(entries);
      this.classpath = Collections.unmodifiableList(classpath);
      this.aarNodes = Collections.unmodifiableList(aarNodes);
      this.ignored = ignored;
      this.unlisted = unlisted;
      this.overLimit = overLimit;
      this.signature = signature;
      this.integrity = Collections.unmodifiableList(integrity);
    }

    static final Finding NONE =
        new Finding(new ArrayList<Entry>(), new ArrayList<File>(), new ArrayList<File>(), 0, 0, 0, "",
            new ArrayList<String>());

    /** لا مكتبةَ في ‏libs/ مَرفوضةٌ: عندها فقطَ يُقالُ إنَّ الطبقةَ مَكتومةٌ عن آخرِها. */
    public boolean isClean() {
      return integrity.isEmpty();
    }

    public boolean isEmpty() {
      return classpath.isEmpty() && aarNodes.isEmpty();
    }

    /** كم أرشيفًا رُئيَ في `libs/` (بما فيهِ المتروكُ) — للرسالةِ لا للحُكمِ. */
    public int seen() {
      return entries.size();
    }
  }

  private LocalLibraries() {}

  /** مجلدُ `libs/` الطبيعيُّ للوحدةِ (أو `libs` تحتَ جذرِ المشروعِ إن لم يكنْ للوحدةِ واحدٌ). */
  public static File libsDirOf(File moduleDir, File projectRoot) {
    File direct = new File(moduleDir, "libs");
    if (direct.isDirectory()) return direct;
    File atRoot = projectRoot == null ? null : new File(projectRoot, "libs");
    return atRoot != null && atRoot.isDirectory() ? atRoot : direct;
  }

  /** البصمةُ: أسماءُ ما في `libs/` وأحجامُهُ وأزمنةُهُ، مرتَّبةً. تغيُّرُها يعني إعادةَ رصدٍ. */
  public static String signatureOf(File libsDir) {
    if (libsDir == null || !libsDir.isDirectory()) return "";
    File[] files = libsDir.listFiles();
    if (files == null || files.length == 0) return "";
    List<String> lines = new ArrayList<>();
    for (File file : files) {
      if (file.isFile()) lines.add(file.getName() + ":" + file.length() + ":" + file.lastModified());
    }
    Collections.sort(lines);
    StringBuilder b = new StringBuilder();
    for (String line : lines) b.append(line).append('\n');
    return Integer.toHexString(b.toString().hashCode()) + ":" + lines.size();
  }

  /** هل القرصُ كما عهدناهُ؟ (بلا قائمةٍ ثانيةٍ: البصمةُ تُحسَبُ عندَ المنادِي الذي يملكُ النتيجةَ) */
  public static boolean unchanged(File libsDir, String signature) {
    return signature != null && signature.equals(signatureOf(libsDir));
  }

  /** أرشيفُ مصادرَ/توثيقٍ: لا يُفهرَسُ ولا يُنزَّلُ ولا يُبلَّغُ خطأً — لا معنى لهُ في التحليلِ. */
  public static boolean isSourceOrDoc(String name) {
    if (name == null) return false;
    String n = name.toLowerCase(Locale.US);
    return n.contains("-sources.") || n.contains("_sources.") || n.contains("-javadoc.")
        || n.contains("_javadoc.") || n.endsWith("-sources.jar") || n.endsWith("-javadoc.jar");
  }

  /** تصنيفُ ملفٍّ واحدٍ في `libs/`. */
  public static Entry classify(File file, String buildText) {
    String name = file.getName();
    boolean mentioned = isMentioned(buildText, name);
    if (!name.endsWith(".jar") && !name.endsWith(".aar")) {
      return new Entry(file, IGNORED, REASON_NOT_ARCHIVE, mentioned);
    }
    if (isSourceOrDoc(name)) return new Entry(file, IGNORED, REASON_SOURCE_OR_DOC, mentioned);
    if (file.length() < 22) return new Entry(file, IGNORED, REASON_TOO_SMALL, mentioned);
    return new Entry(file, name.endsWith(".aar") ? AAR : JAR, "", mentioned);
  }

  /**
   * هل ذكرَ ملفُّ البناءِ هذهِ الأداةَ؟ — إمّا بالاسمِ صراحةً (`files('libs/x.jar')`،
   * و`"./libs/x.jar"`)، أو بـ`fileTree` على `libs` (فيُشملُ كلُّ jar). aar لا يغطيها `fileTree`
   * عندَ Gradle فتبقى غيرَ مذكورةٍ إلا بالنصِّ الصريحِ.
   */
  public static boolean isMentioned(String buildText, String fileName) {
    if (buildText == null || fileName == null || fileName.isEmpty()) return false;
    String text = buildText.replace("'", "\"");
    for (String prefix : new String[] {"libs/", "libs\\", "./libs/", "app/libs/"}) {
      if (text.contains(prefix + fileName)) return true;
    }
    if (fileName.endsWith(".jar") && text.contains("fileTree") && text.contains("\"libs\"")) return true;
    return false;
  }

  /**
   * الرصدُ وحدَهُ (بلا فكٍّ): القائمةُ والسقْفُ والحُكمُ على كلِّ ملفٍّ — يستعملُهُ من يريدُ
   * البصمةَ والعدَّ قبلَ أيِّ عملِ قرصٍ ثقيلٍ.
   */
  public static List<Entry> scan(File libsDir, String buildText) {
    ArrayList<Entry> out = new ArrayList<>();
    if (libsDir == null || !libsDir.isDirectory()) return out;
    File[] files = libsDir.listFiles();
    if (files == null) return out;
    List<File> sorted = new ArrayList<>();
    for (File file : files) {
      if (!file.isFile()) continue;
      String name = file.getName();
      if (name.startsWith(".") || name.contains(".exploded.aar")) continue;
      sorted.add(file);
    }
    Collections.sort(sorted);
    int kept = 0;
    for (File file : sorted) {
      if (kept >= MAX_ENTRIES) {
        out.add(new Entry(file, IGNORED, REASON_TOO_MANY, isMentioned(buildText, file.getName())));
        continue;
      }
      out.add(classify(file, buildText));
      kept++;
    }
    return out;
  }

  /**
   * الرصدُ ثمَّ الفكُّ: تُضافُ jar مباشرةً، وتُفَكُّ aar إلى `build/shima-libs/‹اسمٌ›.exploded.aar`
   * بآليّةِ {@link AarExploder} (فإعادةُ الاستخدامِ عبرَ المشاريعِ بلا تنزيلٍ ولا تكرارٍ)، ويُجمَعُ
   * `classes.jar` و`libs/*.jar` من عقدةِ كلِّ aar. أرشيفٌ تالفٌ لا يُسقِطُ الدورةَ: يُترَكُ مُسَمًّى
   * باسمِهِ وسببِهِ في ‏{@link Finding#integrity} — فلا العددُ يُخفيهِ ولا الصمتُ يُبقيهِ مَجهولًا.
   */
  public static Finding discover(File moduleDir, File projectRoot, String buildText,
      AarExploder.Progress progress) {
    File libsDir = libsDirOf(moduleDir, projectRoot);
    List<Entry> entries = scan(libsDir, buildText);
    if (entries.isEmpty()) return Finding.NONE;
    String signature = signatureOf(libsDir);
    ArrayList<File> classpath = new ArrayList<>();
    ArrayList<File> nodes = new ArrayList<>();
    ArrayList<String> integrity = new ArrayList<>();
    int ignored = 0;
    int unlisted = 0;
    int over = 0;
    for (Entry entry : entries) {
      if (entry.kind == IGNORED) {
        ignored++;
        if (entry.reason.equals(REASON_TOO_MANY)) over++;
        continue;
      }
      if (entry.unlisted()) unlisted++;
      if (entry.kind == JAR) {
        classpath.add(entry.file);
        continue;
      }
      File writable = new File(moduleDir, EXPLODE_ROOT);
      try {
        AarExploder.Report report = AarExploder.ensure(entry.file, writable, progress);
        nodes.add(report.node);
        File classes = AarExploder.classesJarOf(report.node);
        if (classes != null && classes.isFile()) classpath.add(classes);
        classpath.addAll(AarExploder.bundledJars(report.node));
      } catch (java.io.IOException broken) {
        // aar لا يُفَكُّ (مقطوعٌ أو ليس أرشيفًا): لا يُضافُ شيءٌ ولا تُسقَطُ الدورةُ — باقي `libs/` حيٌّ،
        // لكنَّهُ لا يَمُرُّ صامتًا: اسمُهُ وسببُهُ يَبلُغانِ اللوحةَ ويُبطِلاَنَ «كلُّ مكتبةٍ تامَّةٌ».
        ignored++;
        integrity.add(entry.file.getName() + " — " + reasonOf(broken));
      }
    }
    return new Finding(entries, classpath, nodes, ignored, unlisted, over, signature, integrity);
  }

  /** أقصى ما يُقبَلُ من مخرَجِ الوحدةِ نفسِها في الدورةِ الواحدةِ. */
  public static final int MAX_OUTPUT_FILES = 64;

  /**
   * مجلدَا مخرجِ الوحدةِ القياسيانِ: ‏{@code build/libs} (‏jar) و‏{@code build/outputs/aar}
   * (‏aar). لا بحثٌ في ‏{@code build/intermediates}: مساراتُهُ غيرُ ثابتةٍ بينَ إصداراتِ ‏AGP،
   * والعدوُّ فيهِ انفلاتُ عدَدٍ — فإمّا مخرجٌ معروفُ الموضعِ أو لا شيءَ.
   */
  public static ArrayList<File> outputDirsOf(File moduleDir) {
    ArrayList<File> out = new ArrayList<>();
    if (moduleDir == null) return out;
    File build = new File(moduleDir, "build");
    File libs = new File(build, "libs");
    if (libs.isDirectory()) out.add(libs);
    File aar = new File(new File(build, "outputs"), "aar");
    if (aar.isDirectory()) out.add(aar);
    return out;
  }

  /** بصمةُ المخرجِ: غيابٌ متكرّرٌ لا يُحرِّكُها، وولادةُ أرشيفٍ جديدٍ أو تغيُّرُ حجمِهِ تُحرِّكُها. */
  public static String outputsSignature(File moduleDir) {
    StringBuilder b = new StringBuilder();
    for (File dir : outputDirsOf(moduleDir)) {
      String one = signatureOf(dir);
      if (one.isEmpty()) continue;
      if (b.length() > 0) b.append(',');
      b.append(dir.getParentFile().getName()).append('/').append(dir.getName()).append('=').append(one);
    }
    return b.toString();
  }

  /**
   * مخرجُ الوحدةِ المُترجَمُ على القرصِ، بوصفةِ ‏{@link #discover} نفسِها: jar إلى المسارِ، وaar
   * إلى عقدةٍ بـ‏{@link AarExploder} ثمَّ ‏{@code classes.jar} و‏{@code libs/*.jar} من جوفِها.
   * لا يُبنى شيءٌ ولا يُطلَبُ بناءٌ: إن لم يكنْ مخرجٌ فلا شيءَ يُضافُ؛ وأرشيفٌ تالفٌ يُترَكُ
   * معلنًا ولا يُسقِطُ الدورةَ؛ ومَن فاقَ ‏{@value #MAX_OUTPUT_FILES} فعدَّهُ السقفُ {@code over}.
   */
  public static Finding discoverOutputs(File moduleDir, AarExploder.Progress progress) {
    ArrayList<File> classpath = new ArrayList<>();
    ArrayList<File> nodes = new ArrayList<>();
    ArrayList<Entry> entries = new ArrayList<>();
    ArrayList<String> integrity = new ArrayList<>();
    int ignored = 0;
    int over = 0;
    int kept = 0;
    if (moduleDir != null) {
      for (File dir : outputDirsOf(moduleDir)) {
        for (Entry entry : scan(dir, null)) {
          entries.add(entry);
          if (entry.kind == IGNORED) {
            ignored++;
            if (REASON_TOO_MANY.equals(entry.reason)) over++;
            continue;
          }
          if (kept >= MAX_OUTPUT_FILES) {
            over++;
            continue;
          }
          kept++;
          if (entry.kind == JAR) {
            classpath.add(entry.file);
            continue;
          }
          File writable = new File(moduleDir, EXPLODE_ROOT);
          try {
            AarExploder.Report report = AarExploder.ensure(entry.file, writable, progress);
            nodes.add(report.node);
            File classes = AarExploder.classesJarOf(report.node);
            if (classes != null && classes.isFile()) classpath.add(classes);
            classpath.addAll(AarExploder.bundledJars(report.node));
          } catch (java.io.IOException broken) {
            // aar لا يُفَكُّ: لا يُضافُ شيءٌ ولا تُنسَبُ الدوراتُ إلى الفشلِ — واسمُهُ يُقالُ كـ libs/.
            ignored++;
            integrity.add(entry.file.getName() + " — " + reasonOf(broken));
          }
        }
      }
    }
    return new Finding(entries, classpath, nodes, ignored, 0, over, outputsSignature(moduleDir), integrity);
  }

  /** سطرُ اللوحةِ/الرسالةِ: كم فُهرِسَ، وكم منها خارجُ ملفِّ البناءِ، وكم تُرِكَ. */
  public static String summary(Finding finding) {
    // W32: «صفرٌ مَسْمِيٌّ» خيرٌ من صمتٍ. لو رُفِضَ كلُّ ما في `libs/` لم تَكُنِ اللوحةُ تُطيقُ سطرًا
    // لأنَّ ما فُهرِسَ لا شيءَ، فيبقى المستخدمُ يَحسبُ المجلدَ فارغًا لا مكتباتِهِ ميِّتةً.
    if (finding == null || (finding.isEmpty() && finding.integrity.isEmpty())) return "";
    StringBuilder b = new StringBuilder();
    b.append(finding.classpath.size()).append(" local lib file(s) indexed");
    if (finding.unlisted > 0) b.append(", ").append(finding.unlisted).append(" not in build.gradle");
    // ج٤١: «للفحصِ لا للبِناءِ» يَلزَمُ أن يُقالَ لا أن يُعرَفَ سرًّا، وإلّا حُسِبَتِ المكتبةُ دَخَلَتِ
    // APKِ ولم تَدخُلْهُ — فيُنطَقُ العَدَدُ في السَّطرِ نفسِهِ الذي يُطيقُهُ اللوحةُ أصلًا.
    int compileOnly = 0;
    if (finding.entries != null) {
      for (Entry entry : finding.entries) if (entry.compileOnly()) compileOnly++;
    }
    if (compileOnly > 0) {
      b.append(", ").append(compileOnly).append(" compile-only (checked, not packaged)");
    }
    if (finding.ignored > 0) b.append(", ").append(finding.ignored).append(" left out");
    if (!finding.integrity.isEmpty()) {
      b.append(", ").append(finding.integrity.size()).append(" refused: ");
      for (int i = 0; i < finding.integrity.size() && i < 3; i++) {
        if (i > 0) b.append("; ");
        b.append(finding.integrity.get(i));
      }
      if (finding.integrity.size() > 3) b.append(" …+").append(finding.integrity.size() - 3);
    }
    return b.toString();
  }
}
