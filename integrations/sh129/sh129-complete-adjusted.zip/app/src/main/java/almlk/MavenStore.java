package almlk;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;
import java.util.Set;

/**
 * مخزن مكتبات Maven في التطبيق (M1).
 *
 * <p>يحدّد:
 * <ul>
 *   <li>مجلد التنزيل: الافتراضي {@code <noBackup>/.aide/maven}، أو مجلد مخصّص فعّال وقابل للكتابة.
 *   <li>المستودعات المحلية للقراءة فقط ({@code user_m2repositories}، مفصولة بـ{@code ;}).
 *   <li>تخطيط Maven القياسي {@code group/path/artifact/version/artifact-version[-classifier].ext}.
 * </ul>
 * جافا خالصة بلا Android — تُختبر مباشرة في RegressionSuite. الربط بالسياق في {@link AppSettings}.
 */
public final class MavenStore {

  public static final String DEFAULT_SUBDIR = ".aide/maven";
  public static final String KEY_ENABLE_CUSTOM_DIR = "advanced_setting_enable_mavenDownloadDir";
  public static final String KEY_CUSTOM_DIR = "advanced_setting_mavenDownloadDir";
  public static final String KEY_LOCAL_REPOSITORIES = "user_m2repositories";

  /** إحداثيات أداة Maven: group:artifact:version[:classifier][@extension]. */
  public static final class Coordinate {
    public final String group, artifact, version, classifier, extension;

    public Coordinate(String group, String artifact, String version, String classifier, String extension) {
      this.group = group;
      this.artifact = artifact;
      this.version = version;
      this.classifier = classifier == null || classifier.isEmpty() ? null : classifier;
      this.extension = extension == null || extension.isEmpty() ? null : extension;
    }

    /** يعيد null لأي نص ليس إحداثيات كاملة (ثلاثة أجزاء على الأقل، بلا فراغات ولا متغيرات). */
    public static Coordinate parse(String text) {
      if (text == null) return null;
      String value = text.trim();
      String extension = null;
      int at = value.lastIndexOf('@');
      if (at > 0) {
        extension = value.substring(at + 1);
        value = value.substring(0, at);
        if (!extension.matches("[A-Za-z0-9]+")) return null;
      }
      String[] parts = value.split(":", -1);
      if (parts.length < 3 || parts.length > 4) return null;
      for (String part : parts) {
        if (part.isEmpty() || !part.matches("[A-Za-z0-9_.+\\-\\[\\](),]+")) return null;
      }
      if (!parts[0].matches("[A-Za-z0-9_.\\-]+") || !parts[1].matches("[A-Za-z0-9_.\\-]+")) return null;
      return new Coordinate(parts[0], parts[1], parts[2], parts.length == 4 ? parts[3] : null, extension);
    }

    /** group:artifact بلا إصدار — مفتاح حلّ التعارض. */
    public String key() {
      return group + ":" + artifact;
    }

    /** إصدار ديناميكي يحتاج maven-metadata.xml: {@code +} أو {@code 1.2.+} أو نطاق. */
    public boolean isDynamicVersion() {
      return version.endsWith("+") || version.startsWith("[") || version.startsWith("(")
          || version.equals("latest.release") || version.equals("latest.integration");
    }

    public Coordinate withVersion(String newVersion) {
      return new Coordinate(group, artifact, newVersion, classifier, extension);
    }

    /** المسار النسبي لمجلد الإصدار: androidx/core/core/1.19.1 */
    public String relativeDir() {
      return group.replace('.', '/') + "/" + artifact + "/" + version;
    }

    /** اسم الملف: core-1.19.1.aar أو lib-1.0-sources.jar */
    public String fileName(String ext) {
      return artifact + "-" + version + (classifier == null ? "" : "-" + classifier) + "." + ext;
    }

    @Override
    public String toString() {
      return key() + ":" + version + (classifier == null ? "" : ":" + classifier)
          + (extension == null ? "" : "@" + extension);
    }

    @Override
    public boolean equals(Object other) {
      return other instanceof Coordinate && toString().equals(other.toString());
    }

    @Override
    public int hashCode() {
      return toString().hashCode();
    }
  }

  private final File downloadDir;
  private final List<File> localRepositories;

  public MavenStore(File downloadDir, List<File> localRepositories) {
    this.downloadDir = downloadDir;
    this.localRepositories =
        localRepositories == null
            ? Collections.<File>emptyList()
            : Collections.unmodifiableList(new ArrayList<>(localRepositories));
  }

  /** من قيم الإعدادات الخام: مفتاح التفعيل والمسار المخصّص وقائمة المستودعات المحلية. */
  public static MavenStore fromSettings(
      File noBackupDir, boolean customEnabled, String customDir, String localRepositories) {
    return new MavenStore(
        chooseDownloadDir(noBackupDir, customEnabled, customDir),
        parseLocalRepositories(localRepositories));
  }

  public static File defaultDownloadDir(File noBackupDir) {
    return new File(noBackupDir, DEFAULT_SUBDIR);
  }

  /**
   * المجلد المخصّص فقط إن كان مفعّلًا وغير فارغ وقابلًا للكتابة (يُنشأ إن غاب)، وإلا الافتراضي
   * بصمت.
   */
  public static File chooseDownloadDir(File noBackupDir, boolean customEnabled, String customDir) {
    if (customEnabled && customDir != null && !customDir.trim().isEmpty()) {
      File custom = new File(customDir.trim());
      if (custom.isDirectory() || custom.mkdirs()) {
        if (custom.canWrite()) return custom;
      }
    }
    return defaultDownloadDir(noBackupDir);
  }

  /** مسارات كاملة مفصولة بـ{@code ;}، بلا فراغات ولا تكرار، بالترتيب المكتوب. */
  public static List<File> parseLocalRepositories(String value) {
    List<File> out = new ArrayList<>();
    if (value == null) return out;
    Set<String> seen = new LinkedHashSet<>();
    for (String part : value.split(";")) {
      String path = part.trim();
      if (path.isEmpty() || !seen.add(path)) continue;
      out.add(new File(path));
    }
    return out;
  }

  public File downloadDir() {
    return downloadDir;
  }

  public List<File> localRepositories() {
    return localRepositories;
  }

  /** مجلد إصدار الأداة داخل مجلد التنزيل (الكتابة هنا دائمًا). */
  public File artifactDir(Coordinate coordinate) {
    return new File(downloadDir, coordinate.relativeDir());
  }

  /** موضع كتابة ملف الأداة بامتداد معيّن داخل مجلد التنزيل. */
  public File artifactFile(Coordinate coordinate, String ext) {
    return new File(artifactDir(coordinate), coordinate.fileName(ext));
  }

  /** أول ملف موجود: مجلد التنزيل ثم المستودعات المحلية بترتيبها، وإلا null. */
  public File find(Coordinate coordinate, String ext) {
    File own = artifactFile(coordinate, ext);
    if (own.isFile()) return own;
    for (File repository : localRepositories) {
      File candidate = new File(new File(repository, coordinate.relativeDir()), coordinate.fileName(ext));
      if (candidate.isFile()) return candidate;
    }
    return null;
  }

  /**
   * ملف الأداة الثنائي المحلي: الامتداد المعلَن أولًا، وإلا aar ثم jar. pom وحده لا يكفي إلا لأداة
   * {@code pom} (BOM/أب).
   */
  public File findBinary(Coordinate coordinate) {
    if (coordinate.extension != null) return find(coordinate, coordinate.extension);
    File aar = find(coordinate, "aar");
    return aar != null ? aar : find(coordinate, "jar");
  }

  /** مثبّتة محليًا: POM موجود مع ملفها الثنائي (أو POM فقط لأدوات packaging=pom). */
  public boolean isInstalled(Coordinate coordinate) {
    if (coordinate.isDynamicVersion()) return false;
    if ("pom".equals(coordinate.extension)) return find(coordinate, "pom") != null;
    return findBinary(coordinate) != null;
  }

  // ═══════════════ المثبَّت محليًا (إكمال Gradle وحوار Add Dependency) ═══════════════

  private static volatile Map<String, List<String>> installedSnapshot = Collections.emptyMap();

  /** آخر لقطة لـ«group:artifact ← الإصدارات» في المخزن النشط (تُنشر بعد كل دورة مكتبات). */
  public static Map<String, List<String>> installedSnapshot() {
    return installedSnapshot;
  }

  public static void publishInstalled(Map<String, List<String>> installed) {
    installedSnapshot = installed == null ? Collections.<String, List<String>>emptyMap() : Collections.unmodifiableMap(installed);
  }

  /**
   * كل ما في مجلد التنزيل والمستودعات المحلية بتخطيط Maven: {@code g/r/o/u/p/artifact/version/
   * artifact-version.pom}. الإصدارات مرتّبة تصاعديًا.
   */
  public Map<String, List<String>> installedVersions() {
    TreeMap<String, Set<String>> found = new TreeMap<>();
    collectInstalled(downloadDir, new ArrayList<String>(), found);
    for (File repo : localRepositories) collectInstalled(repo, new ArrayList<String>(), found);
    TreeMap<String, List<String>> out = new TreeMap<>();
    for (Map.Entry<String, Set<String>> e : found.entrySet()) {
      List<String> versions = new ArrayList<>(e.getValue());
      versions.sort(MavenVersion::compare);
      out.put(e.getKey(), Collections.unmodifiableList(versions));
    }
    return out;
  }

  private static void collectInstalled(File dir, List<String> path, Map<String, Set<String>> out) {
    if (dir == null || path.size() > 16) return;
    File[] children = dir.listFiles();
    if (children == null) return;
    int depth = path.size();
    for (File child : children) {
      String name = child.getName();
      if (child.isDirectory()) {
        if (name.startsWith(".")) continue;
        path.add(name);
        collectInstalled(child, path, out);
        path.remove(path.size() - 1);
      } else if (depth >= 3 && name.endsWith(".pom")) {
        String version = path.get(depth - 1);
        String artifact = path.get(depth - 2);
        if (!name.equals(artifact + "-" + version + ".pom")) continue;
        String group = String.join(".", path.subList(0, depth - 2));
        Set<String> versions = out.get(group + ":" + artifact);
        if (versions == null) out.put(group + ":" + artifact, versions = new LinkedHashSet<>());
        versions.add(version);
      }
    }
  }

  /** الحجم الكلي لمجلد التنزيل بالبايت. */
  public long sizeBytes() {
    return sizeOf(downloadDir);
  }

  /** يحذف محتوى مجلد التنزيل (لا المستودعات المحلية أبدًا). يعيد عدد الملفات المحذوفة. */
  public int clear() {
    int[] count = {0};
    File[] children = downloadDir.listFiles();
    if (children != null) for (File child : children) delete(child, count);
    return count[0];
  }

  /** حجم مجلدات إصدارات هذه الأدوات داخل مجلد التنزيل فقط. */
  public long sizeOf(Collection<Coordinate> coordinates) {
    long total = 0;
    for (File dir : ownedDirs(coordinates)) total += sizeOf(dir);
    return total;
  }

  /**
   * يحذف مجلدات إصدارات هذه الأدوات من مجلد التنزيل (مكتبات مشروع واحد)، ثم المجلدات الأم التي فرغت.
   * المستودعات المحلية للمستخدم لا تُمسّ أبدًا. يعيد عدد الملفات المحذوفة.
   */
  public int deleteArtifacts(Collection<Coordinate> coordinates) {
    int[] count = {0};
    for (File dir : ownedDirs(coordinates)) {
      delete(dir, count);
      for (File parent = dir.getParentFile(); parent != null && !parent.equals(downloadDir);
          parent = parent.getParentFile()) {
        String[] left = parent.list();
        if (left == null || left.length > 0 || !parent.delete()) break;
      }
    }
    return count[0];
  }

  /** مجلدات الإصدارات الموجودة فعلًا داخل مجلد التنزيل، بلا تكرار. */
  private List<File> ownedDirs(Collection<Coordinate> coordinates) {
    List<File> out = new ArrayList<>();
    if (coordinates == null) return out;
    String root = downloadDir.getAbsolutePath() + File.separator;
    Set<String> seen = new HashSet<>();
    for (Coordinate coordinate : coordinates) {
      if (coordinate == null || coordinate.version == null || coordinate.version.isEmpty()) continue;
      File dir = artifactDir(coordinate);
      if (!dir.getAbsolutePath().startsWith(root) || !dir.isDirectory() || isSymlink(dir)) continue;
      if (seen.add(dir.getAbsolutePath())) out.add(dir);
    }
    return out;
  }

  /**
   * قيمة متغير البناء {@code SHIMA_M2_REPOSITORIES}: مستودعات المستخدم ثم مجلد التنزيل، كي لا يعيد
   * Gradle تنزيل ما في مخزننا.
   */
  public String gradleRepositoriesValue() {
    StringBuilder out = new StringBuilder();
    Set<String> seen = new LinkedHashSet<>();
    for (File repository : localRepositories) {
      if (seen.add(repository.getAbsolutePath())) append(out, repository.getAbsolutePath());
    }
    if (seen.add(downloadDir.getAbsolutePath())) append(out, downloadDir.getAbsolutePath());
    return out.toString();
  }

  /** حجم مقروء: 0 B، 12.3 KB، 4.5 MB، 1.2 GB. */
  public static String formatSize(long bytes) {
    if (bytes < 1024) return bytes + " B";
    String[] units = {"KB", "MB", "GB", "TB"};
    double value = bytes;
    int unit = -1;
    while (value >= 1024 && unit < units.length - 1) {
      value /= 1024;
      unit++;
    }
    return String.format(Locale.US, "%.1f %s", value, units[unit]);
  }

  private static void append(StringBuilder out, String path) {
    if (out.length() > 0) out.append(';');
    out.append(path);
  }

  private static long sizeOf(File file) {
    if (file.isFile()) return file.length();
    if (isSymlink(file)) return 0;
    long total = 0;
    File[] children = file.listFiles();
    if (children != null) for (File child : children) total += sizeOf(child);
    return total;
  }

  /** رابط رمزي؟ (java.nio متاح منذ minSdk 26) — لا يُتبع عند المسح. */
  private static boolean isSymlink(File file) {
    return java.nio.file.Files.isSymbolicLink(file.toPath());
  }

  private static void delete(File file, int[] count) {
    File[] children = file.isDirectory() && !isSymlink(file) ? file.listFiles() : null;
    if (children != null) for (File child : children) delete(child, count);
    boolean wasFile = file.isFile();
    if (file.delete() && wasFile) count[0]++;
  }
}
