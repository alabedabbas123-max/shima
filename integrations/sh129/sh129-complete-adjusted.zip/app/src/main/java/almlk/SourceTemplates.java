package almlk;

/**
 * قَوَالِبُ مَا يَكتُبُهُ المُتَصَفِّرُ مِن مِلفَاتِ المَصدَرِ (‏1.0.197): نَقلٌ لِمَا كَانَ خَاصًّا
 * بِـ{@code BrowserPager} إلى حَيِّزٍ يُقرَأُ مِنهُ وَمِنَ الفَحصِ جَميعًا.
 *
 * <p>لِمَاذَا النِّقلُ؟ صَفُّ «‏{@code Create class 'X'}» فِي لوحَةِ الأَخطَاءِ يَكتُبُ المِلَفَّ
 * بِأَداةِ المُتَصَفِّرِ نَفسِهَا — وَلكِنْ «هَل مَا كَتَبنَاهُ يَعمَلُ؟» سُؤَالٌ يَجِبُ أن يُسأَلَ عَلى
 * القَالَبِ الحَقِّ لا عَلى نَسخَةٍ مِنهُ؛ وَالفَحصُ الآلِيَّ لا يَبلُغُ صِنفَ الوَاجِهَةِ. بِالنِّقلِ
 * تَصِيرُ الكَلِمَةُ الوَاحِدَةُ «مَكتُوبٌ» مَصدَرًا وَاحِدًا، وَيَستَطِيعُ الجَولَةُ أن تُشغِلَ
 * ‏javacَ عَلى مَا نُولِّدُهُ حَقيقَةً، فَتَكُونَ صَادِقَةً إِذَا قَالَت «يُبنَى».
 *
 * <p>رَقمُ الصِّنْفِ (kind) مَعمُولٌ بِهِ كَمَا هُوَ عِندَ الحِوارِ: صفرٌ صِنفٌ، وَاحِدٌ نَشَاطٌ،
 * اِثنَانِ وَاجِهَةٌ، ثَلاثَةٌ تَعدَادِيٌّ، أربَعَةٌ خِدمَةٌ، خَمسَةٌ مُستَلقٍ — وَلا نَلمِسُ دلالاتِهِ.
 * وَقَاعِدَةُ ج٣٦ بَاقِيَةٌ فِعلًا لا قَولًا: صِفرَ سَطَرَ تَعلِيقٍ فِيمَا يَخرُجُ هُنَا.
 */
public final class SourceTemplates {

  private SourceTemplates() {}

  public static String classCodeFor(
      int kind, String pkg, String name, boolean withLayout, String layoutName) {
    StringBuilder code = new StringBuilder();
    if (!pkg.isEmpty()) code.append("package ").append(pkg).append(";\n\n");
    switch (kind) {
      case 1: // Activity
        code.append("import android.app.Activity;\nimport android.os.Bundle;\n\n")
            .append("public class ").append(name).append(" extends Activity {\n\n")
            .append("    @Override\n")
            .append("    protected void onCreate(Bundle savedInstanceState) {\n")
            .append("        super.onCreate(savedInstanceState);\n");
        if (withLayout)
          code.append("        setContentView(R.layout.").append(layoutName).append(");\n");
        code.append("    }\n}\n");
        break;
      case 2: // Interface
        code.append("public interface ").append(name).append(" {\n\n}\n");
        break;
      case 3: // Enum
        code.append("public enum ").append(name).append(" {\n\n}\n");
        break;
      case 4: // Service
        code.append("import android.app.Service;\n")
            .append("import android.content.Intent;\n")
            .append("import android.os.IBinder;\n\n")
            .append("public class ").append(name).append(" extends Service {\n\n")
            .append("    @Override\n")
            .append("    public IBinder onBind(Intent intent) {\n")
            .append("        return null;\n    }\n}\n");
        break;
      case 5: // BroadcastReceiver
        code.append("import android.content.BroadcastReceiver;\n")
            .append("import android.content.Context;\n")
            .append("import android.content.Intent;\n\n")
            .append("public class ").append(name).append(" extends BroadcastReceiver {\n\n")
            .append("    @Override\n")
            .append("    public void onReceive(Context context, Intent intent) {\n")
            .append("    }\n}\n");
        break;
      default: // Class
        code.append("public class ").append(name).append(" {\n\n}\n");
    }
    return code.toString();
  }
}
