package almlk;

/**
 * سياسةُ مخزنِ مخرَجِ البناءِ: كم يُحفَظُ، وأينَ يُقطعُ.
 *
 * <p>مخرَجُ ‏Gradle قد يمتدُّ لمئاتِ الألوفِ من الأسطرِ؛ والاحتفاظُ كلِّهِ في ‏TextView داخلَ حوارٍ
 * يعني نصًّا يتضخّمُ حتى ينفدَ ذاكرةَ التطبيقِ على الجهازِ. تُبقي هذهِ السياسةُ آخرَ النافذةِ،
 * وتقطعُ عندَ حدِّ سطرٍ كاملٍ لا في وسطِهِ، وتُعلِنُ عن كلِّ قطعٍ بسطرٍ واحدٍ كي لا يُظَنَّ أنَّ
 * ما يُرى هو كلُّ ما قالَهُ البناءُ. دوالٌ صرفةٌ بلا Androidَ: تُختبَرُ وحدَها بلا محاكيَ.
 */
public final class ConsoleBuffer {

  /** فوقَ هذا العددِ من المحارفَ يُقلَّمُ المخزنُ: سقفُهُ ‏2^18 محرفًا، لا أكثرَ. */
  public static final int MAX_CHARS = 1 << 18;
  /** عندَ التخفيفِ يُرجَعُ إلى ثلاثةِ أرباعِ السقفِ — فلا يُقلَّمُ مع كلِّ سطرٍ بعدَهُ. */
  public static final int TRIM_TO_CHARS = MAX_CHARS * 3 / 4;
  /** السطرُ الذي يُعلَنُ فيهِ القطعُ (‏{@code …} بدلَ ما حُذِفَ). */
  public static final String CUT_MARK = " […]\n";

  private ConsoleBuffer() {}

  /** هل تجاوزَ الطولُ السقفَ ويستحقُّ التخفيفَ؟ */
  public static boolean needsTrim(int length) {
    return length > MAX_CHARS;
  }

  /** كم محرفًا يُقطَعُ من أولِ النصِّ ليصيرَ طولُهُ {@code target} أو أقلَّ (0 بلا تجاوزٍ). */
  public static int overflow(int length, int target) {
    if (length <= target) return 0;
    return length - target;
  }

  /** عددُ المحارفَ المقطوعةِ عندها سياسةُ السقفِ نفسِها. */
  public static int overflow(int length) {
    return overflow(length, TRIM_TO_CHARS);
  }

  /**
   * موضعُ أولِّ سطرٍ كاملٍ عندَ أو بعدَ {@code from} — فلا يبدأُ المعروضُ بذيولِ سطرٍ مقطوعٍ.
   * إن لم يبقَ سطرٌ كامِلٌ أُعيدَ {@code text.length()} (أيْ لا قطعَ هذهِ المرّةَ).
   */
  public static int firstLineStart(CharSequence text, int from) {
    if (text == null || text.length() == 0) return 0;
    int i = Math.max(0, Math.min(from, text.length()));
    // من أوّلِ السطرِ الذي يلي النافذةِ المقطوعةِ، لا من منتصفِهِ.
    int newline = indexOf(text, '\n', i);
    return newline < 0 ? text.length() : newline + 1;
  }

  /**
   * النصُّ المُقلَّمُ: يُحفَظُ آخرُ {@code maxChars} محرفًا مُسْتَوِيًا على حدِّ سطرٍ، ويُقدَّمُ
   * {@link #CUT_MARK} إن حُذِفَ شيءٌ فعلًا. يعيدُ النصَّ نفسَهُ (بلا نسخةٍ) حينَ لا حاجةَ إلى قطعٍ.
   */
  public static String trimmed(String text, int maxChars) {
    if (text == null || text.length() <= maxChars) return text;
    int cut = firstLineStart(text, text.length() - maxChars);
    if (cut <= 0 || cut >= text.length()) return text;
    return CUT_MARK + text.substring(cut);
  }

  /** النسخةُ المُقلَّمةُ بسقفِ السياسةِ. */
  public static String trimmed(String text) {
    return trimmed(text, TRIM_TO_CHARS);
  }

  private static int indexOf(CharSequence text, char c, int from) {
    for (int i = from; i < text.length(); i++) if (text.charAt(i) == c) return i;
    return -1;
  }
}
