package almlk;

import android.content.Context;

/**
 * أسماءُ الثيماتِ من مواردها باسمِها — مصدرٌ واحدٌ يقرؤُهُ سطرُ الإعداداتِ ورأسُ شاشةِ الألوانِ معًا،
 * فلا اسمَيْنِ لثيمٍ واحدٍ ولا ترجمةً منسوخةً في شاشة. الاسمُ يُستدلُّ عليهِ بـ{@code theme_<code>}،
 * وإن لم يُعرَّفِ الموردُ رجَعَ الكودُ نفسُهُ: شاشةُ إعداداتٍ لا تنهارُ على ترجمةٍ ناقصة.
 */
public final class ThemeNames {

  private ThemeNames() {}

  /** موردُ {@code theme_<code>}؛ صفرٌ إن لم يُعرَّف. */
  public static int titleRes(Context context, String code) {
    return context
        .getResources()
        .getIdentifier("theme_" + code, "string", context.getPackageName());
  }

  public static String title(Context context, String code) {
    int id = titleRes(context, code);
    return id == 0 ? code : context.getString(id);
  }

  /** نصٌّ من موردِهِ باسمِهِ، وبالبديلِ عندَ غيابِهِ. */
  public static String text(Context context, String resourceName, String fallback) {
    int id =
        context.getResources().getIdentifier(resourceName, "string", context.getPackageName());
    return id == 0 ? fallback : context.getString(id);
  }
}
