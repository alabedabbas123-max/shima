package almlk;

/**
 * What may define a symbol for the project model — and what is only tooling or a shadow.
 *
 * <p>The file browser and the project search still cover every file of the user's tree: that is his
 * tree and it is his to read, edit and search. This policy decides a narrower thing — which files
 * the <em>symbol index</em> trusts. A helper folder next to the sources (the JVM test harness,
 * scripts, reports) is not project source, and a file that re-declares a type owned by the platform
 * or by a library is never that type's definition: a fourteen-line stub silently outranking
 * {@code android.content.Context} produced false «cannot find symbol» waves in real files and made
 * go-to jump into the stub instead of the platform. Both are refused here, and the shadow is
 * announced so the refusal is never mistaken for health.
 */
public final class ProjectSourceRoots {

  /** Generated output and VCS/tooling caches: never source, at any depth. */
  private static final String[] NEVER_SOURCE = {
    "build", "out", "target", "bin", "obj", "gen", "tmp", "temp", "intermediates", "outputs",
    "node_modules", ".git", ".gradle", ".idea", ".cxx", ".cache", "captures", ".m2"
  };

  /** Project-local tooling folders: refused unless the path is inside a Gradle source root. */
  private static final String[] TOOLING = {
    "qa", "host-stubs", "stubs", "scripts", "docs", "reports", "deliverables", "signing",
    "testdata", "samples", "gradle", "gradlew"
  };

  /** Language directories of a Gradle source root: {@code src/<set>/<lang>/…}. */
  private static final String[] SOURCE_LANGS = {
    "java", "kotlin", "resources", "aidl", "renderscript", "rs", "shaders"
  };

  private ProjectSourceRoots() {}

  /** {@code …/src/main/java/…} (or {@code src/<set>/<lang>}): Gradle's own source layout. */
  public static boolean underSourceRoot(String path) {
    if (path == null) return false;
    int from = 0;
    while (from <= path.length()) {
      int slash = path.indexOf('/', from);
      int end = slash < 0 ? path.length() : slash;
      if (path.regionMatches(true, from, "src", 0, 3) && end - from == 3) {
        // next two segments: <set>/<lang>
        int setStart = end + 1;
        if (setStart < path.length()) {
          int setEnd = path.indexOf('/', setStart);
          if (setEnd < 0) setEnd = path.length();
          int langStart = setEnd + 1;
          if (langStart < path.length()) {
            int langEnd = path.indexOf('/', langStart);
            if (langEnd < 0) langEnd = path.length();
            for (int i = 0; i < SOURCE_LANGS.length; i++)
              if (path.regionMatches(true, langStart, SOURCE_LANGS[i], 0, SOURCE_LANGS[i].length())
                  && langEnd - langStart == SOURCE_LANGS[i].length()) return true;
          }
        }
      }
      if (slash < 0) break;
      from = slash + 1;
    }
    return false;
  }

  /** True when this file must not enter the symbol index (it is tooling or generated output). */
  public static boolean skipIndexingFor(String referenceOrPath) {
    if (referenceOrPath == null || referenceOrPath.isEmpty()) return false;
    String path = referenceOrPath;
    if (underSourceRoot(path)) return false;
    int from = 0;
    while (from <= path.length()) {
      int slash = path.indexOf('/', from);
      int end = slash < 0 ? path.length() : slash;
      int len = end - from;
      if (len > 0) {
        String segment = path.substring(from, end);
        // a document-URI tree root looks like "primary:Project" — compare by its tail
        if (indexOfSegment(segment, ':') >= 0) segment = tailAfterColon(segment);
        if (equalsAny(segment, NEVER_SOURCE)) return true;
        if (equalsAny(segment, TOOLING)) return true;
      }
      if (slash < 0) break;
      from = slash + 1;
    }
    return false;
  }

  /**
   * Packages owned by the platform or by a dependency: a project file may re-declare them for the
   * compiler's benefit (that is what a stub folder does), but that copy is not the definition of
   * the type — the platform/library layer is, and it is complete.
   */
  public static boolean platformOrLibraryPackage(String packageName) {
    if (packageName == null || packageName.isEmpty()) return false;
    return startsWithAny(packageName, PLATFORM_PREFIXES) || equalsAny(packageName, PLATFORM_ROOTS);
  }

  private static final String[] PLATFORM_PREFIXES = {
    "java.", "javax.", "jdk.", "sun.", "com.sun.", "libcore.", "dalvik.", "android.",
    "android.annotation", "androidx.", "kotlin.", "kotlinx.", "org.json.", "org.w3c.",
    "org.xml.", "org.apache.http.", "org.apache.commons.", "com.google.android.", "com.google.common.",
    "junit.", "org.junit.", "org.hamcrest.", "org.robolectric.", "org.mockito.", "org.jetbrains.",
    "retrofit2.", "okhttp3.", "okio.", "io.reactivex.", "com.squareup.", "org.eclipse.", "groovy.",
    "org.intellij."
  };

  /** The namespace heads themselves: a file declaring {@code package android;} is also a shadow. */
  private static final String[] PLATFORM_ROOTS = {
    "java", "javax", "jdk", "sun", "libcore", "dalvik", "android", "androidx", "kotlin",
    "kotlinx", "junit", "org.json", "org.w3c", "org.xml", "okio", "okhttp3", "retrofit2",
    "io.reactivex", "org.hamcrest", "org.junit", "org.mockito", "org.robolectric"
  };

  private static boolean startsWithAny(String value, String[] prefixes) {
    for (int i = 0; i < prefixes.length; i++) if (value.startsWith(prefixes[i])) return true;
    return false;
  }

  private static boolean equalsAny(String value, String[] names) {
    for (int i = 0; i < names.length; i++)
      if (value.equalsIgnoreCase(names[i])) return true;
    return false;
  }

  private static int indexOfSegment(String segment, char c) {
    return segment.indexOf(c);
  }

  private static String tailAfterColon(String segment) {
    int at = segment.lastIndexOf(':');
    return at < 0 ? segment : segment.substring(at + 1);
  }
}
