package almlk;

/**
 * إِشرَاقُ الوَجهَةِ الجَارِيَةِ عَلى حافَّةٍ: إِعلَانٌ عِندَمَا يَتَغَيَّرُ الوَصفُ، لَا عَلى
 * كُلِّ رَسمٍ.
 *
 * <p>الدَّاءُ الَّذِي كُتِبَ هٰذَا الصِّنَفُ لِأَجۡلِهِ (ج٥٨) لَيسَ «نَشرًا زَائِدًا» بَلۡ
 * حافَّةٌ وَاحِدَةٌ فِي المِبۡدَأ: كَانَتِ الصَّفحَةُ إِذَا رَسَمَتِ الوَسومَ تُعلِنُ «هٰذِهِ هِيَ
 * الوَجهَةُ الجَارِيَة» مَعَ أَنَّ الرَّسمَ لَا يُغَيِّرُ الوَجهَةَ فِي شَيءٍ. وَإِذَا كَانَ
 * الجِسۡرُ يُجِيبُ الإِعلَانَ بِنَشرٍ، فَالنَّشرُ يُولِدُ إِعلَانًا يُولِدُ نَشرًا — وَقَدۡ سَقَطَتِ
 * الوَاجِهَةُ بِ‏{@link StackOverflowError} عِندَ الإِقلَاعِ عَلَىٰ ذٰلِكَ (ج٥٤، عَلى الجِهَازِ).
 *
 * <p>مَا فَعَلَتۡهُ ج٥٤ أَحۡرَاسٌ: حَارِسُ خَيطِ النَّشرِ، وَإِعلَانُ المُتَغَيِّرِ فَقطۡ عِندَ
 * الإِفرَاغِ. كِلَاهُمَا يُبقي الدَّورَةَ مَحۡدُودَةً لَا مَعدُومَةً، وَكِلَاهُمَا يَعرِفُ طَرِيقًا
 * وَيَجهَلُ غَيرَهُ — فَكُلُّ نَشرٍ لَا يَمُرُّ بِبَابِ الجِسۡرِ (كَإِقلَاعٍ لَا مَشرُوعَ فِيهِ)
 * يَبقَى حَارِسُهُ مَفتُوحًا. أَمَّا هٰذَا الصِّنَفُ فَيَقطَعُ الدَّورَةَ فِي نَفسِهَا: إِعلَانٌ
 * بِوَصفٍ لَمۡ يَتَغَيَّرۡ لَا يُرسَلُ أَبَدًا، فَتَكونُ الحَلقَةُ قَدۡ اِنتَهَتۡ عِندَمَا اِنتَهَيۡنَا
 * مِنَ الوَصفِ — لَا عِندَمَا تَذَكَّرۡنَا مَن بَدَأَ النَّشرَ.
 *
 * <p>الحَقُّ الَّذِي لَا يَنقُص: الوَصفُ هُوَ (اسمُ التَّبويبِ، مرجَعُهُ المُحَلَّلُ). فَإِن
 * ظَهَرَ المرجَعُ المُحَلَّلُ بَعدَ الرَّسمِ الأَوَّلِ — وَذٰلِكَ هُوَ سَبَبُ إِعلَانِنَا مِن
 * دَاخِلِ الرَّسمِ أَصلًا (ج٤٧: الوَسمُ لَا يُعرَفُ مُجَرَّدًا وَحۡدَهُ) — فَالحافَّةُ تَلحَقُ
 * التَّغَيُّرَ مَرَّةً وَاحدَةً، وَلَا تَسكُتُ عَنهُ.
 */
public final class EditorFocusEdge {

  /** مَا يَسمَعُ الإِعلَانَ (عِندَ الصَّفحَةِ: المُضيفُ الَّذِي يَحمِلُ وَحدَةَ الفَحصِ). */
  public interface Sink {
    void onFocus(String fileName, String reference);
  }

  private String announcedFile;
  private String announcedReference;

  /** أُعلِنَ شَيءٌ قَبلُ: بِدُونِهَا يَكُونُ «لَا وَجهَ» أَوَّلَ مَرَّةٍ إِعلَانًا كَاذِبًا. */
  private boolean primed;

  /** شَاهِدَانِ لِلمُجَرَّبِ: كَمۡ مَرَّةٍ سُمِعَ الإِعلَانُ، وَكَمۡ مَرَّةٍ لَمۡ يَكُنۡ لَهُ مَعنًى. */
  private int announcements;

  private int suppressions;

  /**
   * @return {@code true} إِنَّ سُمِعَ الإِعلَانُ (تَغَيُّرٌ حَقٌّ)، وَ{@code false} إِنَّ الوَصفَ
   *     هُوَ هُوَ — فَلا شَيءَ يَنبَغِي أن يُعادَ لِأَجلِهِ.
   */
  public boolean announce(Sink sink, String fileName, String reference) {
    if (primed && same(announcedFile, fileName) && same(announcedReference, reference)) {
      suppressions++;
      return false;
    }
    primed = true;
    announcedFile = fileName;
    announcedReference = reference;
    announcements++;
    if (sink != null) sink.onFocus(fileName, reference);
    return true;
  }

  /** الوَصفُ الحَالِيُّ: مَا يَعرِفُهُ الصِّنَفُ أَنَّهُ أُعلِنَ آخِرًا. */
  public boolean isCurrent(String fileName, String reference) {
    return primed && same(announcedFile, fileName) && same(announcedReference, reference);
  }

  /**
   * المِبۡدَأُ يُغلَقُ وَالتَّبويِبُ يَفرَغُ وَالوَاجِهُ تُهَيَّأُ مِن جَدِيدٍ: الوَصفُ الحافِظُ
   * يَسقُطُ لِئَلَّا يَبقَى «حَالِيٌّ» لَا صَاحِبَ لَهُ، فَإِنَّ نِسيَانَ الحافَّةِ إِعلَانٌ
   * ضَائِعٌ وَاحدٌ — وَتَذَكُّرَهُ سَقۡطَةُ وَاجِهَةٍ.
   */
  public void forget() {
    primed = false;
    announcedFile = null;
    announcedReference = null;
  }

  public int announcements() {
    return announcements;
  }

  public int suppressions() {
    return suppressions;
  }

  private static boolean same(String left, String right) {
    return left == null ? right == null : left.equals(right);
  }
}
