package almlk;

import com.almlkid.kay.ui.CodeLanguageTools.Diagnostic.Severity;

/**
 * تصنيفُ التشخيص — جدولٌ واحد وقرارٌ واحد (W6).
 *
 * <p>المرجع يحمل تصنيفه في حقلٍ واحد داخل كل تشخيص ({@code com.aide.engine.SyntaxError#f313FH})
 * ويقرأه بأربعة قرارات فقط، كلها مثبتة من المصدر المفكوك: {@code m190Hw()} أي {@code ==0} (الخطأ
 * الأساسي)، {@code m189FH()} أي {@code ==400}، {@code m193v5()} أي {@code ==500}، و{@code m191Zo()}
 * للعائلة {@code {2, 250, 251, 101…112, 200…204}} التي تُدير العرضَ والسلوك معًا. أما **مغزى كل
 * رقم** فيُحسب داخل المحرّك الأصلي ({@code C0048c} تَسنده من {@code La.rN}: طبقة native غير مفكوكة
 * عندنا)، فلا نَنقل الأرقام ولا ندّعي دلالتها — وما نَنقله هو العقد نفسه: لا يشذّ تشخيص عن تصنيفه،
 * والقرار كله في جدول واحد.
 *
 * <p>عندنا كان الحقل يُملأ بالحرف {@code "CODE"} لكل تشخيص دلالي (بقايا نقلٍ نصّي)، أي أن كل ما
 * عدا النحوي كان «غير مصنَّف» بلا استثناء. هذا الجدول هو المُحِلّ محله، ويُثبَّت به أيضًا أن رسالة
 * المرجع لا تُسرَّب وسومها ({@link #applyQuoteRule}) وقاعدةُ تسمية موضوعها ({@link #quotesSubjects}).
 */
public final class JavaDiagnosticCodes {

  private JavaDiagnosticCodes() {}

  /** رمز فاحص النحوي نفسه (كان موجودًا ويُستعمل): كل ما يرميه {@code JavaSyntaxChecker}. */
  public static final String SYNTAX = JavaSyntaxChecker.CODE;

  /** اسمٌ لا يُحلّ: كيانٌ أو نوعٌ أو عضوٌ أو متغيّرٌ أو حزمة. */
  public static final String UNKNOWN_SYMBOL = "UNKNOWN_SYMBOL";

  /** اسمٌ يحتمل أكثر من مصدر: لا يُختار له واحدٌ بالترتيب، ولا يُستورد له شيء. */
  public static final String AMBIGUOUS = "AMBIGUOUS";

  /** لا يوافق النوع ما طُلب: تعيينٌ أو إرجاعٌ أو التقاط/رميٌ أو استعمالٌ لا ينطبق. */
  public static final String TYPE_MISMATCH = "TYPE_MISMATCH";

  /** زائدٌ لا يغيّر شيئًا: قيدٌ أو قسمان متطابقان أو سطرٌ فارغ أو عضوٌ لا يُقرأ. */
  public static final String REDUNDANT = "REDUNDANT";

  /** اصطدامُ إعلانٍ أو حالةُ تدفّق (تكرارُ اسم، final، تهيئةٌ ناقصة، استثناءٌ لا يُلْتَقَط). */
  public static final String DECLARATION_STATE = "DECLARATION_STATE";

  /**
   * جولةُ ٤١: العُضوُ مَوجودٌ في الكتالوجِ لكنَّهُ لا يُتاحُ على إصدارِ المشروعِ — «‏requires API‏»
   * و«‏removed in API‏». عائلةٌ مُستقِلَّةٌ لأنَّ الحُكمَ ليسَ على الاسمِ ولا على النوعِ بل على
   * ‏minSdk/compileSdk‏ المَذكورَينِ في ‏build.gradle‏، وليست الناقِصَةُ منها «نحويًّا» بحالٍ:
   * الشيفرَةُ تَمامُ الجُملةِ، والمنصَّةُ هي التي تُجيبُ.
   */
  public static final String API_LEVEL = "API_LEVEL";

  /** لا عائلة له: يظهر صريحًا فتلتقطه البوابة، بدل أن يتنكّر زمرةً أو يبقى {@code "CODE"} خفية. */
  public static final String UNCLASSIFIED = "UNCLASSIFIED";

  /**
   * عائلةُ مفتاح الرسالة الدلالية تُشتَقّ ببنية الاسم لا بسردٍ يدوي، فلا يسقط منها مفتاحٌ جديد؛
   * وما لا يرميه الفاحصُ الدلالي (رسائلُ البناء والسمالي) يبقى صراحةً في {@link #UNCLASSIFIED}
   * عندنا، لأن منتجَه يحمل تشخيصَه برمزِه الخاص.
   */
  public static String codeOf(String messageKey) {
    if (messageKey == null) return UNCLASSIFIED;
    String key =
        messageKey.startsWith(PREFIX) ? messageKey.substring(PREFIX.length()) : messageKey;
    if (key.startsWith("ambiguous")) return AMBIGUOUS;
    if (key.startsWith("unknown")
        || key.startsWith("no_such")
        || key.startsWith("abstract_instantiation")
        || key.startsWith("call_on_primitive")) return UNKNOWN_SYMBOL;
    if (key.startsWith("incompatible")
        || key.startsWith("no_applicable")
        || key.startsWith("not_applicable")
        || key.startsWith("not_compatible")
        || key.startsWith("these_types")
        || key.startsWith("condition_not")
        || key.startsWith("index_not")
        || key.startsWith("array_size")
        || key.startsWith("array_length")
        || key.startsWith("expected_collection")
        || key.startsWith("throw_not")
        || key.startsWith("catch_not")
        || key.startsWith("class_extends")
        || key.startsWith("class_implements")
        || key.startsWith("enum_implements")
        || key.startsWith("interface_extends")
        || key.startsWith("must_return")
        || key.startsWith("method_must_return")) return TYPE_MISMATCH;
    // W27/3: «عليهِ تنفيذُ الدوالِّ المجرّدةِ» حالةُ إعلانِ الصنفِ لا مِثالُ أنواعٍ (‏1.0.180).
    if (key.startsWith("must_implement") || key.startsWith("must_be_")) return DECLARATION_STATE;
    if (key.startsWith("redundant")
        || key.startsWith("cast_not_required")
        || key.startsWith("assignment_no_effect")
        || key.startsWith("if_else_identical")
        || key.startsWith("empty_statement")
        || key.startsWith("already_imported")
        || key.startsWith("unreachable")
        || key.startsWith("possible_fall")
        || key.startsWith("initializer_returns")
        || key.startsWith("constructor_returns")
        || key.startsWith("void_method_returns")
        || key.startsWith("unused")
        || key.startsWith("method_never")
        || key.startsWith("variable_never")
        || key.startsWith("parameter_never")
        || key.startsWith("duplicate_modifier")
        || key.startsWith("there_is_no_read")
        || key.startsWith("can_be_")) return REDUNDANT;
    if (key.startsWith("duplicate")
        || key.startsWith("exception_")
        || key.startsWith("final_")
        || key.startsWith("initializer_must")
        || key.startsWith("field_")
        || key.startsWith("variable_not")
        || key.startsWith("public_class_name")) return DECLARATION_STATE;
    // الباقي بنيةٌ نصّية: الرمي والتكرار والوسوم غير المغلقة وانتهاءُ بناءٍ — عائلةُ النحوي الواحدة
    // (يرميها فاحصُ النحوي ومحلّلُ الوسوم برمزها أصلًا، فلا تصنيفَ ثانيًا لها).
    // استثناءٌ صريح: {@code missing_method} يرميه الفاحصُ الدلالي ورسالته «Unknown method 'x' of
    // 'y'» تُسمّي موضوعها باقتباسين — فقياسُ W7 أثبت أن وضعَه مع النحوي كان خطأً يُبطل قاعدةَ
    // الاقتباس عن أكثر البلاغات شيوعًا في التحرير. وبقيةُ «missing*» نحويٌّ حقًّا (فاصلة، جسمُ صنف،
    // {@code extends}، {@code implements}).
    // جولةُ ٤١:availabilityُ العُضوِ بحسبِ إصدارِ المشروعِ — بنيةُ الاسمِ تَكتَفِي ب‏_api`‏ خاتِمَةً،
    // فلا يَلحَقُ بها مفتاحٌ يُستَعمَلُ اليومَ ولا يَنفُتُ منها مفتاحٌ يُضافُ غَدًا بلا جَدوَلٍ ثانٍ.
    if (key.endsWith("_api") || key.endsWith("_api_level")) return API_LEVEL;
    if (key.equals("missing_method")) return UNKNOWN_SYMBOL;
    if (key.startsWith("missing")
        || key.startsWith("unexpected")
        || key.startsWith("unclosed")
        || key.startsWith("unmatched")
        || key.startsWith("mismatched")
        || key.startsWith("invalid")
        || key.startsWith("closing_tag")
        || key.startsWith("binary_operator")
        || key.startsWith("unary_operator")
        || key.startsWith("break_outside")
        || key.startsWith("continue_outside")
        || key.startsWith("not_a_statement")) return SYNTAX;
    return UNCLASSIFIED;
  }

  private static final String PREFIX = "ui_diagnostic_";

  /** عائلةُ النحوي وحدها تُبطل التقريرَ الدلالي على سطرٍ مكسور — وهي قرارُ المنتجين كلهم. */
  public static boolean isSyntaxCode(String code) {
    return SYNTAX.equals(code);
  }

  /**
   * هل يُعرض هذا التشخيص في لوحة الأخطاء؟ **القرار الصريح (G9): الخطأ نعم والتحذير لا** — لأن رأس
   * اللوحة يعدّ «errors» حرفيًا ({@code view_no_errors}/{@code view_one_error}/{@code view_errors})،
   * ولكل صفوف المرجع أيقونةٌ واحدة ({@code project_errors}) فلا مزجَ بصريّ للعائلتين؛ ولا يُدّعى
   * أكثر من ذلك عن المرجع لأن قائمته تُبنى في {@code U.we()} غير المفكوكة. لا يُغيّر هذا العددُ ولا
   * الشكلُ شيئًا: إنه التوثيق الصريح للقاعدة القائمة، ومرجعُها الواحد بدل مقارنةِ شدةٍ مبعثرة.
   */
  public static boolean showsInPanel(String code, Severity severity) {
    return severity == Severity.ERROR && !isUnused(code, null);
  }

  /**
   * أسرةُ تلميحاتِ المحرِّرِ (الجولةُ ‏30، شرطٌ دائمٌ ‏21): التحويلُ غيرُ الضروريِّ، وما لا وصولَ إليهِ
   * من متغيِّرٍ ودالةٍ وحقلٍ ومعامِلٍ — لا تُعتبَرُ أخطاءً، ولا تُذكَرُ في لوحِ الأخطاءِ، ولا تُعَدُّ
   * في الشارةِ؛ لَها خطٌّ أصفرُ متعرِّجٌ تحتَ الرمزِ وحدَهُ.
   *
   * <p>المرجعُ يُثبِتُ البِنيةَ لا اللفظَ: صفوفُ اللوحةِ تُبنى من مصفوفةِ {@code SyntaxError[]} التي
   * يَبثُّها المُحرِّكُ لكلِّ ملفٍ ({@code ErrorBrowser.m25FH} يَقرَأُ {@code U.we().DW(path)})،
   * و{@code SyntaxError.f313FH == 0} يعني «لا شيءَ» عندَهُ ({@code m190Hw()})؛ وأمّا زينةٌ لا خطأَ
   * تحتَها فمَجراها جَدوَلاَنِ آخرانِ في {@code AIDEEditor$C0009a} غيرُ الجدولِ الذي يُغذّي اللوحةَ.
   * فالتلميحُ عندَهُ لا يَستطيعُ دخولَ اللوحةِ بِناءً على مُعرِّفِهِ؛ ولا حاجةَ لنا بقاعدةِ استثناءٍ
   * مبعثرةٍ: إِخراجُهُ بـ{@code INFO} هو كلُّ شيءٍ، واللوحةُ مَبنيَّةٌ على {@code listsInPanel} من
   * قبلُ.
   */
  public static boolean isEditorOnlyHint(String messageKey) {
    if (messageKey == null) return false;
    switch (messageKey) {
      case "ui_diagnostic_cast_not_required":
      case "ui_diagnostic_variable_never_accessed":
      case "ui_diagnostic_method_never_used":
      case "ui_diagnostic_parameter_never_accessed":
      case "ui_diagnostic_unused_private_field":
        return true;
      default:
        return false;
    }
  }

  /**
   * المَصبُّ الواحدُ للأسرةِ: ما كانَ تلميحًا يَخرُجُ بـ{@code INFO} مهما نَدَبَهُ المُنتِجُ إنذارًا؛
   * فلا يُترَكُ قرارُ اللونِ والعدِّ لكلِّ مُنتِجٍ على حدةٍ. وهو إحلالٌ لا مُوازيةٌ: فُروُعُ
   * {@code WARNING} الخمسةُ في المُنتِجَينِ صارتْ {@code INFO} من هذا البابِ وحدَهُ.
   */
  public static boolean isUnusedMessageKey(String messageKey) {
    return (messageKey != null && messageKey.startsWith("ui_diagnostic_unused_"))
        || "ui_diagnostic_variable_never_accessed".equals(messageKey)
        || "ui_diagnostic_method_never_used".equals(messageKey)
        || "ui_diagnostic_parameter_never_accessed".equals(messageKey)
        || "ui_diagnostic_unused_private_field".equals(messageKey);
  }

  public static boolean isUnused(String code, String messageKey) {
    return (code != null && code.startsWith("UNUSED_")) || isUnusedMessageKey(messageKey);
  }

  public static Severity severityFor(String messageKey, Severity declared) {
    if (isUnusedMessageKey(messageKey)) return Severity.WARNING;
    return isEditorOnlyHint(messageKey) ? Severity.INFO : declared;
  }

  /**
   * العائلات التي تُسمّي **موضوع الرمز** (اسمًا أو نوعًا أو عضوًا)، وقاعدتُها — كما في المرجع — أن
   * يكون الاسم بين اقتباسين. العائلتان الأخريان خارج القاعدة عن بَصيرة: النحويُّ يسمّي رمزًا نصيًا
   * لا موضوعًا، و{@link #DECLARATION_STATE} وسائطه **مساراتُ ملفات** لا أسماءُ رموز — قياسُ كل
   * مفاتيح الكتالوج في اللغتين يُظهر {@code duplicate_class} و{@code public_class_name_mismatch}
   * وحدهما فيها، وكلاهما يذكر اسم الملف.
   */
  public static boolean quotesSubjects(String code) {
    return UNKNOWN_SYMBOL.equals(code)
        || AMBIGUOUS.equals(code)
        || TYPE_MISMATCH.equals(code)
        || REDUNDANT.equals(code);
  }

  /**
   * قاعدةُ الاقتباس كما في المرجع ({@code f323u7.replace("</C>","'").replace("<//C>","'")}) —
   * تطبَّق مرةً واحدة في صانع التشخيص، فتتساوى اللوحة والفقاعة وشريطُ التحديد ولقطةُ المشروع.
   * وهي مُعرَّفة على النص المُصاغ: لا وسمَ ينجو إلى الشاشة مهما أُضيفت رسائل جديدة.
   */
  public static String applyQuoteRule(String message) {
    if (message == null || message.indexOf('<') < 0) return message;
    // الوسمان فتحٌ وإغلاقٌ في المرجع، فالاثنان يصيران الاقتباسَ نفسه؛ وحذفُ الفاتح وحده يخلّف
    // اقتباسًا أعرج (Foo' بلا فاتحة) — لذلك يُقلب الفاتح أيضًا، بلا استثناءٍ ولا ابتكار.
    return message.replace("</C>", "'").replace("<//C>", "'").replace("<C>", "'");
  }
}
