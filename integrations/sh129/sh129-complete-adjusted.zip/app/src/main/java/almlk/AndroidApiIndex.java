package almlk;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Pattern;
import java.util.zip.GZIPInputStream;

/**
 * Offline knowledge of the Android platform used by code completion: every public class with its
 * typed members, parameter names and API levels, plus the XML attribute/styleable/widget tables.
 *
 * <p>The data is produced from the official SDK by {@code qa/tools/AndroidApiIndexGenerator} and
 * shipped as {@code assets/completion/*.idx.gz}. Loading is lazy and happens once on a worker
 * thread: only the class table is parsed eagerly; a class's member block is decoded the first time
 * that class is asked for, then cached. All query methods are thread-safe and never block the UI
 * thread unless they are called there before the warm-up finished.
 */
public final class AndroidApiIndex {

  /** Opens an asset by its name relative to {@code assets/} (device) or a directory (tests). */
  public interface StreamSource {
    InputStream open(String name) throws IOException;
  }

  public static final String API_ASSET = "completion/android-api.idx.gz";
  public static final String XML_ASSET = "completion/android-xml.idx.gz";

  /** A public platform class, interface, enum or annotation. */
  public static final class ClassInfo {
    public final String qualifiedName, simpleName, packageName, container, kind;
    public final String superName;
    public final String[] interfaces, typeParameters;
    public final int since, deprecated, removed;
    final int memberStart, memberEnd;
    /** Index text holding the member block: null = the platform asset. */
    final byte[] data;
    /** Library class (M4): read from a dependency JAR/AAR or synthesised (R). */
    public final boolean library;
    /** Not public: kept only so supertype chains through it stay complete. */
    public final boolean hidden;
    /** Built from changing sources (the app's R): its absence of a member proves nothing. */
    public final boolean provisional;
    volatile List<Member> members;
    volatile List<Member> constructors;

    ClassInfo(String[] f, int memberStart, int memberEnd) {
      this(f, memberStart, memberEnd, null);
    }

    ClassInfo(String[] f, int memberStart, int memberEnd, byte[] data) {
      qualifiedName = f[1];
      kind = f[2];
      since = parse(f[3], 1);
      deprecated = parse(f[4], 0);
      removed = parse(f[5], 0);
      superName = f.length > 6 ? f[6] : "";
      interfaces = f.length > 7 && !f[7].isEmpty() ? f[7].split(",") : new String[0];
      typeParameters = f.length > 8 && !f[8].isEmpty() ? f[8].split(",") : new String[0];
      String flags = f.length > 9 ? f[9] : "";
      this.data = data;
      library = data != null;
      hidden = flags.indexOf('h') >= 0;
      provisional = flags.indexOf('v') >= 0;
      if (f.length > 10) {
        packageName = f[10];
      } else {
        int pkgEnd = packageEnd(qualifiedName);
        packageName = pkgEnd < 0 ? "" : qualifiedName.substring(0, pkgEnd);
      }
      int dot = qualifiedName.lastIndexOf('.');
      simpleName = qualifiedName.substring(dot + 1);
      container = dot < 0 ? "" : qualifiedName.substring(0, dot);
      this.memberStart = memberStart;
      this.memberEnd = memberEnd;
    }

    public boolean isInterface() {
      return kind.equals("i") || kind.equals("a");
    }

    /** Nested types are imported through their container, e.g. {@code android.view.View}. */
    public boolean isNested() {
      return !container.equals(packageName);
    }
  }

  /** A field, method or constructor of a platform class. */
  public static final class Member {
    public static final int FIELD = 0, METHOD = 1, CONSTRUCTOR = 2;
    public final int kind;
    public final String name, type, parameters;
    public final boolean isStatic, isProtected;
    public final int since, deprecated, removed;
    public final ClassInfo owner;

    Member(int kind, String name, String flags, String type, String parameters, String levels,
        ClassInfo owner) {
      this.kind = kind;
      this.name = name;
      this.type = type;
      this.parameters = parameters;
      this.isStatic = flags.indexOf('s') >= 0;
      this.isProtected = flags.indexOf('p') >= 0;
      this.owner = owner;
      String[] l = levels.isEmpty() ? new String[0] : levels.split(",", -1);
      since = l.length > 0 && !l[0].isEmpty() ? parse(l[0], owner.since) : owner.since;
      deprecated = l.length > 1 && !l[1].isEmpty() ? parse(l[1], owner.deprecated) : owner.deprecated;
      removed = l.length > 2 && !l[2].isEmpty() ? parse(l[2], owner.removed) : owner.removed;
    }

    /** The type as shown in the completion row: simple names, e.g. {@code List<String>}. */
    public String displayType() {
      return simpleTypeText(type);
    }
  }

  /** One XML attribute of the {@code android:} namespace. */
  public static final class AttrInfo {
    public final String name, format;
    public final String[] values;
    public final int since, deprecated, removed;

    AttrInfo(String[] f) {
      name = f[1];
      format = f[2];
      values = f[3].isEmpty() ? new String[0] : f[3].split(",");
      String[] l = f[4].split(",", -1);
      since = parse(l[0], 1);
      deprecated = l.length > 1 ? parse(l[1], 0) : 0;
      removed = l.length > 2 ? parse(l[2], 0) : 0;
    }

    /** Java-like value type shown after the attribute name (layout_width : int). */
    public String valueType() {
      if (format.contains("string")) return "String";
      if (format.contains("boolean")) return "boolean";
      if (format.contains("float") || format.contains("fraction")) return "float";
      return "int";
    }
  }

  private static final Object LOCK = new Object();
  private static volatile StreamSource source;
  private static volatile boolean apiLoaded, xmlLoaded;
  private static byte[] apiData = new byte[0];
  private static Map<String, ClassInfo> byQualified = Collections.emptyMap();
  private static Map<String, List<ClassInfo>> bySimple = Collections.emptyMap();
  private static Map<String, List<ClassInfo>> byContainer = Collections.emptyMap();
  /** Simple names sorted case-insensitively for prefix searches. */
  private static ClassInfo[] sortedBySimple = new ClassInfo[0];
  private static Map<String, AttrInfo> attrs = Collections.emptyMap();
  private static Map<String, List<String>> styleables = Collections.emptyMap();
  private static volatile List<ClassInfo> viewClasses;

  /**
   * M4: classes of the project's libraries, swapped atomically after every resolution. Every query
   * below consults the platform first and then this layer, so completion, auto-import, supertype
   * chains and XML views see library classes through the same public methods.
   */
  static final class Layer {
    static final Layer EMPTY = new Layer(new ArrayList<ClassInfo>(), 0);
    final Map<String, ClassInfo> byQualified = new HashMap<>();
    final Map<String, List<ClassInfo>> bySimple = new HashMap<>();
    final Map<String, List<ClassInfo>> byContainer = new HashMap<>();
    final ClassInfo[] sortedBySimple;
    final java.util.Set<String> packages = new java.util.HashSet<>();
    final int generation;
    volatile List<ClassInfo> views;

    Layer(List<ClassInfo> classes, int generation) {
      this.generation = generation;
      ArrayList<ClassInfo> visible = new ArrayList<>();
      for (ClassInfo c : classes) {
        if (byQualified.containsKey(c.qualifiedName)) continue; // first on the classpath wins
        byQualified.put(c.qualifiedName, c);
        if (c.hidden) continue;
        visible.add(c);
        bySimple.computeIfAbsent(c.simpleName, k -> new ArrayList<>(1)).add(c);
        for (String p = c.packageName; !p.isEmpty(); p = p.lastIndexOf('.') < 0 ? "" : p.substring(0, p.lastIndexOf('.')))
          if (!packages.add(p)) break;
      }
      ClassInfo[] sorted = visible.toArray(new ClassInfo[0]);
      Arrays.sort(sorted, (a, b) -> {
        int c = a.simpleName.compareToIgnoreCase(b.simpleName);
        return c != 0 ? c : a.qualifiedName.compareTo(b.qualifiedName);
      });
      for (ClassInfo c : sorted) byContainer.computeIfAbsent(c.container, k -> new ArrayList<>()).add(c);
      sortedBySimple = sorted;
    }

    int size() {
      return byQualified.size();
    }
  }

  private static volatile Layer libraries = Layer.EMPTY;

  /** Parses library index texts (same format as the asset) into a layer; first class wins. */
  static Layer buildLayer(List<byte[]> blocks, int generation) {
    ArrayList<ClassInfo> classes = new ArrayList<>();
    for (byte[] data : blocks) {
      if (data == null) continue;
      int lineStart = 0;
      String[] pending = null;
      int pendingMembers = 0;
      for (int i = 0; i <= data.length; i++) {
        if (i < data.length && data[i] != '\n') continue;
        if (i > lineStart && data[lineStart] == 'C') {
          if (pending != null) classes.add(new ClassInfo(pending, pendingMembers, lineStart, data));
          pending = new String(data, lineStart, i - lineStart, StandardCharsets.UTF_8).split("\t", -1);
          pendingMembers = i + 1;
        }
        lineStart = i + 1;
      }
      if (pending != null) classes.add(new ClassInfo(pending, pendingMembers, data.length, data));
    }
    return new Layer(classes, generation);
  }

  /** Installs (or clears with null) the library layer and drops caches derived from it. */
  static void installLibraries(Layer layer) {
    libraries = layer == null ? Layer.EMPTY : layer;
    PlatformMemberLookup.clearLibraryCache();
  }

  /** Number of library classes currently merged (0 = none). */
  public static int libraryClassCount() {
    return libraries.size();
  }

  /** A known package of the platform or the libraries (for import checks). */
  public static boolean isKnownPackage(String packageName) {
    if (packageName == null || packageName.isEmpty()) return false;
    ensureApi();
    if (byContainer.containsKey(packageName) || libraries.packages.contains(packageName)) return true;
    String prefix = packageName + ".";
    for (String container : byContainer.keySet()) if (container.startsWith(prefix)) return true;
    return false;
  }

  /** The platform table is available (loads it on first call; callers run off the UI thread). */
  public static boolean isLoaded() {
    ensureApi();
    return apiLoaded;
  }

  private static <T> List<T> merge(List<T> first, List<T> second) {
    if (second == null || second.isEmpty()) return first == null ? Collections.<T>emptyList() : first;
    if (first == null || first.isEmpty()) return second;
    ArrayList<T> out = new ArrayList<>(first.size() + second.size());
    out.addAll(first);
    out.addAll(second);
    return out;
  }

  private AndroidApiIndex() {}

  /** Registers where the data lives; previously loaded data is dropped if the source changes. */
  public static void install(StreamSource streams) {
    synchronized (LOCK) {
      if (streams == null || source != null) return; // the asset source never changes at runtime
      source = streams;
      apiLoaded = false;
      xmlLoaded = false;
    }
  }

  public static boolean isInstalled() {
    return source != null;
  }

  /** Loads both tables on a daemon thread so the first completion request does not wait. */
  public static void warmUpAsync() {
    if (source == null || (apiLoaded && xmlLoaded)) return;
    Thread worker = new Thread(() -> {
      ensureApi();
      ensureXml();
    }, "AndroidApiIndex");
    worker.setDaemon(true);
    worker.setPriority(Thread.MIN_PRIORITY);
    worker.start();
  }

  // ───────────────────────────── loading ─────────────────────────────

  /**
   * يفتح أصلًا مضغوطًا. أداة تغليف أندرويد تفك أصول {@code .gz} وتحذف الامتداد داخل الـAPK،
   * فيُجرَّب الاسم دون الامتداد عند غيابه، ويُكشف gzip بتوقيعه لا بالاسم.
   */
  public static InputStream openPacked(StreamSource streams, String name) throws IOException {
    InputStream raw;
    try {
      raw = streams.open(name);
    } catch (IOException missing) {
      if (!name.endsWith(".gz")) throw missing;
      raw = streams.open(name.substring(0, name.length() - 3));
    }
    java.io.BufferedInputStream in = new java.io.BufferedInputStream(raw, 1 << 16);
    try {
      in.mark(2);
      int first = in.read();
      int second = in.read();
      in.reset();
      return first == 0x1f && second == 0x8b ? new GZIPInputStream(in, 1 << 16) : in;
    } catch (IOException | RuntimeException failure) {
      in.close();
      throw failure;
    }
  }

  private static byte[] readAll(String name) {
    StreamSource streams = source;
    if (streams == null) return null;
    try (InputStream in = openPacked(streams, name)) {
      ByteArrayOutputStream out = new ByteArrayOutputStream(1 << 20);
      byte[] buffer = new byte[1 << 16];
      int n;
      while ((n = in.read(buffer)) > 0) out.write(buffer, 0, n);
      return out.toByteArray();
    } catch (IOException | RuntimeException error) {
      return null;
    }
  }

  private static void ensureApi() {
    if (apiLoaded) return;
    synchronized (LOCK) {
      if (apiLoaded) return;
      byte[] data = readAll(API_ASSET);
      HashMap<String, ClassInfo> qualified = new HashMap<>(8192);
      HashMap<String, List<ClassInfo>> simple = new HashMap<>(8192);
      if (data != null) {
        int lineStart = 0;
        String[] pending = null;
        int pendingMembers = 0;
        for (int i = 0; i <= data.length; i++) {
          if (i < data.length && data[i] != '\n') continue;
          if (i > lineStart && data[lineStart] == 'C') {
            if (pending != null) add(qualified, simple, new ClassInfo(pending, pendingMembers, lineStart));
            pending = new String(data, lineStart, i - lineStart, StandardCharsets.UTF_8).split("\t", -1);
            pendingMembers = i + 1;
          }
          lineStart = i + 1;
        }
        if (pending != null) add(qualified, simple, new ClassInfo(pending, pendingMembers, data.length));
        apiData = data;
      }
      ClassInfo[] sorted = qualified.values().toArray(new ClassInfo[0]);
      Arrays.sort(sorted, (a, b) -> {
        int c = a.simpleName.compareToIgnoreCase(b.simpleName);
        return c != 0 ? c : a.qualifiedName.compareTo(b.qualifiedName);
      });
      HashMap<String, List<ClassInfo>> containers = new HashMap<>();
      for (ClassInfo c : sorted) containers.computeIfAbsent(c.container, k -> new ArrayList<>()).add(c);
      byQualified = qualified;
      bySimple = simple;
      byContainer = containers;
      sortedBySimple = sorted;
      apiLoaded = data != null;
    }
  }

  private static void add(Map<String, ClassInfo> qualified, Map<String, List<ClassInfo>> simple,
      ClassInfo info) {
    qualified.put(info.qualifiedName, info);
    simple.computeIfAbsent(info.simpleName, k -> new ArrayList<>(1)).add(info);
  }

  private static void ensureXml() {
    if (xmlLoaded) return;
    synchronized (LOCK) {
      if (xmlLoaded) return;
      byte[] data = readAll(XML_ASSET);
      LinkedHashMap<String, AttrInfo> a = new LinkedHashMap<>();
      HashMap<String, List<String>> s = new HashMap<>();
      if (data != null) {
        for (String line : new String(data, StandardCharsets.UTF_8).split("\n")) {
          if (line.isEmpty() || line.charAt(0) == '#') continue;
          String[] f = line.split("\t", -1);
          switch (f[0]) {
            case "A":
              AttrInfo attr = new AttrInfo(f);
              a.put(attr.name, attr);
              break;
            case "S":
              s.put(f[1], Collections.unmodifiableList(Arrays.asList(f[2].split(","))));
              break;
            default:
              break;
          }
        }
      }
      attrs = a;
      styleables = s;
      xmlLoaded = data != null;
    }
  }

  // ───────────────────────────── classes ─────────────────────────────

  public static ClassInfo classByQualifiedName(String qualifiedName) {
    ensureApi();
    if (qualifiedName == null) return null;
    String name = stripGenerics(qualifiedName);
    ClassInfo platform = byQualified.get(name);
    return platform != null ? platform : libraries.byQualified.get(name);
  }

  /** Visible (public) class by qualified name: platform, then libraries; hidden ones excluded. */
  private static ClassInfo visibleClass(String name) {
    ClassInfo platform = byQualified.get(name);
    if (platform != null) return platform;
    ClassInfo library = libraries.byQualified.get(name);
    return library == null || library.hidden ? null : library;
  }

  public static List<ClassInfo> classesNamed(String simpleName) {
    ensureApi();
    if (simpleName == null) return Collections.emptyList();
    return merge(bySimple.get(simpleName), libraries.bySimple.get(simpleName));
  }

  /**
   * Resolves a type written in source: qualified, imported (single or on-demand), java.lang or a
   * unique simple name. Returns null when the name is not a platform class.
   */
  public static ClassInfo resolve(String written, List<String> imports) {
    String name = stripGenerics(written == null ? "" : written.trim());
    while (name.endsWith("[]")) name = name.substring(0, name.length() - 2);
    if (name.isEmpty()) return null;
    ensureApi();
    if (name.indexOf('.') > 0) {
      ClassInfo direct = visibleClass(name);
      if (direct != null) return direct;
      int dot = name.indexOf('.');
      ClassInfo outer = resolve(name.substring(0, dot), imports);
      return outer == null ? null : visibleClass(outer.qualifiedName + name.substring(dot));
    }
    List<ClassInfo> candidates = classesNamed(name);
    if (candidates.isEmpty()) return null;
    if (imports != null) {
      for (String imp : imports) if (imp.equals(name) || imp.endsWith("." + name)) {
        ClassInfo exact = visibleClass(imp);
        if (exact != null) return exact;
      }
      for (String imp : imports) if (imp.endsWith(".*")) {
        ClassInfo onDemand = visibleClass(imp.substring(0, imp.length() - 1) + name);
        if (onDemand != null) return onDemand;
      }
    }
    ClassInfo lang = byQualified.get("java.lang." + name);
    if (lang != null) return lang;
    ClassInfo best = null;
    for (ClassInfo c : candidates) if (!c.isNested() && (best == null || rank(c) < rank(best))) best = c;
    return best != null ? best : candidates.get(0);
  }

  private static int rank(ClassInfo c) {
    if (c.library) return 5;
    String p = c.packageName;
    if (p.startsWith("android.widget") || p.startsWith("android.view") || p.startsWith("android.app")
        || p.startsWith("android.content") || p.startsWith("android.os")) return 0;
    if (p.startsWith("java.util") || p.startsWith("java.io")) return 1;
    if (p.startsWith("android.")) return 2;
    if (p.startsWith("java.")) return 3;
    return 4;
  }

  /** Member types of a class (e.g. View → OnClickListener, LayoutParams…). */
  public static List<ClassInfo> nestedClasses(ClassInfo outer) {
    ensureApi();
    if (outer == null) return Collections.emptyList();
    return merge(byContainer.get(outer.qualifiedName), libraries.byContainer.get(outer.qualifiedName));
  }

  /** Classes directly in a package, and the sub-package names below it (for import completion). */
  public static List<ClassInfo> classesInPackage(String packageName) {
    ensureApi();
    return merge(byContainer.get(packageName), libraries.byContainer.get(packageName));
  }

  public static java.util.Set<String> subPackages(String parent) {
    ensureApi();
    java.util.TreeSet<String> out = new java.util.TreeSet<>();
    String base = parent == null || parent.isEmpty() ? "" : parent + ".";
    java.util.HashSet<String> containers = new java.util.HashSet<>(byContainer.keySet());
    containers.addAll(libraries.byContainer.keySet());
    for (String container : containers) {
      if (!container.startsWith(base) || container.length() <= base.length()) continue;
      String rest = container.substring(base.length());
      int dot = rest.indexOf('.');
      String segment = dot < 0 ? rest : rest.substring(0, dot);
      if (!segment.isEmpty() && Character.isLowerCase(segment.charAt(0))) out.add(segment);
    }
    return out;
  }

  /** Top-level and nested classes whose simple name starts with {@code prefix} (case-insensitive). */
  public static List<ClassInfo> classesWithPrefix(String prefix, int limit) {
    ensureApi();
    ArrayList<ClassInfo> out = new ArrayList<>();
    String p = prefix == null ? "" : prefix;
    ClassInfo[] platform = sortedBySimple;
    ClassInfo[] library = libraries.sortedBySimple;
    int a = lowerBound(platform, p), b = lowerBound(library, p);
    // Merge both sorted runs so the result keeps the simple-name order across sources.
    while (out.size() < limit) {
      ClassInfo x = a < platform.length && platform[a].simpleName.regionMatches(true, 0, p, 0, p.length()) ? platform[a] : null;
      ClassInfo y = b < library.length && library[b].simpleName.regionMatches(true, 0, p, 0, p.length()) ? library[b] : null;
      if (x == null && y == null) break;
      ClassInfo next;
      if (y == null || x != null && x.simpleName.compareToIgnoreCase(y.simpleName) <= 0) {
        next = x;
        a++;
      } else {
        next = y;
        b++;
      }
      if (next.removed == 0) out.add(next);
    }
    return out;
  }

  private static int lowerBound(ClassInfo[] sorted, String p) {
    int low = 0, high = sorted.length;
    while (low < high) {
      int mid = (low + high) >>> 1;
      if (sorted[mid].simpleName.compareToIgnoreCase(p) < 0) low = mid + 1;
      else high = mid;
    }
    return low;
  }

  // ───────────────────────────── members ─────────────────────────────

  /** Declared fields and methods of the class (not inherited), decoded on first use. */
  public static List<Member> declaredMembers(ClassInfo info) {
    if (info == null) return Collections.emptyList();
    decode(info);
    return info.members;
  }

  public static List<Member> constructors(ClassInfo info) {
    if (info == null) return Collections.emptyList();
    decode(info);
    return info.constructors;
  }

  private static void decode(ClassInfo info) {
    if (info.members != null) return;
    synchronized (info) {
      if (info.members != null) return;
      ArrayList<Member> members = new ArrayList<>();
      ArrayList<Member> ctors = new ArrayList<>();
      byte[] data = info.data != null ? info.data : apiData;
      if (info.memberEnd > info.memberStart && info.memberEnd <= data.length) {
        String block = new String(data, info.memberStart, info.memberEnd - info.memberStart,
            StandardCharsets.UTF_8);
        for (String line : block.split("\n")) {
          if (line.isEmpty()) continue;
          String[] f = line.split("\t", -1);
          switch (f[0]) {
            case "F":
              members.add(new Member(Member.FIELD, f[1], f[2], f[3], "", at(f, 4), info));
              break;
            case "M":
              members.add(new Member(Member.METHOD, f[1], f[2], f[3], f[4], at(f, 5), info));
              break;
            case "K":
              ctors.add(new Member(Member.CONSTRUCTOR, info.simpleName, "-", info.simpleName, f[1],
                  at(f, 2), info));
              break;
            default:
              break;
          }
        }
      }
      info.constructors = Collections.unmodifiableList(ctors);
      info.members = Collections.unmodifiableList(members);
    }
  }

  private static String at(String[] f, int index) {
    return index < f.length ? f[index] : "";
  }

  /**
   * Visits the class and then its supertypes (superclass chain first, then interfaces, and
   * finally java.lang.Object for interfaces), each exactly once.
   */
  public static List<ClassInfo> hierarchy(ClassInfo start) {
    ArrayList<ClassInfo> order = new ArrayList<>();
    if (start == null) return order;
    java.util.ArrayDeque<ClassInfo> queue = new java.util.ArrayDeque<>();
    java.util.HashSet<String> seen = new java.util.HashSet<>();
    queue.add(start);
    while (!queue.isEmpty()) {
      ClassInfo current = queue.poll();
      if (!seen.add(current.qualifiedName)) continue;
      order.add(current);
      ClassInfo sup = classByQualifiedName(current.superName);
      if (sup != null) queue.addFirst(sup);
      for (String i : current.interfaces) {
        ClassInfo iface = classByQualifiedName(i);
        if (iface != null) queue.addLast(iface);
      }
    }
    ClassInfo object = classByQualifiedName("java.lang.Object");
    if (object != null && seen.add(object.qualifiedName)) order.add(object);
    return order;
  }

  // ───────────────────────────── XML ─────────────────────────────

  public static AttrInfo attr(String name) {
    ensureXml();
    return name == null ? null : attrs.get(name.startsWith("android:") ? name.substring(8) : name);
  }

  public static List<AttrInfo> allAttrs() {
    ensureXml();
    return new ArrayList<>(attrs.values());
  }

  public static List<String> styleable(String name) {
    ensureXml();
    List<String> found = styleables.get(name);
    return found == null ? Collections.emptyList() : found;
  }

  /**
   * Every public top-level class extending android.view.View (abstract ones included, like the
   * reference's element list), sorted by simple name. Computed once from the class hierarchy.
   */
  public static List<ClassInfo> viewClasses() {
    List<ClassInfo> platform = viewClasses;
    if (platform == null) {
      ensureApi();
      ArrayList<ClassInfo> out = new ArrayList<>();
      HashMap<String, Boolean> memo = new HashMap<>();
      for (ClassInfo c : sortedBySimple)
        if (!c.isNested() && !c.isInterface() && c.removed == 0 && isView(c, memo)) out.add(c);
      viewClasses = platform = Collections.unmodifiableList(out);
    }
    Layer layer = libraries;
    if (layer.size() == 0) return platform;
    List<ClassInfo> merged = layer.views;
    if (merged == null) {
      ArrayList<ClassInfo> out = new ArrayList<>(platform);
      HashMap<String, Boolean> memo = new HashMap<>();
      for (ClassInfo c : layer.sortedBySimple)
        if (!c.isNested() && !c.isInterface() && isView(c, memo)) out.add(c);
      out.sort((x, y) -> {
        int c = x.simpleName.compareToIgnoreCase(y.simpleName);
        return c != 0 ? c : x.qualifiedName.compareTo(y.qualifiedName);
      });
      layer.views = merged = Collections.unmodifiableList(out);
    }
    return merged;
  }

  private static boolean isView(ClassInfo c, Map<String, Boolean> memo) {
    if (c == null) return false;
    if (c.qualifiedName.equals("android.view.View")) return true;
    Boolean known = memo.get(c.qualifiedName);
    if (known != null) return known;
    memo.put(c.qualifiedName, false);
    boolean result = !c.superName.isEmpty() && isView(classByQualifiedName(c.superName), memo);
    memo.put(c.qualifiedName, result);
    return result;
  }

  /** The tag a layout uses for a view: LayoutInflater adds android.widget/webkit/app/view itself. */
  public static String tagName(ClassInfo view) {
    String pkg = view.packageName;
    return pkg.equals("android.widget") || pkg.equals("android.webkit") || pkg.equals("android.view")
            || pkg.equals("android.app")
        ? view.simpleName : view.qualifiedName;
  }

  /** Resolves a layout tag (simple or qualified) to its platform view class, or null. */
  public static ClassInfo viewClassForTag(String tag) {
    if (tag == null || tag.isEmpty()) return null;
    ensureApi();
    if (tag.indexOf('.') > 0) return visibleClass(tag);
    for (String pkg : new String[] {"android.widget.", "android.webkit.", "android.view.", "android.app."}) {
      ClassInfo c = byQualified.get(pkg + tag);
      if (c != null) return c;
    }
    return null;
  }

  // ───────────────────────────── API level text ─────────────────────────────

  /** "Added in API level 8", "Added in API level 3, Deprecated in API level 29", or "". */
  public static String apiLevelText(int since, int deprecated, int removed, boolean showAdded) {
    StringBuilder b = new StringBuilder();
    if (showAdded && since > 1) b.append("Added in API level ").append(since);
    if (deprecated > 0) {
      if (b.length() > 0) b.append(", ");
      b.append("Deprecated in API level ").append(deprecated);
    } else if (deprecated < 0) {
      if (b.length() > 0) b.append(", ");
      b.append("Deprecated"); // library member: deprecated, no API level
    }
    if (removed > 0) {
      if (b.length() > 0) b.append(", ");
      b.append("Removed in API level ").append(removed);
    }
    return b.toString();
  }

  // ───────────────────────────── helpers ─────────────────────────────

  private static final Pattern QUALIFIER = Pattern.compile("\\b(?:[a-z_][a-z0-9_]*\\.)+([A-Z])");

  /** {@code java.util.List<java.lang.String>} → {@code List<String>}. */
  public static String simpleTypeText(String type) {
    if (type == null || type.indexOf('.') < 0) return type == null ? "" : type;
    return QUALIFIER.matcher(type).replaceAll("$1");
  }

  public static String stripGenerics(String type) {
    int lt = type.indexOf('<');
    if (lt < 0) return type;
    int gt = type.lastIndexOf('>');
    return type.substring(0, lt) + (gt > lt ? type.substring(gt + 1) : "");
  }

  /** Index where the package ends: the dot before the first capitalised segment. */
  static int packageEnd(String qualified) {
    int start = 0;
    int lastDot = -1;
    while (start < qualified.length()) {
      int dot = qualified.indexOf('.', start);
      String segment = qualified.substring(start, dot < 0 ? qualified.length() : dot);
      if (!segment.isEmpty() && Character.isUpperCase(segment.charAt(0))) return lastDot;
      if (dot < 0) return lastDot;
      lastDot = dot;
      start = dot + 1;
    }
    return lastDot;
  }

  private static int parse(String value, int fallback) {
    try {
      return value == null || value.isEmpty() ? fallback : Integer.parseInt(value.trim());
    } catch (NumberFormatException error) {
      return fallback;
    }
  }

  /** For tests and diagnostics: number of loaded classes. */
  public static int classCount() {
    ensureApi();
    return byQualified.size();
  }

  static String lower(String value) {
    return value.toLowerCase(Locale.US);
  }
}
