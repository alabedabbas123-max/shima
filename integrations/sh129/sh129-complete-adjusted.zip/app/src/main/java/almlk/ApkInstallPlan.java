package almlk;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/**
 * قرارُ التثبيتِ — الطبقةُ الصافيةُ من الجولةِ 22/5د (‏`W22/reports/تقرير_دراسة_التثبيتُ_من_اللوحةِ_W22_5د.md`).
 *
 * <p>المرجعُ يَمشي في سبيلَينِ لا واحدٍ: شجرةُ ‏`abcd.lk` ‏(المَدخلُ ‏`MainActivity.j6(String,String)`)
 * إذا وجَدَ الجذرَ سَلَكَ ‏`su` في خيطٍ، وإلا بَنَى نِيةَ ‏`VIEW` على ‏`content://` أو ‏`file://` حسبَ
 * إصدارِ النظامِ، وأقرَأَ قراءةً واحدةً، وثبَّتَ مُثبِّتَ النظامِ إن كانَ في قائمةِ المُحَلِّلاتِ، ثمَّ
 * ‏`startActivity` — كلُّ ذلكَ داخلَ ‏`try/catch (Throwable)`. والمكتبةُ المحمولةُ في ‏`classes3.dex`
 * (‏`com.blankj.utilcode.util.IntentUtils`) تَقولُ المَعنى نفسَهُ بحرسِ ملفٍّ صريحٍ: ‏`null` إذا غابَ
 * الملفُّ، و‏`FileProvider` من الإصدارِ الرابعِ والعِشرِينَ، وسلسلةُ أبثوريو مَبنيّةٌ من اسمِ الحزمةِ.
 *
 * <p>عندَنا تُجْلَمُ القرارُ كلُّهُ هنا، بلا ‏`android.` وبلا نِداءِ أداةٍ وبلا كتابةٍ: لا ‏`aapt`،
 * ولا ‏`apksigner`، ولا ‏`PackageInstaller` (خِطّةُ الجولةِ تُصرِّحُ)، ولا ‏`su`. والغلافُ الأندرويديُّ
 * يَبقَى عندَهُ ما لا يُعرَفُ إلا منهُ: ‏`getUriForFile` و‏`startActivity` وسؤالُ
 * ‏`canRequestPackageInstalls()`. الحَقنُ بمِثالِ ‏`MavenResolver.Fetcher` و‏`ApkArtifacts.SignerReader`:
 * الطبقةُ الصافيةُ لا تَعرِفُ السياقَ، فلا تَدَّعي ما لا تَعلَمُ.
 *
 * <p>العجزُ حالةٌ مُسَمّاةٌ لا استثناءٌ ولا ‏`isError()`: ‏`missing_file` و‏`empty_file` و‏`not_apk` و
 * ‏`no_package` و‏`bad_authority` و‏`blocked_installs`. ولا ‏`ProgressDialog` ولا شريطَ تَقدُّمٍ:
 * التثبيتُ شأنُهُ إلى مُثبِّتِ النظامِ بعدَ النِّيةِ.
 */
public final class ApkInstallPlan {

  /** النِّيةُ كما في ‏`53509e` وفي ‏`25f300`: عرضٌ لا إرسالٌ، والنظامُ يَختارُ المُثبِّتَ. */
  public static final String ACTION_VIEW = "android.intent.action.VIEW";

  /** شاشةُ تفاصيلِ التطبيقِ — مَوضِعُ الإذنِ عندَ المرجعِ (‏`25f420`)، لا ‏`MANAGE_UNKNOWN_APP_SOURCES`. */
  public static final String ACTION_APP_DETAILS = "android.settings.APPLICATION_DETAILS_SETTINGS";

  /** الصيغةُ الواحدةُ في المرجعِ كلِّهِ: ‏`53510a` و‏`25f30a`. */
  public static final String MIME = "application/vnd.android.package-archive";

  /** أبثوريو الموفِّرِ: اسمُ الحزمةِ زائدَ هذهِ السلسلةِ (‏`47abca`: «‏`.fileprovider`‏»). */
  public static final String AUTHORITY_SUFFIX = ".fileprovider";

  /** المُثبِّتُ النظاميُّ الذي يُفرَضُ إن كانَ حاضرًا (‏`53517f`). */
  public static final String SYSTEM_INSTALLER = "com.android.packageinstaller";

  public static final int FLAG_ACTIVITY_NEW_TASK = 0x10000000;
  public static final int FLAG_GRANT_READ_URI_PERMISSION = 0x00000001;

  /** منهُ لا يَمشي ‏`file://`: مَفصِلُ ‏`5350c0` و‏`25f358`. */
  public static final int API_CONTENT_URI = 24;

  /** منهُ يُسأَلُ ‏`canRequestPackageInstalls()`؛ قبلَهُ لا سائلَ ولا مانعَ. */
  public static final int API_INSTALL_PERMISSIONS = 26;

  /** أسقافٌ: أربعُ علاماتَ، واسمٌ بطولٍ مَعقولٍ، وستةَ عشرَ مُحلِّلًا، ووادِعانِ بحجمٍ مُعلَنٍ. */
  public static final int MAX_PROBLEMS = 4;

  public static final int MAX_NAME = 240;
  public static final int MAX_RESOLVERS = 16;
  public static final int MAX_TEXT = 64 * 1024;

  private ApkInstallPlan() {}

  /** قرارٌ واحدٌ: هل تُرسَلُ النِّيةُ؟ وما نِيّتُها؟ ولماذا لا، إن لم تُرسَلْ. */
  public static final class Plan {
    public final String action;
    public final String mime;
    /** مسارُ الموفِّرِ، أو ‏`null` عندَ ‏`file://` تحتَ الإصدارِ الرابعِ والعِشرِينَ. */
    public final String authority;
    public final int flags;
    public final boolean ready;
    public final String state;
    public final String fileName;
    public final long bytes;
    public final int sdkInt;
    public final boolean installsPermitted;
    /** كلُّ عَيْبٍ يُعَدُّ ولا يُكتَمُ؛ والعرضُ عندَ السقفِ. */
    public final int counted;
    public final boolean overflow;
    private final List<String> problems;

    Plan(String action, String mime, String authority, int flags, boolean ready, String state,
        String fileName, long bytes, int sdkInt, boolean installsPermitted, List<String> problems,
        int counted) {
      this.action = action == null ? "" : action;
      this.mime = mime == null ? "" : mime;
      this.authority = authority;
      this.flags = flags;
      this.ready = ready;
      this.state = state == null ? "ready" : state;
      this.fileName = fileName == null ? "" : fileName;
      this.bytes = bytes;
      this.sdkInt = sdkInt;
      this.installsPermitted = installsPermitted;
      this.problems = problems == null ? new ArrayList<String>() : problems;
      this.counted = counted;
      this.overflow = counted > this.problems.size();
    }

    /** لا قائمَةً تُعدَّلُ من خارِجِ القرارِ: القراءةُ فقطْ. */
    public List<String> problems() {
      return Collections.unmodifiableList(problems);
    }

    /** أوّلُ ما يُقالُ للمستخدمِ عندَ النقرِ؛ فارغٌ إذا كانَ القرارُ جاهزًا. */
    public String reason() {
      return problems.isEmpty() ? "" : problems.get(0);
    }

    /** سطرٌ واحدٌ للوحةِ ولسجلِّ القراءةِ: حالَةٌ، واسمٌ، ومرجعٌ — بلا مسارٍ مُطلَقٍ. */
    public String describe() {
      StringBuilder out = new StringBuilder();
      out.append("install ").append(fileName.length() == 0 ? "«no file»" : fileName);
      out.append(" [").append(bytes).append(" B, sdk ").append(sdkInt);
      out.append(", ").append(state);
      if (authority == null) {
        out.append(", file://");
      } else {
        out.append(", content://").append(authority);
      }
      out.append(", flags 0x").append(Integer.toHexString(flags)).append("]");
      return out.toString();
    }
  }

  /**
   * القرارُ من ملفٍّ. {@code installsPermitted} يُحسَبُ في الغلافِ: ‏`true` تحتَ الإصدارِ السادسِ
   * والعِشرِينَ (لا سائلَ ولا مانعَ)، وفوقَهُ جوابُ ‏`canRequestPackageInstalls()`.
   */
  public static Plan of(File apk, int sdkInt, boolean installsPermitted, String packageName) {
    List<String> problems = new ArrayList<String>();
    int counted = 0;
    String name = apk == null || apk.getName() == null ? "" : apk.getName();
    if (name.length() > MAX_NAME) name = name.substring(0, MAX_NAME);
    long length = 0L;
    boolean isFile = false;
    if (apk != null) {
      try {
        isFile = apk.isFile();
        length = isFile ? apk.length() : 0L;
      } catch (SecurityException forbidden) {
        isFile = false;
        length = 0L;
      }
    }
    String authority = authorityFor(packageName);
    boolean needsProvider = needsContentUri(sdkInt);
    String state = "ready";
    if (apk == null || !isFile) {
      state = "missing_file";
      counted++;
      add(problems, "no such file to install: " + (name.length() == 0 ? "«no name»" : name));
    } else if (length == 0L) {
      state = "empty_file";
      counted++;
      add(problems, name + " is empty (0 B) — it was never packaged, or was truncated");
    } else if (!name.toLowerCase(Locale.US).endsWith(".apk")) {
      state = "not_apk";
      counted++;
      add(problems, name + " is not an application archive (.apk)");
    }
    if (needsProvider && authority == null) {
      state = "bad_authority";
      counted++;
      add(problems, "no package name to build a provider authority from");
    }
    if (sdkInt >= API_INSTALL_PERMISSIONS && !installsPermitted) {
      if ("ready".equals(state)) state = "blocked_installs";
      counted++;
      add(problems, "installing from this app is not allowed yet — " + ACTION_APP_DETAILS + " for "
          + settingsUri(packageName));
    }
    // تحتَ المَفصِلِ لا موفِّرَ البتّةَ (‏5350f8‏: ‏Uri.fromFile‏): فالحقلُ ‏null‏ لا «يُتجاهَلُ».
    String provider = needsProvider ? authority : null;
    int flags = FLAG_ACTIVITY_NEW_TASK
        | (provider != null ? FLAG_GRANT_READ_URI_PERMISSION : 0);
    boolean ready = "ready".equals(state);
    return new Plan(ready ? ACTION_VIEW : "", ready ? MIME : "", ready ? provider : null, flags,
        ready, state, name, length, sdkInt, installsPermitted, problems, counted);
  }

  /** كما {@link #of(File, int, boolean, String)}، على وَفقِ البابِ الثالثِ في المرجعِ (‏`25f3bc`). */
  public static Plan of(String apkPath, int sdkInt, boolean installsPermitted, String packageName) {
    return of(apkPath == null || apkPath.trim().isEmpty() ? null : new File(apkPath), sdkInt,
        installsPermitted, packageName);
  }

  /** هل يَلزَمُ موفِّرٌ؟ (‏`5350c0`: ‏`>= 24` ⇒ موفِّرٌ، وإلا ملفٌّ مباشرةً). */
  public static boolean needsContentUri(int sdkInt) {
    return sdkInt >= API_CONTENT_URI;
  }

  /** أبثوريو الموفِّرِ من اسمِ الحزمةِ (‏`47ab84`)؛ وسلسلةٌ فارغةٌ أو ‏`null` بلا أبثوريو. */
  public static String authorityFor(String packageName) {
    if (packageName == null) return null;
    String trimmed = packageName.trim();
    if (trimmed.isEmpty()) return null;
    return trimmed + AUTHORITY_SUFFIX;
  }

  /** «‏`package:`‏ + اسمُ الحزمةِ» — كما في ‏`25f448`: بلا هذهِ البادئةِ لا تَفتَحُ الشاشةُ شيءً. */
  public static String settingsUri(String packageName) {
    if (packageName == null || packageName.trim().isEmpty()) return "package:";
    return "package:" + packageName.trim();
  }

  /**
   * تَثبيتُ المُثبِّتِ النظاميِّ من قائمةِ المُحَلِّلاتِ (‏`53513e`‑‏`535190`): يُفرَضُ فقطْ إذا كانَ
   * حاضرًا؛ لا قوائمَ مُختلَقةً ولا ترتيبًا مُرتَجَلًا — وإلا تركنا النظامَ يَختارُ.
   */
  public static String installerChoice(List<String> resolverPackages) {
    if (resolverPackages == null || resolverPackages.isEmpty()) return null;
    int seen = 0;
    for (String pkg : resolverPackages) {
      if (seen >= MAX_RESOLVERS) break;
      seen++;
      if (SYSTEM_INSTALLER.equals(pkg)) return SYSTEM_INSTALLER;
    }
    return null;
  }

  /**
   * حارسُ المظهَرِ والوثيقةِ: يُعرَفُ وقتَ البناءِ لا وقتَ التشغيلِ — لا يَستطيعُ التطبيقُ أن
   * يَقرَأَ مظهرَهُ، فالحُكمُ على النصِّ لمَن يَملِكُهُ (البوابةُ والفصلُ [30]). ‏`null` يعنيَ لا
   * عَيْبًا؛ وإلا سطرٌ لكلِّ نقصٍ حتى السقفِ.
   */
  public static String manifestGuard(String manifestText, String pathsXmlText) {
    List<String> problems = new ArrayList<String>();
    String manifest = manifestText == null ? "" : manifestText;
    String paths = pathsXmlText == null ? "" : pathsXmlText;
    if (manifest.length() > MAX_TEXT) {
      add(problems, "manifest text is over " + (MAX_TEXT / 1024) + " KiB — checked up to the cap");
      manifest = manifest.substring(0, MAX_TEXT);
    }
    if (paths.length() > MAX_TEXT) {
      add(problems, "provider paths text is over " + (MAX_TEXT / 1024) + " KiB — checked up to the cap");
      paths = paths.substring(0, MAX_TEXT);
    }
    require(manifest, "<provider", problems, "no <provider element in the manifest");
    require(manifest, "androidx.core.content.FileProvider", problems,
        "the provider is not androidx FileProvider");
    require(manifest, "android:authorities=\"${applicationId}" + AUTHORITY_SUFFIX + "\"", problems,
        "provider authority is not ${applicationId}" + AUTHORITY_SUFFIX);
    require(manifest, "android:exported=\"false\"", problems, "provider is exported");
    require(manifest, "android:grantUriPermissions=\"true\"", problems,
        "provider does not grant uri permissions");
    require(manifest, "@xml/file_paths", problems, "provider paths resource is missing");
    require(manifest, "android.permission.REQUEST_INSTALL_PACKAGES", problems,
        "REQUEST_INSTALL_PACKAGES is not declared");
    require(paths, "<external-path", problems, "paths document has no external-path");
    require(paths, "<files-path", problems, "paths document has no files-path");
    if (problems.isEmpty()) return null;
    StringBuilder out = new StringBuilder("install guard:");
    for (String problem : problems) out.append(' ').append(problem).append(';');
    return out.toString().trim();
  }

  private static void require(String text, String needle, List<String> problems, String message) {
    if (text.indexOf(needle) >= 0) return;
    add(problems, message);
  }

  private static void add(List<String> problems, String message) {
    if (problems.size() < MAX_PROBLEMS) problems.add(message);
  }
}
