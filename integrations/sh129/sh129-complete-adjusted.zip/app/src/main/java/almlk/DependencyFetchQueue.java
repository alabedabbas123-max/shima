package almlk;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;

/**
 * منسِّقُ الجَلبِ الصامتِ: طابورٌ واحدٌ لكلِّ مشروعٍ، إلغاءُ تكرارٍ على <em>مجموعةِ الإحداثيّاتِ</em>، خيطُ
 * عملٍ واحدٌ، و<b>سطرُ حالةٍ واحدٌ</b> بدلَ نوافذِ الانتظارِ — وهو نفسُ ترتيبِ المرجعِ (‏{@code Ej.run()}: اجمعْ
 * من {@code HashSet<Be$g>} ← أدرِجِ المهمّةَ ← اضبطِ النصَّ ← {@code ExecutorService.execute} ← رسالةُ ختامٍ
 * عبرَ {@code com.aide.common.ma}).
 *
 * <p>فارقٌ مُقصَدٌ مذكورٌ في تقريرِ الدراسةِ: المرجعُ يَكتُبُ السطرَ ثمَّ يَدَعُ مُنفِّذَ ‏{@code Gradle} يهضمُ
 * الإحداثيّةَ؛ أمّا عندَنا فالتنزيلُ يسبقُ الكتابةَ، لأنَّ سطرَ {@code implementation} لحزمةٍ غيرِ موجودةٍ في
 * المخزنِ المحليِّ يُعطِّلُ البناءَ على الجهازِ ولا يُصلَحُ بشيءٍ. تبقى النتيجةُ واحدةً من الخارجِ: سطرٌ مضافٌ،
 * بلا حوارٍ، بلا بناءٍ لأجلِ المستخدمِ.
 *
 * <p>الحملُ الثقيلُ كلُّهُ مُعادُ استعمالٍ: {@link GradleDependencyEditor} للكتابةِ في ‏{@code dependencies
 * {}}، {@link AarExploder}/{@link LocalLibraries} لتفكيكِ ‏{@code aar} في مجلّدِ البناءِ (<b>لا</b> في ‏{@code
 * assets/})، {@link LibraryInstallState} لحُكمِ الحالةِ، والشبكةُ عندَ {@link MavenResolver} خلفَ {@link
 * Transport} — فلا منطقَ تكرارٍ هنا، ولا {@code android.*} أيضًا.
 */
public final class DependencyFetchQueue {

  /** كمَّ مهمّةٍ تنتظرُ قبلَ الرفضِ الهادئِ المُعَدِّ. */
  public static final int MAX_PENDING = 32;
  /** كمَّ سطرِ حالةٍ يُحفَظُ للعرضِ في آخرِ الجولةِ. */
  public static final int MAX_LOG = 8;

  public static final int STATE_IDLE = 0;
  public static final int STATE_RUNNING = 1;

  public enum Outcome {
    DONE,
    PARTIAL,
    FAILED,
    REJECTED
  }

  /** ما يَفعَلُهُ المضيفُ ليُثبِّتَ الإحداثيّةَ في المخزنِ: تنزيلٌ + تفكيكٌ + تحديثُ فهرسٍ. */
  public interface Transport {
    /** {@code true} إذا صارَتِ الحزمةُ مُتاحةً (أُنجِبَت أو كانتْ مُثبَّتةً). */
    boolean install(DependencyFetchPlan plan) throws IOException;
  }

  /** سطرُ الحالةِ ونتيجةُ الجولةِ — لا نوافذَ ولا أشرطةَ تقدُّمٍ. */
  public interface Listener {
    void onFetchStatus(String statusKey, String coordinate);

    void onFetchFinished(Outcome outcome, int written, int fetched, int failed);
  }

  /** وصولُ المهمّةِ إلى الطابورِ: كم قُبلَ، كم تكرارٌ حُذِفَ، وكم تجاوزَ السقفَ. */
  public static final class Receipt {
    public final Outcome outcome;
    public final int accepted;
    public final int duplicates;
    public final int overflow;
    public final String statusKey;

    Receipt(Outcome outcome, int accepted, int duplicates, int overflow, String statusKey) {
      this.outcome = outcome;
      this.accepted = accepted;
      this.duplicates = duplicates;
      this.overflow = overflow;
      this.statusKey = statusKey == null ? "" : statusKey;
    }
  }

  private static final class Task {
    final File buildFile;
    final List<DependencyFetchPlan> plans;
    final boolean kts;

    Task(File buildFile, List<DependencyFetchPlan> plans, boolean kts) {
      this.buildFile = buildFile;
      this.plans = plans;
      this.kts = kts;
    }
  }

  private static final Map<String, DependencyFetchQueue> INSTANCES =
      new HashMap<String, DependencyFetchQueue>();

  /** مفتاحُ التسجيلِ: المسارُ المُحلَّلُ، فلا يتعدَّدُ المنسِّقُ بتعدُّدِ الصِّيغِ. */
  static String keyOf(File projectDir) {
    if (projectDir == null) return "";
    try {
      return projectDir.getCanonicalPath();
    } catch (IOException fallback) {
      return projectDir.getAbsolutePath();
    }
  }

  public static DependencyFetchQueue forProject(File projectDir) {
    String key = keyOf(projectDir);
    synchronized (INSTANCES) {
      DependencyFetchQueue queue = INSTANCES.get(key);
      if (queue == null) {
        queue = new DependencyFetchQueue(projectDir);
        INSTANCES.put(key, queue);
      }
      return queue;
    }
  }

  public static int instanceCount() {
    synchronized (INSTANCES) {
      return INSTANCES.size();
    }
  }

  public static void forget(File projectDir) {
    synchronized (INSTANCES) {
      DependencyFetchQueue queue = INSTANCES.remove(keyOf(projectDir));
      if (queue != null) queue.shutdown();
    }
  }

  public static void forgetAll() {
    List<DependencyFetchQueue> copy;
    synchronized (INSTANCES) {
      copy = new ArrayList<DependencyFetchQueue>(INSTANCES.values());
      INSTANCES.clear();
    }
    for (DependencyFetchQueue queue : copy) queue.shutdown();
  }

  private final File projectDir;
  private final Set<String> seen = new LinkedHashSet<String>();
  private final List<Task> pending = new ArrayList<Task>();
  private final ArrayList<String> log = new ArrayList<String>();
  private ExecutorService worker;
  private volatile Transport transport;
  private volatile Listener listener;
  private volatile boolean runInline;
  private volatile int state = STATE_IDLE;
  private volatile String statusKey = "";
  private int requested;
  private int duplicates;
  private int overflow;
  private int written;
  private int fetched;
  private int failed;

  private DependencyFetchQueue(File projectDir) {
    this.projectDir = projectDir;
  }

  public File projectDir() {
    return projectDir;
  }

  public void setTransport(Transport transport) {
    this.transport = transport;
  }

  /** المُوصِّلُ الحاليُّ؛ {@code null} قبلَ أن يُثبِّتَهُ المضيفُ (يَستعمِلُهُ المضيفُ مرةً واحدةً). */
  public Transport transport() {
    return transport;
  }

  /** المُستقبِلُ الحاليُّ لسطرِ الحالةِ ونتيجةِ الجولةِ. */
  public Listener listener() {
    return listener;
  }

  public void setListener(Listener listener) {
    this.listener = listener;
  }

  /** التنفيذُ في خيطِ المُستدعي (للبوّابةِ، وللمضيفِ الذي لا يَملِكُ خيطًا). */
  public void setRunInline(boolean runInline) {
    this.runInline = runInline;
  }

  public int state() {
    return state;
  }

  public boolean isIdle() {
    return state == STATE_IDLE && pending.isEmpty();
  }

  public String statusKey() {
    return statusKey;
  }

  public List<String> log() {
    synchronized (log) {
      return Collections.unmodifiableList(new ArrayList<String>(log));
    }
  }

  public int requested() {
    return requested;
  }

  public int duplicates() {
    return duplicates;
  }

  public int overflow() {
    return overflow;
  }

  public int written() {
    return written;
  }

  public int fetched() {
    return fetched;
  }

  public int failed() {
    return failed;
  }

  public int pendingCount() {
    synchronized (pending) {
      return pending.size();
    }
  }

  /** الإحداثيّاتُ التي مرَّتْ بالطابورِ (للعرضِ وللبوّابةِ): بضمِّ ما قُبلَ وما رُفِضَ بالتكرارِ. */
  public Set<String> coordinates() {
    synchronized (seen) {
      return Collections.unmodifiableSet(new LinkedHashSet<String>(seen));
    }
  }

  /**
   * إدراجُ قرارٍ (أو مجموعةِ قراراتٍ) في الطابورِ. الرفضُ الهادئُ لا يُبطِلُ عملًا جارٍ: الزائدُ عن السقفِ
   * يُعَدُّ في {@link #overflow()} ويُسقَطُ، والمُكرَّرُ يُعَدُّ في {@link #duplicates()}.
   */
  public Receipt enqueue(File moduleBuildFile, List<DependencyFetchPlan> plans) {
    boolean kts = moduleBuildFile != null && moduleBuildFile.getName().endsWith(".kts");
    return enqueue(moduleBuildFile, kts, plans);
  }

  public Receipt enqueue(File moduleBuildFile, boolean kts, List<DependencyFetchPlan> plans) {
    ArrayList<DependencyFetchPlan> accepted = new ArrayList<DependencyFetchPlan>();
    int duplicatesNow = 0;
    int overflowNow = 0;
    if (plans != null) {
      synchronized (seen) {
        for (DependencyFetchPlan plan : plans) {
          if (plan == null || !UnresolvedSymbolRule.shouldQueue(plan)) continue;
          if (accepted.size() >= DependencyFetchPlan.MAX_COORDINATES) {
            overflowNow++;
            continue;
          }
          String key = plan.key();
          if (key.isEmpty() || !seen.add(key)) {
            duplicatesNow++;
            continue;
          }
          accepted.add(plan);
        }
      }
    }
    requested += accepted.size();
    duplicates += duplicatesNow;
    overflow += overflowNow;
    if (accepted.isEmpty()) {
      String key = duplicatesNow > 0 ? "ui_fetch_status_duplicate" : "ui_fetch_status_idle";
      status(key, "");
      return new Receipt(duplicatesNow > 0 ? Outcome.REJECTED : Outcome.DONE, 0, duplicatesNow, overflowNow, key);
    }
    boolean acceptedForWrite = false;
    for (DependencyFetchPlan plan : accepted) {
      if (plan.isActionable()) acceptedForWrite = true;
    }
    if (moduleBuildFile == null && acceptedForWrite) {
      overflow += accepted.size();
      requested -= accepted.size();
      String key = "ui_fetch_status_no_build_file";
      status(key, "");
      return new Receipt(Outcome.REJECTED, 0, duplicatesNow, accepted.size(), key);
    }
    synchronized (pending) {
      if (pending.size() >= MAX_PENDING) {
        overflow += accepted.size();
        requested -= accepted.size();
        String key = "ui_fetch_status_overloaded";
        status(key, "");
        return new Receipt(Outcome.REJECTED, 0, duplicatesNow, accepted.size(), key);
      }
      pending.add(new Task(moduleBuildFile, Collections.unmodifiableList(accepted), kts));
    }
    String queued = "ui_fetch_status_queued";
    status(queued, accepted.get(0).coordinate);
    Receipt receipt = new Receipt(Outcome.PARTIAL, accepted.size(), duplicatesNow, overflowNow, queued);
    schedule();
    return receipt;
  }

  /** جدولةُ التفريغِ: خيطٌ واحدٌ، أو تنفِيذٌ مُباشِرٌ عندَ الطلبِ. */
  private void schedule() {
    if (runInline) {
      drain();
      return;
    }
    ExecutorService current = worker;
    if (current == null) {
      synchronized (this) {
        current = worker;
        if (current == null) {
          current =
              Executors.newSingleThreadExecutor(
                  new ThreadFactory() {
                    @Override
                    public Thread newThread(Runnable runnable) {
                      Thread thread = new Thread(runnable, "shima-fetch");
                      thread.setDaemon(true);
                      thread.setPriority(Thread.MIN_PRIORITY);
                      return thread;
                    }
                  });
          worker = current;
        }
      }
    }
    final ExecutorService service = current;
    try {
      service.execute(
          new Runnable() {
            @Override
            public void run() {
              drain();
            }
          });
    } catch (RuntimeException rejected) {
      // الخيطُ أُغلِقِ بينَ الفحصِ والاستعمالِ: التفريغُ مُباشِرٌ ولا تُفقَدُ مهمّةٌ.
      drain();
    }
  }

  /** يَجرِي في الخيطِ الواحدِ، مهمةً مهمةً، بلا تداخلٍ: القفلُ على {@code this} يمنعُ جولتينِ متوازيتينِ. */
  void drain() {
    synchronized (this) {
      if (state != STATE_IDLE) return;
      state = STATE_RUNNING;
    }
    int writtenNow = 0;
    int fetchedNow = 0;
    int failedNow = 0;
    try {
      Task task;
      while ((task = take()) != null) {
        String buildText = "";
        try {
          if (task.buildFile != null && task.buildFile.isFile()) buildText = read(task.buildFile);
        } catch (IOException unreadable) {
          buildText = "";
        }
        ArrayList<String> lines = new ArrayList<String>();
        for (DependencyFetchPlan plan : task.plans) {
          status("ui_fetch_status_running", plan.coordinate);
          boolean ok = true;
          Transport current = transport;
          if (current != null) {
            try {
              ok = current.install(plan);
            } catch (IOException failure) {
              ok = false;
            } catch (RuntimeException failure) {
              ok = false;
            }
          }
          if (!ok) {
            failedNow++;
            failed++;
            note("ui_fetch_status_failed", plan.coordinate);
            continue;
          }
          fetchedNow++;
          fetched++;
          String line = plan.line(task.kts);
          if (plan.action == DependencyFetchPlan.Action.ALREADY_LISTED
              || line == null
              || GradleDependencyEditor.containsDependency(buildText, line)) {
            note("ui_fetch_status_listed", plan.coordinate);
            continue;
          }
          buildText = GradleDependencyEditor.addDependency(buildText, line);
          lines.add(line);
          writtenNow++;
          written++;
          note("ui_fetch_status_written", plan.coordinate);
        }
        if (!lines.isEmpty() && task.buildFile != null) {
          try {
            write(task.buildFile, buildText);
          } catch (IOException unwritable) {
            failedNow += lines.size();
            failed += lines.size();
            written -= lines.size();
            writtenNow -= lines.size();
            note("ui_fetch_status_write_failed", task.buildFile.getName());
          }
        }
      }
    } finally {
      state = STATE_IDLE;
    }
    Outcome outcome =
        failedNow == 0
            ? (writtenNow + fetchedNow == 0 ? Outcome.DONE : Outcome.DONE)
            : (writtenNow + fetchedNow == 0 ? Outcome.FAILED : Outcome.PARTIAL);
    String key =
        outcome == Outcome.FAILED
            ? "ui_fetch_status_failed_all"
            : (outcome == Outcome.PARTIAL ? "ui_fetch_status_partial" : "ui_fetch_status_done");
    status(key, "");
    Listener sink = listener;
    if (sink != null) {
      try {
        sink.onFetchFinished(outcome, Math.max(0, writtenNow), fetchedNow, failedNow);
      } catch (RuntimeException ignored) {
        // المضيفُ لا يُسقِطُ الطابورَ.
      }
    }
  }

  private Task take() {
    synchronized (pending) {
      return pending.isEmpty() ? null : pending.remove(0);
    }
  }

  private void status(String key, String coordinate) {
    statusKey = key == null ? "" : key;
    note(statusKey, coordinate);
    Listener sink = listener;
    if (sink != null) {
      try {
        sink.onFetchStatus(statusKey, coordinate == null ? "" : coordinate);
      } catch (RuntimeException ignored) {
        // المُستقبِلُ مُختارٌ من المضيفِ: لا يَنبَغي أن يُعطِّلَ الجَلبَ.
      }
    }
  }

  private void note(String key, String coordinate) {
    synchronized (log) {
      log.add(coordinate == null || coordinate.isEmpty() ? key : key + " " + coordinate);
      while (log.size() > MAX_LOG) log.remove(0);
    }
  }

  /** يُلغي ما لم يبدأْ ويُبقِي ما بدأَ: المرجعُ لا يَقطَعُ تنزيلًا نصفَ مُكتملٍ عندَ إغلاقِ المشروعِ. */
  public int clearPending() {
    int cleared;
    synchronized (pending) {
      cleared = pending.size();
      pending.clear();
    }
    if (cleared > 0) note("ui_fetch_status_cleared", cleared + " tasks");
    return cleared;
  }

  public void shutdown() {
    clearPending();
    ExecutorService current;
    synchronized (this) {
      current = worker;
      worker = null;
    }
    if (current != null) current.shutdownNow();
  }

  public static String read(File file) throws IOException {
    InputStream in = new FileInputStream(file);
    try {
      ByteArrayOutputStream out = new ByteArrayOutputStream((int) Math.min(file.length(), 1 << 20));
      byte[] chunk = new byte[8192];
      int count;
      while ((count = in.read(chunk)) > 0) out.write(chunk, 0, count);
      return new String(out.toByteArray(), "UTF-8");
    } finally {
      in.close();
    }
  }

  /** كتابةٌ ذرّيّةٌ بجوارِ الملفِّ ثمَّ تبديلٌ، فلا يبقى ملفُّ بناءٍ مقطوعَ الأسطرِ عندَ الانقطاعِ. */
  public static void write(File file, String text) throws IOException {
    File parent = file.getParentFile();
    if (parent != null && !parent.isDirectory()) parent.mkdirs();
    File temp = new File(parent, file.getName() + ".shima-tmp");
    OutputStream out = new FileOutputStream(temp);
    try {
      out.write(text.getBytes("UTF-8"));
    } finally {
      out.close();
    }
    if (file.exists() && !file.delete()) throw new IOException("cannot replace " + file.getName());
    if (!temp.renameTo(file)) throw new IOException("cannot move " + temp.getName());
  }
}
