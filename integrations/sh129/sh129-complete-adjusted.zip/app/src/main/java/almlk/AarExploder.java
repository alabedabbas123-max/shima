package almlk;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipInputStream;

/**
 * عقدُ AAR: {@code ‹اسمُ الأداةِ›.exploded.aar/} بالمكوِّناتِ الخمسةِ مصرَّحةً في علامةٍ تحملُ
 * بصمةَ المصدرِ.
 *
 * <p>كانَ المسارُ القديمُ يفكُّ إلى مجلدٍ باسمِ الأداةِ بلا لاحقةٍ ويكتفي بعلامةِ `.extracted`
 * حُكمُها «زمنُ العلامةِ ≥ زمنُ الأداةِ»: فإبدالُ المستودعِ أداةً بأخرى لا يُبطِلُ إعادةَ
 * الاستخدامِ إن لم يتقدَّمْ زمنُ الملفِّ، ومحوُ `classes.jar` من العقدِ لا يُنتِجُ شيئًا لأنَّ
 * لا أحَدَ يسألُ عنهِ عندَ الاستعادةِ، ولا سبيلَ لمعرفةِ أيُّ المكوِّناتِ خرجتْ فعلًا إلا بإعادةِ
 * المشيِ على القرصِ كلَّ مرةٍ (`LibraryClassIndex.readAar`).
 *
 * <p>الآليَةُ منقولةٌ عن نظامِ المكتباتِ الحديثِ — لا شفرتُهُ: العقدُ بلاحقةٍ صريحةٍ، وعلامةٌ
 * تعلنُ مكوِّناتِها واحدةً واحدةً، وبصمةُ المصدرِ = الحجمُ + عدلةُ التعديلِ + بصمةُ
 * `AndroidManifest.xml` (فلا تتشابه أداتانِ استُبدِلَتا في نفسِ الثانيةِ)، والفكُّ لا يترُكُ
 * نصفَ عقدةٍ (إلغاءٌ، أو أرشيفٌ لا يُقرأُ جدولُ وسطِهِ، أو مدخلٌ موعودٌ لم يخرجْ ⇒ محوُ ما
 * كُتِبَ والاستثناءُ للمنادِي)، والفهارسُ تقرأُ قائمةَ المكوِّناتِ من العلامةِ بدلَ تخمينِها.
 * أمَّا «هل هذا مكتبةُ أندرويدَ؟» فليسَ سؤالَ الآلةِ: مكتبةُ مواردَ بلا `classes.jar` حقٌّ،
 * والحُكمُ لـ`LibraryInstallState` عندَ المنادِي — فلا تُرفَضُ لأجلِ manifestٍ غائبٍ، ولا
 * تُقبَلُ نصفُ مكتبةٍ لمجرَّدِ أنَّ ما نُصِفَ موجودٌ.
 *
 * <p>جافا خالصةٌ: لا `android.*`، ولا خيطَ واجهةٍ يمسُّها — مُنظِّفُ التنزيلِ و`installAsync` هما
 * المنادِيانِ، والبوّاباتُ تُقيسُها على قرصٍ مؤقَّتٍ بأرشيفاتٍ حقيقيةٍ.
 */
public final class AarExploder {

  /** لاحقةُ العقدِ: تُميِّزُ المُخرَجاتِ عن الأداةِ ولا تلتصقُ باسمِ مجلدِ القالبِ. */
  public static final String NODE_SUFFIX = ".exploded.aar";
  /** علامةُ العقدِ: البصمةُ + العددُ + المكوِّناتُ التي وُجِّدَتْ فعلًا. */
  public static final String STAMP_NAME = ".shima-exploded";
  static final String STAMP_HEADER = "#shima-aar-exploded 1";

  public static final String CLASSES_JAR = "classes.jar";
  public static final String LIBS_DIR = "libs";
  public static final String RES_DIR = "res";
  public static final String ASSETS_DIR = "assets";
  public static final String MANIFEST = "AndroidManifest.xml";
  public static final String R_TXT = "R.txt";

  /** مُشرِّطُ الفكِّ: يُلغى حيثَ ألغى المنادِي، ويُبَلَّغُ بالتقدُّمِ. */
  public interface Progress {
    void extracted(int entries, long bytes);

    boolean cancelled();
  }

  static final Progress SILENT = new Progress() {
    @Override
    public void extracted(int entries, long bytes) {}

    @Override
    public boolean cancelled() {
      return false;
    }
  };

  /** نتيجةُ عقدٍ واحدٍ: أيُّ المكوِّناتِ على القرصِ حقًّا، وما الذي وعدَ بهِ الأرشيفُ. */
  public static final class Report {
    public final File node;
    /** صفرٌ عندَ إعادةِ الاستخدامِ: لا قراءةَ للأرشيفِ ولا كتابةَ. */
    public final long bytesWritten;
    public final int entriesWritten;
    public final boolean reused;
    public final boolean manifest, classesJar, libs, res, assets, rTxt;
    public final boolean archiveHasClasses, archiveHasRes, archiveHasAssets, archiveHasR;
    public final String signature, reason;

    Report(File node, long bytesWritten, int entriesWritten, boolean reused, boolean manifest,
        boolean classesJar, boolean libs, boolean res, boolean assets, boolean rTxt,
        boolean archiveHasClasses, boolean archiveHasRes, boolean archiveHasAssets, boolean archiveHasR,
        String signature, String reason) {
      this.node = node;
      this.bytesWritten = bytesWritten;
      this.entriesWritten = entriesWritten;
      this.reused = reused;
      this.manifest = manifest;
      this.classesJar = classesJar;
      this.libs = libs;
      this.res = res;
      this.assets = assets;
      this.rTxt = rTxt;
      this.archiveHasClasses = archiveHasClasses;
      this.archiveHasRes = archiveHasRes;
      this.archiveHasAssets = archiveHasAssets;
      this.archiveHasR = archiveHasR;
      this.signature = signature == null ? "" : signature;
      this.reason = reason == null ? "" : reason;
    }

    /** العقدُ صالحٌ للفهرسةِ: manifestٌ على القرصِ وعلامةٌ ببصمةِ المصدرِ نفسِها. */
    public boolean usable() {
      return manifest && !signature.isEmpty();
    }

    /** الأرشيفُ وعدَ بأصنافٍ والعقدُ لا يحملُها: نصفُ عملٍ، لا «مكتبةُ مواردَ». */
    public boolean missingPromisedClasses() {
      return archiveHasClasses && !classesJar;
    }

    /** المكوِّناتُ الخمسةُ الموجودةُ فعلًا، بترتيبِ التصريحِ. */
    public List<String> components() {
      List<String> out = new ArrayList<>();
      if (classesJar) out.add(CLASSES_JAR);
      if (libs) out.add(LIBS_DIR);
      if (res) out.add(RES_DIR);
      if (assets) out.add(ASSETS_DIR);
      if (manifest) out.add(MANIFEST);
      if (rTxt) out.add(R_TXT);
      return Collections.unmodifiableList(out);
    }

    @Override
    public String toString() {
      return (reused ? "reused " : "exploded ") + entriesWritten + "e/" + bytesWritten + "B "
          + components() + (reason.isEmpty() ? "" : " " + reason);
    }
  }

  private AarExploder() {}

  /** {@code ‹الاسمُ بلا امتدادٍ›.exploded.aar} تحتَ دليلِ الكتابةِ نفسِهِ. */
  public static File nodeFor(File aar, File writableDir) {
    return new File(writableDir, baseName(aar) + NODE_SUFFIX);
  }

  /** اسمُ المُخرَجاتِ القديمِ (بلا لاحقةٍ) — يُمحى عندَ أولِ عقدٍ جديدٍ للأداةِ نفسِها. */
  public static File legacyNodeFor(File aar, File writableDir) {
    return new File(writableDir, baseName(aar));
  }

  private static String baseName(File aar) {
    String name = aar == null ? "unknown" : aar.getName();
    int dot = name.lastIndexOf('.');
    return dot > 0 ? name.substring(0, dot) : name;
  }

  /** هل العقدُ صالحٌ للأداةِ الآنَ؟ (بصمتُها + مكوِّناتُها المعلَنةُ حيّةٌ على القرصِ) */
  public static boolean reusable(File aar, File node) {
    return readStamp(node, signatureOf(aar)) != null;
  }

  /**
   * بصمةُ المصدرِ: الحجمُ + عدلةُ التعديلِ + عشرةُ سداسيٍّ من sha1 لمدخلِ `AndroidManifest.xml`.
   * لا قراءةَ للأرشيفِ كلِّهِ — manifestٌ صغيرٌ يميِّزُ أداةً مُبدَّلةً وإن اتفقتِ الأزمنةُ.
   * الأرشيفُ الذي لا يُفتَحُ يعطي بصمةً بغيرِ manifest، والفكُّ يقولُ سببَهُ بنفسِهِ.
   */
  public static String signatureOf(File aar) {
    if (aar == null || !aar.isFile()) return "";
    String digest = "";
    ZipFile zip = null;
    try {
      zip = new ZipFile(aar);
      ZipEntry entry = zip.getEntry(MANIFEST);
      if (entry != null) {
        MessageDigest sha = MessageDigest.getInstance("SHA-1");
        byte[] buffer = new byte[16384];
        InputStream in = zip.getInputStream(entry);
        try {
          int n;
          while ((n = in.read(buffer)) > 0) sha.update(buffer, 0, n);
        } finally {
          in.close();
        }
        byte[] raw = sha.digest();
        StringBuilder b = new StringBuilder(20);
        for (int i = 0; i < 10; i++) b.append(String.format(Locale.US, "%02x", raw[i]));
        digest = b.toString();
      }
    } catch (Exception ignored) {
      // لا شيءَ: البصمةُ تبقى «بلا manifest»، ولا تُعَدُّ علامةً على صحةٍ ولا على خطإٍ.
    } finally {
      if (zip != null) {
        try {
          zip.close();
        } catch (IOException ignored) {
          // إغلاقُ قراءةٍ تمَّتْ: لا يعني شيئًا.
        }
      }
    }
    return aar.length() + ":" + aar.lastModified() + ":" + (digest.isEmpty() ? "-" : digest);
  }

  /** فحصٌ بلا فكٍّ: العقدٌ الصالحُ يُعيدهُ Report `reused`، وغيرُهُ بلا سببٍ مُختلَقٍ. */
  public static Report read(File aar, File node) {
    Stamp stamp = readStamp(node, signatureOf(aar));
    if (stamp != null) return stamp.report(node, true, 0L, 0);
    String why = stampProblem(node, signatureOf(aar));
    return absent(node, why == null ? "no usable node" : why);
  }

  /**
   * علَّةُ العقدِ منطوقةٌ، أو `null` إذا كانَ صالحًا للفهرسةِ. ليست قراءةً ثانيةً: الحُكمُ والسببُ
   * يَخرُجانِ من parseStamp نفسِها — فلو انفصلتا لقالَ سببٌ شيئًا وحَكَمَ غيرَهُ عندَ أوَّلِ علَّةٍ
   * جديدةٍ (وهو ما كانَ: «‏no usable node» يَجمَعُ أربعَ علَلٍ على السواءِ).
   */
  public static String stampProblem(File node, String signature) {
    try {
      parseStamp(node, signature);
      return null;
    } catch (StampProblem refused) {
      return refused.getMessage();
    }
  }

  /**
   * ما يُبطِلُ **الفهرسةَ** لا إعادةَ الاستعمالِ: مُكوِّنٌ أُعلِنَ ثمَّ بُتِرَ، أو بصمةُ الأرشيفِ
   * تبدَّلَت. وأمَّا عقدٌ بلا علامةٍ — مَجلوبٌ من أداةٍ قديمةٍ أو من عدّةِ اختبارٍ — فمَحمولٌ:
   * العلامةُ عَهدَةٌ بينَ الفكِّ والاستعمالِ، لا شرطٌ في صحةِ ما على القرصِ، وإلّا لصارَ كلُّ
   * ما فُكَّ قبلَ هذهِ الجولةِ مكتبةً ميِّتةً بلا سببٍ يَستحقُّه المستخدمُ.
   */
  public static String nodeDamage(File node) {
    String why = stampProblem(node, "");
    if (why == null) return null;
    return why.startsWith("no exploded node on disk") || why.contains("carries no stamp")
        || why.contains("does not start with " + STAMP_HEADER) ? null : why;
  }

  /** رَفضُ العلامةِ بسببٍ واحدٍ يُقرَأُ للمستخدمِ كما يُستعمَلُ للحُكمِ. */
  static final class StampProblem extends Exception {
    private static final long serialVersionUID = 1L;

    StampProblem(String why) {
      super(why);
    }
  }

  /**
   * العقدُ جاهزٌ أو يُفكُّ الآنَ: إعادةُ استخدامٍ إن طابقتِ البصمةُ، وإلا محوُ القديمِ (ومجلدُ
   * المسارِ السابِقِ) ثمَّ فكٌّ كاملٌ. الاستثناءُ يعني أنَّ لا عقدةً صالحةً على القرصِ بعدَ النداءِ.
   */
  public static Report ensure(File aar, File writableDir, Progress progress) throws IOException {
    return ensure(aar, writableDir, progress, false);
  }

  public static Report ensure(File aar, File writableDir, Progress progress, boolean force)
      throws IOException {
    if (aar == null || !aar.isFile()) throw new IOException("no aar file");
    Progress sink = progress == null ? SILENT : progress;
    String signature = signatureOf(aar);
    File node = nodeFor(aar, writableDir);
    if (!force && readStamp(node, signature) != null) {
      return read(aar, node);
    }
    File legacy = legacyNodeFor(aar, writableDir);
    if (legacy.isDirectory() && !legacy.getAbsolutePath().equals(node.getAbsolutePath())) {
      deleteTree(legacy);
    }
    deleteTree(node);
    if (!node.mkdirs() && !node.isDirectory()) throw new IOException("cannot create " + node);
    Stamp stamp;
    try {
      stamp = explode(aar, node, signature, sink);
    } catch (IOException | RuntimeException broken) {
      deleteTree(node);
      if (broken instanceof IOException) throw (IOException) broken;
      throw (RuntimeException) broken;
    }
    return stamp.report(node, false, stamp.bytes, stamp.entries);
  }

  /** فكٌّ كاملٌ ثمَّ كتابةُ العلامةِ؛ الإلغاءُ والتلفُ يرميانِ الاستثناءَ ولا يترُكانِ بقايا. */
  private static Stamp explode(File aar, File node, String signature, Progress progress)
      throws IOException {
    String rootPath = node.getCanonicalPath() + File.separator;
    Stamp stamp = new Stamp(signature);
    byte[] buffer = new byte[32768];
    try (ZipInputStream zip = new ZipInputStream(new FileInputStream(aar))) {
      ZipEntry entry;
      while ((entry = zip.getNextEntry()) != null) {
        if (progress.cancelled() || Thread.currentThread().isInterrupted()) {
          throw new IOException("cancelled");
        }
        String name = entry.getName();
        if (name.isEmpty() || name.startsWith("__MACOSX") || name.endsWith("/.DS_Store")) continue;
        File out = new File(node, name);
        if (!out.getCanonicalPath().startsWith(rootPath)) {
          throw new IOException("unsafe entry " + name);
        }
        if (entry.isDirectory()) {
          out.mkdirs();
          stamp.countDir();
          continue;
        }
        File parent = out.getParentFile();
        if (parent != null) parent.mkdirs();
        long written = 0;
        try (OutputStream stream = new FileOutputStream(out)) {
          int n;
          while ((n = zip.read(buffer)) > 0) {
            stream.write(buffer, 0, n);
            written += n;
          }
        }
        stamp.countFile(name, written);
        progress.extracted(stamp.entries, stamp.bytes);
      }
    }
    // جدولُ الوسطِ يقولُ كم كانَ يفترضُ أن يخرجَ: تنزيلٌ انقطعَ في آخرِهِ كانَ يمرُّ في المسارِ
    // القديمِ لأنَّ الدورةَ تنتهي بسلامٍ عندَ آخرِ بايتٍ مقروءٍ — هنا يُرفَضُ ويُمحى النصفُ. ولا
    // حكمَ هنا على غيابِ `AndroidManifest.xml`: مكتبةُ مواردَ بلا أصنافَ حقٌّ، ومَن يقرِّرُ ذلكَ
    // هو `LibraryInstallState` عندَ المنادِي، لا آلةُ الفكِّ التي تَعِدُ بما خرجَ فقطْ.
    int expected = expectedEntries(aar);
    if (expected < 0) {
      throw new IOException("unreadable aar archive (no central directory)");
    }
    if (stamp.entries != expected) {
      throw new IOException("truncated aar: " + stamp.entries + " of " + expected + " entries");
    }
    stamp.writeTo(node);
    return stamp;
  }

  /** عددُ المداخلِ التي كانَ يجبُ أن تُخرَجَ (بنفسِ قاعدةِ التخطيِ)؛ -1 إن لم يُفتَحِ الأرشيفُ. */
  static int expectedEntries(File aar) {
    ZipFile zip = null;
    try {
      zip = new ZipFile(aar);
      int n = 0;
      java.util.Enumeration<? extends ZipEntry> entries = zip.entries();
      while (entries.hasMoreElements()) {
        String name = entries.nextElement().getName();
        if (name.isEmpty() || name.startsWith("__MACOSX") || name.endsWith("/.DS_Store")) continue;
        n++;
      }
      return n;
    } catch (IOException unreadable) {
      return -1;
    } finally {
      if (zip != null) {
        try {
          zip.close();
        } catch (IOException ignored) {
          // لا شيءَ.
        }
      }
    }
  }

  /** ما على القرصِ حينَ لا علامةَ صالحةً — للرسالةِ لا للحُكمِ. */
  private static Report absent(File node, String why) {
    return new Report(node, 0L, 0, false,
        new File(node, MANIFEST).isFile(), new File(node, CLASSES_JAR).isFile(),
        new File(node, LIBS_DIR).isDirectory(), new File(node, RES_DIR).isDirectory(),
        new File(node, ASSETS_DIR).isDirectory(), new File(node, R_TXT).isFile(),
        false, false, false, false, "", why);
  }

  /** قراءةُ العلامةِ والتحقّقُ من البصمةِ والمكوِّناتِ؛ `null` إن لم يكنْ عقدٌ يُعتمَدُ عليهِ. */
  static Stamp readStamp(File node, String signature) {
    try {
      return parseStamp(node, signature);
    } catch (StampProblem refused) {
      return null;
    }
  }

  /**
   * العلامةُ كلُّها مَحمودَةٌ أو لا علامةَ: بصمةُ المصدرِ، ورأسُ السجلِّ، وكلُّ مُكوِّنٍ أعلنَهُ
   * الفكُّ موجودٌ على القرصِ. الأدْنى يَرمِي بالسببِ، فلا يَقبَعُ مُستعمِلٌ على «نِصفِ مكتبةٍ»، ولا
   * يُعرَّى صنفٌ من أعضائِهِ لأنَّ أحَدًا مَحَا ‏`classes.jar` بعدَ الفكِّ ثمَّ اعتُدَّ بالعقدِ.
   */
  private static Stamp parseStamp(File node, String signature) throws StampProblem {
    if (node == null || !node.isDirectory()) throw new StampProblem("no exploded node on disk");
    String text = readText(new File(node, STAMP_NAME));
    if (text == null) {
      throw new StampProblem("the node carries no stamp — extraction never finished or was removed");
    }
    return Stamp.parseChecked(text, signature, node);
  }

  /** العلامةُ نفسُها: البصمةُ + العددُ + المكوِّناتُ التي وُجِّدَتْ وقتَ الفكِّ. */
  static final class Stamp {
    String signature;
    int entries;
    long bytes;
    final Set<String> components = new LinkedHashSet<>();
    boolean archiveHasClasses, archiveHasRes, archiveHasAssets, archiveHasR;

    Stamp(String signature) {
      this.signature = signature == null ? "" : signature;
    }

    void countDir() {
      entries++;
    }

    void countFile(String name, long written) {
      entries++;
      bytes += written;
      if (name.equals(MANIFEST)) {
        components.add(MANIFEST);
      } else if (name.equals(CLASSES_JAR)) {
        components.add(CLASSES_JAR);
        archiveHasClasses = true;
      } else if (name.equals(R_TXT)) {
        components.add(R_TXT);
        archiveHasR = true;
      } else if (name.startsWith(ASSETS_DIR + "/")) {
        components.add(ASSETS_DIR);
        archiveHasAssets = true;
      } else if (name.startsWith(RES_DIR + "/")) {
        components.add(RES_DIR);
        archiveHasRes = true;
      } else if (name.startsWith(LIBS_DIR + "/") && name.endsWith(".jar")) {
        components.add(LIBS_DIR);
      }
    }

    boolean present(String component) {
      return components.contains(component);
    }

    void writeTo(File node) throws IOException {
      StringBuilder b = new StringBuilder(STAMP_HEADER).append('\n');
      b.append("sig=").append(signature).append('\n');
      b.append("entries=").append(entries).append('\n');
      b.append("bytes=").append(bytes).append('\n');
      b.append("components=").append(String.join(",", new ArrayList<>(components))).append('\n');
      try (OutputStream out = new FileOutputStream(new File(node, STAMP_NAME))) {
        out.write(b.toString().getBytes(StandardCharsets.UTF_8));
      }
    }

    /** `null` عندَ أدنى فارقٍ: بصمةٌ أخرى، أو مكوِّنٌ مُعلَنٌ لا يوجدُ على القرصِ. */
    static Stamp parse(String text, String signature, File node) {
      try {
        return parseChecked(text, signature, node);
      } catch (StampProblem refused) {
        return null;
      }
    }

    static Stamp parseChecked(String text, String signature, File node) throws StampProblem {
      if (!text.startsWith(STAMP_HEADER)) {
        throw new StampProblem("the stamp does not start with " + STAMP_HEADER);
      }
      Stamp stamp = new Stamp(signature);
      String declaredSig = "";
      List<String> declared = new ArrayList<>();
      for (String line : text.split("\n")) {
        int eq = line.indexOf('=');
        if (eq < 0) continue;
        String key = line.substring(0, eq);
        String value = line.substring(eq + 1);
        if (key.equals("sig")) declaredSig = value;
        else if (key.equals("entries")) stamp.entries = (int) toLong(value);
        else if (key.equals("bytes")) stamp.bytes = toLong(value);
        else if (key.equals("components")) {
          for (String part : value.split(",")) {
            if (!part.isEmpty()) declared.add(part);
          }
        }
      }
      if (signature == null || signature.isEmpty()) {
        // القارئُ الذي لا يريدُ مقارنةً (الفهرسُ مثلًا) يأخذُ البصمةَ المعلَنةَ كما هي، فيبني
        // بها stampَ ذاكرتِهِ — فلو ظلتْ فارغةً لأصبحَتِ الذاكرةُ لا تُبطَلُ أبدًا.
        stamp.signature = declaredSig;
      } else if (!signature.equals(declaredSig)) {
        throw new StampProblem("stale stamp: the archive changed (stamped "
            + (declaredSig.isEmpty() ? "nothing" : declaredSig) + ", now " + signature + ")");
      }
      for (String component : declared) {
        File probe = new File(node, component);
        boolean directory = component.equals(LIBS_DIR) || component.equals(RES_DIR)
            || component.equals(ASSETS_DIR);
        if (directory ? !probe.isDirectory() : !probe.isFile()) {
          throw new StampProblem("component declared by the stamp is gone from the node: " + component);
        }
        stamp.components.add(component);
      }
      stamp.archiveHasClasses = stamp.components.contains(CLASSES_JAR);
      stamp.archiveHasRes = stamp.components.contains(RES_DIR);
      stamp.archiveHasAssets = stamp.components.contains(ASSETS_DIR);
      stamp.archiveHasR = stamp.components.contains(R_TXT);
      return stamp;
    }

    Report report(File node, boolean reused, long bytesWritten, int entriesWritten) {
      return new Report(node, bytesWritten, entriesWritten, reused,
          present(MANIFEST), present(CLASSES_JAR),
          components.contains(LIBS_DIR), components.contains(RES_DIR),
          components.contains(ASSETS_DIR), components.contains(R_TXT),
          archiveHasClasses, archiveHasRes, archiveHasAssets, archiveHasR, signature, "");
    }

    private static long toLong(String text) {
      try {
        return Long.parseLong(text.trim());
      } catch (NumberFormatException wrong) {
        return 0L;
      }
    }
  }

  /** `classes.jar` العقدِ — للفهرسةِ بلا إعادةِ فتحِ الأرشيفِ. */
  public static File classesJarOf(File node) {
    return node == null ? null : new File(node, CLASSES_JAR);
  }

  /** ما في `libs/` من jar، مرتَّبًا — نفسُ ما كانَ المنادِي يعدُّهُ بيدِهِ. */
  public static List<File> bundledJars(File node) {
    ArrayList<File> out = new ArrayList<>();
    File[] children = node == null ? null : new File(node, LIBS_DIR).listFiles();
    if (children != null) {
      for (File child : children) {
        if (child.isFile() && child.getName().toLowerCase(Locale.US).endsWith(".jar")) out.add(child);
      }
      Collections.sort(out);
    }
    return out;
  }

  /** حُكمُ العلامةِ للمُنظِّفِ: أيُّ مكوِّنٍ يوجدُ، وهل البصمةُ هي بصمةُ الأداةِ الآنَ. */
  public static List<String> declaredComponents(File node) {
    Stamp stamp = readStamp(node, "");
    return stamp == null ? Collections.<String>emptyList() : new ArrayList<>(stamp.components);
  }

  static void deleteTree(File file) {
    if (file == null) return;
    File[] children = file.listFiles();
    if (children != null) {
      for (File child : children) deleteTree(child);
    }
    file.delete();
  }

  private static String readText(File file) {
    if (file == null || !file.isFile()) return null;
    try (InputStream in = new FileInputStream(file)) {
      ByteArrayOutputStream out = new ByteArrayOutputStream();
      byte[] buffer = new byte[8192];
      int n;
      while ((n = in.read(buffer)) > 0) out.write(buffer, 0, n);
      return new String(out.toByteArray(), StandardCharsets.UTF_8);
    } catch (IOException unreadable) {
      return null;
    }
  }
}
