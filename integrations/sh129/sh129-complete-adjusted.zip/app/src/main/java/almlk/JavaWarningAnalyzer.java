package almlk;

import static almlk.JavaSyntaxTree.*;

import com.almlkid.kay.ui.CodeLanguageTools.Diagnostic;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;

/**
 * R6 (the reference's local warning pass): code that compiles but is very likely not what was
 * meant — an empty statement, identical if/else parts, a local or parameter that is never
 * accessed, a private method nobody calls. Every finding is a WARNING and runs only on a clean
 * tree. A "use" is any mention of the name in its scope that is not a member selection, so an
 * ambiguous mention always counts as a use: the pass may miss a warning, it never invents one.
 * The type-dependent warnings (unneeded cast, assignment without effect) live in the attributor.
 */
final class JavaWarningAnalyzer {
  private static final int MAX_FINDINGS = 200;
  private static final HashSet<String> SERIALIZATION_HOOKS = new HashSet<>();

  static {
    Collections.addAll(SERIALIZATION_HOOKS,
        "writeObject", "readObject", "readObjectNoData", "writeReplace", "readResolve");
  }

  private final String src;
  private final Unit unit;
  private final List<Diagnostic> out = new ArrayList<>();
  private final HashSet<String> reported = new HashSet<>();
  private final int[] lineStarts;
  private JavaLexer tokens;

  JavaWarningAnalyzer(String src, Unit unit) {
    this.src = src == null ? "" : src;
    this.unit = unit;
    this.lineStarts = lineStarts(this.src);
  }

  List<Diagnostic> run() {
    if (unit == null) return out;
    tokens = JavaLexer.tokenize(src);
    for (TypeDecl t : unit.types) type(t);
    return out;
  }

  private static int[] lineStarts(String s) {
    int count = 1;
    for (int i = 0; i < s.length(); i++) if (s.charAt(i) == '\n') count++;
    int[] starts = new int[count];
    int k = 1;
    for (int i = 0; i < s.length(); i++) if (s.charAt(i) == '\n') starts[k++] = i + 1;
    return starts;
  }

  private void warn(int start, int end, QuickFix fix, String key, String fallback, Object... args) {
    if (out.size() >= MAX_FINDINGS || start < 0 || start >= src.length()) return;
    if (!reported.add(start + ":" + key)) return;
    int lo = 0, hi = lineStarts.length - 1;
    while (lo < hi) {
      int mid = (lo + hi + 1) >>> 1;
      if (lineStarts[mid] <= start) lo = mid;
      else hi = mid - 1;
    }
    // أسرةُ التلميحِ تُفرَزُ في طبقةِ التصنيفِ لا هنا: لا يَجلِسُ «لا وصولَ إلى…» في لوحِ الأخطاءِ.
    Diagnostic d = Diagnostic.localized(start, Math.max(start + 1, Math.min(end, src.length())), lo + 1,
        start - lineStarts[lo] + 1,
        JavaDiagnosticCodes.severityFor(key, Diagnostic.Severity.WARNING),
        JavaDiagnosticCodes.codeOf(key), key, fallback, args);
    if (fix != null) d = d.withQuickFixes(Collections.singletonList(fix));
    out.add(d);
  }

  // ───────────────────────────── token helpers ─────────────────────────────

  /** Index of the first token starting at or after {@code offset}. */
  private int tokenAt(int offset) {
    int lo = 0, hi = tokens.count;
    while (lo < hi) {
      int mid = (lo + hi) >>> 1;
      if (tokens.start[mid] < offset) lo = mid + 1;
      else hi = mid;
    }
    return lo;
  }

  /** True when {@code name} is mentioned in {@code [from, to)} other than as {@code x.name}. */
  private boolean mentioned(String name, int from, int to) {
    for (int i = tokenAt(from); i < tokens.count && tokens.start[i] < to; i++) {
      if (tokens.kind[i] != JavaLexer.IDENT || !name.equals(tokens.text[i])) continue;
      if (i > 0 && ".".equals(tokens.text[i - 1])) continue;
      return true;
    }
    return false;
  }

  /** Number of mentions of {@code name} anywhere in the file (selections included). */
  private int mentions(String name) {
    int n = 0;
    for (int i = 0; i < tokens.count; i++)
      if (tokens.kind[i] == JavaLexer.IDENT && name.equals(tokens.text[i])) n++;
    return n;
  }

  /** Same token sequence (comments and layout ignored). */
  private boolean sameTokens(Node a, Node b) {
    int i = tokenAt(a.start), j = tokenAt(b.start);
    int n = 0;
    while (i < tokens.count && tokens.start[i] < a.end) {
      if (j >= tokens.count || tokens.start[j] >= b.end) return false;
      if (tokens.kind[i] != tokens.kind[j] || !tokens.text(i).equals(tokens.text(j))) return false;
      i++;
      j++;
      n++;
    }
    return n > 0 && (j >= tokens.count || tokens.start[j] >= b.end);
  }

  // ───────────────────────────── declarations ─────────────────────────────

  private void type(TypeDecl t) {
    if (t == null) return;
    for (EnumConstant c : t.constants) {
      if (c.args != null) for (Expr a : c.args) expr(a);
      if (c.body != null) type(c.body);
    }
    for (Member m : t.members) {
      if (m instanceof TypeDecl) type((TypeDecl) m);
      else if (m instanceof FieldDecl) {
        for (VarDecl v : ((FieldDecl) m).vars) expr(v.init);
      } else if (m instanceof Initializer) {
        Block b = ((Initializer) m).body;
        if (b != null) statement(b, b.end, false);
      } else if (m instanceof MethodDecl) method(t, (MethodDecl) m);
    }
  }

  private void method(TypeDecl owner, MethodDecl md) {
    if (md.bodySkipped) return;
    if (md.body != null) statement(md.body, md.body.end, false);
    if (md.body == null || md.mods == null) return;
    boolean isPrivate = md.mods.has(PRIVATE);
    // Id: a private method nobody calls (reflection-reached hooks and annotated methods excepted)
    if (isPrivate && !md.constructor && md.mods.annotations.isEmpty()
        && !SERIALIZATION_HOOKS.contains(md.name) && md.nameStart >= 0
        && src.startsWith(md.name, md.nameStart) && mentions(md.name) <= 1)
      warn(md.nameStart, md.nameStart + md.name.length(), null, "ui_diagnostic_method_never_used",
          "Method '%1$s' is never used", md.name);
    // Id: a parameter the body never reads — only where the method cannot override another one
    if (md.body.stmts.isEmpty() || md.mods.has(NATIVE) || md.mods.has(ABSTRACT)) return;
    if (!(isPrivate || md.constructor || md.mods.has(STATIC))) return;
    if (isMain(md)) return;
    for (VarDecl p : md.params) {
      if (p.name == null || p.name.isEmpty() || "_".equals(p.name)) continue;
      if (!src.startsWith(p.name, p.nameStart)) continue;
      if (!mentioned(p.name, md.body.start, md.body.end))
        warn(p.nameStart, p.nameStart + p.name.length(), null, "ui_diagnostic_parameter_never_accessed",
            "There is no access to parameter '%1$s' in this method", p.name);
    }
  }

  private static boolean isMain(MethodDecl md) {
    if (!"main".equals(md.name) || md.params.size() != 1) return false;
    TypeRef t = md.params.get(0).type;
    return t != null && "String".equals(t.simpleName()) && (t.dims == 1 || t.varargs);
  }

  // ───────────────────────────── statements ─────────────────────────────

  /** A statement list (block, case body): {@code scopeEnd} closes the locals declared in it. */
  private void statements(List<Stmt> list, int scopeEnd) {
    for (Stmt st : list) statement(st, scopeEnd, true);
  }

  /**
   * One statement. {@code inList}: it sits directly in a block or case body (an empty statement
   * there is deleted) rather than being the body of if/while/for (where it becomes {@code {}}).
   */
  private void statement(Stmt st, int scopeEnd, boolean inList) {
    if (st == null) return;
    if (st instanceof Block) {
      Block b = (Block) st;
      statements(b.stmts, b.end);
    } else if (st instanceof Empty) {
      emptyStatement((Empty) st, inList);
    } else if (st instanceof LocalVars) {
      LocalVars lv = (LocalVars) st;
      for (VarDecl v : lv.vars) {
        expr(v.init);
        if (v.name == null || v.name.isEmpty() || "_".equals(v.name)) continue;
        if (v.nameStart < 0 || !src.startsWith(v.name, v.nameStart)) continue;
        if (!mentioned(v.name, v.nameStart + v.name.length(), scopeEnd))
          warn(v.nameStart, v.nameStart + v.name.length(), null, "ui_diagnostic_variable_never_accessed",
              "There is no access to variable '%1$s'", v.name);
      }
    } else if (st instanceof LocalClass) {
      type(((LocalClass) st).decl);
    } else if (st instanceof ExprStmt) {
      expr(((ExprStmt) st).expr);
    } else if (st instanceof If) {
      If i = (If) st;
      expr(i.cond);
      statement(i.then, scopeEnd, false);
      statement(i.otherwise, scopeEnd, false);
      if (i.then != null && i.otherwise != null && sameTokens(i.then, i.otherwise))
        warn(i.start, i.start + 2, null, "ui_diagnostic_if_else_identical",
            "The 'if' and 'else' parts of this statement are identical");
    } else if (st instanceof While) {
      expr(((While) st).cond);
      statement(((While) st).body, scopeEnd, false);
    } else if (st instanceof DoWhile) {
      statement(((DoWhile) st).body, scopeEnd, false);
      expr(((DoWhile) st).cond);
    } else if (st instanceof For) {
      For f = (For) st;
      // the header's locals live for the whole loop; an unused loop counter is not reported
      for (Stmt s : f.init) {
        if (s instanceof LocalVars) for (VarDecl v : ((LocalVars) s).vars) expr(v.init);
        else statement(s, f.end, true);
      }
      expr(f.cond);
      for (Expr u : f.update) expr(u);
      statement(f.body, f.end, false);
    } else if (st instanceof ForEach) {
      expr(((ForEach) st).iterable);
      statement(((ForEach) st).body, st.end, false);
    } else if (st instanceof Return) {
      expr(((Return) st).value);
    } else if (st instanceof Throw) {
      expr(((Throw) st).value);
    } else if (st instanceof Yield) {
      expr(((Yield) st).value);
    } else if (st instanceof Try) {
      Try t = (Try) st;
      for (Node r : t.resources) {
        if (r instanceof VarDecl) expr(((VarDecl) r).init);
        else if (r instanceof Expr) expr((Expr) r);
      }
      statement(t.body, scopeEnd, false);
      for (Catch c : t.catches) statement(c.body, scopeEnd, false);
      statement(t.fin, scopeEnd, false);
    } else if (st instanceof Switch) {
      Switch sw = (Switch) st;
      expr(sw.selector);
      cases(sw.cases, sw.end);
    } else if (st instanceof Synchronized) {
      expr(((Synchronized) st).lock);
      statement(((Synchronized) st).body, scopeEnd, false);
    } else if (st instanceof Labeled) {
      statement(((Labeled) st).body, scopeEnd, false);
    } else if (st instanceof Assert) {
      expr(((Assert) st).cond);
      expr(((Assert) st).message);
    }
  }

  private void cases(List<Case> cases, int switchEnd) {
    for (Case c : cases) {
      for (Expr l : c.labels) expr(l);
      expr(c.guard);
      statements(c.body, switchEnd);
    }
  }

  /** Id: "This empty statement may be not intended here" with "delete" / "Replace with {}". */
  private void emptyStatement(Empty e, boolean inList) {
    if (e.start < 0 || e.start >= src.length() || src.charAt(e.start) != ';') return;
    QuickFix fix;
    if (inList) {
      fix = QuickFix.deleteText(src, e.start, e.start + 1, "ui_quick_fix_delete");
    } else {
      int from = e.start;
      while (from > 0 && (src.charAt(from - 1) == ' ' || src.charAt(from - 1) == '\t')) from--;
      fix = QuickFix.replaceText(src, from, e.start + 1, " {}", "ui_quick_fix_replace_with_block", "");
    }
    warn(e.start, e.start + 1, fix, "ui_diagnostic_empty_statement",
        "This empty statement may be not intended here");
  }

  // ───────────────────────────── expressions ─────────────────────────────

  /** Walks into expressions only to reach nested bodies (lambdas, anonymous classes, switches). */
  private void expr(Expr e) {
    if (e == null) return;
    if (e instanceof Lambda) {
      Node body = ((Lambda) e).body;
      if (body instanceof Block) statement((Block) body, ((Block) body).end, false);
      else if (body instanceof Expr) expr((Expr) body);
    } else if (e instanceof NewObject) {
      NewObject n = (NewObject) e;
      expr(n.outer);
      for (Expr a : n.args) expr(a);
      if (n.body != null) type(n.body);
    } else if (e instanceof SwitchExpr) {
      SwitchExpr sw = (SwitchExpr) e;
      expr(sw.selector);
      cases(sw.cases, sw.end);
    } else if (e instanceof Call) {
      Call c = (Call) e;
      expr(c.target);
      for (Expr a : c.args) expr(a);
    } else if (e instanceof Select) {
      expr(((Select) e).target);
    } else if (e instanceof Binary) {
      expr(((Binary) e).left);
      expr(((Binary) e).right);
    } else if (e instanceof Assign) {
      expr(((Assign) e).target);
      expr(((Assign) e).value);
    } else if (e instanceof Unary) {
      expr(((Unary) e).operand);
    } else if (e instanceof Conditional) {
      expr(((Conditional) e).cond);
      expr(((Conditional) e).whenTrue);
      expr(((Conditional) e).whenFalse);
    } else if (e instanceof Cast) {
      expr(((Cast) e).operand);
    } else if (e instanceof InstanceOf) {
      expr(((InstanceOf) e).operand);
    } else if (e instanceof Paren) {
      expr(((Paren) e).inner);
    } else if (e instanceof Index) {
      expr(((Index) e).array);
      expr(((Index) e).index);
    } else if (e instanceof NewArray) {
      for (Expr d : ((NewArray) e).dimExprs) expr(d);
      expr(((NewArray) e).init);
    } else if (e instanceof ArrayInit) {
      for (Expr x : ((ArrayInit) e).elements) expr(x);
    } else if (e instanceof MethodRef) {
      expr(((MethodRef) e).target);
    }
  }
}
