package almlk;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.ConcurrentHashMap;

/**
 * مقارنة مراجع الملفات بصيغها المختلفة: المسار نفسه قد يصل بصيغة {@code /sdcard/…} أو
 * {@code /storage/emulated/0/…} أو {@code file://…} أو برابط رمزي، فتفشل المساواة النصية فلا يُرسم
 * تموّج الخطأ على ملفه المفتوح. المسار يُوحَّد إلى صيغته القانونية (مع ذاكرة صغيرة)، وروابط SAF
 * تُقارن كما هي.
 */
public final class FileReferences {
  private static final int CACHE_LIMIT = 4096;
  private static final ConcurrentHashMap<String, String> CANONICAL = new ConcurrentHashMap<>();

  private FileReferences() {}

  /** الصيغة القانونية لمسار ملف، أو المرجع كما هو لغير المسارات (content://). */
  public static String normalize(String reference) {
    if (reference == null || reference.isEmpty()) return "";
    String path = reference.startsWith("file://") ? reference.substring(7) : reference;
    if (!path.startsWith("/")) return path;
    String canonical = CANONICAL.get(path);
    if (canonical != null) return canonical;
    try {
      canonical = new File(path).getCanonicalPath();
    } catch (IOException | SecurityException unreadable) {
      canonical = new File(path).getAbsolutePath();
    }
    if (CANONICAL.size() >= CACHE_LIMIT) CANONICAL.clear();
    CANONICAL.put(path, canonical);
    return canonical;
  }

  /** هل يشير المرجعان إلى الملف نفسه؟ الفارغ لا يطابق شيئًا. */
  public static boolean same(String a, String b) {
    if (a == null || b == null || a.isEmpty() || b.isEmpty()) return false;
    return a.equals(b) || normalize(a).equals(normalize(b));
  }
}
