package almlk;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * One applicable correction attached to a diagnostic (Stage 3 of error checking).
 *
 * <p>The object is computed together with the diagnostic on the analysis worker, so the selection
 * toolbar can show the Fix icon immediately instead of probing the source on demand. Today the only
 * kinds are {@link Kind#CREATE_METHOD} (a call to a method the receiving project class does not
 * declare) and {@link Kind#CREATE_FIELD} (an unknown simple name inside a method body). The text edit itself is planned purely from the target source by {@link
 * #planInsertion(String)} — no Android types — so it is covered by the regression suite.
 *
 * <p>Placement rule: right after the first consecutive block of field declarations of the target
 * class (the usual "fields then methods" layout); a class without fields receives the method just
 * before its own closing brace; a new field joins the end of that field block (or opens the body).
 * The generated method body is empty ({@code return <default>;} for non-void
 * results), and the method name range is reported so the caller can select it after applying.
 */
public final class QuickFix {

  public enum Kind {
    CREATE_METHOD,
    CREATE_FIELD,
    /** The reference's "Insert 'x'" repair of a missing token, applied in the current file. */
    INSERT_TOKEN,
    /** R6: a local edit of the checked file — replace a verified range (remove cast, delete…). */
    EDIT_TEXT,
    /** W5: {@code Add 'import <fqn>'} — يُلصَق بتشخيص اسمٍ مرشّحه الوحيد صنفُ مشروع غير مستورد. */
    ADD_IMPORT,
    /** W5: «Fix imports» الجماعي — يفوّض إلى {@code organizeImports} القائم، لا نسخة ثانية منه. */
    FIX_IMPORTS,
    /**
     * 1.0.176: دفعةُ حذفِ الاستيراداتِ السقيمةِ — سِجلُّ عملياتٍ {@code REPLACE_TEXT_REGION} كما في سجلِّ
     * الإصلاحِ عندَ المرجعِ (‏{@code com.aide.engine.Modification}): كلُّ سطرٍ يُستبدَلُ ببديلٍ فارغٍ، والدفعةُ
     * كلُّها خطوةُ تراجعٍ واحدةٌ تُطبَّقُ من النصِّ الحيِّ؛ فإن تحرَّكَ سطرٌ واحدٌ رُفِضَت كلُّها.
     */
    REMOVE_IMPORTS,
    /**
     * ‏1.0.197: «‏{@code Create class 'X'}» — صَفٌّ <b>يَكتُبُ مِلَفًّا</b> فِي باقَةِ المِلَفِّ الحَامِلِ،
     * لا يَعدِلُ نَصًّا. لا سَطرَ {@code REPLACE_TEXT_REGION} فِيهِ وَلا يَمُرُّ عَلى مُحرِّكٍ بَعيدٍ:
     * الخُطَّةُ كُلُّها فِي {@link #createType}، وَالكَاتِبُ صاحِبُ المِلَفِّ {@link
     * almlk.QuickFixExecutor.Host#createType} — كَـ{@link Kind#FETCH_DEPENDENCY} قَبلَهُ: مَسؤولٌ عَن
     * أَثَرٍ لا عَن حَرَكَةِ نَصٍّ.
     */
    CREATE_TYPE,
    /**
     * 1.0.175: «Fetch library» — لا يُعدِّلُ النصَّ بنفسِهِ أبدًا؛ يَدفَعُ الإحداثيّةَ إلى {@link
     * DependencyFetchQueue} الذي يَكتُبُ سطرَ {@code dependencies {}} ويُنزِلُ الحزمةَ في خيطِهِ، ثمَّ
     * تُعادُ قراءةُ الحكمِ بإعادةِ الفحصِ. لا حوارَ ولا نافذةَ انتظارٍ، كما في المرجعِ.
     */
    FETCH_DEPENDENCY
  }

  /** A parameter of the method to create. */
  public static final class Param {
    public final String type;
    public final String name;

    public Param(String type, String name) {
      this.type = type == null || type.trim().isEmpty() ? "Object" : type.trim();
      this.name = name == null || name.trim().isEmpty() ? "arg" : name.trim();
    }
  }

  /** A planned insertion: {@code text} goes at {@code offset}; the name range is in the result. */
  public static final class Insertion {
    public final int offset;
    public final String text;
    public final int nameStart;
    public final int nameEnd;
    /** End of the replaced range; equal to {@link #offset} for a pure insertion. */
    public final int removeEnd;

    Insertion(int offset, String text, int nameStart, int nameEnd) {
      this(offset, offset, text, nameStart, nameEnd);
    }

    Insertion(int offset, int removeEnd, String text, int nameStart, int nameEnd) {
      this.offset = offset;
      this.removeEnd = Math.max(offset, removeEnd);
      this.text = text;
      this.nameStart = nameStart;
      this.nameEnd = nameEnd;
    }

    /** Returns {@code source} with the insertion applied. */
    public String applyTo(String source) {
      return source.substring(0, offset) + text + source.substring(removeEnd);
    }
  }

  public final Kind kind;
  public final String targetClass;
  public final String returnType;
  public final String methodName;
  public final List<Param> params;
  /** Member is generated {@code static} (called from a static context or through the class). */
  public final boolean isStatic;

  private QuickFix(
      Kind kind,
      String targetClass,
      String returnType,
      String methodName,
      List<Param> params,
      boolean isStatic) {
    this.kind = kind;
    this.targetClass = targetClass;
    this.returnType = returnType;
    this.methodName = methodName;
    this.params = params;
    this.isStatic = isStatic;
  }

  /**
   * A "create method" fix. Duplicate parameter names (e.g. {@code f(a, a)}) get an index suffix so
   * the generated declaration always compiles.
   */
  public static QuickFix createMethod(
      String targetClass, String returnType, String methodName, List<Param> params) {
    return createMethod(targetClass, returnType, methodName, params, false);
  }

  public static QuickFix createMethod(
      String targetClass,
      String returnType,
      String methodName,
      List<Param> params,
      boolean isStatic) {
    ArrayList<Param> unique = new ArrayList<>();
    HashSet<String> used = new HashSet<>();
    if (params != null) {
      for (Param param : params) {
        if (param == null) continue;
        String name = param.name;
        for (int n = 2; !used.add(name); n++) name = param.name + n;
        unique.add(new Param(param.type, name));
      }
    }
    String type = returnType == null || returnType.trim().isEmpty() ? "void" : returnType.trim();
    return new QuickFix(
        Kind.CREATE_METHOD,
        targetClass == null ? "" : targetClass.trim(),
        type,
        methodName == null ? "" : methodName.trim(),
        Collections.unmodifiableList(unique),
        isStatic);
  }

  /** A "create field" fix: {@code private [static] type name;} in {@code targetClass}. */
  public static QuickFix createField(
      String targetClass, String type, String fieldName, boolean isStatic) {
    String fieldType = type == null || type.trim().isEmpty() ? "Object" : type.trim();
    return new QuickFix(
        Kind.CREATE_FIELD,
        targetClass == null ? "" : targetClass.trim(),
        fieldType,
        fieldName == null ? "" : fieldName.trim(),
        Collections.<Param>emptyList(),
        isStatic);
  }

  /** Offset of an {@link Kind#INSERT_TOKEN} repair in the checked file (-1 otherwise). */
  public int insertOffset = -1;
  /** EDIT_TEXT: end of the replaced range, the text it must still hold, and the menu title. */
  public int editEnd = -1;
  public String expected = "";
  /** Optional whole-document guard for fixes originating from a snapshot-based analyzer. */
  private String expectedSourceDigest;
  public String titleKey = "";
  public String titleArg = "";

  /** "Insert 'token'" at {@code offset} of the checked source (a syntax repair). */
  public static QuickFix insertToken(String token, int offset) {
    QuickFix fix =
        new QuickFix(Kind.INSERT_TOKEN, "", "", token == null ? "" : token,
            Collections.<Param>emptyList(), false);
    fix.insertOffset = Math.max(0, offset);
    return fix;
  }

  /**
   * R6 (Id/wd fixes): replaces {@code [start, end)} — which must still read the same text when
   * applied — with {@code replacement}. {@code titleKey} names the menu entry ("Remove cast"…).
   */
  public static QuickFix replaceText(
      String source, int start, int end, String replacement, String titleKey, String titleArg) {
    if (source == null || start < 0 || end < start || end > source.length()) return null;
    QuickFix fix =
        new QuickFix(Kind.EDIT_TEXT, "", "", replacement == null ? "" : replacement,
            Collections.<Param>emptyList(), false);
    fix.insertOffset = start;
    fix.editEnd = end;
    fix.expected = source.substring(start, end);
    fix.titleKey = titleKey == null ? "" : titleKey;
    fix.titleArg = titleArg == null ? "" : titleArg;
    return fix;
  }

  /** Guard against applying an old snapshot's fix, including zero-length insertions. */
  public QuickFix guardSource(String source) {
    expectedSourceDigest = source == null ? null : sourceDigest(source);
    return this;
  }

  private static String sourceDigest(String source) {
    try {
      byte[] bytes = java.security.MessageDigest.getInstance("SHA-256")
          .digest(source.getBytes(java.nio.charset.StandardCharsets.UTF_8));
      char[] digits = "0123456789abcdef".toCharArray();
      char[] hex = new char[bytes.length * 2];
      for (int i = 0; i < bytes.length; i++) {
        int value = bytes[i] & 255;
        hex[2 * i] = digits[value >>> 4]; hex[2 * i + 1] = digits[value & 15];
      }
      return new String(hex);
    } catch (java.security.NoSuchAlgorithmException impossible) {
      throw new IllegalStateException(impossible);
    }
  }

  /** Inserts {@code text} at {@code offset} under the given menu title. */
  public static QuickFix insertText(String source, int offset, String text, String titleKey, String titleArg) {
    return replaceText(source, offset, offset, text, titleKey, titleArg);
  }

  /**
   * Deletes {@code [start, end)}; when the range is alone on its line(s) the whole lines go, so no
   * blank line is left behind.
   */
  public static QuickFix deleteText(String source, int start, int end, String titleKey) {
    if (source == null || start < 0 || end < start || end > source.length()) return null;
    int from = start, to = end;
    int ls = from;
    while (ls > 0 && (source.charAt(ls - 1) == ' ' || source.charAt(ls - 1) == '\t')) ls--;
    int le = to;
    while (le < source.length() && (source.charAt(le) == ' ' || source.charAt(le) == '\t')) le++;
    if ((ls == 0 || source.charAt(ls - 1) == '\n') && (le == source.length() || source.charAt(le) == '\n')) {
      from = ls;
      to = le < source.length() ? le + 1 : le;
    } else {
      while (from > 0 && (source.charAt(from - 1) == ' ' || source.charAt(from - 1) == '\t')) from--;
    }
    return replaceText(source, from, to, "", titleKey, "");
  }

  /** الاسم المحزَّم الذي سيُستورد (لـ{@link Kind#ADD_IMPORT} وحده). */
  public String importName = "";

  /**
   * أسطرُ الاستيرادِ التي تَطلَبُها الدَّفعَةُ، مُقيَّدةً، تُمهَّدُ معَ الجِسمِ في عمليةٍ واحدةٍ.
   * تَخرُجُ من {@link #withImports} ولا تُعرَّضُ للفهرسةِ: لا يَقرَأُها إلّا {@link #planInsertion} على
   * النصِّ الحيِّ. ومنذُ ‏1.0.191‏ تَعبرُ السِّلكَ أيضًا — لأنَّ ما فيها حقيقةٌ عن **المولودِ** («ماذا
   * يَحتاجُ») لا عنِ الملفِّ؛ وأمّا «أفي الملفِّ سطرُهُ الآنَ؟» فيُقرَأُ عندَ التطبيقِ ب‏{@link
   * AbstractImplementationGap#pendingFetches}‏، فلا سطرَ مُكرَّرًا ولا صفرًا زورًا حينَ يَنقُصُ المولودُ سطرَهُ.
   */
  public List<String> importsToFetch = Collections.emptyList();

  /** استيراداتُ ما يُولَّدُ: الترتيبُ محفوظٌ، والاسمُ الواحدُ مَرَّةٌ واحدةٌ (دفعَةٌ ثلاثُ دوالَّ قد
   * تَذكُرُ {@code android.view.View} في العَودِ وفي الوصفِ معًا). */
  public void withImports(List<String> qualifiedNames) {
    if (qualifiedNames == null || qualifiedNames.isEmpty()) {
      importsToFetch = Collections.emptyList();
      return;
    }
    ArrayList<String> unique = new ArrayList<String>(qualifiedNames.size());
    for (String name : qualifiedNames) {
      if (name == null || name.isEmpty() || unique.contains(name)) continue;
      unique.add(name);
    }
    importsToFetch = unique.isEmpty()
        ? Collections.<String>emptyList()
        : Collections.unmodifiableList(unique);
  }

  /** {@code group:artifact:version} المُقرَّرةُ للجَلبِ (لـ{@link Kind#FETCH_DEPENDENCY} وحده). */
  public String coordinate = "";

  /** دفعةُ الحذفِ (لـ{@link Kind#REMOVE_IMPORTS} وحدها): نطاقاتٌ مُتحقَّقٌ منها مع النصِّ الحيِّ عندَ الطلبِ. */
  public ImportFixActions.Plan importPlan;

  /** ‏1.0.197: خُطَّةُ {@link Kind#CREATE_TYPE} وَحدَها؛ بِلا خُطَّةٍ لا صَفَّ (لا مَعرِضَ لِوَعَدٍ لا نَوَفِيهِ). */
  public CreateClassPlan createType;

  /**
   * W27/3 (‏1.0.180): بقيّةُ الدوالِّ المجرّدةِ في الدفعةِ — الأولى في الحقولِ المَعتادةِ لهذهِ الصيغةِ
   * ({@code methodName}/{@code params}/{@code returnType})، والباقي هنا، فتَخرُجُ الدفعةُ كلُّها
   * لَاصقةً من مَوضِعٍ واحدٍ في خطوةِ تراجعٍ واحدةٍ، ولا سطرَ في الغلافِ يَعرِفُ أنَّها دَفعَةٌ.
   */
  public List<QuickFix> companions = Collections.emptyList();

  /** ‏1.0.186: الدالةُ تَنفِذُ ما طَلَبَهُ الأصلُ، فتُكتَبُ معَ {@code @Override} — عَلمٌ لا قالبٌ ثانٍ. */
  public boolean overrides;

  /**
   * «نفِّذ الدوالَّ المجرّدةَ كلَّها»: إصلاحٌ واحدٌ لِكُلِّ ناقصٍ. لا تُقبَلُ الدفعةُ بنصفِها: صِفرُ
   * دوالٍّ تعنيَ صنفًا لا يُبنى، فالعَرضُ يَسقُطُ كلُّهُ أو يَنفُذُ كلُّهُ.
   */
  public static QuickFix implementAbstractMethods(List<QuickFix> methods) {
    if (methods == null || methods.isEmpty()) return null;
    QuickFix first = methods.get(0);
    if (first == null || first.kind != Kind.CREATE_METHOD) return null;
    QuickFix fix =
        new QuickFix(Kind.CREATE_METHOD, first.targetClass, first.returnType, first.methodName,
            first.params, false);
    fix.companions =
        methods.size() == 1
            ? Collections.<QuickFix>emptyList()
            : Collections.unmodifiableList(new ArrayList<QuickFix>(methods.subList(1, methods.size())));
    fix.overrides = first.overrides; // الدفعةُ كلُّها من طلبِ الأصلِ: لا تَفقِدُ الأولى عَلمَها
    return fix;
  }

  /** الدفعةُ التي تَزدادُ على دالةٍ واحدةٍ (لا حَصرَ على الأولى عندَ أيِّ عَدٍّ). */
  public boolean isBatch() {
    return !companions.isEmpty();
  }

  /** W5: إصلاح «Add 'import &lt;fqn&gt;'» لملف الفحص نفسه — بلا حوار تأكيد لأنه تعديل محلي. */
  public static QuickFix addImport(String qualifiedName) {
    if (qualifiedName == null || qualifiedName.lastIndexOf('.') <= 0) return null;
    QuickFix fix =
        new QuickFix(
            Kind.ADD_IMPORT, "", "", "", Collections.<Param>emptyList(), false);
    fix.importName = qualifiedName;
    return fix;
  }

  /**
   * ‏1.0.197: صَفُّ «‏{@code Create class 'X'}» — اسمُ المَجرَى هُوَ اسمُ الصِّنْفِ، وَ{@code targetClass}
   * هِيَ باقَتُهُ، فَيَقرَأُ الغِلافُ الصَّفَّ «‏{@code Create class 'Game' in 'com.y'}» مِن غَيرِ أن
   * يَعرِفَ شَيئًا عَن صِنفِ البِناءِ. وَلا {@code insertOffset}: لا نِطاقَ فِي نَصٍّ نَعدِلُهُ.
   */
  public static QuickFix createType(CreateClassPlan plan) {
    if (plan == null) return null;
    QuickFix fix = new QuickFix(
        Kind.CREATE_TYPE, plan.packageName, "", plan.className, Collections.<Param>emptyList(), false);
    fix.createType = plan;
    return fix;
  }

  /** W5: صفّ «Fix imports» الجماعي، يستدعي تنظيم الاستيرادات القائم. */
  public static QuickFix fixImports() {
    return new QuickFix(Kind.FIX_IMPORTS, "", "", "", Collections.<Param>emptyList(), false);
  }

  /** 1.0.176: صفُّ حذفِ الاستيراداتِ السقيمةِ — دفعةٌ واحدةٌ من {@link ImportFixActions}؛ بلا قيمةٍ إن لم تُغرِّ. */
  public static QuickFix removeImports(ImportFixActions.Plan plan) {
    if (plan == null || !plan.isApplicable() || plan.isEmpty()) return null;
    QuickFix fix =
        new QuickFix(Kind.REMOVE_IMPORTS, "", "", "", Collections.<Param>emptyList(), false);
    fix.importPlan = plan;
    return fix;
  }

  /**
   * 1.0.175: صفّ «Fetch library for «X»» على تشخيصِ استيرادٍ غيرِ محلولٍ. {@code qualifiedName} هو الصنفُ
   * المطلوبُ (يُحمَلُ في {@code targetClass} لتعملَ به إعادةُ الفحصِ القائمةِ بلا تغييرٍ)، و{@code symbol}
   * الاسمُ المُبسَّطُ كما يراهُ القارئُ. الإحداثيّةُ تُترَكُ فارغةً: تُستخرَجُ في الخلفيةِ عندَ التنفيذِ،
   * فلا قرصَ ولا شبكةَ في خيطِ الواجهةِ.
   */
  public static QuickFix fetchDependency(String qualifiedName, String symbol) {
    String name = qualifiedName == null ? "" : qualifiedName.trim();
    if (name.indexOf('.') <= 0) return null;
    QuickFix fix =
        new QuickFix(Kind.FETCH_DEPENDENCY, name, "", symbol == null ? "" : symbol.trim(),
            Collections.<Param>emptyList(), false);
    return fix;
  }

  /**
   * المرحلة ١ من عزلِ المُحرِّكِ (‏W23): يُعادُ بناءُ الإصلاحِ من حِملِهِ السِّلكيّ كما يعودُ في المرجعِ من
   * ‏{@code Parcel} في {@code SyntaxError}/{@code Modification} — السِّجلُّ يعرفُ كيفَ يُعيدُ نفسَهُ من
   * تمثيلِهِ، فلا يتكرَّرُ ترتيبُ الحقولِ في موضعينِ (وهو موضِعُ الخطإِ في كلِّ جسرٍ بينَ العملياتِ).
   * القيمُ وصلَت مِنَ الطبقةِ الصافيةِ مُطبَّعةً أصلًا، فلا إعادةَ {@code trim} ولا إزالةَ تكرارٍ ثانيةً.
   */
  public static QuickFix restored(
      Kind kind,
      String targetClass,
      String returnType,
      String methodName,
      List<Param> params,
      boolean isStatic,
      String importName,
      String titleKey,
      String titleArg,
      String expected,
      int insertOffset,
      int editEnd) {
    QuickFix fix =
        new QuickFix(
            kind == null ? Kind.EDIT_TEXT : kind,
            targetClass == null ? "" : targetClass,
            returnType == null ? "" : returnType,
            methodName == null ? "" : methodName,
            params == null
                ? Collections.<Param>emptyList()
                : Collections.unmodifiableList(new ArrayList<>(params)),
            isStatic);
    fix.importName = importName == null ? "" : importName;
    fix.titleKey = titleKey == null ? "" : titleKey;
    fix.titleArg = titleArg == null ? "" : titleArg;
    fix.expected = expected == null ? "" : expected;
    fix.insertOffset = insertOffset;
    fix.editEnd = editEnd;
    return fix;
  }

  /**
   * ج٤٤: الدَّفعَةُ الَّتي جَمَعَتْ مَا ثَبَتَ تَحتَ حِجَابٍ في سِلسِلَةِ الأصلِ لا تَقولُ «كُلَّها» —
   * تَقولُ «المَعلومَةَ». حَقلٌ لا قَرينَ لَهُ في البِصمَةِ لأنَّ الإِصلاحَ نَفسَهُ مُتَطابِقٌ.
   */
  public boolean listMayBeIncomplete;

  /** String resource key of the menu title; its arguments are (signature, target class). */
  public String menuKey() {
    if (kind == Kind.REMOVE_IMPORTS) return "menu_remove_imports";
    if (kind == Kind.FETCH_DEPENDENCY) return "menu_fetch_dependency";
    if (kind == Kind.ADD_IMPORT) return "menu_add_import";
    if (kind == Kind.CREATE_TYPE) return "menu_create_class";
    if (kind == Kind.FIX_IMPORTS) return "menu_fix_imports";
    if (kind == Kind.EDIT_TEXT) return titleKey;
    if (kind == Kind.INSERT_TOKEN) return "ui_quick_fix_insert_token";
    if (isBatch())
      return listMayBeIncomplete ? "ui_quick_fix_implement_known_abstract"
                                 : "ui_quick_fix_implement_all_abstract";
    return kind == Kind.CREATE_FIELD ? "ui_quick_fix_create_field" : "ui_quick_fix_create_method";
  }

  /** Message key when the member already exists in the target class. */
  public String existsKey() {
    if (kind == Kind.CREATE_TYPE) return "ui_file_already_exists";
    return kind == Kind.CREATE_FIELD ? "ui_field_already_exists" : "ui_method_already_exists";
  }

  /** Toast key after the member was created; its argument is the member name. */
  public String createdKey() {
    if (isBatch()) return "ui_abstract_methods_created";
    if (kind == Kind.CREATE_TYPE) return "ui_class_created";
    return kind == Kind.CREATE_FIELD ? "ui_field_created" : "ui_method_created";
  }

  /**
   * حِجَّةُ رسالةِ النجاحِ: اسمُ العضوِ عادةً، وعَدَدُ الدوالِّ في دَفعةِ ‏W27/3. والنَّوعُ ‏`Object`‏
   * لا ‏`String`‏ عمدًا: قالبُ الدَّفعَةِ ‏`%1$d`‏ (‏ui_abstract_methods_created`‏)، وسِلسِلَةُ «‏3`‏»
   * تَرمِي ‏IllegalFormatConversionException`‏ من جَوفِ ‏Resources.getString`‏ بَعدَ تَطبيقِ الإصلاحِ
   * نَاجِحًا — جِهازُ الجَولَةِ ٤١. ومَن يَقرَأُها يَجِدُ ‏Integer`‏ عِندَها ويَجِدُ الاسمَ عِندَ الأُخرى.
   */
  public Object createdArg() {
    return isBatch() ? Integer.valueOf(1 + companions.size()) : methodName;
  }

  /** Declaration header as shown in the menu, e.g. {@code public void getstr()}. */
  public String signature() {
    if (kind == Kind.REMOVE_IMPORTS) return importPlan == null ? "" : importPlan.removedLines() + " lines";
    if (kind == Kind.FETCH_DEPENDENCY) return coordinate.isEmpty() ? targetClass : coordinate;
    if (kind == Kind.ADD_IMPORT) return importName;
    if (kind == Kind.CREATE_TYPE) return methodName;
    if (kind == Kind.FIX_IMPORTS) return "";
    if (kind == Kind.INSERT_TOKEN) return methodName;
    if (kind == Kind.EDIT_TEXT) return titleArg;
    if (kind == Kind.CREATE_FIELD)
      return "private " + (isStatic ? "static " : "") + returnType + " " + methodName;
    StringBuilder out = new StringBuilder("public ");
    if (isStatic) out.append("static ");
    out.append(returnType).append(' ').append(methodName).append('(');
    for (int i = 0; i < params.size(); i++) {
      if (i > 0) out.append(", ");
      out.append(params.get(i).type).append(' ').append(params.get(i).name);
    }
    return out.append(')').toString();
  }

  /** Identity used to drop duplicate fixes coming from several diagnostics on one range. */
  public String key() {
    if (kind == Kind.REMOVE_IMPORTS) {
      if (importPlan == null || importPlan.isEmpty()) return kind.toString();
      ImportFixActions.Op first = importPlan.ops.get(0);
      ImportFixActions.Op last = importPlan.ops.get(importPlan.ops.size() - 1);
      return kind + ":" + importPlan.ops.size() + ":" + first.start + ":" + last.end;
    }
    if (kind == Kind.FETCH_DEPENDENCY) return kind + ":" + (coordinate.isEmpty() ? targetClass : coordinate);
    if (kind == Kind.ADD_IMPORT) return kind + ":" + importName;
    if (kind == Kind.CREATE_TYPE) return kind + ":" + targetClass + ":" + methodName;
    if (kind == Kind.FIX_IMPORTS) return kind.toString();
    return kind + ":" + targetClass + ":" + methodName + ":" + params.size() + ":" + isStatic
        + ":" + insertOffset + (kind == Kind.EDIT_TEXT ? ":" + editEnd + ":" + titleKey : "")
        + (isBatch() ? ":batch" + (1 + companions.size()) : "");
  }

  /** True when {@code source} declares a class/interface/enum/record named {@link #targetClass}. */
  public boolean isDeclaredIn(String source) {
    return source != null && findDeclaration(mask(source), targetClass) != null;
  }

  /**
   * Plans the edit on {@code source}, or returns null when the class is not declared there or a
   * method with the same name and parameter count already exists.
   */
  public Insertion planInsertion(String source) {
    if (expectedSourceDigest != null && (source == null || !expectedSourceDigest.equals(sourceDigest(source))))
      return null;
    if (kind == Kind.ADD_IMPORT) {
      // من النص الحيّ لا من لقطة الفحص: الاستيراد يُضاف حيث هو الآن، أو لا يُضاف إن صار كافيًا.
      return JavaImportResolver.insertionFor(source, importName);
    }
    if (kind == Kind.FIX_IMPORTS) return null;
    if (kind == Kind.FETCH_DEPENDENCY) return null;
    if (kind == Kind.REMOVE_IMPORTS) {
      // النطاقاتُ إعادةُ بناؤها من النصِّ الحيِّ لا من لقطةِ الفحصِ: سطرٌ تحرَّكَ تُرفَضُ الدفعةُ كلُّها.
      return importPlan == null ? null : importPlan.asInsertion(source);
    } // الجَلبُ كتابةٌ في ملفِّ البناءِ، لا في المُحرِّرِ
    if (kind == Kind.EDIT_TEXT) {
      if (source == null || insertOffset < 0 || editEnd > source.length()
          || !source.startsWith(expected, insertOffset))
        return null; // the file changed since the check: never edit the wrong text
      int after = insertOffset + methodName.length();
      return new Insertion(insertOffset, editEnd, methodName, after, after);
    }
    if (kind == Kind.INSERT_TOKEN) {
      if (source == null || methodName.isEmpty() || insertOffset > source.length()) return null;
      int after = insertOffset + methodName.length();
      return new Insertion(insertOffset, methodName, after, after);
    }
    if (source == null || methodName.isEmpty() || targetClass.isEmpty()) return null;
    String code = mask(source);
    int[] declaration = findDeclaration(code, targetClass);
    if (declaration == null) return null;
    boolean isInterface = declaration[2] == 1;
    boolean isEnum = declaration[2] == 2;
    int open = code.indexOf('{', declaration[1]);
    if (open < 0) return null;
    int close = matchingBrace(code, open);
    if (close < 0) return null;

    Members members = scanMembers(code, open, close, isEnum);
    if (kind == Kind.CREATE_FIELD) return planField(source, code, declaration, open, close, members);
    if (members.hasMethod(methodName, params.size())) {
      // ‏1.0.191: الدَّفعَةُ لا تَسقُطُ برأسِها. إن كانَ أولُها مَكتوبًا وبَقِيَ فيهِ ناقصٌ — نقرةٌ
      // ثانِيَةٌ على «نفِّذ الدوالَّ»، أو صنفٌ كتَبَ بعضَها قبلَ الفحصِ — رُفِعَ أولُ مَفقودٍ إلى
      // الرأسِ وبَقِيَتِ الدَّفعَةُ خطوةَ تراجعٍ واحدةً. والرأسُ المَرفوعُ مَفقودٌ بالضرورةِ، فلا
      // دَورةَ في التخطيطِ؛ وإن كانَ كلُّها مَكتوبٍ بَقِيَ الرَفْضُ كما كانَ (سطرُ «مَوجودٌ» في اللوحةِ).
      QuickFix promoted = pendingHead(members);
      return promoted == null ? null : promoted.planInsertion(source);
    }

    String classIndent = lineIndent(source, declaration[0]);
    String indent;
    int offset;
    String prefix = "\n\n";
    String suffix = "";
    if (members.fieldBlockEnd >= 0) {
      int semicolon = members.fieldBlockEnd;
      int lineEnd = code.indexOf('\n', semicolon);
      if (lineEnd < 0 || lineEnd > close) lineEnd = close;
      offset = isBlank(code, semicolon + 1, lineEnd) ? lineEnd : semicolon + 1;
      indent = lineIndent(source, members.fieldBlockStart);
      if (indent.length() <= classIndent.length()) indent = classIndent + "    ";
    } else {
      int last = close - 1;
      while (last > open && Character.isWhitespace(code.charAt(last))) last--;
      offset = last + 1;
      indent = members.firstMember >= 0 ? lineIndent(source, members.firstMember) : "";
      if (indent.length() <= classIndent.length()) indent = classIndent + "    ";
      if (last == open) {
        prefix = "\n";
        if (code.indexOf('\n', open) < 0 || code.indexOf('\n', open) > close)
          suffix = "\n" + classIndent;
      } else if (isEnum && !members.enumConstantsTerminated) {
        prefix = ";\n\n";
      }
    }

    StringBuilder text = new StringBuilder(prefix);
    String sig = signature();
    text.append(declarationHead(indent, overrides && !isInterface));
    int nameAt = text.length() - sig.length() + sig.indexOf(' ' + methodName + '(') + 1;
    if (isInterface) {
      text.append(';');
    } else {
      text.append(stubBody(indent));
      if (isBatch())
        for (QuickFix companion : companions) {
          if (members.hasMethod(companion.methodName, companion.params.size())) continue;
          text.append("\n\n").append(companion.declarationHead(indent, companion.overrides))
              .append(companion.stubBody(indent));
        }
    }
    text.append(suffix);
    int nameStart = offset + nameAt;
    if (importsToFetch.isEmpty())
      return new Insertion(offset, text.toString(), nameStart, nameStart + methodName.length());
    // ‏1.0.189: التوقيعُ المَبسَّطُ يَحمِلُ معَهُ سطورَهُ — كتلةٌ واحدةٌ بأيِّ عدَدٍ، ودُفِعَت بخطوةِ
    // تراجعٍ واحدةٍ معَ الجِسمِ (نفسُ {@code ImportFixActions.Plan} التي تَجمَعُ حَذفَ الاستيراداتِ
    // في عمليةٍ واحدةٍ: unionٌ للنافذةِ معَ تَخلِيصِ البادئةِ واللَّحقَةِ المشتركةِ، فلا مَسارَ ثانِيَ).
    Insertion imports = JavaImportResolver.insertionForAll(source, importsToFetch);
    if (imports == null)
      return new Insertion(offset, text.toString(), nameStart, nameStart + methodName.length());
    ArrayList<ImportFixActions.Op> ops = new ArrayList<ImportFixActions.Op>(2);
    ImportFixActions.Op importOp =
        new ImportFixActions.Op(imports.offset, imports.offset, imports.text, "", "generate");
    ImportFixActions.Op bodyOp = new ImportFixActions.Op(offset, offset, text.toString(), "", "generate");
    if (importOp.start <= bodyOp.start) {
      ops.add(importOp);
      ops.add(bodyOp);
    } else {
      ops.add(bodyOp);
      ops.add(importOp);
    }
    ImportFixActions.Plan merged = new ImportFixActions.Plan(ops, 0, 0, "ok");
    Insertion asOne = merged.asInsertion(source);
    if (asOne == null)
      return new Insertion(offset, text.toString(), nameStart, nameStart + methodName.length());
    // المِرناءُ داخِلُ المُولَّدِ، فلا يُنقَلُ بـ{@code caretAfter} (تِلكَ عِدادُ ما يَلي الدفعةَ كلَّها):
    // اسمُ الدالةِ يَنزِلُ في الناتجِ عندَ مَوضِعِهِ زائدًا طولَ كتلةِ الاستيراداتِ إن كانت فوقَهُ —
    // وبلا ذلكَ يَبقُ مَوضِعُهُ كما هو. غلطُ هذا الحِسابِ كان يُلقِي المِرناءَ وراءَ آخرِ الملفِّ.
    int nameAtAfter = imports.offset <= nameStart
        ? nameStart + imports.text.length()
        : nameStart;
    return new Insertion(asOne.offset, asOne.removeEnd, asOne.text, nameAtAfter,
        nameAtAfter + methodName.length());
  }

  /**
   * رأسُ الدَّفعَةِ مَكتوبٌ: أولُ مَفقودٍ من رُفَقاءَ — صيغةٌ جديدةٌ لا تَعديلٌ في القديمةِ (الحقولُ
   * final)، ومَعَهُ عَلمُ التغطيةِ واستيراداتُ الدَّفعَةِ كلِّها. صِفرٌ إن لم يَبقَ ناقصٌ.
   */
  private QuickFix pendingHead(Members members) {
    if (companions.isEmpty()) return null;
    QuickFix head = null;
    for (QuickFix companion : companions) {
      if (companion == null || companion.kind != Kind.CREATE_METHOD) continue;
      if (head == null && !members.hasMethod(companion.methodName, companion.params.size())) {
        head = companion;
      }
    }
    if (head == null) return null;
    QuickFix promoted =
        QuickFix.createMethod(targetClass, head.returnType, head.methodName, head.params,
            head.isStatic);
    if (promoted == null) return null;
    promoted.overrides = head.overrides;
    ArrayList<QuickFix> rest = new ArrayList<QuickFix>(companions.size());
    for (QuickFix companion : companions)
      if (companion != null && companion != head) rest.add(companion);
    promoted.companions = Collections.unmodifiableList(rest);
    promoted.withImports(importsToFetch); // أسطرُ الدَّفعَةِ تَبقُ للدَّفعَةِ، لا للرأسِ المَكتوبِ
    return promoted;
  }

  /** Field placement: appended to the first field block, else at the top of the class body. */
  private Insertion planField(
      String source, String code, int[] declaration, int open, int close, Members members) {
    if (members.fields.contains(methodName)) return null;
    String classIndent = lineIndent(source, declaration[0]);
    String declarationText = signature() + ";";
    String indent;
    int offset;
    String prefix = "\n";
    String suffix = "";
    if (members.fieldBlockEnd >= 0) {
      int semicolon = members.fieldBlockEnd;
      int lineEnd = code.indexOf('\n', semicolon);
      if (lineEnd < 0 || lineEnd > close) lineEnd = close;
      offset = isBlank(code, semicolon + 1, lineEnd) ? lineEnd : semicolon + 1;
      indent = lineIndent(source, members.fieldBlockStart);
    } else if (declaration[2] == 2) {
      // Enum constants must stay first: the field goes right after the constants' ';'.
      indent = members.firstMember >= 0 ? lineIndent(source, members.firstMember) : "";
      if (indent.length() <= classIndent.length()) indent = classIndent + "    ";
      if (members.enumSemicolon >= 0) {
        offset = members.enumSemicolon + 1;
      } else {
        int last = close - 1;
        while (last > open && Character.isWhitespace(code.charAt(last))) last--;
        offset = last + 1;
        prefix = last == open ? "\n" + indent + ";\n" : ";\n";
        if (code.indexOf('\n', offset) < 0 || code.indexOf('\n', offset) > close)
          suffix = "\n" + classIndent;
      }
    } else {
      offset = open + 1;
      indent = members.firstMember >= 0 ? lineIndent(source, members.firstMember) : "";
      if (members.firstMember >= 0) suffix = "\n";
      else if (code.indexOf('\n', open) < 0 || code.indexOf('\n', open) > close)
        suffix = "\n" + classIndent;
    }
    if (indent.length() <= classIndent.length()) indent = classIndent + "    ";
    String text = prefix + indent + declarationText + suffix;
    int nameStart = offset + prefix.length() + indent.length() + declarationText.lastIndexOf(' ') + 1;
    return new Insertion(offset, text, nameStart, nameStart + methodName.length());
  }

  /**
   * جِسمُ الدالةِ المُولَّدةِ: {@code { … }} والعودةُ الافتراضيةَ فقط — **بلا سطرِ تعليقٍ**
   * (طلبُ ١.٠.١٨٨): لا «TODO» ولا «طَلَبَها المُصنِّفُ» يُدرَجانِ في شيفرةِ المُستخدِمِ لا من
   * إصلاحٍ ولا من إكمالٍ، فالتعليقُ المُولَّدُ دَينٌ في الملفِّ لا مَعلومةٌ، والمُستخدِمُ يَرى
   * جِسمًا فارغًا صحيحًا يَبني من أوَّلِ مُحاولةٍ.
   * المصبُّ الواحدُ لقالبٍ واحِدٍ: يَقرَأُهُ إصلاحُ «نفِّذ الدوالَّ المجرّدةَ كلَّها» ويَقرَأُهُ
   * المُكمِّلُ عندَ اقتراحِ دالةٍ مورَثةٍ في جِسمِ الصنفِ (‏1.0.186) — فلا قَالَبَانِ يَنفصلانِ يومًا.
   */
  public String stubBody(String indent) {
    StringBuilder out = new StringBuilder(" {\n");
    if (!"void".equals(returnType))
      out.append(indent).append("    return ").append(defaultValue(returnType)).append(";\n");
    out.append(indent).append('}');
    return out.toString();
  }

  /**
   * رأسُ الإعلانِ كما يَنزِلُ في جِسمِ الصنفِ: {@code @Override} عندَ تنفيذِ طلبِ الأصلِ، ثمَّ
   * المَسافةُ، ثمَّ التوقيعُ. المصبُّ واحدٌ: إصلاحُ «نفِّذ الدوالَّ المجرّدةَ كلَّها» وإكمالُ
   * «اِكتُبْها فوقَها» يَقرآنِ هذا السطرَ نفسَهُ، فلا يتفرّقُ قالبٌ يومًا على غلافَيْنِ.
   */
  public String declarationHead(String indent, boolean annotate) {
    return (annotate ? "@Override\n" : "") + indent + signature();
  }

  /** Default return expression for a generated body. */

  static String defaultValue(String type) {
    switch (type) {
      case "boolean":
        return "false";
      case "byte":
      case "short":
      case "int":
      case "long":
      case "float":
      case "double":
        return "0";
      case "char":
        return "'\\0'";
      default:
        return "null";
    }
  }

  // ---------------------------------------------------------------- source scanning

  private static final class Members {
    int fieldBlockStart = -1;
    int fieldBlockEnd = -1; // offset of the ';' closing the last field of the first block
    int firstMember = -1;
    boolean enumConstantsTerminated;
    int enumSemicolon = -1;
    final ArrayList<String> methods = new ArrayList<>(); // "name/paramCount"
    final HashSet<String> fields = new HashSet<>();

    boolean hasMethod(String name, int count) {
      return methods.contains(name + "/" + count);
    }
  }

  /** Walks the depth-1 members of the class body [open, close]. */
  private static Members scanMembers(String code, int open, int close, boolean isEnum) {
    Members members = new Members();
    int start = open + 1;
    if (isEnum) {
      int semicolon = topLevelSemicolon(code, open + 1, close);
      if (semicolon < 0) return members;
      members.enumConstantsTerminated = true;
      members.enumSemicolon = semicolon;
      start = semicolon + 1;
    }
    boolean blockOpen = true; // still inside the first run of fields
    int segment = start;
    int paren = 0;
    for (int i = start; i < close; i++) {
      char c = code.charAt(i);
      if (c == '(') paren++;
      else if (c == ')') paren = Math.max(0, paren - 1);
      else if (c == '{' && paren == 0) {
        int end = matchingBrace(code, i);
        if (end < 0 || end > close) break;
        String header = code.substring(segment, i);
        if (hasTopLevel(header, '=')) {
          i = end; // array/anonymous/lambda initializer of a field: the member ends at ';'
          continue;
        }
        if (members.firstMember < 0 && !header.trim().isEmpty())
          members.firstMember = segment + leadingSpace(header);
        recordMethod(members, header);
        if (members.fieldBlockEnd >= 0) blockOpen = false;
        i = end;
        segment = end + 1;
      } else if (c == ';' && paren == 0) {
        String member = code.substring(segment, i);
        if (!member.trim().isEmpty()) {
          int memberStart = segment + leadingSpace(member);
          if (members.firstMember < 0) members.firstMember = memberStart;
          int eq = topLevelIndex(member, '=');
          String head = eq < 0 ? member : member.substring(0, eq);
          if (head.indexOf('(') < 0) {
            recordFieldNames(members, member);
            if (blockOpen) {
              if (members.fieldBlockStart < 0) members.fieldBlockStart = memberStart;
              members.fieldBlockEnd = i;
            }
          } else {
            recordMethod(members, member); // abstract/interface method declaration
            if (members.fieldBlockEnd >= 0) blockOpen = false;
          }
        }
        segment = i + 1;
      }
    }
    return members;
  }

  /** Declarator names of a field member: {@code int a = 1, b;} gives a and b. */
  private static void recordFieldNames(Members members, String member) {
    int depth = 0, start = 0;
    ArrayList<String> parts = new ArrayList<>();
    for (int i = 0; i < member.length(); i++) {
      char c = member.charAt(i);
      if (c == '(' || c == '<' || c == '[' || c == '{') depth++;
      else if (c == ')' || c == '>' || c == ']' || c == '}') depth = Math.max(0, depth - 1);
      else if (c == ',' && depth == 0) {
        parts.add(member.substring(start, i));
        start = i + 1;
      }
    }
    parts.add(member.substring(start));
    for (String part : parts) {
      int eq = topLevelIndex(part, '=');
      String head = (eq < 0 ? part : part.substring(0, eq)).replaceAll("\\[\\s*\\]", "").trim();
      int end = head.length();
      int begin = end;
      while (begin > 0 && Character.isJavaIdentifierPart(head.charAt(begin - 1))) begin--;
      if (begin < end) members.fields.add(head.substring(begin, end));
    }
  }

  private static final Pattern ANNOTATION =
      Pattern.compile("^\\s*@\\s*[A-Za-z_$][\\w$.]*\\s*");

  /** Records "name/count" for a method or constructor header; ignores nested types/initializers. */
  private static void recordMethod(Members members, String header) {
    String rest = header;
    while (true) {
      Matcher annotation = ANNOTATION.matcher(rest);
      if (!annotation.find() || rest.trim().startsWith("@interface")) break;
      rest = rest.substring(annotation.end());
      if (rest.startsWith("(")) {
        int end = matchingParen(rest, 0);
        if (end < 0) return;
        rest = rest.substring(end + 1);
      }
    }
    int paren = rest.indexOf('(');
    if (paren < 0) return;
    int nameEnd = paren;
    while (nameEnd > 0 && Character.isWhitespace(rest.charAt(nameEnd - 1))) nameEnd--;
    int nameStart = nameEnd;
    while (nameStart > 0 && Character.isJavaIdentifierPart(rest.charAt(nameStart - 1))) nameStart--;
    if (nameStart == nameEnd) return;
    String before = rest.substring(0, nameStart);
    if (before.matches("(?s).*\\b(class|interface|enum|record)\\s+$")) return;
    int close = matchingParen(rest, paren);
    if (close < 0) return;
    members.methods.add(rest.substring(nameStart, nameEnd) + "/" + countParameters(rest.substring(paren + 1, close)));
  }

  private static int countParameters(String list) {
    if (list.trim().isEmpty()) return 0;
    int count = 1, angle = 0, paren = 0;
    for (int i = 0; i < list.length(); i++) {
      char c = list.charAt(i);
      if (c == '<') angle++;
      else if (c == '>') angle = Math.max(0, angle - 1);
      else if (c == '(') paren++;
      else if (c == ')') paren = Math.max(0, paren - 1);
      else if (c == ',' && angle == 0 && paren == 0) count++;
    }
    return count;
  }

  /** {start of keyword line anchor, end of the name, kind 0=class 1=interface 2=enum}. */
  private static int[] findDeclaration(String code, String name) {
    if (name == null || name.isEmpty()) return null;
    Matcher matcher =
        Pattern.compile("(?<![\\w$@])(class|interface|enum|record)\\s+" + Pattern.quote(name) + "(?![\\w$])")
            .matcher(code);
    if (!matcher.find()) return null;
    String keyword = matcher.group(1);
    int kind = "interface".equals(keyword) ? 1 : "enum".equals(keyword) ? 2 : 0;
    return new int[] {matcher.start(), matcher.end(), kind};
  }

  private static int topLevelSemicolon(String code, int from, int to) {
    int brace = 0, paren = 0;
    for (int i = from; i < to; i++) {
      char c = code.charAt(i);
      if (c == '{') brace++;
      else if (c == '}') brace--;
      else if (c == '(') paren++;
      else if (c == ')') paren--;
      else if (c == ';' && brace == 0 && paren == 0) return i;
    }
    return -1;
  }

  private static boolean hasTopLevel(String text, char wanted) {
    return topLevelIndex(text, wanted) >= 0;
  }

  /** Index of {@code wanted} outside parentheses/angle brackets (annotation arguments, generics). */
  private static int topLevelIndex(String text, char wanted) {
    int paren = 0;
    for (int i = 0; i < text.length(); i++) {
      char c = text.charAt(i);
      if (c == '(') paren++;
      else if (c == ')') paren = Math.max(0, paren - 1);
      else if (c == wanted && paren == 0) {
        // '==' / '<=' / '>=' / '!=' never appear in a member header at depth 0; plain '=' only.
        return i;
      }
    }
    return -1;
  }

  private static int matchingBrace(String code, int open) {
    int depth = 0;
    for (int i = open; i < code.length(); i++) {
      char c = code.charAt(i);
      if (c == '{') depth++;
      else if (c == '}' && --depth == 0) return i;
    }
    return -1;
  }

  private static int matchingParen(String text, int open) {
    int depth = 0;
    for (int i = open; i < text.length(); i++) {
      char c = text.charAt(i);
      if (c == '(') depth++;
      else if (c == ')' && --depth == 0) return i;
    }
    return -1;
  }

  private static int leadingSpace(String text) {
    int i = 0;
    while (i < text.length() && Character.isWhitespace(text.charAt(i))) i++;
    return i;
  }

  private static boolean isBlank(String text, int from, int to) {
    for (int i = from; i < to; i++) if (!Character.isWhitespace(text.charAt(i))) return false;
    return true;
  }

  private static String lineIndent(String source, int offset) {
    int lineStart = source.lastIndexOf('\n', Math.max(0, offset - 1)) + 1;
    if (offset == 0) lineStart = 0;
    int end = lineStart;
    while (end < source.length() && (source.charAt(end) == ' ' || source.charAt(end) == '\t')) end++;
    return source.substring(lineStart, end);
  }

  /**
   * Blanks comments, string/char literals and text blocks with spaces (newlines kept) so offsets
   * stay identical to the source while braces and semicolons inside them are ignored.
   */
  static String mask(String source) {
    char[] out = source.toCharArray();
    int i = 0, n = out.length;
    while (i < n) {
      char c = source.charAt(i);
      char next = i + 1 < n ? source.charAt(i + 1) : '\0';
      if (c == '/' && next == '/') {
        while (i < n && source.charAt(i) != '\n') out[i++] = ' ';
      } else if (c == '/' && next == '*') {
        int end = source.indexOf("*/", i + 2);
        end = end < 0 ? n : end + 2;
        blank(out, i, end);
        i = end;
      } else if (c == '"' && source.startsWith("\"\"\"", i)) {
        int end = source.indexOf("\"\"\"", i + 3);
        end = end < 0 ? n : end + 3;
        blank(out, i, end);
        i = end;
      } else if (c == '"' || c == '\'') {
        int j = i + 1;
        while (j < n && source.charAt(j) != c && source.charAt(j) != '\n') {
          if (source.charAt(j) == '\\') j++;
          j++;
        }
        int end = Math.min(n, j + 1);
        blank(out, i, end);
        i = end;
      } else {
        i++;
      }
    }
    return new String(out);
  }

  private static void blank(char[] out, int from, int to) {
    for (int k = from; k < to && k < out.length; k++) if (out[k] != '\n') out[k] = ' ';
  }
}
