package almlk;

/**
 * بند almlk ← أسلوب تحديد العناصر في AIDE عند الانتقاء (identifier-aware):
 * حدود معرّف لغة Java حول نقطة ما — حروف/أرقام/«_»/«$» — فينتقي الضغط المزدوج المعرف
 * كاملًا بدل تقطيع كلمة عشوائي عند «_».
 */
public final class IdentifierBounds {

  /** بداية المعرف الحاوي للموضع (أو الموضع نفسه عندما لا يوجد معرف). */
  public static int start(CharSequence text, int offset) {
    if (text == null || offset <= 0 || offset > text.length()) return Math.max(0, offset);
    int at = Math.min(offset, text.length());
    int start = at;
    while (start > 0 && isPart(text.charAt(start - 1))) start--;
    return start;
  }

  /** نهاية المعرف الحاوي للموضع (حصرية). */
  public static int end(CharSequence text, int offset) {
    if (text == null || offset < 0) return 0;
    int end = offset;
    while (end < text.length() && isPart(text.charAt(end))) end++;
    return end;
  }

  /**
   * يعيد حدود المعرّف الكامل عند حرف فعلي تحت اللمسة، أو null إن كانت اللمسة على فاصل.
   * يختلف عن start/end عند حدود الإدراج عمدًا: لا تُسند المسافة أو النقطة إلى الكلمة السابقة.
   */
  public static int[] rangeAt(CharSequence text, int offset) {
    if (text == null || offset < 0 || offset >= text.length() || !isPart(text.charAt(offset)))
      return null;
    return wholeIdentifierForSelection(text, offset, offset + 1);
  }

  /**
   * يوسّع اختيارًا غير فارغ واقعًا كله داخل مقطع واحد من محارف المعرّف إلى حدود المقطع كاملة.
   * يعيد null إذا لامس الاختيار فاصلًا، أو كان فارغًا/خارج النص؛ يدعم ترتيب طرفي الاختيار عكسيًا.
   */
  public static int[] wholeIdentifierForSelection(
      CharSequence text, int selectionStart, int selectionEnd) {
    if (text == null) return null;
    int from = Math.min(selectionStart, selectionEnd);
    int to = Math.max(selectionStart, selectionEnd);
    if (from < 0 || from >= to || to > text.length()) return null;
    for (int i = from; i < to; i++) {
      if (!isPart(text.charAt(i))) return null;
    }
    int start = from;
    while (start > 0 && isPart(text.charAt(start - 1))) start--;
    int end = to;
    while (end < text.length() && isPart(text.charAt(end))) end++;
    return new int[] {start, end};
  }

  /** هل الموضع داخل معرف (وليس على فراغ/علامة). */
  public static boolean inside(CharSequence text, int offset) {
    if (text == null || offset < 0 || offset >= text.length()) return false;
    return isPart(text.charAt(offset)) || (offset > 0 && isPart(text.charAt(offset - 1)));
  }

  /** قواعد المعرّف كما في مواصفة Java (Character.isJavaIdentifierPart). */
  public static boolean isPart(char c) {
    return Character.isJavaIdentifierPart(c);
  }

  /** يجب أن يبدأ معرف جافا بحرف/عملة/ندرسكور (يخدم فحص الكلمات المرشّحة للتعريف). */
  public static boolean isStart(char c) {
    return Character.isJavaIdentifierStart(c);
  }
}
