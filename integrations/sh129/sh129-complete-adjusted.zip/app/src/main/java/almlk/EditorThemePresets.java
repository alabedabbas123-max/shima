package almlk;

import java.util.LinkedHashMap;
import java.util.Locale;

/**
 * معرضُ الثيمات: خمسةٌ فاتحةٌ وخمسةٌ داكنةٌ لأشهرِ لوحاتِ تلوينِ الشيفرة (GitHub، Solarized, Quiet Light,
 * One, Visual Studio — وOne Dark Pro, Dracula, GitHub Dark, Solarized, Monokai Pro).
 *
 * <p>**ما أُخِذَ من المرجعِ هو الآليّةُ لا الأسماء**: عندَهُم رمزُ الثيمِ يحدّدُ لوحةً من نفسِ المفاتيحِ
 * الثلاثةَ عشرَ ({@code ColorDefault} / {@code ColorBlue} / {@code RedColor} / {@code TealColor})،
 * والتخزينُ ملفُّ تفضيلاتٍ لكلِّ رمز، والزرعُ عندَ الغيابِ فقط ({@code HighlightUtils}) ⇒ overrides كلِّ
 * ثيمٍ مستقلّةٌ، وتخصيصُكَ لـDracula لا يلمسُ GitHub. هنا العشرةُ لوحاتٌ بأسماءِ الثيماتِ المنشورةِ
 * لأصحابِها، بنفسِ البنيةِ تمامًا: الكودُ ← ثلاثةَ عشرَ سداسيًّا ← وعاءٌ مستقلّ.
 *
 * <p>كلُّ لوحةٍ تُعرِّفُ **لوحتَها هي** (فاتحةً كانت أو داكنة)؛ اللوحةُ الأخرى للثيمِ نفسِهِ تُقرأُ من
 * {@link EditorThemePalette} كما يقرأُ المرجعُ من {@code ColorDefault} عندَ غيابِ المفتاح — فلا استنساخُ
 * قيمٍ لا يقرأُها أحد، ولا اختراعُ لوحةٍ مضادّةٍ تُفسِدُ معاينةَ أصحابِ الثيم.
 *
 * <p>ترتيبُ {@link #hexByRole} مُطابِقٌ لـ{@link EditorThemePalette#ROLE_ORDER} حرفيًّا (ثلاثةَ عشرَ)،
 * والبوّاباتُ تُمسِكُ الجدولَ كلَّهُ لا عيّناتٍ منهُ.
 */
public final class EditorThemePresets {

  /** ثيمٌ واحدٌ: رمزٌ، لوحةٌ (فاتحةٌ/داكنةٌ)، وثلاثةَ عشرَ سداسيًّا بترتيبِ اللوحة. */
  public static final class Preset {
    public final String code;
    /** {@code true}: هذا ثيمٌ فاتحٌ ⇒ يُطبَّقُ مع نمطِ التطبيقِ الفاتح، و{@code false} داكن. */
    public final boolean light;
    public final String[] hexByRole;

    Preset(String code, boolean light, String... hexByRole) {
      if (hexByRole.length != EditorThemePalette.ROLE_ORDER.length) {
        throw new IllegalStateException(
            "theme " + code + " must declare " + EditorThemePalette.ROLE_ORDER.length + " roles, got " + hexByRole.length);
      }
      this.code = code;
      this.light = light;
      this.hexByRole = hexByRole;
    }

    public String roleHex(String role) {
      int index = EditorThemePalette.indexOf(role);
      return index < 0 ? null : hexByRole[index];
    }

    public Integer colorFor(String role) {
      String hex = roleHex(role);
      return hex == null ? null : EditorThemePalette.parseHexOrNull(hex);
    }
  }

  // ═══ الفاتح: خمسةٌ لأشهرِ ما يُستعمَلُ نهارًا ═══
  private static final Preset GITHUB_LIGHT =
      new Preset(
          "github_light", true,
          "#FFFFFFFF", "#FF24292E", "#FFD73A49", "#FF24292E", "#FF032F62", "#FFD73A49", "#FF6F42C1",
          "#FF005CC5", "#FF24292E", "#FF6A737D", "#FF9AA0A6", "#FFF6F8FA", "#FFC8E1FF");

  private static final Preset SOLARIZED_LIGHT =
      new Preset(
          "solarized_light", true,
          "#FFFDF6E3", "#FF657B83", "#FF859900", "#FF586E7D", "#FF2AA198", "#FFCB4B16", "#FFB58900",
          "#FF268BD2", "#FF93A1A1", "#FF93A1A1", "#FFAEA79F", "#FFEEE8D5", "#FFE5DFD0");

  private static final Preset QUIET_LIGHT =
      new Preset(
          "quiet_light", true,
          "#FFF5F5F5", "#FF333333", "#FFAA0D91", "#FF393939", "#FFC41A16", "#FF000000", "#FF74531F",
          "#FF800000", "#FF4F4F4F", "#FF008000", "#FF237893", "#FFEAEAEA", "#FFADD6FF");

  private static final Preset ONE_LIGHT =
      new Preset(
          "one_light", true,
          "#FFFAFAFA", "#FF383A42", "#FFA626A4", "#FF383A42", "#FF50A14F", "#FF0184BC", "#FFC18401",
          "#FF986801", "#FF383A42", "#FFA0A1A7", "#FF9A9B9C", "#FFF2F2F2", "#FFE5E5E6");

  private static final Preset VS_LIGHT =
      new Preset(
          "vs_light", true,
          "#FFFFFFFF", "#FF000000", "#FF0000FF", "#FF001080", "#FFA31515", "#FF000000", "#FF267F99",
          "#FF795E26", "#FF000000", "#FF008000", "#FF237893", "#FFF2F2F2", "#FFADD6FF");

  // ═══ الداكن: خمسةٌ لأشهرِ ما يُستعمَلُ ليلاً ═══
  private static final Preset ONE_DARK_PRO =
      new Preset(
          "one_dark_pro", false,
          "#FF282C34", "#FFABB2BF", "#FFC678DD", "#FFE06C75", "#FF98C379", "#FF56B6C2", "#FFE5C07B",
          "#FFD19A66", "#FFABB2BF", "#FF5C6370", "#FF4B5263", "#FF2C313A", "#FF3E4451");

  private static final Preset DRACULA =
      new Preset(
          "dracula", false,
          "#FF282A36", "#FFF8F8F2", "#FFFF79C6", "#FFF8F8F2", "#FFF1FA8C", "#FFFF79C6", "#FF8BE9FD",
          "#FFBD93F9", "#FFF8F8F2", "#FF6272A4", "#FF6272A4", "#3344475A", "#FF44475A");

  private static final Preset GITHUB_DARK =
      new Preset(
          "github_dark", false,
          "#FF0D1117", "#FFC9D1D9", "#FFFF7B72", "#FFC9D1D9", "#FFA5D6FF", "#FFFF7B72", "#FFFFA657",
          "#FFD2A8FF", "#FFC9D1D9", "#FF8B949E", "#FF6E7681", "#FF161B22", "#401F6FEB");

  private static final Preset SOLARIZED_DARK =
      new Preset(
          "solarized_dark", false,
          "#FF002B36", "#FF839496", "#FF859900", "#FF657B83", "#FF2AA198", "#FFCB4B16", "#FFB58900",
          "#FF268BD2", "#FF586E7D", "#FF586E7D", "#FF586E7D", "#FF073642", "#FF0F4C5C");

  private static final Preset MONOKAI_PRO =
      new Preset(
          "monokai_pro", false,
          "#FF2D2A2E", "#FFFCFCF6", "#FFFF6188", "#FFF8F8F2", "#FFFFD866", "#FFFF6188", "#FFA9DC76",
          "#FF78DCE8", "#FFFCFCF6", "#FF727072", "#FF727072", "#FF39373A", "#FF49484E");

  /** الخمسُ الفاتحةُ ثم الخمسُ الداكنة — ترتيبُ عرضِ الأقسامِ في الشاشة، لا ترتيبٌ أبجديّ. */
  public static final Preset[] LIGHT = {GITHUB_LIGHT, SOLARIZED_LIGHT, QUIET_LIGHT, ONE_LIGHT, VS_LIGHT};
  public static final Preset[] DARK = {ONE_DARK_PRO, DRACULA, GITHUB_DARK, SOLARIZED_DARK, MONOKAI_PRO};

  public static final Preset[] ALL = concat(LIGHT, DARK);

  private EditorThemePresets() {}

  private static Preset[] concat(Preset[] first, Preset[] second) {
    Preset[] out = new Preset[first.length + second.length];
    System.arraycopy(first, 0, out, 0, first.length);
    System.arraycopy(second, 0, out, first.length, second.length);
    return out;
  }

  /** {@code null} للأساسِ ({@code default}) وللكودِ المجهول: المرجعُ يقرأُ لوحةَ {@code ColorDefault} حينَها. */
  public static Preset byCode(String code) {
    if (code == null || EditorThemePalette.DEFAULT_THEME_CODE.equals(code)) return null;
    for (Preset preset : ALL) if (preset.code.equals(code)) return preset;
    return null;
  }

  /**
   * وعاءُ التفضيلاتِ لكلِّ رمزِ ثيم — {@code HighlightUtils} عندهم ملفٌّ لكلِّ ثيم؛ والأساسُ يبقى على
   * ملفِّه القديمِ {@code shima_color_scheme} فلا تضيعُ بياناتُ من ضبطَ ألوانَهُ قبلَ المعرض.
   */
  public static String prefsNameFor(String code) {
    String base = "shima_color_scheme";
    if (code == null || code.trim().isEmpty() || EditorThemePalette.DEFAULT_THEME_CODE.equals(code))
      return base;
    return base + "_" + code.toLowerCase(Locale.US).replaceAll("[^a-z0-9_]", "_");
  }

  /** سداسيُّ الدورِ في لوحةٍ بعينِها لهذا الثيم، أو {@code null} ليُكمِلَ {@link EditorThemePalette}. */
  public static String hexFor(String code, String role, boolean light) {
    Preset preset = byCode(code);
    if (preset == null || preset.light != light) return null;
    return preset.roleHex(role);
  }

  public static Integer colorFor(String code, String role, boolean light) {
    String hex = hexFor(code, role, light);
    return hex == null ? null : EditorThemePalette.parseHexOrNull(hex);
  }

  /** الخاناتُ الخمسُ التي تُرسمُ في شريطِ المعاينةِ باللوحةِ نفسِها — المصدرُ واحدٌ فلا تُعرَضُ ألوانٌ أخرى. */
  public static final String[] PREVIEW_ROLES = {
    EditorThemePalette.BACKGROUND, EditorThemePalette.PLAIN, EditorThemePalette.KEYWORD,
    EditorThemePalette.LITERAL, EditorThemePalette.COMMENT
  };

  /**
   * معاينةُ الثيمِ نفسِهِ (قيمتُهُ المعلَنةُ، لا تعديلاتُ المستخدمِ في وعائِهِ): ما يراهُ المشتَرِكُ قبلَ أن
   * يلمسَ شيئًا. وللأساسِ تُقرأُ لوحةُ المرجعِ الفاتحةُ كما هي.
   */
  public static int[] previewColors(String code) {
    Preset preset = byCode(code);
    int[] out = new int[PREVIEW_ROLES.length];
    for (int i = 0; i < PREVIEW_ROLES.length; i++) {
      String hex = preset == null ? null : preset.roleHex(PREVIEW_ROLES[i]);
      if (hex == null) hex = EditorThemePalette.defaultHex(PREVIEW_ROLES[i], preset == null || preset.light);
      out[i] = EditorThemePalette.parseHex(hex, out[i]);
    }
    return out;
  }

  public static String[] codes() {
    String[] out = new String[ALL.length];
    for (int i = 0; i < out.length; i++) out[i] = ALL[i].code;
    return out;
  }

  /** اسمُ موردِ العنوانِ للعرض ({@code theme_github_light}) — الشاشةُ تربطُهُ بـ{@code R.string}. */
  public static String titleResourceName(String code) {
    return "theme_" + (code == null ? EditorThemePalette.DEFAULT_THEME_CODE : code);
  }

  public static String summaryResourceName(String code) {
    return titleResourceName(code) + "_summary";
  }

  /** كلُّ ثيمٍ يُميَّزُ نفسَهُ عن أساسِهِ: لا دورَ يسقطُ على دورٍ آخرَ بالغلط (بوابةُ العقد). */
  public static LinkedHashMap<String, String> roleHexMap(Preset preset) {
    LinkedHashMap<String, String> out = new LinkedHashMap<>();
    for (int i = 0; i < EditorThemePalette.ROLE_ORDER.length; i++) {
      out.put(EditorThemePalette.ROLE_ORDER[i], preset.hexByRole[i]);
    }
    return out;
  }
}
