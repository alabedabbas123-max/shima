package almlk;

import java.io.File;

/**
 * «إضافة إلى المشروع…»: تحرير نصّي آمن لكتلة dependencies في ملف بناء Gradle (Groovy أو KTS).
 * Java خالصة بلا Android — تُختبر مباشرة في RegressionSuite.
 */
public final class GradleDependencyEditor {

  private GradleDependencyEditor() {}

  /** إحداثيات Maven صالحة: group:artifact:version (مع مصنِّف اختياري رابع). */
  public static boolean isValidCoordinate(String text) {
    if (text == null) return false;
    String value = text.trim();
    return value.matches("[A-Za-z0-9_.\\-]+:[A-Za-z0-9_.\\-]+:[A-Za-z0-9_.+\\-\\[\\](),]+(:[A-Za-z0-9_.\\-]+)?");
  }

  /** سطر الاعتماد بصيغة الملف: KTS يتطلب الأقواس وعلامات الاقتباس المزدوجة. */
  public static String mavenLine(String coordinate, boolean kts) {
    String value = coordinate.trim();
    return kts ? "implementation(\"" + value + "\")" : "implementation '" + value + "'";
  }

  /** سطر مكتبات libs/*.jar بصيغة الملف. */
  public static String jarFolderLine(boolean kts) {
    return kts
        ? "implementation(fileTree(mapOf(\"dir\" to \"libs\", \"include\" to listOf(\"*.jar\"))))"
        : "implementation fileTree(dir: 'libs', include: ['*.jar'])";
  }

  /** هل يحوي الملف هذا الاعتماد سلفًا؟ (مقارنة بلا مسافات ولا نوع الاقتباس). */
  public static boolean containsDependency(String buildText, String line) {
    return normalize(buildText).contains(normalize(line));
  }

  /**
   * يضيف السطر داخل كتلة dependencies العليا (لا داخل buildscript) أو ينشئ الكتلة في آخر الملف.
   * يعيد النص نفسه إن كان الاعتماد موجودًا.
   */
  public static String addDependency(String buildText, String line) {
    String text = buildText == null ? "" : buildText;
    if (containsDependency(text, line)) return text;
    int block = topLevelBlock(text, "dependencies");
    if (block < 0) {
      String prefix = text.isEmpty() || text.endsWith("\n") ? text : text + "\n";
      return prefix + "\ndependencies {\n    " + line + "\n}\n";
    }
    int close = matchingBrace(text, text.indexOf('{', block));
    if (close < 0) return text + "\n" + line + "\n";
    int lineStart = text.lastIndexOf('\n', close - 1) + 1;
    boolean braceAlone = text.substring(lineStart, close).trim().isEmpty();
    String insertion = "    " + line + "\n";
    if (braceAlone) return text.substring(0, lineStart) + insertion + text.substring(lineStart);
    return text.substring(0, close) + "\n" + insertion + text.substring(close);
  }

  /**
   * يزيلُ سطرَ الاعتمادِ من كتلةِ dependencies العليا فقطْ — ولا يمسُّ شيئًا آخرِ.
   * المطابقةُ بمقياسِ {@link #normalize} نفسِهِ المستعملِ في الإضافةِ، فلا يبقى سطرٌ
   * «شبهَ مطابقٍ» ولا يُحذَفَ سطرٌ لا يمتُّ إلى ما طُلِبَ. يعيدُ النصَّ كما هوَ إن لم يوجدْ.
   */
  public static String removeDependency(String buildText, String line) {
    String text = buildText == null ? "" : buildText;
    String wanted = normalize(line);
    if (wanted.isEmpty() || text.isEmpty()) return text;
    int block = topLevelBlock(text, "dependencies");
    if (block < 0) return text;
    int open = text.indexOf('{', block);
    int close = matchingBrace(text, open);
    if (open < 0 || close < 0) return text;
    String head = text.substring(0, open + 1);
    String body = text.substring(open + 1, close);
    String tail = text.substring(close);
    String[] lines = body.split("\n", -1);
    StringBuilder kept = new StringBuilder();
    boolean removed = false;
    for (String raw : lines) {
      String trimmed = raw.trim();
      String comparable = trimmed.endsWith(",") || trimmed.endsWith(";")
          ? trimmed.substring(0, trimmed.length() - 1).trim() : trimmed;
      if (!removed && !comparable.isEmpty() && normalize(comparable).equals(wanted)) {
        removed = true;
        continue;
      }
      kept.append(raw).append('\n');
    }
    if (!removed) return text;
    String rebuilt = kept.toString();
    while (rebuilt.endsWith("\n\n")) rebuilt = rebuilt.substring(0, rebuilt.length() - 1);
    if (!rebuilt.isEmpty() && !rebuilt.endsWith("\n")) rebuilt += "\n";
    return head + rebuilt + tail;
  }

  private static final java.util.regex.Pattern WRITTEN_LINE = java.util.regex.Pattern.compile(
      "\\s*([A-Za-z][A-Za-z0-9_]*)\\s*\\(?\\s*(['\"])([^'\"]+)\\2\\s*\\)?\\s*;?\\s*");

  /**
   * سطر من محرّر حوار Add Dependency: إحداثيات مجرّدة ({@code g:a:v} ← implementation) أو سطر
   * كامل ({@code api 'g:a:v'} / {@code compileOnly("g:a:v")}). يعيد السطر بصيغة الملف، أو null
   * إن لم تكن الإحداثيات صالحة.
   */
  public static String dependencyLine(String input, boolean kts) {
    if (input == null) return null;
    String value = input.trim();
    if (value.isEmpty()) return null;
    java.util.regex.Matcher m = WRITTEN_LINE.matcher(value);
    String configuration = "implementation";
    if (m.matches()) {
      configuration = m.group(1);
      value = m.group(3).trim();
    } else {
      if (value.length() > 1 && (value.charAt(0) == '\'' || value.charAt(0) == '"')
          && value.charAt(value.length() - 1) == value.charAt(0)) value = value.substring(1, value.length() - 1).trim();
    }
    if (!isValidCoordinate(value)) return null;
    return kts ? configuration + "(\"" + value + "\")" : configuration + " '" + value + "'";
  }

  /** يضيف عدة أسطر بالترتيب (الموجود سلفًا يُتخطّى). */
  public static String addDependencies(String buildText, java.util.List<String> lines) {
    String text = buildText == null ? "" : buildText;
    for (String line : lines) text = addDependency(text, line);
    return text;
  }

  /** ملف البناء الذي تُضاف إليه الاعتمادات: وحدة app إن كان المجلد جذر مشروع متعدد الوحدات. */
  public static File moduleBuildFile(File projectDir) {
    if (projectDir == null) return null;
    File own = buildFileIn(projectDir);
    boolean multiModule =
        new File(projectDir, "settings.gradle").isFile()
            || new File(projectDir, "settings.gradle.kts").isFile();
    if (multiModule) {
      File app = buildFileIn(new File(projectDir, "app"));
      if (app != null) return app;
    }
    return own;
  }

  /** build.gradle ثم build.gradle.kts داخل المجلد، وإلا null. */
  public static File buildFileIn(File dir) {
    if (dir == null) return null;
    File groovy = new File(dir, "build.gradle");
    if (groovy.isFile()) return groovy;
    File kts = new File(dir, "build.gradle.kts");
    return kts.isFile() ? kts : null;
  }

  /** موضع كلمة الكتلة في المستوى الأعلى (عمق أقواس صفر، خارج التعليقات والنصوص)، وإلا -1. */
  static int topLevelBlock(String text, String name) {
    int depth = 0;
    int n = text.length();
    for (int i = 0; i < n; i++) {
      char c = text.charAt(i);
      if (c == '/' && i + 1 < n && text.charAt(i + 1) == '/') {
        int end = text.indexOf('\n', i);
        if (end < 0) return -1;
        i = end;
      } else if (c == '/' && i + 1 < n && text.charAt(i + 1) == '*') {
        int end = text.indexOf("*/", i + 2);
        if (end < 0) return -1;
        i = end + 1;
      } else if (c == '"' || c == '\'') {
        i = skipString(text, i);
      } else if (c == '{') {
        depth++;
      } else if (c == '}') {
        depth = Math.max(0, depth - 1);
      } else if (depth == 0
          && text.startsWith(name, i)
          && (i == 0 || !Character.isJavaIdentifierPart(text.charAt(i - 1)))) {
        int j = i + name.length();
        while (j < n && Character.isWhitespace(text.charAt(j))) j++;
        if (j < n && text.charAt(j) == '{') return i;
      }
    }
    return -1;
  }

  private static int matchingBrace(String text, int open) {
    if (open < 0) return -1;
    int depth = 0;
    for (int i = open; i < text.length(); i++) {
      char c = text.charAt(i);
      if (c == '/' && i + 1 < text.length() && text.charAt(i + 1) == '/') {
        int end = text.indexOf('\n', i);
        if (end < 0) return -1;
        i = end;
      } else if (c == '/' && i + 1 < text.length() && text.charAt(i + 1) == '*') {
        int end = text.indexOf("*/", i + 2);
        if (end < 0) return -1;
        i = end + 1;
      } else if (c == '"' || c == '\'') {
        i = skipString(text, i);
      } else if (c == '{') {
        depth++;
      } else if (c == '}' && --depth == 0) {
        return i;
      }
    }
    return -1;
  }

  private static int skipString(String text, int start) {
    char quote = text.charAt(start);
    for (int i = start + 1; i < text.length(); i++) {
      char c = text.charAt(i);
      if (c == '\\') i++;
      else if (c == quote || c == '\n') return i;
    }
    return text.length() - 1;
  }

  private static String normalize(String text) {
    return text.replace('"', '\'').replaceAll("\\s+", "");
  }
}
