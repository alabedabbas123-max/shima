package almlk;

/**
 * Filtering rule of the completion popup and the positions to paint in the accent colour.
 *
 * <p>Like the reference, a row matches when its name starts with the typed prefix (ignoring case).
 * In addition, camel humps are accepted the way Android Studio does ({@code gSS} →
 * {@code getSystemService}, {@code lw} → {@code layout_width}); such rows rank after plain prefix
 * matches.
 */
public final class CompletionMatcher {

  public static final int NO_MATCH = Integer.MAX_VALUE;

  private CompletionMatcher() {}

  /** 0 = exact, 1 = prefix with same case, 2 = prefix ignoring case, 3 = camel humps, else NO_MATCH. */
  public static int rank(String name, String prefix) {
    if (name == null) return NO_MATCH;
    if (prefix == null || prefix.isEmpty()) return 2;
    if (name.equals(prefix)) return 0;
    if (name.startsWith(prefix)) return 1;
    if (name.regionMatches(true, 0, prefix, 0, prefix.length())) return 2;
    return humps(name, prefix) != null ? 3 : NO_MATCH;
  }

  public static boolean matches(String name, String prefix) {
    return rank(name, prefix) != NO_MATCH;
  }

  /**
   * Character positions of {@code name} matched by {@code prefix}: a leading run for prefix
   * matches, the hump starts otherwise; null when nothing matches.
   */
  public static int[] highlight(String name, String prefix) {
    if (name == null || prefix == null || prefix.isEmpty()) return null;
    if (name.regionMatches(true, 0, prefix, 0, prefix.length())) {
      int[] run = new int[prefix.length()];
      for (int i = 0; i < run.length; i++) run[i] = i;
      return run;
    }
    return humps(name, prefix);
  }

  /** Greedy camel/underscore hump match; the first character must match the first character. */
  private static int[] humps(String name, String prefix) {
    if (name.isEmpty() || Character.toLowerCase(name.charAt(0)) != Character.toLowerCase(prefix.charAt(0)))
      return null;
    int[] at = new int[prefix.length()];
    at[0] = 0;
    int q = 1;
    int i = 1;
    while (q < prefix.length() && i < name.length()) {
      char wanted = prefix.charAt(q);
      char c = name.charAt(i);
      boolean hump = Character.isUpperCase(c) || name.charAt(i - 1) == '_' || name.charAt(i - 1) == '-'
          || (Character.isDigit(c) && !Character.isDigit(name.charAt(i - 1)));
      boolean continues = at[q - 1] == i - 1;
      if (Character.toLowerCase(c) == Character.toLowerCase(wanted) && (hump || continues)) {
        at[q++] = i;
      }
      i++;
    }
    return q == prefix.length() ? at : null;
  }
}
