package almlk;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;

/**
 * شريطُ معاينةِ الثيمِ في المعرض: خمسةُ خاناتٍ (الخلفية، العاديّ، المفتاح، النص/الرقم، التعليق) تُرسمُ
 * بألوانِ اللوحةِ نفسِها، لا بسداسياتٍ منسوخةٍ في العرض — فإن بدّلَ المستخدمُ لونًا في مُحرِّرِ الأدوارِ
 * خرجتِ المعاينةُ معهُ لأنَّ المصدرَ واحد.
 *
 * <p>علامةُ ✓ على يسارِ الشريطِ تدلُّ الثيمَ المُطبَّقَ الآن، بلا حوارٍ ولا نافذةٍ تُزعجُ الاختيار.
 */
public class ThemeSwatchStrip extends View {

  private static final int MAX_CELLS = 6;
  private final int[] colors = new int[MAX_CELLS];
  private int cellCount = 0;
  private boolean active;

  private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
  private final Paint frame = new Paint(Paint.ANTI_ALIAS_FLAG);
  private final Paint check = new Paint(Paint.ANTI_ALIAS_FLAG);
  private final RectF box = new RectF();

  public ThemeSwatchStrip(Context context) {
    this(context, null);
  }

  public ThemeSwatchStrip(Context context, AttributeSet attrs) {
    super(context, attrs);
    float density = getResources().getDisplayMetrics().density;
    frame.setStyle(Paint.Style.STROKE);
    frame.setStrokeWidth(Math.max(1f, 1f * density));
    frame.setColor(0x40808080);
    check.setStyle(Paint.Style.STROKE);
    check.setStrokeWidth(Math.max(1.5f, 2f * density));
    check.setColor(0xFFFFFFFF);
    check.setStrokeCap(Paint.Cap.ROUND);
  }

  /** ألوانُ الخاناتِ بترتيبِها؛ الزائدُ عن {@link #MAX_CELLS} يُهمَل، والفراغُ يُخفي الشريطَ كلَّهُ. */
  public void setColors(int[] argb) {
    cellCount = 0;
    if (argb != null) {
      cellCount = Math.min(argb.length, MAX_CELLS);
      for (int i = 0; i < cellCount; i++) colors[i] = argb[i];
    }
    invalidate();
  }

  public void setActive(boolean active) {
    if (this.active == active) return;
    this.active = active;
    invalidate();
  }

  public boolean isActive() {
    return active;
  }

  @Override
  protected void onDraw(Canvas canvas) {
    super.onDraw(canvas);
    if (cellCount == 0) return;
    float density = getResources().getDisplayMetrics().density;
    float radius = 3f * density;
    float right = getWidth() - 1f;
    float left = 1f;
    float top = 1f;
    float bottom = getHeight() - 1f;
    if (active) {
      // الخانةُ الأولى جهةُ اليمينُ (RTL) للعلامة؛ والشريطُ بعدها فلا يتداخلُ شيئان.
      float mark = (bottom - top) * 0.62f;
      float cx = right - mark * 0.9f;
      float cy = (top + bottom) * 0.5f;
      canvas.drawCircle(cx, cy, mark * 0.78f, fillWith(0xFF1B9E4B));
      canvas.drawLine(cx - mark * 0.42f, cy, cx - mark * 0.06f, cy + mark * 0.34f, check);
      canvas.drawLine(cx - mark * 0.06f, cy + mark * 0.34f, cx + mark * 0.46f, cy - mark * 0.38f, check);
      right = cx - mark * 0.95f;
    }
    float width = right - left;
    if (width <= 0f) return;
    // المستطيلُ يُضبَطُ قبلَ الحلقةِ لا بعدَها: كلُّ خانةٍ شريحةٌ من المستطيلِ كلِّهِ، فلا تظهرُ
    // حوافٌ مستديرةٌ بينَ الخاناتِ ولا يبقى الإطارُ فارغًا في أوّلِ إطارٍ (وهو ما كانَ يُخفي
    // المعاينةَ حتى تُعادَ رسمَها مرةً أخرى).
    box.set(left, top, right, bottom);
    float cell = width / cellCount;
    for (int i = 0; i < cellCount; i++) {
      float from = left + cell * i;
      float to = (i == cellCount - 1) ? right : from + cell;
      canvas.save();
      canvas.clipRect(from, top, to, bottom);
      canvas.drawRoundRect(box, radius, radius, fillWith(colors[i]));
      canvas.restore();
    }
    canvas.drawRoundRect(box, radius, radius, frame);
  }

  private Paint fillWith(int argb) {
    fill.setColor(argb);
    return fill;
  }
}
