package almlk;

/**
 * هندسةُ رقعةِ التعشيبِ التي يظهرُ خلفَها لونُ السطرِ الشفّاف في مُحرِّرِ الألوان — طبقةٌ خالصةٌ
 * تفصلُ **قرارَ الشكلِ** عن **تنفيذِ الرسم**: الحجمُ والشفّافيةُ وتناوبُ الخليّةِ تُختبَرُ بلا
 * Android، و{@link AlphaCheckeredBar} يرسمُ ما تُقرِّرُهُ هذه فقط.
 *
 * <p>السببُ عمليٌّ: الصورةُ المرجعية تُظهرُ سطرَ «Selected line background» (قيمَتُهُ
 * {@code #10200000}) مُرقَّطًا لا مُموَّهًا على خلفيةِ الشاشة، فقيمتُها تُرى لونًا لا أثرًا. ومن هنا
 * قرارُ{@code showsChecker}: اللونُ الشفّافُ كلِّيًّا لا رقعةَ له أصلًا، لأنَّ الرقعةَ عندَها توهِمُ
 * بوجودِ لونٍ حيث لا لون.
 */
public final class AlphaCheckerPattern {

  /** مربّعٌ فاتحٌ ومربّعٌ كاسٍ — القيمتانِ اللتانِ تُقرآنُ عليهما درجةُ الألفا. */
  public static final int CELL_LIGHT = 0xFFBDBDBD;
  public static final int CELL_DARK = 0xFFFFFFFF;

  private AlphaCheckerPattern() {}

  /**
   * ارتفاعُ الشريطِ مقسومٌ خمسَ خلايا، وأقلُّها أربعُ نقطٍ حتى تُرى الرقعةُ على الشرائطِ الصغيرة؛
   * وصفرٌ عندَ ارتفاعٍ معدومٍ لأنَّ الرسمَ على حدودٍ فارغةٍ عملٌ بلا نتيجة.
   */
  public static int cellSizeFor(int heightPx) {
    return heightPx <= 0 ? 0 : Math.max(4, heightPx / 5);
  }

  /** هل يُرسمُ للشريطِ رقعةٌ أصلًا؟ الشفّافُ كلِّيًّا ({@code #00……}) يُترَكُ خاليًا بلا لون. */
  public static boolean showsChecker(int color) {
    return ((color >>> 24) & 0xFF) != 0;
  }

  /** لونُ الخليّةِ بتناوبِ الصفِّ والعمود — لا جدولَ ولا ذاكرةَ تخطيطٍ للرقعة. */
  public static int cellColor(int row, int column) {
    return ((row + column) & 1) == 0 ? CELL_LIGHT : CELL_DARK;
  }
}
