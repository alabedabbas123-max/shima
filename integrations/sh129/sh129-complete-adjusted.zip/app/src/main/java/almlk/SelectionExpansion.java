package almlk;

/**
 * "Expand selection" — the one selection button of the Select actions bar (pure).
 *
 * <p>Each press grows the selection one step and the same button works with or without a
 * selection, like the reference: on a word → the word, its {@code a.b} chain and call arguments;
 * on blank space → the current line; then the enclosing {@code { … }} block (repeatedly outward);
 * finally the whole file. Braces inside strings and comments are ignored via a masked copy of the
 * text (same length, literals blanked), computed only when that step is reached.
 */
public final class SelectionExpansion {

  private SelectionExpansion() {}

  /**
   * Next selection after {@code [start, end)}, or null when it already covers the whole text.
   *
   * @param masker blanks strings/comments keeping the length (Java-like files), or null; only
   *     called when the block step is reached
   */
  public static int[] expand(String text, java.util.function.UnaryOperator<String> masker, int start, int end) {
    if (text == null || text.isEmpty()) return null;
    int s = Math.max(0, Math.min(Math.min(start, end), text.length()));
    int e = Math.max(s, Math.min(Math.max(start, end), text.length()));
    boolean caretOnly = s == e;
    boolean touchesWord = (s > 0 && Character.isJavaIdentifierPart(text.charAt(s - 1)))
        || (e < text.length() && Character.isJavaIdentifierPart(text.charAt(e)));
    int[] next = caretOnly && !touchesWord ? null : wordChainOrCall(text, s, e);
    if (!accepted(next, s, e)) next = lineContent(text, s, e);
    if (!accepted(next, s, e)) {
      next = null;
      String masked = masker == null ? null : masker.apply(text);
      String code = masked != null && masked.length() == text.length() ? masked : text;
      int from = s, to = e;
      for (int[] block = enclosingBlock(code, from, to); block != null; block = enclosingBlock(code, from, to)) {
        if (accepted(block, s, e)) {
          next = block;
          break;
        }
        from = block[0]; // the selection is this block already: look one level out
        to = block[1];
      }
      if (next == null) next = new int[] {0, text.length()};
    }
    return accepted(next, s, e) ? next : null;
  }

  /** A caret accepts any non-empty range on its line (indentation is not dragged in); a selection must grow. */
  private static boolean accepted(int[] range, int start, int end) {
    if (range == null) return false;
    return start == end ? range[1] > range[0] : grows(range, start, end);
  }

  private static boolean grows(int[] range, int start, int end) {
    return range[0] <= start && range[1] >= end && (range[0] < start || range[1] > end);
  }

  /** The line's text without its indentation; null for a blank line. */
  private static int[] lineContent(String text, int start, int end) {
    int lineStart = text.lastIndexOf('\n', Math.max(0, start - 1)) + 1;
    if (start == 0) lineStart = 0;
    int lineEnd = text.indexOf('\n', end);
    if (lineEnd < 0) lineEnd = text.length();
    int left = lineStart;
    while (left < lineEnd && Character.isWhitespace(text.charAt(left))) left++;
    int right = lineEnd;
    while (right > left && Character.isWhitespace(text.charAt(right - 1))) right--;
    if (left >= right) return null;
    return start == end ? new int[] {left, right} : new int[] {Math.min(left, start), Math.max(right, end)};
  }

  /** The nearest {@code { … }} (braces included) containing {@code [start, end)}, or null. */
  private static int[] enclosingBlock(String code, int start, int end) {
    int depth = 0;
    for (int i = start - 1; i >= 0; i--) {
      char c = code.charAt(i);
      if (c == '}') depth++;
      else if (c == '{') {
        if (depth == 0) {
          int close = matchingBrace(code, i);
          if (close >= end - 1 && close >= 0) return new int[] {i, close + 1};
        } else depth--;
      }
    }
    return null;
  }

  private static int matchingBrace(String code, int open) {
    int depth = 0;
    for (int i = open; i < code.length(); i++) {
      char c = code.charAt(i);
      if (c == '{') depth++;
      else if (c == '}' && --depth == 0) return i;
    }
    return -1;
  }

  /** The word under the selection, widened over {@code a.b} chains and a following call's (…). */
  private static int[] wordChainOrCall(String text, int start, int end) {
    int left = start, right = end;
    while (left > 0 && Character.isJavaIdentifierPart(text.charAt(left - 1))) left--;
    while (right < text.length() && Character.isJavaIdentifierPart(text.charAt(right))) right++;
    int dotBefore = left - 1;
    while (dotBefore >= 0 && Character.isWhitespace(text.charAt(dotBefore))) dotBefore--;
    if (dotBefore >= 0 && text.charAt(dotBefore) == '.') {
      left = dotBefore;
      while (left > 0 && Character.isJavaIdentifierPart(text.charAt(left - 1))) left--;
    }
    int cursor = right;
    while (cursor < text.length() && Character.isWhitespace(text.charAt(cursor)) && text.charAt(cursor) != '\n') cursor++;
    if (cursor < text.length() && text.charAt(cursor) == '.') {
      cursor++;
      while (cursor < text.length() && Character.isWhitespace(text.charAt(cursor))) cursor++;
      while (cursor < text.length() && Character.isJavaIdentifierPart(text.charAt(cursor))) cursor++;
      right = cursor;
    }
    while (cursor < text.length() && Character.isWhitespace(text.charAt(cursor)) && text.charAt(cursor) != '\n') cursor++;
    if (cursor < text.length() && text.charAt(cursor) == '(') {
      int depth = 0;
      char quote = 0;
      boolean escape = false;
      for (int i = cursor; i < text.length(); i++) {
        char value = text.charAt(i);
        if (quote != 0) {
          if (escape) escape = false;
          else if (value == '\\') escape = true;
          else if (value == quote) quote = 0;
        } else if (value == '"' || value == '\'') quote = value;
        else if (value == '(') depth++;
        else if (value == ')' && --depth == 0) {
          right = i + 1;
          break;
        }
      }
    }
    if (left < right && (left != start || right != end)) return new int[] {left, right};
    return null;
  }
}
