package almlk;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.ByteBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * جدول ترحيل AndroidX (بيانات Google المنشورة، معاد صياغتها في {@link #ASSET}): قائمتا حوار
 * Add Dependency (AndroidX / AppCompat)، والإحداثيات المقترحة، وتحويل المشروع في الاتجاهين.
 *
 * <p>التحويل مسح واحد بحدود المعرّفات وأطول مطابقة (صنف ثم حزمة) فلا يُستبدل اسم داخل اسم آخر،
 * وإحداثيات Gradle تُبدَّل كاملة مع إصدار صالح، ولا يُكتب إلا الملف المتغيّر.
 */
public final class AndroidXMigration {
  public interface StreamSource extends AndroidApiIndex.StreamSource {}

  public static final String ASSET = "completion/androidx-migration.idx.gz";
  /** آخر إصدار لمكتبات الدعم (com.android.support) قبل AndroidX. */
  static final String LAST_SUPPORT_VERSION = "28.0.0";

  public static final class Artifact {
    public final String oldName, newName, baseVersion;

    Artifact(String oldName, String newName, String baseVersion) {
      this.oldName = oldName;
      this.newName = newName;
      this.baseVersion = baseVersion;
    }
  }

  /** الجدول المحمَّل: الاتجاهان للأدوات والحزم والأصناف. */
  static final class Table {
    final List<Artifact> artifacts = new ArrayList<>();
    final Map<String, Artifact> byOld = new HashMap<>();
    final Map<String, Artifact> byNew = new HashMap<>();
    final Map<String, String> classes = new HashMap<>();
    final Map<String, String> classesBack = new HashMap<>();
    final Map<String, String> packages = new HashMap<>();
    final Map<String, String> packagesBack = new HashMap<>();
    List<String> androidxNames = Collections.emptyList();
    List<String> appcompatNames = Collections.emptyList();
    /** أول جزء من كل اسم قديم/جديد: يسرّع رفض السلاسل التي لا تعنينا. */
    final Set<String> oldRoots = new HashSet<>();
    final Set<String> newRoots = new HashSet<>();
  }

  private static volatile StreamSource source;
  private static volatile Table table;

  private AndroidXMigration() {}

  public static void install(StreamSource streams) {
    source = streams;
  }

  /** الجدول (يُقرأ مرة واحدة)؛ جدول فارغ إن تعذّر الأصل فلا يُكسر شيء. */
  static Table table() {
    Table current = table;
    if (current != null) return current;
    synchronized (AndroidXMigration.class) {
      if (table != null) return table;
      Table loaded = null;
      StreamSource streams = source;
      if (streams != null) {
        try (InputStream in = AndroidApiIndex.openPacked(streams, ASSET)) {
          loaded = parse(in);
        } catch (IOException | RuntimeException failure) {
          loaded = null;
        }
      }
      if (loaded == null) {
        if (streams == null) return new Table(); // لم يُثبَّت بعد: لا نحفظ جدولًا فارغًا
        loaded = new Table();
      }
      table = loaded;
      return loaded;
    }
  }

  static Table parse(InputStream in) throws IOException {
    Table t = new Table();
    BufferedReader reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
    TreeSet<String> androidx = new TreeSet<>(), appcompat = new TreeSet<>();
    String line;
    while ((line = reader.readLine()) != null) {
      if (line.isEmpty() || line.startsWith("#")) continue;
      String[] f = line.split("\t", -1);
      if (f[0].equals("A") && f.length >= 4) {
        Artifact a = new Artifact(f[1], f[2], f[3]);
        t.artifacts.add(a);
        t.byOld.put(a.oldName, a);
        Artifact previous = t.byNew.get(a.newName);
        // اسمان قديمان لاسم جديد واحد: الرجوع إلى مجموعة الدعم الأصلية أولًا.
        if (previous == null || (!previous.oldName.startsWith("com.android.support:") && a.oldName.startsWith("com.android.support:")))
          t.byNew.put(a.newName, a);
        androidx.add(a.newName);
        appcompat.add(a.oldName);
      } else if ((f[0].equals("C") || f[0].equals("P")) && f.length >= 3) {
        boolean isClass = f[0].equals("C");
        Map<String, String> forward = isClass ? t.classes : t.packages;
        Map<String, String> back = isClass ? t.classesBack : t.packagesBack;
        forward.put(f[1], f[2]);
        if (back.containsKey(f[2])) back.put(f[2], null); // غامض في الرجوع: لا يُستعمل
        else back.put(f[2], f[1]);
        t.oldRoots.add(root(f[1]));
        t.newRoots.add(root(f[2]));
      }
    }
    t.classesBack.values().removeIf(v -> v == null);
    t.packagesBack.values().removeIf(v -> v == null);
    t.androidxNames = Collections.unmodifiableList(new ArrayList<>(androidx));
    t.appcompatNames = Collections.unmodifiableList(new ArrayList<>(appcompat));
    return t;
  }

  private static String root(String qualified) {
    int dot = qualified.indexOf('.');
    return dot < 0 ? qualified : qualified.substring(0, dot);
  }

  /** قائمة AndroidX (group:artifact) مرتّبة أبجديًا. */
  public static List<String> androidxNames() {
    return table().androidxNames;
  }

  /** قائمة AppCompat (مكتبات الدعم القديمة) مرتّبة أبجديًا. */
  public static List<String> appcompatNames() {
    return table().appcompatNames;
  }

  /** بديلُ الأداةِ القديمةِ في الجدولِ ({@code group:artifact} ← الاسمُ الجديدُ)، أو null. */
  public static Artifact oldToNew(String oldGroupArtifact) {
    if (oldGroupArtifact == null) return null;
    Artifact a = table().byOld.get(oldGroupArtifact);
    return a == null || a.newName == null || a.newName.isEmpty() ? null : a;
  }

  /** هل المشروعُ يعملُ بـAndroidX؟ {@code android.useAndroidX=true} في gradle.properties. */
  public static boolean usesAndroidX(File projectDir) {
    if (projectDir == null) return false;
    File properties = new File(projectDir, "gradle.properties");
    if (!properties.isFile() && "app".equals(projectDir.getName())) {
      properties = new File(projectDir.getParentFile(), "gradle.properties");
    }
    if (!properties.isFile()) return false;
    try (java.io.InputStream in = new java.io.FileInputStream(properties)) {
      StringBuilder text = new StringBuilder();
      byte[] buffer = new byte[8192];
      int read;
      long size = 0;
      while ((read = in.read(buffer)) > 0) {
        size += read;
        if (size > 256 * 1024) break;
        text.append(new String(buffer, 0, read, "UTF-8"));
      }
      for (String line : text.toString().split("\n")) {
        int eq = line.indexOf('=');
        if (eq < 0) continue;
        if ("android.useAndroidX".equals(line.substring(0, eq).trim())) {
          String value = line.substring(eq + 1).trim();
          int hash = value.indexOf('#');
          if (hash >= 0) value = value.substring(0, hash).trim();
          return "true".equalsIgnoreCase(value);
        }
      }
    } catch (Exception ignored) {
      // لا تُقرأُ الخصائصُ ← لا تحويلَ: يُترَكُ ما طلبَهُ المستخدمُ كما هوَ
    }
    return false;
  }

  /**
   * سطرُ الإحداثياتِ البديلُ في مشروعِ AndroidX لإحداثياتٍ قديمةٍ، أو null إن لم تكن قديمةً.
   * الإصدارُ من الجدولِ المحمَّلِ وحدَهُ — فلا سؤالَ شبكةٍ زائدًا لمجرَّدِ اقتراحٍ.
   */
  public static String androidxSubstitute(String oldGroupArtifact, boolean useAndroidX) {
    return androidxSubstitute(oldGroupArtifact, useAndroidX, null);
  }

  /**
   * كما {@link #androidxSubstitute(String, boolean)} لكنْ يُفضَّلُ أعلى إصدارٍ مستقرٍّ موجودٍ
   * محليًّا — وهو المنطقُ نفسُهُ الذي يستعملُهُ حوارُ «إضافةِ اعتمادٍ»، فلا سطرَيْنِ مختلفَيْنِ
   * للإحداثياتِ ذاتِها في مكانَيْنِ من التطبيقِ.
   */
  public static String androidxSubstitute(
      String oldGroupArtifact, boolean useAndroidX, java.util.Collection<String> localVersions) {
    if (!useAndroidX) return null;
    Artifact a = oldToNew(oldGroupArtifact);
    return a == null ? null : coordinateFor(a.newName, true, localVersions);
  }

  /** الإصدار الأساسي لاسم AndroidX، أو null. */
  public static String baseVersion(String androidxName) {
    Artifact a = table().byNew.get(androidxName);
    if (a == null) for (Artifact candidate : table().artifacts) if (candidate.newName.equals(androidxName)) return candidate.baseVersion;
    return a == null ? null : a.baseVersion;
  }

  /**
   * سطر المحرّر لعنصر مؤشَّر: AndroidX بإصداره الأساسي (أو أعلى إصدار مستقر موجود محليًا إن كان
   * أحدث)، وAppCompat بـ{@code +} كالمرجع.
   */
  public static String coordinateFor(String name, boolean androidx, Collection<String> localVersions) {
    if (!androidx) return name + ":+";
    String base = baseVersion(name);
    String best = base;
    if (localVersions != null) {
      for (String v : localVersions) {
        if (v == null || !MavenVersion.isStable(v)) continue;
        if (best == null || MavenVersion.compare(v, best) > 0) best = v;
      }
    }
    return name + ":" + (best == null ? "+" : best);
  }

  // ═══════════════ التحويل ═══════════════

  /** نتيجة تحويل المشروع. */
  public static final class Result {
    public int files;
    public int replacements;
    public long millis;
    public boolean propertiesChanged;
    public final List<File> changed = new ArrayList<>();
  }

  private static final Pattern COORDINATE =
      Pattern.compile("(?<![\\w.\\-])([A-Za-z][\\w.\\-]*:[A-Za-z][\\w.\\-]*)(?::([^'\"\\s,)}\\]]*))?(?=['\"])");
  private static final Set<String> TEXT_EXTENSIONS = new HashSet<>(java.util.Arrays.asList(
      "java", "kt", "kts", "gradle", "xml", "pro", "cfg", "txt", "json", "properties", "toml", "aidl"));
  static final long MAX_FILE_BYTES = 4L << 20;

  /**
   * يحوّل نصًا واحدًا. {@code gradle}: يُبدّل أيضًا الإحداثيات داخل النصوص. {@code count[0]}
   * يُزاد بعدد الاستبدالات.
   */
  public static String convertText(String text, boolean toAndroidX, boolean gradle, int[] count) {
    if (text == null || text.isEmpty()) return text;
    Table t = table();
    String out = gradle ? convertCoordinates(text, t, toAndroidX, count) : text;
    return convertNames(out, t, toAndroidX, count);
  }

  private static String convertCoordinates(String text, Table t, boolean toAndroidX, int[] count) {
    Matcher m = COORDINATE.matcher(text);
    StringBuilder out = null;
    int last = 0;
    while (m.find()) {
      String ga = m.group(1);
      String version = m.group(2);
      String replacement;
      if (toAndroidX) {
        Artifact a = t.byOld.get(ga);
        if (a == null) continue;
        replacement = a.newName + (version == null ? "" : ":" + a.baseVersion);
      } else {
        Artifact a = t.byNew.get(ga);
        if (a == null) continue;
        replacement = a.oldName + (version == null ? "" : ":" + supportVersion(a.oldName));
      }
      if (out == null) out = new StringBuilder(text.length() + 64);
      out.append(text, last, m.start()).append(replacement);
      last = m.end();
      count[0]++;
    }
    if (out == null) return text;
    return out.append(text, last, text.length()).toString();
  }

  /** إصدار صالح عند الرجوع إلى مكتبات الدعم. */
  static String supportVersion(String oldName) {
    if (oldName.startsWith("com.android.support:multidex")) return "1.0.3";
    return oldName.startsWith("com.android.support:") ? LAST_SUPPORT_VERSION : "+";
  }

  private static String convertNames(String text, Table t, boolean toAndroidX, int[] count) {
    Map<String, String> classes = toAndroidX ? t.classes : t.classesBack;
    Map<String, String> packages = toAndroidX ? t.packages : t.packagesBack;
    Set<String> roots = toAndroidX ? t.oldRoots : t.newRoots;
    if (classes.isEmpty() && packages.isEmpty()) return text;
    StringBuilder out = null;
    int last = 0;
    int n = text.length();
    int i = 0;
    while (i < n) {
      char c = text.charAt(i);
      if (!Character.isJavaIdentifierStart(c) || (i > 0 && isChainChar(text.charAt(i - 1)))) {
        i++;
        continue;
      }
      // سلسلة نقطية كاملة: a.b.C$D
      int end = i;
      int firstDot = -1;
      while (end < n) {
        char ch = text.charAt(end);
        if (Character.isJavaIdentifierPart(ch) && ch != '$') {
          end++;
        } else if ((ch == '.' || ch == '$') && end + 1 < n && Character.isJavaIdentifierStart(text.charAt(end + 1))) {
          if (firstDot < 0 && ch == '.') firstDot = end;
          end++;
        } else {
          break;
        }
      }
      if (firstDot < 0 || !roots.contains(text.substring(i, firstDot)) || (end < n && text.charAt(end) == ':')) {
        i = end;
        continue;
      }
      String chain = text.substring(i, end);
      String replacement = null;
      int matched = 0;
      for (int cut = chain.length(); cut > 0; cut = previousBoundary(chain, cut)) {
        String prefix = chain.substring(0, cut);
        String mapped = classes.get(prefix);
        if (mapped == null) mapped = packages.get(prefix);
        if (mapped != null) {
          replacement = mapped;
          matched = cut;
          break;
        }
      }
      if (replacement != null) {
        if (out == null) out = new StringBuilder(n + 64);
        out.append(text, last, i).append(replacement);
        last = i + matched;
        count[0]++;
      }
      i = end;
    }
    if (out == null) return text;
    return out.append(text, last, n).toString();
  }

  private static boolean isChainChar(char c) {
    return Character.isJavaIdentifierPart(c) || c == '.';
  }

  private static int previousBoundary(String chain, int cut) {
    for (int k = cut - 1; k > 0; k--) {
      char c = chain.charAt(k);
      if (c == '.' || c == '$') return k;
    }
    return 0;
  }

  /**
   * يحوّل المشروع كله: ملفات النص المعروفة (بلا build/.gradle/.git ولا bin بجوار المنيفست)،
   * ويكتب المتغيّر فقط ذرّيًا، ويضبط {@code android.useAndroidX} في gradle.properties.
   */
  public static Result convertProject(File root, boolean toAndroidX) throws IOException {
    long start = System.nanoTime();
    Result result = new Result();
    if (root == null || !root.isDirectory()) throw new IOException("project not found: " + root);
    walk(root, toAndroidX, result, 0);
    File properties = new File(root, "gradle.properties");
    String current = properties.isFile() ? readUtf8(properties) : null;
    String updated = withUseAndroidX(current, toAndroidX);
    if (updated != null && !updated.equals(current)) {
      writeAtomically(properties, updated);
      result.propertiesChanged = true;
      if (!result.changed.contains(properties)) {
        result.changed.add(properties);
        result.files++;
      }
    }
    result.millis = (System.nanoTime() - start) / 1_000_000L;
    return result;
  }

  private static void walk(File dir, boolean toAndroidX, Result result, int depth) throws IOException {
    if (depth > 40) return;
    File[] children = dir.listFiles();
    if (children == null) return;
    java.util.Arrays.sort(children);
    for (File child : children) {
      String name = child.getName();
      if (child.isDirectory()) {
        if (name.equals(".gradle") || name.equals(".git") || name.equals(".idea")) continue;
        if (name.equals("build") && (new File(dir, "build.gradle").isFile() || new File(dir, "build.gradle.kts").isFile())) continue;
        if (name.equals("bin") && new File(dir, "AndroidManifest.xml").isFile()) continue;
        if (Files.isSymbolicLink(child.toPath())) continue;
        walk(child, toAndroidX, result, depth + 1);
        continue;
      }
      int dot = name.lastIndexOf('.');
      String ext = dot < 0 ? "" : name.substring(dot + 1).toLowerCase(Locale.US);
      if (!TEXT_EXTENSIONS.contains(ext) || child.length() > MAX_FILE_BYTES) continue;
      String text;
      try {
        text = readUtf8(child);
      } catch (CharacterCodingException binary) {
        continue;
      }
      int[] count = {0};
      boolean gradle = ext.equals("gradle") || ext.equals("kts");
      String converted = convertText(text, toAndroidX, gradle, count);
      if (count[0] > 0 && !converted.equals(text)) {
        writeAtomically(child, converted);
        result.changed.add(child);
        result.files++;
        result.replacements += count[0];
      }
    }
  }

  /** نص gradle.properties بعد ضبط android.useAndroidX، أو null إن لم يلزم إنشاؤه. */
  static String withUseAndroidX(String text, boolean value) {
    String line = "android.useAndroidX=" + value;
    if (text == null) return value ? line + "\n" : null;
    Matcher m = Pattern.compile("(?m)^[ \\t]*android\\.useAndroidX[ \\t]*[=:].*$").matcher(text);
    if (m.find()) return text.substring(0, m.start()) + line + text.substring(m.end());
    if (!value) return text;
    return text + (text.isEmpty() || text.endsWith("\n") ? "" : "\n") + line + "\n";
  }

  static String readUtf8(File file) throws IOException {
    byte[] data;
    try (InputStream in = new FileInputStream(file)) {
      ByteArrayOutputStream buffer = new ByteArrayOutputStream((int) Math.min(file.length() + 16, MAX_FILE_BYTES + 16));
      byte[] chunk = new byte[1 << 15];
      int read;
      while ((read = in.read(chunk)) > 0) buffer.write(chunk, 0, read);
      data = buffer.toByteArray();
    }
    return StandardCharsets.UTF_8.newDecoder()
        .onMalformedInput(CodingErrorAction.REPORT)
        .onUnmappableCharacter(CodingErrorAction.REPORT)
        .decode(ByteBuffer.wrap(data))
        .toString();
  }

  static void writeAtomically(File file, String text) throws IOException {
    File temp = new File(file.getParentFile(), "." + file.getName() + ".shima-tmp");
    Files.write(temp.toPath(), text.getBytes(StandardCharsets.UTF_8));
    try {
      Files.move(temp.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
    } catch (IOException atomicUnsupported) {
      Files.move(temp.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING);
    } finally {
      if (temp.exists()) temp.delete();
    }
  }

  /** للاختبار: تفريغ الجدول ليُعاد تحميله من المصدر المثبَّت. */
  static void reset() {
    table = null;
  }

  /** عدد الأصناف والحزم والأدوات (للاختبار والتشخيص). */
  public static int[] sizes() {
    Table t = table();
    return new int[] {t.artifacts.size(), t.packages.size(), t.classes.size()};
  }
}
