package almlk;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * قراءةُ ما في ‏`AndroidManifest.xml` من معلوماتٍ تُبنى عليها المعرفةُ، لا البناءُ.
 *
 * <p>المرجعُ يلتقطُ المانيفستَ بموضعَيْه (‏`src/main/` للحديثِ وجذرُ الوحدةِ لتخطيطِ ADT
 * القديمِ) ويستخرجُ من وسمِهِ ‏`package=` اسمَ الحزمةِ التي تُبنى منها أسماءُ المولَّداتِ
 * وأسماءُ المكوّناتِ النسبيّةُ. لا ‏`aapt` عندَنا ولا ‏`R.java` على القرصِ، فالمطلوبُ من
 * هنا معلومةٌ صافيةٌ: أينَ الملفُّ، وما حزمتُهُ، وما مكوّناتُهُ محمولةً على حزمَتِها.
 *
 * <p>مسحٌ حرفيٌّ بلا أنماطٍ نظاميّةٍ: يقبلُ الاقتباسَينِ والسطرَ الواحدَ أو المتعدّدَ
 * للوسمِ الافتتاحيِّ، ولا يقرأُ من قرصٍ — النصُّ يُسلَّمُ إليهِ. ولا يلمسُ ‏`build/` أبدًا:
 * نُسخُ ‏`injected/` و‏`merged/` مخرجاتُ بناءٍ، لا مصادرُ.
 */
public final class AndroidManifestModel {

  /** سقفُ نصٍّ يُقرأُ من ملفٍ واحدٍ — كبقيةِ الطبقةِ الصافيةِ. */
  public static final int MAX_TEXT_BYTES = 512 * 1024;
  /** سقفُ المكوّناتِ الملتقَطةِ في مانيفستٍ واحدٍ. */
  public static final int MAX_COMPONENTS = 256;

  /** مكوّنٌ مُعلَنٌ في المانيفستِ: اسمُهُ كما كُتِبَ، وسطرُهُ، وهل هو نسبيٌّ. */
  public static final class Component {
    /** الوسمُ الحاملُ: ‏`activity` و‏`service` و… */
    public final String tag;
    /** الاسمُ كما كُتِبَ (قد يبدأُ بنقطةٍ أو يكونُ مطلقًا). */
    public final String name;
    /** سطرُ الخاصّةِ من 1؛ 1 حينَ لا سطرَ معروفَ. */
    public final int line;
    /** ‏`true` إن كانَ نسبيًّا (نقطةٌ بدايةً، أو اسمٌ بسيطٌ بلا نقطةٍ). */
    public final boolean relative;

    Component(String tag, String name, int line, boolean relative) {
      this.tag = tag == null ? "" : tag;
      this.name = name == null ? "" : name;
      this.line = Math.max(1, line);
      this.relative = relative;
    }

    @Override
    public String toString() {
      return tag + " " + name + ":" + line;
    }
  }

  private AndroidManifestModel() {}

  /**
   * ملفُّ مانيفستِ وحدةٍ: ‏`src/main/AndroidManifest.xml` أولًا (التخطيطُ الحديثُ، بهِ
   * يُنشئُ مشروعُنا وحداتِهِ)، ثمَّ جذرُ الوحدةِ (تخطيطُ ADT القديمُ الذي يقرؤُهُ المرجعُ).
   * الموجودُ فقط؛ ولا ‏`build/` ولا مواضعَ أُخرى خارجَ هذينِ — ما عدا ذلكَ إمّا مخرَجُ
   * بناءٍ أو ملفٌّ لا يُنتِجُ حزمةً، فلا تُقرَأُ نُسخُ ‏`injected/` ولا ‏`merged/`.
   */
  public static File find(File moduleDir) {
    return find(moduleDir, null);
  }

  /**
   * الموضعُ المُعلَنُ (‏`manifest.srcFile = file('Weird.xml')`) يُقدَّمُ على العُرفَيْنِ: ما
   * يقولُ المشروعُ إنَّهُ مانيفستُهُ يُصدَّقُ، وإن لم يكنْ موجودًا رجعنا إلى العُرفِ — لا
   * اختراعَ لمسارٍ لا ملفَّ فيهِ.
   */
  public static File find(File moduleDir, String declaredSrcFile) {
    if (moduleDir == null || !moduleDir.isDirectory()) return null;
    if (declaredSrcFile != null && !declaredSrcFile.isEmpty()) {
      File declared = declaredSrcFile.charAt(0) == '/'
          ? new File(declaredSrcFile) : new File(moduleDir, declaredSrcFile);
      if (declared.isFile()) return declared;
    }
    File modern = new File(new File(new File(moduleDir, "src"), "main"), "AndroidManifest.xml");
    if (modern.isFile()) return modern;
    File legacy = new File(moduleDir, "AndroidManifest.xml");
    return legacy.isFile() ? legacy : null;
  }

  /**
   * حزمةُ المانيفستِ من ‏`package=` في وسمِهِ الافتتاحيِّ، أو {@code ""}. تُقبَلُ
   * الاقتباساتُ المفردةُ والمزدوجةُ، والقيمةَ غيرُ القانونيّةٍ (فاصلٌ فارغٌ أو رقمٌ بادئٌ)
   * تُهمَلُ كمن لم يكنْ — لا تُبنى حزمةٌ على نصٍّ لا يُحمَلُ.
   */
  public static String packageOf(String manifestText) {
    String raw = attributeInOpenTag(manifestText, "manifest", "package");
    return isPackage(raw) ? raw : "";
  }

  /**
   * مكوّناتُ المانيفستِ على ترتيبِ ورودِهِ: لكلِّ وسمٍ من وسومِ المكوّناتِ اسمُ
   * ‏`android:name` المصحوبُ بسطرِهِ، ونسبيّتُهُ محسوبةٌ من كتابتِهِ لا من طوله.
   */
  public static List<Component> componentsOf(String manifestText) {
    if (manifestText == null || manifestText.isEmpty()) return Collections.emptyList();
    ArrayList<Component> out = new ArrayList<>();
    int line = 1;
    int at = 0;
    while (at < manifestText.length() && out.size() < MAX_COMPONENTS) {
      int lt = manifestText.indexOf('<', at);
      if (lt < 0) break;
      line += newlinesBetween(manifestText, at, lt);
      // تعليقٌ: ما داخلَهُ غيرُ مُعلَنِ — مكوّنٌ معطَّلٌ بالتعليقِ لا يُطالَبُ بصنفِهِ
      if (manifestText.startsWith("<!--", lt)) {
        int closed = manifestText.indexOf("-->", lt + 4);
        if (closed < 0) break;
        line += newlinesBetween(manifestText, lt, closed + 3);
        at = closed + 3;
        continue;
      }
      int name0 = lt + 1;
      if (name0 < manifestText.length() && manifestText.charAt(name0) == '/') {
        at = lt + 1;
        continue;
      }
      int nameEnd = name0;
      while (nameEnd < manifestText.length() && isTagChar(manifestText.charAt(nameEnd))) nameEnd++;
      String tag = manifestText.substring(name0, nameEnd);
      int gt = tagEnd(manifestText, nameEnd);
      if (gt < 0) break;
      if (!isComponentTag(tag)) {
        line += newlinesBetween(manifestText, lt, gt);
        at = gt + 1;
        continue;
      }
      String openTag = manifestText.substring(nameEnd, gt);
      int colon = tag.indexOf(':');
      String bare = colon < 0 ? tag : tag.substring(colon + 1);
      String value = attributeValue(openTag, "name");
      if (value != null && !value.isEmpty()) {
        // السطرُ سطرُ بدايةِ الوسمِ: لا دقّةً مُختَرَعةً داخلَ وسمٍ قد يتعدّدُ سطرُهُ
        out.add(new Component(bare, value, line, isRelativeName(value)));
      }
      line += newlinesBetween(manifestText, nameEnd, gt);
      at = gt + 1;
    }
    return out;
  }

  /**
   * الاسمُ كما سيراهُ المُترجِمُ: ‏`.X` و‏`X` يُنسبانِ إلى حزمةِ المانيفستِ (كذاکَ يفعلُ
   * منشئُ الحِزمةِ في المرجعِ)، والمطلقُ كما هو؛ وبلا حزمةٍ لا اختراعَ — يُعادُ الاسمُ
   * الأصليُّ ليُخبَرَ عنهُ لا ليُقدَّرَ لهُ.
   */
  public static String resolve(String name, String manifestPackage) {
    if (name == null || name.isEmpty()) return "";
    if (manifestPackage == null || manifestPackage.isEmpty()) return name;
    if (name.charAt(0) == '.') return manifestPackage + name;
    if (name.indexOf('.') < 0) return manifestPackage + "." + name;
    return name;
  }

  /**
   * أسماءُ ‏`${…}` في النصِّ لم تُحَلَّ بـ‏{@code values} (وسيطُ ‏`provider` مثلًا):
   * تُعادُ بالترتيبِ وبلا تكرارٍ، ليُخبَرَ المستخدمُ باسمِ الناقصِ لا بخطأٍ مبهمٍ.
   */
  public static List<String> unresolvedPlaceholders(String text, Map<String, String> values) {
    ArrayList<String> out = new ArrayList<>();
    if (text == null || text.isEmpty()) return out;
    int at = 0;
    while (at < text.length()) {
      int open = text.indexOf("${", at);
      if (open < 0) break;
      int close = text.indexOf('}', open + 2);
      if (close < 0) break;
      String key = text.substring(open + 2, close);
      if (isKey(key) && (values == null || !values.containsKey(key) || values.get(key) == null)) {
        if (!out.contains(key)) out.add(key);
      }
      at = close + 1;
    }
    return out;
  }

  // ═══════════════ المِسحُ الحرفيُّ ═══════════════

  /** قيمةُ خاصيّةٍ داخلَ وسمٍ افتتاحيٍّ باسمٍ معلومٍ (كلا الاقتباسينِ)، أو {@code null}. */
  private static String attributeInOpenTag(String text, String tag, String attribute) {
    if (text == null || text.isEmpty()) return null;
    int at = 0;
    while (at < text.length()) {
      int lt = text.indexOf('<', at);
      if (lt < 0) return null;
      int name0 = lt + 1;
      int nameEnd = name0;
      while (nameEnd < text.length() && isTagChar(text.charAt(nameEnd))) nameEnd++;
      String found = text.substring(name0, nameEnd);
      int gt = tagEnd(text, nameEnd);
      if (gt < 0) return null;
      if (found.equals(tag)) return attributeValue(text.substring(nameEnd, gt), attribute);
      at = gt + 1;
    }
    return null;
  }

  /** قراءةُ ‏`name="قيمة"` أو ‏`name='قيمة'` من مقطعِ وسْمٍ — بلا أنماطٍ. */
  private static String attributeValue(String openTag, String attribute) {
    if (openTag == null || openTag.isEmpty()) return null;
    int from = 0;
    while (true) {
      int at = indexOfAttribute(openTag, attribute, from);
      if (at < 0) return null;
      int i = at + attribute.length();
      while (i < openTag.length() && (Character.isWhitespace(openTag.charAt(i)) || openTag.charAt(i) == '\n')) i++;
      if (i >= openTag.length() || openTag.charAt(i) != '=') {
        from = at + attribute.length();
        continue;
      }
      i++;
      while (i < openTag.length() && (Character.isWhitespace(openTag.charAt(i)) || openTag.charAt(i) == '\n')) i++;
      if (i >= openTag.length()) return null;
      char quote = openTag.charAt(i);
      if (quote != '"' && quote != '\'') return null;
      int close = openTag.indexOf(quote, i + 1);
      if (close < 0) return null;
      return openTag.substring(i + 1, close);
    }
  }

  /** موضعُ اسمِ الخاصيّةِ: لا ذيلًا لاسمٍ آخرَ، ولا موصولًا بنقاطِ مساحةِ الاسمِ. */
  private static int indexOfAttribute(String openTag, String attribute, int from) {
    int at = openTag.indexOf(attribute, from);
    while (at >= 0) {
      // ما قبلَ الاسمِ: حرفُ هجاءٍ = ذيلُ اسمٍ آخرَ (displayName) ← مرفوضٌ؛
      // ونقاطةٌ = بادئةُ مساحةِ أسماءٍ (android:name) ← مقبولٌ، وهي الصيغةُ الشائعةُ.
      boolean leftOk = at == 0 || !Character.isJavaIdentifierPart(openTag.charAt(at - 1));
      int after = at + attribute.length();
      boolean rightOk = after >= openTag.length()
          || Character.isWhitespace(openTag.charAt(after)) || openTag.charAt(after) == '\n'
          || openTag.charAt(after) == '=';
      if (leftOk && rightOk) return at;
      at = openTag.indexOf(attribute, at + attribute.length());
    }
    return -1;
  }

  /** نهايةُ الوسمِ الافتتاحيِّ، متجاهلًا ‏`>` داخلَ قيمةٍ مُقتبَسةٍ. */
  private static int tagEnd(String text, int from) {
    char quote = 0;
    for (int i = from; i < text.length(); i++) {
      char c = text.charAt(i);
      if (quote != 0) {
        if (c == quote) quote = 0;
      } else if (c == '"' || c == '\'') {
        quote = c;
      } else if (c == '>') {
        return i;
      }
    }
    return -1;
  }

  private static int newlinesBetween(String text, int from, int to) {
    int n = 0;
    for (int i = Math.max(0, from); i < Math.min(to, text.length()); i++) if (text.charAt(i) == '\n') n++;
    return n;
  }

  private static boolean isComponentTag(String tag) {
    int colon = tag.lastIndexOf(':');
    String bare = colon < 0 ? tag : tag.substring(colon + 1);
    return bare.equals("application") || bare.equals("activity") || bare.equals("service")
        || bare.equals("receiver") || bare.equals("provider") || bare.equals("instrumentation")
        || bare.equals("activity-alias");
  }

  /** اسمٌ نسبيٌّ: نقطةٌ بدايةً، أو اسمٌ بسيطٌ بلا نقطةٍ — ولا واحدَ منهما يُبنى عليهِ تخمينٌ. */
  private static boolean isRelativeName(String name) {
    return !name.isEmpty() && (name.charAt(0) == '.' || name.indexOf('.') < 0);
  }

  private static boolean isKey(String key) {
    if (key == null || key.isEmpty() || key.indexOf(' ') >= 0) return false;
    for (int i = 0; i < key.length(); i++) {
      char c = key.charAt(i);
      if (!Character.isJavaIdentifierPart(c) && c != '.' && c != '-') return false;
    }
    return true;
  }

  /** اسمُ حزمةٍ: فواصلُ غيرُ فارغةٍ، لا رقمٌ بادئًا، ولا حرفٌ غيرُ قانونيٍّ. */
  static boolean isPackage(String value) {
    if (value == null || value.isEmpty() || value.charAt(0) == '.') return false;
    int segment = 0;
    for (int i = 0; i < value.length(); i++) {
      char c = value.charAt(i);
      if (c == '.') {
        if (i == 0 || value.charAt(i - 1) == '.' || i + 1 >= value.length()) return false;
        segment = 0;
        continue;
      }
      if (segment == 0) {
        if (!Character.isJavaIdentifierStart(c)) return false;
        segment = 1;
      } else if (!Character.isJavaIdentifierPart(c)) {
        return false;
      }
    }
    return value.indexOf('.') > 0 || Character.isJavaIdentifierStart(value.charAt(0));
  }

  private static boolean isTagChar(char c) {
    return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9')
        || c == '_' || c == '-' || c == '.' || c == ':';
  }
}
