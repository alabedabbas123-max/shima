package almlk;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.view.ActionMode;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import com.shima.demo.UiStrings;

/**
 * بند almlk ← طبقة «OEditor»: الإدخال والتحرير فوق لوحة الرسم {@link CodeCanvasView}.
 *
 * <p>الأساليب المنقولة (بكودنا الخاص):
 *
 * <ul>
 *   <li>InputConnection مخصص (commit/delete/Enter بمسافة بادئة ذكية) كما في OEditor.onCreateInputConnection.
 *   <li>مفاتيح العتاد: أسهم تحرّك بالمؤشر، Shift+أسهم يمدّد التحديد، Delete/Enter عبر الأحداث.
 *   <li>تراجع/إعادة مدمجان بالموديل ({@link UndoRedoStack}) — لا مسار خارجي موازٍ.
 *   <li>قائمة التحديد (Cut/Copy/Paste/Select All) عند دخول وضع التحديد — مع نقطة ربط لعناصر
 *       مخصصة من المضيف (الانتقال/الاستخدامات...) عبر {@link #setActionModeContributor}.
 *   <li>إظهار الكيبورد عند نقر النص كسلوك محرر AIDE.
 * </ul>
 */
public class CodeEditorView extends CodeCanvasView {

  /** مستمع تغييرات النص بمستوى الاستبدالات — تنقل أحداث التحرير للواجهة (TextWatcher مكافئ). */
  public interface ReplacementListener {
    /**
     * بعد كل استبدال فعلي: start=الإزاحة، removedCount=ما خرج، insertedCount=ما دخل.
     * قبل الإشعار مباشرة كانت removed تملأ [start,start+removedCount).
     */
    void onTextReplaced(int start, int removedCount, int insertedCount);
  }

  /** مساهم خارجي بعناصر إضافية في قائمة وضع التحديد. */
  public interface ActionModeContributor {
    void onCreateMenu(ActionMode mode, Menu menu);

    /** يعيد true عندما تغيرت خصائص عناصر القائمة الحية. */
    default boolean onPrepareMenu(ActionMode mode, Menu menu) {
      return false;
    }

    boolean onMenuItem(ActionMode mode, MenuItem item);

    void onDestroy(ActionMode mode);
  }

  /** معرفات عناصر قائمة التحديد المدمجة — عامة ليعيد المضيف تصميمها كأيقونات تولبار. */
  public static final int ID_CUT = 0xA10001;
  public static final int ID_COPY = 0xA10002;
  public static final int ID_PASTE = 0xA10003;
  public static final int ID_SELECT_ALL = 0xA10004;

  private final UndoRedoStack history = new UndoRedoStack();
  private ReplacementListener replacementListener;
  private ActionModeContributor actionModeContributor;
  private ActionMode selectionActionMode;
  private final ClipboardManager.OnPrimaryClipChangedListener clipboardStateListener =
      () -> {
        if (selectionActionMode != null) selectionActionMode.invalidate();
      };
  private boolean muted; // أثناء undo/redo لا نسجل التاريخ

  public CodeEditorView(Context context) {
    super(context);
    setInteractionListener(
        new InteractionListener() {
          @Override
          public void onSelectionModeChanged(boolean active) {
            // القائمة تنبثق فقط لتحديد لمسي فعلي (مثل نظام أندرويد لا تفتح CAB برمجيًا
            // ولا فارغًا) — بحث/انتقال/setSelection البرمجية لا تُخرجها.
            if (active && hasSelection() && selectionFromTouch) startSelectionActionMode();
            else if (!active && selectionActionMode != null) selectionActionMode.finish();
            if (active && selectionActionMode != null) selectionActionMode.invalidate();
          }

          @Override
          public void onContentScrolled(int x, int y) {
            onEditorScrolledExternal(x, y);
          }

          @Override
          public void onTextSizeChanged(float textSizePixels) {
            onEditorZoomedExternal(textSizePixels);
          }

          @Override
          public void onShowKeyboardRequested() {
            showSoftKeyboard();
          }

          @Override
          public void onCaretRepositioned() {
            if (selectionActionMode != null) selectionActionMode.invalidate();
          }

          @Override
          public void onShowSelectionActionsRequested() {
            startSelectionActionMode();
          }
        });
  }

  public void setReplacementListener(ReplacementListener listener) {
    replacementListener = listener;
  }

  /** hook محمي: يبث التمرير الخارجي للواجهات المضيفة (الـPager). */
  protected void onEditorScrolledExternal(int x, int y) {}

  /** hook محمي: يبث حجم الخط الجديد بعد التكبير. */
  protected void onEditorZoomedExternal(float textSizePixels) {}


  public void setActionModeContributor(ActionModeContributor contributor) {
    actionModeContributor = contributor;
  }

  /** يعيد بناء شريط «تحديد الإجراءات» المفتوح (مثلًا عند وصول إصلاحات جديدة للتشخيص). */
  public void invalidateSelectionActions() {
    if (selectionActionMode != null) selectionActionMode.invalidate();
  }

  // ---------------- التحرير بالإزاحات (الجوهر) ----------------

  /**
   * استبدال [start,end) بالنص + تسجيل التراجع + تحريك المؤشر — نقطة الدخول الوحيدة للتحرير.
   * سياسةُ المؤشّرِ الافتراضيّةُ هي سياسةُ الكتابةِ: المؤشّرُ يلحقُ المُدخَلَ ويُكشفُ (IME/الاقتراحُ).
   */
  public final int replaceRange(int start, int end, String text) {
    return replaceRange(start, end, text, false);
  }

  /**
   * الاستبدالُ نفسُه بسياسةِ الإصلاحِ (preserveCaret=true): مسارٌ واحدٌ وكلامٌ آخرُ بعدَ الكتابةِ —
   * المؤشّرُ والتحديدُ يُزاحانِ مع نصّهما، والمنظرُ يُعوَّضُ عن الأسطرِ الزائدةِ فوقَه، ولا كشفَ
   * ولا انتقالَ. منه تُطبَّقُ إصلاحاتُ التشخيصِ (إضافةُ استيرادٍ، إنشاءُ عضوٍ، تنظيمُ الاستيراداتِ)
   * فلا يقفزُ المحرّرُ إلى رأسِ الملفِّ حينَ لا يريدُ المستخدمُ سوى النصِّ الصحيحِ.
   */
  public final int replaceRange(int start, int end, String text, boolean preserveCaret) {
    int from = Math.max(0, Math.min(start, document.length()));
    int to = Math.max(from, Math.min(end, document.length()));
    String inserted = text == null ? "" : text;
    String removed;
    synchronized (document) {
      removed = document.subText(from, to);
      // المؤشّرُ والمرساةُ بالإزاحةِ القديمةِ تُلتَقَطانِ قبلَ الزرْعِ: لا يُشتَقُّ موضعٌ محفوظٌ من
      // سطرٍ/عمودٍ بعدَ أن قصَّهُ المستندُ على عددِ أسطرِهِ الجديدِ.
      int caretOffsetBefore = document.offsetFor(caretLine, caretColumn);
      int anchorOffsetBefore = selectionAnchorOffset();
      int caretOffset = document.replace(from, to, inserted);
      if (!muted) history.record(from, removed, inserted);
      if (preserveCaret) {
        preserveViewAcrossEdit(
            from,
            to,
            inserted.length(),
            removed.length(),
            countNewlines(inserted),
            countNewlines(removed),
            caretOffsetBefore,
            anchorOffsetBefore);
      } else {
        int caretLine = document.lineForOffset(caretOffset);
        setCaret(caretLine, caretOffset - document.lineStartOffset(caretLine));
      }
    }
    if (replacementListener != null)
      replacementListener.onTextReplaced(from, removed.length(), inserted.length());
    return from + inserted.length();
  }

  public boolean undo() {
    UndoRedoStack.Applied op = history.popUndo();
    if (op == null) return false;
    muted = true;
    try {
      // عكس العملية: أزل المُدخَل وأعد المحذوف.
      replaceRange(op.start, op.start + op.inserted.length(), op.removed);
    } finally {
      muted = false;
    }
    return true;
  }

  public boolean redo() {
    UndoRedoStack.Applied op = history.popRedo();
    if (op == null) return false;
    muted = true;
    try {
      replaceRange(op.start, op.start + op.removed.length(), op.inserted);
    } finally {
      muted = false;
    }
    return true;
  }

  public boolean canUndo() {
    return history.canUndo();
  }

  public boolean canRedo() {
    return history.canRedo();
  }

  public void clearHistory() {
    history.clear();
  }

  // ---------------- الإدخال: IME ----------------

  @Override
  public boolean onCheckIsTextEditor() {
    return true;
  }

  @Override
  public InputConnection onCreateInputConnection(EditorInfo outAttrs) {
    outAttrs.inputType =
        android.text.InputType.TYPE_CLASS_TEXT
            | android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE
            | android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            | android.text.InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD;
    outAttrs.imeOptions =
        EditorInfo.IME_FLAG_NO_EXTRACT_UI
            | EditorInfo.IME_FLAG_NO_ENTER_ACTION
            | EditorInfo.IME_ACTION_NONE;
    return new CodeInputConnection(this);
  }

  public void showSoftKeyboard() {
    requestFocus();
    InputMethodManager imm =
        (InputMethodManager) getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
    if (imm != null) {
      imm.viewClicked(this);
      imm.showSoftInput(this, InputMethodManager.SHOW_IMPLICIT);
    }
  }

  public void hideSoftKeyboard() {
    InputMethodManager imm =
        (InputMethodManager) getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
    if (imm != null) imm.hideSoftInputFromWindow(getWindowToken(), 0);
  }

  /** نص مُدخَل من الكيبورد/اللصق/الإكمال: يستبدل التحديد (أو يُدرج عند المؤشر). */
  public final void commitInput(String text) {
    int[] sel = selectionOffsets();
    replaceRange(sel[0], sel[1], text);
    exitSelectionMode();
  }

  /** حذف قبل/بعد المؤشر (Backspace/Delete من الكيبورد). */
  public final void deleteSurrounding(int before, int after) {
    int[] sel = selectionOffsets();
    if (sel[0] != sel[1]) {
      replaceRange(sel[0], sel[1], "");
      exitSelectionMode();
      return;
    }
    int length = document.length();
    int from = Math.max(0, sel[0] - before);
    int to = Math.min(length, sel[1] + after);
    if (to > from) replaceRange(from, to, "");
  }

  /** إزاحات التحديد المرتبة [بداية، نهاية] — أو المؤشر مرتين. */
  public final int[] selectionOffsets() {
    int[] ordered = orderedSelection();
    int start = document.offsetFor(ordered[0], ordered[1]);
    int end = document.offsetFor(ordered[2], ordered[3]);
    return new int[] {start, end};
  }

  /** Enter بمسافة بادئة ذكية (أسلوب OEditor): نسخ بادئة السطر + وحدة إضافية بعد '{'. */
  /** المرحلة 1: مفتاح Tab يُدرج مسافات أو \t وفق إعدادات المستخدم. */
  public final void insertTabOrSpaces() {
    if (almlk.AppSettings.useSpacesForTabs(getContext())) {
      int width = almlk.AppSettings.tabSize(getContext());
      StringBuilder spaces = new StringBuilder();
      for (int i = 0; i < width; i++) spaces.append(' ');
      commitInput(spaces.toString());
    } else {
      commitInput("\t");
    }
  }

  public final void newlineWithIndent() {
    int[] sel = selectionOffsets();
    int caretOffset = sel[0] == sel[1] ? document.offsetFor(caretLine(), caretColumn()) : -1;
    if (caretOffset < 0) {
      commitInput("\n");
      return;
    }
    String lineText;
    synchronized (document) {
      lineText = document.line(caretLine()).toString();
    }
    StringBuilder indent = new StringBuilder("\n");
    int i = 0;
    while (i < lineText.length()
        && (lineText.charAt(i) == ' ' || lineText.charAt(i) == '\t')) {
      indent.append(lineText.charAt(i));
      i++;
    }
    // سياق فوري: حرف قبل المؤشر { ← بادئة إضافية، وإن كان } بعده مباشرة افتح السطر الأوسط.
    boolean openBrace = caretColumn() > 0
        && caretColumn() <= lineText.length()
        && lineText.charAt(caretColumn() - 1) == '{';
    boolean closeFollows = caretColumn() < lineText.length()
        && lineText.charAt(caretColumn()) == '}';
    if (openBrace) indent.append("    ");
    if (openBrace && closeFollows) {
      String mid = indent.toString();
      StringBuilder tail = new StringBuilder("\n");
      i = 0;
      while (i < lineText.length()
          && (lineText.charAt(i) == ' ' || lineText.charAt(i) == '\t')) {
        tail.append(lineText.charAt(i));
        i++;
      }
      tail.append('}');
      int insertAt = document.offsetFor(caretLine(), caretColumn());
      // { | } → {\n<بادئة+وحدة>\n<بادئة>} والمؤشر في نهاية السطر الأوسط.
      replaceRange(insertAt, insertAt + 1, mid + tail);
      int target = insertAt + mid.length();
      int targetLine = document.lineForOffset(target);
      setCaret(targetLine, target - document.lineStartOffset(targetLine));
    } else {
      String insertion = indent.toString();
      replaceRange(sel[0], sel[1], insertion);
    }
    exitSelectionMode();
  }

  // ---------------- مفاتيح العتاد ----------------

  @Override
  public boolean onKeyDown(int keyCode, KeyEvent event) {
    boolean shift = (event.getMetaState() & KeyEvent.META_SHIFT_ON) != 0;
    switch (keyCode) {
      case KeyEvent.KEYCODE_DPAD_LEFT:
        moveCaretHorizontally(-1, shift);
        return true;
      case KeyEvent.KEYCODE_DPAD_RIGHT:
        moveCaretHorizontally(1, shift);
        return true;
      case KeyEvent.KEYCODE_DPAD_UP:
        moveCaretVertically(-1, shift);
        return true;
      case KeyEvent.KEYCODE_DPAD_DOWN:
        moveCaretVertically(1, shift);
        return true;
      case KeyEvent.KEYCODE_MOVE_HOME:
        if (shift) setCaretExtendingSelection(caretLine(), 0);
        else setCaret(caretLine(), 0);
        return true;
      case KeyEvent.KEYCODE_MOVE_END:
        if (shift) setCaretExtendingSelection(caretLine(), document.lineLength(caretLine()));
        else setCaret(caretLine(), document.lineLength(caretLine()));
        return true;
      case KeyEvent.KEYCODE_DEL:
        deleteSurrounding(1, 0);
        return true;
      case KeyEvent.KEYCODE_FORWARD_DEL:
        deleteSurrounding(0, 1);
        return true;
      case KeyEvent.KEYCODE_ENTER:
        newlineWithIndent();
        return true;
      case KeyEvent.KEYCODE_TAB:
        insertTabOrSpaces();
        return true;
      case KeyEvent.KEYCODE_A:
        if (event.isCtrlPressed()) {
          selectAll();
          return true;
        }
        break;
      case KeyEvent.KEYCODE_C:
        if (event.isCtrlPressed() && hasSelection()) {
          copySelection();
          return true;
        }
        break;
      case KeyEvent.KEYCODE_X:
        if (event.isCtrlPressed() && hasSelection()) {
          cutSelection();
          return true;
        }
        break;
      case KeyEvent.KEYCODE_V:
        if (event.isCtrlPressed()) {
          pasteClipboard();
          return true;
        }
        break;
      case KeyEvent.KEYCODE_Z:
        if (event.isCtrlPressed()) {
          if (event.isShiftPressed()) redo();
          else undo();
          return true;
        }
        break;
      case KeyEvent.KEYCODE_Y:
        if (event.isCtrlPressed()) {
          redo();
          return true;
        }
        break;
      default:
        break;
    }
    // W8: أيُّ مفتاحٍ يحمل حرفًا مطبوعًا (صفُّ الأرقام في التخطيط العربي، اللوحةُ العتادية، الرموز) كان
    // يسقط صامتًا لأن هذا العارضَ ليس TextView ولا أحدَ يترجم الحدثَ إلى نصّ. القرارُ في
    // EditorKeyInput: إدخالٌ إن كان حرفًا مطبوعًا بلا ctrl/alt وبالخارجِ عن مفاتيح التنقّل والحذف.
    char typed = (char) event.getUnicodeChar(event.getMetaState());
    if (almlk.EditorKeyInput.shouldCommitChar(keyCode, event.isCtrlPressed(), event.isAltPressed(),
        typed)) {
      commitInput(String.valueOf(typed));
      return true;
    }
    return super.onKeyDown(keyCode, event);
  }

  private void moveCaretHorizontally(int delta, boolean extend) {
    int line = caretLine(), column = caretColumn();
    if (delta < 0) {
      if (column > 0) column--;
      else if (line > 0) {
        line--;
        column = document.lineLength(line);
      }
    } else {
      if (column < document.lineLength(line)) column++;
      else if (line < document.lineCount() - 1) {
        line++;
        column = 0;
      }
    }
    if (extend) {
      enterSelectionMode();
      setCaretExtendingSelection(line, column);
    } else {
      setCaret(line, column);
    }
    exitSelectionModeIfCollapsed();
  }

  private void moveCaretVertically(int delta, boolean extend) {
    int targetLine =
        Math.max(0, Math.min(caretLine() + delta, document.lineCount() - 1));
    int column = Math.max(0, Math.min(caretColumn(), document.lineLength(targetLine)));
    if (extend) {
      enterSelectionMode();
      setCaretExtendingSelection(targetLine, column);
    } else {
      setCaret(targetLine, column);
    }
    exitSelectionModeIfCollapsed();
  }

  private void exitSelectionModeIfCollapsed() {
    if (!hasSelection() && inSelectionMode()) exitSelectionMode();
  }

  // ---------------- الحافظة وقائمة وضع التحديد ----------------

  public final String selectedText() {
    int[] sel = selectionOffsets();
    return sel[0] == sel[1] ? "" : document.subText(sel[0], sel[1]);
  }

  /** أهلية لصق حية لشريط ActionMode؛ لا تقرأ الحافظة الواجهة بمسار موازٍ. */
  public final boolean hasClipboardText() {
    ClipboardManager clipboard =
        (ClipboardManager) getContext().getSystemService(Context.CLIPBOARD_SERVICE);
    if (clipboard == null || !clipboard.hasPrimaryClip()) return false;
    ClipData clip = clipboard.getPrimaryClip();
    if (clip == null || clip.getItemCount() == 0) return false;
    CharSequence text = clip.getItemAt(0).coerceToText(getContext());
    return text != null && text.length() > 0;
  }

  /** يمرّر إزاحة إلى المرئي دون تحريك المؤشر (مكافئ TextView.bringPointIntoView للبحث/الانتقال). */
  public boolean scrollOffsetIntoView(int offset) {
    int clamped = Math.max(0, Math.min(offset, document.length()));
    int line = document.lineForOffset(clamped);
    int column = clamped - document.lineStartOffset(line);
    float pointX = columnToContentX(line, column);
    float lineTop = line * lineStride();
    float lineBottom = lineTop + lineStride();
    int newX = getScrollX(), newY = getScrollY();
    float margin = lineStride() * 2;
    if (lineTop < getScrollY() + margin)
      newY = (int) Math.max(0, lineTop - margin);
    else if (lineBottom > getScrollY() + getHeight() - margin)
      newY = (int) Math.min(contentHeightForScroll() - getHeight(), lineBottom - getHeight() + margin);
    float viewX = pointX - getScrollX();
    if (viewX < gutterWidth() + dp(16)) newX = (int) Math.max(0, pointX - gutterWidth() - dp(16));
    else if (viewX > getWidth() - dp(24)) newX = (int) Math.max(0, pointX - getWidth() + dp(48));
    if (newX != getScrollX() || newY != getScrollY()) {
      scrollTo(newX, newY);
      return true;
    }
    return false;
  }

  private float contentHeightForScroll() {
    return document.lineCount() * lineStride() + dp(12);
  }

  public final void cutSelection() {
    if (!hasSelection()) return;
    copySelection();
    int[] sel = selectionOffsets();
    replaceRange(sel[0], sel[1], "");
    exitSelectionMode();
  }

  public final void copySelection() {
    if (!hasSelection()) return;
    ClipboardManager clipboard =
        (ClipboardManager) getContext().getSystemService(Context.CLIPBOARD_SERVICE);
    if (clipboard != null) clipboard.setPrimaryClip(ClipData.newPlainText("code", selectedText()));
  }

  public final void pasteClipboard() {
    ClipboardManager clipboard =
        (ClipboardManager) getContext().getSystemService(Context.CLIPBOARD_SERVICE);
    if (clipboard == null || !clipboard.hasPrimaryClip()) return;
    ClipData clip = clipboard.getPrimaryClip();
    if (clip == null || clip.getItemCount() == 0) return;
    CharSequence text = clip.getItemAt(0).coerceToText(getContext());
    if (text != null && text.length() > 0) commitInput(text.toString());
  }

  /**
   * يفتح شريط «تحديد الإجراءات» على تحديد برمجي قائم — للمسارات التي تحدد نيابة عن المستخدم ثم
   * تطلب الإجراءات صراحة (الضغط المطوّل على صف خطأ في اللوحة كما في المرجع).
   */
  public void showSelectionActions() {
    if (hasSelection()) startSelectionActionMode();
  }

  private void startSelectionActionMode() {
    if (selectionActionMode != null) return;
    selectionActionMode =
        startActionMode(
            new ActionMode.Callback() {
              @Override
              public boolean onCreateActionMode(ActionMode mode, Menu menu) {
                // الترتيب يطابق تولبار المرجع: توسيع(0) قص(1) نسخ(2) لصق(3) ثم القائمة الفائضة.
                menu.add(0, ID_CUT, 1, UiStrings.get(getContext(), "command_cut"))
                    .setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER);
                menu.add(0, ID_COPY, 2, UiStrings.get(getContext(), "command_copy"))
                    .setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER);
                menu.add(0, ID_PASTE, 3, UiStrings.get(getContext(), "command_paste"))
                    .setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER);
                menu.add(0, ID_SELECT_ALL, 10, UiStrings.get(getContext(), "keybind_select_all"))
                    .setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER);
                ActionModeContributor contributor = actionModeContributor;
                if (contributor != null) contributor.onCreateMenu(mode, menu);
                return true;
              }

              @Override
              public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
                boolean selection = hasSelection();
                MenuItem cut = menu.findItem(ID_CUT);
                MenuItem copy = menu.findItem(ID_COPY);
                MenuItem paste = menu.findItem(ID_PASTE);
                MenuItem selectAll = menu.findItem(ID_SELECT_ALL);
                if (cut != null) cut.setEnabled(selection);
                if (copy != null) copy.setEnabled(selection);
                if (paste != null) paste.setEnabled(hasClipboardText());
                if (selectAll != null) selectAll.setEnabled(document.length() > 0);
                ActionModeContributor contributor = actionModeContributor;
                if (contributor != null) contributor.onPrepareMenu(mode, menu);
                return true;
              }

              @Override
              public boolean onActionItemClicked(ActionMode mode, MenuItem item) {
                switch (item.getItemId()) {
                  case ID_CUT:
                    cutSelection();
                    return true;
                  case ID_COPY:
                    copySelection();
                    mode.finish();
                    return true;
                  case ID_PASTE:
                    pasteClipboard();
                    mode.finish();
                    return true;
                  case ID_SELECT_ALL:
                    selectAll();
                    return true;
                  default:
                    ActionModeContributor contributor = actionModeContributor;
                    return contributor != null && contributor.onMenuItem(mode, item);
                }
              }

              @Override
              public void onDestroyActionMode(ActionMode mode) {
                ClipboardManager clipboard =
                    (ClipboardManager) getContext().getSystemService(Context.CLIPBOARD_SERVICE);
                if (clipboard != null)
                  clipboard.removePrimaryClipChangedListener(clipboardStateListener);
                selectionActionMode = null;
                ActionModeContributor contributor = actionModeContributor;
                if (contributor != null) contributor.onDestroy(mode);
                if (hasSelection()) exitSelectionMode();
              }
            });
    if (selectionActionMode != null) {
      ClipboardManager clipboard =
          (ClipboardManager) getContext().getSystemService(Context.CLIPBOARD_SERVICE);
      if (clipboard != null)
        clipboard.addPrimaryClipChangedListener(clipboardStateListener);
    }
  }

  /** إغلاق القائمة إن كانت مفتوحة عند مغادرة النافذة. */
  @Override
  protected void onDetachedFromWindow() {
    if (selectionActionMode != null) selectionActionMode.finish();
    super.onDetachedFromWindow();
  }
}
