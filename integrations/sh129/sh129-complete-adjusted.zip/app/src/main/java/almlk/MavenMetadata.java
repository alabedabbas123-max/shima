package almlk;

import java.io.File;
import java.nio.file.Files;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Deque;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * قراءة {@code maven-metadata.xml} بوعيِ موضعِ الوسمِ — طبقةٌ صافيةٌ واحدةٌ يقرؤها محركُ الحلِّ وحوارُ
 * التصفُّحِ معًا (W22/ب1).
 *
 * <p><b>لماذا وُجِدَتْ:</b> كانَ المحلِّلُ السابقُ تعبيرًا نمطيًّا {@code <version>…</version>} يلتقطُ
 * <em>كلَّ</em> وسمٍ بهذا الاسمِ في الملفِّ، و{@code versioning/snapshot} (وفي أمتعةٍ أقدمَ
 * {@code snapshotVersion/version}) يحملُ الوسمَ نفسَهُ لإصدارٍ لا يُنزَّلُ كإصدارٍ مُطلَقٍ — فيُعرَضُ
 * سطرٌ لا يوجدُ، ويقعُ المستخدمُ في حلقةِ «Could not resolve». القراءةُ الآنَ مسبوكةٌ على مسارِ العنصرِ:
 * ما يُقبَلُ هو {@code metadata/versioning/versions/version} وحدهُ، وتُستفادُ وسومُ
 * {@code latest}/{@code release}/{@code lastUpdated} التي كانتْ تُهمَلُ مع أنَّهُما الجوابُ عن «الأحدثُ
 * المستقرُّ».
 *
 * <p>لا يُرمَى استثناءٌ أبدًا: ملفٌّ مبتورٌ أو غيرُ موجودٍ يُنتجُ ما فُهِمَ قبلَ القطعِ، وإلا {@link #EMPTY}
 * — لأنَّ المخبأَ ملكُ المستخدمِ ولا يجوزُ أن يفجُرَ حوارًا.
 */
public final class MavenMetadata {

  /** سقفُ ما يُقرَأُ من ملفٍ واحدٍ: أعلى من أيِّ metadata حقيقيٍّ، وأقلُّ من أن يُرهقَ الذاكرةَ. */
  static final int MAX_TEXT = 4_000_000;

  public final String groupId;
  public final String artifactId;
  /** {@code <latest>} كما هو (قد يكونُ snapshot)، أو "". */
  public final String latest;
  /** {@code <release>} = آخرُ إصدارٍ غيرِ snapshot — الأساسُ في «الأحدثُ». */
  public final String release;
  /** {@code <lastUpdated>} بصيغةِ {@code yyyyMMddHHmmss}، أو "". */
  public final String lastUpdated;
  /** إصداراتٌ معلَنةٌ بترتيبِ الملفِّ، بلا تكرارٍ. */
  public final List<String> versions;

  public static final MavenMetadata EMPTY =
      new MavenMetadata("", "", "", "", "", Collections.<String>emptyList());

  private MavenMetadata(
      String groupId, String artifactId, String latest, String release, String lastUpdated,
      List<String> versions) {
    this.groupId = groupId;
    this.artifactId = artifactId;
    this.latest = latest;
    this.release = release;
    this.lastUpdated = lastUpdated;
    this.versions = Collections.unmodifiableList(versions);
  }

  /** هل هذا النصُّ metadata أصلًا؟ (أولُ 4096 حرفًا — يكفي للتمييزِ عن صفحةِ خطأِ مرآةٍ). */
  public static boolean looksLikeMetadata(String text) {
    if (text == null || text.isEmpty()) return false;
    int probe = Math.min(text.length(), 4096);
    int at = text.indexOf("<metadata");
    return at >= 0 && at < probe;
  }

  public static MavenMetadata parse(String text) {
    if (text == null || text.isEmpty() || text.length() > MAX_TEXT) return EMPTY;
    List<String> versions = new ArrayList<String>();
    Set<String> seen = new LinkedHashSet<String>();
    String[] singles = new String[5]; // 0=groupId 1=artifactId 2=latest 3=release 4=lastUpdated
    Deque<String> stack = new ArrayDeque<String>();
    int i = 0;
    int n = text.length();
    while (i < n) {
      int lt = text.indexOf('<', i);
      if (lt < 0) break;
      if (text.startsWith("<!--", lt)) {
        int end = text.indexOf("-->", lt + 4);
        if (end < 0) break;
        i = end + 3;
        continue;
      }
      if (text.startsWith("<![CDATA[", lt)) {
        int end = text.indexOf("]]>", lt + 9);
        if (end < 0) break;
        i = end + 3;
        continue;
      }
      if (text.startsWith("<?", lt) || text.startsWith("<!", lt)) {
        int end = text.indexOf('>', lt);
        if (end < 0) break;
        i = end + 1;
        continue;
      }
      int gt = text.indexOf('>', lt);
      if (gt < 0) break;
      String raw = text.substring(lt + 1, gt).trim();
      if (raw.isEmpty()) break;
      if (raw.startsWith("/")) {
        if (!stack.isEmpty()) stack.removeLast();
        i = gt + 1;
        continue;
      }
      boolean selfClosing = raw.endsWith("/");
      String name = raw;
      int space = name.indexOf(' ');
      if (space > 0) name = name.substring(0, space);
      name = name.trim();
      if (name.isEmpty()) break;
      if (selfClosing) {
        i = gt + 1;
        continue;
      }
      String path = path(stack, name);
      int slot = slotOf(path);
      if (slot < 0 && !path.equals("metadata/versioning/versions/version")) {
        stack.addLast(name);
        i = gt + 1;
        continue;
      }
      int close = text.indexOf("</" + name, gt);
      if (close < 0) break; // ملفٌّ مبتورٌ: ما جُمِعَ قبلَ القطعِ يبقى صالحًا
      int valueEnd = text.indexOf('>', close);
      if (valueEnd < 0) break;
      String value = unescape(text.substring(gt + 1, close).trim());
      if (slot >= 0) {
        if (!value.isEmpty()) singles[slot] = value;
      } else if (!value.isEmpty() && seen.add(value)) {
        versions.add(value);
      }
      i = valueEnd + 1;
    }
    if (versions.isEmpty() && singles[2] == null && singles[3] == null) {
      return EMPTY;
    }
    return new MavenMetadata(
        orEmpty(singles[0]), orEmpty(singles[1]), orEmpty(singles[2]), orEmpty(singles[3]),
        orEmpty(singles[4]), versions);
  }

  /** قراءةٌ من قرصٍ بلا استثناءٍ — التلفُ والغيابُ سيّانِ عندَ المُستَدعي. */
  public static MavenMetadata read(File file) {
    if (file == null || !file.isFile()) return EMPTY;
    try {
      byte[] raw = Files.readAllBytes(file.toPath());
      if (raw.length > MAX_TEXT) return EMPTY;
      return parse(new String(raw, "UTF-8"));
    } catch (Exception failure) {
      return EMPTY;
    }
  }

  /** اتحادُ كلِّ وسومِ الإصداراتِ في كلِّ {@code maven-metadata*.xml} في مجلدٍ (بما فيها ملفاتُنا المخبوءةُ بالاسمِ الموروثِ). */
  public static List<String> versionsIn(File dir) {
    LinkedHashSet<String> out = new LinkedHashSet<String>();
    File[] children = dir == null ? null : dir.listFiles();
    if (children != null) {
      for (File child : children) {
        if (child.isFile() && child.getName().startsWith("maven-metadata")
            && child.getName().endsWith(".xml")) {
          out.addAll(read(child).versions);
        }
      }
    }
    return new ArrayList<String>(out);
  }

  /**
   * اسمُ ملفِّ المخبأِ لموردٍ — <b>القاعدةُ الموروثةُ محفوظةٌ</b> {@code maven-metadata-<hex(url.hashCode())>.xml}،
   * فتُقرَأُ مخبآتُ ما قبلَ هذهِ الجولةِ ولا تُهدَرُ.
   */
  public static String cacheFileName(String repoUrl) {
    return "maven-metadata-" + Integer.toHexString(repoUrl == null ? 0 : repoUrl.hashCode()) + ".xml";
  }

  public boolean isEmpty() {
    return versions.isEmpty() && latest.isEmpty() && release.isEmpty();
  }

  /** أحدثُ معلَنٍ ترتيبًا؛ و{@code stableOnly} تُضيِّقُ إلى {@code <release>} فإن غابَ فآخرُ مستقرٍّ. */
  public String newest(boolean stableOnly) {
    if (stableOnly && !release.isEmpty() && versions.contains(release)) return release;
    String best = null;
    for (String version : versions) {
      if (stableOnly && !MavenVersion.isStable(version)) continue;
      if (best == null || MavenVersion.compare(version, best) > 0) best = version;
    }
    if (best == null && !stableOnly && !latest.isEmpty()) return latest;
    return best == null ? "" : best;
  }

  public boolean contains(String version) {
    return version != null && versions.contains(version.trim());
  }

  @Override
  public String toString() {
    return "MavenMetadata[" + groupId + ":" + artifactId + " versions=" + versions.size()
        + " release=" + release + " lastUpdated=" + lastUpdated + "]";
  }

  // ═══════════════ أدواتٌ داخليّةٌ ═══════════════

  private static String path(Deque<String> stack, String name) {
    StringBuilder out = new StringBuilder(name.length() + 32);
    for (String parent : stack) out.append(parent).append('/');
    return out.append(name).toString();
  }

  private static int slotOf(String path) {
    if (path.equals("metadata/groupId")) return 0;
    if (path.equals("metadata/artifactId")) return 1;
    if (path.equals("metadata/versioning/latest")) return 2;
    if (path.equals("metadata/versioning/release")) return 3;
    if (path.equals("metadata/versioning/lastUpdated")) return 4;
    return -1;
  }

  private static String orEmpty(String value) {
    return value == null ? "" : value;
  }

  private static String unescape(String value) {
    if (value.indexOf('&') < 0) return value;
    StringBuilder out = new StringBuilder(value.length());
    for (int i = 0; i < value.length(); i++) {
      char c = value.charAt(i);
      if (c != '&') {
        out.append(c);
        continue;
      }
      int end = value.indexOf(';', i);
      if (end < 0 || end - i > 8) {
        out.append(c);
        continue;
      }
      String entity = value.substring(i + 1, end);
      if (entity.equals("amp")) out.append('&');
      else if (entity.equals("lt")) out.append('<');
      else if (entity.equals("gt")) out.append('>');
      else if (entity.equals("quot")) out.append('"');
      else if (entity.equals("apos")) out.append('\'');
      else if (entity.startsWith("#x") || entity.startsWith("#X")) {
        try {
          out.append((char) Integer.parseInt(entity.substring(2), 16));
        } catch (NumberFormatException keep) {
          out.append(value, i, end + 1);
        }
      } else if (entity.startsWith("#")) {
        try {
          out.append((char) Integer.parseInt(entity.substring(1)));
        } catch (NumberFormatException keep) {
          out.append(value, i, end + 1);
        }
      } else {
        out.append(value, i, end + 1);
        continue;
      }
      i = end;
    }
    return out.toString();
  }
}
