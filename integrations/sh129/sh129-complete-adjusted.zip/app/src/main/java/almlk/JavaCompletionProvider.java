package almlk;

import com.almlkid.kay.ui.ProjectSymbolIndex;
import com.almlkid.kay.ui.ProjectSymbolIndex.CompletionItem;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Java completion with the reference editor's presentation: typed rows for locals, fields and
 * methods (own members dark, inherited light), classes ("Name - package" when an import is still
 * needed, imported on commit), packages and keywords.
 *
 * <p>Knowledge comes from three places: the active file's {@link JavaSourceOutline} (exact members
 * and visible locals), the project index for other project classes, and {@link AndroidApiIndex}
 * for the platform (complete typed signatures, parameter names and API levels).
 */
public final class JavaCompletionProvider {

  private static final int MAX_RESULTS = 300;
  private static final int MAX_CLASSES = 80;

  static final String[] KEYWORDS = {
    "abstract", "assert", "boolean", "break", "byte", "case", "catch", "char", "class", "continue",
    "default", "do", "double", "else", "enum", "extends", "false", "final", "finally", "float", "for",
    "if", "implements", "import", "instanceof", "int", "interface", "long", "native", "new", "null",
    "package", "private", "protected", "public", "return", "short", "static", "super", "switch",
    "synchronized", "this", "throw", "throws", "transient", "true", "try", "var", "void", "volatile",
    "while", "yield", "record"
  };
  private static final Set<String> PRIMITIVES = new HashSet<>(Arrays.asList(
      "byte", "short", "int", "long", "float", "double", "boolean", "char", "void"));
  private static final Set<String> NOT_RETURN_TYPES = new HashSet<>(Arrays.asList(
      "return", "new", "else", "throw", "case", "public", "protected", "private", "static", "final",
      "abstract", "synchronized", "native", "default", "yield", "await"));
  private static final Set<String> SYNTHETIC_OBJECT_METHODS = new HashSet<>(Arrays.asList(
      "toString", "hashCode", "equals", "clone"));

  private JavaCompletionProvider() {}

  // ───────────────────────────── type model ─────────────────────────────

  /** A resolved type: one of the three knowledge sources plus generic arguments. */
  static final class TypeRef {
    JavaSourceOutline.Type source;
    ProjectSymbolIndex.ProjectClass project;
    AndroidApiIndex.ClassInfo platform;
    Map<String, String> typeArgs = Collections.emptyMap();
    int arrayDims;
    boolean staticRef;

    String simpleName() {
      return source != null ? source.name : project != null ? project.name : platform != null ? platform.simpleName : "";
    }

    boolean isInterface() {
      return source != null ? source.kind.equals("interface")
          : platform != null && platform.isInterface();
    }
  }

  /** Everything the resolver needs about the active file. */
  static final class Scope {
    final String text, masked;
    final int cursor;
    final JavaSourceOutline outline;
    final JavaSourceOutline.Type current;
    final JavaSourceOutline.Method method;
    final List<JavaSourceOutline.Local> locals;

    Scope(String text, String masked, int cursor) {
      this.text = text;
      this.masked = masked;
      this.cursor = cursor;
      this.outline = JavaSourceOutline.parse(masked);
      this.current = outline.typeAt(cursor);
      this.method = outline.methodAt(current, cursor);
      this.locals = JavaSourceOutline.localsAt(masked, method, cursor);
    }
  }

  // ───────────────────────────── entry ─────────────────────────────

  public static List<CompletionItem> complete(String source, int cursorOffset) {
    String text = source == null ? "" : source;
    int at = Math.max(0, Math.min(cursorOffset, text.length()));
    String masked = ProjectSymbolIndex.maskSource(text);
    if (masked.length() != text.length()) masked = text;
    if (at > 0) {
      char raw = text.charAt(at - 1);
      if (masked.charAt(at - 1) != raw && raw != '"' && raw != '\'') return new ArrayList<>();
    }
    int start = at;
    while (start > 0 && Character.isJavaIdentifierPart(text.charAt(start - 1))) start--;
    String prefix = text.substring(start, at);
    if (!prefix.isEmpty() && Character.isDigit(prefix.charAt(0))) return new ArrayList<>();

    int lineStart = masked.lastIndexOf('\n', Math.max(0, start - 1)) + 1;
    String line = masked.substring(lineStart, start).trim();
    Matcher imp = Pattern.compile("^import\\s+(?:static\\s+)?([\\w.]*)$").matcher(line);
    if (imp.find()) return importItems(imp.group(1), prefix);
    if (line.startsWith("package ") || line.equals("package")) return new ArrayList<>();

    int before = start - 1;
    while (before >= 0 && Character.isWhitespace(masked.charAt(before))) before--;
    Scope scope = new Scope(text, masked, at);
    Sink sink = new Sink(prefix);
    if (before >= 0 && masked.charAt(before) == '.') {
      if (before > 0 && Character.isDigit(text.charAt(before - 1)) && isNumberBefore(text, before)) return new ArrayList<>();
      TypeRef receiver = evaluateReceiver(scope, before);
      if (receiver == null) return new ArrayList<>();
      addReceiverMembers(scope, receiver, sink);
      return sink.result();
    }
    boolean afterNew = endsWithWord(masked, before + 1, "new");
    boolean afterAt = before >= 0 && masked.charAt(before) == '@';
    if (afterNew || afterAt) {
      addClasses(scope, prefix, sink, true);
      return sink.result();
    }
    for (JavaSourceOutline.Local local : scope.locals) {
      if (!CompletionMatcher.matches(local.name, prefix)) continue;
      CompletionItem item = new CompletionItem(CompletionItem.VARIABLE, local.name, local.name, "");
      item.suffix = local.type.equals("var") ? "" : " : " + AndroidApiIndex.simpleTypeText(local.type);
      sink.add("l:" + local.name, item);
    }
    if (scope.current != null && scope.method == null) {
      addOverrideStubs(scope, sink);
    } else {
      for (JavaSourceOutline.Type t = scope.current; t != null; t = t.outer) {
        TypeRef self = new TypeRef();
        self.source = t;
        collectMembers(scope, self, true, true, t == scope.current ? 0 : 0, sink, new HashSet<>());
      }
    }
    if (!prefix.isEmpty()) {
      addClasses(scope, prefix, sink, false);
      for (String keyword : KEYWORDS)
        if (CompletionMatcher.rank(keyword, prefix) <= 2)
          sink.add("k:" + keyword, new CompletionItem(CompletionItem.KEYWORD, keyword, keyword, ""));
    }
    return sink.result();
  }

  private static boolean isNumberBefore(String text, int dot) {
    int i = dot - 1;
    while (i >= 0 && (Character.isDigit(text.charAt(i)) || text.charAt(i) == '_')) i--;
    return i < 0 || !Character.isJavaIdentifierPart(text.charAt(i));
  }

  private static boolean endsWithWord(String masked, int end, String word) {
    int e = end;
    while (e > 0 && Character.isWhitespace(masked.charAt(e - 1))) e--;
    int s = e - word.length();
    return s >= 0 && masked.startsWith(word, s) && (s == 0 || !Character.isJavaIdentifierPart(masked.charAt(s - 1)));
  }

  // ───────────────────────────── result collection ─────────────────────────────

  static final class Sink {
    final String prefix;
    final LinkedHashMap<String, CompletionItem> items = new LinkedHashMap<>();

    Sink(String prefix) {
      this.prefix = prefix;
    }

    void add(String key, CompletionItem item) {
      if (!items.containsKey(key)) items.put(key, item);
    }

    private int tier(CompletionItem item) {
      int rank = CompletionMatcher.rank(item.label, prefix);
      return rank <= 1 ? 0 : rank == 2 ? 1 : 2;
    }

    private static int group(CompletionItem item) {
      switch (item.kind) {
        case CompletionItem.VARIABLE:
        case CompletionItem.METHOD:
          return 0;
        case CompletionItem.KEYWORD:
          return 1;
        case CompletionItem.PACKAGE:
          return 2;
        default:
          return 3;
      }
    }

    List<CompletionItem> result() {
      // Rows whose case matches the typed prefix first (as in the reference), then locals,
      // members, keywords and classes, each alphabetically.
      ArrayList<Map.Entry<String, CompletionItem>> entries = new ArrayList<>(items.entrySet());
      entries.sort((x, y) -> {
        CompletionItem a = x.getValue();
        CompletionItem b = y.getValue();
        int ra = tier(a);
        int rb = tier(b);
        if (ra != rb) return Integer.compare(ra, rb);
        int ka = x.getKey().startsWith("l:") ? -1 : group(a);
        int kb = y.getKey().startsWith("l:") ? -1 : group(b);
        if (ka != kb) return Integer.compare(ka, kb);
        int c = a.label.compareToIgnoreCase(b.label);
        return c != 0 ? c : a.suffix.compareTo(b.suffix);
      });
      ArrayList<CompletionItem> out = new ArrayList<>(Math.min(entries.size(), MAX_RESULTS));
      for (Map.Entry<String, CompletionItem> e : entries) {
        if (out.size() >= MAX_RESULTS) break;
        out.add(e.getValue());
      }
      return out;
    }
  }

  // ───────────────────────────── classes & packages ─────────────────────────────

  private static void addClasses(Scope scope, String prefix, Sink sink, boolean allowEmpty) {
    if (prefix.isEmpty() && !allowEmpty) return;
    String currentPackage = scope.outline.packageName;
    List<String> imports = scope.outline.imports;
    for (JavaSourceOutline.Type t : scope.outline.types) {
      if (!CompletionMatcher.matches(t.name, prefix)) continue;
      sink.add("c:" + t.name, classItem(t.name, null, false, null));
    }
    for (String name : ProjectSymbolIndex.projectClassNamesMatching("", 4096)) {
      if (!CompletionMatcher.matches(name, prefix)) continue;
      String pkg = ProjectSymbolIndex.packageOf(name);
      String qualified = pkg == null || pkg.isEmpty() ? name : pkg + "." + name;
      boolean needsImport = pkg != null && !pkg.isEmpty() && !pkg.equals(currentPackage) && !isImported(imports, qualified, pkg);
      sink.add("c:" + qualified, classItem(name, pkg, needsImport, needsImport ? qualified : null));
    }
    if (prefix.isEmpty()) return;
    for (AndroidApiIndex.ClassInfo c : AndroidApiIndex.classesWithPrefix(prefix, MAX_CLASSES)) {
      String importable = c.isNested() ? c.container : c.packageName;
      boolean needsImport = !c.packageName.equals("java.lang") || c.isNested();
      if (needsImport && (isImported(imports, c.qualifiedName, importable) || importable.equals(currentPackage))) needsImport = false;
      if (c.isNested() && !needsImport) continue;
      CompletionItem item = classItem(c.simpleName, c.isNested() ? c.container : c.packageName, needsImport,
          needsImport ? c.qualifiedName : null);
      item.apiInfo = AndroidApiIndex.apiLevelText(c.since, c.deprecated, c.removed, true);
      sink.add("c:" + c.qualifiedName, item);
    }
  }

  private static boolean isImported(List<String> imports, String qualified, String container) {
    for (String imp : imports) {
      if (imp.equals(qualified)) return true;
      if (imp.endsWith(".*") && imp.substring(0, imp.length() - 2).equals(container)) return true;
    }
    return false;
  }

  private static CompletionItem classItem(String name, String pkg, boolean needsImport, String importName) {
    CompletionItem item = new CompletionItem(CompletionItem.CLASS, name, name, "");
    item.secondary = needsImport;
    item.suffix = needsImport && pkg != null && !pkg.isEmpty() ? " - " + pkg : "";
    item.importNames = importName == null || importName.isEmpty()
        ? null : java.util.Collections.singletonList(importName);
    return item;
  }

  private static List<CompletionItem> importItems(String qualifier, String prefix) {
    Sink sink = new Sink(prefix);
    String parent = qualifier.endsWith(".") ? qualifier.substring(0, qualifier.length() - 1) : "";
    if (!qualifier.isEmpty() && !qualifier.endsWith(".")) return sink.result();
    for (String segment : AndroidApiIndex.subPackages(parent)) {
      if (!CompletionMatcher.matches(segment, prefix)) continue;
      CompletionItem item = new CompletionItem(CompletionItem.PACKAGE, segment, segment + ".", "");
      item.reopen = true;
      sink.add("p:" + segment, item);
    }
    for (AndroidApiIndex.ClassInfo c : AndroidApiIndex.classesInPackage(parent)) {
      if (!CompletionMatcher.matches(c.simpleName, prefix) || c.removed > 0) continue;
      CompletionItem item = new CompletionItem(CompletionItem.CLASS, c.simpleName, c.simpleName, "");
      item.apiInfo = AndroidApiIndex.apiLevelText(c.since, c.deprecated, c.removed, true);
      sink.add("c:" + c.qualifiedName, item);
    }
    for (String name : ProjectSymbolIndex.projectClassNamesMatching("", 4096)) {
      String pkg = ProjectSymbolIndex.packageOf(name);
      if (pkg == null) continue;
      if (pkg.equals(parent) && CompletionMatcher.matches(name, prefix))
        sink.add("c:" + pkg + "." + name, new CompletionItem(CompletionItem.CLASS, name, name, ""));
      else if (pkg.startsWith(parent.isEmpty() ? "" : parent + ".")) {
        String rest = pkg.substring(parent.isEmpty() ? 0 : parent.length() + 1);
        String segment = rest.contains(".") ? rest.substring(0, rest.indexOf('.')) : rest;
        if (!segment.isEmpty() && CompletionMatcher.matches(segment, prefix)) {
          CompletionItem item = new CompletionItem(CompletionItem.PACKAGE, segment, segment + ".", "");
          item.reopen = true;
          sink.add("p:" + segment, item);
        }
      }
    }
    return sink.result();
  }

  // ───────────────────────────── members ─────────────────────────────

  private static void addReceiverMembers(Scope scope, TypeRef receiver, Sink sink) {
    if (receiver.arrayDims > 0) {
      if (CompletionMatcher.matches("length", sink.prefix))
        sink.add("f:length", new CompletionItem(CompletionItem.VARIABLE, "length", "length", "int"));
      TypeRef object = platformRef("java.lang.Object");
      if (object != null) collectMembers(scope, object, true, false, 1, sink, new HashSet<>());
      return;
    }
    boolean inside = scope.current != null && isSubtypeOfCurrent(scope, receiver);
    collectMembers(scope, receiver, !receiver.staticRef, inside, 0, sink, new HashSet<>());
    if (receiver.staticRef) {
      for (String nested : nestedTypeNames(receiver))
        if (CompletionMatcher.matches(nested, sink.prefix))
          sink.add("c:" + nested, classItem(nested, null, false, null));
      for (String keyword : new String[] {"class", "this"})
        if (CompletionMatcher.rank(keyword, sink.prefix) <= 2 && (keyword.equals("class") || scope.current != null))
          sink.add("k:" + keyword, new CompletionItem(CompletionItem.KEYWORD, keyword, keyword, ""));
    }
  }

  /**
   * Protected members are visible when the receiver is the current class, an enclosing class, or
   * one of their supertypes (super.onCreate, getResources-style inherited helpers).
   */
  private static boolean isSubtypeOfCurrent(Scope scope, TypeRef receiver) {
    String name = receiver.simpleName();
    for (JavaSourceOutline.Type t = scope.current; t != null; t = t.outer) {
      if (t.name.equals(name)) return true;
      TypeRef sup = t.superName.isEmpty() ? null : resolveType(scope, t.superName, scope.outline.imports);
      for (int guard = 0; sup != null && guard < 24; guard++) {
        if (sup.simpleName().equals(name)) return true;
        sup = superOf(scope, sup);
      }
    }
    return false;
  }

  private static TypeRef superOf(Scope scope, TypeRef type) {
    if (type.source != null)
      return type.source.superName.isEmpty() ? null : resolveType(scope, type.source.superName, scope.outline.imports);
    if (type.project != null)
      return type.project.superName.isEmpty() ? null : resolveType(scope, type.project.superName, type.project.imports);
    if (type.platform != null && !type.platform.superName.isEmpty())
      return platformRef(AndroidApiIndex.stripGenerics(type.platform.superName));
    return null;
  }

  private static List<String> nestedTypeNames(TypeRef type) {
    ArrayList<String> out = new ArrayList<>();
    if (type.source != null) for (JavaSourceOutline.Type n : type.source.nested) out.add(n.name);
    if (type.platform != null) for (AndroidApiIndex.ClassInfo n : AndroidApiIndex.nestedClasses(type.platform)) out.add(n.simpleName);
    return out;
  }

  /**
   * جِسمُ الصنفِ (المؤشِّرُ خارجَ أيِّ دالةٍ): الدوالُّ المورَثةُ تُعرَضُ كما تُكتَبُ لا كما تُنادى —
   * {@code @Override} وتوقيعٌ كاملٌ وجِسمٌ **نظيفٌ بلا تعليقٍ** (طلبُ ١.٠.١٨٨)، بِنَفسِ
   * قَالَبِ {@link QuickFix#stubBody(String)}
   * الذي يَكتُبُهُ إصلاحُ «نفِّذ الدوالَّ المجرّدةَ كلَّها»، فلا قَالَبَانِ يَنفصلانِ يومًا. وما كَتَبَ
   * الصنفُ فيهِ لا يُعرَضُ، وما لا يُكتَبُ نوعُهُ في هذا الملفِّ (استيرادٌ ناقصٌ) يُترَكُ ولا
   * يُختَرََعُ — قاعدةُ {@link AbstractImplementationGap#renderType} هي هيَ هُنا، لأنَّ سطرًا لا
   * يُترجَمُ أسوأُ من صمتٍ.
   *
   * <p>ولا {@code java.lang.Object} في المِشْيِ: الفِهرسُ لا يَحمِلُ عَلمَ {@code final}، فاقتراحُ
   * {@code getClass()} أو {@code wait()} «لإعادةِ التعريفِ» كذبٌ؛ والثلاثُ التي تَصلُحُ
   * ({@code toString}/​{@code equals}/​{@code hashCode}) تُذكَرُ صراحةً عندَ أصنافٍ بلا أصلٍ مَكتوبٍ.
   */
  private static void addOverrideStubs(Scope scope, Sink sink) {
    JavaSourceOutline.Type self = scope.current;
    if (self == null) return;
    Set<String> declared = new HashSet<>();
    for (JavaSourceOutline.Method m : self.methods) declared.add(m.name + "/" + paramCount(m.parameters));
    // أعضاءُ الصنفِ نفسِهِ لا يُقترَحونَ هُنا: سطرٌ في جِسمِ الصنفِ مَوضِعُهُ إعلانٌ، ونداءٌ
    // {@code getCount()} بَعدَ {@code get} يُدرَجُ خارجَ أيِّ دالةٍ فلا يُترجَمُ — ضجيجٌ بلا نفعٍ.
    ArrayList<String> supers = new ArrayList<>();
    if (!self.superName.isEmpty()) supers.add(self.superName);
    supers.addAll(self.interfaces);
    collectOverrides(scope, supers, 1, sink, declared, new HashSet<>());
    if (supers.isEmpty()) overrideObjectHelpers(scope, self.name, sink, declared);
  }

  /** سُلَّمُ الأصنافِ العليا: كلُّ دالةِ مِثالٍ يَمكِنُ إعادةُ تعريفِها سطرٌ في القائمةِ. */
  private static void collectOverrides(Scope scope, List<String> supers, int depth, Sink sink,
      Set<String> declared, Set<String> visited) {
    if (supers == null || supers.isEmpty() || depth > 12) return;
    for (String written : supers) {
      if (written == null || written.isEmpty()) continue;
      TypeRef ref = resolveType(scope, written, scope.outline.imports);
      if (ref == null) continue;
      if (isObjectType(ref)) continue;
      String id = ref.simpleName() + "@" + (ref.platform != null ? "p" : ref.source != null ? "s" : "j");
      if (!visited.add(id)) continue;
      ArrayList<String> next = new ArrayList<>();
      if (ref.source != null) {
        JavaSourceOutline.Type t = ref.source;
        for (JavaSourceOutline.Method m : t.methods) {
          if (m.isStatic) continue;
          overrideRow(scope, sink, declared, t.name, m.name, m.parameters, m.returnType, null);
        }
        if (!t.superName.isEmpty()) next.add(t.superName);
        next.addAll(t.interfaces);
      } else if (ref.project != null) {
        ProjectSymbolIndex.ProjectClass p = ref.project;
        for (Map.Entry<String, String> e : p.methodReturns.entrySet()) {
          String name = e.getKey();
          String ret = e.getValue();
          if (name == null || name.equals(p.name) || NOT_RETURN_TYPES.contains(ret)
              || SYNTHETIC_OBJECT_METHODS.contains(name) && paramCount(p.methodParameters.get(name)) == 0
                  && !p.methodParameters.containsKey(name))
            continue; // بذرةُ الإطارِ لا مُتمِّماتٍ لَها: لا سطرَ يُختَرَعُ منهُ
          overrideRow(scope, sink, declared, p.name, name, p.methodParameters.getOrDefault(name, ""),
              ret, null);
        }
        next.addAll(p.supertypes);
        if (next.isEmpty() && !p.superName.isEmpty()) next.add(p.superName);
      } else if (ref.platform != null) {
        AndroidApiIndex.ClassInfo info = ref.platform;
        for (AndroidApiIndex.Member m : AndroidApiIndex.declaredMembers(info)) {
          if (m.kind != AndroidApiIndex.Member.METHOD || m.isStatic || m.removed > 0) continue;
          overrideRow(scope, sink, declared, info.simpleName, m.name,
              substitute(m.parameters, ref.typeArgs), substitute(m.type, ref.typeArgs),
              AndroidApiIndex.apiLevelText(m.since, m.deprecated, m.removed, true));
        }
        if (!info.superName.isEmpty()) next.add(AndroidApiIndex.stripGenerics(info.superName));
        for (String iface : info.interfaces) next.add(AndroidApiIndex.stripGenerics(iface));
      }
      collectOverrides(scope, next, depth + 1, sink, declared, visited);
    }
  }

  private static void overrideObjectHelpers(Scope scope, String owner, Sink sink, Set<String> declared) {
    if (CompletionMatcher.matches("toString", sink.prefix))
      overrideRow(scope, sink, declared, owner, "toString", "", "String", null);
    if (CompletionMatcher.matches("hashCode", sink.prefix))
      overrideRow(scope, sink, declared, owner, "hashCode", "", "int", null);
    if (CompletionMatcher.matches("equals", sink.prefix))
      overrideRow(scope, sink, declared, owner, "equals", "Object other", "boolean", null);
  }

  /** سطرُ «اِكتُبْها فوقَها»: الاسمُ مَفتَوحًا على جِسمٍ مُعلَّمٍ، والمؤشِّرُ داخِلَهُ. */
  private static void overrideRow(Scope scope, Sink sink, Set<String> declared, String owner,
      String name, String params, String returnType, String api) {
    if (name == null || name.isEmpty() || name.indexOf('<') >= 0) return;
    String shown = params == null ? "" : params.trim();
    if (declared.contains(name + "/" + paramCount(shown))) return;
    if (!CompletionMatcher.matches(name, sink.prefix)) return;
    List<String> toFetch = new ArrayList<>(); // ما يَلزَمُ من سطورِ الاستيرادِ — بأيِّ عدَدٍ
    String ret = writtenType(returnType, scope.outline.imports, toFetch);
    if (ret == null) return;
    ArrayList<QuickFix.Param> list = new ArrayList<>();
    for (String part : splitTopLevel(shown)) {
      String p = part.trim();
      if (p.isEmpty()) continue;
      boolean varargs = p.endsWith("...");
      if (varargs) p = p.substring(0, p.length() - 3).trim();
      int sp = declarationSplit(p);
      if (sp < 0) return;
      String type = writtenType(p.substring(0, sp), scope.outline.imports, toFetch);
      if (type == null) return;
      String pname = p.substring(sp + 1).trim();
      if (pname.isEmpty() || !Character.isJavaIdentifierStart(pname.charAt(0))) return;
      list.add(new QuickFix.Param(varargs ? type + "..." : type, pname));
    }
    QuickFix stub = QuickFix.createMethod(owner, ret, name, list);
    if (stub == null) return;
    String indent = caretIndent(scope);
    CompletionItem item = new CompletionItem(CompletionItem.METHOD, name,
        stub.declarationHead(indent, true) + stub.stubBody(indent), "");
    item.suffix = "(" + AndroidApiIndex.simpleTypeText(shown) + ") : "
        + AndroidApiIndex.simpleTypeText(ret);
    item.caretBack = indent.length() + 1;
    if (!toFetch.isEmpty()) item.importNames = java.util.Collections.unmodifiableList(toFetch);
    if (api != null) item.apiInfo = api;
    sink.add("o:" + name + "/" + paramCount(shown), item);
  }

  /**
   * الاسمُ كما يَنبغِي أن يُكتَبَ في هذا الملفِّ: {@code java.lang} ضِمنُ الاستيرادِ بحُكمِ اللُّغةِ،
   * و{@code toFetch} — حينَ تُمرَّرُ — قائمةُ مُخرَجٍ تَأخُذُ كلَّ اسمٍ قُلِّصَ إلى المَبسَّطِ فصارَ
   * يَحتاجُ سطرًا (‏1.0.189): اقتراحُ التغطيةِ لا يَدَعُ نوعًا مَبسَّطًا بلا استيرادِهِ، ولا يُبقي
   * نوعًا مُقيَّدًا في جِسمِ الدالةِ لأنَّ سطرَهُ كانَ يَسَعُهُ. القاعدةُ كلُّها في
   * {@code AbstractImplementationGap.renderType} — لا قاعدةَ ثانيةً للإكمالِ.
   */
  private static String writtenType(String type, List<String> imports, List<String> toFetch) {
    if (type == null) return null;
    String t = AndroidApiIndex.stripGenerics(type).trim();
    if (t.isEmpty()) return null;
    String direct = AbstractImplementationGap.renderType(t, imports, toFetch);
    if (direct != null) return direct;
    return t.indexOf('.') < 0 && AndroidApiIndex.classByQualifiedName("java.lang." + t) != null
        ? AbstractImplementationGap.renderType("java.lang." + t, imports, toFetch)
        : null;
  }

  /** هل هو {@code java.lang.Object} (بمَصدَرِهِ المُؤكَّدِ وحدَهُ — لا بالاسمِ المَبسَّطِ)؟ */
  private static boolean isObjectType(TypeRef ref) {
    return ref != null && ref.platform != null && "java.lang.Object".equals(ref.platform.qualifiedName);
  }

  /** «View convertView» ← فاصلُ النوعِ عنِ الاسمِ؛ و{@code -1} ما لم يَكُنْ إعلانًا مَقروءًا. */
  private static int declarationSplit(String param) {
    int depth = 0;
    for (int i = param.length() - 1; i > 0; i--) {
      char c = param.charAt(i);
      if (c == '>' || c == ')') depth++;
      else if (c == '<' || c == '(') depth--;
      else if (depth == 0 && (c == ' ' || c == '\t')) return i;
    }
    return -1;
  }

  /** مسافةُ سطرِ المؤشِّرِ: القالبُ يَنزِلُ على مِثْلِها، لا على أربعِ مسافاتٍ افتراضيةٍ. */
  private static String caretIndent(Scope scope) {
    int lineStart = scope.masked.lastIndexOf('\n', Math.max(0, scope.cursor - 1)) + 1;
    int i = lineStart;
    while (i < scope.cursor && i < scope.masked.length()
        && (scope.masked.charAt(i) == ' ' || scope.masked.charAt(i) == '\t')) i++;
    return scope.masked.substring(lineStart, i);
  }

  /**
   * Adds the members of {@code type} and of its supertypes. Members found below depth 0 are
   * inherited and drawn with the light icon.
   */
  private static void collectMembers(Scope scope, TypeRef type, boolean instance, boolean includeProtected,
      int depth, Sink sink, Set<String> visited) {
    if (type == null || !visited.add(type.simpleName() + "@" + (type.platform != null ? "p" : type.source != null ? "s" : "j"))) return;
    String prefix = sink.prefix;
    boolean inherited = depth > 0;
    if (type.source != null) {
      JavaSourceOutline.Type t = type.source;
      for (JavaSourceOutline.Field f : t.fields) {
        if ((!instance && !f.isStatic) || !CompletionMatcher.matches(f.name, prefix)) continue;
        sink.add("f:" + f.name, field(f.name, f.type, inherited, null));
      }
      for (JavaSourceOutline.Method m : t.methods) {
        if ((!instance && !m.isStatic) || !CompletionMatcher.matches(m.name, prefix)) continue;
        sink.add("m:" + m.name + "(" + paramTypes(m.parameters), method(m.name, m.parameters, m.returnType, inherited, null));
      }
      if (t.kind.equals("enum") && depth == 0) {
        // compiler-generated statics every enum has
        if (CompletionMatcher.matches("values", prefix))
          sink.add("m:values(", method("values", "", t.name + "[]", false, null));
        if (CompletionMatcher.matches("valueOf", prefix))
          sink.add("m:valueOf(String", method("valueOf", "String name", t.name, false, null));
      }
      List<String> supers = new ArrayList<>();
      if (!t.superName.isEmpty()) supers.add(t.superName);
      supers.addAll(t.interfaces);
      if (t.superName.isEmpty() && !t.kind.equals("interface")) supers.add(t.kind.equals("enum") ? "java.lang.Enum" : "java.lang.Object");
      if (t.kind.equals("interface")) supers.add("java.lang.Object");
      for (String sup : supers) collectMembers(scope, resolveType(scope, sup, scope.outline.imports), instance, includeProtected, depth + 1, sink, visited);
      return;
    }
    if (type.project != null) {
      ProjectSymbolIndex.ProjectClass p = type.project;
      for (Map.Entry<String, String> f : p.fields.entrySet()) {
        if (!CompletionMatcher.matches(f.getKey(), prefix)) continue;
        sink.add("f:" + f.getKey(), field(f.getKey(), f.getValue(), inherited, null));
      }
      for (Map.Entry<String, String> m : p.methodReturns.entrySet()) {
        String name = m.getKey();
        String params = p.methodParameters.getOrDefault(name, "");
        String ret = m.getValue();
        if (name.equals(p.name) || NOT_RETURN_TYPES.contains(ret) || !CompletionMatcher.matches(name, prefix)) continue;
        if (SYNTHETIC_OBJECT_METHODS.contains(name) && params.isEmpty()) continue; // seeded, Object provides it
        sink.add("m:" + name + "(" + paramTypes(params), method(name, params, ret, inherited, null));
      }
      List<String> supers = new ArrayList<>(p.supertypes);
      if (supers.isEmpty() && !p.superName.isEmpty()) supers.add(p.superName);
      if (supers.isEmpty()) supers.add("java.lang.Object");
      for (String sup : supers) {
        TypeRef next = resolveType(scope, sup, p.imports);
        collectMembers(scope, next, instance, includeProtected, depth + 1, sink, visited);
      }
      return;
    }
    if (type.platform != null) collectPlatform(type.platform, type.typeArgs, instance, includeProtected, depth, sink, visited);
  }

  private static void collectPlatform(AndroidApiIndex.ClassInfo info, Map<String, String> args, boolean instance,
      boolean includeProtected, int depth, Sink sink, Set<String> visited) {
    if (depth > 0 && !visited.add(info.qualifiedName)) return;
    if (depth == 0) visited.add(info.qualifiedName);
    String prefix = sink.prefix;
    boolean inherited = depth > 0;
    for (AndroidApiIndex.Member m : AndroidApiIndex.declaredMembers(info)) {
      if (m.removed > 0 || (!instance && !m.isStatic) || (m.isProtected && !includeProtected)) continue;
      if (!CompletionMatcher.matches(m.name, prefix)) continue;
      String api = AndroidApiIndex.apiLevelText(m.since, m.deprecated, m.removed, true);
      if (m.kind == AndroidApiIndex.Member.FIELD) {
        sink.add("f:" + m.name, field(m.name, substitute(m.type, args), inherited, api));
      } else {
        String params = substitute(m.parameters, args);
        sink.add("m:" + m.name + "(" + paramTypes(params), method(m.name, params, substitute(m.type, args), inherited, api));
      }
    }
    if (!info.superName.isEmpty()) {
      AndroidApiIndex.ClassInfo sup = AndroidApiIndex.classByQualifiedName(info.superName);
      if (sup != null) collectPlatform(sup, bind(sup, substitute(info.superName, args)), instance, includeProtected, depth + 1, sink, visited);
    }
    for (String iface : info.interfaces) {
      AndroidApiIndex.ClassInfo i = AndroidApiIndex.classByQualifiedName(iface);
      if (i != null) collectPlatform(i, bind(i, substitute(iface, args)), instance, includeProtected, depth + 1, sink, visited);
    }
    if (info.isInterface() && depth == 0) {
      AndroidApiIndex.ClassInfo object = AndroidApiIndex.classByQualifiedName("java.lang.Object");
      if (object != null) collectPlatform(object, Collections.emptyMap(), instance, includeProtected, 1, sink, visited);
    }
  }

  private static CompletionItem field(String name, String type, boolean inherited, String api) {
    CompletionItem item = new CompletionItem(CompletionItem.VARIABLE, name, name, "");
    item.suffix = " : " + AndroidApiIndex.simpleTypeText(type);
    item.secondary = inherited;
    if (api != null) item.apiInfo = api;
    return item;
  }

  private static CompletionItem method(String name, String params, String returnType, boolean inherited, String api) {
    String shownParams = AndroidApiIndex.simpleTypeText(params == null ? "" : params.trim());
    CompletionItem item = new CompletionItem(CompletionItem.METHOD, name, name + "()", "");
    item.suffix = "(" + shownParams + ") : " + AndroidApiIndex.simpleTypeText(returnType);
    item.caretBack = shownParams.isEmpty() ? 0 : 1;
    item.secondary = inherited;
    if (api != null) item.apiInfo = api;
    return item;
  }

  /** "int a, String b" → "int,String" (overload key). */
  private static String paramTypes(String params) {
    if (params == null || params.trim().isEmpty()) return "";
    StringBuilder b = new StringBuilder();
    for (String part : splitTopLevel(params)) {
      String p = part.trim();
      int space = p.lastIndexOf(' ');
      if (b.length() > 0) b.append(',');
      b.append(AndroidApiIndex.simpleTypeText(space > 0 ? p.substring(0, space).trim() : p));
    }
    return b.toString();
  }

  // ───────────────────────────── generics ─────────────────────────────

  private static Map<String, String> bind(AndroidApiIndex.ClassInfo info, String written) {
    if (info == null || info.typeParameters.length == 0) return Collections.emptyMap();
    int lt = written.indexOf('<');
    int gt = written.lastIndexOf('>');
    if (lt < 0 || gt < lt) return Collections.emptyMap();
    List<String> args = splitTopLevel(written.substring(lt + 1, gt));
    HashMap<String, String> map = new HashMap<>();
    for (int i = 0; i < info.typeParameters.length && i < args.size(); i++) {
      String arg = args.get(i).trim();
      if (arg.startsWith("?")) arg = arg.startsWith("? extends ") ? arg.substring(10) : "java.lang.Object";
      map.put(info.typeParameters[i], arg);
    }
    return map;
  }

  private static String substitute(String type, Map<String, String> args) {
    if (type == null || args == null || args.isEmpty()) return type == null ? "" : type;
    StringBuilder out = new StringBuilder();
    Matcher m = Pattern.compile("[A-Za-z_$][\\w$.]*").matcher(type);
    int last = 0;
    while (m.find()) {
      out.append(type, last, m.start());
      String word = m.group();
      out.append(args.getOrDefault(word, word));
      last = m.end();
    }
    out.append(type.substring(last));
    return out.toString();
  }

  private static List<String> splitTopLevel(String text) {
    ArrayList<String> out = new ArrayList<>();
    int depth = 0;
    int last = 0;
    for (int i = 0; i < text.length(); i++) {
      char c = text.charAt(i);
      if (c == '<' || c == '(' || c == '[') depth++;
      else if (c == '>' || c == ')' || c == ']') depth--;
      else if (c == ',' && depth == 0) {
        out.add(text.substring(last, i));
        last = i + 1;
      }
    }
    if (last < text.length() || !out.isEmpty()) out.add(text.substring(last));
    return out;
  }

  // ───────────────────────────── type resolution ─────────────────────────────

  static TypeRef platformRef(String qualified) {
    AndroidApiIndex.ClassInfo info = AndroidApiIndex.classByQualifiedName(qualified);
    if (info == null) return null;
    TypeRef ref = new TypeRef();
    ref.platform = info;
    return ref;
  }

  /** Resolves a written type in the context of {@code imports}; null for primitives/unknown. */
  static TypeRef resolveType(Scope scope, String written, List<String> imports) {
    if (written == null) return null;
    String w = written.replaceAll("@[\\w$.]+\\s*", "").trim();
    int dims = 0;
    while (w.endsWith("[]")) {
      dims++;
      w = w.substring(0, w.length() - 2).trim();
    }
    if (w.endsWith("...")) {
      dims++;
      w = w.substring(0, w.length() - 3);
    }
    String base = AndroidApiIndex.stripGenerics(w).trim();
    if (base.isEmpty() || base.equals("var") || (PRIMITIVES.contains(base) && dims == 0)) return null;
    TypeRef ref = new TypeRef();
    ref.arrayDims = dims;
    if (PRIMITIVES.contains(base)) return ref;
    String simple = base.substring(base.lastIndexOf('.') + 1);
    if (scope != null && (base.indexOf('.') < 0 || base.startsWith(scope.outline.packageName + "."))) {
      JavaSourceOutline.Type local = scope.outline.type(simple);
      if (local != null) {
        ref.source = local;
        return ref;
      }
    }
    // Java's order: the file's own package comes before on-demand imports (R of the app, M4).
    if (scope != null && !scope.outline.packageName.isEmpty()) {
      ArrayList<String> withPackage = new ArrayList<>(imports == null ? Collections.<String>emptyList() : imports);
      withPackage.add(0, scope.outline.packageName + ".*");
      imports = withPackage;
    }
    ProjectSymbolIndex.ProjectClass project = ProjectSymbolIndex.projectClass(simple);
    AndroidApiIndex.ClassInfo platform = null;
    if (project != null && base.indexOf('.') > 0) {
      String qualified = project.packageName.isEmpty() ? simple : project.packageName + "." + simple;
      if (!qualified.equals(base)) {
        platform = AndroidApiIndex.resolve(base, imports);
        if (platform != null) project = null;
      }
    }
    if (project != null) {
      ref.project = project;
      return ref;
    }
    if (platform == null) platform = AndroidApiIndex.resolve(base, imports);
    if (platform == null) return null;
    ref.platform = platform;
    ref.typeArgs = bind(platform, w);
    return ref;
  }

  // ───────────────────────────── receiver evaluation ─────────────────────────────

  /** Type of the expression ending right before the dot at {@code dot}. */
  static TypeRef evaluateReceiver(Scope scope, int dot) {
    int end = dot;
    int literalEnd = dot;
    while (literalEnd > 0 && Character.isWhitespace(scope.text.charAt(literalEnd - 1))) literalEnd--;
    if (literalEnd > 0 && scope.text.charAt(literalEnd - 1) == '"') return platformRef("java.lang.String");
    while (end > 0 && Character.isWhitespace(scope.masked.charAt(end - 1))) end--;
    int start = receiverStart(scope.masked, end);
    if (start >= end) return null;
    String expression = scope.masked.substring(start, end);
    boolean isNew = endsWithWord(scope.masked, start, "new");
    if (isNew) expression = "new " + expression;
    return evaluate(scope, expression.trim());
  }

  private static int receiverStart(String code, int end) {
    int i = end;
    while (i > 0) {
      char c = code.charAt(i - 1);
      if (c == ')' || c == ']') {
        int open = matchBackward(code, i - 1);
        if (open < 0) return i;
        i = open;
        continue;
      }
      if (Character.isJavaIdentifierPart(c)) {
        while (i > 0 && Character.isJavaIdentifierPart(code.charAt(i - 1))) i--;
      } else if (c == '>') {
        int open = matchAngleBackward(code, i - 1);
        if (open < 0) return i;
        i = open;
        continue;
      } else return i;
      int j = i;
      while (j > 0 && Character.isWhitespace(code.charAt(j - 1))) j--;
      if (j > 0 && code.charAt(j - 1) == '.') {
        i = j - 1;
        while (i > 0 && Character.isWhitespace(code.charAt(i - 1))) i--;
        continue;
      }
      return i;
    }
    return i;
  }

  private static int matchBackward(String code, int close) {
    char closing = code.charAt(close);
    char opening = closing == ')' ? '(' : '[';
    int depth = 0;
    for (int i = close; i >= 0; i--) {
      char c = code.charAt(i);
      if (c == closing) depth++;
      else if (c == opening && --depth == 0) return i;
    }
    return -1;
  }

  private static int matchAngleBackward(String code, int close) {
    int depth = 0;
    for (int i = close; i >= 0 && close - i < 200; i--) {
      char c = code.charAt(i);
      if (c == '>') depth++;
      else if (c == '<' && --depth == 0) return i;
      else if (c == ';' || c == '{' || c == '}') return -1;
    }
    return -1;
  }

  private static final Pattern CAST = Pattern.compile("^\\(\\s*\\(\\s*([\\w$.<>\\[\\], ?]+?)\\s*\\)\\s*[\\s\\S]+\\)$");

  static TypeRef evaluate(Scope scope, String expression) {
    List<String> segments = splitSegments(expression);
    if (segments.isEmpty()) return null;
    TypeRef current = null;
    int index = 0;
    String first = segments.get(0).trim();
    if (first.startsWith("new ")) {
      String created = first.substring(4).trim();
      int paren = created.indexOf('(');
      int bracket = created.indexOf('[');
      if (bracket >= 0 && (paren < 0 || bracket < paren)) {
        current = resolveType(scope, created.substring(0, bracket), scope.outline.imports);
        if (current == null) current = new TypeRef();
        current.arrayDims = 1;
      } else {
        current = resolveType(scope, paren < 0 ? created : created.substring(0, paren), scope.outline.imports);
      }
      index = 1;
    } else if (first.startsWith("(")) {
      Matcher cast = CAST.matcher(first);
      if (cast.find()) current = resolveType(scope, cast.group(1), scope.outline.imports);
      else if (first.endsWith(")")) current = evaluate(scope, first.substring(1, first.length() - 1).trim());
      index = 1;
    } else if (first.equals("this")) {
      current = selfRef(scope.current);
      index = 1;
    } else if (first.equals("super")) {
      current = scope.current == null ? null
          : resolveType(scope, scope.current.superName.isEmpty() ? "java.lang.Object" : scope.current.superName, scope.outline.imports);
      index = 1;
    } else {
      String name = segmentName(first);
      if (first.contains("(")) {
        current = methodReturn(scope, selfChain(scope), name, argumentCount(first), true);
        index = 1;
      } else {
        current = variableType(scope, name);
        if (current != null) {
          current = applyIndexing(current, first);
          index = 1;
        } else {
          // Class name, or a qualified name such as android.widget.Toast / View.OnClickListener.
          StringBuilder qualified = new StringBuilder();
          for (int k = 0; k < segments.size(); k++) {
            String seg = segments.get(k).trim();
            if (seg.contains("(") || seg.contains("[")) break;
            if (qualified.length() > 0) qualified.append('.');
            qualified.append(seg);
            TypeRef type = resolveType(scope, qualified.toString(), scope.outline.imports);
            if (type != null) {
              current = type;
              current.staticRef = true;
              index = k + 1;
              // keep extending while nested types resolve (View.OnClickListener)
              for (int n = k + 1; n < segments.size(); n++) {
                String nestedName = segments.get(n).trim();
                if (nestedName.contains("(") || nestedName.isEmpty()) break;
                if (!Character.isUpperCase(nestedName.charAt(0)) && !isLowercaseNestedType(current, nestedName)) break;
                TypeRef nested = resolveType(scope, qualified + "." + nestedName, scope.outline.imports);
                if (nested == null && current.source != null) {
                  for (JavaSourceOutline.Type t : current.source.nested)
                    if (t.name.equals(nestedName)) {
                      nested = new TypeRef();
                      nested.source = t;
                    }
                }
                if (nested == null) break;
                qualified.append('.').append(nestedName);
                current = nested;
                current.staticRef = true;
                index = n + 1;
              }
              break;
            }
          }
          if (current == null) return null;
        }
      }
    }
    for (int k = index; k < segments.size() && current != null; k++) {
      String seg = segments.get(k).trim();
      String name = segmentName(seg);
      if (current.arrayDims > 0 && name.equals("length") && !seg.contains("(")) return null;
      TypeRef next;
      if (seg.contains("(")) next = methodReturn(scope, Collections.singletonList(current), name, argumentCount(seg), false);
      else if (name.equals("class") && current.staticRef) next = platformRef("java.lang.Class");
      else next = fieldType(scope, current, name);
      current = next == null ? null : applyIndexing(next, seg);
    }
    return current;
  }

  /**
   * {@code R.string}: a lower-case nested class of an indexed type (android.R, a library R, the
   * app's R). As in Java, a field of the same name would win, so then it is not a type.
   */
  private static boolean isLowercaseNestedType(TypeRef type, String name) {
    if (type == null || type.platform == null) return false;
    for (AndroidApiIndex.Member m : AndroidApiIndex.declaredMembers(type.platform))
      if (m.kind == AndroidApiIndex.Member.FIELD && m.name.equals(name)) return false;
    for (AndroidApiIndex.ClassInfo nested : AndroidApiIndex.nestedClasses(type.platform))
      if (nested.simpleName.equals(name)) return true;
    return false;
  }

  private static TypeRef applyIndexing(TypeRef type, String segment) {
    int count = 0;
    int depth = 0;
    for (int i = 0; i < segment.length(); i++) {
      char c = segment.charAt(i);
      if (c == '(') depth++;
      else if (c == ')') depth--;
      else if (c == '[' && depth == 0) count++;
    }
    if (count == 0) return type;
    type.arrayDims = Math.max(0, type.arrayDims - count);
    if (type.arrayDims == 0 && type.source == null && type.project == null && type.platform == null) return null;
    return type;
  }

  private static TypeRef selfRef(JavaSourceOutline.Type type) {
    if (type == null) return null;
    TypeRef ref = new TypeRef();
    ref.source = type;
    return ref;
  }

  private static List<TypeRef> selfChain(Scope scope) {
    ArrayList<TypeRef> out = new ArrayList<>();
    for (JavaSourceOutline.Type t = scope.current; t != null; t = t.outer) out.add(selfRef(t));
    return out;
  }

  private static String segmentName(String segment) {
    int i = 0;
    while (i < segment.length() && Character.isJavaIdentifierPart(segment.charAt(i))) i++;
    return segment.substring(0, i);
  }

  private static int argumentCount(String segment) {
    int open = segment.indexOf('(');
    int close = segment.lastIndexOf(')');
    if (open < 0 || close <= open) return 0;
    String args = segment.substring(open + 1, close).trim();
    return args.isEmpty() ? 0 : splitTopLevel(args).size();
  }

  /** Splits "a.b(c.d).e[0]" at top-level dots. */
  private static List<String> splitSegments(String expression) {
    ArrayList<String> out = new ArrayList<>();
    int depth = 0;
    int last = 0;
    for (int i = 0; i < expression.length(); i++) {
      char c = expression.charAt(i);
      if (c == '(' || c == '[' || c == '<') depth++;
      else if (c == ')' || c == ']' || c == '>') depth--;
      else if (c == '.' && depth == 0) {
        out.add(expression.substring(last, i));
        last = i + 1;
      }
    }
    out.add(expression.substring(last));
    ArrayList<String> clean = new ArrayList<>();
    for (String s : out) {
      String t = s.trim();
      if (t.startsWith("<")) { // explicit type arguments: this.<T>foo()
        int gt = t.indexOf('>');
        t = gt >= 0 ? t.substring(gt + 1).trim() : t;
      }
      if (!t.isEmpty()) clean.add(t);
    }
    return clean;
  }

  private static TypeRef variableType(Scope scope, String name) {
    for (JavaSourceOutline.Local local : scope.locals)
      if (local.name.equals(name)) return resolveType(scope, local.type, scope.outline.imports);
    for (TypeRef self : selfChain(scope)) {
      TypeRef type = fieldType(scope, self, name);
      if (type != null) return type;
    }
    return null;
  }

  /** Type of field {@code name} declared in {@code owner} or its supertypes. */
  private static TypeRef fieldType(Scope scope, TypeRef owner, String name) {
    return memberType(scope, owner, name, -2, new HashSet<>());
  }

  private static TypeRef methodReturn(Scope scope, List<TypeRef> owners, String name, int argc, boolean fallbackOuter) {
    for (TypeRef owner : owners) {
      TypeRef type = memberType(scope, owner, name, argc, new HashSet<>());
      if (type != null) return type;
    }
    return null;
  }

  /** argc == -2 → field lookup; otherwise a method with that many arguments (any if none fits). */
  private static TypeRef memberType(Scope scope, TypeRef owner, String name, int argc, Set<String> visited) {
    if (owner == null || !visited.add(owner.simpleName())) return null;
    boolean wantField = argc == -2;
    if (owner.source != null) {
      JavaSourceOutline.Type t = owner.source;
      if (wantField) {
        for (JavaSourceOutline.Field f : t.fields) if (f.name.equals(name)) return resolveType(scope, f.type, scope.outline.imports);
      } else {
        JavaSourceOutline.Method best = null;
        for (JavaSourceOutline.Method m : t.methods)
          if (m.name.equals(name) && (best == null || paramCount(m.parameters) == argc)) best = m;
        if (best != null) return resolveType(scope, best.returnType, scope.outline.imports);
      }
      if (t.kind.equals("enum") && !wantField && (name.equals("values") || name.equals("valueOf") && argc == 1))
        return resolveType(scope, name.equals("values") ? t.name + "[]" : t.name, scope.outline.imports);
      List<String> supers = new ArrayList<>();
      if (!t.superName.isEmpty()) supers.add(t.superName);
      supers.addAll(t.interfaces);
      supers.add("java.lang.Object");
      for (String sup : supers) {
        TypeRef found = memberType(scope, resolveType(scope, sup, scope.outline.imports), name, argc, visited);
        if (found != null) return found;
      }
      return null;
    }
    if (owner.project != null) {
      ProjectSymbolIndex.ProjectClass p = owner.project;
      String type = wantField ? p.fields.get(name) : p.methodReturns.get(name);
      if (type != null && !(wantField ? false : NOT_RETURN_TYPES.contains(type))
          && !(!wantField && SYNTHETIC_OBJECT_METHODS.contains(name) && p.methodParameters.getOrDefault(name, "").isEmpty()))
        return resolveType(scope, type, p.imports);
      List<String> supers = new ArrayList<>(p.supertypes);
      if (supers.isEmpty() && !p.superName.isEmpty()) supers.add(p.superName);
      supers.add("java.lang.Object");
      for (String sup : supers) {
        TypeRef found = memberType(scope, resolveType(scope, sup, p.imports), name, argc, visited);
        if (found != null) return found;
      }
      return null;
    }
    if (owner.platform != null) return platformMemberType(owner.platform, owner.typeArgs, name, argc, new HashSet<>());
    return null;
  }

  private static TypeRef platformMemberType(AndroidApiIndex.ClassInfo info, Map<String, String> args, String name,
      int argc, Set<String> visited) {
    if (info == null || !visited.add(info.qualifiedName)) return null;
    AndroidApiIndex.Member best = null;
    for (AndroidApiIndex.Member m : AndroidApiIndex.declaredMembers(info)) {
      if (!m.name.equals(name)) continue;
      if (argc == -2 ? m.kind != AndroidApiIndex.Member.FIELD : m.kind != AndroidApiIndex.Member.METHOD) continue;
      if (best == null || (argc >= 0 && paramCount(m.parameters) == argc && paramCount(best.parameters) != argc)) best = m;
    }
    if (best != null) {
      String type = substitute(best.type, args);
      TypeRef ref = resolveType(null, type, Collections.<String>emptyList());
      if (ref == null && args != null && !args.isEmpty()) return null;
      return ref;
    }
    if (!info.superName.isEmpty()) {
      AndroidApiIndex.ClassInfo sup = AndroidApiIndex.classByQualifiedName(info.superName);
      TypeRef found = platformMemberType(sup, bind(sup, substitute(info.superName, args)), name, argc, visited);
      if (found != null) return found;
    }
    for (String iface : info.interfaces) {
      AndroidApiIndex.ClassInfo i = AndroidApiIndex.classByQualifiedName(iface);
      TypeRef found = platformMemberType(i, bind(i, substitute(iface, args)), name, argc, visited);
      if (found != null) return found;
    }
    if (info.isInterface()) return platformMemberType(AndroidApiIndex.classByQualifiedName("java.lang.Object"),
        Collections.emptyMap(), name, argc, visited);
    return null;
  }

  private static int paramCount(String params) {
    return params == null || params.trim().isEmpty() ? 0 : splitTopLevel(params).size();
  }
}
