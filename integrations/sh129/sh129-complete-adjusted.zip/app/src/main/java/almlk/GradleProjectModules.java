package almlk;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * وحداتُ المشروعِ المعلَنةُ في {@code settings.gradle}: خريطةُ «اسمُ الوحدةِ ← مجلدُها» وما يترتّبُ
 * عليها من نماذجَ ونوافذَ بحثٍ.
 *
 * <p>Gradleُ يجعلُ كلَّ {@code include ':x'} عضوًا في نفسِ مجموعةِ الوحداتِ، ومرجعُها إلى أخرياتِها
 * بسطرِ {@code implementation project(':y')}؛ ولا شيءَ يُستنتَجُ من القرصِ وحدَهُ: فلا مجلدٌ يُفهرَسُ
 * لم تُعلِنْهُ الإعداداتُ، ولا اعتمادٌ يُطلَبْ لم يُعلِنْهُ ملفُّ بناءٍ. لذا تُقرأُ الإدراجَاتُ
 * بآلةِ الربطِ نفسِها ({@link GradleLibraryLinks#includedModules(File)}) — لا مُحلِّلًا ثانيًا — ثمَّ
 * يُحمَّلُ لكلِّ وحدةٍ نموذجُها، ويُحسَبُ ما يَبلُغُهُ المنادِي بتكرارٍ مُقيَّدٍ.
 *
 * <p>سقفانِ صريحانِ يحميانِ الخفّةَ: {@value #MAX_MODULES} وحدةً و{@value #MAX_DEPTH} مستوىً،
 * ومانعُ دوراتٍ بمجموعةِ ما زارَهُ التفقّدُ؛ وما لا يُحَلُّ لا يُرفَضُ بل يُخبَرُ عنهُ
 * بـ{@link Issue#reason} (مبدأُ الإثباتِ). جافا خالصةٌ بلا Androidَ.
 */
public final class GradleProjectModules {

  /** أقصى عددِ وحداتٍ تُحمَّلُ نماذجُها للدورةِ الواحدةِ. */
  public static final int MAX_MODULES = 12;
  /** أقصى عمقٍ للتكرارِ عبرَ سطورِ {@code project(':…')}. */
  public static final int MAX_DEPTH = 6;
  /** كم مجلدَ مصادرَ يُقبَلُ من كلِّ الوحداتِ في المسحةِ الواحدةِ (لا انفلاتَ شجرةٍ غريبةٍ). */
  public static final int MAX_SOURCE_DIRS = 36;

  /** وحدةٌ مُعلَنةٌ: مجلدُها، ونموذجُها إن كانَ لهُ ملفُّ بناءٍ، وسببُ التعذّرِ إن كانَ. */
  public static final class Module {
    /** الاسمُ كما في {@code include} (بلا نقطتَينِ رئيستينِ مُقدِّمتينِ). */
    public final String name;
    /** مجلدُ الوحدةِ — مُسَوًّى ومطلقٌ، كما رأتَهُ {@code projectDir} أو الافتراضُ. */
    public final File dir;
    /** نموذجُ الوحدةِ، أو {@code null} إن لا ملفَّ بناءَ. */
    public final GradleBuildModel model;
    /** سببٌ مسمًّى عندَ التعذّرِ، وإلا {@code null}. */
    public final String issue;

    Module(String name, File dir, GradleBuildModel model, String issue) {
      this.name = name;
      this.dir = dir;
      this.model = model;
      this.issue = issue;
    }

    public boolean loaded() {
      return model != null;
    }

    @Override
    public String toString() {
      return name + " → " + (model != null ? "نموذجٌ" : issue);
    }
  }

  /** ما لا يُحَلُّ: سطرُ {@code project(':ghost')} بلا وحدةٍ بهذا الاسمِ، أو مُدرَجٌ بلا بناءٍ. */
  public static final class Issue {
    /** {@code project} لسطرِ اعتمادٍ، و{@code include} لسطرِ إعداداتٍ. */
    public final String kind;
    public final String path;
    public final File file;
    public final int line;
    public final String reason;
    /**
     * نصُّ السطرِ كما قُرِئَ وقتَ الحلِّ، تُعرضُ في اللوحةِ بلا قرصٍ في خيطِ الواجهةِ؛
     * فارغٌ إن لم يكنِ النصُّ تحتَ اليدِ (سطرُ ‏{@code include} المفقودِ مثلًا).
     */
    public final String lineText;
    /** عمودُ البدايةِ من 1 (1 حينَ لا موضعَ معروفَ لهُ). */
    public final int column;

    Issue(String kind, String path, File file, int line, String reason) {
      this(kind, path, file, line, reason, "", 1);
    }

    Issue(String kind, String path, File file, int line, String reason, String lineText, int column) {
      this.kind = kind;
      this.path = path;
      this.file = file;
      this.line = line;
      this.reason = reason;
      this.lineText = lineText == null ? "" : lineText;
      this.column = Math.max(1, column);
    }

    @Override
    public String toString() {
      return kind + " " + path + " — " + reason;
    }
  }

  /**
   * سطرُ ملفٍ (من 1) كما هو — بلا ‏{@code trim} يُفقدُ المحاذاةَ؛ وإن خرجَ الرقمُ عن
   * النصِّ فـ{@code ""}: تُعرَضُ الرسالةُ وحدَها ولا تُختلَقُ مواضعُ كاذبةٌ.
   */
  public static String lineAt(String text, int line) {
    if (text == null || line < 1) return "";
    int at = 0;
    for (int seen = 1; seen < line; seen++) {
      int next = text.indexOf('\n', at);
      if (next < 0) return "";
      at = next + 1;
    }
    int end = text.indexOf('\n', at);
    String out = end < 0 ? text.substring(at) : text.substring(at, end);
    return out.endsWith("\r") ? out.substring(0, out.length() - 1) : out;
  }

  /**
   * سطرُ إزاحةٍ (من 1) — كالذي تحسبُهُ علاماتُ الاعتمادِ: العددُ من النصِّ لا من رقمٍ
   * موروثٍ عن الماشي، وإلا دلّتِ اللوحةُ على سطرِ جارتِها.
   */
  public static int lineNumberOf(String text, int offset) {
    if (text == null || text.isEmpty()) return 1;
    int at = Math.max(0, Math.min(offset, text.length() - 1));
    int line = 1;
    for (int i = 0; i < at; i++) if (text.charAt(i) == '\n') line++;
    return line;
  }

  /** عمودُ ‏{@code needle} إن ظهرَ في السطرِ، وإلا عمودُ أولِ غيرِ مسافةٍ، وإلا 1. */
  public static int columnAt(String lineText, String needle) {
    if (lineText == null || lineText.isEmpty()) return 1;
    if (needle != null && !needle.isEmpty()) {
      int at = lineText.indexOf(needle);
      if (at >= 0) return at + 1;
    }
    for (int i = 0; i < lineText.length(); i++) {
      if (!Character.isWhitespace(lineText.charAt(i))) return i + 1;
    }
    return 1;
  }

  private static final GradleProjectModules EMPTY = new GradleProjectModules(
      Collections.<Module>emptyList(), Collections.<Module>emptyList(), Collections.<Issue>emptyList());

  private final List<Module> declared;
  private final List<Module> analysis;
  private final List<Issue> issues;

  private GradleProjectModules(List<Module> declared, List<Module> analysis, List<Issue> issues) {
    this.declared = Collections.unmodifiableList(declared);
    this.analysis = Collections.unmodifiableList(analysis);
    this.issues = Collections.unmodifiableList(issues);
  }

  /** حالةٌ فارغةٌ صريحةٌ: مشروعٌ بلا {@code settings.gradle} أو بلا وحداتٍ أُخرَ. */
  public static GradleProjectModules empty() {
    return EMPTY;
  }

  /**
   * يبني المغلَّقَ من نموذجِ الوحدةِ المنادِيَة. لا قرصَ زائدَ على ما تُعلِنُهُ الإعداداتُ؛ ولا
   * استثناءاتٍ تُرمى: ملفٌّ لا يُقرأُ يصيرُ {@link Issue}، ونموذجُ الوحدةِ يبقى كما هو.
   */
  public static GradleProjectModules of(GradleBuildModel caller) {
    return of(caller, null);
  }

  /**
   * كما {@link #of(GradleBuildModel)}، ويزيدُ عليهِ مُقرِئَ حزمةٍ يُمِدُّ بهِ الغلافُ الأندرويديُّ
   * ليُقالَ مَن وقَّعَ ما على القرصِ من مُخرَجٍ؛ وبدونِهِ تَسكُتُ الطبقةُ عن الموقِّعِ لا تَشكو.
   */
  public static GradleProjectModules of(GradleBuildModel caller, ApkArtifacts.SignerReader reader) {
    if (caller == null || caller.projectRoot == null) return EMPTY;
    List<GradleLibraryLinks.Link> links = GradleLibraryLinks.includedModules(caller.projectRoot);
    if (links.isEmpty()) return EMPTY;

    Map<String, Module> byName = new LinkedHashMap<>();
    List<Module> declared = new ArrayList<>();
    List<Issue> issues = new ArrayList<>();
    String callerDir = canonical(caller.moduleDir);
    int taken = 0;
    for (GradleLibraryLinks.Link link : links) {
      if (link == null || link.name == null || link.name.isEmpty()) continue;
      String key = key(link.name);
      if (byName.containsKey(key)) continue;
      if (canonical(link.dir).equals(callerDir)) {
        byName.put(key, new Module(link.name, link.dir, caller, null));
        continue;
      }
      GradleBuildModel moduleModel = null;
      String issue = null;
      if (taken >= MAX_MODULES) {
        issue = "over the module limit (" + MAX_MODULES + ")";
      } else {
        if (GradleDependencyEditor.buildFileIn(link.dir) == null) {
          issue = "no build file in folder";
        } else {
          taken++;
          try {
            moduleModel = GradleBuildModel.load(link.dir);
          } catch (RuntimeException failure) {
            issue = "unreadable build file: " + failure;
          }
          if (moduleModel == null) issue = "no build file in folder";
        }
      }
      Module module = new Module(link.name, link.dir, moduleModel, issue);
      byName.put(key, module);
      declared.add(module);
      if (issue != null) {
        File settings = GradleLibraryLinks.settingsFileIn(caller.projectRoot);
        issues.add(new Issue("include", link.name,
            settings == null ? new File(caller.projectRoot, "settings.gradle") : settings, -1, issue));
      }
    }

    // ما يَبلُغُهُ المنادِي: تكرارٌ عبرَ سطورِ project(':…') بمانعِ دوراتٍ وسقفِ عمقٍ.
    List<Module> reachable = new ArrayList<>();
    Set<String> visited = new HashSet<>();
    List<GradleBuildModel> frontier = new ArrayList<>();
    frontier.add(caller);
    for (int depth = 0; depth < MAX_DEPTH && !frontier.isEmpty(); depth++) {
      List<GradleBuildModel> next = new ArrayList<>();
      for (GradleBuildModel source : frontier) {
        if (source == null || !visited.add(canonical(source.moduleDir))) continue;
        for (GradleBuildModel.Dependency d : source.dependencies) {
          if (d == null || d.kind != GradleBuildModel.Kind.PROJECT) continue;
          String key = key(d.notation);
          Module target = key.isEmpty() ? null : byName.get(key);
          if (target == null || target.issue != null) {
            // الإزاحةُ هي المرجعُ: رقمُ السطرِ في الماشي عدٌّ داخليٌّ، واللوحةُ تريدُ سطرَ
            // المستخدمِ — فيُحسَبُ من النصِّ كما تُحسَبُ علاماتُ أسطرِ الاعتمادِ.
            int line = lineNumberOf(source.text, d.start);
            String at = lineAt(source.text, line);
            String needle = d.rawNotation == null || d.rawNotation.isEmpty() ? d.notation : d.rawNotation;
            issues.add(new Issue("project", d.notation, source.buildFile, line,
                target == null ? "no included module named " + display(d.notation) : target.issue,
                at, columnAt(at, needle)));
            continue;
          }
          if (visited.contains(canonical(target.dir))) continue;
          reachable.add(target);
          next.add(target.model);
        }
      }
      frontier = next;
    }
    List<Module> linked = dedupeModules(reachable);
    // حزمةُ الوحدةِ بلا واسطةٍ: صنفُ ‏`R` لا اسمَ لهُ من دونِها، فتنطفئُ مواردُ الوحدةِ
    // صامتةً. تُذكَرُ الوحدةُ بالاسمِ على سطرِ ما ينقصُهُ — تحذيرًا في اللوحةِ لا خطأً:
    // قرارُ البناءِ للمستخدمِ لا لنا.
    for (Module module : linked) {
      if (module == null || module.model == null) continue; // له سطرُ الإرجاءِ وحدَهُ
      // الحزمةُ تعني صنفَ ‏`R`؛ ولا ‏`R` لوحدةِ جافانٍ أو كوتلِنَ خالصةٍ — فلا حُكمَ عليها.
      if (!wantsAndroidPackage(module.model)) continue;
      if (!LibraryClassIndex.appPackage(module.model).isEmpty()) continue;
      File manifest = AndroidManifestModel.find(module.dir,
          GradleSourceSets.of(module.model.text).manifestFile);
      boolean hasManifest = manifest != null;
      String text = hasManifest ? LibraryClassIndex.readText(manifest) : module.model.text;
      String needle = hasManifest ? "<manifest" : "android {";
      int mark = text.indexOf(needle);
      int line = Math.max(1, lineNumberOf(text, mark));
      String at = lineAt(text, line);
      issues.add(new Issue("manifest", module.name, hasManifest ? manifest : module.model.buildFile, line,
          hasManifest
              ? "no package= in AndroidManifest.xml and no namespace in build file of " + display(module.name)
              : "no namespace in build file and no AndroidManifest.xml in " + display(module.name),
          at, mark < 0 ? 1 : Math.max(1, at.indexOf(hasManifest ? "<manifest" : "android") + 1)));
    }
    // توقيعُ الوحدةِ كما تعلنُهُ هي: لا نبني ولا نوقِّعُ ولا نفتحُ مخزنًا — نُخبِرُ عمّا لا
    // ملفَّ لهُ المسارَ، وعمّا لا تعريفَ لهُ الربطَ، وعمّا أُعلِنَتِ التكويناتُ ولم يستعملْها
    // نمطُ ‏`release`. كلُّ ذلكَ علامةٌ في اللوحةِ على سطرِ الإعلانِ، لا خطأُ بناءٍ.
    ArrayList<Module> signingScope = new ArrayList<>();
    for (Module module : linked) signingScope.add(module);
    for (Module module : byName.values()) {
      // نمطُ المُنادِي أوّلُ من يُوقَّعُ، و‏`linked` لا تضمُّهُ — فعلامتُهُ تُلقَى من هنا
      if (module != null && module.model == caller && !signingScope.contains(module)) signingScope.add(module);
    }
    for (Module module : signingScope) {
      if (module == null || module.model == null) continue;
      GradleSigningConfigs.Model signing = GradleSigningConfigs.of(module.model.text);
      // ما ترَكَهُ البناءُ على القرصِ يُجْلَمُ قبلَ الحُكمِ على التوقيعِ: المُخرَجاتُ تَوجَدُ ولو لم
      // يُعلَنْ توقيعٌ. لا نِداءَ بناءٍ، ولا كتابةَ، ولا مشيَ على الشجرةِ كلِّها: وثيقةُ
      // output.json وحدَها وما تُسَمِّيهِ، وما في bin/ من قديمِ الأداةِ. والعجزُ علامتانِ لا أكثرُ.
      ApkArtifacts.Result outputs = ApkArtifacts.of(module.dir, reader);
      String forOutputs = module.model.text == null ? "" : module.model.text;
      int outMark = forOutputs.indexOf("signingConfigs");
      if (outMark < 0) outMark = forOutputs.indexOf("buildTypes");
      int outLine = Math.max(1, lineNumberOf(forOutputs, outMark));
      String outAt = lineAt(forOutputs, outLine);
      for (String problem : outputs.problems()) {
        issues.add(new Issue("artifacts", module.name, module.model.buildFile, outLine,
            display(module.name) + ": " + problem, outAt, 1));
      }
      if (!signing.configs.isEmpty() && !signing.configFor("release").isEmpty()
          && !outputs.hasReleaseApk() && !outputs.hasReleaseRecord()) {
        issues.add(new Issue("artifacts", module.name, module.model.buildFile, outLine,
            "release signing is declared in " + display(module.name)
                + " but no release apk is on disk yet (" + ApkArtifacts.Result.describeDirs() + ')',
            outAt, 1));
      }
      if (!signing.declaresConfigsBlock) continue;
      String text = module.model.text == null ? "" : module.model.text;
      for (GradleSigningConfigs.Config config : signing.configs) {
        if (config == null) continue;
        File store = GradleSigningConfigs.resolveStore(module.dir, module.model.projectRoot,
            config.storeFile, config.fromRootProject);
        if (store == null) {
          int mark = text.indexOf("signingConfigs");
          issues.add(new Issue("signing", module.name, module.model.buildFile,
              Math.max(1, lineNumberOf(text, mark)),
              "signingConfig " + config.name + " in " + display(module.name)
                  + " declares no storeFile"));
          continue;
        }
        if (store.isFile()) continue;
        int mark = config.storeFileOffset >= 0 ? config.storeFileOffset : text.indexOf("storeFile");
        int line = Math.max(1, lineNumberOf(text, mark));
        String at = lineAt(text, line);
        int col = at.indexOf(config.storeFile);
        issues.add(new Issue("signing", module.name, module.model.buildFile, line,
            "storeFile of signingConfig " + config.name + " in " + display(module.name)
                + " does not exist on disk: " + config.storeFile,
            at, col < 0 ? 1 : Math.max(1, col + 1)));
      }
      for (GradleSigningConfigs.Binding binding : signing.bindings) {
        if (binding == null || !binding.dangling) continue;
        int line = Math.max(1, lineNumberOf(text, binding.offset));
        String at = lineAt(text, line);
        int col = at.indexOf("signingConfig");
        issues.add(new Issue("signing", module.name, module.model.buildFile, line,
            "buildTypes." + binding.buildType + " of " + display(module.name)
                + " uses signingConfigs." + binding.configName + ", which the file never defines",
            at, col < 0 ? 1 : Math.max(1, col + 1)));
      }
      if (!signing.configs.isEmpty() && signing.typeWithoutConfig("release")) {
        int mark = text.indexOf("buildTypes");
        int line = Math.max(1, lineNumberOf(text, mark));
        String at = lineAt(text, line);
        issues.add(new Issue("signing", module.name, module.model.buildFile, line,
            "signingConfigs are declared in " + display(module.name)
                + " but buildTypes.release uses none of them", at,
            Math.max(1, at.indexOf("buildTypes") + 1)));
      }
      // ما وُجِدَ من المخازنِ يُقرَأُ ههُنا، في خيطِ الخلفيّةِ الذي يملأُ اللوحةَ: اسماءُ مفاتيحَ
      // وشهاداتٌ وسريانٌ. لا محاوارَ سرٍّ ولا أداةَ خارجيّةً ولا كتابةً على القرصِ: إن أُعلِنَ
      // السرُّ في المِلَفِّ قُرِئَ وقتَ الفتحِ فقطْ ثمَّ مُمِحِيَ، وما لا يُفتَحُ علامةٌ لا خطأُ بناءٍ.
      for (GradleSigningConfigs.Config config : signing.configs) {
        if (config == null || config.storeFile.isEmpty()) continue;
        File store = GradleSigningConfigs.resolveStore(module.dir, module.model.projectRoot,
            config.storeFile, config.fromRootProject);
        if (store == null || !store.isFile()) continue; // «لا ملفَّ» قالَتهُ طبقةُ الإعلانِ
        char[] secret = GradleSigningConfigs.readStorePassword(module.model.text, config);
        KeystoreInspector.Result keys = secret == null
            ? KeystoreInspector.inspectCached(store)
            : KeystoreInspector.inspect(store, secret);
        int line = Math.max(1, lineNumberOf(text, config.storeFileOffset));
        String at = lineAt(text, line);
        int col = Math.max(1, at.indexOf("storeFile") + 1);
        for (String problem : keys.problems()) {
          issues.add(new Issue("keystore", module.name, module.model.buildFile, line,
              "signingConfig " + config.name + " in " + display(module.name) + ": " + problem,
              at, col));
        }
        if (!config.keyAlias.isEmpty() && keys.opened && !keys.hasAlias(config.keyAlias)) {
          issues.add(new Issue("keystore", module.name, module.model.buildFile, line,
              "keyAlias '" + config.keyAlias + "' of signingConfig " + config.name + " in "
                  + display(module.name) + " is not in " + store.getName() + " " + keys.aliases(),
              at, col));
        }
      }
    }
    return new GradleProjectModules(declared, linked, issues);
  }

  /**
   * هل تُولِّدُ هذهِ الوحدةُ صنفَ ‏{@code R}؟ أي: هل طبّقَت إحدى قيدومتي أندرويد؟
   * مسحٌ نصيٌّ كما تفعلُ {@code transitiveR}: لا حاجةَ إلى محلِّلِ بلوكاتٍ لسؤالٍ واحدٍ.
   */
  static boolean wantsAndroidPackage(GradleBuildModel model) {
    if (model == null || model.text == null) return false;
    return model.text.contains("com.android.application") || model.text.contains("com.android.library");
  }

  /** كلُّ الوحداتِ المعلَنةُ (للبصمةِ والإخبارِ)، بترتيبِ {@code settings.gradle}. */
  public List<Module> declared() {
    return declared;
  }

  /** ما يصلُ إليهِ المنادِي بالتكرارِ: اعتماداتُها و{@code libs/} عندها تدخلُ التحليلَ. */
  public List<Module> forAnalysis() {
    return analysis;
  }

  /** نماذجُ ما يصلُ إليهِ المنادِي، بترتيبِ الوصولِ، بلا تكرارٍ. */
  public List<GradleBuildModel> models() {
    ArrayList<GradleBuildModel> out = new ArrayList<>();
    for (Module module : analysis) if (module.model != null) out.add(module.model);
    return out;
  }

  /** ما لا يُحَلُّ — يُعرَضُ، لا يُرفَضُ بِنيانًا. */
  public List<Issue> issues() {
    return issues;
  }

  public boolean isEmpty() {
    return declared.isEmpty();
  }

  /** هل {@code project(':x')} معروفٌ مُدرَجًا بملفِّ بناءٍ؟ */
  public boolean resolves(String projectPath) {
    Module module = byKey(projectPath);
    return module != null && module.model != null;
  }

  private Module byKey(String projectPath) {
    String key = key(projectPath);
    if (key.isEmpty()) return null;
    for (Module module : declared) if (key(module.name).equals(key)) return module;
    return null;
  }

  /**
   * ذيلُ بصمةِ الحالةِ: ملفاتُ بناءِ الوحداتِ المعلَنةِ وبصمةُ {@code libs/} لكلٍّ منهُا — فحفظُ
   * سطرِ اعتمادٍ داخلَ المكتبةِ يستدعي دورةً، لا بصمةٌ قديمةٌ تكتفي بالمُنادِي.
   */
  public String fingerprintSuffix() {
    if (declared.isEmpty()) return "";
    StringBuilder out = new StringBuilder("|modules=");
    for (Module module : declared) {
      out.append(';').append(module.name).append('@');
      File buildFile = module.dir == null ? null : GradleDependencyEditor.buildFileIn(module.dir);
      if (buildFile != null && buildFile.isFile()) {
        out.append(buildFile.lastModified()).append('/').append(buildFile.length());
      } else {
        out.append('x');
      }
      if (module.dir != null) {
        out.append('/').append(LocalLibraries.signatureOf(
            LocalLibraries.libsDirOf(module.dir, module.dir.getParentFile())));
        // مخرجُ الوحدةِ على القرصِ جزءٌ من البصمةِ: ولادةُ jar جديدةٍ تُعيدُ الدورةَ،
        // وغيابٌ متكرّرٌ لا يُحرِّكُها (لا تُبنى مخرجاتٌ هنا، بل يُنظَرُ ما وُجِدَ).
        out.append('/').append(LocalLibraries.outputsSignature(module.dir));
      }
    }
    return out.toString();
  }

  /** إحداثياتُ ما يصلُ إليهِ المنادِي، بلا تكرارٍ وبترتيبِ الإعلانِ (مع ما للمنادِي نفسِهِ). */
  public List<MavenStore.Coordinate> mergedCoordinates(GradleBuildModel caller) {
    Set<MavenStore.Coordinate> out = new LinkedHashSet<>();
    if (caller != null) out.addAll(caller.analysisCoordinates());
    for (GradleBuildModel model : models()) out.addAll(model.analysisCoordinates());
    return new ArrayList<>(out);
  }

  /** المنادِي ثمَّ ما يصلُ إليهِ: ما تُقرأُ منهُ الاعتماداتُ في حلٍّ وفهرسةٍ. */
  public List<GradleBuildModel> modelsWithCaller(GradleBuildModel caller) {
    ArrayList<GradleBuildModel> out = new ArrayList<>();
    if (caller != null) out.add(caller);
    out.addAll(models());
    return out;
  }

  /**
   * مجلداتُ مصادرِ ما يصلُ إليهِ المنادِي: تخطيطُ ‏Gradle الحديثُ (‏{@code src/main/java} ثمَّ
   * ‏{@code src/main/kotlin}) ثمَّ تخطيطُ ADT القديمُ (‏{@code src} وحدَهُ). لا ‏{@code src/test} ولا
   * ‏{@code src/androidTest} ولا مجموعاتُ البناءِ الأخرى؛ والتخطيطُ الحديثُ يُقصِي القديمَ. فما لم
   * يُفهرَسُ ما أعلنَهُ المشروعُ مصدرًا. الموجودُ فقط، بلا تكرارٍ للكانونِيِّ نفسِهِ، وتحتَ
   * ‏{@value #MAX_SOURCE_DIRS}.
   */
  public List<File> sourceDirs() {
    ArrayList<File> out = new ArrayList<>();
    HashSet<String> seen = new HashSet<>();
    for (Module module : analysis) {
      if (module.dir == null) continue;
      // قولُ المشروعِ أولًا: ما أعلنَهُ ‏`sourceSets { main { java… } }` مصدرًا، ثمَّ العُرفُ
      GradleSourceSets.Declared declared = GradleSourceSets.of(module.model == null ? "" : module.model.text);
      if (!declared.isEmpty()) {
        for (File dir : GradleSourceSets.dirs(module.dir, declared.java)) addSourceDir(out, seen, dir);
        for (File dir : GradleSourceSets.dirs(module.dir, declared.kotlin)) addSourceDir(out, seen, dir);
        if (out.size() >= MAX_SOURCE_DIRS) break;
      }
      // التخطيطُ الحديثُ يُقصِي القديمَ: ‏src يوجدُ دائمًا فوقَ main/java، فمشيُهُ يعني اختبارَ
      // src/test وsrc/debug بلا داعٍ — أيْ فهرسةَ ما لم يعلنهُ المشروعُ مصدرًا لتحليلهِ.
      boolean modern = addSourceDir(out, seen, new File(module.dir, "src/main/java"));
      modern |= addSourceDir(out, seen, new File(module.dir, "src/main/kotlin"));
      if (!modern) addSourceDir(out, seen, new File(module.dir, "src"));
      if (out.size() >= MAX_SOURCE_DIRS) break;
    }
    return out;
  }

  /** مجلداتُ مَصادرِ وحدةٍ واحدةٍ بنفسِ قواعدِ {@link #sourceDirs()} — بلا سقفٍ عالميٍّ ولا تكرارٍ. */
  static List<File> dirsOf(Module module) {
    ArrayList<File> out = new ArrayList<>();
    HashSet<String> seen = new HashSet<>();
    if (module == null || module.dir == null) return out;
    GradleSourceSets.Declared declared =
        GradleSourceSets.of(module.model == null ? "" : module.model.text);
    if (!declared.isEmpty()) {
      for (File dir : GradleSourceSets.dirs(module.dir, declared.java)) addSourceDir(out, seen, dir);
      for (File dir : GradleSourceSets.dirs(module.dir, declared.kotlin)) addSourceDir(out, seen, dir);
    }
    boolean modern = addSourceDir(out, seen, new File(module.dir, "src/main/java"));
    modern |= addSourceDir(out, seen, new File(module.dir, "src/main/kotlin"));
    if (!modern) addSourceDir(out, seen, new File(module.dir, "src"));
    return out;
  }

  /**
   * وحدةُ الملفِّ: أطولُ مطابقةٍ لمجلدِ مَصدرٍ مَذكورٍ تَحسِمُها؛ والتطابقُ في وحدتَينِ يَترُكُها بلا جوابٍ
   * (لا تخمينَ: المُطلِقُ يَعودُ حينَها إلى ملفِّ بناءِ الجذرِ). المُستعرَضُ كلُّ الوحداتِ المُعلَنةِ في
   * ‏{@code settings.gradle} — لا ما يَبلُغُهُ المنادِي وحدَهُ — لأنَّ السطرَ يُكتَبُ حيثُ يسكُنُ الملفُّ. تُستعمَلُ لتوجيهِ سطرِ {@code implementation}
   * إلى الوحدةِ التي تَعرِفُ الصنفَ، كما يَحمِلُ سجلُّ الإصلاحِ عندَ المرجعِ اسمَ الملفِّ لكلِّ عمليةٍ.
   */
  public File moduleDirFor(File sourceFile) {
    if (sourceFile == null) return null;
    String path = canonical(sourceFile);
    if (path.isEmpty()) return null;
    File best = null;
    int bestLength = -1;
    boolean tie = false;
    for (Module module : declared) {
      if (module == null || module.dir == null) continue;
      for (File dir : dirsOf(module)) {
        String prefix = canonical(dir);
        if (prefix.isEmpty()) continue;
        if (!path.startsWith(prefix + File.separator)) continue;
        if (prefix.length() > bestLength) {
          bestLength = prefix.length();
          best = module.dir;
          tie = false;
        } else if (prefix.length() == bestLength && best != null && !best.equals(module.dir)) {
          tie = true;
        }
      }
      if (tie) break;
    }
    return tie ? null : best;
  }

  /** ملفُّ بناءِ وحدةِ الملفِّ؛ {@code null} عندَ الجهلِ — فلا كتابةَ في وحدةٍ بالخطإِ. */
  public File buildFileFor(File sourceFile) {
    File dir = moduleDirFor(sourceFile);
    return dir == null ? null : GradleDependencyEditor.buildFileIn(dir);
  }

  private static boolean addSourceDir(ArrayList<File> out, HashSet<String> seen, File dir) {
    if (out.size() >= MAX_SOURCE_DIRS || !dir.isDirectory()) return false;
    // مفتاحُ واحدٍ لكلِ الطبقةِ: مِسطرةُ canonical الواحدةُ، فلا يُكرَّرُ المسارُ اسمانِ
    if (!seen.add(canonical(dir))) return false;
    out.add(dir);
    return true;
  }

  /**
   * مجلداتُ الوحداتِ الموصولةِ التي تُقرأ منها المواردُ: قائمةُ ‏{@code forAnalysis()}
   * نفسِها، فلا وحدةٌ غيرُ موصولةٍ تُفحَصُ ولا دورةَ اعتمادٍ تُتَّبعُ بلا طائلَ.
   *
   * <p>يُعادُ <em>مجلدُ الوحدةِ</em> لا مجلدُ ‏{@code res} داخلَهُ: الماشي في
   * ‏{@code XmlResourceIndex} يعرفُ ‏{@code src/<set>/res} و{@code res} معًا ويحترمُ
   * استبعادَ ‏{@code build} و{@code .gradle}، فتكرارُ ذلكَ هنا ماكينةُ مسحٍ ثانيةٌ بلا
   * فائدةٍ. ولا جردَ لمجلداتٍ هنا أصلًا — القراءةُ عملُ الفهرسِ. العددُ محدودٌ
   * بـ‏{@value #MAX_MODULES} وحداتٍ فعلًا، والمجلدُ الموجودُ فقط، بلا تكرارٍ.
   */
  public List<File> resourceRoots() {
    ArrayList<File> out = new ArrayList<>();
    HashSet<String> seen = new HashSet<>();
    for (Module module : analysis) {
      if (module.dir == null || !module.dir.isDirectory()) continue;
      if (!seen.add(canonical(module.dir))) continue;
      out.add(module.dir);
      // ‏`res.srcDirs = ['shared-res']` مجلدُ مواردَ خارجَ العُرفِ: يُسلَّمُ جذرًا كما هو،
      // وماشيُ ‏`XmlResourceIndex` يقبلُ الجذرَ الذي هو نفسُهُ مجلدُ مواردَ.
      for (File res : GradleSourceSets.dirs(module.dir, GradleSourceSets.of(
          module.model == null ? "" : module.model.text).res)) {
        if (seen.add(canonical(res))) out.add(res);
      }
    }
    return out;
  }

  /** {@code :a:b} و{@code a:b} و{@code ':a:b'} اسمٌ واحدٌ. */
  static String key(String projectPath) {
    if (projectPath == null) return "";
    String out = projectPath.trim();
    while (out.startsWith("'") || out.startsWith("\"")) out = out.substring(1);
    while (out.endsWith("'") || out.endsWith("\"")) out = out.substring(0, out.length() - 1);
    out = out.trim();
    while (out.startsWith(":")) out = out.substring(1);
    return out;
  }

  private static String display(String projectPath) {
    String key = key(projectPath);
    return key.isEmpty() ? "«»" : "':" + key + "'";
  }

  private static List<Module> dedupeModules(List<Module> in) {
    List<Module> out = new ArrayList<>();
    Set<String> seen = new HashSet<>();
    for (Module module : in) if (module != null && seen.add(canonical(module.dir))) out.add(module);
    return out;
  }

  private static String canonical(File file) {
    if (file == null) return "";
    try {
      return file.getCanonicalFile().getAbsolutePath();
    } catch (java.io.IOException fallback) {
      return file.getAbsolutePath();
    }
  }
}
