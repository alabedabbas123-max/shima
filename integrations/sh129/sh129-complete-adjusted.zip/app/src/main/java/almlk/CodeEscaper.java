package almlk;

/**
 * تهريب الكود (أدوات › تهريب الكود): نص Java داخل علامتي اقتباس، وكيانات XML. التهريب
 * وعكسه متعاكسان تمامًا، والعكس يفهم كل تهريبات Java (و\\uXXXX) وكيانات XML الرقمية.
 */
public final class CodeEscaper {

  private CodeEscaper() {}

  /** فاصل appendLine (صيغة المرجع): كل سطر جديد يُغلق النص ويُكمل بـ «+». */
  static final String LINE_JOIN = "\\n\"\n + \"";

  /** نص ← محتوى نص Java صالح بين «"…"». */
  public static String escapeJava(String text, boolean appendLine) {
    StringBuilder out = new StringBuilder(text.length() + 16);
    for (int i = 0; i < text.length(); i++) {
      char c = text.charAt(i);
      switch (c) {
        case '\\': out.append("\\\\"); break;
        case '"': out.append("\\\""); break;
        case '\'': out.append("\\'"); break;
        case '\n':
          out.append(appendLine && i + 1 < text.length() ? LINE_JOIN : "\\n");
          break;
        case '\r': out.append("\\r"); break;
        case '\t': out.append("\\t"); break;
        case '\b': out.append("\\b"); break;
        case '\f': out.append("\\f"); break;
        default:
          if (c < 0x20 || c == 0x7F) out.append(String.format("\\u%04x", (int) c));
          else out.append(c);
      }
    }
    return out.toString();
  }

  /** عكس {@link #escapeJava}: يفك التهريبات، ويحذف وصلات «"\n + "» بين الأسطر. */
  public static String unescapeJava(String text, boolean appendLine) {
    String source = text;
    if (appendLine) source = source.replaceAll("\"[ \\t]*\\r?\\n[ \\t]*\\+[ \\t]*\"", "");
    StringBuilder out = new StringBuilder(source.length());
    for (int i = 0; i < source.length(); i++) {
      char c = source.charAt(i);
      if (c != '\\' || i + 1 >= source.length()) {
        out.append(c);
        continue;
      }
      char e = source.charAt(++i);
      switch (e) {
        case 'n': out.append('\n'); break;
        case 't': out.append('\t'); break;
        case 'r': out.append('\r'); break;
        case 'b': out.append('\b'); break;
        case 'f': out.append('\f'); break;
        case 's': out.append(' '); break;
        case '\\': out.append('\\'); break;
        case '"': out.append('"'); break;
        case '\'': out.append('\''); break;
        case 'u': {
          int j = i;
          while (j + 1 < source.length() && source.charAt(j + 1) == 'u') j++;
          int code = hex(source, j + 1, 4);
          if (code < 0) {
            out.append('\\').append(e);
          } else {
            out.append((char) code);
            i = j + 4;
          }
          break;
        }
        default:
          if (e >= '0' && e <= '7') {
            int value = e - '0';
            int max = e <= '3' ? 2 : 1;
            while (max-- > 0 && i + 1 < source.length() && source.charAt(i + 1) >= '0' && source.charAt(i + 1) <= '7') {
              value = value * 8 + (source.charAt(++i) - '0');
            }
            out.append((char) value);
          } else {
            out.append('\\').append(e);
          }
      }
    }
    return out.toString();
  }

  private static int hex(String s, int from, int count) {
    if (from + count > s.length()) return -1;
    int value = 0;
    for (int i = from; i < from + count; i++) {
      int d = Character.digit(s.charAt(i), 16);
      if (d < 0) return -1;
      value = value * 16 + d;
    }
    return value;
  }

  /** الكيانات الخمسة. */
  public static String escapeXml(String text) {
    StringBuilder out = new StringBuilder(text.length() + 16);
    for (int i = 0; i < text.length(); i++) {
      char c = text.charAt(i);
      switch (c) {
        case '&': out.append("&amp;"); break;
        case '<': out.append("&lt;"); break;
        case '>': out.append("&gt;"); break;
        case '"': out.append("&quot;"); break;
        case '\'': out.append("&apos;"); break;
        default: out.append(c);
      }
    }
    return out.toString();
  }

  /** فك الكيانات المسماة الخمسة والرقمية (&#NN; و&#xHH;) في مسح واحد فلا يُفك شيء مرتين. */
  public static String unescapeXml(String text) {
    StringBuilder out = new StringBuilder(text.length());
    int i = 0;
    while (i < text.length()) {
      char c = text.charAt(i);
      int semi = c == '&' ? text.indexOf(';', i) : -1;
      if (semi < 0 || semi - i > 12) {
        out.append(c);
        i++;
        continue;
      }
      String name = text.substring(i + 1, semi);
      String value = null;
      switch (name) {
        case "amp": value = "&"; break;
        case "lt": value = "<"; break;
        case "gt": value = ">"; break;
        case "quot": value = "\""; break;
        case "apos": value = "'"; break;
        default:
          if (name.startsWith("#")) {
            try {
              int code = name.startsWith("#x") || name.startsWith("#X")
                  ? Integer.parseInt(name.substring(2), 16)
                  : Integer.parseInt(name.substring(1));
              if (code >= 0 && code <= Character.MAX_CODE_POINT) value = new String(Character.toChars(code));
            } catch (NumberFormatException | IndexOutOfBoundsException notNumeric) {
              value = null;
            }
          }
      }
      if (value == null) {
        out.append(c);
        i++;
      } else {
        out.append(value);
        i = semi + 1;
      }
    }
    return out.toString();
  }
}
