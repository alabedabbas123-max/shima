package almlk;

/**
 * إصدارُ المشروعِ كما قالَ هُوَ، لا كما تَوهَّمَهُ الفاحِصُ (جولةُ ٤١): ‏`minSdk`‏ و‏`compileSdk`‏
 * و‏`targetSdk`‏، وهَلِ المشروعٌ على ‏androidx‏ أم على ‏android.support‏ القديمةِ — من
 * ‏`build.gradle`‏ أولًا ثمَّ من ‏`AndroidManifest.xml`‏ إذا لم يَذْكُرِ الملفُّ شيئًا. للمرجعِ
 * مُقابِلانِ: ‏`GradleInfo(build.gradle)`‏ الذي يَقرَأُ ‏getMinSdkVersionFromProject‏،
 * و‏`AndroidManifestRead`‏ بسَطرَيِ ‏`uses-sdk`‏؛ والنَّقلُ ههُنا إعادةُ بناءٍ بأسلوبِنا لا نَسْخٌ.
 *
 * <p><b>اليقينُ أو لا شَيءَ.</b> أيُّ قيمةٍ ليست رقمًا صَريحًا — تعبيرٌ، متغيِّرَ بناءٍ،
 * ‏`Integer.parseInt(…)`‏، ‏`rootProject.ext.minSdk`‏، ‏`"$sdk"`‏ — تُترَكُ <b>صِفرًا</b> لا تُخمَّنُ:
 * لأنَّ وسمَ «يَطلُبُ API ‏21‏ وحدُّكَ ‏19‏» على مشروعٍ لم يُصَرِّحْ بحدِّهِ خطأٌ وَهميٌّ، والخطأُ
 * الوهميُّ أثقَلُ على المُستَخدِمِ من الصَّمْتِ. وبصِفرٍ يُغلَقُ البابُ كلُّهُ: ‏{@link #gatesApi()}‏
 * كاذِبَةٌ فلا يُنشَأُ تشخيصُ إصدارٍ في الملفِّ كلِّهِ.
 *
 * <p><b>الحاملُ الحاليُّ.</b> ‏{@link #publish}‏/‏{@link #current}‏ قيمةٌ ثابتةٌ <b>لكلِّ عمليةٍ</b>،
 * لا لكلِّ ملفٍّ: invariantُنا أنَّ مشروعًا واحدًا مَفتوحًا يُمسِكُ بهِ ‏`DependencyCycle`‏، والمَسحُ
 * المُوازيُ كلُّهُ لنفسِ الجذرِ (جولةُ ٣٩)، فلا يَحمِلُ خيطٌ قرارَ خيطٍ آخَرَ ولا يَنقَلِبُ الحكمُ بتَبدُّلِ
 * الدَّورِ. ومَن يُريدُ مشروعًا آخَرَ يَنشُرُ قَيمَتَهُ عندَ قِراءةِ ملفِّ بِنائِهِ، والفحصُ يَقرَأُ
 * الحَديثَ دائمًا.
 */
public final class ProjectPlatform {

  /** صِفرٌ = لم يُصَرِّحِ المشروعُ؛ ولا قِيمةَ افتراضيَّةً مُختَرَعةً ههنا. */
  public final int minSdk;
  public final int compileSdk;
  public final int targetSdk;
  /** باقةُ ‏`namespace`‏ (حديثٌ) أو ‏`package`‏ في الملفِّ (قديمٌ): صِفرُ طولٍ إن لم تُعرَفْ. */
  public final String namespace;
  /** تَبعِيَةٌ لِـ‏androidx.*‏: لا ‏support‏. العَكسُ صحيحٌ، وكلاهُما صِفرًا = لا دَلِيلَ. */
  public final boolean usesAndroidX;
  public final boolean usesSupportLibrary;
  /** ‏`compileOnly`/`provided`‏ مُستعمَلةٌ: المكتباتُ التي تُرى للفحصِ ولا تُحزَّمُ. */
  public final boolean hasCompileOnly;

  private static volatile ProjectPlatform CURRENT = new ProjectPlatform(0, 0, 0, "", false, false, false);

  private ProjectPlatform(
      int minSdk,
      int compileSdk,
      int targetSdk,
      String namespace,
      boolean usesAndroidX,
      boolean usesSupportLibrary,
      boolean hasCompileOnly) {
    this.minSdk = minSdk;
    this.compileSdk = compileSdk;
    this.targetSdk = targetSdk;
    this.namespace = namespace == null ? "" : namespace;
    this.usesAndroidX = usesAndroidX;
    this.usesSupportLibrary = usesSupportLibrary;
    this.hasCompileOnly = hasCompileOnly;
  }

  /** لا شَيءَ مَعلومًا: لا فَحصَ إصدارٍ ولا وسمَ على غَيرِ اليَقينِ. */
  public static ProjectPlatform unknown() {
    return new ProjectPlatform(0, 0, 0, "", false, false, false);
  }

  public static ProjectPlatform of(
      int minSdk, int compileSdk, int targetSdk, String namespace) {
    return new ProjectPlatform(minSdk, compileSdk, targetSdk, namespace, false, false, false);
  }

  /** ‏androidx/support/compileOnly‏ تُعرَفُ من نَصِّ ملفِّ البِناءِ وحدَهُ. */
  public ProjectPlatform withLibraryKind(boolean androidx, boolean support, boolean compileOnly) {
    return new ProjectPlatform(
        minSdk, compileSdk, targetSdk, namespace, androidx, support, compileOnly);
  }

  /** تَراكُمٌ: ما جَاءَ منَ الثّاني يَملأُ فَقطْ ما لم يَأتِ منَ الأولِ (المانيفستُ يَلِي الغْرافَ). */
  public ProjectPlatform mergedWith(ProjectPlatform other) {
    if (other == null) return this;
    return new ProjectPlatform(
        minSdk > 0 ? minSdk : other.minSdk,
        compileSdk > 0 ? compileSdk : other.compileSdk,
        targetSdk > 0 ? targetSdk : other.targetSdk,
        !namespace.isEmpty() ? namespace : other.namespace,
        usesAndroidX || other.usesAndroidX,
        usesSupportLibrary || other.usesSupportLibrary,
        hasCompileOnly || other.hasCompileOnly);
  }

  /**
   * هل يَجوزُ للفاحِصِ أن يَحكُمَ على الإصداراتِ؟ مِقياسُنَا ‏minSdk‏ المُصَرَّحُ بِوحدِهِ: بغيرِهِ لا
   * «يَطلُبُ API» ولا «حُذِفَ في API» تُقالُ.
   */
  public boolean gatesApi() {
    return minSdk > 0;
  }

  /** Project level, or zero when it cannot be established; independent of the host device. */
  public int analyzerMinApi() {
    return minSdk > 0 ? minSdk : 0;
  }

  /** deviceApi is kept for binary/source compatibility, but is never a project compileSdk. */
  public int analyzerCompileApi(int deviceApi) {
    return compileSdk > 0 && (minSdk <= 0 || compileSdk >= minSdk) ? compileSdk : 0;
  }

  /** True means that one or both project levels are unknown, not guessed. */
  public boolean analyzerApiAssumed() {
    return analyzerMinApi() == 0 || analyzerCompileApi(0) == 0;
  }

  /** عُضوٌ/صنفٌ دَخَلَ في ‏`since`‏ ولا يَراهُ حدُّ المشروعِ. */
  public boolean requiresAboveMin(int since) {
    return minSdk > 0 && since > minSdk;
  }

  /** A removed compile-time API is asserted only when compileSdk is actually known. */
  public boolean removedForThisProject(int removed) {
    if (removed <= 0) return false;
    // targetSdk controls behavior; it is not the compiler's platform classpath.
    return compileSdk > 0 && removed <= compileSdk;
  }

  /** ما الذي جَزَمَ؟ للوحةِ وللبوَّابةِ معًا (‏0‏ بلا قَولٍ). */
  public String describe() {
    StringBuilder b = new StringBuilder();
    if (minSdk > 0) b.append("minSdk=").append(minSdk).append(' ');
    if (compileSdk > 0) b.append("compileSdk=").append(compileSdk).append(' ');
    if (targetSdk > 0) b.append("targetSdk=").append(targetSdk).append(' ');
    if (usesAndroidX) b.append("androidx ");
    if (usesSupportLibrary) b.append("support ");
    return b.toString().trim();
  }

  // ─────────────────────────── القراءةُ من ملفِّ البِناءِ ───────────────────────────

  /**
   * ‏build.gradle‏ ← مستوياتُ + باقةُ ‏namespace‏. يُؤخَذُ ‏defaultConfig`‏ أولًا (وقد تُعيَدُ
   * المستوياتُ في ‏productFlavors`‏ فتِلكَ ليست حدَّ المشروعِ كلِّهِ)، ثمَّ يُستَكمَلُ من سائرِ الملفِّ.
   */
  public static ProjectPlatform fromGradle(String text) {
    if (text == null || text.isEmpty()) return unknown();
    String clean = stripComments(text);
    String defaultBlock = blockOf(clean, "defaultConfig");
    int min = level(defaultBlock, "minSdkVersion", "minSdk");
    if (min == 0 && defaultBlock.isEmpty() && clean.indexOf("productFlavors") < 0)
      min = level(clean, "minSdkVersion", "minSdk");
    int compile = level(defaultBlock, "compileSdkVersion", "compileSdk");
    if (compile == 0) compile = level(clean, "compileSdkVersion", "compileSdk");
    int target = level(defaultBlock, "targetSdkVersion", "targetSdk");
    if (target == 0 && defaultBlock.isEmpty() && clean.indexOf("productFlavors") < 0)
      target = level(clean, "targetSdkVersion", "targetSdk");
    String namespace = quotedValue(clean, "namespace");
    boolean androidx = clean.indexOf("androidx.") >= 0;
    boolean support =
        clean.indexOf("com.android.support") >= 0 || clean.indexOf("android-support-v") >= 0;
    boolean compileOnly =
        clean.indexOf("compileOnly") >= 0 || clean.indexOf("provided(") >= 0
            || clean.indexOf("provided ") >= 0;
    return new ProjectPlatform(min, compile, target, namespace, androidx, support, compileOnly)
        .withManifestPackageIfAbsent(clean);
  }

  /** باقةُ المشروعِ القديمةُ كانت في ‏build.gradle‏ ب‏`package`‏ (وإلّا من المانيفستِ). */
  private ProjectPlatform withManifestPackageIfAbsent(String gradleText) {
    if (!namespace.isEmpty()) return this;
    String p = quotedValue(gradleText, "package");
    return p.isEmpty()
        ? this
        : new ProjectPlatform(minSdk, compileSdk, targetSdk, p, usesAndroidX, usesSupportLibrary,
            hasCompileOnly);
  }

  /** ‏AndroidManifest.xml‏ ← ‏<uses-sdk android:minSdkVersion="19" …/>‏ و‏package`‏ القديمُ. */
  public static ProjectPlatform fromManifest(String xml) {
    if (xml == null || xml.isEmpty()) return unknown();
    String clean = stripComments(xml);
    int min = attributeNumber(clean, "minSdkVersion");
    int target = attributeNumber(clean, "targetSdkVersion");
    String pkg = attribute(clean, "package");
    return new ProjectPlatform(min, 0, target, pkg, false, false, false);
  }

  // ─────────────────────────── الحاملُ الحاليُّ للمشروعِ ───────────────────────────

  /** عندَ قِراءةِ ‏build.gradle‏ (وبعدَ كلِّ حِفظٍ لهُ): يَنشُرُ المُنجِمُ قرارَ المشروعِ. */
  public static void publish(ProjectPlatform platform) {
    CURRENT = platform == null ? unknown() : platform;
  }

  public static ProjectPlatform current() {
    ProjectPlatform p = CURRENT;
    return p == null ? unknown() : p;
  }

  // ─────────────────────────── أدواتُ تَقطيرٍ صَغيرةٌ لا تُخطِئُ ───────────────────────────

  /** قيمةُ المفتاحِ: رقمٌ صَريحٌ، أو ‏"android-34"‏/‏'android-34'‏، وإلّا صِفرٌ — لا تَخمِينَ. */
  private static int level(String text, String first, String second) {
    int v = levelAfter(text, first);
    return v != 0 ? v : levelAfter(text, second);
  }

  private static int levelAfter(String text, String key) {
    for (int at = text.indexOf(key); at >= 0; at = text.indexOf(key, at + key.length())) {
      if (at > 0 && isIdPart(text.charAt(at - 1))) continue;
      int after = at + key.length();
      if (after < text.length() && isIdPart(text.charAt(after))) continue;
      int i = after;
      while (i < text.length() && (text.charAt(i) == ' ' || text.charAt(i) == '\t')) i++;
      if (i < text.length() && text.charAt(i) == '=') {
        i++;
        while (i < text.length() && (text.charAt(i) == ' ' || text.charAt(i) == '\t')) i++;
      }
      if (i < text.length() && (text.charAt(i) == '"' || text.charAt(i) == '\'')) {
        char q = text.charAt(i++);
        int end = text.indexOf(q, i);
        if (end < 0) continue;
        String inside = text.substring(i, end);
        if (inside.startsWith("android-")) inside = inside.substring(8);
        i = end + 1;
        int n = digits(inside);
        if (n > 0 && literalEnds(text, i)) return n;
        continue;
      }
      int start = i;
      while (i < text.length() && text.charAt(i) >= '0' && text.charAt(i) <= '9') i++;
      if (i > start) {
        int n = digits(text.substring(start, i));
        if (n > 0 && literalEnds(text, i)) return n;
      }
      // أيُّ شَيءٍ آخَرَ (تعبيرٌ، متغيِّرٌ، دالَّةٌ): لا قَرارَ، نَنتَقِلُ إلى مَوضعٍ ثانٍ إن وُجِدَ.
    }
    return 0;
  }

  /** A numeric prefix of an expression is not an authoritative SDK level. */
  private static boolean literalEnds(String text, int at) {
    int i = at;
    while (i < text.length() && (text.charAt(i) == ' ' || text.charAt(i) == '\t')) i++;
    return i == text.length() || text.charAt(i) == '\n' || text.charAt(i) == '\r'
        || text.charAt(i) == ';' || text.charAt(i) == '}' || text.charAt(i) == ')'
        || text.charAt(i) == ',';
  }

  /** ‏name "value"‏ أو ‏name = 'value'‏ في ‏gradle‏. */
  private static String quotedValue(String text, String key) {
    for (int at = text.indexOf(key); at >= 0; at = text.indexOf(key, at + key.length())) {
      if (at > 0 && isIdPart(text.charAt(at - 1))) continue;
      int i = at + key.length();
      while (i < text.length() && (text.charAt(i) == ' ' || text.charAt(i) == '\t' || text.charAt(i) == '=')) i++;
      if (i >= text.length() || (text.charAt(i) != '"' && text.charAt(i) != '\'')) continue;
      char q = text.charAt(i++);
      int end = text.indexOf(q, i);
      if (end < 0) continue;
      return text.substring(i, end);
    }
    return "";
  }

  /** ‏android:minSdkVersion="19"‏ ← رقمٌ فقطْ؛ ‏"@integer/x"‏ أو ‏"${…}"‏ لا يُجيبُ. */
  private static int attributeNumber(String text, String name) {
    String v = attribute(text, name);
    return digits(v);
  }

  private static String attribute(String text, String name) {
    int at = text.indexOf(name + "=");
    if (at < 0) at = text.indexOf(name + " =");
    if (at < 0) return "";
    int i = text.indexOf('"', at);
    if (i < 0) return "";
    int end = text.indexOf('"', i + 1);
    return end < 0 ? "" : text.substring(i + 1, end);
  }

  private static int digits(String value) {
    if (value == null) return 0;
    String v = value.trim();
    if (v.isEmpty()) return 0;
    for (int i = 0; i < v.length(); i++) {
      char c = v.charAt(i);
      if (c < '0' || c > '9') return 0;
    }
    try {
      int n = Integer.parseInt(v);
      return n > 0 && n < 300 ? n : 0; // لا «1900» ولا صِفرٌ: خارجُ مَدَى الإصداراتِ مَجهولٌ
    } catch (NumberFormatException tooLong) {
      return 0;
    }
  }

  /** ‏defaultConfig { … }‏ بموازنةِ الأقواسِ؛ فارغٌ إن لم يَكُنْ. */
  private static String blockOf(String text, String name) {
    int at = text.indexOf(name);
    while (at >= 0) {
      int brace = at + name.length();
      while (brace < text.length() && (text.charAt(brace) == ' ' || text.charAt(brace) == '\t'
          || text.charAt(brace) == '\n' || text.charAt(brace) == '\r')) brace++;
      if (brace < text.length() && text.charAt(brace) == '{') {
        int depth = 0;
        for (int i = brace; i < text.length(); i++) {
          char c = text.charAt(i);
          if (c == '{') depth++;
          else if (c == '}') {
            depth--;
            if (depth == 0) return text.substring(brace + 1, i);
          }
        }
        return "";
      }
      at = text.indexOf(name, at + name.length());
    }
    return "";
  }

  /** ‏//…‏ و‏/* … *\/‏ لا تَشهَدُ على شَيءٍ: تُطرَحُ قبلَ البحثِ (مِثالُ ‏// compileSdk 21‏). */
  private static String stripComments(String text) {
    StringBuilder out = new StringBuilder(text.length());
    for (int i = 0; i < text.length(); i++) {
      char c = text.charAt(i);
      if (c == '/' && i + 1 < text.length() && text.charAt(i + 1) == '/') {
        while (i < text.length() && text.charAt(i) != '\n') i++;
        out.append('\n');
      } else if (c == '/' && i + 1 < text.length() && text.charAt(i + 1) == '*') {
        int end = text.indexOf("*/", i + 2);
        i = end < 0 ? text.length() : end + 1;
        out.append(' ');
      } else if (c == '"' || c == '\'') {
        char q = c;
        out.append(c);
        int j = i + 1;
        while (j < text.length() && (text.charAt(j) != q || text.charAt(j - 1) == '\\')) j++;
        if (j < text.length()) {
          out.append(text, i + 1, j + 1);
          i = j;
        }
      } else {
        out.append(c);
      }
    }
    return out.toString();
  }

  private static boolean isIdPart(char c) {
    return Character.isLetterOrDigit(c) || c == '_' || c == '.';
  }
}
