package almlk;

import com.almlkid.kay.ui.CodeLanguageTools;
import com.almlkid.kay.ui.CodeLanguageTools.Diagnostic;
import java.util.Collections;
import java.util.List;

/**
 * Entry point of the Java analysis engine: parse ({@link JavaParser}) then attribute ({@link
 * JavaAttributor}) one file against the project model, the platform and the resolved libraries.
 * Replaces the former line-pattern checker; the editor, the project scan and the build-output
 * quick fixes all go through here.
 */
public final class JavaCodeAnalyzer {

  /** Files beyond this size are not analysed semantically (syntax checks still run). */
  private static final int MAX_SOURCE = 600_000;

  /**
   * The single source of the hard stop, so {@link DiagnosticBudget} and this engine cannot drift
   * apart into two numbers nobody trusts (W7).
   */
  public static int semanticHardStopChars() {
    return MAX_SOURCE;
  }

  private static final ThreadLocal<Boolean> INCOMPLETE = new ThreadLocal<>();
  public static void beginAssessment() { INCOMPLETE.set(Boolean.FALSE); }
  public static void markIncomplete() { INCOMPLETE.set(Boolean.TRUE); }
  public static boolean assessmentIncomplete() { return Boolean.TRUE.equals(INCOMPLETE.get()); }

  private static final Object CACHE_LOCK = new Object();
  private static String cachedName;
  private static String cachedSource;
  private static List<Diagnostic> cachedDiagnostics = Collections.emptyList();

  private JavaCodeAnalyzer() {}

  /**
   * Semantic diagnostics for {@code source}; {@code lexical} are the diagnostics already found by
   * the lexical and syntax passes — bracket errors there make the tree unreliable, so nothing
   * semantic is reported until they are fixed.
   */
  private static boolean hasSyntaxError(List<Diagnostic> lexical) {
    if (lexical == null) return false;
    for (Diagnostic d : lexical)
      if (d != null && d.severity == Diagnostic.Severity.ERROR && JavaDiagnosticCodes.isSyntaxCode(d.code)) return true;
    return false;
  }

  public static List<Diagnostic> inspect(String source, List<Diagnostic> lexical) {
    String text = source == null ? "" : source;
    if (text.isEmpty()) return Collections.emptyList();
    if (text.length() > MAX_SOURCE || hasStructuralError(lexical)) {
      markIncomplete();
      return Collections.emptyList();
    }
    try {
      JavaSyntaxTree.Unit unit = JavaParser.parse(text);
      JavaAttributor attributor = new JavaAttributor(text, unit);
      List<Diagnostic> found = attributor.run();
      if (attributor.isolatedFailures > 0 || attributor.findingsLimited) markIncomplete();
      if (unit.errorRanges.isEmpty() && !hasSyntaxError(lexical)) {
        // R5 (wd): flow analysis only on a clean tree — a recovered one would cascade.
        try {
          List<Diagnostic> flow = new JavaFlowAnalyzer(text, unit).run();
          if (!flow.isEmpty()) {
            found = new java.util.ArrayList<>(found);
            found.addAll(flow);
          }
        } catch (Throwable ignored) {
          markIncomplete();
          // the attribution findings stand on their own
        }
        // R6 (Id): local warnings, on the same clean tree.
        try {
          List<Diagnostic> warnings = new JavaWarningAnalyzer(text, unit).run();
          if (!warnings.isEmpty()) {
            found = new java.util.ArrayList<>(found);
            found.addAll(warnings);
          }
        } catch (Throwable ignored) {
          markIncomplete();
          // warnings are optional
        }
        // W27/3 (‏1.0.180): الصنفُ المَبنيُّ يُسأَلُ عن دوالِّه المجرّدةِ عندَ اسمِهِ، بإصلاحٍ واحدٍ
        // يَجلبُها كلَّها. على الشجرةِ النظيفةِ وحدَها: شجرةٌ مُستَعادةٌ تُورِثُ صِنفًا ناقصًا زورًا.
        try {
          List<Diagnostic> gaps = AbstractImplementationGap.inspect(text, unit,
              AbstractImplementationGap.RUNTIME);
          if (!gaps.isEmpty()) {
            found = new java.util.ArrayList<>(found);
            found.addAll(gaps);
          }
        } catch (Throwable ignored) {
          markIncomplete();
          // الجَهلُ بأصلٍ لا يَستحقُّ تشخيصًا ولا تعطيلًا
        }
      }
      if (!unit.errorRanges.isEmpty() || hasSyntaxError(lexical)) markIncomplete();
      return found;
    } catch (Throwable ignored) {
      markIncomplete();
      // A failed analysis must never take the editor's other diagnostics down with it.
      return Collections.emptyList();
    }
  }

  /**
   * Quick fixes of the diagnostic overlapping [start, end) in {@code source}; the last analysed
   * file is cached because a build usually reports several errors in the same file.
   */
  public static List<QuickFix> quickFixesAt(String fileName, String source, int start, int end) {
    if (source == null || source.isEmpty() || source.length() > MAX_SOURCE) return Collections.emptyList();
    List<Diagnostic> diagnostics;
    synchronized (CACHE_LOCK) {
      if (source.equals(cachedSource) && String.valueOf(fileName).equals(cachedName)) {
        diagnostics = cachedDiagnostics;
      } else {
        diagnostics = CodeLanguageTools.inspect(fileName == null ? "File.java" : fileName, source);
        cachedName = String.valueOf(fileName);
        cachedSource = source;
        cachedDiagnostics = diagnostics;
      }
    }
    int to = Math.max(start + 1, end);
    for (Diagnostic diagnostic : diagnostics) {
      if (diagnostic.quickFixes.isEmpty()) continue;
      if (diagnostic.offset < to && start < diagnostic.end) return diagnostic.quickFixes;
    }
    return Collections.emptyList();
  }

  static boolean hasStructuralError(List<Diagnostic> lexical) {
    if (lexical == null) return false;
    for (Diagnostic diagnostic : lexical) {
      if (diagnostic == null || diagnostic.severity != Diagnostic.Severity.ERROR) continue;
      String key = diagnostic.messageKey == null ? "" : diagnostic.messageKey;
      if (key.contains("delimiter") || key.startsWith("ui_diagnostic_unclosed")) return true;
    }
    return false;
  }
}
