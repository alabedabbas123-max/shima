package almlk;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * قارئ ملفات {@code .class} مستقل (بلا ASM ولا مكتبات) لفهرسة المكتبات في M4.
 *
 * <p>يقرأ ما يلزم الإكمال والتحقق فقط: الأعلام، والأب والواجهات، و{@code Signature} للأنواع العامة،
 * وجدول الأصناف الداخلية، والحقول والدوال والمُنشئات مع أسماء المعاملات (MethodParameters أو
 * LocalVariableTable). ثم يكتب كتلة الصنف بصيغة {@code android-api.idx} نفسها كي يدمجها
 * {@link AndroidApiIndex} دون مسار موازٍ. أي ملف تالف يرمي {@link IOException} — لا استثناءات تشغيل.
 */
public final class ClassFileReader {

  static final int ACC_PUBLIC = 0x0001, ACC_PRIVATE = 0x0002, ACC_PROTECTED = 0x0004,
      ACC_STATIC = 0x0008, ACC_BRIDGE = 0x0040, ACC_VARARGS = 0x0080, ACC_INTERFACE = 0x0200,
      ACC_ABSTRACT = 0x0400, ACC_SYNTHETIC = 0x1000, ACC_ANNOTATION = 0x2000, ACC_ENUM = 0x4000,
      ACC_MODULE = 0x8000;

  /** حقل أو دالة كما في الملف. */
  public static final class Member {
    public int access;
    public String name, descriptor, signature;
    public boolean deprecated;
    /** أسماء المعاملات إن حفظها المترجم، وإلا null. */
    public String[] parameterNames;
  }

  /** مدخل InnerClasses: الصنف الداخلي وحاويه واسمه البسيط. */
  public static final class InnerClass {
    public String inner, outer, simpleName;
    public int access;
  }

  /** الصنف المقروء (الأسماء بصيغة داخلية a/b/C$D). */
  public static final class ClassFile {
    public int access;
    public String name, superName, signature;
    public String[] interfaces = new String[0];
    public boolean deprecated;
    public final List<Member> fields = new ArrayList<>();
    public final List<Member> methods = new ArrayList<>();
    public final Map<String, InnerClass> innerClasses = new HashMap<>();
  }

  private ClassFileReader() {}

  // ═══════════════ القراءة ═══════════════

  public static ClassFile read(byte[] data) throws IOException {
    if (data == null) throw new IOException("no data");
    try {
      return new Parser(data).parse();
    } catch (IOException error) {
      throw error;
    } catch (RuntimeException error) {
      throw new IOException("bad class file: " + error, error);
    }
  }

  private static final class Parser {
    final byte[] b;
    int p;
    Object[] pool;
    byte[] tags;

    Parser(byte[] data) {
      b = data;
    }

    int u1() throws IOException {
      if (p >= b.length) throw new IOException("truncated");
      return b[p++] & 0xff;
    }

    int u2() throws IOException {
      return (u1() << 8) | u1();
    }

    int u4() throws IOException {
      return (u2() << 16) | u2();
    }

    void skip(long n) throws IOException {
      if (n < 0 || p + n > b.length) throw new IOException("truncated");
      p += (int) n;
    }

    String utf(int index) throws IOException {
      if (index <= 0 || index >= pool.length || tags[index] != 1) throw new IOException("bad utf8 #" + index);
      return (String) pool[index];
    }

    String utfOrNull(int index) throws IOException {
      return index == 0 ? null : utf(index);
    }

    String className(int index) throws IOException {
      if (index <= 0 || index >= pool.length || tags[index] != 7) throw new IOException("bad class #" + index);
      return utf((Integer) pool[index]);
    }

    String classNameOrNull(int index) throws IOException {
      return index == 0 ? null : className(index);
    }

    ClassFile parse() throws IOException {
      if (u4() != 0xCAFEBABE) throw new IOException("not a class file");
      u2();
      u2();
      int count = u2();
      pool = new Object[count];
      tags = new byte[count];
      for (int i = 1; i < count; i++) {
        int tag = u1();
        tags[i] = (byte) tag;
        switch (tag) {
          case 1:
            int length = u2();
            skip(length);
            pool[i] = modifiedUtf8(b, p - length, length);
            break;
          case 7: case 8: case 16: case 19: case 20:
            pool[i] = u2();
            break;
          case 3: case 4: case 9: case 10: case 11: case 12: case 17: case 18:
            skip(4);
            break;
          case 5: case 6:
            skip(8);
            i++;
            break;
          case 15:
            skip(3);
            break;
          default:
            throw new IOException("bad constant tag " + tag);
        }
      }
      ClassFile cf = new ClassFile();
      cf.access = u2();
      cf.name = className(u2());
      cf.superName = classNameOrNull(u2());
      int interfaces = u2();
      cf.interfaces = new String[interfaces];
      for (int i = 0; i < interfaces; i++) cf.interfaces[i] = className(u2());
      int fields = u2();
      for (int i = 0; i < fields; i++) cf.fields.add(member(false));
      int methods = u2();
      for (int i = 0; i < methods; i++) cf.methods.add(member(true));
      int attributes = u2();
      for (int i = 0; i < attributes; i++) {
        String name = utf(u2());
        int length = u4();
        int end = p + length;
        if (length < 0 || end > b.length) throw new IOException("truncated attribute");
        switch (name) {
          case "Signature":
            cf.signature = utf(u2());
            break;
          case "Deprecated":
            cf.deprecated = true;
            break;
          case "InnerClasses":
            int n = u2();
            for (int k = 0; k < n; k++) {
              InnerClass inner = new InnerClass();
              inner.inner = className(u2());
              inner.outer = classNameOrNull(u2());
              inner.simpleName = utfOrNull(u2());
              inner.access = u2();
              cf.innerClasses.put(inner.inner, inner);
            }
            break;
          default:
            break;
        }
        p = end;
      }
      return cf;
    }

    Member member(boolean method) throws IOException {
      Member m = new Member();
      m.access = u2();
      m.name = utf(u2());
      m.descriptor = utf(u2());
      int attributes = u2();
      String[] localNames = null;
      for (int i = 0; i < attributes; i++) {
        String name = utf(u2());
        int length = u4();
        int end = p + length;
        if (length < 0 || end > b.length) throw new IOException("truncated attribute");
        switch (name) {
          case "Signature":
            m.signature = utf(u2());
            break;
          case "Deprecated":
            m.deprecated = true;
            break;
          case "MethodParameters":
            if (method) {
              int n = u1();
              String[] names = new String[n];
              for (int k = 0; k < n; k++) {
                names[k] = utfOrNull(u2());
                u2();
              }
              m.parameterNames = names;
            }
            break;
          case "Code":
            if (method) localNames = parameterSlots(end, m);
            break;
          default:
            break;
        }
        p = end;
      }
      if (method && localNames != null) {
        if (m.parameterNames == null) {
          m.parameterNames = localNames;
        } else if (m.parameterNames.length == localNames.length) {
          // javac يكتب MethodParameters بلا أسماء لمُنشئات الأصناف الداخلية؛ نكمّلها من الجدول.
          for (int k = 0; k < localNames.length; k++)
            if (m.parameterNames[k] == null) m.parameterNames[k] = localNames[k];
        }
      }
      return m;
    }

    /** أسماء المعاملات من LocalVariableTable داخل Code (المدخلات ذات start_pc = 0). */
    String[] parameterSlots(int end, Member m) throws IOException {
      skip(4);
      int codeLength = u4();
      skip(codeLength & 0xffffffffL);
      int exceptions = u2();
      skip(exceptions * 8L);
      int attributes = u2();
      HashMap<Integer, String> bySlot = null;
      for (int i = 0; i < attributes; i++) {
        String name = utf(u2());
        int length = u4();
        int attrEnd = p + length;
        if (length < 0 || attrEnd > end) throw new IOException("truncated code attribute");
        if (name.equals("LocalVariableTable")) {
          int n = u2();
          for (int k = 0; k < n; k++) {
            int start = u2();
            u2();
            String local = utf(u2());
            u2();
            int slot = u2();
            if (start != 0) continue;
            if (bySlot == null) bySlot = new HashMap<>();
            bySlot.put(slot, local);
          }
        }
        p = attrEnd;
      }
      if (bySlot == null) return null;
      List<String> params = descriptorParameters(m.descriptor);
      String[] names = new String[params.size()];
      int slot = (m.access & ACC_STATIC) != 0 ? 0 : 1;
      for (int i = 0; i < names.length; i++) {
        names[i] = bySlot.get(slot);
        String d = params.get(i);
        slot += d.equals("J") || d.equals("D") ? 2 : 1;
      }
      return names;
    }
  }

  /** فك UTF-8 المعدّل الخاص بملفات class (null كـC0 80، والأزواج البديلة كما هي). */
  static String modifiedUtf8(byte[] b, int offset, int length) throws IOException {
    char[] out = new char[length];
    int n = 0;
    int i = offset, end = offset + length;
    while (i < end) {
      int c = b[i++] & 0xff;
      if (c < 0x80) {
        out[n++] = (char) c;
      } else if ((c & 0xe0) == 0xc0) {
        if (i >= end) throw new IOException("bad utf8");
        out[n++] = (char) (((c & 0x1f) << 6) | (b[i++] & 0x3f));
      } else if ((c & 0xf0) == 0xe0) {
        if (i + 1 >= end) throw new IOException("bad utf8");
        out[n++] = (char) (((c & 0x0f) << 12) | ((b[i++] & 0x3f) << 6) | (b[i++] & 0x3f));
      } else {
        throw new IOException("bad utf8");
      }
    }
    return new String(out, 0, n);
  }

  // ═══════════════ الواصفات والتواقيع ═══════════════

  /** واصفات المعاملات الخام: (ILjava/lang/String;[J)V → [I, Ljava/lang/String;, [J]. */
  static List<String> descriptorParameters(String descriptor) throws IOException {
    ArrayList<String> out = new ArrayList<>();
    if (descriptor == null || descriptor.isEmpty() || descriptor.charAt(0) != '(') throw new IOException("bad descriptor");
    int i = 1;
    while (i < descriptor.length() && descriptor.charAt(i) != ')') {
      int start = i;
      while (i < descriptor.length() && descriptor.charAt(i) == '[') i++;
      if (i >= descriptor.length()) throw new IOException("bad descriptor");
      if (descriptor.charAt(i) == 'L') {
        int semi = descriptor.indexOf(';', i);
        if (semi < 0) throw new IOException("bad descriptor");
        i = semi + 1;
      } else i++;
      out.add(descriptor.substring(start, i));
    }
    if (i >= descriptor.length()) throw new IOException("bad descriptor");
    return out;
  }

  /** مؤشّر قراءة لتواقيع Java العامة والواصفات (الصيغة نفسها مع إضافات). */
  static final class Sig {
    final String s;
    int i;

    Sig(String s) {
      this.s = s;
    }

    boolean more() {
      return i < s.length();
    }

    char peek() throws IOException {
      if (i >= s.length()) throw new IOException("truncated signature");
      return s.charAt(i);
    }

    char next() throws IOException {
      char c = peek();
      i++;
      return c;
    }

    void expect(char c) throws IOException {
      if (next() != c) throw new IOException("bad signature: " + s);
    }

    /** نوع واحد بنصّ Java مؤهّل: java.util.List<java.lang.String>، T، int[]. */
    String type() throws IOException {
      char c = next();
      switch (c) {
        case 'B': return "byte";
        case 'C': return "char";
        case 'D': return "double";
        case 'F': return "float";
        case 'I': return "int";
        case 'J': return "long";
        case 'S': return "short";
        case 'Z': return "boolean";
        case 'V': return "void";
        case '[': return type() + "[]";
        case 'T': {
          int semi = s.indexOf(';', i);
          if (semi < 0) throw new IOException("bad type variable");
          String name = s.substring(i, semi);
          i = semi + 1;
          return name;
        }
        case 'L': return classType();
        default: throw new IOException("bad type '" + c + "' in " + s);
      }
    }

    /** بعد 'L': a/b/Outer<..>.Inner<..>; — وسائط الحاوي تُسقط (Outer.Inner<U>). */
    private String classType() throws IOException {
      StringBuilder name = new StringBuilder();
      String args = "";
      while (true) {
        char c = next();
        if (c == ';') break;
        if (c == '<') {
          args = typeArguments();
          continue;
        }
        if (c == '.') {
          name.append('.');
          args = "";
          continue;
        }
        name.append(c == '/' || c == '$' ? '.' : c);
      }
      return name + args;
    }

    private String typeArguments() throws IOException {
      StringBuilder out = new StringBuilder("<");
      boolean first = true;
      while (peek() != '>') {
        if (!first) out.append(", ");
        first = false;
        char c = peek();
        if (c == '*') {
          i++;
          out.append('?');
        } else if (c == '+') {
          i++;
          out.append("? extends ").append(type());
        } else if (c == '-') {
          i++;
          out.append("? super ").append(type());
        } else out.append(type());
      }
      i++;
      return out.append('>').toString();
    }

    /** {@code <T:Ljava/lang/Object;U::Ljava/lang/Comparable<TU;>;>} → أسماء وحدود أولى. */
    LinkedMap typeParameters() throws IOException {
      LinkedMap out = new LinkedMap();
      if (!more() || peek() != '<') return out;
      i++;
      while (peek() != '>') {
        int colon = s.indexOf(':', i);
        if (colon < 0) throw new IOException("bad type parameter");
        String name = s.substring(i, colon);
        i = colon;
        String bound = null;
        while (more() && peek() == ':') {
          i++;
          if (peek() == ':') continue; // حدّ صنف فارغ ثم واجهة
          String t = type();
          if (bound == null) bound = t;
        }
        out.put(name, bound == null ? "java.lang.Object" : bound);
      }
      i++;
      return out;
    }
  }

  /** خريطة صغيرة مرتّبة (اسم → حدّ) دون LinkedHashMap العامة في التواقيع. */
  static final class LinkedMap {
    final ArrayList<String> keys = new ArrayList<>();
    final HashMap<String, String> values = new HashMap<>();

    void put(String key, String value) {
      if (!values.containsKey(key)) keys.add(key);
      values.put(key, value);
    }
  }

  // ═══════════════ الكتابة بصيغة الفهرس ═══════════════

  /** اسم المصدر لصنف داخلي/علوي من جدول InnerClasses؛ null لصنف مجهول أو محلي. */
  static String sourceName(String internal, Map<String, InnerClass> inner, int depth) {
    InnerClass entry = inner.get(internal);
    if (entry == null) return internal.replace('/', '.').replace('$', '.');
    if (entry.outer == null || entry.simpleName == null || depth > 32) return null;
    String outer = sourceName(entry.outer, inner, depth + 1);
    return outer == null ? null : outer + "." + entry.simpleName;
  }

  /** مرئي من خارج الحزمة: public (أو protected للداخلي) على طول سلسلة الحاويات. */
  static boolean isVisible(ClassFile cf, String internal, int depth) {
    InnerClass entry = cf.innerClasses.get(internal);
    if (entry == null) return internal.equals(cf.name) ? (cf.access & ACC_PUBLIC) != 0 : true;
    if ((entry.access & (ACC_PUBLIC | ACC_PROTECTED)) == 0 || depth > 32) return false;
    return entry.outer == null || isVisible(cf, entry.outer, depth + 1);
  }

  private static final Set<String> KEYWORDS = new HashSet<>(Arrays.asList(
      "abstract", "assert", "boolean", "break", "byte", "case", "catch", "char", "class", "const",
      "continue", "default", "do", "double", "else", "enum", "extends", "final", "finally", "float",
      "for", "goto", "if", "implements", "import", "instanceof", "int", "interface", "long", "native",
      "new", "package", "private", "protected", "public", "return", "short", "static", "strictfp",
      "super", "switch", "synchronized", "this", "throw", "throws", "transient", "try", "void",
      "volatile", "while", "var", "record", "yield", "true", "false", "null"));

  static boolean isJavaIdentifier(String name) {
    if (name == null || name.isEmpty() || KEYWORDS.contains(name)) return false;
    if (!Character.isJavaIdentifierStart(name.charAt(0))) return false;
    for (int i = 1; i < name.length(); i++) {
      char c = name.charAt(i);
      if (!Character.isJavaIdentifierPart(c) || c == '$') return false;
    }
    return name.charAt(0) != '$';
  }

  /**
   * كتلة الصنف بصيغة الفهرس، أو null إن لم يكن صنفًا مسمّى (مجهول/محلي/اصطناعي/module-info).
   * العمود 9: أعلام (h = غير عام يُستعمل للتسلسل فقط)، والعمود 10: الحزمة صراحةً.
   */
  public static String indexBlock(ClassFile cf) throws IOException {
    if ((cf.access & (ACC_SYNTHETIC | ACC_MODULE)) != 0) return null;
    String simpleInternal = cf.name.substring(cf.name.lastIndexOf('/') + 1);
    if (simpleInternal.equals("package-info") || simpleInternal.equals("module-info")) return null;
    String source = sourceName(cf.name, cf.innerClasses, 0);
    if (source == null) return null;
    int slash = cf.name.lastIndexOf('/');
    String pkg = slash < 0 ? "" : cf.name.substring(0, slash).replace('/', '.');
    String simple = source.substring(source.lastIndexOf('.') + 1);
    if (!isJavaIdentifier(simple)) return null;
    boolean visible = isVisible(cf, cf.name, 0);
    InnerClass self = cf.innerClasses.get(cf.name);
    int access = self != null ? self.access | (cf.access & (ACC_INTERFACE | ACC_ANNOTATION | ACC_ENUM | ACC_ABSTRACT)) : cf.access;
    boolean isInterface = (access & ACC_INTERFACE) != 0;
    boolean isEnum = (access & ACC_ENUM) != 0;
    boolean innerInstance = self != null && (self.access & ACC_STATIC) == 0 && !isInterface && !isEnum;
    String kind = (access & ACC_ANNOTATION) != 0 ? "a" : isInterface ? "i" : isEnum ? "e"
        : (access & ACC_ABSTRACT) != 0 ? "b" : "c";

    String superType = "";
    List<String> interfaces = new ArrayList<>();
    LinkedMap classParams = new LinkedMap();
    if (cf.signature != null) {
      Sig sig = new Sig(cf.signature);
      classParams = sig.typeParameters();
      superType = sig.type();
      while (sig.more()) interfaces.add(sig.type());
    } else {
      if (cf.superName != null) superType = cf.superName.replace('/', '.').replace('$', '.');
      for (String i : cf.interfaces) interfaces.add(i.replace('/', '.').replace('$', '.'));
    }
    if (isInterface || source.equals("java.lang.Object")) superType = "";
    if (isEnum && superType.startsWith("java.lang.Enum")) superType = "java.lang.Enum";

    StringBuilder out = new StringBuilder(256);
    out.append("C\t").append(source).append('\t').append(kind).append("\t1\t")
        .append(cf.deprecated ? "-1" : "0").append("\t0\t").append(superType).append('\t');
    for (int i = 0; i < interfaces.size(); i++) out.append(i == 0 ? "" : ",").append(interfaces.get(i));
    out.append('\t').append(String.join(",", classParams.keys)).append('\t')
        .append(visible ? "" : "h").append('\t').append(pkg).append('\n');

    for (Member f : cf.fields) {
      if ((f.access & ACC_SYNTHETIC) != 0 || !isMemberVisible(f.access, isInterface) || !isJavaIdentifier(f.name)) continue;
      String type = f.signature != null ? new Sig(f.signature).type() : new Sig(f.descriptor).type();
      out.append("F\t").append(f.name).append('\t').append(flags(f.access, isInterface)).append('\t')
          .append(type).append('\t').append(f.deprecated ? ",-1," : "").append('\n');
    }
    for (Member m : cf.methods) {
      if ((m.access & (ACC_SYNTHETIC | ACC_BRIDGE)) != 0 || !isMemberVisible(m.access, isInterface)) continue;
      boolean ctor = m.name.equals("<init>");
      if (!ctor && !isJavaIdentifier(m.name)) continue;
      if (ctor && (isEnum || isInterface)) continue;
      LinkedMap methodParams = new LinkedMap();
      List<String> params = new ArrayList<>();
      String returnType;
      boolean fromSignature = m.signature != null;
      Sig sig = new Sig(fromSignature ? m.signature : m.descriptor);
      if (fromSignature) methodParams = sig.typeParameters();
      sig.expect('(');
      while (sig.peek() != ')') params.add(sig.type());
      sig.expect(')');
      returnType = sig.type();
      String[] names = m.parameterNames;
      if (ctor && innerInstance && !params.isEmpty()) {
        int descriptorCount = descriptorParameters(m.descriptor).size();
        if (!fromSignature || descriptorCount > params.size()) {
          if (!fromSignature) params.remove(0);
          if (names != null && names.length == params.size() + 1) names = Arrays.copyOfRange(names, 1, names.length);
        }
      }
      if (names != null && names.length != params.size()) names = null;
      String paramText = parameterText(params, names, (m.access & ACC_VARARGS) != 0);
      String level = m.deprecated ? ",-1," : "";
      if (ctor) {
        out.append("K\t").append(paramText).append('\t').append(level).append('\n');
      } else {
        String base = returnType.replace("[]", "");
        String bound = methodParams.values.get(base);
        if (bound != null) returnType = bound + returnType.substring(base.length());
        out.append("M\t").append(m.name).append('\t').append(flags(m.access, isInterface)).append('\t')
            .append(returnType).append('\t').append(paramText).append('\t').append(level).append('\n');
      }
    }
    return out.toString();
  }

  /** العام والمحمي فقط (أعضاء الواجهة عامة؛ الخاصة منها منذ Java 9 تُستبعد). */
  private static boolean isMemberVisible(int access, boolean inInterface) {
    return (access & ACC_PRIVATE) == 0 && (access & (ACC_PUBLIC | ACC_PROTECTED)) != 0;
  }

  private static String flags(int access, boolean inInterface) {
    String f = (access & ACC_STATIC) != 0 ? "s" : "";
    if ((access & ACC_PROTECTED) != 0) f += "p";
    if ((access & ACC_ABSTRACT) != 0) f += "a";
    return f.isEmpty() ? "-" : f;
  }

  /** «View view, int i, String... args» — أنواع مبسّطة كما في فهرس المنصة. */
  static String parameterText(List<String> types, String[] names, boolean varargs) {
    StringBuilder out = new StringBuilder();
    HashSet<String> used = new HashSet<>();
    for (int i = 0; i < types.size(); i++) {
      String type = AndroidApiIndex.simpleTypeText(types.get(i));
      if (varargs && i == types.size() - 1 && type.endsWith("[]")) type = type.substring(0, type.length() - 2) + "...";
      String name = names == null ? null : names[i];
      if (!isJavaIdentifier(name)) name = guessName(type);
      String unique = name;
      for (int n = 2; !used.add(unique); n++) unique = name + n;
      if (i > 0) out.append(", ");
      out.append(type).append(' ').append(unique);
    }
    return out.toString();
  }

  /** اسم معامل من نوعه حين لا يحفظه المترجم: Context → context، int → i. */
  static String guessName(String type) {
    String base = AndroidApiIndex.stripGenerics(type).replace("...", "[]");
    boolean array = base.endsWith("[]");
    base = base.replace("[]", "");
    base = base.substring(base.lastIndexOf('.') + 1);
    String name;
    switch (base) {
      case "int": case "long": case "short": case "byte": case "char": case "float": case "double":
        name = base.substring(0, 1);
        break;
      case "boolean":
        name = "b";
        break;
      default:
        name = base.isEmpty() ? "arg" : Character.toLowerCase(base.charAt(0)) + base.substring(1);
        break;
    }
    if (array) name += "s";
    return isJavaIdentifier(name) ? name : "arg";
  }
}
