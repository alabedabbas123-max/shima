package almlk;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Selection-aware Java member generation and XML resource extraction. */
public final class CodeGen {
  private CodeGen() {}

  private static final Set<String> MODIFIERS = new HashSet<>();
  static {
    Collections.addAll(MODIFIERS,
        "public", "protected", "private", "static", "final", "transient", "volatile");
  }

  private static final class ClassInfo {
    final String kind, name;
    final int open, close;
    ClassInfo(String kind, String name, int open, int close) {
      this.kind = kind;
      this.name = name;
      this.open = open;
      this.close = close;
    }
  }

  private static final class Field {
    final String type, name;
    final int nameStart, nameEnd, declarationStart, declarationEnd;
    final boolean isStatic, isFinal;
    Field(String type, String name, int nameStart, int nameEnd,
        int declarationStart, int declarationEnd, boolean isStatic, boolean isFinal) {
      this.type = type;
      this.name = name;
      this.nameStart = nameStart;
      this.nameEnd = nameEnd;
      this.declarationStart = declarationStart;
      this.declarationEnd = declarationEnd;
      this.isStatic = isStatic;
      this.isFinal = isFinal;
    }
  }

  private static final class MemberHeader {
    final String text;
    MemberHeader(String text) { this.text = text; }
  }

  private static final class Members {
    final List<Field> fields = new ArrayList<>();
    final List<MemberHeader> headers = new ArrayList<>();
  }

  private static final class TypeToken {
    final String value;
    final int end;
    TypeToken(String value, int end) { this.value = value; this.end = end; }
  }

  /** Whether the caret/selection touches a field declared directly in its owning class. */
  public static boolean hasFieldTarget(String source, int selectionStart, int selectionEnd) {
    return !selectedFields(source, selectionStart, selectionEnd).isEmpty();
  }

  /** Generates accessors only for the field(s) selected, or under a collapsed caret. */
  public static String createSettersGetters(String source, int selectionStart, int selectionEnd) {
    if (source == null) return null;
    String masked = JavaSourceScanner.maskNonCode(source);
    ClassInfo owner = classAt(source, masked, selectionStart, selectionEnd);
    if (owner == null || !"class".equals(owner.kind)) return null;
    Members members = scanMembers(source, masked, owner);
    List<Field> targets = selectFields(members.fields, selectionStart, selectionEnd);
    if (targets.isEmpty()) return null;

    String newline = newlineOf(source);
    String indent = memberIndent(source, owner, targets.get(0));
    String bodyIndent = indent + "    ";
    StringBuilder generated = new StringBuilder();
    Set<String> pendingMethods = new HashSet<>();
    for (Field field : targets) {
      String suffix = capitalize(field.name);
      String getter = "get" + suffix;
      if (!hasMethod(members.headers, getter) && pendingMethods.add(getter)) {
        appendIndent(generated, indent);
        generated.append("public ");
        if (field.isStatic) generated.append("static ");
        generated.append(field.type).append(" get").append(suffix).append("() {").append(newline);
        appendIndent(generated, bodyIndent);
        generated.append("return ").append(field.name).append(';').append(newline);
        appendIndent(generated, indent);
        generated.append('}').append(newline).append(newline);
      }
      String setter = "set" + suffix;
      if (!field.isFinal && !hasMethod(members.headers, setter) && pendingMethods.add(setter)) {
        appendIndent(generated, indent);
        generated.append("public ");
        if (field.isStatic) generated.append("static ");
        generated.append("void set").append(suffix).append('(')
            .append(field.type).append(' ').append(field.name).append(") {").append(newline);
        appendIndent(generated, bodyIndent);
        generated.append(field.isStatic ? owner.name + "." : "this.")
            .append(field.name).append(" = ").append(field.name).append(';').append(newline);
        appendIndent(generated, indent);
        generated.append('}').append(newline).append(newline);
      }
    }
    if (generated.length() == 0) return null;
    return insertMembers(source, owner, generated.toString(), newline);
  }

  /**
   * Generates a constructor for the selected field(s). With no field at the caret it creates an
   * explicit no-argument constructor. Static fields are never constructor parameters.
   */
  public static String createConstructor(String source, int selectionStart, int selectionEnd) {
    if (source == null) return null;
    String masked = JavaSourceScanner.maskNonCode(source);
    ClassInfo owner = classAt(source, masked, selectionStart, selectionEnd);
    if (owner == null || !"class".equals(owner.kind)) return null;
    Members members = scanMembers(source, masked, owner);
    List<Field> targets = selectFields(members.fields, selectionStart, selectionEnd);
    ArrayList<Field> parameters = new ArrayList<>();
    for (Field field : targets) if (!field.isStatic) parameters.add(field);

    if (hasConstructor(members.headers, owner.name, parameters)) return null;
    String newline = newlineOf(source);
    String indent = memberIndent(source, owner, parameters.isEmpty() ? null : parameters.get(0));
    String bodyIndent = indent + "    ";
    StringBuilder generated = new StringBuilder();
    appendIndent(generated, indent);
    generated.append("public ").append(owner.name).append('(');
    for (int i = 0; i < parameters.size(); i++) {
      if (i > 0) generated.append(", ");
      Field field = parameters.get(i);
      generated.append(field.type).append(' ').append(field.name);
    }
    generated.append(") {").append(newline);
    for (Field field : parameters) {
      appendIndent(generated, bodyIndent);
      generated.append("this.").append(field.name).append(" = ").append(field.name)
          .append(';').append(newline);
    }
    appendIndent(generated, indent);
    generated.append('}').append(newline);
    return insertMembers(source, owner, generated.toString(), newline);
  }

  private static List<Field> selectedFields(String source, int start, int end) {
    if (source == null) return Collections.emptyList();
    String masked = JavaSourceScanner.maskNonCode(source);
    ClassInfo owner = classAt(source, masked, start, end);
    if (owner == null || !"class".equals(owner.kind)) return Collections.emptyList();
    return selectFields(scanMembers(source, masked, owner).fields, start, end);
  }

  private static List<Field> selectFields(List<Field> fields, int start, int end) {
    ArrayList<Field> selected = new ArrayList<>();
    int from = Math.max(0, Math.min(start, end));
    int to = Math.max(0, Math.max(start, end));
    if (from == to) {
      for (Field field : fields) {
        // Prefer the exact declarator under the caret; include its end for the usual post-name caret.
        if (from >= field.nameStart && from <= field.nameEnd) {
          selected.add(field);
          return selected;
        }
      }
      // A field is the whole declaration, not just its identifier (modifier/type/initializer too).
      for (Field field : fields) {
        if (from >= field.declarationStart && from <= field.declarationEnd) {
          selected.add(field);
          break;
        }
      }
      return selected;
    }
    for (Field field : fields) {
      if (from < field.nameEnd && to > field.nameStart) selected.add(field);
    }
    if (!selected.isEmpty()) return selected;
    for (Field field : fields) {
      if (from < field.declarationEnd && to > field.declarationStart) {
        selected.add(field);
        break;
      }
    }
    return selected;
  }

  private static ClassInfo classAt(String source, String masked, int start, int end) {
    Matcher matcher = Pattern.compile(
        "\\b(class|interface|enum|record)\\s+([\\p{javaJavaIdentifierStart}][\\p{javaJavaIdentifierPart}]*)")
        .matcher(masked);
    ArrayList<ClassInfo> classes = new ArrayList<>();
    while (matcher.find()) {
      int open = findClassOpen(masked, matcher.end());
      if (open < 0) continue;
      int close = JavaSourceScanner.matching(masked, open, '{', '}');
      if (close < 0) continue;
      classes.add(new ClassInfo(matcher.group(1), matcher.group(2), open, close));
    }
    if (classes.isEmpty()) return null;
    int from = Math.max(0, Math.min(start, end));
    int to = Math.max(0, Math.max(start, end));
    int probe = from == to ? from : from + (to - from) / 2;
    ClassInfo best = null;
    for (ClassInfo info : classes) {
      if ("class".equals(info.kind) && probe > info.open && probe < info.close
          && (best == null || info.close - info.open < best.close - best.open)) best = info;
    }
    if (best != null) return best;
    for (ClassInfo info : classes) if ("class".equals(info.kind)) return info;
    return null;
  }

  private static int findClassOpen(String source, int from) {
    for (int i = from; i < source.length(); i++) {
      char value = source.charAt(i);
      if (value == '{') return i;
      if (value == ';' || value == '}') return -1;
    }
    return -1;
  }

  private static Members scanMembers(String source, String masked, ClassInfo owner) {
    Members result = new Members();
    int segmentStart = owner.open + 1;
    int parens = 0, brackets = 0, nestedBraces = 0;
    for (int i = owner.open + 1; i < owner.close; i++) {
      char value = masked.charAt(i);
      if (nestedBraces > 0) {
        if (value == '{') nestedBraces++;
        else if (value == '}') nestedBraces--;
        continue;
      }
      if (value == '(') parens++;
      else if (value == ')' && parens > 0) parens--;
      else if (value == '[') brackets++;
      else if (value == ']' && brackets > 0) brackets--;
      else if (value == '{') {
        String header = masked.substring(segmentStart, i);
        if (parens > 0 || brackets > 0 || hasTopLevelAssignment(header)) {
          nestedBraces = 1; // lambda, anonymous class, or array/object initializer
        } else {
          result.headers.add(new MemberHeader(header));
          int close = JavaSourceScanner.matching(masked, i, '{', '}');
          if (close < 0 || close >= owner.close) break;
          i = close;
          segmentStart = close + 1;
        }
      } else if (value == ';' && parens == 0 && brackets == 0) {
        result.fields.addAll(parseFieldDeclaration(
            source, masked, segmentStart, i + 1));
        segmentStart = i + 1;
      }
    }
    return result;
  }

  private static boolean hasTopLevelAssignment(String header) {
    int parens = 0, brackets = 0;
    for (int i = 0; i < header.length(); i++) {
      char value = header.charAt(i);
      if (value == '(') parens++;
      else if (value == ')' && parens > 0) parens--;
      else if (value == '[') brackets++;
      else if (value == ']' && brackets > 0) brackets--;
      else if (value == '=' && parens == 0 && brackets == 0) {
        char before = i == 0 ? 0 : header.charAt(i - 1);
        char after = i + 1 >= header.length() ? 0 : header.charAt(i + 1);
        if (before != '=' && before != '!' && before != '<' && before != '>' && after != '=')
          return true;
      }
    }
    return false;
  }

  private static List<Field> parseFieldDeclaration(
      String source, String masked, int absoluteStart, int absoluteEnd) {
    ArrayList<Field> fields = new ArrayList<>();
    String declaration = masked.substring(absoluteStart, absoluteEnd);
    int i = skipAnnotations(declaration, 0);
    boolean isStatic = false, isFinal = false;
    while (true) {
      i = JavaSourceScanner.skipWhitespace(declaration, i);
      int tokenEnd = identifierEnd(declaration, i);
      if (tokenEnd == i) break;
      String token = declaration.substring(i, tokenEnd);
      if (!MODIFIERS.contains(token)) break;
      if ("static".equals(token)) isStatic = true;
      if ("final".equals(token)) isFinal = true;
      i = tokenEnd;
    }
    i = JavaSourceScanner.skipWhitespace(declaration, i);
    TypeToken parsedType = readType(declaration, i);
    if (parsedType == null) return fields;
    String type = normalizeType(parsedType.value);
    if (type.isEmpty() || "void".equals(type)) return fields;
    int nameCursor = JavaSourceScanner.skipWhitespace(declaration, parsedType.end);
    while (nameCursor < declaration.length()) {
      int nameEnd = identifierEnd(declaration, nameCursor);
      if (nameEnd == nameCursor) return fields;
      String name = declaration.substring(nameCursor, nameEnd);
      int afterName = JavaSourceScanner.skipWhitespace(declaration, nameEnd);
      String fieldType = type;
      while (afterName + 1 < declaration.length() && declaration.charAt(afterName) == '[') {
        int close = JavaSourceScanner.skipWhitespace(declaration, afterName + 1);
        if (close >= declaration.length() || declaration.charAt(close) != ']') break;
        fieldType += "[]";
        afterName = JavaSourceScanner.skipWhitespace(declaration, close + 1);
      }
      if (afterName >= declaration.length()) return fields;
      char separator = declaration.charAt(afterName);
      if (separator != '=' && separator != ',' && separator != ';') return fields;
      int absoluteNameStart = absoluteStart + nameCursor;
      int declarationStart = absoluteStart + JavaSourceScanner.skipWhitespace(declaration, 0);
      fields.add(new Field(fieldType, name, absoluteNameStart,
          absoluteStart + nameEnd, declarationStart, absoluteEnd, isStatic, isFinal));
      if (separator == ';') return fields;
      int comma = nextDeclaratorComma(declaration, afterName, declaration.length());
      if (comma < 0) return fields;
      nameCursor = JavaSourceScanner.skipWhitespace(declaration, comma + 1);
    }
    return fields;
  }

  private static int nextDeclaratorComma(String declaration, int start, int end) {
    int parens = 0, brackets = 0, braces = 0, angles = 0;
    for (int i = start; i < end; i++) {
      char value = declaration.charAt(i);
      if (value == '(') parens++;
      else if (value == ')' && parens > 0) parens--;
      else if (value == '[') brackets++;
      else if (value == ']' && brackets > 0) brackets--;
      else if (value == '{') braces++;
      else if (value == '}' && braces > 0) braces--;
      else if (value == '<') angles++;
      else if (value == '>' && angles > 0) angles--;
      else if (value == ',' && parens == 0 && brackets == 0 && braces == 0 && angles == 0)
        return i;
      else if (value == ';' && parens == 0 && brackets == 0 && braces == 0 && angles == 0)
        return -1;
    }
    return -1;
  }

  private static int skipAnnotations(String text, int start) {
    int i = JavaSourceScanner.skipWhitespace(text, start);
    while (i < text.length() && text.charAt(i) == '@') {
      i++;
      while (i < text.length() && (JavaSourceScanner.identifierPart(text.charAt(i))
          || text.charAt(i) == '.')) i++;
      i = JavaSourceScanner.skipWhitespace(text, i);
      if (i < text.length() && text.charAt(i) == '(') {
        int close = JavaSourceScanner.matching(text, i, '(', ')');
        if (close < 0) return text.length();
        i = close + 1;
      }
      i = JavaSourceScanner.skipWhitespace(text, i);
    }
    return i;
  }

  private static TypeToken readType(String text, int start) {
    int i = skipAnnotations(text, start);
    int typeStart = i;
    int firstEnd = identifierEnd(text, i);
    if (firstEnd == i) return null;
    i = firstEnd;
    while (i < text.length()) {
      i = JavaSourceScanner.skipWhitespace(text, i);
      if (i < text.length() && text.charAt(i) == '.') {
        int next = JavaSourceScanner.skipWhitespace(text, i + 1);
        int end = identifierEnd(text, next);
        if (end == next) return null;
        i = end;
        continue;
      }
      if (i < text.length() && text.charAt(i) == '<') {
        int depth = 0;
        int close = -1;
        for (int p = i; p < text.length(); p++) {
          if (text.charAt(p) == '<') depth++;
          else if (text.charAt(p) == '>' && --depth == 0) { close = p; break; }
        }
        if (close < 0) return null;
        i = close + 1;
        continue;
      }
      if (i + 1 < text.length() && text.charAt(i) == '[') {
        int close = JavaSourceScanner.skipWhitespace(text, i + 1);
        if (close < text.length() && text.charAt(close) == ']') {
          i = close + 1;
          continue;
        }
      }
      break;
    }
    if (i <= typeStart) return null;
    return new TypeToken(text.substring(typeStart, i), i);
  }

  private static int identifierEnd(String text, int start) {
    if (start < 0 || start >= text.length()
        || !JavaSourceScanner.identifierStart(text.charAt(start))) return start;
    int i = start + 1;
    while (i < text.length() && JavaSourceScanner.identifierPart(text.charAt(i))) i++;
    return i;
  }

  private static String normalizeType(String value) {
    return value.trim().replaceAll("\\s+", " ")
        .replaceAll("\\s*\\.\\s*", ".")
        .replaceAll("\\s*<\\s*", "<")
        .replaceAll("\\s*>\\s*", ">")
        .replaceAll("\\s*,\\s*", ", ")
        .replaceAll("\\s*\\[\\s*\\]", "[]");
  }

  private static boolean hasMethod(List<MemberHeader> headers, String name) {
    Pattern method = Pattern.compile("\\b" + Pattern.quote(name) + "\\s*\\(");
    for (MemberHeader header : headers) if (method.matcher(header.text).find()) return true;
    return false;
  }

  private static boolean hasConstructor(
      List<MemberHeader> headers, String className, List<Field> parameters) {
    ArrayList<String> wanted = new ArrayList<>();
    for (Field field : parameters) wanted.add(signatureType(field.type));
    for (MemberHeader header : headers) {
      List<String> found = constructorParameterTypes(header.text, className);
      if (wanted.equals(found) && found != null) return true;
    }
    return false;
  }

  private static List<String> constructorParameterTypes(String header, String className) {
    int i = skipAnnotations(header, 0);
    while (true) {
      i = JavaSourceScanner.skipWhitespace(header, i);
      int end = identifierEnd(header, i);
      if (end == i) break;
      String token = header.substring(i, end);
      if (!"public".equals(token) && !"protected".equals(token) && !"private".equals(token)) break;
      i = end;
    }
    i = JavaSourceScanner.skipWhitespace(header, i);
    if (i < header.length() && header.charAt(i) == '<') {
      int depth = 0;
      int close = -1;
      for (int p = i; p < header.length(); p++) {
        if (header.charAt(p) == '<') depth++;
        else if (header.charAt(p) == '>' && --depth == 0) { close = p; break; }
      }
      if (close < 0) return null;
      i = JavaSourceScanner.skipWhitespace(header, close + 1);
    }
    int nameEnd = identifierEnd(header, i);
    if (nameEnd == i || !className.equals(header.substring(i, nameEnd))) return null;
    int open = JavaSourceScanner.skipWhitespace(header, nameEnd);
    if (open >= header.length() || header.charAt(open) != '(') return null;
    int close = JavaSourceScanner.matching(header, open, '(', ')');
    if (close < 0) return null;
    String rest = header.substring(close + 1).trim();
    if (!rest.isEmpty() && !rest.startsWith("throws ")) return null;
    String parameterSource = header.substring(open + 1, close);
    List<String> parsed = parameterTypes(parameterSource);
    if (!parameterSource.trim().isEmpty() && parsed.isEmpty()) return null;
    return parsed;
  }

  private static List<String> parameterTypes(String parameters) {
    ArrayList<String> result = new ArrayList<>();
    if (parameters == null || parameters.trim().isEmpty()) return result;
    for (String parameter : splitTopLevel(parameters, ',')) {
      String clean = parameter.trim();
      int i = skipAnnotations(clean, 0);
      while (true) {
        i = JavaSourceScanner.skipWhitespace(clean, i);
        int end = identifierEnd(clean, i);
        if (end == i || !"final".equals(clean.substring(i, end))) break;
        i = end;
      }
      TypeToken type = readType(clean, i);
      if (type == null) return Collections.emptyList();
      String typeName = type.value;
      int afterType = JavaSourceScanner.skipWhitespace(clean, type.end);
      if (afterType + 2 < clean.length() && clean.startsWith("...", afterType)) {
        typeName += "[]";
        afterType += 3;
      }
      afterType = JavaSourceScanner.skipWhitespace(clean, afterType);
      int parameterNameEnd = identifierEnd(clean, afterType);
      if (parameterNameEnd == afterType) return Collections.emptyList();
      int trailing = JavaSourceScanner.skipWhitespace(clean, parameterNameEnd);
      while (trailing + 1 < clean.length() && clean.charAt(trailing) == '[') {
        int close = JavaSourceScanner.skipWhitespace(clean, trailing + 1);
        if (close >= clean.length() || clean.charAt(close) != ']') break;
        typeName += "[]";
        trailing = JavaSourceScanner.skipWhitespace(clean, close + 1);
      }
      result.add(signatureType(typeName));
    }
    return result;
  }

  private static List<String> splitTopLevel(String source, char separator) {
    ArrayList<String> parts = new ArrayList<>();
    int start = 0, parens = 0, brackets = 0, braces = 0, angles = 0;
    for (int i = 0; i < source.length(); i++) {
      char value = source.charAt(i);
      if (value == '(') parens++;
      else if (value == ')' && parens > 0) parens--;
      else if (value == '[') brackets++;
      else if (value == ']' && brackets > 0) brackets--;
      else if (value == '{') braces++;
      else if (value == '}' && braces > 0) braces--;
      else if (value == '<') angles++;
      else if (value == '>' && angles > 0) angles--;
      else if (value == separator && parens == 0 && brackets == 0 && braces == 0 && angles == 0) {
        parts.add(source.substring(start, i));
        start = i + 1;
      }
    }
    parts.add(source.substring(start));
    return parts;
  }

  private static String signatureType(String value) {
    return normalizeType(value).replace("java.lang.", "").replaceAll("\\s+", "");
  }

  private static String insertMembers(String source, ClassInfo owner, String generated, String newline) {
    int lineStart = source.lastIndexOf('\n', owner.close - 1) + 1;
    boolean closeOnOwnLine = true;
    for (int i = lineStart; i < owner.close; i++) {
      if (!Character.isWhitespace(source.charAt(i))) { closeOnOwnLine = false; break; }
    }
    int insertion = closeOnOwnLine ? lineStart : owner.close;
    String prefix = source.substring(0, insertion);
    String suffix = source.substring(insertion);
    StringBuilder output = new StringBuilder(source.length() + generated.length() + 8);
    output.append(prefix);
    if (output.length() > 0 && !endsWithNewline(output, newline)) output.append(newline);
    if (!endsWithTwoNewlines(output, newline)) output.append(newline);
    output.append(generated);
    if (!generated.endsWith(newline)) output.append(newline);
    output.append(suffix);
    return output.toString();
  }

  private static boolean endsWithNewline(StringBuilder value, String newline) {
    return value.length() >= newline.length()
        && value.substring(value.length() - newline.length()).equals(newline);
  }

  private static boolean endsWithTwoNewlines(StringBuilder value, String newline) {
    return value.length() >= 2 * newline.length()
        && value.substring(value.length() - 2 * newline.length()).equals(newline + newline);
  }

  private static void appendIndent(StringBuilder output, String indent) {
    output.append(indent);
  }

  private static String memberIndent(String source, ClassInfo owner, Field field) {
    if (field != null) {
      int lineStart = source.lastIndexOf('\n', field.nameStart - 1) + 1;
      String leading = leadingWhitespace(source, lineStart, field.nameStart);
      if (!leading.isEmpty()) return leading;
    }
    int classLine = source.lastIndexOf('\n', owner.open - 1) + 1;
    String classIndent = leadingWhitespace(source, classLine, owner.open);
    int i = owner.open + 1;
    while (i < owner.close) {
      int lineEnd = source.indexOf('\n', i);
      if (lineEnd < 0 || lineEnd > owner.close) lineEnd = owner.close;
      int first = i;
      while (first < lineEnd && (source.charAt(first) == ' ' || source.charAt(first) == '\t')) first++;
      if (first < lineEnd) {
        String candidate = leadingWhitespace(source, i, first);
        if (candidate.length() > classIndent.length()) return candidate;
        break;
      }
      i = lineEnd + 1;
    }
    return classIndent + "    ";
  }

  private static String leadingWhitespace(String source, int start, int end) {
    int i = Math.max(0, start);
    int limit = Math.max(i, Math.min(end, source.length()));
    while (i < limit && (source.charAt(i) == ' ' || source.charAt(i) == '\t')) i++;
    return source.substring(start, i);
  }

  private static boolean endsWithNewline(String value, String newline) {
    return value.endsWith(newline);
  }

  private static String newlineOf(String source) {
    return source.contains("\r\n") ? "\r\n" : "\n";
  }

  private static String capitalize(String value) {
    if (value.isEmpty()) return value;
    return Character.toUpperCase(value.charAt(0)) + value.substring(1);
  }

  public static String className(String source) {
    if (source == null) return null;
    String masked = JavaSourceScanner.maskNonCode(source);
    Matcher matcher = Pattern.compile(
        "\\bclass\\s+([\\p{javaJavaIdentifierStart}][\\p{javaJavaIdentifierPart}]*)")
        .matcher(masked);
    return matcher.find() ? matcher.group(1) : null;
  }

  /**
   * Extracts an XML string value selection and replaces it with {@code @string/name}.
   * Returns {@code null} for invalid ranges, identifiers, or unquoted values.
   */
  public static String extractResource(String source, int start, int end, String name) {
    if (source == null || start < 0 || end > source.length() || start >= end) return null;
    if (!Renamer.isValidJavaIdentifier(name) || Renamer.isKeyword(name)) return null;
    int q1 = source.lastIndexOf('"', start - 1);
    int q2 = source.indexOf('"', end);
    if (q1 < 0 || q2 < 0 || q2 <= q1) return null;
    return source.substring(0, q1 + 1) + "@string/" + name + source.substring(q2);
  }

  /** Returns an XML {@code <string>} entry. */
  public static String stringEntry(String name, String value) {
    return "    <string name=\"" + name + "\">" + value + "</string>\n";
  }
}
