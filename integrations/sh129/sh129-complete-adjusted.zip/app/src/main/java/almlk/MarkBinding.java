package almlk;

/**
 * قاعدتا **نِسبةِ العلامةِ إلى ملفٍّ** و**بُطلانِها بتحريرِ سطرِها** (الجولةُ ‏33).
 *
 * <p>العلةُ التي عالجناها: المحرِّرُ كانَ يقبلُ وسومَ لوحةِ المشروعِ ب<b>الاسمِ المجرَّدِ</b> عندما لا
 * يكونُ للتبويبِ مرجعٌ — وفي مشروعٍ نُسخُهُ المتعددةُ (أو ملفَّانِ بنفسِ الاسمِ في وحدتَيْنِ) تُرسمُ
 * بلاغاتُ ملفٍّ على نصِّ ملفٍّ آخرَ، فتظهرُ «مئاتُ الأخطاءِ العشوائيةِ» تحتَ الثوابتِ والمعاملاتِ وداخلَ
 * سلاسلِ النصِّ والتعليقاتِ، أي تحتَ رموزٍ لم يَدَّعِ فحصُها شيئًا قطُّ. المرجعُ لا يعرفُ هذا التساهلَ:
 * عقدُ المحرّكِ عندَهُ {@code mo769j6(String path, SyntaxError[] errors, boolean done)} — قائمةُ أخطاءٍ
 * لكلِّ <b>مسارٍ</b> تُستبدَلُ كلُّها ولا تُمزَجُ، والمحرِّرُ يسألُ بـ{@code getFilePath()} وحدَهُ.
 *
 * <p>والثانيةُ: وسمٌ حُسِبَ على سطرٍ ثمَّ حرّرَهُ المستخدمُ يبقى عندَ عمودِهِ القديمِ فيُخيطُ على
 * حروفٍ أخرى. عندَنا {@code ProjectDiagnostic.preview} يحملُ نصَّ السطرِ وقتَ الفحصِ، فيُراجَعُ قبلَ
 * الرسمِ؛ ولا حُكمَ بلا معاينةٍ (معاينةٌ فارغةٌ لا تُسقِطُ شيئًا، فالحجبُ بلا دليلٍ استبدالُ عِلّةٍ
 * بأُخرى).
 *
 * <p>صنفٌ منطقٌ خالصٌ: بلا Android وبلا خيوطٍ، تُغطِّيهِ مجموعةُ الانحدارِ مباشرةً.
 */
public final class MarkBinding {

  private MarkBinding() {}

  /**
   * هل تُرسَمُ علامةٌ صُنِعَت لملفٍّ مرجعُهُ {@code itemReference} داخلَ تبويبٍ مرجعُهُ
   * {@code tabReference}؟ الهُويّةُ التامّةُ أو لا رسمَ: الاسمُ المجرَّدُ ليس هُويّةً، ولا يُنجِبُ
   * قرابةَ مسارٍ.
   */
  public static boolean binds(String tabReference, String itemReference) {
    if (tabReference == null || itemReference == null) return false;
    if (tabReference.isEmpty() || itemReference.isEmpty()) return false;
    return FileReferences.same(tabReference, itemReference);
  }

  /**
   * مرجعُ التبويبِ: ما أُعطيَ عندَ الفتحِ أولًا، فإن لم يُعطَ فمسارُ الملفِّ نفسِهِ إذا كانَ تبويبٌ
   * مفتوحًا بمسارٍ مطلقٍ موجودٍ (وهو الغالبُ في فتحِ المتصفّحِ والتبويبِ المُعاوَدِ) — فلا يفقدُ ملفٌّ
   * وسومَهُ لأنَّ فاتحَهُ لم يحمِلْ مرجعًا، ولا يربحُ وسومَ غيرِهِ.
   */
  public static String tabReference(String given, String tabName, boolean tabNameIsExistingFile) {
    if (given != null && !given.isEmpty()) return given;
    if (tabName == null || tabName.isEmpty() || !tabNameIsExistingFile) return "";
    return tabName.charAt(0) == '/' ? tabName : "";
  }

  /**
   * هل بَطَلَ الوسمُ لأنَّ سطرَهُ تغيّرَ؟ {@code preview} نصُّ السطرِ كما رآهُ الفاحصُ (مَقصوصًا
   * مُهَوَّمًا)، و{@code currentLine} سطرُ المحرِّرِ الآنَ. سطرٌ اختفى (فارغٌ والمعاينةُ ليست فارغةً)
   * بُطلانٌ؛ ومعاينةٌ لا نصَّ لها لا حُكمَ فيها.
   */
  public static boolean isStale(String preview, String currentLine) {
    if (preview == null || preview.isEmpty()) return false;
    String now = currentLine == null ? "" : currentLine.trim();
    if (now.isEmpty()) return true;
    return !preview.equals(now);
  }
}
