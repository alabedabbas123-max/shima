package almlk;

/** Pure transformations shared by Java Code-menu commands and their regression tests. */
public final class CodeMenuCommands {
  private CodeMenuCommands() {}

  public static final class Edit {
    public final int start, end, selectionStart, selectionEnd;
    public final String replacement;

    private Edit(int start, int end, String replacement, int selectionStart, int selectionEnd) {
      this.start = start;
      this.end = end;
      this.replacement = replacement;
      this.selectionStart = selectionStart;
      this.selectionEnd = selectionEnd;
    }
  }

  /** Comments the covered lines, removes one comment layer, or toggles all-commented lines. */
  public static Edit commentLines(String source, int selectionStart, int selectionEnd, Boolean force) {
    if (source == null) return null;
    int[] range = lineRange(source, selectionStart, selectionEnd);
    int start = range[0], end = range[1];
    if (start >= end) return null;
    String region = source.substring(start, end);
    String[] lines = region.split("\n", -1);
    boolean allCommented = true, anyContent = false;
    for (String line : lines) {
      String trimmed = line.trim();
      if (trimmed.isEmpty()) continue;
      anyContent = true;
      if (!trimmed.startsWith("//")) {
        allCommented = false;
        break;
      }
    }
    if (!anyContent) return null;
    boolean addComment = force != null ? force : !allCommented;
    StringBuilder updated = new StringBuilder(region.length() + lines.length * 3);
    for (int i = 0; i < lines.length; i++) {
      String line = lines[i];
      String trimmed = line.trim();
      if (trimmed.isEmpty()) {
        updated.append(line);
      } else if (addComment) {
        if (trimmed.startsWith("//")) {
          updated.append(line);
        } else {
          int indent = indentationEnd(line);
          updated.append(line, 0, indent).append("// ").append(line.substring(indent));
        }
      } else if (trimmed.startsWith("//")) {
        int marker = line.indexOf("//");
        int content = marker + 2;
        if (content < line.length() && line.charAt(content) == ' ') content++;
        updated.append(line, 0, marker).append(line.substring(content));
      } else {
        updated.append(line);
      }
      if (i < lines.length - 1) updated.append('\n');
    }
    if (region.contentEquals(updated)) return null;
    String replacement = updated.toString();
    return new Edit(start, end, replacement, start, start + replacement.length());
  }

  /** Wraps the covered lines in a try/catch block, retaining their existing indentation. */
  public static Edit surroundWithTryCatch(
      String source, int selectionStart, int selectionEnd, String indentUnit) {
    if (source == null) return null;
    int[] range = lineRange(source, selectionStart, selectionEnd);
    int start = range[0], end = range[1];
    if (start >= end) return null;
    String region = source.substring(start, end);
    String[] lines = region.split("\n", -1);
    String baseIndent = "";
    boolean anyContent = false;
    for (String line : lines) {
      if (line.trim().isEmpty()) continue;
      anyContent = true;
      baseIndent = line.substring(0, indentationEnd(line));
      break;
    }
    if (!anyContent) return null;
    String unit = indentUnit == null ? "    " : indentUnit;
    String newline = source.contains("\r\n") ? "\r\n" : "\n";
    StringBuilder wrapped = new StringBuilder(region.length() + 96);
    wrapped.append(baseIndent).append("try {").append(newline);
    for (String line : lines) {
      if (line.trim().isEmpty()) wrapped.append(line);
      else wrapped.append(unit).append(line);
      wrapped.append(newline);
    }
    wrapped.append(baseIndent).append("} catch (Exception e) {").append(newline);
    wrapped.append(baseIndent).append(unit).append("e.printStackTrace();").append(newline);
    wrapped.append(baseIndent).append('}');
    String replacement = wrapped.toString();
    return new Edit(start, end, replacement, start + replacement.length(), start + replacement.length());
  }

  /** The exact text selected by the user, suitable for a prefilled Replace query. */
  public static String selectedText(String source, int selectionStart, int selectionEnd) {
    if (source == null) return "";
    int start = Math.max(0, Math.min(selectionStart, selectionEnd));
    int end = Math.min(source.length(), Math.max(selectionStart, selectionEnd));
    return end > start ? source.substring(start, end) : "";
  }

  private static int[] lineRange(String source, int selectionStart, int selectionEnd) {
    int start = Math.max(0, Math.min(selectionStart, source.length()));
    int end = Math.max(0, Math.min(selectionEnd, source.length()));
    if (end < start) {
      int swap = start;
      start = end;
      end = swap;
    }
    int effectiveEnd =
        end > start && end > 0 && source.charAt(end - 1) == '\n' ? end - 1 : end;
    int lineStart = start <= 0 ? 0 : source.lastIndexOf('\n', start - 1) + 1;
    int lineEnd = source.indexOf('\n', effectiveEnd);
    if (lineEnd < 0) lineEnd = source.length();
    return new int[] {lineStart, lineEnd};
  }

  private static int indentationEnd(String line) {
    int i = 0;
    while (i < line.length() && (line.charAt(i) == ' ' || line.charAt(i) == '\t')) i++;
    return i;
  }
}
