package almlk;

/**
 * قرارٌ واحدٌ مسبَقٌ لعمليةِ جَلبِ اعتمادٍ: ما الذي سيُفعَلَ، وبأيِّ إحداثيّةٍ، ولماذا رُفضَ المسارُ.
 *
 * <p>نمطُ المرجعِ (‏{@code abcd.Be#j6} ثمَّ {@code Hw(الإحداثيّةُ)} ثمَّ تحديثٌ بلا نافذةٍ) هو «الإدراجُ ثمَّ
 * الهضمُ»، لذلك لا يحملُ هذا الكائنُ سوى <em>القرارِ</em> ونصِّ السطرِ: التنفيذُ كلُّهُ في {@link
 * DependencyFetchQueue}، والفحصُ الذي أنتَجَهُ في {@link UnresolvedSymbolRule}. الحالاتُ مُسمّاةٌ لأنَّ البندَ
 * 4ب٢‏ج يشترطُ سببًا مسمًّى عندَ العجزِ، وسقوفٌ معلَنةٌ مع عدِّ التجاوزِ.
 *
 * <p>نقِيٌّ تمامًا: لا {@code android.*}، فلا يختبرُهُ سوى {@code javac} فوقَ {@code almlk/} وحدها.
 */
public final class DependencyFetchPlan {

  /** كمَ إحداثيّةً تُقبَلُ في خطّةٍ واحدةٍ؛ الزائدُ يُعَدُّ في {@link Tally#overflow} ويُطرَدُ. */
  public static final int MAX_COORDINATES = 16;

  public enum Action {
    /** لا شيءَ يُفعَلُ (رمزٌ لا يحتاجُ اعتمادًا، أو نصٌّ لا سطرَ استيرادَ فيه). */
    NONE,
    /** سطرُ {@code implementation} ناقصٌ في {@code dependencies {}} — الجَلبُ ثمَّ الإدراجُ. */
    ADD_GRADLE_LINE,
    /** الإحداثيّةُ المُشتَقّةُ من جيلٍ قديمٍ؛ تُهجَّرُ أولًا عبرَ خريطةِ التهجيرِ ثمَّ تُدرَجُ. */
    MIGRATE_THEN_ADD,
    /** السطرُ موجودٌ في ملفِّ البناءِ: لا كتابةَ ولا جَلبَ، ويُرفَعُ التشخيصُ بعدَ إعادةِ الفحصِ. */
    ALREADY_LISTED,
    /** لا مُرشَّحَ للاسمِ في المخزنِ المحليِّ ولا في خريطةِ التهجيرِ. */
    NOT_IN_CATALOG,
    /** أكثرُ من باقةٍ تُوفِّرُ الاسمَ: لا تخمينَ، والمستخدمُ يَختارُ من نافذةِ الإضافةِ القائمةِ. */
    AMBIGUOUS,
    /** الشبكةُ مَقطوعةٌ بتفضيلٍ أو بفشلٍ مُعلَنٍ: لا محاولةَ، والسببُ يُذكَرُ. */
    OFFLINE,
    /** لا ملفَّ بناءِ وحدةٍ للمشروعِ: الإدراجُ لا موضعَ له. */
    NO_BUILD_FILE,
    /** تجاوزَتِ الإحداثيّاتُ {@link #MAX_COORDINATES}: رُفِضَت الزائدةُ بعدَّها. */
    TOO_MANY
  }

  /** من أينَ جاءَتِ الإحداثيّةُ — يُطبعُ في السجلِّ ويُسجَّلُ للبوّابةِ. */
  public static final String SOURCE_STORE = "store";
  public static final String SOURCE_DERIVED = "derived";
  public static final String SOURCE_MIGRATED = "migrated";

  public final Action action;
  /** الاسمُ المُبسَّطُ الذي لم يُحَلَّ. */
  public final String symbol;
  /** الصيغةُ المؤهَّلةُ إن عُرِفَت (من سطرِ الاستيرادِ أو من مُرشَّحٍ وحيدٍ). */
  public final String qualified;
  /** {@code group:artifact[:version]} المُقرَّرةُ؛ فارغةٌ حينَ لا قرارَ. */
  public final String coordinate;
  public final String source;
  /** سببٌ قصيرٌ مُسمًّى (لا رسالةُ مستخدمٍ): {@code no_import}, {@code not_a_type}… */
  public final String reason;

  private DependencyFetchPlan(
      Action action, String symbol, String qualified, String coordinate, String source, String reason) {
    this.action = action == null ? Action.NONE : action;
    this.symbol = symbol == null ? "" : symbol;
    this.qualified = qualified == null ? "" : qualified;
    this.coordinate = coordinate == null ? "" : coordinate;
    this.source = source == null ? "" : source;
    this.reason = reason == null ? "" : reason;
  }

  public static DependencyFetchPlan of(
      Action action, String symbol, String qualified, String coordinate, String source, String reason) {
    return new DependencyFetchPlan(action, symbol, qualified, coordinate, source, reason);
  }

  public static DependencyFetchPlan none(String reason) {
    return new DependencyFetchPlan(Action.NONE, "", "", "", "", reason);
  }

  public static DependencyFetchPlan reject(Action action, String symbol, String reason) {
    return new DependencyFetchPlan(action, symbol, "", "", "", reason);
  }

  public boolean isActionable() {
    return (action == Action.ADD_GRADLE_LINE || action == Action.MIGRATE_THEN_ADD)
        && coordinate.indexOf(':') > 0;
  }

  /** مفتاحُ موردِ سطرِ الحالةِ الذي يُخبِرُ المستخدمَ بما آلَ إليهِ القرارُ. */
  public String statusKey() {
    switch (action) {
      case ADD_GRADLE_LINE:
      case MIGRATE_THEN_ADD:
        return "ui_fetch_status_planned";
      case ALREADY_LISTED:
        return "ui_fetch_status_listed";
      case NOT_IN_CATALOG:
        return "ui_fetch_status_not_found";
      case AMBIGUOUS:
        return "ui_fetch_status_ambiguous";
      case OFFLINE:
        return "ui_fetch_status_offline";
      case NO_BUILD_FILE:
        return "ui_fetch_status_no_build_file";
      case TOO_MANY:
        return "ui_fetch_status_too_many";
      default:
        return "";
    }
  }

  /** {@code group:artifact} بلا إصدارٍ — مفتاحُ خريطةِ التهجيرِ ومقياسُ التكرارِ في الطابورِ. */
  public String groupArtifact() {
    int first = coordinate.indexOf(':');
    if (first <= 0) return "";
    int second = coordinate.indexOf(':', first + 1);
    return second < 0 ? coordinate : coordinate.substring(0, second);
  }

  /** هل تحملُ الخطّةُ إصدارًا صريحًا؟ (لا {@code +} ولا خلوٌّ). */
  public boolean hasVersion() {
    int second = coordinate.indexOf(':', coordinate.indexOf(':') + 1);
    if (second < 0) return false;
    String version = coordinate.substring(second + 1).trim();
    return !version.isEmpty() && !"+".equals(version);
  }

  /** سطرُ ملفِّ البناءِ بصيغةِ الملفِّ؛ {@code null} حينَ لا إحداثيّةَ. */
  public String line(boolean kts) {
    if (coordinate.indexOf(':') <= 0) return null;
    return GradleDependencyEditor.mavenLine(coordinate, kts);
  }

  /** هُويّةُ الخطّةِ لإلغاءِ التكرارِ: الإحداثيّةُ أولًا ثمَّ الرمزُ، بلا حساسيةِ المسافاتِ. */
  public String key() {
    return isActionable() ? coordinate : action + ":" + symbol;
  }

  @Override
  public String toString() {
    return action + (coordinate.isEmpty() ? "" : " " + coordinate)
        + (symbol.isEmpty() ? "" : " for " + symbol)
        + (source.isEmpty() ? "" : " [" + source + "]");
  }

  /** هل {@code text} يذكرُ هذه الإحداثيّةَ (بأيِّ صيغةِ اقتباسٍ)؟ */
  public boolean isListedIn(String buildText, boolean kts) {
    String line = line(kts);
    return line != null && GradleDependencyEditor.containsDependency(buildText, line);
  }
}
