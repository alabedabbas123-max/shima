package almlk.design;

import android.graphics.Color;
import java.io.File;
import java.io.FileReader;
import java.util.HashMap;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

/**
 * حلّال موارد مشروع المستخدم للمصمم: يقرأ res/values/*.xml مرة واحدة ويحل
 * ‎@dimen/@color/@string/@integer/@bool — فتُعرض الأبعاد والألوان والنصوص الحقيقية
 * كما سيرسمها التطبيق، لا قيمًا افتراضية.
 */
public final class ResourceResolver {

  private final HashMap<String, String> dimens = new HashMap<>();
  private final HashMap<String, String> colors = new HashMap<>();
  private final HashMap<String, String> strings = new HashMap<>();
  private final HashMap<String, String> integers = new HashMap<>();
  private final HashMap<String, String> bools = new HashMap<>();

  /** يستنتج جذر res من مسار ملف التخطيط داخل res/layout ويحمّل كل ملفات values. */
  public static ResourceResolver forLayoutFile(String layoutPath) {
    ResourceResolver resolver = new ResourceResolver();
    if (layoutPath == null || layoutPath.isEmpty()) return resolver;
    String path = layoutPath;
    if (path.startsWith("content:")) {
      // SAF: المسار الحقيقي بعد ‎primary:‎ في الـURI المفكوك — يقرأ مباشرة مع صلاحية الملفات.
      String decoded = android.net.Uri.decode(path);
      int at = decoded.lastIndexOf("primary:");
      if (at < 0) return resolver;
      path = "/storage/emulated/0/" + decoded.substring(at + "primary:".length());
    }
    File layoutDir = new File(path).getParentFile();
    File resDir = layoutDir == null ? null : layoutDir.getParentFile();
    if (resDir == null || !new File(resDir, "values").isDirectory()) return resolver;
    File[] files = new File(resDir, "values").listFiles();
    if (files != null)
      for (File file : files)
        if (file.getName().endsWith(".xml")) resolver.loadValuesFile(file);
    return resolver;
  }

  private void loadValuesFile(File file) {
    try (FileReader reader = new FileReader(file)) {
      XmlPullParser parser = XmlPullParserFactory.newInstance().newPullParser();
      parser.setInput(reader);
      String pendingType = null, pendingName = null;
      StringBuilder pendingValue = null;
      for (int event = parser.getEventType();
          event != XmlPullParser.END_DOCUMENT;
          event = parser.next()) {
        if (event == XmlPullParser.START_TAG) {
          String tag = parser.getName();
          if ("dimen".equals(tag) || "color".equals(tag) || "string".equals(tag)
              || "integer".equals(tag) || "bool".equals(tag) || "item".equals(tag)) {
            String type = "item".equals(tag) ? parser.getAttributeValue(null, "type") : tag;
            String name = parser.getAttributeValue(null, "name");
            if (type != null && name != null) {
              pendingType = type;
              pendingName = name;
              pendingValue = new StringBuilder();
            }
          }
        } else if (event == XmlPullParser.TEXT && pendingValue != null) {
          pendingValue.append(parser.getText());
        } else if (event == XmlPullParser.END_TAG && pendingName != null) {
          store(pendingType, pendingName, pendingValue.toString().trim());
          pendingType = null;
          pendingName = null;
          pendingValue = null;
        }
      }
    } catch (Throwable ignored) {
      // ملف قيم تالف لا يُسقط المعاينة — تستمر بالموارد المحملة.
    }
  }

  private void store(String type, String name, String value) {
    switch (type) {
      case "dimen":
        dimens.put(name, value);
        break;
      case "color":
        colors.put(name, value);
        break;
      case "string":
        strings.put(name, value);
        break;
      case "integer":
        integers.put(name, value);
        break;
      case "bool":
        bools.put(name, value);
        break;
      default:
        break;
    }
  }

  /** حل قيمة سمة: مراجع ‎@type/name تُستبدل بقيمتها (مع تتبع مرجع يحيل لمرجع). */
  public String resolve(String raw) {
    String value = raw;
    for (int hops = 0; value != null && value.startsWith("@") && hops < 5; hops++) {
      if (value.startsWith("@android:")) return resolveAndroid(value);
      int slash = value.indexOf('/');
      if (slash < 0) return value;
      String type = value.substring(1, slash);
      String name = value.substring(slash + 1);
      String next;
      switch (type) {
        case "dimen":
          next = dimens.get(name);
          break;
        case "color":
          next = colors.get(name);
          break;
        case "string":
          next = strings.get(name);
          break;
        case "integer":
          next = integers.get(name);
          break;
        case "bool":
          next = bools.get(name);
          break;
        default:
          return value;
      }
      if (next == null) return value;
      value = next;
    }
    return value;
  }

  private String resolveAndroid(String value) {
    // ثوابت أندرويد الشائعة في التخطيطات — الأهم الشفافية والأبيض والأسود.
    switch (value) {
      case "@android:color/transparent":
        return "#00000000";
      case "@android:color/white":
        return "#FFFFFFFF";
      case "@android:color/black":
        return "#FF000000";
      case "@android:color/darker_gray":
        return "#FFAAAAAA";
      case "@android:color/holo_blue_light":
        return "#FF33B5E5";
      case "@android:color/holo_red_light":
        return "#FFFF4444";
      default:
        return value;
    }
  }

  public Integer color(String raw) {
    String resolved = resolve(raw);
    if (resolved == null || !resolved.startsWith("#")) return null;
    try {
      return Color.parseColor(resolved);
    } catch (IllegalArgumentException wrong) {
      return null;
    }
  }
}
