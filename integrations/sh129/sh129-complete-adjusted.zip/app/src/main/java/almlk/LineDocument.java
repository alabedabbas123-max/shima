package almlk;

import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;

/**
 * بند almlk ← دور كلاس abcd «C0001g» (موديل المستند): أسطر LineBuffer في قائمة، تحميل تدفقي
 * مباشر إلى أسطر، قراءات char[] خفيفة للرسم والمحللات، إشعارات تغيّر تزايدية، + عناوين
 * (إزاحة↔سطر/عمود) واستبدال نصي بالإزاحات (واجهة الإدخال والتراجع) كما في موديل المرجع.
 *
 * <p>كل الدوال مُزامَنة (synchronized): الكتابة من خيط الواجهة فقط، والقراءة الخلفية
 * (الملوّن) آمنة بمقاطع قصيرة لكل سطر — نفس عزل «C0001g» المستعمل في OConsole.
 */
public final class LineDocument {

  /** مستمع تغيير المستند — كل إشعار يخص سطرًا ما (الرسم يعيد حساب ضرورته فقط). */
  public interface ChangeListener {
    void onDocumentChanged(int fromLine, int toLine);
  }

  private final ArrayList<LineBuffer> lines = new ArrayList<>();
  private final ArrayList<ChangeListener> listeners = new ArrayList<>(); // متعدد: لوحة + ملوّن
  private long version;
  private int totalLength; // مجموع الأطوال + فواصل السطور — يُحدَّث تصاعديًا O(1)

  public LineDocument() {
    lines.add(new LineBuffer());
  }

  /** يضيف مستمع تغيّر (اللوحة والملوّن كلاهما يلزمان — لا كتابة فوق بعض). */
  public synchronized void addChangeListener(ChangeListener listener) {
    if (listener != null && !listeners.contains(listener)) listeners.add(listener);
  }

  public synchronized void removeChangeListener(ChangeListener listener) {
    listeners.remove(listener);
  }

  public synchronized int lineCount() {
    return lines.size();
  }

  /** نسخة قابلة للمقارنة لإرساء الإعادات — تتقدم مع كل تعديل. */
  public synchronized long version() {
    return version;
  }

  /** طول المستند بالأحرف (مع '\n' بين الأسطر) — O(1). */
  public synchronized int length() {
    return totalLength;
  }

  public synchronized LineBuffer line(int index) {
    return lines.get(index);
  }

  /** محتوى سطر كما char[] جديد (مناسب للرسم مباشرة). */
  public synchronized char[] lineChars(int index) {
    LineBuffer line = lines.get(index);
    char[] out = new char[line.length()];
    line.getChars(0, line.length(), out, 0);
    return out;
  }

  public synchronized int lineLength(int index) {
    return lines.get(index).length();
  }

  // ---------------- أساسيات التحرير السطري (كما في almlk الأول) ----------------

  public synchronized void setLine(int index, char[] content) {
    int before = lines.get(index).length();
    lines.get(index).replace(content);
    totalLength += lines.get(index).length() - before;
    changed(index, index);
  }

  public synchronized void insertLine(int index, char[] content) {
    lines.add(Math.min(index, lines.size()), new LineBuffer(content));
    totalLength += content.length + 1;
    changed(index, lines.size() - 1);
  }

  public synchronized void removeLine(int index) {
    LineBuffer removed = lines.remove(index);
    totalLength -= removed.length() + 1;
    if (lines.isEmpty()) lines.add(new LineBuffer());
    changed(index, Math.min(index, lines.size() - 1));
  }

  public synchronized void insertChar(int line, int at, char c) {
    lines.get(line).insert(at, c);
    totalLength++;
    changed(line, line);
  }

  public synchronized void insertChars(int line, int at, char[] data, int offset, int count) {
    lines.get(line).insert(at, data, offset, count);
    totalLength += count;
    changed(line, line);
  }

  public synchronized void delete(int line, int start, int count) {
    lines.get(line).delete(start, count);
    totalLength -= count;
    changed(line, line);
  }

  // ---------------- عناوين (إزاحة ↔ سطر/عمود) — بحث خطّي خفيف كما المرجع ----------------

  /** إزاحة بداية سطر (من 0). القيم خارج النطاق تُثبَّت. */
  public synchronized int lineStartOffset(int line) {
    int clamped = Math.max(0, Math.min(line, lines.size() - 1));
    int offset = 0;
    for (int i = 0; i < clamped; i++) offset += lines.get(i).length() + 1;
    return offset;
  }

  /** سطر إزاحة معيّنة. */
  public synchronized int lineForOffset(int offset) {
    int target = Math.max(0, Math.min(offset, totalLength));
    int sum = 0;
    for (int i = 0; i < lines.size(); i++) {
      int next = sum + lines.get(i).length();
      if (target <= next || i == lines.size() - 1) return i;
      sum = next + 1;
    }
    return 0;
  }

  /** إزاحة (سطر، عمود) مع تثبيت كامل. */
  public synchronized int offsetFor(int line, int column) {
    int clampedLine = Math.max(0, Math.min(line, lines.size() - 1));
    int clampedColumn = Math.max(0, Math.min(column, lines.get(clampedLine).length()));
    return lineStartOffset(clampedLine) + clampedColumn;
  }

  // ---------------- التحرير بالإزاحات (واجهة الإدخال/التراجع/اللصق) ----------------

  /** النص الكامل — بناء عند الطلب (المستدعي يخزّن حسب الإصدار). */
  @Override
  public synchronized String toString() {
    StringBuilder out = new StringBuilder(totalLength);
    for (int i = 0; i < lines.size(); i++) {
      LineBuffer line = lines.get(i);
      out.append(line);
      if (i + 1 < lines.size()) out.append('\n');
    }
    return out.toString();
  }

  /** مقتطف [start,end) — يستعمله القص/النسخ والتسجيل التراجعي. */
  public synchronized String subText(int start, int end) {
    int from = Math.max(0, Math.min(start, totalLength));
    int to = Math.max(from, Math.min(end, totalLength));
    StringBuilder out = new StringBuilder(to - from);
    int firstLine = lineForOffset(from);
    int lastLine = lineForOffset(to);
    int firstOffset = lineStartOffset(firstLine);
    int lastOffset = lineStartOffset(lastLine);
    for (int i = firstLine; i <= lastLine; i++) {
      LineBuffer line = lines.get(i);
      int lineStart = (i == firstLine) ? from - firstOffset : 0;
      int lineEnd = (i == lastLine) ? to - lastOffset : line.length();
      lineEnd = Math.max(lineStart, Math.min(lineEnd, line.length()));
      out.append(line.toString(), lineStart, lineEnd);
      if (i < lastLine) out.append('\n');
    }
    return out.toString();
  }

  /**
   * استبدال [start,end) بالنص (قد يحوي أسطرًا) — جوهر أسلوب تحرير «C0001g»:
   * رأس سطر البداية + النص الجديد مقسومًا أسطرًا + ذيل سطر النهاية. يعيد موضع نهاية المُدخَل.
   */
  public synchronized int replace(int start, int end, CharSequence text) {
    int from = Math.max(0, Math.min(start, totalLength));
    int to = Math.max(from, Math.min(end, totalLength));
    CharSequence inserted = text == null ? "" : text;
    int firstLine = lineForOffset(from);
    int lastLine = lineForOffset(to);
    int firstColumn = from - lineStartOffset(firstLine);
    int lastColumn = to - lineStartOffset(lastLine);

    // ذيل سطر النهاية قبل التعديل.
    String tail = lines.get(lastLine).toString();
    tail = tail.substring(Math.max(0, Math.min(lastColumn, tail.length())));

    // رأس سطر البداية + كل سطور النص الجديد + الذيل → سطور النتيجة.
    String head = lines.get(firstLine).toString();
    head = head.substring(0, Math.max(0, Math.min(firstColumn, head.length())));

    ArrayList<LineBuffer> fresh = new ArrayList<>();
    StringBuilder current = new StringBuilder(head);
    for (int i = 0; i < inserted.length(); i++) {
      char c = inserted.charAt(i);
      if (c == '\r') continue;
      if (c == '\n') {
        fresh.add(new LineBuffer(current.toString().toCharArray()));
        current.setLength(0);
      } else {
        current.append(c);
      }
    }
    int resultCaret = current.length();
    current.append(tail);
    fresh.add(new LineBuffer(current.toString().toCharArray()));

    lines.subList(firstLine, lastLine + 1).clear();
    lines.addAll(firstLine, fresh);
    recomputeLength();
    // إصلاح 1.0.17: نهاية المُدخَل تقع في «آخر» سطر من السطور الجديدة لا في سطر البداية —
    // الحساب السابق على firstLine كان يترك المؤشر مكانه عند Enter/اللصق متعدد الأسطر.
    int caretOffset = offsetFor(firstLine + fresh.size() - 1, resultCaret);
    changed(firstLine, lines.size() - 1);
    return caretOffset;
  }

  /** إعادة ضبط كاملة (فتح ملف): بناء أسطر من النص دفعة واحدة + تصفير تدرّجات خارجية. */
  public synchronized void setAll(CharSequence content) {
    lines.clear();
    if (content == null || content.length() == 0) {
      lines.add(new LineBuffer());
    } else {
      StringBuilder current = new StringBuilder();
      for (int i = 0; i < content.length(); i++) {
        char c = content.charAt(i);
        if (c == '\r') continue;
        if (c == '\n') {
          lines.add(new LineBuffer(current.toString().toCharArray()));
          current.setLength(0);
        } else {
          current.append(c);
        }
      }
      lines.add(new LineBuffer(current.toString().toCharArray()));
    }
    recomputeLength();
    changed(0, lines.size() - 1);
  }

  private void recomputeLength() {
    int sum = 0;
    for (LineBuffer line : lines) sum += line.length();
    totalLength = sum + lines.size() - 1;
  }

  private void changed(int from, int to) {
    version++;
    if (listeners.isEmpty()) return;
    // نسخة قبل البث: المستمع قد يعيد الدخول (طلب ملوّن/إعادة قياس) بأمان.
    ChangeListener[] snapshot;
    synchronized (this) {
      snapshot = listeners.toArray(new ChangeListener[0]);
    }
    for (ChangeListener target : snapshot) target.onDocumentChanged(from, to);
  }

  /**
   * التحميل التدفقي (أسلوب AIDE): قطع 8KB تُقرأ وتُبنى السطور مباشرة — لا String أصلي
   * كامل في الذاكرة. سعة السطر تُقدَّر من متوسط الأطوال لتقليل إعادة التخصيص.
   */
  public static LineDocument load(Reader reader) throws IOException {
    LineDocument document = new LineDocument();
    synchronized (document) {
      document.lines.clear();
      char[] chunk = new char[8192];
      StringBuilder pending = new StringBuilder(8192);
      int read;
      while ((read = reader.read(chunk)) != -1) {
        int start = 0;
        for (int i = 0; i < read; i++) {
          if (chunk[i] == '\n') {
            document.lines.add(buildLine(pending, chunk, start, i - start));
            pending.setLength(0);
            start = i + 1;
          }
        }
        for (int i = start; i < read; i++) if (chunk[i] != '\r') pending.append(chunk[i]);
      }
      if (pending.length() > 0 || document.lines.isEmpty()) {
        document.lines.add(buildLine(pending, null, 0, 0));
      }
      document.recomputeLength();
      document.version = 1;
    }
    return document;
  }

  /** يبني سطرًا من بقايا القطعة السابقة + مقطع القطعة الحالية، متجاوزًا '\r' من النص. */
  private static LineBuffer buildLine(
      StringBuilder pending, char[] segment, int off, int count) {
    int extra = 0;
    if (segment != null) {
      for (int i = off; i < off + count; i++) if (segment[i] != '\r') extra++;
    }
    char[] chars = new char[pending.length() + extra];
    if (pending.length() > 0) pending.getChars(0, pending.length(), chars, 0);
    int cursor = pending.length();
    if (segment != null) {
      for (int i = off; i < off + count; i++) {
        char c = segment[i];
        if (c != '\r') chars[cursor++] = c;
      }
    }
    return new LineBuffer(chars);
  }
}
