package almlk;

import android.app.Activity;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import androidx.core.content.ContextCompat;
import com.shima.demo.R;
import com.shima.demo.ThemeConfig;

/**
 * المصدرُ الواحدُ لنمطِ الشريطِ في التطبيقِ كلِّهِ: اللوحةُ المختارةُ تقرِّرُ — فاتحةٌ ⇒ {@code
 * ActivityActionbarThemeLight}، وداكنةٌ ⇒ {@code ActivityActionbarThemeDark}.
 *
 * <p>لمَ ملفٌّ واحدٌ؟ لأنَّ علّةَ 1.0.143 كانتْ التوزيعَ لا الترتيب: سطرُ {@code lightChromeTheme()} كانَ
 * <em>خِيارًا لكلِّ نشاطٍ</em>، فلم يعلنْهُ إلّا {@code MainActivity} و{@code ThemeActivity} — فبقيتْ
 * الإعداداتُ نفسُها (ومنها قسمُ الثيماتِ الذي تُختارُ منهُ اللوحة!) وشاشاتُ الأنماطِ والنبذةِ والرموزِ
 * مسمَّرةً على ما في المانيفستِ من {@code ActivityActionbarThemeDark}، ولا شيءَ يبدَّلُ عندَ اختيارِ
 * «أبيضَ» ولا عندَ اختيارِ «أسود». الآن القرارُ هنا، وكلُّ نشاطٍ يورثُهُ؛ ومَنْ لهُ نمطُهُ الخاصُّ
 * (سبلاشٌ، إنقاذٌ، مُعاينةُ مواردَ، مُصمِّمُ تخطيطٍ) يقولُ صفرًا فيُسقِطُ عنهُ الإلزام.
 *
 * <p>وماذا عنِ الألوانِ التي كانتْ تُدهَنُ شاشةً شاشةً؟ صارتْ من النمطِ نفسِهِ: {@code statusBarColor}
 * و{@code navigationBarColor} و{@code windowLightStatusBar} في {@code res/values/styles.xml}، فلا
 * شريطَ حالةٍ أسودَ على لوحةٍ فاتحة — وبقيَ من التلوينِ اليدويِّ ما لا يملكُهُ النمطُ فقط: مُحرِّرُ الكودِ
 * (ألوانُ اللوحةِ نفسها) وأيقوناتُ الشريطِ التي تُلبَسُ من {@link #navigationIcon}.
 */
public final class ChromeTheme {

  private ChromeTheme() {}

  /** نمطُ النشاطِ الذي تفرضُهُ اللوحةُ المختارة. */
  public static int resolve(Context context) {
    return new ThemeConfig(context).isLight()
        ? R.style.ActivityActionbarThemeLight
        : R.style.ActivityActionbarThemeDark;
  }

  /**
   * أيقونةُ التنقُّقِ في الشريطِ بلونِ نصِّ النمطِ الجاري: بيضاءُ على الأسودِ وسوداءُ على الفاتحِ — لأنَّ
   * المتّجَهَينِ في {@code res/drawable} أبيضَانِ خالصَين، فلو تُرِكا بلا لونٍ لاختفيَا على الشريطِ
   * الفاتح. التلوينُ هنا من <em>النمطِ المُطبَّقِ الآن</em> لا من جدولِ اللوحة، فلا مسارَينِ لسطرٍ واحد.
   */
  public static Drawable navigationIcon(Context context, int resource) {
    Drawable icon = ContextCompat.getDrawable(context, resource);
    if (icon != null) icon.setTint(primaryText(context));
    return icon;
  }

  /**
   * حالةُ نمطٍ مُطبَّقٍ لنشاطٍ واحد: يُثبَّتُ في {@code onCreate} قبلَ {@code super}، ويُراجَعُ عندَ كلِّ
   * استئنافٍ فتُعادُ بناءُ الشاشةِ إن تبدَّلَ النمطُ تحتَها — لأنَّ عناصرَ مُضخَّمةً لا تُصلَحُ
   * تلوينًا يدويًّا واحدًا واحدًا، ولأنَّ المستخدمَ يَرجعُ من الإعداداتِ إلى شاشةٍ حيّةٍ لا إلى فراغ.
   */
  public static final class Applied {
    private int style;

    /** {@code chromeStyle == 0}: للنشاطِ نمطُهُ الخاصُّ فلا يُمَسّ ولا يُراجَعُ لهُ. */
    public void install(Activity activity, int chromeStyle) {
      style = chromeStyle;
      if (chromeStyle != 0) activity.setTheme(chromeStyle);
    }

    /** لا تُلوَّنِ النوافذُ؛ أُهدمِ الشاشةِ وابنِها بالنمطِ الجديد كما يفعلُ المرجع. */
    public void follow(Activity activity) {
      if (style != 0 && style != resolve(activity)) activity.recreate();
    }
  }

  /** {@code ?android:attr/textColorPrimary} كما يراهُ هذا النشاطُ الآن. */
  public static int primaryText(Context context) {
    return themed(context, android.R.attr.textColorPrimary, 0xFFFFFFFF);
  }

  /** {@code ?android:attr/textColorSecondary}: الشروحُ والأسطرُ الثانويةُ على الشاشاتِ كلِّها. */
  public static int secondaryText(Context context) {
    return themed(context, android.R.attr.textColorSecondary, 0xFFBDBDBD);
  }

  /** {@code ?attr/color_app_background}: خلفيةُ شاشةٍ عامّةٍ (نبذةٌ، أذوناتٌ، صفحةُ إقلاعٍ معطوبة). */
  public static int appBackground(Context context) {
    return themed(context, R.attr.color_app_background, 0xFF000000);
  }

  /**
   * خلفيةُ لوحةٍ تُزرَعُ داخلَ المُحرِّرِ (مشاكلٌ، مخرجاتٌ، استعمالٌ): لونُ خلفيةِ اللوحةِ نفسِها، فيبقى
   * اللوحُ والرَّصيفُ من قرارٍ واحدٍ عندَ اختيارِ الثيم — لا رقمٌ صلبٌ يبقى فحميًّا على بياض.
   */
  public static int panelBackground(Context context) {
    return new ThemeConfig(context).color(ThemeConfig.BACKGROUND);
  }

  /**
   * نصُّ سجلِّ الانهيارِ على صفحاتِ الطوارئ: أحمرُ باهتٌ على السوادِ وقِرمِزيٌّ على البياض — ويُستنتَجُ من
   * سطوعِ لونِ النصِّ الجاري، لأنَّ هذه الصفحاتْ تُرسَمُ حينَ يفشلُ الإقلاعُ فلا تُقرَأُ فيها التفضيلات.
   */
  public static int errorText(Context context) {
    int text = primaryText(context);
    int luminance = (77 * ((text >> 16) & 0xFF) + 151 * ((text >> 8) & 0xFF) + 28 * (text & 0xFF)) / 256;
    return luminance > 128 ? 0xFFFFB4B4 : 0xFFB00020;
  }

  /** لونٌ من سمةِ النمطِ الجاري؛ بلا قرصٍ ولا تفضيلات — يصلحُ لمساراتِ الانهيارِ كلِّها. */
  private static int themed(Context context, int attribute, int fallback) {
    TypedArray typed = context.obtainStyledAttributes(new int[] {attribute});
    try {
      ColorStateList colors = typed.getColorStateList(0);
      return colors != null ? colors.getDefaultColor() : fallback;
    } finally {
      typed.recycle();
    }
  }
}
