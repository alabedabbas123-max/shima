package almlk;

import com.almlkid.kay.ui.CodeLanguageTools;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicReferenceArray;

/**
 * بند almlk ← الملوّن التزايدي «C0032va» بروحه الحرفية:
 *
 * <ul>
 *   <li>حالة معجمية لكل سطر: عادي/تعليق، ولـXML وسم وCDATA واقتباس مفرد/مزدوج عبر الأسطر؛
 *       تعيد الإعراب من أول سطر متّسخ وتتوقف عند التقارب.
 *   <li>يعمل على خيط خلفي واحد بعيدًا عن الواجهة؛ أول تنفيذ يكسو الشاشة فورًا دون انتظار أي
 *       معالجة أخرى (الملفات الضخمة تُلوَّن نافذةً نافذةً بصمت).
 *   <li>إلغاء المهام الباهتة: أي تغيّر جديد يلغي الجولة السابقة (جيل متقدّم).
 *   <li>أنماط النص وفهرس {@link XmlColorLiteral} ينشران ذريًا من المرور نفسه؛ لا تحليل في الرسم.
 *   <li>أنماط الإخراج تعيد استعمال ثوابت {@link CodeLanguageTools} — نفس لوحة ألوان التطبيق.
 * </ul>
 */
public final class LineStyler {

  /** يُستدعى على خيط الواجهة بعد كل جولة لإعادة رسم النطاق المتأثر. */
  public interface StylesListener {
    void onStylesUpdated(int fromLine, int toLine);
  }

  /** سطرًا لكلِّ دفعةِ نشرٍ: قلبٌ واحدٌ وطلبُ رسمٍ واحدٌ لكلِّ دفعةٍ (لا لكلِّ سطرٍ ولا لكلِّ ‏512). */
  private static final int SWAP_BATCH_LINES = 4096;

  /**
   * سقفُ نافذةِ التكسيةِ الفوريّةِ على خيطِ الطلبِ (طلبُ ١.٠.١٨٧): شاشةٌ كاملةُ السطورِ تُكسَى
   * قبلَ أوَّلِ إطارٍ — قِيستْ كلفتُها على مِضيفيَّةِ هذا الصنفِ بنحوِ ثلاثةِ أجزاءٍ من الألفِ من
   * الثانيةِ لكلِّ سطرٍ، فثلاثُمئةِ ألفِ مِلفٍ بمِئتينِ وستَّةِ وخمسينَ سطرًا لا يَبذُلُ أكثرَ من
   * بضعةِ ملليِ ثوانٍ، والباقي للخيْطِ الخلفيِّ.
   */
  public static final int SYNC_PRIME_LINES = 256;

  private static final int MODE_PLAIN = 0;
  private static final int MODE_JAVA = 1;
  private static final int MODE_XML = 2;
  private static final int MODE_SMALI = 3;
  private static final int MODE_CONF = 4; // properties/pro/ini/yml… — تعليق # وقيم فقط

  private static final int STATE_NORMAL = 0;
  private static final int STATE_BLOCK_COMMENT = 1; // /* ... */ أو <!-- ... -->
  private static final int STATE_XML_TAG = 2; // داخل وسم، واسم العنصر قُرئ
  private static final int STATE_XML_CDATA = 3; // <![CDATA[ ... ]]> عبر الأسطر
  private static final int STATE_XML_DOUBLE_QUOTE = 4; // قيمة سمة "..." عبر الأسطر
  private static final int STATE_XML_SINGLE_QUOTE = 5; // قيمة سمة '...' عبر الأسطر
  private static final int STATE_XML_TAG_EXPECT_NAME = 6; // سطر انتهى بعد < أو </ قبل الاسم
  /** سطرٌ وسطَ تعليقٍ وثائقٍ مُفتوح: آلةُ الكتليةِ نفسُها، ونمطُ الإرسامِ DOC_COMMENT. */
  private static final int STATE_DOC_COMMENT = 7;

  /** نتيجة سطر واحدة تُنشر ذريًا: لا يرى الرسم نمطًا جديدًا مع فهرس لون قديم. */
  private static final class LineResult {
    final int[] styles;
    final XmlColorLiteral[] colorLiterals;
    final int endState;
    /** نطاقات جافا في نهاية السطر (محليات/براميترات) — null لغير ملفات جافا. */
    final JavaLocalScope.State scope;

    LineResult(
        int[] styles, XmlColorLiteral[] colorLiterals, int endState, JavaLocalScope.State scope) {
      this.styles = styles;
      this.colorLiterals = colorLiterals;
      this.endState = endState;
      this.scope = scope;
    }
  }

  private final LineDocument document;
  /**
   * خيطُ العملِ يُنشَأُ عندَ الحاجةِ ولا يَموتُ موتًا دائمًا: انفصالُ صفحةٍ في ‏ViewPager كانَ
   * يُغلِقُهُ ‏`shutdownNow()` فلا تعودُ ‏`submit` تعملُ أبدًا — ومنهُ أنْ يَبقَى ملفٌّ كلُّهُ
   * بألوانِ السَّذاجةِ بعدَ أوَّلِ تمريرةِ تبويبٍ (شرطٌ دائمٌ ‏20: التلوينُ كاملٌ فورًا).
   */
  private ExecutorService worker;
  private StylesListener listener;

  private volatile AtomicReferenceArray<LineResult> lineResults = new AtomicReferenceArray<>(0);
  private volatile int generation;
  private Future<?> running;
  private int mode = MODE_PLAIN;
  /** ملف Gradle: لوحة جافا مع إبقاء أسماء الأوامر بيضاء (مطابقة مظهر المرجع). */
  private volatile boolean gradleFile = false;
  /** ملف جافا: البراميترات والمحليات Plain والحقول Identifier كما في المرجع. */
  private volatile boolean javaScope = false;
  private final JavaLocalScope scopeTracker = new JavaLocalScope();
  private String fileName = "";
  /**
   * إصدارُ المستندِ الذي اكتملَ اكساؤهُ، وعددُ السطورِ التي نُشِرَت لهُ: بهما تعرفُ الجولةُ أنَّ
   * عليها سطورًا ناقصةً فقط، فلا إعادةَ اكساءَ لملفٍّ مُكتمِلٍ ولا وميضَ بياضٍ بينَ ردَّينِ.
   */
  private volatile long styledVersion = -1L;
  private volatile int styledLines = 0;
  /** إصدارُ المستندِ عندَ دخولِ الجولةِ: اكتمالٌ على إصدارٍ غيرِهِ لا يُعلَّنُ اكتمالًا. */
  private volatile long versionAtPassStart = -1L;

  public LineStyler(LineDocument document) {
    this.document = document;
    document.addChangeListener(
        (from, to) -> {
          // النص يتغير فورًا على خيط الواجهة؛ أبطل نتائج الأسطر المتأثرة قبل طلب الجولة كي لا
          // يرسم إطار واحد زخرفة/نمطًا بائتًا فوق النص الجديد.
          invalidateResults(from, to);
          request(from, to);
        });
  }

  private void invalidateResults(int fromLine, int toLine) {
    AtomicReferenceArray<LineResult> snapshot = lineResults;
    int from = Math.max(0, fromLine);
    int to = Math.min(toLine, snapshot.length() - 1);
    for (int line = from; line <= to; line++) snapshot.set(line, null);
  }

  public void setListener(StylesListener listener) {
    this.listener = listener;
  }

  /** الملف/المحتوى كلُّهُ تغيَّرَ: تصفيرٌ كاملٌ وجولةٌ جديدةٌ. وما لم يتغيَّرْ لا يُصفَّرُ. */
  public void setFileName(String name) {
    String previous = fileName;
    fileName = name == null ? "" : name;
    String lower = fileName.toLowerCase(java.util.Locale.US);
    // ملفات البناء: لوحة جافا نفسها (بما فيها تلوين الدوال) لكن أسماء أوامر Gradle تبقى بيضاء.
    gradleFile = lower.endsWith(".gradle") || lower.endsWith(".gradle.kts");
    javaScope = lower.endsWith(".java") || lower.endsWith(".class");
    // ‎.class: العرض للقراءة مصدرُ جافا مولّد — يُلوَّن بلوحة جافا كاملة كما في المرجع.
    if (lower.endsWith(".java") || lower.endsWith(".class") || lower.endsWith(".kt") || lower.endsWith(".c")
        || lower.endsWith(".cpp") || lower.endsWith(".h") || lower.endsWith(".cs")
        || lower.endsWith(".gradle") || lower.endsWith(".kts") || lower.endsWith(".groovy")
        || lower.endsWith(".js") || lower.endsWith(".ts") || lower.endsWith(".json")
        || lower.endsWith(".css")) {
      mode = MODE_JAVA;
    } else if (XmlCodeFormatter.isXmlName(fileName) || lower.endsWith(".html")
        || lower.endsWith(".htm") || lower.endsWith(".svg")) {
      mode = MODE_XML;
    } else if (lower.endsWith(".smali")) {
      mode = MODE_SMALI;
    } else if (lower.endsWith(".properties") || lower.endsWith(".pro") || lower.endsWith(".ini")
        || lower.endsWith(".cfg") || lower.endsWith(".toml") || lower.endsWith(".yml")
        || lower.endsWith(".yaml") || lower.endsWith(".gitignore")) {
      mode = MODE_CONF;
    } else {
      mode = MODE_PLAIN;
    }
    synchronized (this) {
      if (fileName.equals(previous)) {
        // اسمٌ هو اسمُهُ: لا معنى لهدمِ جدولٍ كاملٍ بُنِيَ من هذا النصِّ نفسِهِ — كانَ الهدمُ هُنا
        // سببَ أنْ يبقى ملفٌّ كلُّهُ بألوانِ السَّذاجةِ بعدَ كلِّ إعادةِ ربطِ تبويبٍ (شرطٌ دائمٌ ‏20).
        ensureResultCapacity(Math.max(0, document.lineCount()));
      } else {
        // اسمٌ آخرَ = نصٌّ آخرَ: لا وجهَ لنتائجَ من غيرِ هذا الملفِ، فيُلغَى الجيلُ وتُفرَغِ الصفوفُ.
        generation++;
        if (running != null) running.cancel(false);
        lineResults = new AtomicReferenceArray<>(0);
        styledVersion = -1L;
        styledLines = 0;
      }
    }
    if (fileName.equals(previous)) requestMissing();
    else request(0, Integer.MAX_VALUE);
  }

  /** جولةٌ للسطورِ الناقصةِ وحدَها: ملفٌّ مُكتمِلُ الأكساءِ لا يُعادُ اكساؤهُ ولا يُلغَى لونُهُ. */
  public void requestMissing() {
    int lineCount = Math.max(0, document.lineCount());
    long version = document.version();
    synchronized (this) {
      if (version == styledVersion && styledLines >= lineCount
          && lineResults.length() >= lineCount) {
        return; // لا ناقصَ: لا إلغاءَ جيلٍ، ولا إعادةَ قراءةٍ، ولا وميضَ بياضٍ
      }
    }
    request(0, Integer.MAX_VALUE);
  }

  /** هل جدولُ الأنماطِ مُكتمِلٌ لهذا الإصدارِ من النصِّ؟ (تُثبِتُها البوَّابةُ وتَقرأُها الوصلةُ) */
  public synchronized boolean isComplete() {
    return styledVersion == document.version() && styledLines >= document.lineCount();
  }

  /** كم سطرًا نُشِرَ لهُ نمطٌ في الإصدارِ الجاري؟ (مِقياسُ «كاملٌ فورًا» لا انطباعٌ) */
  public int styledLineCount() {
    AtomicReferenceArray<LineResult> snapshot = lineResults;
    int published = 0;
    for (int i = 0; i < Math.min(snapshot.length(), document.lineCount()); i++) {
      if (snapshot.get(i) != null) published++;
    }
    return published;
  }

  /**
   * فحصُ المرجعِ في الكلاسِ المفتوحِ: هل سطرٌ ظاهرٌ بلا أكساءَ بعدُ؟ {@code true} تعني أنَّ الرسمَ
   * الحاليَّ سيُري سوادًا — فمَن يَسألُ يُلَوِّنُ الآنَ (‏1.0.189، طلبُ «إذا لم تَكُنِ الأكوادُ ملوَّنةً
   * لُوِّنَتْ تلقائيًّا»). لا قراءةَ نصَّ ولا إعادةَ بناءِ جدولٍ في هذا السؤالِ: محضُ {@code null}
   * على السطورِ المطلوبةِ، فيُستَطاعُ كلَّ إطارٍ.
   */
  public boolean needsColoring(int fromLine, int toLine) {
    int lineCount = Math.max(0, document.lineCount());
    if (lineCount == 0) return false;
    int from = Math.max(0, Math.min(fromLine, lineCount - 1));
    int to = Math.max(from, Math.min(toLine, lineCount - 1));
    for (int i = from; i <= to; i++) if (stylesForLine(i) == null) return true;
    return false;
  }

  /** طلب إكساء من سطر إلى سطر (تغيّر تزايدي أو تحديث شامل). */
  public void request(int fromLine, int toLine) {
    // لا بوابةَ هنا تُشبِهُ «التحليلُ مُتوقِّفٌ»: الأكساءُ محليٌّ لا يَنتظِرُ مُحلِّلًا ولا عمليةً
    if (fromLine <= 0 && toLine == Integer.MAX_VALUE && isComplete()) {
      return; // طلبٌ شاملٌ على ملفٍّ مُكتمِلِ الأكساءِ: لا جيلَ ليُلغَى ولا لونَ ليُمحَى (شرطٌ دائمٌ ‏20)
    }
    final int generationAtRequest;
    synchronized (this) {
      generationAtRequest = ++generation;
      if (running != null) running.cancel(false);
    }
    final int from = Math.max(0, fromLine);
    // طلبُ ١.٠.١٨٧: «مباشرةً عندَ الفتحِ». المحرِّكُ عندَ المرجعِ يَدفَعُ الملفَّ كلَّهُ في نداءٍ
    // واحدٍ («C0048c.m537j6» ← «mo660j6(path, 0, len, runs[], …)») فَيُرسَمُ أوَّلُ إطارٍ ملوَّنًا؛
    // وعندَنا الجدولُ يُبنَى على خيطٍ خلفيٍّ، فكانَ الإطارُ الأولُ ساذجًا ثمَّ يَنقَلِبُ لونًا —
    // وميضٌ عندَ كلِّ فتحٍ أو إعادةِ ربطِ تبويبٍ. النافذةُ أدناه تُكسَى على خيطِ الطلبِ نفسِهِ،
    // بقدرِ ما ينقصُ متصلًا من رأسِ النطاقِ وبسقفِ شاشةٍ واحدةٍ: سطرٌ له لونٌ لا يُعادُ اكساؤُهُ،
    // فتحريرُ ملفٍّ مُلوَّنٍ لا يَدفَعُ هُنا أكثرَ من أسطرِ تعديلِهِ، وما بقيَ من الملفِّ يُمضِيهِ
    // الخيطُ الخلفيُّ ناشرًا فوقَ المنشورِ لا هادمًا لهُ (شرطٌ دائمٌ ‏٢٠).
    int primeLines = 0;
    int lineCount = document.lineCount();
    while (primeLines < SYNC_PRIME_LINES && from + primeLines < lineCount
        && from + primeLines <= toLine && stylesForLine(from + primeLines) == null) {
      primeLines++;
    }
    if (primeLines > 0) {
      runStylingPass(generationAtRequest, from, from + primeLines - 1, primeLines);
      if (isComplete()) return; // قصيرٌ كُسِيَ كلُّهُ: لا خيطَ يُبعَثُ ولا جيلَ يُهدَمُ
    }
    running =
        executor()
            .submit(
                () -> runStylingPass(generationAtRequest, from, toLine, Integer.MAX_VALUE));
  }

  /**
   * الخيطُ الخلفيُّ يُبعَثُ عندَ الحاجةِ: بعدَ ‏`shutdown()` انفصالٍ لا يجوزُ أن يبقى ‏`submit`
   * مرفوضًا إلى أبدِ العمرِ — كانَ ذلكَ يَترُكُ الملفَّ كلَّهُ بسَّذاجةِ الألوانِ بعدَ أوَّلِ تمريرةِ
   * تبويبٍ في ‏ViewPager.
   */
  private synchronized ExecutorService executor() {
    ExecutorService current = worker;
    if (current == null || current.isShutdown()) {
      current = Executors.newSingleThreadExecutor();
      worker = current;
    }
    return current;
  }

  /**
   * جولةٌ واحدةٌ: من أولِ سطرٍ متّسخٍ حتى التقاربِ، والنتائجُ تُنشَرُ بقلبٍ واحدٍ لكلِّ دفعةٍ.
   * «maxLines» سقفُ ما تُكسِيهِ الجولةُ من أسطرٍ متّصلةٍ — به تُصبَحُ نافذةُ التكسيةِ الفوريّةِ
   * («SYNC_PRIME_LINES») مُنفَّذةً على خيطِ الطلبِ بنفسِ الكودِ والنشرِ والحالةِ الجاريةِ، لا بمسارٍ
   * ثانِيَ يُعيدُ اختراعَ اللكسير (شرطُ الإحلالِ).
   */
  private void runStylingPass(int generationAtRun, int from, int to, int maxLines) {
    int lineCount = document.lineCount();
    if (lineCount == 0) return;
    versionAtPassStart = document.version();
    int firstLine = Math.min(from, lineCount - 1);
    int lastTouched = firstLine - 1;
    int batchFrom = firstLine;

    // الصفحةُ الخلفيةُ تبدأُ نسخةً من المنشورِ: سطرٌ لم تَمسَّهُ الجولةُ لا يَفقدُ لونَهُ، ولا ترى
    // الواجهةُ نصفَ حالةٍ بينَ ردَّينِ — وهوَ قلبُ المِبدَّلينِ حرفيًّا عندَ المرجعِ (§١٫١).
    AtomicReferenceArray<LineResult> initial = lineResults;
    int capacity = Math.max(initial.length(), lineCount);
    AtomicReferenceArray<LineResult> back = new AtomicReferenceArray<>(capacity);
    for (int i = 0; i < initial.length() && i < capacity; i++) back.set(i, initial.get(i));
    LineResult previous = firstLine > 0 && firstLine - 1 < capacity ? back.get(firstLine - 1) : null;
    int state = previous == null ? STATE_NORMAL : previous.endState;
    JavaLocalScope.State scope = previous == null ? null : previous.scope;

    for (int line = firstLine;
        line < lineCount && line < capacity && line - firstLine < maxLines; line++) {
      if (generationAtRun != generation) return; // مهمة باهتة — تُترَكُ نتائجُها كلُّها.
      LineResult old = back.get(line);
      if (line > to && old != null && old.endState == state
          && JavaLocalScope.State.same(old.scope, scope)) {
        break; // تقارب مبكر: ما بعد النطاق المتّسخ ما زال يدخل بالحالة والنطاقات نفسها.
      }

      char[] chars;
      synchronized (document) {
        chars = document.lineChars(line);
      }
      lexLineEntryScope = scope;
      int[] styles = lexLine(chars, state, line);
      int endState = lexLineEndState;
      JavaLocalScope.State endScope = lexLineScope;
      XmlColorLiteral[] literals = lexLineColorLiterals;

      if (generationAtRun != generation) return;
      back.set(line, new LineResult(styles, literals, endState, endScope));
      state = endState;
      scope = endScope;
      lastTouched = line;

      // دفعةُ ‏4096 سطرًا:قلبٌ واحدٌ وطلبُ رسمٍ واحدٌ — لا «تدرّجٌ» يُري سوادًا ثمَّ لونًا.
      if (line - firstLine > 0 && (line - firstLine) % SWAP_BATCH_LINES == 0) {
        swapAndPost(generationAtRun, back, batchFrom, line, lineCount + 1);
        back = detachFront(back, capacity);
        capacity = back.length();
        batchFrom = line + 1;
      }
    }
    swapAndPost(generationAtRun, back, batchFrom, lastTouched, lineCount);
  }

  /**
   * النشرُ كلُّهُ هنا: قفلٌ حولَ التبديلِ وحدَهُ (كما عندَ المرجعِ)، ثمَّ ‏`post` واحدٌ للرسمِ،
   * وسِجلُّ الإصدارِ يَتقدَّمُ معَ اكتمالِ الجدولِ فَيَعرِفُ ‏{@link #requestMissing()} أنَّ شيئًا لا
   * ناقصَ.
   */
  private void swapAndPost(int generationAtRun, AtomicReferenceArray<LineResult> back, int from,
      int to, int lineCount) {
    if (to < from) return;
    synchronized (this) {
      if (generationAtRun != generation) return; // بائتةٌ: لا قلبَ لجدولٍ قديمٍ فوقَ الجديدِ
      lineResults = back;
      int published = 0;
      for (int i = 0; i < Math.min(back.length(), lineCount); i++) {
        if (back.get(i) != null) published++;
      }
      styledLines = published;
      // سِجلُّ الإصدارِ يتقدَّمُ بالاكتمالِ وحدَهُ: نصٌّ ناقصُ الأكساءِ لا يُعلَّنُ مُكتمِلًا أبدًا.
      if (published >= lineCount && versionAtPassStart == document.version()) {
        styledVersion = versionAtPassStart;
      }
    }
    postStylesUpdated(generationAtRun, from, to);
  }

  /** نسخةٌ طازجةٌ للمخزنِ الخَلفيِّ بعدَ قلبٍ وسَطيٍّ: يَحملُ كلَّ ما نُشِرَ، ولا يَحمِلُ مرجعَ المنشورِ. */
  private static AtomicReferenceArray<LineResult> detachFront(
      AtomicReferenceArray<LineResult> published, int capacity) {
    AtomicReferenceArray<LineResult> fresh = new AtomicReferenceArray<>(capacity);
    for (int i = 0; i < capacity; i++) fresh.set(i, published.get(i));
    return fresh;
  }

  private void postStylesUpdated(int generationAtRun, int from, int to) {
    if (to < from || listener == null) return;
    new android.os.Handler(android.os.Looper.getMainLooper())
        .post(
            () -> {
              StylesListener target = listener;
              if (target != null && generationAtRun == generation)
                target.onStylesUpdated(from, to);
            });
  }

  private int lexLineEndState = STATE_NORMAL;
  private JavaLocalScope.State lexLineEntryScope;
  private JavaLocalScope.State lexLineScope;
  private XmlColorLiteral[] lexLineColorLiterals = XmlColorLiteral.EMPTY_ARRAY;

  /** تكبير مخزن النتائج مع الحفاظ على الأسطر المنشورة؛ AtomicReferenceArray يعطي رؤية O(1). */
  private synchronized void ensureResultCapacity(int lineCount) {
    AtomicReferenceArray<LineResult> current = lineResults;
    if (current.length() >= lineCount) return;
    AtomicReferenceArray<LineResult> bigger = new AtomicReferenceArray<>(lineCount + 64);
    for (int i = 0; i < current.length(); i++) bigger.set(i, current.get(i));
    lineResults = bigger;
  }

  /** أنماط سطر (كما طوله) أو null إن لم يُكسَ بعد — قراءة الواجهة بلا حجب. */
  public int[] stylesForLine(int line) {
    AtomicReferenceArray<LineResult> snapshot = lineResults;
    if (line < 0 || line >= snapshot.length()) return null;
    LineResult result = snapshot.get(line);
    return result == null ? null : result.styles;
  }

  /** قيم ألوان XML في السطر؛ مصفوفة ثابتة منشورة مع أنماط السطر نفسها. */
  public XmlColorLiteral[] colorLiteralsForLine(int line) {
    AtomicReferenceArray<LineResult> snapshot = lineResults;
    if (line < 0 || line >= snapshot.length()) return XmlColorLiteral.EMPTY_ARRAY;
    LineResult result = snapshot.get(line);
    return result == null ? XmlColorLiteral.EMPTY_ARRAY : result.colorLiterals;
  }

  /**
   * انفصالُ الصفحةِ عن النافذةِ: يُلغَى العملُ الجاري ويُغلَقَ الخيطُ، وتَبقَى النتائجُ المنشورةُ
   * كلُّها مكانَها — فعودةُ التبويبِ إلى النافذةِ تَرسُمُ مُلوَّنةً من أوَّلِ إطارٍ بلا انتظارِ جولةٍ
   * ولا وميضِ سَّذاجةٍ (شرطٌ دائمٌ ‏20).
   */
  public void suspend() {
    synchronized (this) {
      generation++; // تُترَكُ الجولةُ الجاريَةُ نتائجَها كلَّها، لا نصفَها
      ExecutorService current = worker;
      if (current != null) current.shutdownNow();
      worker = null;
      running = null;
    }
  }

  /** عودةُ الصفحةِ: لا شيءَ ناقصًا ⇒ لا طلبَ أصلًا؛ وإلَّا فالفقدُ وحدَهُ يُكسَى. */
  public void resume() {
    requestMissing();
  }

  /** نهايةُ المحرِّرِ الحقيقيَّةُ ( ‏onDestroy ): هُنا وحدَهُ يُمحَى الجدولُ ويُغلَقَ الخيطُ. */
  public void shutdown() {
    suspend();
    synchronized (this) {
      lineResults = new AtomicReferenceArray<>(0);
      styledVersion = -1L;
      styledLines = 0;
    }
  }

  // ---------------- اللكسير السطري (حالات: عادي/كتلي) ----------------

  private int[] lexLine(char[] chars, int entryState, int lineNumber) {
    // كل لغة غير XML تنشر مصفوفة ألوان فارغة؛ فرع Java أدناه لم تتغير قواعده أو نواتجه.
    lexLineColorLiterals = XmlColorLiteral.EMPTY_ARRAY;
    // عزل كامل لمسار XML: آلة حالاته لا تدخل إطلاقًا إلى مسار Java/Smali/الإعدادات.
    if (mode == MODE_XML) return lexXmlLine(chars, entryState, lineNumber);
    int length = chars.length;
    int[] styles = new int[length];
    lexLineEndState = STATE_NORMAL;
    lexLineScope = lexLineEntryScope;
    final JavaLocalScope scope = javaScope && mode == MODE_JAVA ? scopeTracker : null;
    if (scope != null) scope.beginLine(lexLineEntryScope, styles);
    // سياق التصنيف داخل السطر (إثراء 1.0.16، ومطابقةُ لقطاتِ المصدرِ في تقريرِ 1.0.142):
    // qualifiedName: داخل اسم مؤهل بعد import/package حتى «;» → مقاطع الحزم NAMESPACE.
    // expectType/afterNew: بعد class/extends/new... → المعرف التالي نوع TAG.
    // afterDot: الرمزُ السابقُ نقطةٌ — لا يُبدِّلُ لونًا وحدَهُ، لكنَّهُ يُعلِمُ أنَّ الاسمَ عضوٌ
    // فَيُنظَرُ في مستقبِلِهِ (حقلُ محلِّيٍّ سادةٌ، وحقلُ الصنفِ معرِّفٌ)، ويُبقي «new» عبرَ السلسلة.
    boolean qualifiedName = false;
    boolean expectType = false;
    boolean afterNew = false; // «new Foo(» : الاسم استعمالُ نوع، لا دالة
    boolean afterDot = false;
    boolean nextAfterDot = false;
    int i = 0;
    if (entryState == STATE_BLOCK_COMMENT || entryState == STATE_DOC_COMMENT) {
      i = consumeBlockComment(chars, 0, styles, entryState == STATE_DOC_COMMENT);
      // consumeBlockComment يضبط نهاية الحالة بنفسه عند عدم الإنهاء فقط — لا فرض هنا.
      if (i >= length) return styles;
    }
    try {
    while (i < length) {
      char c = chars[i];
      if (c == ';') qualifiedName = false;
      if (c == ' ' || c == '\t') {
        i++;
        continue;
      }
      afterDot = nextAfterDot;
      nextAfterDot = false;
      if (c == '/' && i + 1 < length && chars[i + 1] == '/' && mode == MODE_JAVA) {
        fill(styles, i, length, CodeLanguageTools.COMMENT);
        i = length;
      } else if (c == '/' && i + 1 < length && chars[i + 1] == '*' && mode == MODE_JAVA) {
        // المصدرُ يفرقُ بينَهُما في مصنّفِ المحرّك (pa.J0 → وثائق، pa.j6 → تعليق)، فالفرقُ
        // نمطٌ مستقلٌ لا زخرفًا؛ وفراغُ الوثائق /**/ ليسَ وثائق لأنَّ إغلاقَها يلي فتحَها.
        boolean docComment = i + 2 < length && chars[i + 2] == '*' && !(i + 3 < length && chars[i + 3] == '/');
        i = consumeBlockComment(chars, i, styles, docComment);
      } else if (c == '#' && (mode == MODE_SMALI || mode == MODE_CONF)) {
        fill(styles, i, length, CodeLanguageTools.COMMENT);
        i = length;
      } else if (c == '"') {
        i = consumeQuoted(chars, i, styles, '"');
        if (scope != null) scope.literal();
      } else if (c == '\'') {
        i = consumeQuoted(chars, i, styles, '\'');
        if (scope != null) scope.literal();
      } else if (c == '@' && mode != MODE_XML && i + 1 < length
          && Character.isJavaIdentifierStart(chars[i + 1])) {
        int end = i + 1;
        while (end < length && Character.isJavaIdentifierPart(chars[end])) end++;
        fill(styles, i, end, CodeLanguageTools.ANNOTATION);
        if (scope != null) scope.literal();
        i = end;
      } else if (Character.isDigit(c)) {
        int end = i + 1;
        while (end < length
            && (Character.isLetterOrDigit(chars[end]) || chars[end] == '.' || chars[end] == '_'))
          end++;
        fill(styles, i, end, CodeLanguageTools.NUMBER);
        if (scope != null) scope.literal();
        i = end;
      } else if (c == '.' && mode == MODE_SMALI && i + 1 < length
          && Character.isJavaIdentifierStart(chars[i + 1])) {
        // تعليمة smali (.method .field .registers ...) — كلمات مفتاحية.
        int end = i + 1;
        while (end < length && Character.isJavaIdentifierPart(chars[end])) end++;
        fill(styles, i, end, CodeLanguageTools.KEYWORD);
        i = end;
      } else if ((c == 'L' || c == '[') && mode == MODE_SMALI
          && i + 1 < length && isSmaliTypeStart(chars, i)) {
        int end = i;
        while (end < length && chars[end] != ';') end++;
        // وصفُ النوعِ في smali صنفٌ لا دالةٌ: على سطرِ الأصنافِ (‏1.0.189، بعدَ أن صارَ سطرُ
        // الدالةِ لونَ الجسدِ — فلا يَسرِقُ «L…;» لونَهُ ولا يُترَكُ ساذجًا).
        fill(styles, i, Math.min(end + 1, length), CodeLanguageTools.TAG);
        i = Math.min(end + 1, length);
      } else if (c == 'v' && mode == MODE_SMALI && i + 1 < length
          && Character.isDigit(chars[i + 1])) {
        int end = i + 1;
        while (end < length && Character.isDigit(chars[end])) end++;
        fill(styles, i, end, CodeLanguageTools.NUMBER);
        i = end;
      } else if (Character.isJavaIdentifierStart(c)) {
        int end = i + 1;
        while (end < length && Character.isJavaIdentifierPart(chars[end])) end++;
        String word = new String(chars, i, end - i);
        if (mode == MODE_JAVA && PRIMITIVE_TYPES.contains(word)) {
          // قاعدة المصدر: الأنواع البدائية (void/float/int...) زرقاء كنوع لا حمراء ككلمة.
          fill(styles, i, end, CodeLanguageTools.TAG);
          expectType = false;
          afterNew = false;
          if (scope != null) scope.primitiveType();
        } else if (isKeyword(word) && (scope == null || !scope.usedAsName(word))) {
          fill(styles, i, end, CodeLanguageTools.KEYWORD);
          if (scope != null) scope.keyword(word);
          if (mode == MODE_JAVA) {
            if ("import".equals(word) || "package".equals(word)) qualifiedName = true;
            // «Foo.class.getX()»: class بعد نقطة حرفية صنف، ما بعدها عضو لا نوع.
            boolean classLiteral = "class".equals(word) && i > 0 && chars[i - 1] == '.';
            afterNew = "new".equals(word);
            expectType = ("class".equals(word) && !classLiteral) || "interface".equals(word)
                || "enum".equals(word)
                || "extends".equals(word) || "implements".equals(word) || "new".equals(word)
                || "instanceof".equals(word) || "throws".equals(word) || "record".equals(word);
          }
        } else if (mode == MODE_JAVA) {
          // تصنيفُ المصدرِ كما تُريهِ لقطاتُهُ (تقريرُ 1.0.142): اسمُ الدالةِ **سادةٌ** دائمًا —
          // تعريفًا أو نداءً، محلِّيًا أو موروثًا عبرَ نقطةٍ أو صنفٍ أو سلسلةِ نداءات. فلا قوسُ نداءٍ
          // يُلوَّنُ ولا نقطةُ تُبدِّلُ لونًا: «void onCreate() {}» و«super.onCreate();» و
          // «this.clibs.getKay();» و«loadSettings();» و«mResources.getResources();» كلُّها بلونِ
          // السادة. ويبقى ملوَّنًا: النوعُ أزرقُ، وعضوُ الصنفِ عنبريُّ المعرِّف، والثابتِ العلَّامي،
          // ومقاطعُ اسمِ الباقةِ بعدَ import/package.
          int next = end;
          while (next < length && (chars[next] == ' ' || chars[next] == '\t')) next++;
          boolean function = next < length && chars[next] == '(';
          // وصولٌ إلى عضوٍ بالنقطة: حقلُ **محلِّيٍّ** سادةٌ عندَ المصدرِ («conf.locale» بيضاءٌ لا
          // عنبريَّة) لأنَّهُ لا يُحَلُّ إلى حقلٍ في الصنف، وحقلُ الصنفِ و«this.x» معرِّفٌ عنبري.
          boolean memberAccess = afterDot && !qualifiedName;
          boolean localField =
              memberAccess && scope != null && scope.isLocal(identifierBeforeDot(chars, i));
          if (qualifiedName && !Character.isUpperCase(word.charAt(0))) {
            fill(styles, i, end, CodeLanguageTools.NAMESPACE);
          } else if (isAllCapsConstant(word)) {
            // الثوابت ALL_CAPS (VISIBLE/MIN_...) معرفات عنبرية لا أنواعًا رغم بدايتها الكبيرة.
            // استثناءُ ملفاتِ البناءِ (طلبُ 1.0.158): «JavaVersion.VERSION_17» وصولٌ إلى عضوٍ —
            // الرأسُ الكبيرُ يبقى بلونِ الأصنافِ في الفرعِ الذي بعدَهُ، والذيلُ العلّاميُّ يسقطُ إلى
            // لونِ الدوالِ (سادةٌ). والفرعُ يبتلعُ الكلمةَ عمدًا: لو تُرِكَتْ لفرعِ الأنواعِ لَزُرِقَتْ
            // لأنَّ أوَّلَها حرفٌ كبيرٌ — وهو خطأُ «VERSION_17» الذي رَآهُ المستخدمُ في build.gradle.
            if (!gradleFile) fill(styles, i, end, CodeLanguageTools.IDENTIFIER);
          } else if (function && !afterNew && !gradleFile) {
            // طلبُ ‏1.0.189 (وليس اختراعًا): اسمُ الدالةِ يَأخُذُ نمطَ FUNCTION كما كانَ، لكنَّ لونَهُ
            // سطرُ «Plain» — لأنَّ «EnumC0058m» لا نمطَ للدالةِ فيهِ و«ColorDefault» لا سطرَ لها، فلونُ
            // ما لا سطرَ لهُ لونُ الجسدِ. التعريفُ والنداءُ العاريُّ والمنادى عبرَ نقطةٍ أو سلسلةٍ أو
            // {@code super} نمطٌ واحدٌ، والحقولُ والمحلياتُ على سطرِها، والوراثةُ لا تُبدِّلُ لونًا لأنَّ
            // التصنيفَ نحوِيٌّ. استثناءُ ملفاتِ البناءِ باقٍ: اسمُ الأمرِ ساذجٌ كما قرَّرَ المُستخدِمُ.
            fill(styles, i, end, CodeLanguageTools.FUNCTION);
          } else if (afterNew || expectType || Character.isUpperCase(word.charAt(0))) {
            // «new Foo(» و«new Outer.Inner(» و«extends Outer.Base»: سلسلةُ أنواعٍ زرقاء، والنقطةُ
            // لا تُسقطُ «new» ولا تُحيلُ الاسمَ الكبيرَ عضوًا مموَّهًا.
            fill(styles, i, end, CodeLanguageTools.TAG);
          } else if (!localField && !gradleFile) {
            fill(styles, i, end, CodeLanguageTools.IDENTIFIER); // المتغيرات/الحقول/البراميترات
          }
          // في gradle: أسماء الأوامر (implementation/android/...) تبقى بيضاء كما في المرجع.
          if (scope != null && !memberAccess) {
            // المرجعُ يَنسِبُ اسمَ الباني إلى TYPE_IDENTIFIER (نداءُ المحرِّكِ «C0048c.m534FH») لا
            // إلى ساذجٍ، فالفرعُ الأوَّلُ طلبُ ١.٠.١٨٧: «public Abbas(){}» يُلَوَّنُ Abbas كتلوينِ
            // عباسَ نفسِهِ صنفًا في كلِّ موضعٍ. والبراميتراتُ والمحلياتُ سادةٌ، والحقولُ Identifier.
            int role = scope.identifier(chars, i, end, word);
            if (role == JavaLocalScope.ROLE_CONSTRUCTOR) {
              fill(styles, i, end, CodeLanguageTools.TAG);
            } else if (role == JavaLocalScope.ROLE_LOCAL
                && styles[i] == CodeLanguageTools.IDENTIFIER) {
              fill(styles, i, end, 0);
            }
          }
          expectType = false;
        }
        i = end;
      } else if ("(){}[];,.".indexOf(c) >= 0) {
        // فواصل وترقيم (أقواس/فواصل/نقاط) — فئة مستقلة زرقاء كما في المصدر.
        styles[i] = CodeLanguageTools.SEPARATOR;
        // النقطةُ وحدها تفتحُ «وصولًا إلى عضو» في ما بعدَها وتُبقي «new» عبرَها، وكلُّ فاصلٍ
        // غيرَها يُغلقُها. لا تُبدِّلُ النقطةُ لونًا بذاتِها: اسمُ الدالةِ سادةٌ قبلَها وبعدَها.
        nextAfterDot = c == '.';
        afterNew = c == '.' && afterNew;
        if (scope != null) scope.punctuation(chars, i);
        i++;
      } else if ("=+-*/%&|!<>~^?:".indexOf(c) >= 0) {
        // عواملُ — لها لونُ العاملِ عندَ المصدرِ، و«new» يسقطُ بها ولا تُفتَحُ بها النقطة.
        styles[i] = CodeLanguageTools.OPERATOR;
        afterNew = false;
        if (scope != null) scope.punctuation(chars, i);
        i++;
      } else {
        if (scope != null) scope.punctuation(chars, i);
        i++;
      }
    }
    } finally {
      if (scope != null) lexLineScope = scope.endLine();
    }
    return styles;
  }

  /**
   * مُكْسي XML وفهرس اللون في مرور واحد معزول كليًا عن Java. يحفظ عبر السطور حالات الوسم
   * والتعليق وCDATA ونوعي الاقتباس، فلا يُفسَّر &gt; داخل قيمة متعددة الأسطر كنهاية وسم.
   */
  private int[] lexXmlLine(char[] chars, int entryState, int lineNumber) {
    int length = chars.length;
    int[] styles = new int[length];
    ArrayList<XmlColorLiteral> colors = null;
    int i = 0;
    boolean inTag = entryState == STATE_XML_TAG
        || entryState == STATE_XML_TAG_EXPECT_NAME
        || entryState == STATE_XML_DOUBLE_QUOTE
        || entryState == STATE_XML_SINGLE_QUOTE;
    boolean expectElementName = entryState == STATE_XML_TAG_EXPECT_NAME;

    // استمرار تعليق من السطر السابق: لا تُفهرس أي قيم داخله.
    if (entryState == STATE_BLOCK_COMMENT) {
      int end = findToken(chars, 0, "-->");
      if (end < 0) {
        fill(styles, 0, length, CodeLanguageTools.COMMENT);
        return finishXmlLine(styles, colors, STATE_BLOCK_COMMENT);
      }
      i = end + 3;
      fill(styles, 0, i, CodeLanguageTools.COMMENT);
      inTag = false;
    } else if (entryState == STATE_XML_CDATA) {
      // CDATA محتوى خام: يُلوّن Literal ولا يُفسر ما بداخله كألوان أو وسوم.
      int end = findToken(chars, 0, "]]>");
      if (end < 0) {
        fill(styles, 0, length, CodeLanguageTools.STRING);
        return finishXmlLine(styles, colors, STATE_XML_CDATA);
      }
      i = end + 3;
      fill(styles, 0, i, CodeLanguageTools.STRING);
      inTag = false;
    } else if (entryState == STATE_XML_DOUBLE_QUOTE
        || entryState == STATE_XML_SINGLE_QUOTE) {
      char quote = entryState == STATE_XML_DOUBLE_QUOTE ? '"' : '\'';
      int close = findChar(chars, 0, quote);
      int contentEnd = close < 0 ? length : close;
      colors = collectXmlColors(chars, 0, contentEnd, lineNumber, colors);
      if (close < 0) {
        fill(styles, 0, length, CodeLanguageTools.STRING);
        return finishXmlLine(styles, colors, entryState);
      }
      i = close + 1;
      fill(styles, 0, i, CodeLanguageTools.STRING);
      inTag = true;
      expectElementName = false;
    }

    while (i < length) {
      char c = chars[i];
      if (!inTag) {
        if (c == '<' && matches(chars, i, "<!--")) {
          int end = findToken(chars, i + 4, "-->");
          if (end < 0) {
            fill(styles, i, length, CodeLanguageTools.COMMENT);
            return finishXmlLine(styles, colors, STATE_BLOCK_COMMENT);
          }
          int after = end + 3;
          fill(styles, i, after, CodeLanguageTools.COMMENT);
          i = after;
          continue;
        }
        if (c == '<' && matches(chars, i, "<![CDATA[")) {
          int end = findToken(chars, i + 9, "]]>");
          if (end < 0) {
            fill(styles, i, length, CodeLanguageTools.STRING);
            return finishXmlLine(styles, colors, STATE_XML_CDATA);
          }
          int after = end + 3;
          fill(styles, i, after, CodeLanguageTools.STRING);
          i = after;
          continue;
        }
        if (c == '<') {
          styles[i] = CodeLanguageTools.KEYWORD;
          inTag = true;
          expectElementName = true;
          i++;
          continue;
        }
        if (c == '#') {
          XmlColorLiteral literal = XmlColorLiteral.parseAt(chars, i, length, lineNumber);
          if (literal != null) {
            if (colors == null) colors = new ArrayList<>();
            colors.add(literal);
            i = literal.endColumn;
            continue;
          }
        }
        if (c == '&') {
          // كيان &amp; / &#160; — قيمة حرفية خضراء كما يرسمها المرجع.
          int end = i + 1;
          while (end < length && end - i < 10
              && (Character.isLetterOrDigit(chars[end]) || chars[end] == '#')) end++;
          if (end < length && chars[end] == ';') {
            fill(styles, i, end + 1, CodeLanguageTools.STRING);
            i = end + 1;
            continue;
          }
        }
        i++; // نص حر بين الوسوم — أبيض Plain.
        continue;
      }

      // داخل وسم (ولو عبر أسطر متعددة):
      if (c == '>') {
        styles[i] = CodeLanguageTools.KEYWORD;
        inTag = false;
        expectElementName = false;
        i++;
        continue;
      }
      if (c == '/' || c == '?' || c == '!') {
        styles[i] = CodeLanguageTools.KEYWORD;
        i++;
        continue;
      }
      if (c == '"' || c == '\'') {
        char quote = c;
        int close = findChar(chars, i + 1, quote);
        int contentEnd = close < 0 ? length : close;
        colors = collectXmlColors(chars, i + 1, contentEnd, lineNumber, colors);
        if (close < 0) {
          fill(styles, i, length, CodeLanguageTools.STRING);
          return finishXmlLine(
              styles,
              colors,
              quote == '"' ? STATE_XML_DOUBLE_QUOTE : STATE_XML_SINGLE_QUOTE);
        }
        int after = close + 1;
        fill(styles, i, after, CodeLanguageTools.STRING);
        i = after;
        continue;
      }
      if (c == '=') {
        styles[i] = CodeLanguageTools.OPERATOR;
        i++;
        continue;
      }
      if (Character.isJavaIdentifierStart(c) || c == ':') {
        int end = i + 1;
        while (end < length
            && (Character.isJavaIdentifierPart(chars[end])
                || chars[end] == '-' || chars[end] == ':' || chars[end] == '.')) end++;
        // طلبُ المستخدمِ على 1.0.158: ما بعدَ اسمِ العنصرِ سمةٌ (`android:id`، `xmlns:android`،
        // `android:label`) — تُترَكُ **سادةً** بلونِ اسمِ الدالةِ في جافا (`onCreate`)، لا عنبريّةً.
        // البنيةُ لا تضيعُ: اسمُ العنصرِ و`<` و`>` و`/` تبقى كلماتٍ، والقيمةُ المقتبسةُ خضراءُ،
        // و`=` عاملٌ. ولا مسارَ آخرَ يقرأُ VARIABLE هنا، فبقيةُ اللغاتِ لا تُمَسُّ.
        if (expectElementName) fill(styles, i, end, CodeLanguageTools.KEYWORD);
        expectElementName = false;
        i = end;
        continue;
      }
      i++;
    }

    int endState = inTag
        ? (expectElementName ? STATE_XML_TAG_EXPECT_NAME : STATE_XML_TAG)
        : STATE_NORMAL;
    return finishXmlLine(styles, colors, endState);
  }

  private int[] finishXmlLine(
      int[] styles, ArrayList<XmlColorLiteral> colors, int endState) {
    lexLineEndState = endState;
    lexLineColorLiterals = colors == null || colors.isEmpty()
        ? XmlColorLiteral.EMPTY_ARRAY
        : colors.toArray(new XmlColorLiteral[colors.size()]);
    return styles;
  }

  /** يفهرس الألوان داخل جزء مسموح (نص XML أو قيمة مقتبسة) دون تخصيص إن لم يجد شيئًا. */
  private ArrayList<XmlColorLiteral> collectXmlColors(
      char[] chars,
      int from,
      int to,
      int lineNumber,
      ArrayList<XmlColorLiteral> colors) {
    int i = Math.max(0, from);
    int limit = Math.min(chars.length, to);
    while (i < limit) {
      if (chars[i] != '#') {
        i++;
        continue;
      }
      XmlColorLiteral literal = XmlColorLiteral.parseAt(chars, i, limit, lineNumber);
      if (literal == null) {
        i++;
        continue;
      }
      if (colors == null) colors = new ArrayList<>();
      colors.add(literal);
      i = literal.endColumn;
    }
    return colors;
  }

  private int findToken(char[] chars, int from, String token) {
    int last = chars.length - token.length();
    for (int i = Math.max(0, from); i <= last; i++) if (matches(chars, i, token)) return i;
    return -1;
  }

  private int findChar(char[] chars, int from, char target) {
    for (int i = Math.max(0, from); i < chars.length; i++) if (chars[i] == target) return i;
    return -1;
  }

  /**
   * اسمُ المُستقبِلِ الذي تليهِ النقطةُ مباشرةً — «conf» في «conf.locale». بلاهُ خطأُ برنامجٍ،
   * ولا يُعادُ منه شيءٌ إن لم تكن النقطةُ حيث تُوقَّع (فلا محليَّ حينَئذٍ ولا سادةَ زائدة).
   */
  private static String identifierBeforeDot(char[] chars, int memberStart) {
    int k = memberStart - 1;
    while (k >= 0 && (chars[k] == ' ' || chars[k] == '\t')) k--;
    if (k < 0 || chars[k] != '.') return null;
    k--;
    while (k >= 0 && (chars[k] == ' ' || chars[k] == '\t')) k--;
    int end = k + 1;
    while (k >= 0 && Character.isJavaIdentifierPart(chars[k])) k--;
    return end - (k + 1) > 0 ? new String(chars, k + 1, end - (k + 1)) : null;
  }

  private boolean matches(char[] chars, int at, String token) {
    if (at + token.length() > chars.length) return false;
    for (int i = 0; i < token.length(); i++)
      if (chars[at + i] != token.charAt(i)) return false;
    return true;
  }

  private boolean isSmaliTypeStart(char[] chars, int at) {
    if (chars[at] == '[') return true;
    if (at + 1 >= chars.length) return false;
    char next = chars[at + 1];
    return Character.isUpperCase(next) || next == 'a' || next == 'b' || next == 'c';
  }

  private int consumeQuoted(char[] chars, int start, int[] styles, char quote) {
    int i = start + 1;
    boolean escaped = false;
    while (i < chars.length) {
      char c = chars[i];
      if (escaped) escaped = false;
      else if (c == '\\') escaped = true;
      else if (c == quote) {
        i++;
        break;
      }
      i++;
    }
    fill(styles, start, Math.min(i, chars.length), CodeLanguageTools.STRING);
    return Math.min(i, chars.length);
  }

  private int consumeBlockComment(char[] chars, int start, int[] styles) {
    return consumeBlockComment(chars, start, styles, false);
  }

  /**
   * تعليقٌ كتليٌ يحملُ نوعَهُ عابرَ السطور: لَوثائقٍ نمطٌ وحالةُ استئنافٍ خاصَّة، فلا
   * ينقلبُ /** إلى /* في السطر التالي ولا عكسَ ذلك، ولا يُبدلُ نمطَ ما بعدَ إغلاق.
   */
  private int consumeBlockComment(char[] chars, int start, int[] styles, boolean docComment) {
    String terminator = mode == MODE_XML ? "-->" : "*/";
    int style = docComment ? CodeLanguageTools.DOC_COMMENT : CodeLanguageTools.COMMENT;
    int openState = docComment ? STATE_DOC_COMMENT : STATE_BLOCK_COMMENT;
    int i = start;
    int from = start;
    while (i < chars.length) {
      if (matches(chars, i, terminator)) {
        i += terminator.length();
        fill(styles, from, Math.min(i, chars.length), style);
        return i;
      }
      i++;
    }

    fill(styles, from, chars.length, style);
    lexLineEndState = openState;
    return chars.length;
  }

  private static void fill(int[] styles, int from, int to, int id) {
    for (int i = Math.max(0, from); i < Math.min(to, styles.length); i++) styles[i] = id;
  }

  /** الأنواع البدائية — تُلوَّن كأنواع (زرقاء) لا ككلمات مفتاحية، مطابقة للتطبيق المصدر. */
  private static final HashSet<String> PRIMITIVE_TYPES = new HashSet<>();

  static {
    String[] primitives = {
      "void", "boolean", "byte", "char", "short", "int", "long", "float", "double"
    };
    for (String word : primitives) PRIMITIVE_TYPES.add(word);
  }

  /** ثابت ALL_CAPS (حرفان فأكثر، كبائر/أرقام/شرطات سفلية فقط وفيه حرف واحد على الأقل). */
  private static boolean isAllCapsConstant(String word) {
    if (word.length() < 2) return false;
    boolean hasLetter = false;
    for (int i = 0; i < word.length(); i++) {
      char c = word.charAt(i);
      if (c >= 'A' && c <= 'Z') hasLetter = true;
      else if (!(c >= '0' && c <= '9') && c != '_' && c != '$') return false;
    }
    return hasLetter;
  }

  /**
   * كلماتُ اللغةِ (جافا/كوتلن/غرووفي/جافاسكريبت) — وهي وحدُها المعرَّفةُ في ملفاتِ البناءِ.
   * طلبُ المستخدمِ على 1.0.158: أسماءُ الكتلِ والنداءِ في `build.gradle` (`defaultConfig` و
   * `dependencies` و`implementation` و…) تكونُ **سادةً** كلونِ `onCreate`؛ وقد كانَ `namespace`
   * يحمَرُّ لأنَّهُ كلمةٌ محجوزةٌ في C++ لا في Gradle — فالخلطُ بينَ لسانَيْنِ في مجموعةٍ واحدةٍ.
   */
  private static final String[] LANGUAGE_WORDS = {
    "abstract", "assert", "boolean", "break", "byte", "case", "catch", "char", "class",
    "const", "continue", "default", "do", "double", "else", "enum", "extends", "final",
    "finally", "float", "for", "goto", "if", "implements", "import", "instanceof", "int",
    "interface", "long", "native", "new", "package", "private", "protected", "public",
    "return", "short", "static", "strictfp", "super", "switch", "synchronized", "this",
    "throw", "throws", "transient", "try", "void", "volatile", "while", "true", "false",
    "null", "record", "sealed", "permits", "var", "yield"
  };

  /** كلماتُ C/C++ (لا لغةَ جافا): تُعرَّفُ حيثُ تُقرأُ شيفرةٌ صميميّةٌ، وتُستثنى من ملفاتِ البناءِ. */
  private static final String[] NATIVE_WORDS = {
    "int32_t", "int64_t", "struct", "typedef", "union", "unsigned", "register", "sizeof",
    "override", "virtual", "template", "namespace", "using", "inline", "explicit"
  };

  private static final HashSet<String> JAVA_KEYWORDS = new HashSet<>();
  private static final HashSet<String> BUILD_KEYWORDS = new HashSet<>();

  static {
    for (String word : LANGUAGE_WORDS) JAVA_KEYWORDS.add(word);
    for (String word : NATIVE_WORDS) JAVA_KEYWORDS.add(word);
    for (String word : LANGUAGE_WORDS) BUILD_KEYWORDS.add(word);
  }

  private boolean isKeyword(String word) {
    // ملفاتُ البناءِ: كلماتُ اللغةِ فقطْ — فلا «namespace» و«struct» و«using» تُلوَّنُ كلمةً حيثُ
    // هي أسماءُ أوامرَ. بقيةُ الملفاتِ (جافا/كوتلن/C/smali) على لوحتِها كما كانتْ، حرفيًّا.
    if (mode == MODE_JAVA)
      return (gradleFile ? BUILD_KEYWORDS : JAVA_KEYWORDS).contains(word);
    if (mode == MODE_SMALI)
      return "move".equals(word) || "invoke-virtual".equals(word) || "invoke-static".equals(word)
          || "invoke-direct".equals(word) || "return-void".equals(word);
    return false;
  }
}
