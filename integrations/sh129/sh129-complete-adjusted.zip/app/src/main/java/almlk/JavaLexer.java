package almlk;

import java.util.Arrays;
import java.util.HashMap;

/**
 * Linear Java tokenizer of the analysis engine (E1).
 *
 * <p>Tokens are kept in parallel int arrays (kind, start, end) instead of one object per token, so a
 * 3000-line file costs a few arrays. Operators, keywords and identifiers carry an interned text so
 * the parser compares them with {@code ==}. Comments are dropped; a literal that is not closed
 * becomes an {@link #ERROR} token up to the end of its line, which keeps the stream usable.
 *
 * <p>{@code >} is always emitted alone (except {@code >=}) so nested type arguments such as {@code
 * Map<String, List<Integer>>} close naturally; the parser joins adjacent {@code >} tokens back into
 * shift operators.
 */
public final class JavaLexer {

  public static final int EOF = 0;
  public static final int IDENT = 1;
  public static final int KEYWORD = 2;
  public static final int INT = 3;
  public static final int LONG = 4;
  public static final int FLOAT = 5;
  public static final int DOUBLE = 6;
  public static final int CHAR = 7;
  public static final int STRING = 8;
  public static final int TEXT_BLOCK = 9;
  public static final int OP = 10;
  public static final int ERROR = 11;

  private static final String[] KEYWORDS = {
    "abstract", "assert", "boolean", "break", "byte", "case", "catch", "char", "class", "const",
    "continue", "default", "do", "double", "else", "enum", "extends", "final", "finally", "float",
    "for", "goto", "if", "implements", "import", "instanceof", "int", "interface", "long", "native",
    "new", "package", "private", "protected", "public", "return", "short", "static", "strictfp",
    "super", "switch", "synchronized", "this", "throw", "throws", "transient", "try", "void",
    "volatile", "while", "true", "false", "null"
  };

  /** Operators, longest first within a shared first character (greedy match). */
  private static final String[] OPERATORS = {
    ">>>=", "<<=", "...", "->", "::", "++", "--", "&&", "||", "==", "!=", "<=", ">=", "+=", "-=",
    "*=", "/=", "%=", "&=", "|=", "^=", "<<", "(", ")", "{", "}", "[", "]", ";", ",", ".", "@", "=",
    ">", "<", "!", "~", "?", ":", "+", "-", "*", "/", "&", "|", "^", "%"
  };

  private static final HashMap<String, String> INTERNED = new HashMap<>();

  static {
    for (String k : KEYWORDS) INTERNED.put(k, k.intern());
    for (String o : OPERATORS) INTERNED.put(o, o.intern());
  }

  public final String src;
  public int count;
  public int[] kind;
  public int[] start;
  public int[] end;
  /** Interned text of IDENT, KEYWORD and OP tokens; null for literals (see {@link #text}). */
  public String[] text;

  private JavaLexer(String src) {
    this.src = src;
    int capacity = Math.max(16, src.length() / 4);
    kind = new int[capacity];
    start = new int[capacity];
    end = new int[capacity];
    text = new String[capacity];
  }

  public static JavaLexer tokenize(String source) {
    JavaLexer lexer = new JavaLexer(source == null ? "" : source);
    lexer.run();
    return lexer;
  }

  public static boolean isKeyword(String word) {
    String k = INTERNED.get(word);
    return k != null && Character.isLetter(k.charAt(0));
  }

  /** Source text of token {@code i}. */
  public String text(int i) {
    String t = text[i];
    return t != null ? t : src.substring(start[i], end[i]);
  }

  private void add(int k, int s, int e, String t) {
    if (count == kind.length) {
      int n = count * 2;
      kind = Arrays.copyOf(kind, n);
      start = Arrays.copyOf(start, n);
      end = Arrays.copyOf(end, n);
      text = Arrays.copyOf(text, n);
    }
    kind[count] = k;
    start[count] = s;
    end[count] = e;
    text[count] = t;
    count++;
  }

  private void run() {
    final String s = src;
    final int n = s.length();
    int i = 0;
    while (i < n) {
      char c = s.charAt(i);
      if (c == ' ' || c == '\t' || c == '\n' || c == '\r' || c == '\f') {
        i++;
        continue;
      }
      if (c == '/' && i + 1 < n) {
        char d = s.charAt(i + 1);
        if (d == '/') {
          i += 2;
          while (i < n && s.charAt(i) != '\n') i++;
          continue;
        }
        if (d == '*') {
          int close = s.indexOf("*/", i + 2);
          i = close < 0 ? n : close + 2;
          continue;
        }
      }
      int from = i;
      if (Character.isJavaIdentifierStart(c)) {
        i++;
        while (i < n && Character.isJavaIdentifierPart(s.charAt(i))) i++;
        String word = s.substring(from, i);
        String k = INTERNED.get(word);
        if (k != null && Character.isLetter(k.charAt(0))) add(KEYWORD, from, i, k);
        else add(IDENT, from, i, word.intern());
        continue;
      }
      if (c >= '0' && c <= '9' || c == '.' && i + 1 < n && Character.isDigit(s.charAt(i + 1))) {
        i = number(from);
        continue;
      }
      if (c == '"') {
        if (s.startsWith("\"\"\"", i)) {
          int close = i + 3;
          int stop = -1;
          while (close < n) {
            char x = s.charAt(close);
            if (x == '\\') {
              close += 2;
              continue;
            }
            if (x == '"' && s.startsWith("\"\"\"", close)) {
              stop = close + 3;
              break;
            }
            close++;
          }
          if (stop < 0) {
            add(ERROR, from, n, null);
            i = n;
          } else {
            add(TEXT_BLOCK, from, stop, null);
            i = stop;
          }
          continue;
        }
        i = quoted(from, '"', STRING);
        continue;
      }
      if (c == '\'') {
        i = quoted(from, '\'', CHAR);
        continue;
      }
      String op = null;
      for (String candidate : OPERATORS) {
        if (candidate.charAt(0) == c && s.startsWith(candidate, i)) {
          op = candidate;
          break;
        }
      }
      if (op == null) {
        add(ERROR, from, from + 1, null);
        i++;
        continue;
      }
      // ">>>=" is matched first only to keep the table greedy; '>' stays alone otherwise.
      if (op.charAt(0) == '>' && !op.equals(">=")) op = ">";
      add(OP, from, from + op.length(), INTERNED.get(op));
      i += op.length();
    }
    add(EOF, n, n, "");
  }

  private int quoted(int from, char quote, int tokenKind) {
    final String s = src;
    final int n = s.length();
    int i = from + 1;
    while (i < n) {
      char x = s.charAt(i);
      if (x == '\\') {
        i += 2;
        continue;
      }
      if (x == '\n' || x == '\r') break;
      if (x == quote) {
        add(tokenKind, from, i + 1, null);
        return i + 1;
      }
      i++;
    }
    int stop = Math.min(i, n);
    add(ERROR, from, Math.max(from + 1, stop), null);
    return Math.max(from + 1, stop);
  }

  private int number(int from) {
    final String s = src;
    final int n = s.length();
    int i = from;
    boolean floating = false;
    if (s.charAt(i) == '0' && i + 1 < n && (s.charAt(i + 1) == 'x' || s.charAt(i + 1) == 'X')) {
      i += 2;
      while (i < n && (isHex(s.charAt(i)) || s.charAt(i) == '_')) i++;
      if (i < n && s.charAt(i) == '.') {
        floating = true;
        i++;
        while (i < n && (isHex(s.charAt(i)) || s.charAt(i) == '_')) i++;
      }
      if (i < n && (s.charAt(i) == 'p' || s.charAt(i) == 'P')) {
        floating = true;
        i = exponent(i + 1);
      }
    } else if (s.charAt(i) == '0' && i + 1 < n && (s.charAt(i + 1) == 'b' || s.charAt(i + 1) == 'B')) {
      i += 2;
      while (i < n && (s.charAt(i) == '0' || s.charAt(i) == '1' || s.charAt(i) == '_')) i++;
    } else {
      while (i < n && (Character.isDigit(s.charAt(i)) || s.charAt(i) == '_')) i++;
      if (i < n && s.charAt(i) == '.' && (i + 1 >= n || s.charAt(i + 1) != '.')
          && !(i + 1 < n && Character.isJavaIdentifierStart(s.charAt(i + 1))
              && s.charAt(i + 1) != 'e' && s.charAt(i + 1) != 'E'
              && s.charAt(i + 1) != 'f' && s.charAt(i + 1) != 'F'
              && s.charAt(i + 1) != 'd' && s.charAt(i + 1) != 'D')) {
        floating = true;
        i++;
        while (i < n && (Character.isDigit(s.charAt(i)) || s.charAt(i) == '_')) i++;
      }
      if (i < n && (s.charAt(i) == 'e' || s.charAt(i) == 'E')) {
        floating = true;
        i = exponent(i + 1);
      }
    }
    int k = floating ? DOUBLE : INT;
    if (i < n) {
      char suffix = s.charAt(i);
      if (suffix == 'l' || suffix == 'L') {
        k = LONG;
        i++;
      } else if (suffix == 'f' || suffix == 'F') {
        k = FLOAT;
        i++;
      } else if (suffix == 'd' || suffix == 'D') {
        k = DOUBLE;
        i++;
      }
    }
    // Glued garbage such as 12abc stays part of the literal (reported later as invalid).
    while (i < n && Character.isJavaIdentifierPart(s.charAt(i))) i++;
    add(k, from, i, null);
    return i;
  }

  private int exponent(int i) {
    final String s = src;
    final int n = s.length();
    if (i < n && (s.charAt(i) == '+' || s.charAt(i) == '-')) i++;
    while (i < n && (Character.isDigit(s.charAt(i)) || s.charAt(i) == '_')) i++;
    return i;
  }

  private static boolean isHex(char c) {
    return c >= '0' && c <= '9' || c >= 'a' && c <= 'f' || c >= 'A' && c <= 'F';
  }
}
