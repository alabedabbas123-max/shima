package almlk;

import java.util.ArrayList;
import java.util.List;

/**
 * Line-indexed store of diagnostic ranges for one open document.
 *
 * <p>The analyzer replaces the whole set after every pass; between passes the editor reports each
 * text replacement through {@link #applyEdit} so the ranges travel with the text the user is typing
 * (lines inserted above an error push its underline down, characters typed before it on the same
 * line push it right). A range touched by the edit itself is dropped instead of guessed, except a
 * single-line insertion strictly inside it, which simply widens it.
 *
 * <p><b>W20′3 — قناةٌ مسطَّحةٌ لا كائناتٍ ولا خرائطَ لكلِّ جولةٍ.</b> الحالةُ كلُّها أربعةُ مصفوفاتٍ
 * متوازيةٍ (سطرٌ، بدءٌ، نهايةٌ، أعلامٌ) مرتَّبةٌ بالسطرِ مع حمولةِ كلِّ مدىً في مصفوفةٍ سادسةٍ، تُملَأُ
 * جولةُ التحليلِ في بافرٍ خلفيٍّ ثمَّ تُنسَخُ منشورةً — فلا {@code ArrayList<Span>} لكلِّ جولةٍ، ولا
 * {@code HashSet<String>} وأرقامٌ مُلحَمةٌ نصوصًا لإبطالِ التكرارِ (التكرارُ يُحذَفُ بعدَ ترتيبٍ مستقرٍّ
 * بمقارنةِ الرباعيّاتِ رقميًّا)، ولا خرائطَ سطورٍ تُهدَمُ وتُعادُ لكلِّ سطرٍ. {@link #applyEdit} تزحزحُ
 * الإزاحاتِ في مكانِها (الترتيبُ محفوظٌ رياضيًّا: الإزاحةُ رتيبةٌ فلا إعادةَ ترتيبٍ)، والحذفُ انضغاطٌ
 * في مكانِهِ. والرسمُ يجدُ مدياتِهِ من بيفورِ جدولِ التذكّرِ الصغيرِ (٦٤ خانةً) بعيونٍ مطابقةٍ مطابقةً
 * رقميّةً تامّةً: سطرٌ لم تتغيّرْ مدياتُهُ لا يُعادُ بناءُ مصفوفتِهِ أبدًا، والنتيجةُ صفرتُ كائناتٍ في
 * الإطارِ الساكنِ. والنموُّ بسقفِ {@code (n*5)/4} كما يفعلُ المرجعُ بصفوفِ
 * {@code FileHighlightings} عندَهُ: المصفوفاتُ تُعادُ استعمالُها حتى يكبرَ العددُ، فلا تخصيصَ في كلِّ
 * ضغطةِ مفتاحٍ.
 *
 * <p>All coordinates are zero-based; ranges never span lines. Methods are synchronized because the
 * analyzer result and the edit notifications may arrive from different call sites, while reads are
 * cheap binary searches over the published arrays.
 */
public final class DiagnosticSpanIndex {

  /** One diagnostic range on a single line plus the opaque analyzer object it came from. */
  public static final class Span {
    /** أسرةُ التَسطيرِ: لا ثالثَ لَها ولا رابعَ — خطأٌ، إنذارُ كودٍ، تلميحُ محرِّرٍ. */
    public static final int FAMILY_ERROR = 0;
    public static final int FAMILY_WARNING = 1;
    public static final int FAMILY_HINT = 2;

    public final int line;
    public final int startColumn;
    public final int endColumn;
    public final boolean warning;
    /** الأسرةُ رقمًا؛ و‏`warning` بقِيَتْ لأنَّ كلَّ مُستَعمِلٍ سابقٍ يسألُ عن الإنذارِ وحدَهُ. */
    public final int family;
    public final Object payload;

    public Span(int line, int startColumn, int endColumn, boolean warning, Object payload) {
      this(line, startColumn, endColumn, warning ? FAMILY_WARNING : FAMILY_ERROR, payload);
    }

    /** تلميحُ المحرِّرِ: زينةٌ تحتَ الرمزِ بلونٍ أصفرَ، لا صفَّ في اللوحةِ ولا عدَّ خطأٍ. */
    public static Span hint(int line, int startColumn, int endColumn, Object payload) {
      return new Span(line, startColumn, endColumn, FAMILY_HINT, payload);
    }

    private Span(int line, int startColumn, int endColumn, int family, Object payload) {
      this.line = Math.max(0, line);
      this.startColumn = Math.max(0, startColumn);
      this.endColumn = Math.max(this.startColumn + 1, endColumn);
      this.family = family;
      this.warning = family == FAMILY_WARNING;
      this.payload = payload;
    }

    Span moved(int newLine, int newStart, int newEnd) {
      return new Span(newLine, newStart, newEnd, family, payload);
    }
  }

  private static final DiagnosticUnderline[] NONE = new DiagnosticUnderline[0];
  private static final int MIN_CAPACITY = 16;
  private static final int FLAG_WARNING = 1;
  /** تلميحُ المحرِّرِ (شرطٌ دائمٌ ‏21): يُميَّزُ في الأعلامِ فلا يَسقُطُ إلى أسرةِ الإنذارِ. */
  private static final int FLAG_HINT = 2;
  private static final int MEMO_SLOTS = 64;

  // الحالةُ المنشورةُ: مصفوفاتٌ متوازيةٌ مرتَّبةٌ (line, start, end, warning) ترتيبًا معجميًّا مستقرًّا.
  private int[] lines = new int[MIN_CAPACITY];
  private int[] starts = new int[MIN_CAPACITY];
  private int[] ends = new int[MIN_CAPACITY];
  private int[] flags = new int[MIN_CAPACITY];
  private Object[] payloads = new Object[MIN_CAPACITY];
  private int size;

  // البافرُ الخلفيُّ الذي تُجمَّعُ فيهِ جولةُ التحليلِ قبلَ النشرِ، ومُبدَّلا الترتيبِ المستقرِّ.
  private int[] backLines = new int[0];
  private int[] backStarts = new int[0];
  private int[] backEnds = new int[0];
  private int[] backFlags = new int[0];
  private Object[] backPayloads = new Object[0];
  private int[] perm = new int[0];
  private int[] permTmp = new int[0];

  // تذكّرُ سطورٍ مرئيّةٍ: مصفوفةُ التحديدِ لكلِّ سطرٍ تُعادُ فقطْ حينْ لا تُطابقْ مدياتُهُ المطابقةَ التامّةَ.
  private final int[] memoLine = new int[MEMO_SLOTS];
  private final DiagnosticUnderline[][] memoValue = new DiagnosticUnderline[MEMO_SLOTS][];
  private final boolean[] memoUsed = new boolean[MEMO_SLOTS];

  // لا يُبطَلُ التذكّرُ عندَ النشرِ ولا عندَ الزحزحةِ: المطابقةُ الرقميّةُ التامّةُ أعلاه هي الإبطالُ
  // نفسَهُ، فسطرٌ لم تتغيّرْ مدياتُهُ يُعادُ إليهِ مصفوفتُهُ القديمةُ عينَها أبدَ الدهرِ، وسطرٌ تغيّرَتْ
  // مدياتُهُ أو تزحزحتْ عنهُ يُعادُ بناؤُها لهُ وحدَهُ عندَ أولِ رسمٍ — لا مسحَ جدولٍ كلَّ جولةٍ.


  /** Replaces every range with a fresh analyzer result; identical ranges are kept once. */
  public synchronized void replaceAll(List<Span> values) {
    int count = values == null ? 0 : values.size();
    if (count == 0) {
      clear();
      return;
    }
    ensureBackCapacity(count);
    int filled = 0;
    for (Span span : values) {
      if (span == null) continue;
      backLines[filled] = span.line;
      backStarts[filled] = span.startColumn;
      backEnds[filled] = span.endColumn;
      backFlags[filled] =
          span.family == Span.FAMILY_WARNING
              ? FLAG_WARNING
              : span.family == Span.FAMILY_HINT ? FLAG_HINT : 0;
      backPayloads[filled] = span.payload;
      filled++;
    }
    if (filled == 0) {
      clear();
      return;
    }
    sortPerm(filled);
    ensureFrontCapacity(filled);
    int written = 0;
    int previous = -1;
    for (int i = 0; i < filled; i++) {
      int at = perm[i];
      if (previous >= 0
          && backLines[previous] == backLines[at]
          && backStarts[previous] == backStarts[at]
          && backEnds[previous] == backEnds[at]
          && backFlags[previous] == backFlags[at]) {
        continue; // مدىً مكرَّرٌ حرفيًّا: يُحفَظُ أولُهما (الترتيبُ مستقرٌّ) كما كانَ في المسارِ القديمِ
      }
      lines[written] = backLines[at];
      starts[written] = backStarts[at];
      ends[written] = backEnds[at];
      flags[written] = backFlags[at];
      payloads[written] = backPayloads[at];
      written++;
      previous = at;
    }
    size = written;
  }

  public synchronized void clear() {
    size = 0;
    for (int i = 0; i < payloads.length; i++) payloads[i] = null;
  }

  public synchronized int size() {
    return size;
  }

  public synchronized boolean isEmpty() {
    return size == 0;
  }

  /**
   * Cached underline ranges for {@code line}; never null. The array of an unchanged line is handed
   * back as the very same object — مطابقةٌ رقميّةٌ تامّةٌ للمدياتِ، لا بصمةٌ قد تخدعُ — فلا تخصيصَ في
   * كلِّ إطارِ رسمٍ ولا إعادةَ بناءِ صفوفَ حينَ لا شيءَ تغيّرَ.
   */
  public synchronized DiagnosticUnderline[] underlines(int line) {
    int from = lowerBound(line);
    int to = upperBound(line, from);
    int count = to - from;
    if (count == 0) return NONE;
    int slot = -1;
    for (int attempt = 0; attempt < 2; attempt++) {
      int candidate = memoSlot(line, attempt);
      if (memoUsed[candidate] && memoLine[candidate] == line) {
        DiagnosticUnderline[] cached = memoValue[candidate];
        if (cached != null && matches(cached, from, to)) return cached;
        slot = candidate; // السطرُ نفسُهُ ومدياتُهُ تغيّرتْ: البناءُ يعودُ إلى خانَتِهِ
        break;
      }
      if (slot < 0) slot = candidate;
    }
    DiagnosticUnderline[] built = new DiagnosticUnderline[count];
    // التلميحاتُ ثمَّ الإنذاراتُ ثمَّ الأخطاءُ: الأعلى رتبةً يُرسَمُ آخرًا فيبقى فوقَهُ إنِ اعتلَيا
    // المدى نفسَهُ (المرجعُ كذلكَ: لا خطأَ يَخبو تحتهُ تلميحٌ).
    int at = 0;
    for (int i = from; i < to; i++)
      if (flags[i] == FLAG_HINT) built[at++] = new DiagnosticUnderline(starts[i], ends[i], false, true);
    for (int i = from; i < to; i++)
      if (flags[i] == FLAG_WARNING) built[at++] = new DiagnosticUnderline(starts[i], ends[i], true);
    for (int i = from; i < to; i++)
      if (flags[i] == 0) built[at++] = new DiagnosticUnderline(starts[i], ends[i], false);
    memoUsed[slot] = true;
    memoLine[slot] = line;
    memoValue[slot] = built;
    return built;
  }

  /**
   * The range under a caret at ({@code line}, {@code column}); the end column counts as inside so a
   * caret placed right after the word still finds it. Errors win over warnings and, among the same
   * kind, the narrowest range wins.
   */
  public synchronized Span spanAt(int line, int column) {
    int from = lowerBound(line);
    int to = upperBound(line, from);
    Span best = null;
    for (int i = from; i < to; i++) {
      if (column < starts[i] || column > ends[i]) continue;
      if (best == null || better(i, best)) best = newSpan(i);
    }
    return best;
  }

  /** First range overlapping columns [{@code from}, {@code to}) on {@code line}, errors first. */
  public synchronized Span spanOverlapping(int line, int from, int to) {
    int begin = lowerBound(line);
    int end = upperBound(line, begin);
    int want = Math.max(from + 1, to);
    Span best = null;
    for (int i = begin; i < end; i++) {
      if (ends[i] <= from || starts[i] >= want) continue;
      if (best == null || better(i, best)) best = newSpan(i);
    }
    return best;
  }

  /** Snapshot of all ranges in their current (edit-adjusted) positions. */
  public synchronized List<Span> snapshot() {
    ArrayList<Span> out = new ArrayList<>(size);
    for (int i = 0; i < size; i++) out.add(newSpan(i));
    return out;
  }

  /**
   * Moves the ranges after one replacement. The removed text covered old positions ({@code
   * startLine}, {@code startColumn}) .. ({@code removedEndLine}, {@code removedEndColumn}); the
   * inserted text now covers ({@code startLine}, {@code startColumn}) .. ({@code insertedEndLine},
   * {@code insertedEndColumn}).
   *
   * <p>الأرقامُ تُزاحُ في مكانِها وتُضغطُ المحذوفاتُ في مكانِها: الترتيبُ المعجميُّ محفوظٌ لأنَّ كلَّ
   * زحزحةٍ رتيبةٌ، فلا إعادةَ ترتيبٍ ولا كائنَ مدىً لمن لم يتغيّرْ شكلُهُ — وهذا فرقُ المسارِ القديمِ
   * الذي كانَ يبني {@code ArrayList}ةً و{@code Span}ًا جديدَيْنِ لكلِّ ضغطةِ مفتاحٍ.
   */
  public synchronized void applyEdit(
      int startLine,
      int startColumn,
      int removedEndLine,
      int removedEndColumn,
      int insertedEndLine,
      int insertedEndColumn) {
    if (size == 0) return;
    boolean pureInsertion = startLine == removedEndLine && startColumn == removedEndColumn;
    boolean singleLineInsertion = pureInsertion && insertedEndLine == startLine;
    int lineDelta = insertedEndLine - removedEndLine;
    int written = 0;
    boolean changed = false;
    for (int i = 0; i < size; i++) {
      int line = lines[i], start = starts[i], end = ends[i];
      boolean keep = true;
      if (line < startLine || (line == startLine && end <= startColumn)) {
        // entirely before the edit — unchanged
      } else if (line > removedEndLine
          || (line == removedEndLine && start >= removedEndColumn)) {
        changed = true;
        if (line == removedEndLine) {
          int shift = insertedEndColumn - removedEndColumn;
          line = insertedEndLine;
          start += shift;
          end += shift;
        } else if (lineDelta != 0) {
          line += lineDelta;
        }
      } else if (singleLineInsertion
          && line == startLine
          && startColumn > start
          && startColumn < end) {
        changed = true;
        end += insertedEndColumn - startColumn; // الكتابةُ داخلَ الكلمةِ توسّعُ المدى ولا تُسقِطُهُ
      } else {
        changed = true;
        keep = false; // التعديلُ لمسَ المدى نفسَهُ: التحليلُ القادمُ يقرّرُ، ولا تخمينَ بينَ الجولتَيْنِ
      }
      if (keep) {
        lines[written] = line;
        starts[written] = start;
        ends[written] = Math.max(start + 1, end);
        flags[written] = flags[i];
        if (written != i) payloads[written] = payloads[i];
        written++;
      } else {
        payloads[i] = null;
      }
    }
    if (!changed) return;
    for (int i = written; i < size; i++) payloads[i] = null;
    size = written;
  }

  // ---------------- الأدواتُ الداخليّةُ ----------------

  private Span newSpan(int at) {
    return new Span(lines[at], starts[at], ends[at], familyOf(flags[at]), payloads[at]);
  }

  /** رقمُ الأسرةِ من العلمِ: خطأٌ ‏0، إنذارٌ ‏1، تلميحٌ ‏2؛ والأولويَّةُ للسؤالِ للأصغرِ رقمًا. */
  private static int familyOf(int flag) {
    if (flag == FLAG_WARNING) return Span.FAMILY_WARNING;
    if (flag == FLAG_HINT) return Span.FAMILY_HINT;
    return Span.FAMILY_ERROR;
  }

  private boolean better(int candidateIndex, Span currentBest) {
    int candidateFamily = familyOf(flags[candidateIndex]);
    if (candidateFamily != currentBest.family) return candidateFamily < currentBest.family;
    return (ends[candidateIndex] - starts[candidateIndex])
        < (currentBest.endColumn - currentBest.startColumn);
  }

  /** أوّلُ فهرسٍ لسطرٍ ≥ {@code line} على مصفوفةٍ مرتَّبةٍ بالمسطرةِ الثنائيّةِ. */
  private int lowerBound(int line) {
    int lo = 0, hi = size;
    while (lo < hi) {
      int mid = (lo + hi) >>> 1;
      if (lines[mid] < line) lo = mid + 1;
      else hi = mid;
    }
    return lo;
  }

  private int upperBound(int line, int from) {
    int lo = from, hi = size;
    while (lo < hi) {
      int mid = (lo + hi) >>> 1;
      if (lines[mid] <= line) lo = mid + 1;
      else hi = mid;
    }
    return lo;
  }

  /** مطابقةٌ تامّةٌ بينَ مصفوفةٍ مخزّنةٍ ومدياتِ السطرِ (تعدّدًا وأرقامًا) — لا بصمةً تُخالِجُها. */
  private boolean matches(DiagnosticUnderline[] cached, int from, int to) {
    int count = to - from;
    if (cached.length != count) return false;
    for (int i = 0; i < count; i++) {
      DiagnosticUnderline underline = cached[i];
      boolean found = false;
      for (int j = from; j < to; j++) {
        if (underline.startColumn == starts[j]
            && underline.endColumn == ends[j]
            && familyOf(flags[j])
                == (underline.hint
                    ? Span.FAMILY_HINT
                    : underline.warning ? Span.FAMILY_WARNING : Span.FAMILY_ERROR)) {
          found = true;
          break;
        }
      }
      if (!found) return false;
    }
    return true;
  }

  /** خانَتانِ لكلِّ سطرٍ (نصفُ الجدولِ إزاحةً): سطرانِ متجاورانِ في الجدولِ لا يطرُدُ واحدُهُما الآخرَ. */
  private int memoSlot(int line, int attempt) {
    int h = line * 0x9E3779B1;
    h ^= h >>> 13;
    return attempt == 0 ? h & (MEMO_SLOTS - 1) : (h + (MEMO_SLOTS >> 1)) & (MEMO_SLOTS - 1);
  }

  /** نموٌّ بسقفِ {@code (n*5)/4} كما المرجعُ بصفوفِهِ: مساحةٌ للأمامِ فلا إعادةَ تخصيصٍ كلَّ جولةٍ. */
  private static int grown(int needed) {
    int capacity = Math.max(MIN_CAPACITY, needed + (needed >> 2));
    return capacity;
  }

  private void ensureBackCapacity(int needed) {
    if (backLines.length >= needed) return;
    int capacity = grown(needed);
    backLines = new int[capacity];
    backStarts = new int[capacity];
    backEnds = new int[capacity];
    backFlags = new int[capacity];
    backPayloads = new Object[capacity];
    perm = new int[capacity];
    permTmp = new int[capacity];
  }

  private void ensureFrontCapacity(int needed) {
    if (lines.length >= needed) return;
    int capacity = grown(needed);
    lines = new int[capacity];
    starts = new int[capacity];
    ends = new int[capacity];
    flags = new int[capacity];
    payloads = new Object[capacity];
  }

  /**
   * ترتيبٌ دمجيٌّ سفليٌّ مستقرٌّ على بدلِ الفهارسِ (مقارنةٌ معجميّةٌ على سطرٍ/بدءٍ/نهايةٍ/علامةٍ)، فيصيرُ
   * التكرارُ مجاورًا ويُحذَفُ أولُ الظاهرينِ — بلا مفاتيحَ نصّيّةٍ ولا {@code HashSet} ولا {@code Span}
   * إضافيٍّ، وبضمانِ {@code O(n log n)} لملفٍّ فيه آلافُ التشخيصاتِ.
   */
  private void sortPerm(int count) {
    for (int i = 0; i < count; i++) perm[i] = i;
    for (int width = 1; width < count; width <<= 1) {
      int step = width << 1;
      for (int left = 0; left < count; left += step) {
        int mid = Math.min(count, left + width);
        int right = Math.min(count, left + step);
        merge(left, mid, right);
      }
      System.arraycopy(permTmp, 0, perm, 0, count);
    }
  }

  /** دمجُ [left,mid) مع [mid,right) في البدلِ؛ والجريُ الأخيرُ بلا قرينٍ يُنسَخُ كما هو. */
  private void merge(int left, int mid, int right) {
    int i = left, j = mid, k = left;
    while (i < mid && j < right) {
      // «أصغرُ أو يساوي» من اليسارِ أولًا هو ما يبقي الترتيبَ مستقرًّا: المتساويانِ يحفظانِ أسبقيَّتَهُما.
      permTmp[k++] = compare(perm[i], perm[j]) <= 0 ? perm[i++] : perm[j++];
    }
    while (i < mid) permTmp[k++] = perm[i++];
    while (j < right) permTmp[k++] = perm[j++];
  }

  private int compare(int a, int b) {
    if (backLines[a] != backLines[b]) return backLines[a] < backLines[b] ? -1 : 1;
    if (backStarts[a] != backStarts[b]) return backStarts[a] < backStarts[b] ? -1 : 1;
    if (backEnds[a] != backEnds[b]) return backEnds[a] < backEnds[b] ? -1 : 1;
    if (backFlags[a] != backFlags[b]) return backFlags[a] < backFlags[b] ? -1 : 1;
    return 0;
  }
}
