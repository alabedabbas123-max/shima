package almlk;

/**
 * موضعُ الصنفِ من المسارِ (‏1.0.197): قاعدةٌ واحدةٌ لا نُسختانِ.
 *
 * <p>كانت «حزمةُ المجلدِ» مكتوبةً في المتصفِّر وحدَه (‏{@code BrowserPager.packageForDir}‏). ولمّا
 * صارَ صفُّ «‏{@code Create class 'X'}» في لوحةِ الأخطاءِ يكتبُ ملفًّا هو أيضًا، لَزِمَ أن يسألَ
 * السؤالَ نفسَه — فَنُنزِلُ القاعِدةَ هنا ويَسأَلُها الاثنانِ، وإلّا كانَ «الموضعُ الصحيحُ» عندَ
 * المتصفِّرِ غيرَهُ عندَ الإصلاحِ، وَهُوَ أَسرعُ طريقٍ إلى صِنفٍ يُكتَبُ في غَيرِ باقَتِهِ.
 */
public final class SourceLayout {

  private SourceLayout() {}

  /**
   * الحزمةُ التي يَدُلُّ عَلَيها مُجَلَّدٌ: ما تَحتَ {@code /java/} في البِنيَةِ Gradleِيَّةِ
   * ({@code …/src/main/java/com/y} ← {@code com.y}). وما لا مَوضِعَ لَهُ مِنها — كِبِنيَةِ Eclipseِ
   * {@code src/com/y} أو مُجَلَّدٍ خارِجَ المَشرُوعِ — فَلا باقَةَ لَهُ عِندَنَا: {@code ""}، لا تَخمينَ
   * بالسُّطُورِ العَددِ وَلا بِأَسْمَاءِ المَجَلَّداتِ.
   */
  public static String packageOfDirectory(String dirPath) {
    if (dirPath == null || dirPath.isEmpty()) return "";
    String flat = dirPath.replace('\\', '/');
    int javaAt = flat.lastIndexOf("/java/");
    if (javaAt < 0) return "";
    return flat.substring(javaAt + 6).replace('/', '.');
  }

  /** مُجَلَّدُ المِلَفِّ (كُلُّ ما قَبلَ آخِرِ شَرطَةٍ)؛ {@code ""} إذا لَم يَكُنْ لَهُ أَبٌ. */
  public static String directoryOf(String path) {
    if (path == null || path.isEmpty()) return "";
    String flat = path.replace('\\', '/');
    int slash = flat.lastIndexOf('/');
    return slash <= 0 ? "" : flat.substring(0, slash);
  }

  /**
   * هل هذا مَسارٌ يَسَعُ الكِتابَةَ فيهِ مُجَلَّدًا؟ مُطلَقٌ وبلا مَخطَّطٍ: {@code content://} لَيسَ
   * مُجَلَّدًا، وَمَسارٌ بِلا بادِئَةِ شَرطَةٍ لَيسَ مَسَارًا — وَالصَّفُّ الَّذي لا يَدرِي أينَ يَكتُبُ
   * لا يُعرَضُ، فَصَفٌّ بِلا أَثَرٍ مَضمُونٍ شَرٌّ مِن غَيرِهِ (عَهدُ ج٤٣).
   */
  public static boolean isWritableDirectoryPath(String path) {
    if (path == null) return false;
    String flat = path.trim().replace('\\', '/');
    return flat.startsWith("/") && !flat.contains("://");
  }
}
