package almlk;

/**
 * إيقاعُ الفحصِ المَقيسُ (طلبُ ١.٠.١٨٧/١٨٨): الأرضيةُ التي ينتظرُها الملفُّ الكبيرُ قبلَ أن تُطلَبَ
 * جَولةٌ دلاليّةٌ كانت جدولًا ساكنًا على الطولِ وحدَهُ — 900ms تزادُ 22ms لكلِّ ألفِ محرفٍ إلى
 * 3000ms — لأنَّها كُتِبتْ حينَ كانَ التحليلُ يَجرِي في خيطِ التطبيقِ. اليومَ التحليلُ في
 * **عمليّةٍ مستقلّةٍ** مع حارسَيْنِ بنيويَّيْنِ (طلبٌ جارٍ واحدٌ، ولقطاتُ الكتابةِ المتواصلةِ تُدمَجُ)،
 * فصارَ الجدولُ الساكنُ يُضيفُ تأخُّرًا محسوسًا لا يَحمي من شيءٍ: ملفٌّ بألفِ سطرٍ يَنتظِرُ 2968ms
 * قبلَ أن يبدأَ عملٌ ثمنُهُ على المِضيفِ 39ms، بينما جَهازٌ ضعيفٌ قد يَستغرِقُ الجَولةُ فيهِ
 * 2334ms فيَستحِقُّ انتظارًا أطولَ — والفرقُ بينَ هذهِ الحالاتِ لا يَقرؤُهُ جدولٌ على الطولِ،
 * بل يَقرؤُهُ **زمنُ الجَولاتِ نفسِها**.
 *
 * <p>فلهذا الصنفِ سُلوكٌ واحدٌ: يَقيسُ مدةَ كلِّ جَولةٍ مُنتَهيةٍ على نصٍّ بطولٍ معلومٍ، ويَحفظُ
 * مُتوسِّطًا أُسِّيًا للسعرِ (mili ثانيةً لكلِّ ألفِ محرفٍ)، ثمَّ يُرجِعُ أرضيةً نصفَ ثمنِ الجَولةِ
 * المَتوقَّعةِ للنصِّ الجاري — سقفُها {@link #CAP_MS} وحدُّها الأدنى {@link #MIN_USEFUL_MS}، وبلا
 * عيّناتٍ كافيةٍ يَرجِعُ إلى {@link DiagnosticBudget#delayFloorMs(int)} ريثما يَجِيءَ قياسٌ. فلا انتظارَ على
 * جِهازٍ سريعٍ، ولا تراكُمَ على جِهازٍ بطيءٍ، ولا رقمُ سياسةٍ يُملى على حِسابِ المُستخدِمِ.
 *
 * <p>نقاءُ الصنفِ مقصودٌ: لا Androidَ فيهِ (لا {@code SystemClock}) لأنَّ القياسَ يَجري عندَ المُستدعيِ
 * ويُسجَّلُ هنا بالمِلي ثانيةٍ، فيُختبَرُ في {@code qa.sh} بلا مُحاكيَ وبأرقامٍ قاطعةٍ.
 */
public final class AnalysisPace {

  /** تحتَ هذا لا أرضيةَ: تأجيلُ الكتابةِ (‏{@code LiveDiagnostics.TYPING_DELAY_MS}) يَكفي. */
  public static final long MIN_USEFUL_MS = 40;

  /** لا انتظارَ بلا نهايةٍ: نفسُ سقفِ الجدولِ الساكنِ، ولو جاءَ القياسُ أعظمَ منهُ. */
  public static final long CAP_MS = 3000;

  /** نصفُ ثمنِ الجَولةِ المَتوقَّعةِ: مساحةُ هدوءٍ للكتابةِ، لا مِثلُ زمنِ العملِ. */
  public static final double COST_FACTOR = 0.5;

  /** عيّنةٌ واحدةٌ قد تكونُ أوَّلَ ترجمةٍ (JIT) فلا تُصدَّقُ قبلَ ثانِيَةٍ. */
  public static final int SAMPLES_FOR_TRUST = 2;

  private long ratePerKiloChars; // mِli ثانيةٌ لكلِّ ألفِ محرفٍ (صفرٌ = لا قياسَ بعدُ)
  private int samples;

  /** جَولةٌ انتهت: «durationMs» على نصٍّ بطولِ «chars» — القِياسُ الوحيدُ الذي يُغيِّرُ الإيقاعَ. */
  public void observe(long durationMs, int chars) {
    if (chars <= 0 || durationMs < 0) return;
    long instant = durationMs * 1000L / chars;
    ratePerKiloChars = samples == 0 ? instant : (ratePerKiloChars + instant * 3) / 4;
    samples++;
  }

  /** كم مرّةً سُجِّلَ قياسٌ؟ (تُثبِتُها البوَّابةُ: لا أرضيةَ قبلَ عيّنَتَيْنِ) */
  public int samples() {
    return samples;
  }

  /** السعرُ المُتوسِّطُ بالمِلي ثانيةِ لكلِّ ألفِ محرفٍ — القراءةُ الوحيدةُ التي تُثبِتُ الاتِّجاهَ. */
  public long ratePerKiloChars() {
    return ratePerKiloChars;
  }

  /**
   * أرضيةُ الانتظارِ لنصٍّ بطولِ {@code chars}: صفرٌ تحتَ حدِّ الميزانيةِ الرخوةِ، والجدولُ الساكنُ
   * ما دُمنا باردين، وإلّا نصفُ المَتوقَّعِ بينَ {@link #MIN_USEFUL_MS} و{@link #CAP_MS}.
   */
  public long floorFor(int chars) {
    if (chars <= DiagnosticBudget.SOFT_LIMIT_CHARS) return 0;
    if (samples < SAMPLES_FOR_TRUST) return DiagnosticBudget.delayFloorMs(chars);
    long predicted = ratePerKiloChars * Math.max(1, chars / 1000);
    long floor = (long) (predicted * COST_FACTOR);
    if (floor < MIN_USEFUL_MS) return 0;
    return Math.min(floor, CAP_MS);
  }

  /** إعادةُ ضبطٍ صريحةٌ عندَ تبدُّلِ سياقِ المشروعِ (مكاتبُ جديدةٌ = سعرٌ لا يُعرَفُ بعدُ). */
  public void reset() {
    ratePerKiloChars = 0;
    samples = 0;
  }
}
