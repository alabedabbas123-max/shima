package almlk;

/**
 * سياسةُ تحديثِ لوحِ الأخطاءِ (ملحقُ ‏W27/2).
 *
 * <p>المرجعُ ‏({@code com.aide.ui.browsers.ErrorBrowser}) لا يُعيدُ بناءَ قائمَتِهِ في كلِّ نبضةِ
 * فحصٍ: {@code m26Hw()} يَخرُجُ أوَّلًا إن كانَ العددُ قد بلغَ مِئةً أو لم يتغيَّرْ عن آخرِ بناءٍ،
 * و{@code m25FH()} يحفَظُ تركيزَ القائمةِ قبلَ إعادةِ البناءِ ويُعيدُهُ بعدها. وسببُ الحارسِ الأولِ
 * أنَّهُ في المشاريعِ الكبيرةِ تُرسَلُ الموجاتُ متتابعةً، فإعادةُ بناءِ صفوفٍ بألْفِ سطرٍ لكلِّ
 * تغيُّرٍ حرفٍ واحدٍ يَستهلِكُ اللوحةَ كلَّها.
 *
 * <p>الطبقةُ هنا تُسمِّي القرارَ ولا تَكتُبُ أرقامًا: {@code rebuild}/{@code skip} بسبب مُعلَنٍ،
 * وعدَدُ ما يُعرَضُ، وما يَسقُطُ بالسقفِ — ليُبلَّغَ في سطرِ الحالةِ لا في حوارٍ. ولا {@code
 * android.*} ولا مِسكَ عرضٍ: العرضُ قرارُ الغلافِ.
 */
public final class ErrorBrowserPolicy {

  /** سقْفُ المرجعِ حرفيًّا: عندَهُ وفيما فوقَهُ لا إعادةَ بناءَ للّوحِ. */
  public static final int MAX_LISTED_ERRORS = 100;

  /**
   * ‏W27/2: ما جاوزَ هذا العرضَ من مدىِ التشخيصِ ليسَ رمزًا بل عبارةٌ أو كتلةٌ؛ عندَهُ يضيَّقُ
   * التحديدُ في المحرِّرِ إلى المُعرِّفِ عندَ بدايةِ التشخيصِ (طلبُ الملحقِ: «مع تحديدِ الرمزِ
   * المُخطِئِ») بدلَ تظليلِ سطرٍ كلُّهُ.
   */
  public static final int MAX_TOKEN_SPAN = 64;

  /** أساسُ ‏FNV‑1a وبَسيطُهُ: بصمةُ الصُّوفةِ تُحسَبُ بالاسمِ لا بالنصِّ الكاملِ، وبلا بَذْرٍ صِفرٍ. */
  public static final long FNV_OFFSET = 1469598103934665603L;
  public static final long FNV_PRIME = 1099511628211L;

  /** صِفرُ البصمةِ المُتَّفَقُ عليهِ: عدٌّ بلا بصمةٍ (الطريقُ القديمُ في ‏1.0.177) لا يسقُطُ معَهُ القرارُ. */
  public static final long SIGNATURE_UNKNOWN = -1L;

  public static final String REBUILD = "rebuild";
  public static final String SKIP = "skip";

  /** أسبابٌ مُسمّاةٌ تُقرَأُ في اللوحةِ وتُثبِتُها البوّابةُ. */
  public static final String REASON_CHANGED = "count_changed";
  public static final String REASON_FIRST_BUILD = "first_build";
  public static final String REASON_UNCHANGED = "unchanged";
  public static final String REASON_CAPPED = "over_display_limit";
  public static final String REASON_NO_COUNT = "no_count";
  /** ‏W27/2: عددٌ لم يتغيَّرْ لكنَّ المحتوى تغيَّرَ (خطأٌ انتقلَ سطرًا، أو تحذيرٌ حلَّ محلَّ خطأٍ). */
  public static final String REASON_CONTENT_CHANGED = "content_changed";

  /** مفاتيحُ سلاسلِ الرأسِ الثلاثةِ كما في المرجعِ (عدٌّ بلا صِيغَةٍ واحدةٍ لكلِّ الحالاتِ). */
  public static final String HEADER_NONE = "view_no_errors";
  public static final String HEADER_ONE = "view_one_error";
  public static final String HEADER_MANY = "view_errors";

  /** قرارٌ واحدٌ: ماذا يَفعَلُ اللوحُ بهذهِ النبضةِ، وبأيِّ سببٍ. */
  public static final class Decision {

    public final String action;
    public final String reason;
    /** كم صفًّا يُعرَضُ بعدَ هذا القرارِ (بما فيهِ المَقطوعُ بالسقفِ). */
    public final int listed;
    /** كم خطأً لم يَدخُلِ اللوحةَ لسقفٍ؛ لا يُطوى في صمتٍ. */
    public final int dropped;
    /** هل يُعادُ التركيزُ إلى القائمةِ بعدَ البناءِ؟ (المرجعُ يَفعلُها عندَ فقدَانِهِ أثناءَ التحديثِ) */
    public final boolean restoreFocus;

    Decision(String action, String reason, int listed, int dropped, boolean restoreFocus) {
      this.action = action;
      this.reason = reason;
      this.listed = listed;
      this.dropped = dropped;
      this.restoreFocus = restoreFocus;
    }

    public boolean rebuilds() {
      return REBUILD.equals(action);
    }

    @Override
    public String toString() {
      return action + " (" + reason + ", listed=" + listed + ", dropped=" + dropped + ")";
    }
  }

  private ErrorBrowserPolicy() {}

  /**
   * @param previousCount كم كانَ معروضًا في آخرِ بناءٍ (‏-1 إن لم يُبنَ اللوحُ بعدَ)
   * @param currentCount عددُ الصفوفِ في النبضةِ الحاليةِ (الخطأُ والتحذيرُ بعدَ ‏W27/2)
   * @param hadFocus هل كانتِ القائمةُ مُركَّزةً قبلَ التحديثِ؟
   */
  public static Decision decide(int previousCount, int currentCount, boolean hadFocus) {
    return decide(previousCount, currentCount, hadFocus, SIGNATURE_UNKNOWN, SIGNATURE_UNKNOWN);
  }

  /**
   * القرارُ كاملًا بعدَ ‏W27/2: {@code previousSignature}/{@code currentSignature} بصمتا صُوفةِ
   * ما يَدخُلُ اللوحَ. العددُ المُساويُ لم يَعُدْ سببَ صمتٍ ما دامتِ البصمةُ تغيَّرَتِ — وإلّا بقيَ
   * اللوحُ على قائمةٍ قديمةٍ بعدَ أن يَنتقِلَ الخطأُ سطرًا أو يَحِلَّ تحذيرٌ محلَّهُ، وهذا نَقصُ
   * «فورًا» في طلبِ الملحقِ. وحينَ لا تُعطى بصمةٌ ({@link #SIGNATURE_UNKNOWN}) يَرجِعُ القرارُ إلى
   * قاعدةِ العددِ كما أُقرِّرَ في ‏1.0.177، فلا يَنقَلِبُ سلوكُ مَن لا يَحمِلُ بصمةً.
   */
  public static Decision decide(
      int previousCount,
      int currentCount,
      boolean hadFocus,
      long previousSignature,
      long currentSignature) {
    if (currentCount < 0) {
      return new Decision(SKIP, REASON_NO_COUNT, 0, 0, false);
    }
    boolean built = previousCount >= 0;
    boolean counts = built && currentCount == previousCount;
    boolean signed =
        previousSignature != SIGNATURE_UNKNOWN && currentSignature != SIGNATURE_UNKNOWN;
    boolean contentChanged = signed && previousSignature != currentSignature;
    if (counts && !contentChanged) {
      return new Decision(SKIP, REASON_UNCHANGED, currentCount, dropped(currentCount), false);
    }
    // السقفُ يَحجُبُ إعادةَ البناءِ ما لم تُغَيِّرِ البصمةُ نافذةَ العرضِ نفسِها: صَمتٌ بسببٍ لا بِهَوى.
    if (built && !contentChanged && currentCount >= MAX_LISTED_ERRORS) {
      return new Decision(SKIP, REASON_CAPPED, listed(currentCount), dropped(currentCount), false);
    }
    return new Decision(
        REBUILD,
        built ? (contentChanged ? REASON_CONTENT_CHANGED : REASON_CHANGED) : REASON_FIRST_BUILD,
        listed(currentCount),
        dropped(currentCount),
        hadFocus);
  }

  // ─────────────────── ما يَدخُلُ اللوحَ، وبأيِّ بصمةٍ (‏W27/2) ───────────────────

  /**
   * اللوحُ بعدَ ملحقِ ‏W27/2 يَعرِضُ الخطأَ والتحذيرَ معًا: نصُّ الطلبِ «تُعرَضُ الأخطاءُ والتحذيراتُ
   * مُقسَّمةً تحتَ أسماءِ ملفّاتِها». وما دونَ التحذيرِ (معلوماتٌ) يَبقى في فقاعةِ المحرِّرِ لا في اللوحِ.
   */
  public static boolean listsInPanel(int severity) {
    return severity >= AnalyzerProtocol.SEVERITY_WARNING;
  }

  /** Unused items remain yellow in the editor but do not enter the critical-error panel. */
  public static boolean listsInPanel(int severity, String code, String messageKey) {
    return !JavaDiagnosticCodes.isUnused(code, messageKey) && listsInPanel(severity);
  }

  /** عدُّ الأخطاءِ (الشارةُ وسطرُ الرأسِ الأولُ): الخطأُ وحدَهُ — تحذيرٌ واحدٌ لا يَجعَلُ الشارةَ حمراءَ. */
  public static boolean countsAsError(int severity) {
    return severity == AnalyzerProtocol.SEVERITY_ERROR;
  }

  /** هل يَضيَّقُ التحديدُ إلى الرمزِ؟ المدى الأوسعُ من رمزٍ يَترُكُ المؤشَرَ على المُعرِّفِ عندَ البدايةِ. */
  public static boolean narrowsToToken(int column, int endColumn) {
    return endColumn - column > MAX_TOKEN_SPAN;
  }

  /** بدايةُ طَيِّ الصُّوفةِ — لا بصمةَ قبلَ أيِّ صفٍّ، فيَستحيلُ الخلطُ بينَ «لا صفوفَ» و«صِفرٌ». */
  public static long foldBegin() {
    return FNV_OFFSET;
  }

  /** طَيُّ قيمةٍ واحدةٍ (‏FNV‑1a): كلُّ مَن قَرَأَ الصُّوفةَ نفسَها جَمَعَ البصمةَ نفسَها، بلا ساعةٍ ولا عشوائيةٍ. */
  public static long fold(long accumulator, long value) {
    return (accumulator ^ value) * FNV_PRIME;
  }

  /** بصمةُ صفٍّ واحدٍ: ملفٌّ + سطرٌ + عمودٌ + رتبةٌ + مفتاحُ رسالةٍ. لا نصَّ كاملًا ولا قراءةَ قرصٍ. */
  public static long rowSignature(int fileHash, int line, int column, int severity, int messageHash) {
    long acc = foldBegin();
    acc = fold(acc, fileHash);
    acc = fold(acc, line);
    acc = fold(acc, column);
    acc = fold(acc, severity);
    return fold(acc, messageHash);
  }

  /**
   * عَدُّ الصُّوفةِ إلى قِسِمَينِ: ما يَحسُبُهُ الرأسُ خطأً وما يَذكُرُهُ تحذيرًا. في الغلافِ لا في
   * اللوحةِ: التفرِقةُ بينَ «صِفرِ أخطاءَ معَ تحذيراتٍ» و«لوحٌ فارغٌ» قرارٌ لا مِنصّةٌ، فَيُختَبَرُ هنا.
   *
   * @return {@code {errors, warnings}} — وما دونَ التحذيرِ لا يَدخُلُ الصُّوفةَ أصلًا فلا يُعَدُّ.
   */
  public static int[] countBySeverity(int[] severities) {
    int errors = 0;
    int warnings = 0;
    if (severities != null) {
      for (int severity : severities) {
        if (countsAsError(severity)) errors++;
        else if (listsInPanel(severity)) warnings++;
      }
    }
    return new int[] {errors, warnings};
  }

  /** قِطعةُ الرأسِ للتحذيراتِ: فارغةٌ إن لم تكنْ، وإلا مفتاحُ سلسلتِها — فلا «لا أخطاءَ» وَحدَها تَمحوها. */
  public static String warningsSegmentKey(int warnings) {
    return warnings > 0 ? "ui_errors_warnings_count" : "";
  }

  /** كم صفًّا يُعرَضُ من ‏{@code total}؟ (الباقي يُعَدُّ مَقطوعًا لا مَطويًا) */
  public static int listed(int total) {
    if (total <= 0) return 0;
    return Math.min(total, MAX_LISTED_ERRORS);
  }

  /** كم لم يُعرَضْ لسقفِ اللوحةِ؟ */
  public static int dropped(int total) {
    return total <= MAX_LISTED_ERRORS ? 0 : total - MAX_LISTED_ERRORS;
  }

  /** مفتاحُ سلسلةِ الرأسِ: لا خطأَ، أو واحدٌ، أو عددٌ — كما يَنقَسِمُ المرجعُ. */
  public static String headerKey(int total) {
    if (total <= 0) return HEADER_NONE;
    return total == 1 ? HEADER_ONE : HEADER_MANY;
  }

  /** هل تُخبَّأُ علامةُ الشريطِ العلويِّ؟ (المرجعُ: {@code iFH == 0 → GONE}) */
  public static boolean badgeHidden(int total) {
    return total <= 0;
  }
}
