package almlk;

/**
 * Coalesces editor signals onto an asynchronous main-thread poster. The latest
 * editor wins, while any text edit in the batch still requests a project pass.
 * All calls, including poster callbacks, must happen on the main thread.
 */
public final class AnalyzerSignalQueue {
  public interface Poster {
    /** Must enqueue, not run the task inline. Returns false if it cannot be posted. */
    boolean post(Runnable task);
  }

  public interface Sink {
    void onSignal(String fileName, String reference, boolean textChanged);
  }

  private final Poster poster;
  private final Sink sink;
  private String fileName;
  private String reference;
  private boolean textChanged;
  private boolean scheduled;
  private long generation;

  public AnalyzerSignalQueue(Poster poster, Sink sink) {
    if (poster == null || sink == null) throw new NullPointerException();
    this.poster = poster;
    this.sink = sink;
  }

  /** Returns false if the poster rejects the task. A later signal can retry. */
  public boolean offer(String name, String ref, boolean changed) {
    fileName = name;
    reference = ref;
    textChanged |= changed;
    if (scheduled) return true;

    scheduled = true;
    final long token = ++generation;
    final boolean posted;
    try {
      posted = poster.post(() -> deliver(token));
    } catch (RuntimeException | Error failure) {
      if (generation == token) scheduled = false;
      throw failure;
    }
    if (!posted && generation == token) scheduled = false;
    return posted;
  }

  /** Invalidates an already posted task, including if another signal arrives afterwards. */
  public void cancel() {
    generation++;
    scheduled = false;
    fileName = null;
    reference = null;
    textChanged = false;
  }

  private void deliver(long token) {
    if (!scheduled || generation != token) return;
    String name = fileName;
    String ref = reference;
    boolean changed = textChanged;
    scheduled = false;
    fileName = null;
    reference = null;
    textChanged = false;
    sink.onSignal(name, ref, changed);
  }
}
