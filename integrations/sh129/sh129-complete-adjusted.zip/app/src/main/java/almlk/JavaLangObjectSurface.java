package almlk;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

/**
 * سطحُ {@code java.lang.Object} — مُعطىً لغويٌّ ثابت، لا جدولَ رسائل.
 *
 * <p>لماذا يوجد: البلاغُ عن عضوٍ مجهولٍ في صنفٍ **مُعلَنٍ في الملف نفسه** قرينةٌ محليةٌ بالكامل، فلا
 * يجوز أن يتوقّف على جاهزيةِ فهرس المنصّة؛ لكن كلَّ صنفٍ بلا {@code extends} يرث Object ضمْنًا، فأيُّ
 * اسمٍ على سطحه يجب ألا يُبلَّغ. عندنا كانت هذه الحالة تُسكِت البلاغَ كلَّه عند غياب الفهرس (قيسَ في
 * W7: {@code setKev();} لا يُبلَّغ عنه)، لأن الاكتمالَ كان يُستمدّ من الفهرس وحده.
 *
 * <p>الاستعمالُ محصورٌ في اتجاهين: **حجبُ** البلاغ حين يشبه الاسمُ عضوًا في Object. لا يُبنى عليه نصٌّ ولا
 * رقم، ولا يُستعمل ليُثبت وجودَ عضو — فوجودُه يُثبَت من الفهرس أو من الإعلان نفسه. والأسماءُ هي سطحُ
 * Object في Java 21 كاملةً (بما فيها {@code finalize} المهجورة، تُحفَظُ لا تُستعمل).
 */
public final class JavaLangObjectSurface {

  private static final Set<String> MEMBERS;

  static {
    Set<String> names = new HashSet<>();
    Collections.addAll(names, "equals", "hashCode", "toString", "getClass", "clone", "finalize",
        "notify", "notifyAll", "wait");
    MEMBERS = Collections.unmodifiableSet(names);
  }

  private JavaLangObjectSurface() {}

  /** هل {@code name} اسمُ عضوٍ في Object (بطريقةٍ لا تجعلنا نجزم بغيابه في صنفٍ محلي)؟ */
  public static boolean mightBeInherited(String name) {
    return name != null && MEMBERS.contains(name);
  }
}
