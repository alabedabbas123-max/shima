package almlk;

import static almlk.JavaSyntaxTree.*;

import com.almlkid.kay.ui.CodeLanguageTools.Diagnostic;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

/**
 * Flow analysis of one parsed Java file (the reference's {@code wd} pass, re-implemented): statement
 * reachability (JLS 14.22), definite assignment of locals and blank final fields (JLS 16), missing
 * returns, initializers that cannot complete and switch fall-through.
 *
 * <p>Reachability is three-valued: a condition that might be a constant we cannot evaluate (a
 * final field, {@code BuildConfig.DEBUG}) yields MAYBE, and only a certain NO / YES is reported, so
 * an unevaluated constant never produces a false "cannot be reached" or "must return".
 */
public final class JavaFlowAnalyzer {
  private static final int NO = 0, MAYBE = 1, YES = 2;
  private static final int MAX_VARS = 2048;
  private static final int MAX_FINDINGS = 200;
  private static final int CONST_TRUE = 1, CONST_FALSE = 2, CONST_MAYBE = 3, CONST_NONE = 0;
  private static final BitSet ALL = new BitSet(MAX_VARS);

  static {
    ALL.set(0, MAX_VARS);
  }

  /** A visible variable: its definite-assignment bit (-1 when untracked) and constant-ness. */
  private static final class Local {
    final String name;
    final int index;
    final boolean field;
    final boolean maybeConstant;
    /** R6: the local's declaration and declared type, for the "Initialize variable" fix. */
    VarDecl decl;
    TypeRef type;

    Local(String name, int index, boolean field, boolean maybeConstant) {
      this.name = name;
      this.index = index;
      this.field = field;
      this.maybeConstant = maybeConstant;
    }
  }

  /** A break/continue/yield target with the state merged from every jump to it. */
  private static final class Target {
    final Node node;
    String label;
    final boolean loop, breakable, switchExpr;
    int breakReach = NO;
    BitSet breakDa;
    int contReach = NO;
    BitSet contDa;

    Target(Node node, String label, boolean loop, boolean breakable, boolean switchExpr) {
      this.node = node;
      this.label = label;
      this.loop = loop;
      this.breakable = breakable;
      this.switchExpr = switchExpr;
    }
  }

  private final String src;
  private final Unit unit;
  private final int[] lineStarts;
  private final List<Diagnostic> out = new ArrayList<>();
  private final HashSet<String> reported = new HashSet<>();
  private final HashSet<Local> readReported = new HashSet<>();

  private HashMap<String, ArrayList<Local>> visible = new HashMap<>();
  private ArrayList<String> declared = new ArrayList<>();
  private ArrayList<Target> targets = new ArrayList<>();
  private ArrayList<HashMap<String, FieldInfo>> classFields = new ArrayList<>();
  private BitSet da = new BitSet();
  private int nextIndex;
  private BitSet returnDa;
  private String pendingLabel;
  private boolean inInitializer;

  private static final class FieldInfo {
    final boolean maybeConstant;

    FieldInfo(boolean maybeConstant) {
      this.maybeConstant = maybeConstant;
    }
  }

  public JavaFlowAnalyzer(String src, Unit unit) {
    this.src = src == null ? "" : src;
    this.unit = unit;
    this.lineStarts = lineStarts(this.src);
  }

  public List<Diagnostic> run() {
    if (unit == null) return Collections.emptyList();
    for (TypeDecl d : unit.types) {
      try {
        analyzeClass(d);
      } catch (RuntimeException | StackOverflowError failure) {
        // isolation: one broken class body never silences the rest of the file
      }
    }
    return out;
  }

  // ───────────────────────────── reporting ─────────────────────────────

  private static int[] lineStarts(String s) {
    int count = 1;
    for (int i = 0; i < s.length(); i++) if (s.charAt(i) == '\n') count++;
    int[] starts = new int[count];
    int k = 1;
    for (int i = 0; i < s.length(); i++) if (s.charAt(i) == '\n') starts[k++] = i + 1;
    return starts;
  }

  private void report(int start, int end, Diagnostic.Severity severity, String key, String fallback, Object... args) {
    if (out.size() >= MAX_FINDINGS || start < 0 || start > src.length()) return;
    if (!reported.add(start + ":" + key)) return;
    int lo = 0, hi = lineStarts.length - 1;
    while (lo < hi) {
      int mid = (lo + hi + 1) >>> 1;
      if (lineStarts[mid] <= start) lo = mid;
      else hi = mid - 1;
    }
    out.add(Diagnostic.localized(start, Math.max(start + 1, Math.min(end, src.length())), lo + 1,
        start - lineStarts[lo] + 1, severity, JavaDiagnosticCodes.codeOf(key), key, fallback, args));
  }

  private void error(int start, int end, String key, String fallback, Object... args) {
    report(start, end, Diagnostic.Severity.ERROR, key, fallback, args);
  }

  /** {@link #report} plus a quick fix attached to the finding when it was actually added. */
  private void reportFix(QuickFix fix, int start, int end, Diagnostic.Severity severity, String key,
      String fallback, Object... args) {
    int before = out.size();
    report(start, end, severity, key, fallback, args);
    if (fix != null && out.size() > before) {
      Diagnostic d = out.get(out.size() - 1);
      out.set(out.size() - 1, d.withQuickFixes(java.util.Collections.singletonList(fix)));
    }
  }

  /** Leading blanks of the line holding {@code offset}. */
  private String lineIndent(int offset) {
    int ls = Math.max(0, Math.min(offset, src.length()));
    while (ls > 0 && src.charAt(ls - 1) != '\n') ls--;
    int e = ls;
    while (e < src.length() && (src.charAt(e) == ' ' || src.charAt(e) == '\t')) e++;
    return src.substring(ls, e);
  }

  /** wd's default value for a missing return / an initializer: false, 0 or null. */
  private static String defaultValue(TypeRef t) {
    if (t == null || t.dims > 0 || t.varargs || t.primitive == null) return "null";
    return "boolean".equals(t.primitive) ? "false" : "0";
  }

  /** Offset of a block's closing brace, or -1. */
  private int closingBrace(Block b) {
    if (b == null || b.end <= 0 || b.end > src.length()) return -1;
    return src.charAt(b.end - 1) == '}' ? b.end - 1 : -1;
  }

  // ───────────────────────────── state helpers ─────────────────────────────

  private static BitSet copy(BitSet b) {
    return (BitSet) b.clone();
  }

  private static BitSet meet(BitSet a, BitSet b) {
    if (a == null) return b == null ? copy(ALL) : copy(b);
    if (b == null) return copy(a);
    BitSet r = copy(a);
    r.and(b);
    return r;
  }

  private static int or(int a, int b) {
    return Math.max(a, b);
  }

  private int mark() {
    return declared.size();
  }

  private void release(int mark) {
    while (declared.size() > mark) {
      String name = declared.remove(declared.size() - 1);
      ArrayList<Local> stack = visible.get(name);
      if (stack != null && !stack.isEmpty()) stack.remove(stack.size() - 1);
    }
  }

  private Local declare(String name, boolean assigned, boolean maybeConstant, boolean field) {
    if (name == null || name.isEmpty()) return null;
    int index = nextIndex < MAX_VARS ? nextIndex++ : -1;
    Local l = new Local(name, index, field, maybeConstant);
    visible.computeIfAbsent(name, k -> new ArrayList<>()).add(l);
    declared.add(name);
    if (index >= 0) {
      if (assigned) da.set(index);
      else da.clear(index);
    }
    return l;
  }

  private Local lookup(String name) {
    ArrayList<Local> stack = visible.get(name);
    return stack == null || stack.isEmpty() ? null : stack.get(stack.size() - 1);
  }

  /** The tracked field of that name even when a local or parameter shadows it ({@code this.x}). */
  private Local lookupField(String name) {
    ArrayList<Local> stack = visible.get(name);
    if (stack == null) return null;
    for (int i = stack.size() - 1; i >= 0; i--) if (stack.get(i).field) return stack.get(i);
    return null;
  }

  private void assign(Local l) {
    if (l != null && l.index >= 0) da.set(l.index);
  }

  private void read(Name n) {
    Local l = lookup(n.id);
    if (l == null || l.index < 0 || da.get(l.index)) return;
    if (l.field) {
      // the field stays unassigned (its declaration may still need "may not be initialized")
      if (readReported.add(l))
        error(n.start, n.end, "ui_diagnostic_field_not_initialized", "Field '%1$s' might not have been initialized", n.id);
      return;
    }
    QuickFix fix = null;
    VarDecl v = l.decl;
    if (v != null && l.type != null && !l.type.inferred && v.extraDims == 0 && v.init == null
        && v.nameStart >= 0 && src.startsWith(v.name, v.nameStart))
      fix = QuickFix.insertText(src, v.nameStart + v.name.length(), " = " + defaultValue(l.type),
          "ui_quick_fix_initialize_variable", "");
    reportFix(fix, n.start, n.end, Diagnostic.Severity.ERROR, "ui_diagnostic_variable_not_initialized",
        "Variable '%1$s' might not have been initialized", n.id);
    da.set(l.index); // one report per path
  }

  private static boolean isLiteral(Expr e, String text, String src) {
    while (e instanceof Paren) e = ((Paren) e).inner;
    return e instanceof Literal && ((Literal) e).kind == LIT_BOOLEAN && e.end <= src.length()
        && src.substring(e.start, e.end).trim().equals(text);
  }

  /** Constant-ness of a loop condition: literal true/false, maybe-constant, or certainly not. */
  private int constant(Expr e) {
    if (e == null) return CONST_TRUE;
    if (isLiteral(e, "true", src)) return CONST_TRUE;
    if (isLiteral(e, "false", src)) return CONST_FALSE;
    return maybeConstant(e) ? CONST_MAYBE : CONST_NONE;
  }

  private boolean maybeConstant(Expr e) {
    if (e instanceof Paren) return maybeConstant(((Paren) e).inner);
    if (e instanceof Literal) return true;
    if (e instanceof Name) {
      String id = ((Name) e).id;
      Local l = lookup(id);
      if (l != null) return l.maybeConstant;
      for (int i = classFields.size() - 1; i >= 0; i--) {
        FieldInfo f = classFields.get(i).get(id);
        if (f != null) return f.maybeConstant;
      }
      return true; // inherited or statically imported: may be a constant
    }
    if (e instanceof Select) {
      Expr t = ((Select) e).target;
      if (t instanceof This || t instanceof Super || t instanceof Call || t instanceof NewObject) return false;
      if (t instanceof Name && lookup(((Name) t).id) != null) return false;
      return t instanceof Name || t instanceof Select;
    }
    if (e instanceof Unary) {
      String op = ((Unary) e).op;
      return op != "++" && op != "--" && maybeConstant(((Unary) e).operand);
    }
    if (e instanceof Binary) return maybeConstant(((Binary) e).left) && maybeConstant(((Binary) e).right);
    if (e instanceof Conditional) {
      Conditional c = (Conditional) e;
      return maybeConstant(c.cond) && maybeConstant(c.whenTrue) && maybeConstant(c.whenFalse);
    }
    if (e instanceof Cast) return maybeConstant(((Cast) e).operand);
    return false;
  }

  // ───────────────────────────── classes and members ─────────────────────────────

  private static boolean blankFinal(FieldDecl f, VarDecl v, TypeDecl owner) {
    return owner.kind != INTERFACE && owner.kind != ANNOTATION && owner.kind != RECORD
        && f.mods != null && f.mods.has(FINAL) && v.init == null;
  }

  private void analyzeClass(TypeDecl d) {
    if (d == null) return;
    // Outer locals are hidden: a member of this body may shadow them.
    HashMap<String, ArrayList<Local>> savedVisible = visible;
    ArrayList<String> savedDeclared = declared;
    ArrayList<Target> savedTargets = targets;
    BitSet savedDa = da;
    BitSet savedReturns = returnDa;
    int savedNext = nextIndex;
    String savedLabel = pendingLabel;
    boolean savedInit = inInitializer;
    inInitializer = false;
    visible = new HashMap<>();
    declared = new ArrayList<>();
    targets = new ArrayList<>();
    pendingLabel = null;
    HashMap<String, FieldInfo> fields = new HashMap<>();
    for (Member m : d.members) {
      if (!(m instanceof FieldDecl)) continue;
      FieldDecl f = (FieldDecl) m;
      boolean fin = d.kind == INTERFACE || f.mods != null && f.mods.has(FINAL);
      for (VarDecl v : f.vars) fields.put(v.name, new FieldInfo(fin && v.init != null && maybeConstant(v.init)));
    }
    classFields.add(fields);
    try {
      for (EnumConstant ec : d.constants) {
        if (ec.args != null) for (Expr a : ec.args) analyzeDetached(a);
        if (ec.body != null) analyzeClass(ec.body);
      }
      initializationSequence(d, true);
      initializationSequence(d, false);
      for (Member m : d.members) {
        if (m instanceof MethodDecl && !((MethodDecl) m).constructor) analyzeMethod((MethodDecl) m, null);
        else if (m instanceof TypeDecl) analyzeClass((TypeDecl) m);
      }
    } finally {
      classFields.remove(classFields.size() - 1);
      visible = savedVisible;
      declared = savedDeclared;
      targets = savedTargets;
      da = savedDa;
      returnDa = savedReturns;
      nextIndex = savedNext;
      pendingLabel = savedLabel;
      inInitializer = savedInit;
    }
  }

  /** An expression outside any body (enum constant arguments): only nested bodies matter. */
  private void analyzeDetached(Expr e) {
    BitSet saved = da;
    da = copy(ALL);
    int m = mark();
    try {
      expr(e);
    } finally {
      release(m);
      da = saved;
    }
  }

  /**
   * Field initializers and initializer blocks of one kind (static or instance) in order, then, for
   * instance members, every constructor; blank final fields must be assigned at the end.
   */
  private void initializationSequence(TypeDecl d, boolean statics) {
    int m = mark();
    da = new BitSet();
    nextIndex = 0;
    ArrayList<Local> blanks = new ArrayList<>();
    ArrayList<VarDecl> blankDecls = new ArrayList<>();
    for (Member member : d.members) {
      if (!(member instanceof FieldDecl)) continue;
      FieldDecl f = (FieldDecl) member;
      boolean isStatic = f.mods != null && f.mods.has(STATIC) || d.kind == INTERFACE;
      if (isStatic != statics) continue;
      for (VarDecl v : f.vars) {
        if (!blankFinal(f, v, d)) continue;
        Local l = declare(v.name, false, false, true);
        if (l != null && l.index >= 0) {
          blanks.add(l);
          blankDecls.add(v);
        }
      }
    }
    try {
      for (Member member : d.members) {
        if (member instanceof FieldDecl) {
          FieldDecl f = (FieldDecl) member;
          boolean isStatic = f.mods != null && f.mods.has(STATIC) || d.kind == INTERFACE;
          if (isStatic != statics) continue;
          for (VarDecl v : f.vars) {
            if (v.init == null) continue;
            expr(v.init);
          }
        } else if (member instanceof Initializer) {
          Initializer init = (Initializer) member;
          if (init.isStatic != statics || init.body == null) continue;
          targets = new ArrayList<>();
          inInitializer = true;
          int r;
          try {
            r = statement(init.body, YES);
          } finally {
            inInitializer = false;
          }
          if (r == NO) {
            int brace = closingBrace(init.body);
            if (brace >= 0)
              error(brace, brace + 1, "ui_diagnostic_initializer_must_complete",
                  "An initializer must be able to complete normally");
            da = copy(ALL);
          }
        }
      }
      if (statics) {
        reportUnassigned(blanks, blankDecls, da);
        return;
      }
      BitSet afterInit = copy(da);
      boolean anyCtor = false;
      BitSet missing = new BitSet();
      for (Member member : d.members) {
        if (!(member instanceof MethodDecl) || !((MethodDecl) member).constructor) continue;
        MethodDecl ctor = (MethodDecl) member;
        anyCtor = true;
        BitSet end = analyzeMethod(ctor, afterInit);
        if (end == null) continue; // this(...) delegation or no body
        for (Local l : blanks) if (!end.get(l.index)) missing.set(l.index);
      }
      if (!anyCtor) {
        reportUnassigned(blanks, blankDecls, afterInit);
      } else {
        BitSet ok = copy(ALL);
        ok.andNot(missing);
        reportUnassigned(blanks, blankDecls, ok);
      }
    } finally {
      release(m);
    }
  }

  private void reportUnassigned(List<Local> blanks, List<VarDecl> decls, BitSet state) {
    for (int i = 0; i < blanks.size(); i++) {
      Local l = blanks.get(i);
      if (state.get(l.index)) continue;
      VarDecl v = decls.get(i);
      if (v.nameStart >= 0 && src.startsWith(v.name, v.nameStart))
        error(v.nameStart, v.nameStart + v.name.length(), "ui_diagnostic_field_may_not_be_initialized",
            "This field may not be initialized");
    }
  }

  /** wd's "Insert return statement": a default return just before the closing brace. */
  private QuickFix returnFix(MethodDecl md, int brace) {
    String value = "return " + defaultValue(md.result) + ";";
    int ls = brace;
    while (ls > 0 && (src.charAt(ls - 1) == ' ' || src.charAt(ls - 1) == '\t')) ls--;
    if (ls > 0 && src.charAt(ls - 1) == '\n') {
      List<Stmt> body = md.body.stmts;
      String indent = body.isEmpty() ? lineIndent(brace) + "    " : lineIndent(body.get(body.size() - 1).start);
      return QuickFix.insertText(src, ls, indent + value + "\n", "ui_quick_fix_insert_return", "");
    }
    return QuickFix.insertText(src, brace, value + " ", "ui_quick_fix_insert_return", "");
  }

  private static boolean startsWithThisCall(MethodDecl md) {
    if (md.body == null || md.body.stmts.isEmpty()) return false;
    Stmt first = md.body.stmts.get(0);
    if (!(first instanceof ExprStmt)) return false;
    Expr e = ((ExprStmt) first).expr;
    return e instanceof Call && ((Call) e).target == null && "this".equals(((Call) e).name);
  }

  /**
   * One method or constructor body. For a constructor {@code fieldState} carries the blank finals
   * assigned by the initializers; the state at its normal end and at every return is returned.
   */
  private BitSet analyzeMethod(MethodDecl md, BitSet fieldState) {
    if (md.body == null || md.bodySkipped) return null;
    boolean ctor = md.constructor;
    if (ctor && startsWithThisCall(md)) {
      // delegation: the other constructor assigns the fields; the body is still checked
      fieldState = copy(ALL);
    }
    ArrayList<Target> savedTargets = targets;
    BitSet savedDa = da;
    BitSet savedReturns = returnDa;
    int savedNext = nextIndex;
    int m = mark();
    targets = new ArrayList<>();
    returnDa = null;
    boolean savedInit = inInitializer;
    inInitializer = false;
    if (fieldState != null) {
      da = copy(fieldState);
    } else {
      // ordinary methods: fields are not tracked; locals are numbered afresh
      da = copy(ALL);
      nextIndex = 0;
    }
    try {
      for (VarDecl p : md.params) declare(p.name, true, false, false);
      int r = statement(md.body, YES);
      if (!ctor && r == YES && returnsValue(md)) {
        int brace = closingBrace(md.body);
        if (brace >= 0 && md.result.end > md.result.start && md.result.end <= src.length())
          reportFix(returnFix(md, brace), brace, brace + 1, Diagnostic.Severity.ERROR,
              "ui_diagnostic_method_must_return_value",
              "This method must return a value of type '%1$s'", src.substring(md.result.start, md.result.end).trim());
      }
      if (!ctor || startsWithThisCall(md)) return ctor ? null : da;
      BitSet end = r == NO ? null : copy(da);
      return meet(end, returnDa);
    } finally {
      release(m);
      targets = savedTargets;
      da = savedDa;
      returnDa = savedReturns;
      nextIndex = savedNext;
      inInitializer = savedInit;
    }
  }

  private static boolean returnsValue(MethodDecl md) {
    if (md.result == null) return false;
    if ("void".equals(md.result.primitive) && md.result.dims == 0) return false;
    return md.mods == null || !md.mods.has(ABSTRACT) && !md.mods.has(NATIVE);
  }

  // ───────────────────────────── statements ─────────────────────────────

  /** Statements of one list: the first unreachable one is reported, the rest analysed as reachable. */
  private int statements(List<Stmt> list, int reach) {
    boolean reportedHere = false;
    for (Stmt st : list) {
      if (reach == NO) {
        if (!reportedHere && !(st instanceof Empty)) {
          reportFix(QuickFix.deleteText(src, st.start, Math.min(st.end, src.length()), "ui_quick_fix_delete"),
              st.start, st.end, Diagnostic.Severity.ERROR, "ui_diagnostic_unreachable_statement",
              "This statement cannot be reached");
          reportedHere = true;
        }
        reach = YES;
      }
      reach = statement(st, reach);
    }
    return reach;
  }

  private int statement(Stmt st, int reach) {
    if (st == null) return reach;
    int r = statementIn(st, reach);
    if (r == NO) da = copy(ALL);
    return r;
  }

  private Target findTarget(String label, boolean isContinue) {
    for (int i = targets.size() - 1; i >= 0; i--) {
      Target t = targets.get(i);
      if (label != null) {
        if (label.equals(t.label)) return t;
      } else if (isContinue ? t.loop : t.breakable) {
        return t;
      }
    }
    return null;
  }

  private Target pushTarget(Node node, boolean loop, boolean breakable, boolean switchExpr, String label) {
    Target t = new Target(node, loop ? label : null, loop, breakable, switchExpr);
    targets.add(t);
    return t;
  }

  /** The label a labeled statement handed to the loop now starting (consumed once). */
  private String takeLabel() {
    String l = pendingLabel;
    pendingLabel = null;
    return l;
  }

  private void popTarget() {
    targets.remove(targets.size() - 1);
  }

  private int loopExit(int cv, int reach) {
    if (cv == CONST_TRUE) return NO;
    if (cv == CONST_MAYBE) return Math.min(reach, MAYBE);
    return reach;
  }

  private int statementIn(Stmt st, int reach) {
    if (!(st instanceof While || st instanceof DoWhile || st instanceof For || st instanceof ForEach))
      pendingLabel = st instanceof Labeled ? pendingLabel : null;
    if (st instanceof Block) {
      int m = mark();
      try {
        return statements(((Block) st).stmts, reach);
      } finally {
        release(m);
      }
    }
    if (st instanceof LocalVars) {
      LocalVars lv = (LocalVars) st;
      boolean fin = lv.mods != null && lv.mods.has(FINAL);
      for (VarDecl v : lv.vars) {
        Local l = declare(v.name, false, fin && v.init != null && maybeConstant(v.init), false);
        if (l != null) {
          l.decl = v;
          l.type = lv.type;
        }
        if (v.init != null) {
          expr(v.init);
          assign(l);
        }
      }
      return reach;
    }
    if (st instanceof LocalClass) {
      analyzeClass(((LocalClass) st).decl);
      return reach;
    }
    if (st instanceof ExprStmt) {
      expr(((ExprStmt) st).expr);
      return reach;
    }
    if (st instanceof If) {
      If i = (If) st;
      BitSet[] c = cond(i.cond);
      da = c[0];
      int r1 = statement(i.then, reach);
      BitSet afterThen = da;
      da = c[1];
      int r2 = i.otherwise == null ? reach : statement(i.otherwise, reach);
      da = meet(afterThen, da);
      return i.otherwise == null ? reach : or(r1, r2);
    }
    if (st instanceof While) {
      While w = (While) st;
      String label = takeLabel();
      int cv = constant(w.cond);
      BitSet[] c = cond(w.cond);
      Target t = pushTarget(st, true, true, false, label);
      da = c[0];
      try {
        if (cv == CONST_FALSE && w.body != null && !(w.body instanceof Empty)) {
          error(w.body.start, w.body.end, "ui_diagnostic_unreachable_statement", "This statement cannot be reached");
          statement(w.body, YES);
        } else {
          statement(w.body, reach);
        }
      } finally {
        popTarget();
      }
      da = meet(cv == CONST_MAYBE ? copy(ALL) : c[1], t.breakDa);
      return or(loopExit(cv, reach), t.breakReach);
    }
    if (st instanceof DoWhile) {
      DoWhile dw = (DoWhile) st;
      String label = takeLabel();
      int cv = constant(dw.cond);
      Target t = pushTarget(st, true, true, false, label);
      int r;
      try {
        r = statement(dw.body, reach);
      } finally {
        popTarget();
      }
      da = meet(da, t.contDa);
      BitSet[] c = cond(dw.cond);
      int bodyEnd = or(r, t.contReach);
      da = meet(cv == CONST_MAYBE ? copy(ALL) : c[1], t.breakDa);
      return or(loopExit(cv, bodyEnd), t.breakReach);
    }
    if (st instanceof For) {
      For f = (For) st;
      String label = takeLabel();
      int m = mark();
      try {
        for (Stmt i : f.init) statement(i, reach);
        int cv = constant(f.cond);
        BitSet[] c = f.cond == null ? new BitSet[] {copy(da), copy(ALL)} : cond(f.cond);
        Target t = pushTarget(st, true, true, false, label);
        da = c[0];
        try {
          if (cv == CONST_FALSE && f.body != null && !(f.body instanceof Empty)) {
            error(f.body.start, f.body.end, "ui_diagnostic_unreachable_statement", "This statement cannot be reached");
            statement(f.body, YES);
          } else {
            statement(f.body, reach);
          }
          da = meet(da, t.contDa);
          for (Expr u : f.update) expr(u);
        } finally {
          popTarget();
        }
        da = meet(cv == CONST_MAYBE ? copy(ALL) : c[1], t.breakDa);
        return or(loopExit(cv, reach), t.breakReach);
      } finally {
        release(m);
      }
    }
    if (st instanceof ForEach) {
      ForEach fe = (ForEach) st;
      String label = takeLabel();
      expr(fe.iterable);
      int m = mark();
      try {
        BitSet before = copy(da);
        declare(fe.var == null ? null : fe.var.name, true, false, false);
        Target t = pushTarget(st, true, true, false, label);
        try {
          statement(fe.body, reach);
        } finally {
          popTarget();
        }
        da = meet(before, t.breakDa);
        return or(reach, t.breakReach);
      } finally {
        release(m);
      }
    }
    if (st instanceof Labeled) {
      Labeled lb = (Labeled) st;
      Stmt body = lb.body;
      if (body instanceof While || body instanceof DoWhile || body instanceof For || body instanceof ForEach) {
        pendingLabel = lb.label;
        return statement(body, reach);
      }
      Target t = new Target(st, lb.label, false, false, false);
      targets.add(t);
      int r;
      try {
        r = statement(body, reach);
      } finally {
        popTarget();
      }
      da = meet(r == NO ? null : da, t.breakDa);
      return or(r, t.breakReach);
    }
    if (st instanceof Switch) {
      Switch sw = (Switch) st;
      expr(sw.selector);
      return switchBody(sw, sw.cases, reach, false);
    }
    if (st instanceof Synchronized) {
      expr(((Synchronized) st).lock);
      return statement(((Synchronized) st).body, reach);
    }
    if (st instanceof Try) return tryStatement((Try) st, reach);
    if (st instanceof Return) {
      Return r = (Return) st;
      if (r.value != null) expr(r.value);
      if (inInitializer) return reach; // already "may not contain a return": no cascade
      returnDa = meet(returnDa, da);
      return NO;
    }
    if (st instanceof Throw) {
      expr(((Throw) st).value);
      return NO;
    }
    if (st instanceof Jump) {
      Jump j = (Jump) st;
      Target t = findTarget(j.label, !j.isBreak);
      if (t == null) return reach; // misplaced jump: already an attribution error, no cascade
      {
        if (j.isBreak) {
          t.breakReach = or(t.breakReach, reach);
          t.breakDa = meet(t.breakDa, da);
        } else {
          t.contReach = or(t.contReach, reach);
          t.contDa = meet(t.contDa, da);
        }
      }
      return NO;
    }
    if (st instanceof Yield) {
      Yield y = (Yield) st;
      if (y.value != null) expr(y.value);
      for (int i = targets.size() - 1; i >= 0; i--) {
        Target t = targets.get(i);
        if (t.switchExpr) {
          t.breakReach = or(t.breakReach, reach);
          t.breakDa = meet(t.breakDa, da);
          break;
        }
      }
      return NO;
    }
    if (st instanceof Assert) {
      Assert a = (Assert) st;
      BitSet before = copy(da);
      BitSet[] c = cond(a.cond);
      if (a.message != null) {
        da = c[1];
        expr(a.message);
      }
      da = before; // assignments inside an assert never count
      return reach;
    }
    return reach;
  }

  private int tryStatement(Try t, int reach) {
    int m = mark();
    try {
      for (Node r : t.resources) {
        if (r instanceof VarDecl) {
          VarDecl v = (VarDecl) r;
          Local l = declare(v.name, false, false, false);
          if (v.init != null) expr(v.init);
          assign(l);
        } else if (r instanceof Expr) {
          expr((Expr) r);
        }
      }
      BitSet before = copy(da);
      int result = statement(t.body, reach);
      BitSet merged = result == NO ? null : copy(da);
      for (Catch c : t.catches) {
        da = copy(before);
        int cm = mark();
        try {
          declare(c.name, true, false, false);
          int cr = statement(c.body, reach);
          result = or(result, cr);
          merged = meet(merged, cr == NO ? null : da);
        } finally {
          release(cm);
        }
      }
      if (merged == null) merged = copy(ALL);
      if (t.fin != null) {
        da = copy(before);
        int fr = statement(t.fin, reach);
        if (fr == NO) {
          da = copy(ALL);
          return NO;
        }
        BitSet fin = da;
        da = merged;
        da.or(fin);
        return result;
      }
      da = merged;
      return result;
    } finally {
      release(m);
    }
  }

  private static boolean hasPattern(Case c) {
    for (Expr l : c.labels) if (l instanceof Pattern) return true;
    return false;
  }

  /** A switch statement or expression body; {@code value} for a switch expression. */
  private int switchBody(Node node, List<Case> cases, int reach, boolean value) {
    BitSet afterSelector = copy(da);
    boolean hasDefault = false, patterns = false, arrow = false;
    for (Case c : cases) {
      hasDefault |= c.isDefault;
      patterns |= hasPattern(c);
      arrow |= c.arrow;
    }
    Target t = pushTarget(node, false, !value, value, null);
    int m = mark();
    int last = reach;
    BitSet merged = null;
    int arrowReach = NO;
    try {
      int previous = NO;
      boolean previousHadStatements = false;
      Case previousCase = null;
      for (Case c : cases) {
        if (arrow) {
          da = copy(afterSelector);
          int cm = mark();
          try {
            declarePatterns(c);
            if (c.guard != null) da = cond(c.guard)[0];
            int r;
            if (value && c.body.size() == 1 && c.body.get(0) instanceof ExprStmt) {
              expr(((ExprStmt) c.body.get(0)).expr);
              t.breakReach = or(t.breakReach, reach);
              t.breakDa = meet(t.breakDa, da);
              r = NO;
            } else {
              r = statements(c.body, reach);
              if (r == NO) da = copy(ALL);
            }
            arrowReach = or(arrowReach, r);
            merged = meet(merged, r == NO ? null : da);
          } finally {
            release(cm);
          }
          continue;
        }
        if (previous == YES && previousHadStatements && !value) {
          int labelEnd = c.labels.isEmpty() ? Math.min(src.length(), c.start + 7) : c.labels.get(c.labels.size() - 1).end;
          QuickFix fix = null;
          if (previousCase != null && !previousCase.body.isEmpty()) {
            Stmt tail = previousCase.body.get(previousCase.body.size() - 1);
            if (tail.end > 0 && tail.end <= src.length())
              fix = QuickFix.insertText(src, tail.end, "\n" + lineIndent(tail.start) + "break;",
                  "ui_quick_fix_insert_break", "");
          }
          reportFix(fix, c.start, labelEnd, Diagnostic.Severity.WARNING, "ui_diagnostic_possible_fall_through",
              "Possible fall through");
        }
        da = previous == NO ? copy(afterSelector) : meet(afterSelector, da);
        declarePatterns(c);
        if (c.guard != null) da = cond(c.guard)[0];
        int r = statements(c.body, reach);
        if (r == NO) da = copy(ALL);
        previous = c.body.isEmpty() ? or(previous, reach) : r;
        previousHadStatements = !c.body.isEmpty();
        previousCase = c;
        last = previous;
      }
      if (!arrow) merged = cases.isEmpty() || last == NO ? null : copy(da);
    } finally {
      release(m);
      popTarget();
    }
    if (value) {
      da = meet(merged, t.breakDa);
      return reach;
    }
    int exhaustiveGap = hasDefault ? NO : patterns ? MAYBE : reach;
    BitSet noMatch = hasDefault ? null : patterns ? copy(ALL) : afterSelector;
    da = meet(meet(merged, t.breakDa), noMatch);
    int body = arrow ? arrowReach : cases.isEmpty() ? reach : last;
    return or(or(body, t.breakReach), exhaustiveGap);
  }

  private void declarePatterns(Case c) {
    for (Expr l : c.labels) if (l instanceof Pattern) declarePattern((Pattern) l);
  }

  private void declarePattern(Pattern p) {
    if (p.binding != null) declare(p.binding, true, false, false);
    if (p.nested != null) for (Pattern n : p.nested) declarePattern(n);
  }

  // ───────────────────────────── expressions ─────────────────────────────

  /** Definite assignment when true / when false (JLS 16.1). */
  private BitSet[] cond(Expr e) {
    if (e == null) return new BitSet[] {copy(da), copy(ALL)};
    if (e instanceof Paren) return cond(((Paren) e).inner);
    if (isLiteral(e, "true", src)) return new BitSet[] {copy(da), copy(ALL)};
    if (isLiteral(e, "false", src)) return new BitSet[] {copy(ALL), copy(da)};
    if (e instanceof Unary && ((Unary) e).op == "!") {
      BitSet[] c = cond(((Unary) e).operand);
      return new BitSet[] {c[1], c[0]};
    }
    if (e instanceof Binary && (((Binary) e).op == "&&" || ((Binary) e).op == "||")) {
      Binary b = (Binary) e;
      BitSet[] l = cond(b.left);
      if (b.op == "&&") {
        da = l[0];
        BitSet[] r = cond(b.right);
        return new BitSet[] {r[0], meet(l[1], r[1])};
      }
      da = l[1];
      BitSet[] r = cond(b.right);
      return new BitSet[] {meet(l[0], r[0]), r[1]};
    }
    if (e instanceof Conditional) {
      Conditional c = (Conditional) e;
      BitSet[] k = cond(c.cond);
      da = k[0];
      BitSet[] a = cond(c.whenTrue);
      da = k[1];
      BitSet[] b = cond(c.whenFalse);
      return new BitSet[] {meet(a[0], b[0]), meet(a[1], b[1])};
    }
    if (e instanceof InstanceOf) {
      InstanceOf io = (InstanceOf) e;
      expr(io.operand);
      if (io.pattern != null) declarePattern(io.pattern);
      return new BitSet[] {copy(da), copy(da)};
    }
    expr(e);
    return new BitSet[] {copy(da), copy(da)};
  }

  private void expr(Expr e) {
    if (e == null) return;
    if (e instanceof Name) {
      read((Name) e);
    } else if (e instanceof Paren) {
      expr(((Paren) e).inner);
    } else if (e instanceof Select) {
      Select s = (Select) e;
      if (!(s.target instanceof This)) expr(s.target);
    } else if (e instanceof Call) {
      Call c = (Call) e;
      expr(c.target);
      for (Expr a : c.args) expr(a);
    } else if (e instanceof Assign) {
      Assign a = (Assign) e;
      Expr target = a.target;
      while (target instanceof Paren) target = ((Paren) target).inner;
      Local l = null;
      if (target instanceof Name) {
        l = lookup(((Name) target).id);
        if (a.op != "=") read((Name) target);
      } else if (target instanceof Select && ((Select) target).target instanceof This
          && ((This) ((Select) target).target).qualifier == null) {
        l = lookupField(((Select) target).name);
      } else if (target instanceof Index) {
        expr(((Index) target).array);
        expr(((Index) target).index);
      } else {
        expr(target);
      }
      expr(a.value);
      assign(l);
    } else if (e instanceof Binary) {
      Binary b = (Binary) e;
      if (b.op == "&&" || b.op == "||") {
        BitSet[] c = cond(e);
        da = meet(c[0], c[1]);
      } else {
        // left-nested chains are walked iteratively
        ArrayList<Binary> chain = new ArrayList<>();
        Expr x = b;
        while (x instanceof Binary && ((Binary) x).op != "&&" && ((Binary) x).op != "||" && chain.size() < 10000) {
          chain.add((Binary) x);
          x = ((Binary) x).left;
        }
        expr(x);
        for (int i = chain.size() - 1; i >= 0; i--) expr(chain.get(i).right);
      }
    } else if (e instanceof Unary) {
      expr(((Unary) e).operand);
    } else if (e instanceof Conditional) {
      Conditional c = (Conditional) e;
      BitSet[] k = cond(c.cond);
      da = k[0];
      expr(c.whenTrue);
      BitSet afterTrue = da;
      da = k[1];
      expr(c.whenFalse);
      da = meet(afterTrue, da);
    } else if (e instanceof Index) {
      expr(((Index) e).array);
      expr(((Index) e).index);
    } else if (e instanceof Cast) {
      expr(((Cast) e).operand);
    } else if (e instanceof InstanceOf) {
      InstanceOf io = (InstanceOf) e;
      expr(io.operand);
      if (io.pattern != null) declarePattern(io.pattern);
    } else if (e instanceof NewObject) {
      NewObject n = (NewObject) e;
      expr(n.outer);
      for (Expr a : n.args) expr(a);
      if (n.body != null) analyzeClass(n.body);
    } else if (e instanceof NewArray) {
      NewArray na = (NewArray) e;
      for (Expr d : na.dimExprs) expr(d);
      expr(na.init);
    } else if (e instanceof ArrayInit) {
      for (Expr x : ((ArrayInit) e).elements) expr(x);
    } else if (e instanceof Lambda) {
      lambda((Lambda) e);
    } else if (e instanceof MethodRef) {
      MethodRef mr = (MethodRef) e;
      if (mr.target != null && !(mr.target instanceof This) && !(mr.target instanceof Super)) expr(mr.target);
    } else if (e instanceof SwitchExpr) {
      SwitchExpr se = (SwitchExpr) e;
      expr(se.selector);
      switchBody(se, se.cases, YES, true);
    }
  }

  /** A lambda body sees the state at its creation; its own assignments never leave it. */
  private void lambda(Lambda l) {
    BitSet before = copy(da);
    ArrayList<Target> savedTargets = targets;
    BitSet savedReturns = returnDa;
    String savedLabel = pendingLabel;
    targets = new ArrayList<>();
    pendingLabel = null;
    boolean savedInit = inInitializer;
    inInitializer = false;
    int m = mark();
    try {
      for (VarDecl p : l.params) declare(p.name, true, false, false);
      if (l.body instanceof Block) statement((Block) l.body, YES);
      else if (l.body instanceof Expr) expr((Expr) l.body);
    } finally {
      release(m);
      targets = savedTargets;
      returnDa = savedReturns;
      pendingLabel = savedLabel;
      inInitializer = savedInit;
      da = before;
    }
  }
}
