package almlk;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * عقدُ السِّلكِ بينَ عمليةِ الواجهةِ وعمليةِ التحليلِ (المرحلةُ ١ من عزلِ المُحرِّكِ، ‏W23).
 *
 * <p>الطبقةُ صافيةٌ: لا ‏android‏ هنا، فترميزُ الردِّ وفكُّهُ يُختبَرانِ على المضيفِ في {@code
 * qa/RegressionSuite.java} — لأنَّ ترتيبَ الحقولِ هو موضعُ الخطإِ الحقيقيُّ في أيِّ جسرٍ بينَ العملياتِ.
 *
 * <p>ما أخذَتهُ الطبقةُ من دراسةِ المرجعِ (ورقةُ الدراسةِ ‏W23، البنودُ ‏2 و‏4 و‏6):
 *
 * <ul>
 *   <li><b>النصُّ يُقسَّمُ ولا يُدفَعُ جملةً واحدةً</b>: المرجعُ يقلبُ الاتجاهَ فيستعملُ المُحرِّكُ قناةَ {@code
 *       u.FH(int)→CharArray} لالتماسِ الصفحاتِ؛ الغرضُ واحدٌ — عدمُ اختراقِ سقفِ ‏{@code Binder} (~1 ميجابايت)
 *       مهما كَبُرَ الملفُّ، فلا تُرفَضُ الرسالةُ ولا يَنجَمِدُ الوجهُ.
 *   <li><b>التشخيصُ يحملُ رمزًا وقائمةَ عناوينَ إصلاحٍ</b> كما في {@code SyntaxError} (رسالةٌ + {@code String[]}
 *       + رمزٌ مُصنَّفٌ): الواجهةُ لا تُحاوِرُ المُحرِّكَ عندَ كلِّ نقرةٍ على سطرِ إصلاحٍ.
 *   <li><b>صفوفٌ أوليّةٌ مُتوازٍيةٌ بدلَ الكائناتِ</b> للمُعرِّفاتِ الحيّةِ، على مثالِ {@code
 *       FileHighlightings} — أخفُّ على النقلِ وعلى جامعِ القمامةِ.
 *   <li><b>الجيلُ (generation)</b> يُهدَرُ به كلُّ جوابٍ عفا عليهِ الزمنُ؛ يعدُّهُ المرجعُ في {@code
 *       abcd.Xj.Hw:AtomicInteger} ويُرفَقُ بكلِّ طلبٍ هنا.
 * </ul>
 *
 * <p>الترميزُ سطرٌ واحدٌ ذو أربعةِ مستوياتِ تفرّقُها محارفُ تحكُّمٍ: {@link #FIELD} ثمَّ {@link #RECORD} ثمَّ
 * {@link #PART} ثمَّ {@link #SUB}، والمسافةُ داخلَ سِجلِّ الإصلاحِ. {@link #esc(String)} يُهرِّبُ هذه المحارفَ
 * الأربعةَ والمسافةَ والشرطةَ المائلةَ العكسيّةَ والتابَ ورفَّ السطرِ ونهايتَه، فلا يظهرُ محرفٌ فاصلٌ من بياناتٍ،
 * ويبقى المُخرَجُ كلُّهُ قابلًا للطبعِ في السجلِّ سطرًا واحدًا.
 */
public final class AnalyzerProtocol {

  /** محارفُ الفصلِ بأربعةِ مستوياتِ (لا تُترَكُ واحدةٌ منها في البياناتِ بعدَ التهرّبِ). */
  public static final char FIELD = '\u0001';
  public static final char RECORD = '\u0002';
  public static final char PART = '\u0003';
  public static final char SUB = '\u0004';

  // ── الرموزُ الدالّةُ على نوعِ الرسالةِ ────────────────────────────────────
  /** قياسُ الوصلِ: يُجابُ عنهُ بحالةٍ فقط، لا بتحليلٍ. */
  public static final int CODE_PING = 1;
  /** رأسُ طلبِ تحليلٍ لملفٍّ: الجيلُ + الاسمُ + الحجمُ الكليُّ + عددُ القطعِ. */
  public static final int CODE_BEGIN = 2;
  /** قطعةُ نصٍّ من طلبٍ مُقسَّمٍ. */
  public static final int CODE_PART = 3;
  /** نهايةُ الطلبِ: عندَهُ فقط يُنفَّذُ التحليلُ، فلا تحليلَ لنصفِ ملفٍّ. */
  public static final int CODE_END = 4;
  /** النتيجةُ: تشخيصاتٌ + مُعرِّفاتٌ حيّةٌ. */
  public static final int CODE_RESULT = 5;
  /** إعلانُ حالةٍ من أيِّ الطرفَينِ. */
  public static final int CODE_STATE = 6;
  /** إلغاءُ الطلبِ الجاريِ (تبويبٌ أُغلِقَ أو المحرِّرُ انفصلَ). */
  public static final int CODE_CANCEL = 7;

  /** رتبُ التشخيصِ بأساسِ {@code CodeLanguageTools.Diagnostic.Severity} (ذاتُ الترتيبِ). */
  public static final int SEVERITY_INFO = 0;
  public static final int SEVERITY_WARNING = 1;
  public static final int SEVERITY_ERROR = 2;

  // ── الحالاتُ المسماةُ (لا أرقامَ عائمةً في السجلِّ) ───────────────────────
  public static final String STATE_OK = "ok";
  /** لا وكيلَ بعدُ: يبقى الطلبُ في الطابورِ المعلَّقِ ولا يُسقَطُ (خلافًا للمرجعِ عندَ {@code Xj}). */
  public static final String STATE_NOT_BOUND = "not_bound";
  /** جوابٌ لجيلٍ سابقٍ: رُمِيَ لأنَّ النصَّ أحدثُ أو لأنَّ العمليةَ وُلِدَت من جديدٍ. */
  public static final String STATE_STALE = "stale";
  /** الطلبُ أكبرُ من السقفِ المُعلَنِ: رُمِيَ كلُّهُ بنصِّهِ وعُدَّ، لا بصمتٍ. */
  public static final String STATE_TOO_LARGE = "too_large";
  /** الطرفُ الآخرُ رافضٌ: الخدمةُ تُغلَقُ أو طابورُها مُثقَلٌ. */
  public static final String STATE_REFUSED = "refused";
  /** ماتت عمليةُ التحليلِ: بائتٌ كلُّ ما في الطريقِ، ويُعادُ الربطُ عندَ أولِ طلبٍ جديدٍ. */
  public static final String STATE_PROCESS_DIED = "process_died";
  /** ضغطُ ذاكرةٍ في عمليةِ التحليلِ: تُترَكُ آخرُ نتيجةٍ معروفةٍ للواجهةِ. */
  public static final String STATE_MEMORY_PRESSURE = "memory_pressure";

  // ── السقوفُ المعلَنةُ ────────────────────────────────────────────────────
  /**
   * أقصى عددِ محارفَ في قطعةٍ واحدةٍ: القطعةُ تدخلُ حقلًا نصّيًّا في ‏{@code Bundle}، والتهرّبُ قد يَضَعّفُ
   * أطوالًا مُمرَّرةً، فالحدُّ يبقى دونَ سقفِ النقلِ بفارقٍ مريحٍ حتى مع أسوأِ نصٍّ.
   */
  public static final int MAX_CHUNK_CHARS = 220_000;
  public static final int MAX_FINDINGS = 400;
  public static final int MAX_FIXES = 6;

  /** دَفعَةُ التغطيةِ: سَقفُها سَقفُ الدَّفعَةِ في المُحرِّكِ، فلا تَنقُصُ دَفعَةٌ عابِرَةٌ للسِّلكِ. */
  public static final int MAX_COMPANIONS = 12;
  public static final int MAX_ARGS = 4;
  public static final int MAX_CLASSES = 32;
  public static final int MAX_METHODS = 256;
  public static final int MAX_FIELDS = 192;
  public static final int MAX_NAME = 240;
  public static final int MAX_MESSAGE = 8 * 1024;
  /** أقصى نصٍّ لطلبٍ واحدٍ (يُقسَّمُ لا يُقطَعُ): ما زادَ عنهُ يُرفَضُ بحالةٍ مسماةٍ. */
  public static final int MAX_REQUEST_CHARS = 4 * 1024 * 1024;
  /** عددُ المشكلاتِ المُعلَنةِ الباقيةُ معَ الردِّ. */
  public static final int MAX_PROBLEMS = 4;

  /**
   * كم موضعًا يُرسَلُ للعنصرِ نفسِهِ؟ المكرَّرُ يُبرَزُ حيثُ وُجِدَ لا حيثُ شُخِصَ، والمواضعُ تُطلَبُ كلُّها؛
   * ما زادَ على هذا الحدِّ يُعدُّ في {@code dropped} مع سِجلٍّ، فلا «تزيينٌ» ناقصٌ بلا علمٍ.
   */
  public static final int MAX_OCCURRENCES = 32;

  /**
   * ميزانيّةُ الردِّ كلِّهِ بالمحارفِ (≈ نصفُ ميزانيّةِ النقلِ): سقفٌ إجماليٌّ يمنعُ
   * {@code TransactionTooLargeException} الذي لا يُصلَحُ بإعادةِ المحاولةِ. التشخيصاتُ تُقبَلُ حتى يبلغَ
   * الردُّ حدَّهُ، والباقي يُعدُّ {@code dropped} مع سِجلٍّ مُعلَنٍ — لا يُرسَلُ نصفُ ردٍّ ولا يُترَكُ
   * السِّجلُّ صامتًا.
   */
  public static final int MAX_REPLY_CHARS = 256_000;

  private AnalyzerProtocol() {}

  // ─────────────────────────── السِّجلّاتُ العابرةُ ───────────────────────────

  /** إصلاحٌ واحدٌ: نوعُهُ وما يحتاجُهُ من أسماءَ وأرقامٍ — مرآةُ {@code almlk.QuickFix}. */
  public static final class Fix {
    public final String kind;
    public final String targetClass;
    public final String returnType;
    public final String methodName;
    public final String importName;
    public final String titleKey;
    public final String titleArg;
    public final String expected;
    public final String[] paramTypes;
    public final String[] paramNames;
    public final boolean isStatic;
    public final int insertOffset;
    public final int editEnd;
    /** ‏1.0.191: الدالةُ تَنفِذُ ما طَلَبَ الأصلُ — صِفةٌ عنِ الدَّفعَةِ لا عنِ النصِّ، فتَعبرُ السِّلكَ. */
    public final boolean overrides;
    /** بَقِيَّةُ دوالِّ الدَّفعَةِ: تُرسَلُ كلُّها لأنَّ الدَّفعَةَ لا تُقبَلُ بنصفِها (‏`QuickFix.companions`‏). */
    public final Fix[] companions;
    /**
     * أسطرُ الاستيرادِ التي تَطلَبُها الدَّفعَةُ مُقيَّدةً (‏`QuickFix.importsToFetch`‏). تُرسَلُ من ‏1.0.191‏
     * لأنَّها حقيقةٌ عن **الجِسمِ المَولودِ** لا عنِ الملفِّ: «ماذا يَحتاجُ هذا المولودُ» يَثبُتُ في
     * المُحرِّكِ حيثُ الصنوفُ مَعلومةٌ، وأمّا «أفي الملفِّ سطرُهُ الآنَ؟» فسؤالٌ عنِ الكتابةِ الجاريةِ
     * يُترَكُ لمَوضِعِ التطبيقِ يَقرؤُهُ على النصِّ الحيِّ — فلا سطرُ زورٍ ولا مَكرورٌ، ولا اختراعُ باقةٍ ههنا.
     */
    public final String[] imports;

    public Fix(
        String kind,
        String targetClass,
        String returnType,
        String methodName,
        String importName,
        String titleKey,
        String titleArg,
        String expected,
        String[] paramTypes,
        String[] paramNames,
        boolean isStatic,
        int insertOffset,
        int editEnd,
        boolean overrides,
        Fix[] companions) {
      this(kind, targetClass, returnType, methodName, importName, titleKey, titleArg, expected,
          paramTypes, paramNames, isStatic, insertOffset, editEnd, overrides, companions, null);
    }

    public Fix(
        String kind,
        String targetClass,
        String returnType,
        String methodName,
        String importName,
        String titleKey,
        String titleArg,
        String expected,
        String[] paramTypes,
        String[] paramNames,
        boolean isStatic,
        int insertOffset,
        int editEnd,
        boolean overrides,
        Fix[] companions,
        String[] imports) {
      this.kind = orEmpty(kind);
      this.targetClass = orEmpty(targetClass);
      this.returnType = orEmpty(returnType);
      this.methodName = orEmpty(methodName);
      this.importName = orEmpty(importName);
      this.titleKey = orEmpty(titleKey);
      this.titleArg = orEmpty(titleArg);
      this.expected = orEmpty(expected);
      this.paramTypes = paramTypes == null ? new String[0] : paramTypes;
      this.paramNames = paramNames == null ? new String[0] : paramNames;
      this.isStatic = isStatic;
      this.insertOffset = insertOffset;
      this.editEnd = editEnd;
      this.overrides = overrides;
      this.companions = companions == null ? new Fix[0] : companions;
      this.imports = imports == null ? new String[0] : imports;
    }

    /** الثلاثةَ عشرَ التي كانت قبلَ ‏1.0.191‏: بلا عَلمٍ ولا دَفعَةٍ — لا يُجبَرُ قارئٌ قَديمٌ على شَيءٍ. */
    public Fix(
        String kind,
        String targetClass,
        String returnType,
        String methodName,
        String importName,
        String titleKey,
        String titleArg,
        String expected,
        String[] paramTypes,
        String[] paramNames,
        boolean isStatic,
        int insertOffset,
        int editEnd) {
      this(kind, targetClass, returnType, methodName, importName, titleKey, titleArg, expected,
          paramTypes, paramNames, isStatic, insertOffset, editEnd, false, null, null);
    }
  }

  /** تشخيصٌ واحدٌ: مواضعُ + رمزٌ + رسالةٌ بمفتاحِها + إصلاحاتُها. */
  public static final class Finding {
    public final int offset;
    public final int end;
    public final int line;
    public final int column;
    public final int severity;
    public final String code;
    public final String message;
    public final String messageKey;
    /** {@code s} = نصٌّ و{@code i} = عددٌ: نوعُ كلِّ وسْمٍ كما وصلَ من {@code messageArgs}. */
    public final char[] argTags;
    public final String[] argValues;
    public final Fix[] fixes;
    /** كلُّ مواضعِ العنصرِ المُشارِ إليهِ (إزاحاتٌ) — للمُكرَّراتِ وحالاتِ الاستيرادِ، فارغٌ لغيرِها. */
    public final int[] occStarts;
    public final int[] occEnds;

    public Finding(
        int offset,
        int end,
        int line,
        int column,
        int severity,
        String code,
        String message,
        String messageKey,
        char[] argTags,
        String[] argValues,
        Fix[] fixes) {
      this.offset = offset;
      this.end = end;
      this.line = line;
      this.column = column;
      this.severity = severity < SEVERITY_INFO || severity > SEVERITY_ERROR ? SEVERITY_ERROR : severity;
      this.code = orEmpty(code);
      this.message = orEmpty(message);
      this.messageKey = orEmpty(messageKey);
      this.argTags = argTags == null ? new char[0] : argTags;
      this.argValues = argValues == null ? new String[0] : argValues;
      this.fixes = fixes == null ? new Fix[0] : fixes;
      this.occStarts = new int[0];
      this.occEnds = new int[0];
    }


    /** نفسُ الحِملِ زائدَ مواضعِ الاستعمالِ: لا نسخةَ ثانيةً من الحقولِ العشرةِ عندَ كلِّ مُوسِّعٍ. */
    public Finding(
        int offset,
        int end,
        int line,
        int column,
        int severity,
        String code,
        String message,
        String messageKey,
        char[] argTags,
        String[] argValues,
        Fix[] fixes,
        int[] occStarts,
        int[] occEnds) {
      this.offset = offset;
      this.end = end;
      this.line = line;
      this.column = column;
      this.severity = severity < SEVERITY_INFO || severity > SEVERITY_ERROR ? SEVERITY_ERROR : severity;
      this.code = orEmpty(code);
      this.message = orEmpty(message);
      this.messageKey = orEmpty(messageKey);
      this.argTags = argTags == null ? new char[0] : argTags;
      this.argValues = argValues == null ? new String[0] : argValues;
      this.fixes = fixes == null ? new Fix[0] : fixes;
      this.occStarts = occStarts == null ? new int[0] : occStarts;
      this.occEnds = occEnds == null ? new int[0] : occEnds;
    }

    /** هل للعنصرِ مواضعُ أخرى غيرُ موضعِ التشخيصِ نفسِهِ؟ (على هذا يُبنى التزيينُ المتعدِّدُ). */
    public boolean hasOccurrences() {
      return occStarts.length > 0 && occEnds.length > 0;
    }

    public boolean isWarning() {
      return severity == SEVERITY_WARNING;
    }

    public boolean isError() {
      return severity == SEVERITY_ERROR;
    }
  }

  /**
   * المُعرِّفاتُ الحيّةُ لملفٍّ: ما يقرؤهُ الفاحصُ ويقارنُهُ فهرسُ المشروعِ (أصنافٌ، دوالٌ، حقولٌ
   * بأنواعِها). صفوفٌ أوليّةٌ مُتوازٍيةٌ كما في {@code FileHighlightings} المرجعيّةِ.
   */
  public static final class Members {
    public final String[] classNames;
    public final String[] methodNames;
    public final String[] fieldNames;
    public final String[] fieldTypes;

    public Members(String[] classNames, String[] methodNames, String[] fieldNames, String[] fieldTypes) {
      this.classNames = classNames == null ? new String[0] : classNames;
      this.methodNames = methodNames == null ? new String[0] : methodNames;
      this.fieldNames = fieldNames == null ? new String[0] : fieldNames;
      this.fieldTypes = fieldTypes == null ? new String[0] : fieldTypes;
    }

    public boolean isEmpty() {
      return classNames.length == 0 && methodNames.length == 0 && fieldNames.length == 0;
    }

    public static Members empty() {
      return new Members(null, null, null, null);
    }
  }

  /** ما يعودُ من عمليةِ التحليلِ عن طلبٍ واحدٍ. */
  public static final class Reply {
    public final long generation;
    public final String file;
    public final Finding[] findings;
    public final Members members;
    public final String state;
    /** كم سُقِطَ من سِجلّاتٍ لبلوغِ سقفٍ مُعلَنِ (لا ضياعَ صامتًا). */
    public final int dropped;
    public final List<String> problems;

    Reply(
        long generation,
        String file,
        Finding[] findings,
        Members members,
        String state,
        int dropped,
        List<String> problems) {
      this.generation = generation;
      this.file = orEmpty(file);
      this.findings = findings == null ? new Finding[0] : findings;
      this.members = members == null ? Members.empty() : members;
      this.state = orEmpty(state).isEmpty() ? STATE_OK : state;
      this.dropped = Math.max(0, dropped);
      this.problems =
          problems == null || problems.isEmpty()
              ? Collections.<String>emptyList()
              : Collections.unmodifiableList(new ArrayList<>(problems));
    }

    public boolean isTruncated() {
      return dropped > 0;
    }

    public boolean isOk() {
      return STATE_OK.equals(state);
    }
  }

  /** رأسُ الطلبِ: ملفٌّ واحدٌ، جيلٌ واحدٌ، حجمٌ كليٌّ معلَنٌ. */
  public static final class Request {
    public final long generation;
    public final String file;
    public final int totalChars;
    public final int partCount;

    public Request(long generation, String file, int totalChars, int partCount) {
      this.generation = generation;
      this.file = orEmpty(file);
      this.totalChars = Math.max(0, totalChars);
      this.partCount = Math.max(0, partCount);
    }
  }

  /** قطعةٌ من نصِّ الطلبِ: اسمُ الملفِّ يَسيرُ معَ كلِّ قطعةٍ فلا تُفتَّشُ الجلسةُ بالحدسِ. */
  public static final class Part {
    public final long generation;
    public final int index;
    public final String file;
    public final String text;

    public Part(long generation, int index, String file, String text) {
      this.generation = generation;
      this.index = index;
      this.file = orEmpty(file);
      this.text = text == null ? "" : text;
    }
  }

  // ─────────────────────────── التقسيمُ واللمُّ ───────────────────────────

  /** عددُ القطعِ التي يحتاجُها نصٌّ بطولِ {@code chars} (صفرٌ لنصٍّ فارغٍ: لا قطعةَ بلا معنى). */
  public static int partCount(int chars) {
    if (chars <= 0) return 0;
    return (chars + MAX_CHUNK_CHARS - 1) / MAX_CHUNK_CHARS;
  }

  /** يقسمُ النصَّ قطعًا لا تتجاوزُ {@link #MAX_CHUNK_CHARS}، بترتيبٍ ثابتٍ وحجمٍ محفوظٍ. */
  public static String[] splitChunks(String text) {
    if (text == null || text.isEmpty()) return new String[0];
    String[] out = new String[partCount(text.length())];
    int at = 0;
    for (int i = 0; i < out.length; i++) {
      int next = Math.min(text.length(), at + MAX_CHUNK_CHARS);
      out[i] = text.substring(at, next);
      at = next;
    }
    return out;
  }

  /** يعيدُ لمَّ القطعِ بترتيبِها (الفراغاتُ تُتجافى، فلا يُبدَّلُ حرفٌ واحدٌ). */
  public static String joinChunks(String[] parts) {
    if (parts == null || parts.length == 0) return "";
    StringBuilder out = new StringBuilder();
    for (String part : parts) if (part != null) out.append(part);
    return out.toString();
  }

  // ─────────────────────────── مُجمِّعُ الردِّ ───────────────────────────

  /**
   * يَبني سِجلَّ الردِّ ويطبِّقُ السقوفَ: كلُّ سِجلٍّ زائدٍ يُعدُّ في {@link Reply#dropped} ولا يضيعُ
   * صامتًا، وكلُّ اسمٍ أو رسالةٍ أطولُ من سقفِها يُقطَعُ ويُعلَمُ ذلكَ في {@link Reply#problems}.
   */
  public static final class Builder {
    private final long generation;
    private final String file;
    private final ArrayList<Finding> findings = new ArrayList<>();
    private final ArrayList<String> problems = new ArrayList<>(MAX_PROBLEMS + 1);
    private Members members = Members.empty();
    private String state = STATE_OK;
    private int dropped;
    private int chars;

    public Builder(long generation, String file) {
      this.generation = generation;
      this.file = orEmpty(file);
    }

    /** ‏true‏ عندَ القَبولِ، و‏false‏ عندَ بلوغِ {@link #MAX_FINDINGS} (يُعدُّ في {@code dropped}). */
    public boolean add(Finding finding) {
      if (finding == null) return false;
      if (findings.size() >= MAX_FINDINGS) {
        dropped++;
        note("findings capped at " + MAX_FINDINGS);
        return false;
      }
      Finding kept = clamp(finding);
      int cost = estimate(kept);
      if (chars + cost > MAX_REPLY_CHARS) {
        dropped++;
        note("reply clamped at " + MAX_REPLY_CHARS + " chars");
        return false;
      }
      chars += cost;
      findings.add(kept);
      return true;
    }

    public void members(Members value) {
      members = value == null ? Members.empty() : clamp(value);
    }

    public void state(String value) {
      state = orEmpty(value).isEmpty() ? STATE_OK : value;
    }

    public Reply build() {
      return new Reply(
          generation, file, findings.toArray(new Finding[0]), members, state, dropped,
          new ArrayList<>(problems));
    }

    /** تقديرٌ رخيصٌ لحجمِ السِّجلِّ على السِّلكِ: النصُّ والوسومُ والإصلاحاتُ، بلا ترميزٍ كاملٍ لكلِّ مرّةٍ. */
    private static int estimate(Finding f) {
      int cost = f.message.length() + f.messageKey.length() + f.code.length() + 24;
      for (String value : f.argValues) cost += value.length() + 2;
      for (Fix x : f.fixes) {
        cost += x.kind.length() + x.targetClass.length() + x.returnType.length() + x.methodName.length()
            + x.importName.length() + x.titleKey.length() + x.titleArg.length() + x.expected.length() + 48;
        for (String type : x.paramTypes) cost += type.length() + 2;
        for (String name : x.paramNames) cost += name.length() + 2;
      }
      return cost;
    }

    private Finding clamp(Finding in) {
      int tags = Math.min(in.argTags.length, in.argValues.length);
      if (tags > MAX_ARGS) {
        dropped += tags - MAX_ARGS;
        note("args capped at " + MAX_ARGS);
      }
      int args = Math.min(tags, MAX_ARGS);
      char[] keptTags = new char[args];
      String[] keptValues = new String[args];
      for (int i = 0; i < args; i++) {
        keptTags[i] = in.argTags[i] == 'i' ? 'i' : 's';
        keptValues[i] = cut(in.argValues[i], MAX_NAME);
      }
      Fix[] fixes = in.fixes;
      if (fixes.length > MAX_FIXES) {
        dropped += fixes.length - MAX_FIXES;
        note("fixes capped at " + MAX_FIXES);
        fixes = java.util.Arrays.copyOf(fixes, MAX_FIXES);
      }
      int[] starts = in.occStarts;
      int[] ends = in.occEnds;
      int occ = Math.min(starts.length, ends.length);
      if (occ > MAX_OCCURRENCES) {
        dropped += occ - MAX_OCCURRENCES;
        note("occurrences capped at " + MAX_OCCURRENCES);
        occ = MAX_OCCURRENCES;
      }
      return new Finding(
          in.offset, in.end, in.line, in.column, in.severity, cut(in.code, MAX_NAME),
          cut(in.message, MAX_MESSAGE), cut(in.messageKey, MAX_NAME), keptTags, keptValues, fixes,
          java.util.Arrays.copyOf(starts, occ), java.util.Arrays.copyOf(ends, occ));
    }

    private Members clamp(Members in) {
      String[] classes = cutTo(in.classNames, MAX_CLASSES, "classes");
      String[] methods = cutTo(in.methodNames, MAX_METHODS, "methods");
      String[] names = cutTo(in.fieldNames, MAX_FIELDS, "fields");
      String[] types = names.length == in.fieldTypes.length ? in.fieldTypes : new String[names.length];
      for (int i = 0; i < types.length; i++) types[i] = cut(types[i], MAX_NAME);
      for (int i = 0; i < names.length; i++) names[i] = cut(names[i], MAX_NAME);
      for (int i = 0; i < classes.length; i++) classes[i] = cut(classes[i], MAX_NAME);
      for (int i = 0; i < methods.length; i++) methods[i] = cut(methods[i], MAX_NAME);
      return new Members(classes, methods, names, types);
    }

    private String[] cutTo(String[] values, int cap, String what) {
      if (values == null) return new String[0];
      if (values.length <= cap) return values.clone();
      dropped += values.length - cap;
      note(what + " capped at " + cap);
      return java.util.Arrays.copyOf(values, cap);
    }

    private String cut(String value, int cap) {
      String clamped = clampLen(value, cap);
      if (value != null && clamped.length() != value.length()) note("text clamped to " + cap);
      return clamped;
    }

    private void note(String text) {
      if (problems.size() >= MAX_PROBLEMS) return;
      if (!problems.contains(text)) problems.add(text);
    }
  }

  /** هل يتّسعُ الطلبُ كلُّهُ؟ (الحجمُ بعدَ التهرّبِ هو المُعتَدُّ بهِ، فيُقدَّرُ تقديرًا آمنًا). */
  public static boolean acceptsRequest(int totalChars) {
    return totalChars >= 0 && totalChars <= MAX_REQUEST_CHARS;
  }

  // ─────────────────────────── الترميزُ ───────────────────────────

  /** رأسُ الطلبِ: {@code generation|file|totalChars|partCount}. */
  public static String encodeRequest(Request request) {
    if (request == null) return "";
    return join(FIELD, num(request.generation), esc(request.file), num(request.totalChars),
        num(request.partCount));
  }

  /** قطعةُ نصٍّ: {@code generation|index|file|text}. */
  public static String encodePart(Part part) {
    if (part == null) return "";
    return join(FIELD, num(part.generation), num(part.index), esc(part.file), esc(part.text));
  }

  /** عددُ حقولِ الردِّ: جيلٌ، ملفٌّ، حالةٌ، مسقَطاتٌ، تشخيصاتٌ، أعضاءُ، سِجلّاتٌ. */
  private static final int FIELD_COUNT_REPLY = 7;

  /** حقلا حالةٍ: {@code state|detail} — فكٌّ مُقوَّسٌ كما في الباقينَ، لا انقسامٌ على نصٍّ حرٍّ. */
  public static String[] stateFields(String wire) {
    String[] f = fields(wire);
    if (f.length < 1) return new String[] {STATE_NOT_BOUND, ""};
    return new String[] {unesc(f[0]), f.length > 1 ? unesc(f[1]) : ""};
  }

  /** حالةٌ مُجرَّدةٌ: {@code state|detail}. */
  public static String encodeState(String state, String detail) {
    return join(FIELD, esc(orEmpty(state)), esc(clampLen(orEmpty(detail), MAX_MESSAGE)));
  }

  /** فكُّ رأسِ الطلبِ؛ {@code null} عندَ أيِّ انحرافٍ. */
  public static Request decodeRequest(String wire) {
    String[] f = fields(wire);
    if (f.length < 4) return null;
    try {
      return new Request(
          Long.parseLong(unesc(f[0])), unesc(f[1]), Integer.parseInt(unesc(f[2])),
          Integer.parseInt(unesc(f[3])));
    } catch (RuntimeException malformed) {
      return null;
    }
  }

  /** فكُّ قطعةِ نصٍّ؛ {@code null} عندَ أيِّ انحرافٍ. */
  public static Part decodePart(String wire) {
    String[] f = fields(wire);
    if (f.length < 4) return null;
    try {
      return new Part(Long.parseLong(unesc(f[0])), Integer.parseInt(unesc(f[1])), unesc(f[2]), unesc(f[3]));
    } catch (RuntimeException malformed) {
      return null;
    }
  }

  /** الردُّ كلُّهُ في سلسلةٍ واحدةٍ. */
  public static String encode(Reply reply) {
    if (reply == null) return "";
    StringBuilder findings = new StringBuilder(32 + reply.findings.length * 48);
    findings.append(reply.findings.length);
    for (Finding f : reply.findings) {
      findings.append(RECORD).append(encodeFinding(f));
    }
    // لا تهريبَ للحقلينِ البنيويّينِ: قيماهُما المُهرَّبةُ لا تحمِلُ فاصلًا خامًا من المستوى الأعلى،
    // والفواصلُ الداخليّةُ (RECORD/PART/SUB والمسافةُ) متميّزةٌ، فالتقسيمُ يَبقى صحيحًا بلا تضخيمٍ.
    StringBuilder problems = new StringBuilder(16);
    List<String> notes = reply.problems;
    problems.append(num(notes.size()));
    for (String note : notes) problems.append(SUB).append(esc(note));
    return join(FIELD, num(reply.generation), esc(reply.file), esc(reply.state), num(reply.dropped),
        findings.toString(), encodeMembers(reply.members), problems.toString());
  }

  private static String encodeFinding(Finding f) {
    StringBuilder args = new StringBuilder();
    for (int i = 0; i < f.argValues.length; i++) {
      if (i > 0) args.append(SUB);
      args.append(f.argTags.length > i && f.argTags[i] == 'i' ? 'i' : 's').append(esc(f.argValues[i]));
    }
    StringBuilder fixes = new StringBuilder();
    for (int i = 0; i < f.fixes.length; i++) {
      if (i > 0) fixes.append(SUB);
      fixes.append(encodeFix(f.fixes[i]));
    }
    return join(PART, num(f.offset), num(f.end), num(f.line), num(f.column), num(f.severity),
        esc(f.code), esc(f.message), esc(f.messageKey), args.toString(), fixes.toString(),
        intList(f.occStarts), intList(f.occEnds));
  }

  /** سِجلُّ الإصلاحِ: حقلٌ واحدٌ تفرّقُهُ مسافاتٌ (والهربُ يضمنُ خلوَّ القيمِ من مسافةٍ خامٍ). */
  private static String encodeFix(Fix x) {
    StringBuilder out = new StringBuilder(96);
    int params = Math.min(x.paramTypes.length, x.paramNames.length);
    out.append(esc(x.kind)).append(' ').append(esc(x.targetClass)).append(' ').append(esc(x.returnType))
        .append(' ').append(esc(x.methodName)).append(' ').append(esc(x.importName)).append(' ')
        .append(esc(x.titleKey)).append(' ').append(esc(x.titleArg)).append(' ').append(esc(x.expected))
        .append(' ').append(x.isStatic ? '1' : '0').append(' ').append(num(x.insertOffset)).append(' ')
        .append(num(x.editEnd)).append(' ').append(num(params));
    for (int i = 0; i < params; i++) {
      out.append(' ').append(esc(x.paramTypes[i])).append('=').append(esc(x.paramNames[i]));
    }
    // ‏1.0.191: الحقلانِ الجديدينِ يَلِيانِ القديمَ كلَّهُ، فلا يَنقَلِبُ مَوضِعُ شيءٍ؛ والدَّفعَةُ تُدفَعُ
    // كاملةً لأنَّ نصفَها يَترُكُ صنفًا لا يُبنى (نفسُ علَّةِ OVER_BATCH_LIMIT في المُحرِّكِ).
    out.append(' ').append(x.overrides ? '1' : '0').append(' ').append(num(x.companions.length))
        .append(' ').append(num(x.imports.length));
    for (String imp : x.imports) out.append(' ').append(esc(imp));
    for (Fix c : x.companions) {
      int companionParams = Math.min(c.paramTypes.length, c.paramNames.length);
      out.append(' ').append(esc(c.returnType)).append(' ').append(esc(c.methodName)).append(' ')
          .append(num(companionParams));
      for (int i = 0; i < companionParams; i++) {
        out.append(' ').append(esc(c.paramTypes[i])).append('=').append(esc(c.paramNames[i]));
      }
    }
    return out.toString();
  }

  /** قائمةُ أعدادٍ مُسطَّحةٌ: {@code count\u0004v1\u0004v2…} — نفسُ بنيةِ القوائمِ النصّيّةِ. */
  private static String intList(int[] values) {
    StringBuilder out = new StringBuilder(8 + (values == null ? 0 : values.length * 5));
    out.append(num(values == null ? 0 : values.length));
    if (values != null) {
      for (int value : values) out.append(SUB).append(num(value));
    }
    return out.toString();
  }

  /** فكُّ قائمةِ أعدادٍ؛ {@code null} عندَ أيِّ انحرافٍ (عددٌ لا يَطابِقُ، أو رقمٌ غيرُ صحيحٍ). */
  private static int[] readIntList(String blob) {
    String[] items = sub(blob);
    if (items.length == 0) return null;
    int count = Integer.parseInt(unesc(items[0]));
    if (count < 0 || count != items.length - 1) return null;
    int[] out = new int[count];
    for (int i = 0; i < count; i++) out[i] = Integer.parseInt(unesc(items[i + 1]));
    return out;
  }

  private static String encodeMembers(Members m) {
    StringBuilder out = new StringBuilder(64);
    appendList(out, m.classNames);
    out.append(RECORD);
    appendList(out, m.methodNames);
    out.append(RECORD);
    int fields = Math.min(m.fieldNames.length, m.fieldTypes.length);
    out.append(num(fields));
    for (int i = 0; i < fields; i++) {
      out.append(SUB).append(esc(m.fieldNames[i])).append('=').append(esc(m.fieldTypes[i]));
    }
    return out.toString();
  }

  private static void appendList(StringBuilder out, String[] values) {
    out.append(num(values.length));
    for (String value : values) out.append(SUB).append(esc(value));
  }

  /** {@code null} عندَ أيِّ انحرافٍ في البنيةِ: الردُّ المُختَلُ لا يُطبَّقُ نصفيًّا على المحرِّرِ. */
  public static Reply decode(String wire) {
    String[] top = fields(wire);
    if (top.length < FIELD_COUNT_REPLY) return null;
    try {
      long generation = Long.parseLong(unesc(top[0]));
      String file = unesc(top[1]);
      String state = unesc(top[2]);
      int dropped = Integer.parseInt(unesc(top[3]));
      Finding[] findings = decodeFindings(top[4]);
      Members members = decodeMembers(top[5]);
      List<String> problems = new ArrayList<>(java.util.Arrays.asList(list(top[6])));
      if (findings == null || members == null) return null;
      return new Reply(generation, file, findings, members, state, dropped, problems);
    } catch (RuntimeException malformed) {
      return null;
    }
  }

  private static Finding[] decodeFindings(String blob) {
    String[] records = records(blob);
    if (records.length == 0) return null;
    int count = Integer.parseInt(unesc(records[0]));
    if (count < 0 || count > MAX_FINDINGS || count != records.length - 1) return null;
    Finding[] out = new Finding[count];
    for (int i = 0; i < count; i++) {
      out[i] = decodeFinding(records[i + 1]);
      if (out[i] == null) return null;
    }
    return out;
  }

  private static Finding decodeFinding(String blob) {
    String[] p = parts(blob);
    if (p.length < 10) return null;
    int[] occStarts = new int[0];
    int[] occEnds = new int[0];
    if (p.length >= 12) {
      occStarts = readIntList(p[10]);
      occEnds = readIntList(p[11]);
      if (occStarts == null || occEnds == null) return null;
    }
    String[] args = sub(p[8]);
    char[] tags = new char[args.length];
    String[] values = new String[args.length];
    for (int i = 0; i < args.length; i++) {
      String raw = args[i];
      if (raw.isEmpty()) return null;
      tags[i] = raw.charAt(0) == 'i' ? 'i' : 's';
      values[i] = unesc(cut1(raw, 1, raw.length()));
    }
    String[] fixBlobs = sub(p[9]);
    Fix[] fixes = new Fix[fixBlobs.length];
    for (int i = 0; i < fixes.length; i++) {
      fixes[i] = decodeFix(fixBlobs[i]);
      if (fixes[i] == null) return null;
    }
    return new Finding(
        Integer.parseInt(unesc(p[0])), Integer.parseInt(unesc(p[1])), Integer.parseInt(unesc(p[2])),
        Integer.parseInt(unesc(p[3])), Integer.parseInt(unesc(p[4])), unesc(p[5]), unesc(p[6]),
        unesc(p[7]), tags, values, fixes, occStarts, occEnds);
  }

  private static Fix decodeFix(String raw) {
    String[] x = raw.split(" ", -1);
    if (x.length < 12) return null;
    int params;
    try {
      params = Integer.parseInt(x[11]);
    } catch (NumberFormatException bad) {
      return null;
    }
    if (params < 0 || params > MAX_FIELDS || x.length < 12 + params) return null;
    String[] types = new String[params];
    String[] names = new String[params];
    for (int i = 0; i < params; i++) {
      String pair = x[12 + i];
      int eq = pair.indexOf('=');
      if (eq < 0) return null;
      types[i] = unesc(pair.substring(0, eq));
      names[i] = unesc(pair.substring(eq + 1));
    }
    // ما بَعدَ الثلاثةَ عشرَ اختيارِيٌّ: سِلكٌ قَصيرٌ يَعني «لا عَلمَ ولا دَفعَةَ» — لا فَسخَةً تَرفُضُها.
    int at = 12 + params;
    boolean overrides = x.length > at && "1".equals(x[at]);
    Fix[] companions = new Fix[0];
    String[] importsToFetch = new String[0];
    if (x.length > at + 2) {
      int count;
      int importCount;
      try {
        count = Integer.parseInt(x[at + 1]);
        importCount = Integer.parseInt(x[at + 2]);
      } catch (NumberFormatException bad) {
        return null;
      }
      if (count < 0 || count > MAX_COMPANIONS) return null; // دَفعَةٌ مشبوهةٌ: لا نِصفَها ولا كلَّها
      if (importCount < 0 || importCount > MAX_FIELDS) return null;
      at += 3;
      if (x.length < at + importCount) return null;
      if (importCount > 0) {
        importsToFetch = new String[importCount];
        for (int i = 0; i < importCount; i++) importsToFetch[i] = unesc(x[at + i]);
        at += importCount;
      }
      ArrayList<Fix> built = new ArrayList<Fix>(count);
      for (int c = 0; c < count; c++) {
        if (x.length < at + 3) return null;
        String companionReturn = unesc(x[at]);
        String companionName = unesc(x[at + 1]);
        int companionParams;
        try {
          companionParams = Integer.parseInt(x[at + 2]);
        } catch (NumberFormatException bad) {
          return null;
        }
        if (companionParams < 0 || companionParams > MAX_FIELDS
            || x.length < at + 3 + companionParams) {
          return null;
        }
        String[] cTypes = new String[companionParams];
        String[] cNames = new String[companionParams];
        for (int i = 0; i < companionParams; i++) {
          String pair = x[at + 3 + i];
          int eq = pair.indexOf('=');
          if (eq < 0) return null;
          cTypes[i] = unesc(pair.substring(0, eq));
          cNames[i] = unesc(pair.substring(eq + 1));
        }
        at += 3 + companionParams;
        // الراسُ نفسُهُ في الصنفِ والغلافِ: دَفعَةٌ واحدةٌ، لا نَسخَةٌ ثانِيَةٌ لكلِّ سطرٍ.
        built.add(new Fix(unesc(x[0]), unesc(x[1]), companionReturn, companionName, "", "", "", "",
            cTypes, cNames, false, -1, -1, true, null));
      }
      companions = built.toArray(new Fix[built.size()]);
    }
    return new Fix(
        unesc(x[0]), unesc(x[1]), unesc(x[2]), unesc(x[3]), unesc(x[4]), unesc(x[5]), unesc(x[6]),
        unesc(x[7]), types, names, "1".equals(x[8]), Integer.parseInt(x[9]), Integer.parseInt(x[10]),
        overrides, companions, importsToFetch);
  }

  private static Members decodeMembers(String blob) {
    String[] groups = records(blob);
    if (groups.length < 3) return null;
    String[] classes = list(groups[0]);
    String[] methods = list(groups[1]);
    String[] fieldBlob = sub(groups[2]);
    if (fieldBlob.length == 0) return null;
    int count = Integer.parseInt(unesc(fieldBlob[0]));
    if (count < 0 || count != fieldBlob.length - 1) return null;
    String[] names = new String[count];
    String[] types = new String[count];
    for (int i = 0; i < count; i++) {
      String pair = fieldBlob[i + 1];
      int eq = pair.indexOf('=');
      if (eq < 0) return null;
      names[i] = unesc(cut1(pair, 0, eq));
      types[i] = unesc(cut1(pair, eq + 1, pair.length()));
    }
    return new Members(classes, methods, names, types);
  }

  /** عددُ عناصرَ قائمةٍ مُتَّبعَةٍ بسوابقَ مُهرَّبةٍ (العنصرُ الأولُ عددٌ). */
  private static String[] list(String blob) {
    String[] items = sub(blob);
    if (items.length == 0) return new String[0];
    int count = Integer.parseInt(unesc(items[0]));
    if (count < 0 || count != items.length - 1) throw new IllegalStateException("bad list");
    String[] out = new String[count];
    for (int i = 0; i < count; i++) out[i] = unesc(items[i + 1]);
    return out;
  }

  private static String cut1(String value, int from, int to) {
    return value.substring(Math.max(0, Math.min(from, value.length())), Math.max(0, Math.min(to, value.length())));
  }

  // ─────────────────────────── قناةُ الحِملِ بينَ العمليّاتِ ───────────────────────────
  //
  // عطلٌ قياسيٌّ على الجهازِ (‏1.0.177): كانَ الحِملُ السِّلكيُّ يَسكُنُ {@code Message.obj}، ومن‏ Android 13
  // فصاعدًا يَكتُبُ {@code Message#writeToParcel} ذلكَ الحقلَ بوصفِهِ {@code Parcelable} لا {@code
  // String}، فيُلقِي {@code RuntimeException("Can't marshal non-Parcelable objects across processes.")}
  // على خيطِ الواجهةِ كلَّمَا طَلَبَ المحرِّرُ فحصًا — أي أنَّ الجسرَ كلَّهُ كانَ سقوفًا لا مِشوارًا.
  // القرارُ مُعلَنٌ هنا، وخيطُ النقلِ في {@code com.almlkid.analyzer.AnalyzerCarrier} يَنفُذُهُ: الحِملُ
  // في {@code Message.data} (حزمةُ مفاتيحَ مُجرَّأةٌ أصلًا)، ويَبقى {@code obj} خاليًا.

  /** مفتاحُ الحِملِ داخلَ {@code Message.data} — اسمٌ واحدٌ لا يُتَنازَعُ عليهِ بينَ الطرَفَينِ. */
  public static final String KEY_WIRE = "almlk.analyzer.wire";

  /** القناتانِ اللتانِ تعرفُهُما {@code Messenger}: {@code obj} للـ{@code Parcelable}، و{@code data} لكلِّ شيءٍ آخرَ. */
  public static final String CARRIER_OBJ = "obj";
  public static final String CARRIER_DATA = "data";

  /** الواجهةُ المَعرِفةُ بالاسمِ لا بالنوعِ: الطبقةُ الصافيةُ لا تَعرِفُ ‏android، فتُبتَّلى القابليّةُ كذلكَ. */
  public static final String PARCELABLE = "android.os.Parcelable";

  /** ما يَصلُحُ لحقلِ {@code obj}: {@code null} أو كلُّ ما يُنفِّذُ {@code Parcelable} (بما فيها الموروثةُ). */
  public static boolean allowedInMessageObj(Object payload) {
    return payload == null || implementsParcelable(payload.getClass());
  }

  /** القناةُ الواجبةُ لهذا الحِملِ — لا ثالثةَ لهُما، ولا اختيارٌ عندَ الإرسالِ. */
  public static String carrierFor(Object payload) {
    return allowedInMessageObj(payload) ? CARRIER_OBJ : CARRIER_DATA;
  }

  /** سطرُ السجلِّ: لِمَ سَلَكَ الحِملُ هذه القناةَ بالذاتِ — لا يُترَكُ القارئُ يَخمِنُ. */
  public static String explainCarrier(Object payload) {
    if (payload == null) return "carrier=" + CARRIER_OBJ + "/null";
    return "carrier=" + carrierFor(payload) + " for " + payload.getClass().getName()
        + (allowedInMessageObj(payload) ? " (Parcelable)" : " (not Parcelable)");
  }

  /** حالةٌ مُسمّاةٌ حينَ يَرفُضُ النقلُ ما حُمِّلَ: سماءُ السقفِ من سماءِ العطلِ، فلا صمتَ ولا سقوطَ. */
  public static String stateForSendFailure(Throwable failure) {
    return failure instanceof IllegalStateException ? STATE_TOO_LARGE : STATE_REFUSED;
  }

  /** هل يَحمِلُ هذا النوعُ {@code Parcelable} في سلسلتِهِ؟ عامٌّ لأنَّ الحارسَ والدليلَ يَقرَآنِهِ. */
  public static boolean implementsParcelable(Class<?> type) {
    if (type == null) return false;
    if (PARCELABLE.equals(type.getName())) return true;
    for (Class<?> iface : type.getInterfaces()) {
      if (implementsParcelable(iface)) return true;
    }
    return implementsParcelable(type.getSuperclass());
  }

  // ─────────────────────────── أدواتُ السلسلةِ ───────────────────────────

  /** يهرّبُ محارفَ الفصلِ الأربعةَ والمسافةَ والشرطةَ المائلةَ العكسيّةَ والتابَ ورفَّ السطرِ ونهايتَه. */
  public static String esc(String value) {
    if (value == null || value.isEmpty()) return "";
    StringBuilder out = new StringBuilder(value.length() + 8);
    for (int i = 0; i < value.length(); i++) {
      char c = value.charAt(i);
      if (c == '\\') out.append("\\\\");
      else if (c == FIELD) out.append("\\a");
      else if (c == RECORD) out.append("\\b");
      else if (c == PART) out.append("\\c");
      else if (c == SUB) out.append("\\d");
      else if (c == ' ') out.append("\\s");
      else if (c == '\n') out.append("\\n");
      else if (c == '\r') out.append("\\r");
      else if (c == '\t') out.append("\\t");
      else out.append(c);
    }
    return out.toString();
  }

  /** عكسُ {@link #esc(String)} — لا يُبدِّلُ شيئًا آخرِ، فيبقى نصُّ الملفِّ كما هو بايتًا ببايتٍ. */
  public static String unesc(String value) {
    if (value == null || value.isEmpty()) return "";
    if (value.indexOf('\\') < 0) return value;
    StringBuilder out = new StringBuilder(value.length());
    for (int i = 0; i < value.length(); i++) {
      char c = value.charAt(i);
      if (c != '\\' || i + 1 >= value.length()) {
        out.append(c);
        continue;
      }
      char n = value.charAt(++i);
      if (n == '\\') out.append('\\');
      else if (n == 'a') out.append(FIELD);
      else if (n == 'b') out.append(RECORD);
      else if (n == 'c') out.append(PART);
      else if (n == 'd') out.append(SUB);
      else if (n == 's') out.append(' ');
      else if (n == 'n') out.append('\n');
      else if (n == 'r') out.append('\r');
      else if (n == 't') out.append('\t');
      else out.append('\\').append(n);
    }
    return out.toString();
  }

  /** يقطعُ عندَ السقفِ دونَ كسرِ زوجٍ من محارفِ ‏UTF‑16. */
  public static String clampLen(String value, int cap) {
    if (value == null) return "";
    if (cap <= 0 || value.length() <= cap) return value;
    int cut = cap;
    if (Character.isHighSurrogate(value.charAt(cut - 1))) cut--;
    return value.substring(0, Math.max(0, cut));
  }

  /** يقسمُ على محرفِ فصلٍ مع احترامِ التهرّبِ (لا يَفصِلُ داخلَ قيمةٍ مُهرَّبةٍ). */
  private static String[] cutAt(String wire, char sep) {
    if (wire == null || wire.isEmpty()) return new String[0];
    ArrayList<String> out = new ArrayList<>(4);
    StringBuilder current = new StringBuilder();
    for (int i = 0; i < wire.length(); i++) {
      char c = wire.charAt(i);
      if (c == '\\' && i + 1 < wire.length()) {
        // تسلسلُ تهريبٍ: يُنقَلُ كما هو إلى القطعةِ ولا يُعتَبَرُ فاصلًا.
        current.append(c).append(wire.charAt(++i));
        continue;
      }
      if (c == sep) {
        out.add(current.toString());
        current.setLength(0);
        continue;
      }
      current.append(c);
    }
    out.add(current.toString());
    return out.toArray(new String[0]);
  }

  private static String[] fields(String wire) {
    return cutAt(wire, FIELD);
  }

  private static String[] records(String wire) {
    return cutAt(wire, RECORD);
  }

  private static String[] parts(String wire) {
    return cutAt(wire, PART);
  }

  private static String[] sub(String wire) {
    return cutAt(wire, SUB);
  }

  private static String join(char sep, String... values) {
    StringBuilder out = new StringBuilder(64);
    for (int i = 0; i < values.length; i++) {
      if (i > 0) out.append(sep);
      out.append(values[i]);
    }
    return out.toString();
  }

  private static String num(long value) {
    // الأعدادُ لا تحتاجُ تهريبًا، وتُترَكُ كما هي ليكونَ السطرُ مَقروءً في السجلِّ.
    return Long.toString(value);
  }

  private static String orEmpty(String value) {
    return value == null ? "" : value;
  }
}
