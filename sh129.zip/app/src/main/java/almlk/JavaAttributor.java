package almlk;

import static almlk.JavaSyntaxTree.*;

import almlk.JavaTypeModel.ArrayType;
import almlk.JavaTypeModel.ClassSymbol;
import almlk.JavaTypeModel.ClassType;
import almlk.JavaTypeModel.FieldSymbol;
import almlk.JavaTypeModel.FileContext;
import almlk.JavaTypeModel.Lookup;
import almlk.JavaTypeModel.MethodSymbol;
import almlk.JavaTypeModel.Primitive;
import almlk.JavaTypeModel.SourceClass;
import almlk.JavaTypeModel.Type;
import almlk.JavaTypeModel.TypeVar;
import almlk.JavaTypeModel.Universe;
import almlk.JavaTypeModel.WildcardType;
import com.almlkid.kay.ui.CodeLanguageTools.Diagnostic;
import com.almlkid.kay.ui.ProjectSymbolIndex;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;

/**
 * Name and type attribution of one Java file (E1 of the error-checker replacement).
 *
 * <p>Walks the syntax tree with nested scopes (locals, parameters, pattern bindings, fields with
 * everything inherited, enclosing classes, static imports), types every expression through {@link
 * JavaTypeModel} and reports, in the reference wording: unknown types and packages, unknown
 * methods and fields of a known receiver (project, platform and library classes, chains included),
 * unknown variables and entities, unknown types of fields and variables, calls on primitives,
 * inapplicable methods and constructors by argument count, duplicate imports, and never-used
 * private fields.
 *
 * <p>Precision rule: absence is reported only when proven — the receiver type is known and its whole
 * hierarchy is known and reliable; an unknown receiver silences everything after it, so one wrong
 * name yields one finding.
 */
final class JavaAttributor {

  private static final int MAX_FINDINGS = 200;
  /** أعطال داخلية عُزلت (للاختبارات): لا تُسكت بقية الملف. */
  int isolatedFailures;

  private final String src;

  // R4 (dd$a): statement context of the body being attributed.
  private static final int CTX_NONE = 0, CTX_VOID = 1, CTX_VALUE = 2, CTX_CTOR = 3, CTX_INIT = 4;
  private int returnContext = CTX_NONE;
  private String returnTypeText = "";
  private Type returnType = JavaTypeModel.UNKNOWN;
  // R5 (wd): checked exceptions — context of the body, its throws clause and enclosing catches.
  private static final int EXC_NONE = 0, EXC_METHOD = 1, EXC_STATIC_INIT = 2;
  private int exceptionContext = EXC_NONE;
  /** R6: the method whose body is attributed and the throw statement being checked (for fixes). */
  private MethodDecl currentMethod;
  private Throw currentThrow;
  private List<ClassSymbol> declaredThrows = Collections.emptyList();
  /** Catch types of the enclosing try bodies; a null entry is an unresolved type (covers all). */
  private ArrayList<ClassSymbol> handlers = new ArrayList<>();
  private int loopDepth;
  private Type lastInitType = JavaTypeModel.UNKNOWN;
  private int switchDepth;
  private final Unit unit;
  private final FileContext file;
  private final HashMap<String, ClassSymbol> overlay = new HashMap<>();
  private final Universe universe;
  private final ArrayList<Diagnostic> out = new ArrayList<>();
  private final HashSet<String> reported = new HashSet<>();
  private final int[] lineStarts;
  private final boolean apiReady;
  private final boolean typesCheckable;
  private final boolean importsCheckable;
  private final boolean librariesComplete;
  private final HashMap<String, Boolean> packageCache = new HashMap<>();
  private final HashSet<String> failedFields = new HashSet<>();
  private boolean lastReported;

  // ───────────────────────────── scopes ─────────────────────────────

  private static final class Var {
    final String name;
    final Type type;
    final boolean typeFailed;
    /** Declared final with a value (or a final parameter): any later write is an error. */
    boolean isFinal;

    Var(String name, Type type, boolean typeFailed) {
      this.name = name;
      this.type = type == null ? JavaTypeModel.UNKNOWN : type;
      this.typeFailed = typeFailed;
    }
  }

  private static final class Scope {
    final Scope parent;
    final ClassSymbol owner;
    final boolean isStatic;
    HashMap<String, Var> vars;
    HashMap<String, ClassSymbol> types;
    HashMap<String, TypeVar> typeVars;

    Scope(Scope parent, ClassSymbol owner, boolean isStatic) {
      this.parent = parent;
      this.owner = owner;
      this.isStatic = isStatic;
    }

    void declare(Var v) {
      if (v.name == null || v.name.isEmpty()) return;
      if (vars == null) vars = new HashMap<>();
      vars.put(v.name, v);
    }
  }

  private final class ScopeNames implements JavaTypeModel.LocalNames {
    final Scope scope;

    ScopeNames(Scope scope) {
      this.scope = scope;
    }

    @Override
    public ClassSymbol localType(String name) {
      for (Scope x = scope; x != null; x = x.parent) {
        if (x.types != null && x.types.containsKey(name)) return x.types.get(name);
        if (x.owner != null) return null;
      }
      return null;
    }

    @Override
    public Type typeVariable(String name) {
      return lookupTypeVar(name, scope);
    }
  }

  JavaAttributor(String src, Unit unit) {
    this.src = src;
    this.unit = unit;
    file = new FileContext(unit);
    universe = new Universe(overlay);
    for (TypeDecl decl : unit.types) {
      if (decl.name.isEmpty() || file.topLevel.containsKey(decl.name)) continue;
      SourceClass c = new SourceClass(decl, file, null, universe, null);
      file.topLevel.put(decl.name, c);
      addOverlay(c);
    }
    lineStarts = lineStarts(src);
    apiReady = AndroidApiIndex.classByQualifiedName("java.lang.Object") != null;
    String first = unit.types.isEmpty() ? "" : unit.types.get(0).name;
    boolean indexed = !first.isEmpty()
        && JavaProjectModel.classByQualifiedName(JavaTypeModel.qualify(file.packageName, first)) != null;
    // الجزم بـ«رمز غير موجود» فرعٌ واحد منه typesCheckable؛ يُمنع ما دام نموذج المشروع غير مكتمل
    // (مسحة جارية أو ملف لم تُقرأ) — وإلا انقلبت كل أصناف المشروع إلى Unknown entity عند الفتح.
    typesCheckable = apiReady && indexed && JavaProjectModel.absenceProvablyComplete();
    importsCheckable = apiReady && !first.isEmpty()
        && LibraryClassIndex.importsCheckable(file.packageName, first);
    librariesComplete = importsCheckable && LibraryClassIndex.isComplete();
  }

  private void addOverlay(SourceClass c) {
    overlay.put(c.qualifiedName(), c);
    for (SourceClass n : c.nestedClasses()) addOverlay(n);
  }

  List<Diagnostic> run() {
    checkImports();
    Scope top = new Scope(null, null, false);
    for (TypeDecl decl : unit.types) {
      ClassSymbol c = file.topLevel.get(decl.name);
      try {
        if (c instanceof SourceClass && ((SourceClass) c).decl == decl) attribClass((SourceClass) c, top);
      } catch (RuntimeException | StackOverflowError failure) {
        isolatedFailures++;
      }
    }
    try {
      checkUnusedPrivateFields();
    } catch (RuntimeException | StackOverflowError failure) {
      isolatedFailures++;
    }
    Collections.sort(out, (a, b) -> a.offset != b.offset ? a.offset - b.offset : a.end - b.end);
    return out;
  }

  // ───────────────────────────── reporting ─────────────────────────────

  private static int[] lineStarts(String s) {
    int count = 1;
    for (int i = 0; i < s.length(); i++) if (s.charAt(i) == '\n') count++;
    int[] starts = new int[count];
    int k = 1;
    for (int i = 0; i < s.length(); i++) if (s.charAt(i) == '\n') starts[k++] = i + 1;
    return starts;
  }

  private void report(int start, int end, Diagnostic.Severity severity, String key, String fallback,
      QuickFix fix, Object... args) {
    if (out.size() >= MAX_FINDINGS || start < 0 || start >= src.length() + 1) return;
    if (!reported.add(start + ":" + key)) return;
    int lo = 0;
    int hi = lineStarts.length - 1;
    while (lo < hi) {
      int mid = (lo + hi + 1) >>> 1;
      if (lineStarts[mid] <= start) lo = mid;
      else hi = mid - 1;
    }
    // الأسرةُ تُقرِّرُها طبقةُ التصنيفِ لا المُنتِجُ: تلميحُ المحرِّرِ يَخرُجُ بـ‏INFO (شرطٌ دائمٌ ‏21).
    Diagnostic.Severity family = JavaDiagnosticCodes.severityFor(key, severity);
    Diagnostic d = Diagnostic.localized(start, Math.max(start + 1, end), lo + 1,
        start - lineStarts[lo] + 1, family, JavaDiagnosticCodes.codeOf(key), key, fallback,
        args);
    if (fix != null) d = d.withQuickFixes(Collections.singletonList(fix));
    out.add(d);
    lastReported = true;
  }

  /**
   * الوَجهُ الآخَرُ للحَكمِ الوَاحِدِ: قَرارُ المَخرَجِ في ‏JavaImportResolver‏ لا هُنا، وعَددُ المُختَاراتِ
   * مَسمُومٌ بِسَقفِ المُحرِّكِ (‏AnalyzerProtocol.MAX_FIXES`‏) فَلا صَفحَةٌ تَغرَقُ. والإِصلاحُ الَّذِي
   * لا يَكتُبُ شَيئًا (مِلَفٌّ يَكتَفِيهِ باقَةٌ مَفتُوحَةٌ) لا يُعرَضُ: مَخرَجٌ كَاذِبٌ أَشرُّ مِن لا
   * مَخرَجَ (ج٤٣: «‏Add 'import …'`‏ لكُلِّ مُرشَّحٍ، وَالحُكمُ لِلمُستَخدِمِ»).
   */
  private void reportChoices(int start, int end, Diagnostic.Severity severity, String key,
      String fallback, java.util.List<QuickFix> fixes, Object... args) {
    if (fixes == null || fixes.isEmpty()) {
      report(start, end, severity, key, fallback, (QuickFix) null, args);
      return;
    }
    if (fixes.size() == 1) {
      report(start, end, severity, key, fallback, fixes.get(0), args);
      return;
    }
    if (out.size() >= MAX_FINDINGS || start < 0 || start >= src.length() + 1) return;
    if (!reported.add(start + ":" + key)) return;
    int lo = 0;
    int hi = lineStarts.length - 1;
    while (lo < hi) {
      int mid = (lo + hi + 1) >>> 1;
      if (lineStarts[mid] <= start) lo = mid;
      else hi = mid - 1;
    }
    Diagnostic.Severity family = JavaDiagnosticCodes.severityFor(key, severity);
    Diagnostic d = Diagnostic.localized(start, Math.max(start + 1, end), lo + 1,
        start - lineStarts[lo] + 1, family, JavaDiagnosticCodes.codeOf(key), key, fallback, args);
    out.add(d.withQuickFixes(new ArrayList<QuickFix>(fixes)));
    lastReported = true;
  }

  private void error(int start, int end, String key, String fallback, QuickFix fix, Object... args) {
    report(start, end, Diagnostic.Severity.ERROR, key, fallback, fix, args);
  }

  /** تشخيصٌ ومَخرَجَاتٌ عِدَّةٌ — لا واحدٌ مُختارٌ بالنِّيبَةِ عَنِ المُستَخدِمِ. */
  private void errorChoices(int start, int end, String key, String fallback,
      java.util.List<QuickFix> fixes, Object... args) {
    reportChoices(start, end, Diagnostic.Severity.ERROR, key, fallback, fixes, args);
  }

  // ───────────────────────────── certainty ─────────────────────────────

  private static boolean generatedName(String name) {
    return name.equals("R") || name.equals("BR") || name.equals("BuildConfig")
        || name.equals("Manifest") || name.endsWith("Binding") || name.startsWith("Dagger")
        || name.startsWith("Hilt_") || name.indexOf('_') > 0 || name.endsWith("Directions")
        || name.endsWith("Args") || name.startsWith("AutoValue_");
  }

  /** Every class of a platform or project package is known (library ones only when resolved). */
  private boolean packageFullyKnown(String pkg) {
    Boolean cached = packageCache.get(pkg);
    if (cached != null) return cached;
    boolean known = false;
    if (JavaProjectModel.hasPackage(pkg)) {
      known = !JavaProjectModel.hasForeignSources();
    } else if (apiReady) {
      List<AndroidApiIndex.ClassInfo> classes = AndroidApiIndex.classesInPackage(pkg);
      boolean platform = false;
      for (AndroidApiIndex.ClassInfo c : classes) if (!c.library) platform = true;
      known = platform || !classes.isEmpty() && librariesComplete;
    }
    packageCache.put(pkg, known);
    return known;
  }

  private boolean packageLike(String name) {
    String key = "?" + name;
    Boolean cached = packageCache.get(key);
    if (cached != null) return cached;
    boolean like = JavaProjectModel.isPackagePrefix(name)
        || apiReady && AndroidApiIndex.isKnownPackage(name);
    packageCache.put(key, like);
    return like;
  }

  /**
   * W5′: إصلاح الاستيراد عند الاسم غير المحلول — **مرشَّح وحيد** قرّره {@link JavaImportResolver}
   * بطبقاته (المشروع ← الكتلة المصونة ← فهرس المنصّة) وغيرَ محسومٍ في الملف. عند مرشَّحَين لا شيء:
   * لا تُختار حزمةٌ بالترتيب، وسطرٌ معلَّق بـ{@code //} لا يُحسب تغطية أبدًا. أما غموضُ
   * استيرادَي الحزمة الباقيَين على حالهما فمبلَّغٌ في {@link #reportOnDemandAmbiguity()}.
   */
  /**
   * مُختَاراتُ الاستيرَادِ لاسمٍ بَسيطٍ (ج٤٣): إذا حُسِمَ بِمُرشَّحٍ وَاحِدٍ فهُوَ مَخرَجُهُ الوَاحِدُ
   * كَمَا كَانَ؛ وَإذَا تَزَاحَمَ مُرشَّحَانِ فَأَوضَاحُ فَكُلُّ وَاحِدٍ مَخرَجٌ بِرَأسِهِ — لا نَختَارُ
   * بِالتَّرتِيبِ ولا نَختَرِعُ بَاقَةً (قَيدُ ‏W5‏ البَاقِي)، ولكِن لا نَترُكُ المُستَخدِمَ وَحدَهُ بَينَ
   * أَسمَاءٍ لا يَعرِفُ أَيَّتَهَا عَنَى. وَمَا يَستُرُهُ استيرَادٌ صَرَاحِيٌّ آخَرُ لا يُعرَضُ: لا
   * ‏`import a.X;`‏ وَ‏`import b.X;`‏ مَعًَا — الجَاوَةُ تَرفُضُهُمَا، فَالأَولَى أن لا نَكتُبَهُمَا.
   */
  private java.util.List<QuickFix> importChoices(String name) {
    java.util.List<QuickFix> out = new ArrayList<QuickFix>();
    JavaImportResolver.Resolution resolution =
        JavaImportResolver.resolution(name, file.packageName, src);
    if (resolution.kind == JavaImportResolver.Resolution.Kind.UNIQUE) {
      if (JavaImportResolver.needsImport(src, resolution.qualifiedName))
        out.add(QuickFix.addImport(resolution.qualifiedName));
      return out;
    }
    if (resolution.kind != JavaImportResolver.Resolution.Kind.AMBIGUOUS) return out;
    for (int i = 0; i < resolution.candidates.size() && out.size() < AnalyzerProtocol.MAX_FIXES; i++) {
      String candidate = resolution.candidates.get(i);
      if (!JavaImportResolver.needsImport(src, candidate)) continue;
      out.add(QuickFix.addImport(candidate));
    }
    return out;
  }

  /**
   * ‏1.0.197: صفوفُ «لا أعرِفُ هذا الاسمَ» — استيرادٌ إن كانَ لَهُ مَوضِعٌ يُستورَدُ مِنهُ، وَإلّا
   * فَصَفٌّ يَكتُبُ الصِّنْفَ فِي باقَةِ المِلَفِّ الحَامِلِ. التَّرتِيبُ قَصدٌ: ما دامَ الاسمُ
   * مَكتُوبًا فِي حِزمَةٍ نَعرفُهَا فَالأَولَى أن نُنيرَ عَلى مَوجُودٍ مِن أن نُنشِئَ نَظِيرًا يُظَلِّلُهُ
   * وَيُثيرُ جَدَلَ الاستيرَادِ؛ وَإذَا لَم نَجِد لَهُ مَوضِعًا فَخَيارُنَا أن نَسأَلَهُ أن يَكُونَ، لا
   * أن نَسكُتَ — فَثَلاثَةٌ مِن خَمسَةِ مَوَاضِعٍ لِلجَهلِ كَانَت تُبَلِّغُ وَتَمدُّ يَدًا فَارِغَةً.
   * وَلا يَرى الفَحصُ مُجَلَّدًا، فَصِحَّةُ المَوضِعِ وَالقُدرَةُ عَلى الكِتابَةِ حَقيقَةٌ عِندَ
   * التّنفيذِ، يُخبِرُ بِها المُضيفُ رافِضًا إن لَم تَنطبِق ({@link CreateClassPlan#placedIn}).
   */
  private java.util.List<QuickFix> unknownTypeChoices(String name) {
    java.util.List<QuickFix> rows = new ArrayList<QuickFix>(importChoices(name));
    if (rows.isEmpty()) {
      QuickFix create = createClassRow(name);
      if (create != null) rows.add(create);
    }
    return rows;
  }

  /** صَفُّ «‏{@code Create class 'X'}» — إن سَاعَ الاسمُ أن يَكُونَ صِنفًا فِي باقَتِنَا وَلَم يَكُنْ بَعدُ. */
  private QuickFix createClassRow(String name) {
    if (file.packageName == null || generatedName(name)) return null;
    String pkg = file.packageName;
    // سُؤالُ الصِّنفِ لا سُؤالُ المِلَفِّ (عِبرَةُ ج٤٥): ‏knows(«com.y.Game») يَسأَلُ خَرِيطَةَ
    // المَرَاجِعِ فَإِن كَانَ المِلَفُّ مَفتُوحًا لا صِنفًا ضَلَّ الجَوابُ، فَهذَا يَكتُبُ مُضاعَفًا.
    String qualified = pkg.isEmpty() ? name : pkg + "." + name;
    return QuickFix.createType(CreateClassPlan.forSimpleName(
        pkg, name, almlk.JavaProjectModel.classByQualifiedName(qualified) != null));
  }

  /** A simple type name that resolved nowhere is proven unknown. */
  private boolean typeAbsenceCertain(String name, Scope scope) {
    if (!typesCheckable || generatedName(name) || JavaProjectModel.hasForeignSources()) return false;
    for (Import im : file.imports) {
      if (!im.onDemand) {
        if (JavaTypeModel.lastSegment(im.name).equals(name)) return false;
        continue;
      }
      if (!im.isStatic && packageFullyKnown(im.name)) continue;
      ClassSymbol owner = universe.byQualified(im.name);
      if (owner == null || !JavaTypeModel.hierarchyComplete(owner)) return false;
    }
    for (Scope x = scope; x != null; x = x.parent)
      if (x.owner != null && !JavaTypeModel.hierarchyComplete(x.owner)) return false;
    return true;
  }

  /**
   * هل «لا حقلَ بهذا الاسمِ في سلسلةِ النطاقاتِ الحاضنةِ» جَزمٌ؟ لا — متى كانَ صنفٌ حاضنٌ غيرَ
   * محسومِ السلسلةِ العلويَّةِ، أو انقطَعَت عندَ أبٍ لم نَفهَرْسِهِ: فالثابتُ قد يَكونُ مكتوبًا هناك.
   * القرينةُ هي JavaTypeModel.hierarchyCertain (اكتمالُ السلسلةِ **وانغلاقُها**)، لا hierarchyComplete
   * التي يَكتَفي بها typeAbsenceCertain على الأنواعِ وlocalOwnMemberCertain على الطرقِ: المرجعُ يَحكُمُ
   * على الطرقِ وعلى أسماءِ الحقولِ المَكتوبةِ حالةً مختلطةً ولو انقطَعَت سلسلتُها — بوَّابةُ m4/R3
   * تُثبِتُ نصَّ «Unknown method … setContentView» و«Unknown variable or field 'unknownThing'» معَ
   * أبٍ من مكتبةٍ غيرِ مَعهودةٍ — فلا نُنكِرُ عليهِ ما ثبَتَ عندَهُ؛ وأمَّا نِفيُ ثابتٍ مكتوبٍ أحرفًا
   * كبيرةً (وهو الذي يُجاوِزُ حارسَ typeAbsenceCertain) فلا يقعُ عندَنا إلّا بعدَ أن نعلَمَ أنَّ ما
   * فَوقَ الحاضنِ مَعلومٌ عن آخرِهِ، لأنَّهُ موضِعُ الشكوى: «Unknown variable or field
   * 'DATABASE_NAME'» في ملفٍّ ثابتُهُ مَوصولٌ بسلسلةٍ لم نَفهَرْسِها (ورقةُ W31 §٣٫١ و§٥).
   */
  private boolean memberAbsenceCertain(Scope scope) {
    for (Scope x = scope; x != null; x = x.parent)
      if (x.owner != null && !JavaTypeModel.hierarchyCertain(x.owner)) return false;
    return true;
  }


  /**
   * W5′: اسمٌ يوفّره استيرادا حزمةٍ باقٍ على حالة ({@code import a.*;} و{@code import b.*;}) معًا —
   * غموضٌ في «المستورد» لا في المشروع. يُبلَّغ بنصّ المرجع القائم في مواردنا
   * ({@code ui_diagnostic_ambiguous_type}: «Ambiguous imported type 'X': 'a.X' or 'b.X'») على سطر
   * الاستيراد الثاني، وبلا أيّ إصلاح: لا نختار حزمةً للناس.
   */
  private void reportOnDemandAmbiguity() {
    java.util.Set<String> used = JavaImportOrganizer.classLikeIdentifiers(src);
    if (used.isEmpty()) return;
    ArrayList<Import> onDemand = new ArrayList<>();
    for (Import im : file.imports) if (!im.isStatic && im.onDemand) onDemand.add(im);
    if (onDemand.size() < 2) return;
    for (String name : used) {
      Import firstProvider = null;
      for (Import im : onDemand) {
        if (!JavaImportResolver.provides(im.name, name)) continue;
        if (firstProvider == null) { firstProvider = im; continue; }
        error(firstProvider.nameStart, firstProvider.nameEnd, "ui_diagnostic_ambiguous_type",
            "Ambiguous imported type '%1$s': '%2$s' or '%3$s'", null,
            name, firstProvider.name + "." + name, im.name + "." + name);
        break;
      }
    }
  }

  /** No static import can provide {@code name} as a field or method. */
  private boolean staticImportsExclude(String name, boolean method) {
    for (Import im : file.imports) {
      if (!im.isStatic) continue;
      String ownerName;
      if (im.onDemand) ownerName = im.name;
      else if (JavaTypeModel.lastSegment(im.name).equals(name)) {
        int dot = im.name.lastIndexOf('.');
        ownerName = dot > 0 ? im.name.substring(0, dot) : "";
      } else continue;
      ClassSymbol owner = universe.byQualified(ownerName);
      if (owner == null) return false;
      Lookup l = JavaTypeModel.lookup(owner.thisType(), name, universe);
      if (!l.complete) return false;
      if (method ? !l.methods.isEmpty() : l.field != null) return false;
    }
    return true;
  }

  // ───────────────────────────── imports ─────────────────────────────

  private void checkImports() {
    HashMap<String, Import> singles = new HashMap<>();
    for (Import im : file.imports) {
      if (im.isStatic || im.onDemand) continue;
      String simple = JavaTypeModel.lastSegment(im.name);
      Import previous = singles.get(simple);
      if (previous == null) singles.put(simple, im);
      else if (!previous.name.equals(im.name)) {
        int at = im.segmentStarts.isEmpty() ? im.nameStart : im.segmentStarts.get(im.segmentStarts.size() - 1);
        error(at, im.nameEnd, "ui_diagnostic_already_imported",
            "A type named '%1$s' has already been imported", null, simple);
      }
    }
    if (!importsCheckable) return;
    reportOnDemandAmbiguity();
    String appPackage = LibraryClassIndex.appPackage();
    for (Import im : file.imports) {
      String name = im.name;
      String typeName = im.isStatic && !im.onDemand ? name.substring(0, Math.max(0, name.lastIndexOf('.'))) : name;
      if (typeName.isEmpty()) continue;
      if (im.onDemand && !im.isStatic) {
        if (AndroidApiIndex.isKnownPackage(typeName) || knownType(typeName)
            || isProjectPackage(typeName, appPackage)) continue;
        error(im.nameStart, im.nameEnd, "ui_diagnostic_unknown_package",
            "Unknown type or package '%1$s'", null, typeName);
        continue;
      }
      if (knownType(typeName)) {
        if (im.isStatic && !im.onDemand) checkStaticMember(im, typeName);
        continue;
      }
      int dot = typeName.lastIndexOf('.');
      if (dot <= 0) continue;
      String qualifier = typeName.substring(0, dot);
      String simple = typeName.substring(dot + 1);
      boolean projectPackage = JavaProjectModel.hasPackage(qualifier);
      if (projectPackage ? generatedName(simple) : isProjectPackage(qualifier, appPackage)) continue;
      // اليقينُ شرطٌ لا قرينةٌ (الجولةُ ‏33): «الحزمةُ معروفةٌ» تعني أنَّ مسحةً رأتْ ملفًّا واحدًا فيها،
      // لا أنَّ أصنافَها قُرِئَتْ كلَّها — فوسطَ المسحةِ الجاريةِ تكونُ دعوى «الصنفُ مجهولٌ» على استيرادٍ
      // سليمٍ من حزمةِ المشروعِ وهمًا محضًا، وهو نصفُ «مئاتِ الأخطاءِ» التي شكا منها المستخدمُ.
      if (projectPackage && !JavaProjectModel.absenceProvablyComplete()) continue;
      if (involvesProjectClass(typeName)) continue;
      int segments = typeName.split("\\.").length;
      int simpleStart = segments - 1 < im.segmentStarts.size() ? im.segmentStarts.get(segments - 1) : im.nameStart;
      int typeEnd = simpleStart + simple.length();
      boolean qualifierKnown = projectPackage || AndroidApiIndex.isKnownPackage(qualifier) || knownType(qualifier);
      if (qualifierKnown) {
        error(simpleStart, typeEnd, "ui_diagnostic_unknown_type", "Unknown type '%1$s'", null, simple);
      } else {
        String unknown = unknownPackagePrefix(qualifier);
        // حزمةُ هذا الملفِ وأجدادُها موجودونَ بحكمِ إعلانيها في نصِّه لا بحكمِ الفهرسِ: فالدعوى
        // «حزمةٌ مجهولةٌ» عليها كذبٌ دائمًا — لا سيّما في مشروعٍ لا يَحمِلُ namespace في بناءِهِ.
        if (isOwnPackagePrefix(unknown)) continue;
        error(im.nameStart, im.nameStart + unknown.length(), "ui_diagnostic_unknown_package",
            "Unknown type or package '%1$s'", null, unknown);
      }
    }
  }

  private void checkStaticMember(Import im, String typeName) {
    ClassSymbol owner = universe.byQualified(typeName);
    if (owner == null) return;
    String member = JavaTypeModel.lastSegment(im.name);
    Lookup l = JavaTypeModel.lookup(owner.thisType(), member, universe);
    if (!l.complete || l.field != null || !l.methods.isEmpty() || l.memberType != null) return;
    int at = im.segmentStarts.isEmpty() ? im.nameStart : im.segmentStarts.get(im.segmentStarts.size() - 1);
    error(at, im.nameEnd, "ui_diagnostic_unknown_static_member", "Unknown static member '%1$s'",
        null, member);
  }

  private boolean knownType(String qualified) {
    if (universe.byQualified(qualified) != null) return true;
    return PlatformMemberLookup.isPlatformName(qualified)
        && PlatformMemberLookup.resolve(qualified, null, "") != null;
  }

  private static boolean isProjectPackage(String pkg, String appPackage) {
    if (!appPackage.isEmpty() && (pkg.equals(appPackage) || pkg.startsWith(appPackage + "."))) return true;
    return JavaProjectModel.hasPackage(pkg);
  }

  /** هل هذا الاسمُ حزمةُ الملفِّ الجاري أو جدٌّ لها؟ وجودُها مُعلَنٌ في هذا النصِّ نفسِهِ. */
  private boolean isOwnPackagePrefix(String pkg) {
    String own = file == null ? null : file.packageName;
    if (own == null || own.isEmpty() || pkg == null || pkg.isEmpty()) return false;
    return own.equals(pkg) || own.startsWith(pkg + ".");
  }

  private static boolean involvesProjectClass(String typeName) {
    String[] parts = typeName.split("\\.");
    StringBuilder prefix = new StringBuilder();
    for (int i = 0; i < parts.length - 1; i++) {
      if (prefix.length() > 0) prefix.append('.');
      prefix.append(parts[i]);
      if (JavaProjectModel.classByQualifiedName(prefix.toString()) != null) return true;
    }
    return false;
  }

  private static String unknownPackagePrefix(String qualifier) {
    StringBuilder prefix = new StringBuilder();
    for (String part : qualifier.split("\\.")) {
      if (prefix.length() > 0) prefix.append('.');
      prefix.append(part);
      String p = prefix.toString();
      if (!AndroidApiIndex.isKnownPackage(p) && !JavaProjectModel.isPackagePrefix(p)) return p;
    }
    return qualifier;
  }

  // ───────────────────────────── type references ─────────────────────────────

  private Type lookupTypeVar(String name, Scope s) {
    for (Scope x = s; x != null; x = x.parent) {
      if (x.typeVars != null && x.typeVars.containsKey(name)) return x.typeVars.get(name);
      if (x.owner instanceof SourceClass) {
        SourceClass sc = (SourceClass) x.owner;
        if (sc.typeParams().contains(name)) return sc.thisType().args.get(sc.typeParams().indexOf(name));
      }
    }
    return null;
  }

  private ClassSymbol resolveSimpleType(String name, Scope s) {
    for (Scope x = s; x != null; x = x.parent) {
      if (x.types != null && x.types.containsKey(name)) return x.types.get(name);
      if (x.owner != null) {
        ClassSymbol o = x.owner;
        if (o.simpleName().equals(name) && !(o instanceof SourceClass && ((SourceClass) o).decl.anonymous))
          return o;
        ClassSymbol m = JavaTypeModel.memberTypeInherited(o, name);
        if (m != null) return m;
      }
    }
    return JavaTypeModel.resolveInFile(name, file, universe);
  }

  /** Resolves a written type, reporting the unknown part when proven. */
  private Type resolveType(TypeRef r, Scope s, boolean report) {
    lastReported = false;
    return resolveTypeInner(r, s, report);
  }

  private Type resolveTypeInner(TypeRef r, Scope s, boolean report) {
    if (r == null || r.inferred) return JavaTypeModel.UNKNOWN;
    if (r.wildcard != 0) {
      Type b = r.bound == null ? null : resolveTypeInner(r.bound, s, report);
      return new WildcardType(r.wildcard, b == null ? JavaTypeModel.UNKNOWN : b);
    }
    Type base;
    if (r.primitive != null) {
      base = JavaTypeModel.primitive(r.primitive);
    } else {
      if (r.names.isEmpty()) return JavaTypeModel.UNKNOWN;
      Type var = r.names.size() == 1 ? lookupTypeVar(r.names.get(0), s) : null;
      if (var != null) base = var;
      else {
        ClassSymbol c = resolveClassRef(r, s, report);
        List<Type> args = null;
        for (List<TypeRef> segment : r.args) {
          if (segment == null) continue;
          ArrayList<Type> resolved = new ArrayList<>();
          for (TypeRef a : segment) resolved.add(resolveTypeInner(a, s, report));
          args = resolved;
        }
        if (c == null) return JavaTypeModel.UNKNOWN;
        List<TypeRef> last = r.args.isEmpty() ? null : r.args.get(r.args.size() - 1);
        base = new ClassType(c, last == null || last.isEmpty() ? null : args);
      }
    }
    if (base == null) return JavaTypeModel.UNKNOWN;
    for (int i = 0; i < r.dims; i++) base = new ArrayType(base);
    if (r.varargs) base = new ArrayType(base);
    return base;
  }

  private ClassSymbol resolveClassRef(TypeRef r, Scope s, boolean report) {
    List<String> names = r.names;
    String first = names.get(0);
    ClassSymbol c = resolveSimpleType(first, s);
    int i = 1;
    if (c == null) {
      if (names.size() == 1) {
        if (report && typeAbsenceCertain(first, s))
          errorChoices(r.nameStarts.get(0), r.nameStarts.get(0) + first.length(),
              "ui_diagnostic_unknown_type", "Unknown type '%1$s'", unknownTypeChoices(first), first);
        return null;
      }
      for (i = 2; i <= names.size(); i++) {
        c = universe.byQualified(join(names, i));
        if (c != null) break;
      }
      if (c == null) {
        if (report && typesCheckable) {
          String pkg = join(names, names.size() - 1);
          String last = names.get(names.size() - 1);
          if (packageFullyKnown(pkg) && !packageLike(join(names, names.size())) && !generatedName(last)) {
            int at = r.nameStarts.get(names.size() - 1);
            // ‏1.0.197: باقَةٌ مَعلُومَةٌ وَصِنفٌ غَيرُ مَوجودٍ فِيهَا — إن كَانَت هِيَ باقَتَنا فَذَاكَ
            // مَكانُهُ وَحدَهُ الَّذي نَجرؤُ عَليهِ، فَلا نَكتُبُ فِي باقَةٍ عَلَمنَا بِحَجمِهَا.
            QuickFix ownRow = pkg.equals(file.packageName) ? createClassRow(last) : null;
            if (ownRow == null) {
              error(at, at + last.length(), "ui_diagnostic_unknown_type", "Unknown type '%1$s'", null, last);
            } else {
              errorChoices(at, at + last.length(), "ui_diagnostic_unknown_type", "Unknown type '%1$s'",
                  java.util.Collections.singletonList(ownRow), last);
            }
          } else if (!packageLike(first) && Character.isUpperCase(first.charAt(0))
              && typeAbsenceCertain(first, s)) {
            errorChoices(r.nameStarts.get(0), r.nameStarts.get(0) + first.length(),
                "ui_diagnostic_unknown_type", "Unknown type '%1$s'", unknownTypeChoices(first), first);
          }
        }
        return null;
      }
    }
    for (; i < names.size(); i++) {
      ClassSymbol m = JavaTypeModel.memberTypeInherited(c, names.get(i));
      if (m == null) {
        if (report && typesCheckable && JavaTypeModel.hierarchyComplete(c) && !generatedName(names.get(i))) {
          int at = r.nameStarts.get(i);
          error(at, at + names.get(i).length(), "ui_diagnostic_unknown_type", "Unknown type '%1$s'",
              null, names.get(i));
        }
        return null;
      }
      c = m;
    }
    return c;
  }

  private static String join(List<String> names, int count) {
    StringBuilder b = new StringBuilder(names.get(0));
    for (int j = 1; j < count; j++) b.append('.').append(names.get(j));
    return b.toString();
  }

  // ───────────────────────────── classes ─────────────────────────────

  private void attribClass(SourceClass c, Scope outer) {
    TypeDecl d = c.decl;
    Scope cs = new Scope(outer, c, false);
    for (TypeParam tp : d.typeParams) for (TypeRef b : tp.bounds) resolveType(b, cs, true);
    checkMemberDuplicates(d);
    if (!d.anonymous) {
      Scope header = outer == null ? new Scope(null, null, false) : outer;
      if (d.superclass != null) {
        Type st = resolveType(d.superclass, headerScope(header, c), true);
        if (d.kind == CLASS && knownClass(st) && ((ClassType) st).symbol instanceof SourceClass
            && !((ClassType) st).symbol.isInterface()
            && ((SourceClass) ((ClassType) st).symbol).decl.mods.has(FINAL))
          error(d.superclass.start, d.superclass.end, "ui_diagnostic_final_class_subclassed",
              "The final class '%1$s' can not be subclassed", null, ((ClassType) st).symbol.qualifiedName());
        if (d.kind == CLASS && knownClass(st) && ((ClassType) st).symbol.isInterface())
          error(d.superclass.start, d.superclass.end, "ui_diagnostic_class_extends_interface",
              "A class can not extend an interface", null);
      }
      for (TypeRef i : d.interfaces) {
        Type it = resolveType(i, headerScope(header, c), true);
        if (!knownClass(it) || ((ClassType) it).symbol.isInterface()) continue;
        if (d.kind == INTERFACE)
          error(i.start, i.end, "ui_diagnostic_interface_extends_class", "An interface can not extend a class", null);
        else if (d.kind == ENUM)
          error(i.start, i.end, "ui_diagnostic_enum_implements_class", "An enum can not implement a class", null);
        else if (d.kind == CLASS || d.kind == RECORD)
          error(i.start, i.end, "ui_diagnostic_class_implements_class", "A class can not implement a class", null);
      }
    }
    for (VarDecl v : d.recordComponents) resolveType(v.type, cs, true);
    // Pass 1: member signatures, so a field used before its declaration is typed already.
    for (Member m : d.members) {
      if (m instanceof FieldDecl) {
        FieldDecl f = (FieldDecl) m;
        resolveType(f.type, cs, true);
        if (lastReported) for (VarDecl v : f.vars) failedFields.add(c.qualifiedName() + "#" + v.name);
      } else if (m instanceof MethodDecl) {
        MethodDecl md = (MethodDecl) m;
        Scope sig = methodScope(cs, md);
        for (TypeParam tp : md.typeParams) for (TypeRef b : tp.bounds) resolveType(b, sig, true);
        if (md.result != null) resolveType(md.result, sig, true);
        for (TypeRef t : md.thrown) resolveType(t, sig, true);
      }
    }
    for (EnumConstant ec : d.constants) {
      Scope es = new Scope(cs, null, true);
      if (ec.args != null) for (Expr a : ec.args) attrib(a, es);
      if (ec.body != null) {
        SourceClass body = new SourceClass(ec.body, file, c, universe, new ScopeNames(es));
        body.anonymousBase = new ClassType(c, null);
        attribClass(body, es);
      }
    }
    // Pass 2: bodies and initializers in declaration order; كل عضو معزول عن أعطال غيره.
    for (Member m : d.members) {
      try {
        attribMemberBody(c, cs, m);
      } catch (RuntimeException | StackOverflowError failure) {
        isolatedFailures++;
      }
    }
  }

  private void attribMemberBody(SourceClass c, Scope cs, Member m) {
    int savedContext = returnContext, savedLoops = loopDepth, savedSwitches = switchDepth;
    String savedType = returnTypeText;
    Type savedReturnType = returnType;
    int savedExceptions = exceptionContext;
    List<ClassSymbol> savedThrows = declaredThrows;
    ArrayList<ClassSymbol> savedHandlers = handlers;
    exceptionContext = EXC_NONE;
    declaredThrows = Collections.emptyList();
    handlers = new ArrayList<>();
    returnContext = CTX_NONE;
    returnTypeText = "";
    returnType = JavaTypeModel.UNKNOWN;
    loopDepth = 0;
    switchDepth = 0;
    if (m instanceof MethodDecl) {
      MethodDecl md = (MethodDecl) m;
      if (md.constructor) returnContext = CTX_CTOR;
      else if (md.result != null && "void".equals(md.result.primitive) && md.result.dims == 0) returnContext = CTX_VOID;
      else if (md.result != null && md.result.end > md.result.start && md.result.end <= src.length()) {
        returnContext = CTX_VALUE;
        returnTypeText = src.substring(md.result.start, md.result.end).trim();
        Type rt = resolveType(md.result, methodScope(cs, md), false);
        returnType = lastReported ? JavaTypeModel.UNKNOWN : rt;
      }
    } else if (m instanceof Initializer) returnContext = CTX_INIT;
    MethodDecl savedMethod = currentMethod;
    currentMethod = m instanceof MethodDecl ? (MethodDecl) m : null;
    if (m instanceof MethodDecl) {
      MethodDecl md = (MethodDecl) m;
      ArrayList<ClassSymbol> thrown = new ArrayList<>();
      boolean known = true;
      Scope ts = md.thrown.isEmpty() ? null : methodScope(cs, md);
      for (TypeRef t : md.thrown) {
        Type x = resolveType(t, ts, false);
        if (lastReported || !knownClass(x)) known = false;
        else thrown.add(((ClassType) x).symbol);
      }
      if (known) {
        exceptionContext = EXC_METHOD;
        declaredThrows = thrown;
      }
    } else if (m instanceof Initializer && ((Initializer) m).isStatic) {
      exceptionContext = EXC_STATIC_INIT;
    }
    try {
      attribMemberBodyIn(c, cs, m);
    } finally {
      currentMethod = savedMethod;
      exceptionContext = savedExceptions;
      declaredThrows = savedThrows;
      handlers = savedHandlers;
      returnContext = savedContext;
      returnTypeText = savedType;
      returnType = savedReturnType;
      loopDepth = savedLoops;
      switchDepth = savedSwitches;
    }
  }

  private void attribMemberBodyIn(SourceClass c, Scope cs, Member m) {
    {
      if (m instanceof FieldDecl) {
        FieldDecl f = (FieldDecl) m;
        Scope fs = new Scope(cs, null, f.mods.has(STATIC) || c.isInterface());
        Type ft = f.type == null || f.type.inferred ? null : resolveType(f.type, fs, false);
        if (ft != null && lastReported) ft = null;
        for (VarDecl v : f.vars) {
          if (v.init == null) continue;
          Type it = attrib(v.init, fs);
          if (ft != null && !(v.init instanceof ArrayInit)) {
            Type target = ft;
            for (int i = 0; i < v.extraDims; i++) target = new ArrayType(target);
            checkAssignable(it, target, v.init, "ui_diagnostic_incompatible_field",
                "An instance of type '%1$s' can not be assigned to a field of type '%2$s'");
          }
        }
      } else if (m instanceof MethodDecl) {
        MethodDecl md = (MethodDecl) m;
        Scope ms = methodScope(cs, md);
        for (VarDecl p : md.params) {
          Type t = resolveType(p.type, ms, true);
          boolean failed = lastReported;
          for (int i = 0; i < p.extraDims; i++) t = new ArrayType(t);
          Var pv = new Var(p.name, t, failed);
          pv.isFinal = p.mods != null && p.mods.has(FINAL);
          declareLocal(ms, pv, p.nameStart, true);
        }
        if (md.defaultValue != null) attrib(md.defaultValue, ms);
        if (md.body != null && !md.bodySkipped) attribBlockInto(md.body, ms);
      } else if (m instanceof Initializer) {
        Initializer init = (Initializer) m;
        if (init.body != null) attribBlock(init.body, new Scope(cs, null, init.isStatic));
      } else if (m instanceof TypeDecl) {
        ClassSymbol nested = c.memberType(((TypeDecl) m).name);
        if (nested instanceof SourceClass && ((SourceClass) nested).decl == m)
          attribClass((SourceClass) nested, cs);
      }
    }
  }

  /** Supertypes see the enclosing scope plus the class's own type parameters. */
  private Scope headerScope(Scope outer, SourceClass c) {
    Scope s = new Scope(outer, null, false);
    for (TypeParam tp : c.decl.typeParams) {
      if (s.typeVars == null) s.typeVars = new HashMap<>();
      Type v = c.thisType().args.get(c.typeParams().indexOf(tp.name));
      if (v instanceof TypeVar) s.typeVars.put(tp.name, (TypeVar) v);
    }
    return s;
  }

  private Scope methodScope(Scope cs, MethodDecl md) {
    Scope ms = new Scope(cs, null, md.mods.has(STATIC));
    if (!md.typeParams.isEmpty()) {
      ms.typeVars = new HashMap<>();
      for (TypeParam tp : md.typeParams) ms.typeVars.put(tp.name, new TypeVar(tp.name, false));
      for (TypeParam tp : md.typeParams) {
        if (!tp.bounds.isEmpty()) {
          Type b = resolveType(tp.bounds.get(0), ms, false);
          ms.typeVars.get(tp.name).bound = JavaTypeModel.isUnknown(b) ? null : b;
          if (JavaTypeModel.isUnknown(b)) ms.typeVars.put(tp.name, new TypeVar(tp.name, true));
        }
      }
    }
    return ms;
  }

  // ───────────────────────────── statements ─────────────────────────────

  private void attribBlock(Block b, Scope s) {
    attribBlockInto(b, new Scope(s, null, s.isStatic));
  }

  private void attribBlockInto(Block b, Scope bs) {
    for (Stmt st : b.stmts) attribStmt(st, bs);
  }

  /**
   * عزل الأعطال على مستوى العبارة: عطل داخلي في عبارة واحدة لا يُسكت بقية الملف (كان يُسقط كل
   * تشخيصاته). متغيرات التصريح المعطوب تُعلن بنوع مجهول فلا تولّد أخطاء «Unknown variable» كاذبة.
   */
  private void attribStmt(Stmt st, Scope s) {
    if (st == null || out.size() >= MAX_FINDINGS) return;
    try {
      attribStmtChecked(st, s);
    } catch (RuntimeException | StackOverflowError failure) {
      isolatedFailures++;
      if (st instanceof LocalVars)
        for (VarDecl v : ((LocalVars) st).vars)
          if (s.vars == null || !s.vars.containsKey(v.name)) s.declare(new Var(v.name, JavaTypeModel.UNKNOWN, true));
    }
  }

  private void attribStmtChecked(Stmt st, Scope s) {
    if (st instanceof Block) attribBlock((Block) st, s);
    else if (st instanceof LocalVars) {
      LocalVars lv = (LocalVars) st;
      Type declared = lv.type != null && lv.type.inferred ? null : resolveType(lv.type, s, true);
      boolean failed = declared != null && lastReported;
      for (VarDecl v : lv.vars) {
        Type t = declared;
        lastInitType = JavaTypeModel.UNKNOWN;
        if (v.init != null) {
          Type it = attrib(v.init, s);
          lastInitType = it;
          if (t == null) t = it == JavaTypeModel.NULL ? JavaTypeModel.UNKNOWN : it;
        }
        if (t == null) t = JavaTypeModel.UNKNOWN;
        for (int i = 0; i < v.extraDims; i++) t = new ArrayType(t);
        if (declared != null && !failed && v.init != null && !(v.init instanceof ArrayInit))
          checkAssignable(lastInitType, t, v.init, "ui_diagnostic_incompatible_variable",
              "An instance of type '%1$s' can not be assigned to a variable of type '%2$s'");
        Var lvv = new Var(v.name, t, failed);
        lvv.isFinal = lv.mods != null && lv.mods.has(FINAL) && v.init != null;
        declareLocal(s, lvv, v.nameStart, false);
      }
    } else if (st instanceof LocalClass) {
      TypeDecl decl = ((LocalClass) st).decl;
      SourceClass lc = new SourceClass(decl, file, innermostClass(s), universe, new ScopeNames(s));
      if (s.types == null) s.types = new HashMap<>();
      s.types.put(decl.name, lc);
      attribClass(lc, s);
    } else if (st instanceof ExprStmt) attrib(((ExprStmt) st).expr, s);
    else if (st instanceof If) {
      If i = (If) st;
      checkCondition(i.cond, attrib(i.cond, s));
      attribStmt(i.then, new Scope(s, null, s.isStatic));
      if (i.otherwise != null) attribStmt(i.otherwise, new Scope(s, null, s.isStatic));
    } else if (st instanceof While) {
      checkCondition(((While) st).cond, attrib(((While) st).cond, s));
      loopBody(((While) st).body, new Scope(s, null, s.isStatic));
    } else if (st instanceof DoWhile) {
      loopBody(((DoWhile) st).body, new Scope(s, null, s.isStatic));
      checkCondition(((DoWhile) st).cond, attrib(((DoWhile) st).cond, s));
    } else if (st instanceof For) {
      For f = (For) st;
      Scope fs = new Scope(s, null, s.isStatic);
      for (Stmt i : f.init) attribStmt(i, fs);
      if (f.cond != null) checkCondition(f.cond, attrib(f.cond, fs));
      for (Expr u : f.update) attrib(u, fs);
      loopBody(f.body, new Scope(fs, null, s.isStatic));
    } else if (st instanceof ForEach) {
      ForEach fe = (ForEach) st;
      Type it = attrib(fe.iterable, s);
      if (!(it instanceof ArrayType) && knownNonSubtype(it, "java.lang.Iterable"))
        error(fe.iterable.start, fe.iterable.end, "ui_diagnostic_expected_collection_or_array",
            "Expected a collection or an array", null);
      Scope fs = new Scope(s, null, s.isStatic);
      Type t;
      boolean failed = false;
      if (fe.var.type == null || fe.var.type.inferred) t = JavaTypeModel.elementTypeOf(it, universe);
      else {
        t = resolveType(fe.var.type, s, true);
        failed = lastReported;
      }
      Var fv = new Var(fe.var.name, t, failed);
      fv.isFinal = fe.var.mods != null && fe.var.mods.has(FINAL);
      declareLocal(fs, fv, fe.var.nameStart, false);
      loopBody(fe.body, fs);
    } else if (st instanceof Return) {
      Return r = (Return) st;
      Type rv = r.value != null ? attrib(r.value, s) : null;
      checkReturn(r);
      if (rv != null && returnContext == CTX_VALUE)
        checkAssignable(rv, returnType, r.value, "ui_diagnostic_incompatible_return",
            "An instance of type '%1$s' can not be returned by a method of type '%2$s'");
    } else if (st instanceof Jump) {
      Jump j = (Jump) st;
      if (j.label == null && j.isBreak && loopDepth == 0 && switchDepth == 0)
        error(j.start, j.end, "ui_diagnostic_break_outside",
            "A 'break' statement must be contained in a 'do', 'while', 'for' or 'switch' statement", null);
      else if (j.label == null && !j.isBreak && loopDepth == 0)
        error(j.start, j.end, "ui_diagnostic_continue_outside",
            "A 'continue' statement must be contained in a 'do', 'while' or 'for' statement", null);
    } else if (st instanceof Throw) {
      Expr v = ((Throw) st).value;
      Type tt = attrib(v, s);
      if (v != null && knownNonSubtype(tt, "java.lang.Throwable"))
        error(v.start, v.end, "ui_diagnostic_throw_not_throwable", "Only subtypes of 'Throwable' can be thrown", null);
      else if (v instanceof NewObject) {
        Throw savedThrow = currentThrow;
        currentThrow = (Throw) st;
        try {
          checkUncaught(tt, v);
        } finally {
          currentThrow = savedThrow;
        }
      }
    }
    else if (st instanceof Yield) attrib(((Yield) st).value, s);
    else if (st instanceof Assert) {
      checkCondition(((Assert) st).cond, attrib(((Assert) st).cond, s));
      if (((Assert) st).message != null) attrib(((Assert) st).message, s);
    } else if (st instanceof Synchronized) {
      attrib(((Synchronized) st).lock, s);
      attribBlock(((Synchronized) st).body, s);
    } else if (st instanceof Labeled) attribStmt(((Labeled) st).body, s);
    else if (st instanceof Try) attribTry((Try) st, s);
    else if (st instanceof Switch) {
      Switch sw = (Switch) st;
      Type sel = attrib(sw.selector, s);
      switchDepth++;
      try {
        attribCases(sw.cases, sel, s);
      } finally {
        switchDepth--;
      }
    }
  }

  private void loopBody(Stmt body, Scope s) {
    loopDepth++;
    try {
      attribStmt(body, s);
    } finally {
      loopDepth--;
    }
  }

  /** dd$a: the return statement against the enclosing body's kind. */
  private void checkReturn(Return r) {
    if (r.value != null) {
      if (returnContext == CTX_VOID)
        error(r.value.start, r.value.end, "ui_diagnostic_void_method_returns_value",
            "A void method can not return a value", null);
      else if (returnContext == CTX_CTOR)
        error(r.value.start, r.value.end, "ui_diagnostic_constructor_returns_value",
            "A constructor can not return a value", null);
    } else if (returnContext == CTX_VALUE && !returnTypeText.isEmpty()) {
      error(r.start, Math.min(src.length(), r.start + 6), "ui_diagnostic_method_must_return_value",
          "This method must return a value of type '%1$s'", null, returnTypeText);
    }
    if (returnContext == CTX_INIT)
      error(r.start, Math.min(src.length(), r.start + 6), "ui_diagnostic_initializer_returns",
          "An initializer may not contain a return statement", null);
  }

  /** dd$a: a condition must be boolean (judged only on a certainly known type). */
  private void checkCondition(Expr cond, Type t) {
    if (cond == null) return;
    if ((t instanceof Primitive && t != JavaTypeModel.BOOLEAN) || isString(t))
      error(cond.start, cond.end, "ui_diagnostic_condition_not_boolean",
          "A condition must be of type 'boolean'", null);
  }

  /** An index or array size: int-convertible types only. */
  private void checkIntIndex(Expr e, Type t, boolean size) {
    if (e == null) return;
    if (t == JavaTypeModel.BOOLEAN || t == JavaTypeModel.LONG || t == JavaTypeModel.FLOAT
        || t == JavaTypeModel.DOUBLE || isString(t)) {
      if (size)
        error(e.start, e.end, "ui_diagnostic_array_size_not_int", "An array size must be of type 'int'", null);
      else
        error(e.start, e.end, "ui_diagnostic_index_not_int", "An index must be of type 'int'", null);
    }
  }

  // ── R4b: compatibility, operators, final, duplicates ──

  /** Declares a local, reporting a name already used by a local or parameter of the same body. */
  private void declareLocal(Scope s, Var v, int nameStart, boolean parameter) {
    if (v.name != null && !v.name.isEmpty() && !v.name.equals("_")) {
      for (Scope x = s; x != null && x.owner == null; x = x.parent) {
        if (x.vars != null && x.vars.containsKey(v.name)) {
          int end = Math.min(src.length(), nameStart + v.name.length());
          if (nameStart >= 0 && end > nameStart && src.startsWith(v.name, nameStart)) {
            if (parameter)
              error(nameStart, end, "ui_diagnostic_duplicate_parameter", "There already is another parameter named '%1$s'", null, v.name);
            else
              error(nameStart, end, "ui_diagnostic_duplicate_variable", "There already is another variable named '%1$s'", null, v.name);
          }
          break;
        }
      }
    }
    s.declare(v);
  }

  /** 1 = local variable, 2 = field, 0 = other (array element, unknown). */
  private int targetKind(Expr target, Scope s) {
    while (target instanceof Paren) target = ((Paren) target).inner;
    if (target instanceof Name) {
      NameHit hit = lookupVariable(((Name) target).id, s);
      if (hit.local != null) return hit.local.typeFailed ? 0 : 1;
      return hit.field != null ? 2 : 0;
    }
    if (target instanceof Select) return 2;
    return 0;
  }

  /** Reports writes to final variables/fields and to an array's length; false when one was reported. */
  private boolean checkWritable(Expr target, Scope s) {
    while (target instanceof Paren) target = ((Paren) target).inner;
    if (target instanceof Name) {
      String name = ((Name) target).id;
      NameHit hit = lookupVariable(name, s);
      if (hit.local != null) {
        if (hit.local.isFinal) {
          error(target.start, target.end, "ui_diagnostic_final_variable_modified",
              "This variable is final and can not be modified", null);
          return false;
        }
        return true;
      }
      if (hit.field != null && finalWithValue(hit.field)) {
        error(target.start, target.end, "ui_diagnostic_final_field_modified", "This field is final and can not be modified", null);
        return false;
      }
      return true;
    }
    if (target instanceof Select) {
      Select sel = (Select) target;
      if (sel.target instanceof This && ((This) sel.target).qualifier == null) {
        ClassSymbol c = innermostClass(s);
        if (c != null) {
          Lookup l = JavaTypeModel.lookup(c.thisType(), sel.name, universe);
          if (l.field != null && finalWithValue(l.field)) {
            error(target.start, target.end, "ui_diagnostic_final_field_modified", "This field is final and can not be modified", null);
            return false;
          }
        }
      } else if ("length".equals(sel.name) && !(sel.target instanceof This) && !(sel.target instanceof Super)) {
        Meaning m = qualifier(sel.target, s);
        if (m.kind == VALUE && m.type instanceof ArrayType) {
          error(target.start, target.end, "ui_diagnostic_array_length_modified", "The length of an array can not be modified", null);
          return false;
        }
      }
    }
    return true;
  }

  /** A project field declared final with an initializer, or any interface field. */
  private static boolean finalWithValue(FieldSymbol f) {
    if (!(f.owner instanceof SourceClass)) return false;
    TypeDecl d = ((SourceClass) f.owner).decl;
    for (Member m : d.members) {
      if (!(m instanceof FieldDecl)) continue;
      FieldDecl fd = (FieldDecl) m;
      for (VarDecl v : fd.vars) {
        if (!v.name.equals(f.name)) continue;
        if (d.kind == INTERFACE || d.kind == ANNOTATION) return true;
        return fd.mods != null && fd.mods.has(FINAL) && v.init != null;
      }
    }
    return false;
  }

  private static int widthRank(Primitive p) {
    if (p == JavaTypeModel.BYTE) return 1;
    if (p == JavaTypeModel.SHORT || p == JavaTypeModel.CHAR) return 2;
    if (p == JavaTypeModel.INT) return 3;
    if (p == JavaTypeModel.LONG) return 4;
    if (p == JavaTypeModel.FLOAT) return 5;
    if (p == JavaTypeModel.DOUBLE) return 6;
    return 0;
  }

  /** Identity or widening primitive conversion (JLS 5.1.2). */
  private static boolean widens(Primitive from, Primitive to) {
    if (from == to) return true;
    if (!from.isNumeric() || !to.isNumeric()) return false;
    if (to == JavaTypeModel.CHAR) return false;
    if (from == JavaTypeModel.CHAR) return widthRank(to) >= 3;
    if (to == JavaTypeModel.SHORT) return from == JavaTypeModel.BYTE;
    return widthRank(from) < widthRank(to);
  }

  private static boolean isBox(Type t) {
    return t instanceof ClassType && unboxed(t) != null;
  }

  private static boolean isWide(Primitive p) {
    return p == JavaTypeModel.LONG || p == JavaTypeModel.FLOAT || p == JavaTypeModel.DOUBLE;
  }

  /** True only for conversions that are certainly illegal (constants and references aside). */
  private boolean certainlyIncompatible(Type v, Type t) {
    if (v == null || t == null || v == JavaTypeModel.VOID || t == JavaTypeModel.VOID) return false;
    boolean vPrim = v instanceof Primitive, vStr = isString(v), vArr = v instanceof ArrayType, vBox = isBox(v);
    if (!vPrim && !vStr && !vArr && !vBox) return false;
    if (t instanceof Primitive) {
      Primitive tp = (Primitive) t;
      if (vStr || vArr) return true;
      Primitive vp = unboxed(v);
      if ((vp == JavaTypeModel.BOOLEAN) != (tp == JavaTypeModel.BOOLEAN)) return true;
      if (vp == JavaTypeModel.BOOLEAN) return false;
      if (vBox) return !widens(vp, tp);
      return isWide(vp) && !widens(vp, tp);
    }
    if (isString(t)) return vPrim || vBox || vArr;
    if (t instanceof ArrayType) return vPrim || vBox || vStr;
    if (isBox(t)) {
      Primitive bt = unboxed(t);
      if (vStr || vArr) return true;
      Primitive vp = unboxed(v);
      if ((vp == JavaTypeModel.BOOLEAN) != (bt == JavaTypeModel.BOOLEAN)) return true;
      if (vBox) return vp != bt;
      return isWide(vp) && vp != bt;
    }
    return false;
  }

  private void checkAssignable(Type v, Type t, Expr at, String key, String fallback) {
    if (at == null || !certainlyIncompatible(v, t)) return;
    error(at.start, at.end, key, fallback, null, v.display(), t.display());
  }

  private static boolean integral(Primitive p) {
    return p != null && p.isNumeric() && p != JavaTypeModel.FLOAT && p != JavaTypeModel.DOUBLE;
  }

  /** False only when the operator certainly does not apply to these operand types. */
  private boolean binaryApplies(String op, Type l, Type r) {
    boolean ls = isString(l), rs = isString(r);
    Primitive pl = ls ? null : unboxed(l), pr = rs ? null : unboxed(r);
    if ((!ls && pl == null) || (!rs && pr == null)) return true;
    if (pl == JavaTypeModel.VOID || pr == JavaTypeModel.VOID) return true;
    switch (op) {
      case "+":
        return ls || rs || (pl.isNumeric() && pr.isNumeric());
      case "-":
      case "*":
      case "/":
      case "%":
      case "<":
      case ">":
      case "<=":
      case ">=":
        return pl != null && pr != null && pl.isNumeric() && pr.isNumeric();
      case "<<":
      case ">>":
      case ">>>":
        return integral(pl) && integral(pr);
      case "&":
      case "|":
      case "^":
        return pl != null && pr != null
            && ((pl == JavaTypeModel.BOOLEAN && pr == JavaTypeModel.BOOLEAN) || (integral(pl) && integral(pr)));
      case "&&":
      case "||":
        return pl == JavaTypeModel.BOOLEAN && pr == JavaTypeModel.BOOLEAN;
      case "==":
      case "!=":
        if (ls && rs) return true;
        if (ls || rs) return isBox(ls ? r : l); // String vs primitive: never comparable
        return (pl == JavaTypeModel.BOOLEAN) == (pr == JavaTypeModel.BOOLEAN);
      default:
        return true;
    }
  }

  private boolean unaryApplies(String op, Type t) {
    boolean str = isString(t);
    Primitive p = str ? null : unboxed(t);
    if (!str && (p == null || p == JavaTypeModel.VOID)) return true;
    switch (op) {
      case "!":
        return p == JavaTypeModel.BOOLEAN;
      case "-":
      case "+":
      case "++":
      case "--":
        return p != null && p.isNumeric();
      case "~":
        return integral(p);
      default:
        return true;
    }
  }

  /** Duplicate fields, methods and constructors of one class body. */
  private void checkMemberDuplicates(TypeDecl d) {
    HashSet<String> fields = new HashSet<>();
    for (EnumConstant ec : d.constants) if (ec.name != null) fields.add(ec.name);
    HashSet<String> methods = new HashSet<>();
    for (Member m : d.members) {
      if (m instanceof FieldDecl) {
        for (VarDecl v : ((FieldDecl) m).vars) {
          if (v.name.isEmpty() || fields.add(v.name)) continue;
          if (src.startsWith(v.name, v.nameStart))
            error(v.nameStart, v.nameStart + v.name.length(), "ui_diagnostic_duplicate_field",
                "There already is another field named '%1$s'", null, v.name);
        }
      } else if (m instanceof MethodDecl) {
        MethodDecl md = (MethodDecl) m;
        String key = signatureKey(md);
        if (key == null || methods.add(key)) continue;
        int end = md.nameStart + md.name.length();
        if (md.name.isEmpty() || !src.startsWith(md.name, md.nameStart)) continue;
        if (md.constructor)
          error(md.nameStart, end, "ui_diagnostic_duplicate_constructor",
              "There already is another constructor with the same signature", null);
        else
          error(md.nameStart, end, "ui_diagnostic_duplicate_method",
              "There already is another method with the same signature", null);
      }
    }
  }

  private String signatureKey(MethodDecl md) {
    StringBuilder b = new StringBuilder(md.constructor ? "<init>" : md.name).append('(');
    for (VarDecl p : md.params) {
      if (p.type == null || p.type.end <= p.type.start || p.type.end > src.length()) return null;
      String t = src.substring(p.type.start, p.type.end).replaceAll("\\s+", "").replace("...", "[]");
      if (t.contains("@")) return null;
      b.append(t);
      for (int i = 0; i < p.extraDims; i++) b.append("[]");
      if (p.type.varargs && !t.endsWith("[]")) b.append("[]");
      b.append(',');
    }
    return b.append(')').toString();
  }

  /** A class type that resolved to a real entity (not an error entity). */
  /** R6: identical, fully known, non-generic types (a primitive or a plain class). */
  private static boolean sameExactType(Type o, Type t) {
    if (o == null || t == null || o == JavaTypeModel.UNKNOWN || o == JavaTypeModel.NULL) return false;
    if (o instanceof Primitive && t instanceof Primitive)
      return o != JavaTypeModel.VOID && ((Primitive) o).name.equals(((Primitive) t).name);
    if (!knownClass(o) || !knownClass(t)) return false;
    ClassType a = (ClassType) o, b = (ClassType) t;
    return a.symbol == b.symbol && a.args.isEmpty() && b.args.isEmpty() && a.symbol.typeParams().isEmpty();
  }

  /**
   * True when a primitive operand's type rests on overload resolution (a call, a conditional…):
   * an overload picked with an unknown argument could give the wrong numeric type.
   */
  private static boolean involvesCall(Expr e) {
    if (e == null || e instanceof Name || e instanceof Literal || e instanceof This) return false;
    if (e instanceof Paren) return involvesCall(((Paren) e).inner);
    if (e instanceof Select) return involvesCall(((Select) e).target);
    if (e instanceof Unary) return involvesCall(((Unary) e).operand);
    if (e instanceof Binary) return involvesCall(((Binary) e).left) || involvesCall(((Binary) e).right);
    if (e instanceof Index) return involvesCall(((Index) e).array) || involvesCall(((Index) e).index);
    if (e instanceof Cast) return involvesCall(((Cast) e).operand);
    return true;
  }

  /** R6 (Id): {@code x = x}, {@code this.x = this.x}, or {@code this.x = x} with no local {@code x}. */
  private boolean assignsItself(Expr target, Expr value, Scope s) {
    while (target instanceof Paren) target = ((Paren) target).inner;
    while (value instanceof Paren) value = ((Paren) value).inner;
    String a = selfName(target), b = selfName(value);
    if (a == null || !a.equals(b)) return false;
    boolean qa = target instanceof Select, qb = value instanceof Select;
    if (qa == qb) return true;
    // one side is this.x: the plain x must be that same field of the innermost class
    NameHit hit = lookupVariable(a, s);
    if (hit.local != null || hit.field == null || hit.uncertain) return false;
    for (Scope x = s; x != null; x = x.parent)
      if (x.owner != null) return hit.fieldClass == x.owner;
    return false;
  }

  /** {@code x} for a simple name or {@code this.x} (unqualified this); null otherwise. */
  private static String selfName(Expr e) {
    if (e instanceof Name) return ((Name) e).id;
    if (e instanceof Select) {
      Select sel = (Select) e;
      if (sel.target instanceof This && ((This) sel.target).qualifier == null) return sel.name;
    }
    return null;
  }

  private static boolean knownClass(Type t) {
    return t instanceof ClassType && !((ClassType) t).symbol.isError();
  }

  /** True when {@code t} certainly is not a subtype of {@code qualified} (whole hierarchy known). */
  private static boolean knownNonSubtype(Type t, String qualified) {
    if (t instanceof Primitive) return t != JavaTypeModel.VOID;
    if (!(t instanceof ClassType)) return false;
    ClassSymbol c = ((ClassType) t).symbol;
    if (c.isError() || !fullyKnown(c)) return false;
    return !JavaTypeModel.isSubclass(c, qualified);
  }

  private static boolean fullyKnown(ClassSymbol c) {
    java.util.ArrayDeque<ClassSymbol> queue = new java.util.ArrayDeque<>();
    java.util.HashSet<ClassSymbol> seen = new java.util.HashSet<>();
    queue.add(c);
    while (!queue.isEmpty()) {
      ClassSymbol x = queue.poll();
      if (!seen.add(x)) continue;
      if (seen.size() > 96 || x.isError() || !x.reliable() || !x.supertypesResolved()) return false;
      ClassType sup = x.superclass();
      if (sup != null) queue.add(sup.symbol);
      for (ClassType i : x.interfaces()) queue.add(i.symbol);
    }
    return true;
  }

  /** wd: a certainly checked exception that no enclosing catch and no throws clause covers. */
  private void checkUncaught(Type t, Expr at) {
    if (exceptionContext == EXC_NONE || !knownClass(t)) return;
    ClassSymbol c = ((ClassType) t).symbol;
    if (!fullyKnown(c) || !JavaTypeModel.isSubclass(c, "java.lang.Throwable")
        || JavaTypeModel.isSubclass(c, "java.lang.RuntimeException") || JavaTypeModel.isSubclass(c, "java.lang.Error"))
      return;
    for (ClassSymbol h : handlers) if (h == null || JavaTypeModel.isSubclass(c, h.qualifiedName())) return;
    int before = out.size();
    String name = at instanceof NewObject && ((NewObject) at).type != null ? typeText(((NewObject) at).type) : null;
    if (exceptionContext == EXC_METHOD) {
      for (ClassSymbol d : declaredThrows) if (JavaTypeModel.isSubclass(c, d.qualifiedName())) return;
      error(at.start, at.end, "ui_diagnostic_exception_must_be_caught_or_declared",
          "The exception '%1$s' must be caught or declared in the throws clause", null, t.display());
    } else {
      error(at.start, at.end, "ui_diagnostic_exception_must_be_caught", "The exception '%1$s' must be caught", null,
          t.display());
    }
    if (out.size() == before || name == null) return;
    ArrayList<QuickFix> fixes = new ArrayList<>();
    if (exceptionContext == EXC_METHOD && currentMethod != null) {
      QuickFix f = throwsFix(currentMethod, name);
      if (f != null) fixes.add(f);
    }
    QuickFix f = tryCatchFix(currentThrow, name);
    if (f != null) fixes.add(f);
    if (!fixes.isEmpty()) out.set(out.size() - 1, out.get(out.size() - 1).withQuickFixes(fixes));
  }

  /** Source text of a type reference, or null when it is not a plain slice of the file. */
  private String typeText(TypeRef r) {
    if (r == null || r.start < 0 || r.end > src.length() || r.end <= r.start) return null;
    String text = src.substring(r.start, r.end).trim();
    return text.isEmpty() || text.indexOf('\n') >= 0 ? null : text;
  }

  /** wd's "Add throws clause": {@code throws X} after the parameters, or {@code , X} after the list. */
  private QuickFix throwsFix(MethodDecl md, String name) {
    if (md.body == null || md.body.start <= 0 || md.body.start > src.length()) return null;
    if (!md.thrown.isEmpty()) {
      TypeRef last = md.thrown.get(md.thrown.size() - 1);
      if (last.end <= 0 || last.end > md.body.start) return null;
      return QuickFix.insertText(src, last.end, ", " + name, "ui_quick_fix_add_throws", name);
    }
    int i = md.body.start - 1;
    while (i > 0 && Character.isWhitespace(src.charAt(i))) i--;
    if (src.charAt(i) != ')') return null;
    return QuickFix.insertText(src, i + 1, " throws " + name, "ui_quick_fix_add_throws", name);
  }

  /** wd's "Surround with try/catch" around the throw statement. */
  private QuickFix tryCatchFix(Throw st, String name) {
    if (st == null || st.start < 0 || st.end > src.length() || st.end <= st.start) return null;
    int ls = st.start;
    while (ls > 0 && src.charAt(ls - 1) != '\n') ls--;
    String indent = src.substring(ls, st.start);
    if (!indent.trim().isEmpty()) return null; // the statement does not start its own line
    // one indentation step of this file: the statement's indent beyond its method's line
    String unit = "    ";
    String var = "e";
    if (currentMethod != null && currentMethod.start >= 0 && currentMethod.end <= src.length()) {
      int ms = currentMethod.start;
      while (ms > 0 && src.charAt(ms - 1) != '\n') ms--;
      int me = ms;
      while (me < src.length() && (src.charAt(me) == ' ' || src.charAt(me) == '\t')) me++;
      String methodIndent = src.substring(ms, me);
      if (indent.startsWith(methodIndent) && indent.length() > methodIndent.length())
        unit = indent.substring(methodIndent.length());
      if (java.util.regex.Pattern.compile("\\be\\b").matcher(src.substring(currentMethod.start, currentMethod.end)).find())
        var = "ex";
    }
    String text = "try {\n" + indent + unit + src.substring(st.start, st.end) + "\n" + indent + "} catch ("
        + name + " " + var + ") {\n" + indent + unit + var + ".printStackTrace();\n" + indent + "}";
    return QuickFix.replaceText(src, st.start, st.end, text, "ui_quick_fix_surround_try", name);
  }

  private void attribTry(Try t, Scope s) {
    int handlerMark = handlers.size();
    for (Catch c : t.catches) {
      for (TypeRef r : c.types) {
        Type x = resolveType(r, s, false);
        handlers.add(lastReported || !knownClass(x) ? null : ((ClassType) x).symbol);
      }
    }
    try {
      attribTryBody(t, s);
    } finally {
      while (handlers.size() > handlerMark) handlers.remove(handlers.size() - 1);
    }
    attribCatches(t, s);
  }

  private void attribTryBody(Try t, Scope s) {
    Scope rs = new Scope(s, null, s.isStatic);
    for (Node r : t.resources) {
      if (r instanceof VarDecl) {
        VarDecl v = (VarDecl) r;
        Type declared = v.type != null && v.type.inferred ? null : resolveType(v.type, rs, true);
        boolean failed = declared != null && lastReported;
        Type it = v.init == null ? JavaTypeModel.UNKNOWN : attrib(v.init, rs);
        declareLocal(rs, new Var(v.name, declared == null ? it : declared, failed), v.nameStart, false);
      } else if (r instanceof Expr) attrib((Expr) r, rs);
    }
    if (t.body != null) attribBlock(t.body, rs);
  }

  private void attribCatches(Try t, Scope s) {
    ArrayList<ClassSymbol> earlier = new ArrayList<>();
    for (Catch c : t.catches) {
      ArrayList<ClassSymbol> mine = new ArrayList<>();
      Scope cs = new Scope(s, null, s.isStatic);
      Type ct = JavaTypeModel.UNKNOWN;
      boolean failed = false;
      for (TypeRef r : c.types) {
        Type x = resolveType(r, s, true);
        failed |= lastReported;
        if (!lastReported && knownNonSubtype(x, "java.lang.Throwable"))
          error(r.start, r.end, "ui_diagnostic_catch_not_throwable", "Only subtypes of 'Throwable' can be caught", null);
        else if (!lastReported && knownClass(x) && fullyKnown(((ClassType) x).symbol)) {
          ClassSymbol xs = ((ClassType) x).symbol;
          for (ClassSymbol e : earlier) {
            if (JavaTypeModel.isSubclass(xs, e.qualifiedName())) {
              QuickFix remove = c.types.size() == 1
                  && (t.catches.size() > 1 || t.fin != null || !t.resources.isEmpty())
                  && c.start >= 0 && c.end <= src.length() && src.startsWith("catch", c.start)
                  ? QuickFix.deleteText(src, c.start, c.end, "ui_quick_fix_remove_catch") : null;
              error(r.start, r.end, "ui_diagnostic_exception_already_caught",
                  "The exception '%1$s' has already been caught", remove, x.display());
              break;
            }
          }
          mine.add(xs);
        }
        if (c.types.size() == 1) ct = x;
      }
      if (c.types.size() > 1) {
        ClassSymbol thr = universe.byQualified("java.lang.Throwable");
        ct = thr == null ? JavaTypeModel.UNKNOWN : new ClassType(thr, null);
      }
      Var cv = new Var(c.name, ct, failed && c.types.size() == 1);
      cv.isFinal = c.mods != null && c.mods.has(FINAL);
      declareLocal(cs, cv, c.nameStart, false);
      if (c.body != null) attribBlockInto(c.body, cs);
      earlier.addAll(mine);
    }
    if (t.fin != null) attribBlock(t.fin, s);
  }

  private void attribCases(List<Case> cases, Type selector, Scope s) {
    Scope shared = new Scope(s, null, s.isStatic);
    java.util.HashSet<String> seenLabels = new java.util.HashSet<>();
    boolean seenDefault = false;
    for (Case c : cases) {
      Scope cs = c.arrow ? new Scope(s, null, s.isStatic) : shared;
      if (c.isDefault) {
        if (seenDefault) {
          int at = src.indexOf("default", c.start);
          if (at < 0 || at > c.end) at = c.start;
          error(at, Math.min(src.length(), at + 7), "ui_diagnostic_duplicate_default", "Duplicate default case", null);
        }
        seenDefault = true;
      }
      for (Expr label : c.labels) {
        if (!(label instanceof Pattern) && label.end > label.start && label.end <= src.length()) {
          String text = src.substring(label.start, label.end).trim().replaceAll("\\s+", "");
          if (!text.isEmpty() && !text.equals("null") && !seenLabels.add(text))
            error(label.start, label.end, "ui_diagnostic_duplicate_case", "Duplicate case '%1$s'", null,
                src.substring(label.start, label.end).trim());
        }
        if (label instanceof Pattern) declarePattern((Pattern) label, cs);
        else if (label instanceof Name) continue; // enum constant or constant name
        else attrib(label, cs);
      }
      if (c.guard != null) attrib(c.guard, cs);
      for (Stmt st : c.body) attribStmt(st, cs);
    }
  }

  private void declarePattern(Pattern p, Scope s) {
    Type t = p.type == null || p.type.inferred ? JavaTypeModel.UNKNOWN : resolveType(p.type, s, true);
    boolean failed = lastReported;
    if (p.nested != null) for (Pattern n : p.nested) declarePattern(n, s);
    if (p.binding != null) s.declare(new Var(p.binding, t, failed));
  }

  // ───────────────────────────── names ─────────────────────────────

  private static final class NameHit {
    Var local;
    FieldSymbol field;
    Map<String, Type> env = Collections.emptyMap();
    ClassSymbol fieldClass;
    boolean uncertain;
  }

  private NameHit lookupVariable(String name, Scope s) {
    NameHit hit = new NameHit();
    for (Scope x = s; x != null; x = x.parent) {
      if (x.vars != null) {
        Var v = x.vars.get(name);
        if (v != null) {
          hit.local = v;
          return hit;
        }
      }
      if (x.owner != null) {
        Lookup l = JavaTypeModel.lookup(x.owner.thisType(), name, universe);
        if (l.field != null) {
          hit.field = l.field;
          hit.env = l.fieldEnv;
          hit.fieldClass = x.owner;
          return hit;
        }
        if (!l.complete) hit.uncertain = true;
      }
    }
    for (Import im : file.imports) {
      if (!im.isStatic) continue;
      String ownerName;
      if (im.onDemand) ownerName = im.name;
      else if (JavaTypeModel.lastSegment(im.name).equals(name)) {
        int dot = im.name.lastIndexOf('.');
        ownerName = dot > 0 ? im.name.substring(0, dot) : "";
      } else continue;
      ClassSymbol owner = universe.byQualified(ownerName);
      if (owner == null) {
        hit.uncertain = true;
        continue;
      }
      Lookup l = JavaTypeModel.lookup(owner.thisType(), name, universe);
      if (l.field != null) {
        hit.field = l.field;
        hit.env = l.fieldEnv;
        hit.fieldClass = owner;
        return hit;
      }
      if (!l.complete) hit.uncertain = true;
    }
    return hit;
  }

  private Type typeOfHit(NameHit hit) {
    if (hit.local != null) return hit.local.type;
    if (hit.field != null) {
      if (hit.uncertain) return JavaTypeModel.UNKNOWN;
      return JavaTypeModel.subst(hit.field.type, hit.env);
    }
    return JavaTypeModel.UNKNOWN;
  }

  private boolean failedType(NameHit hit) {
    if (hit.local != null) return hit.local.typeFailed;
    return hit.field != null
        && failedFields.contains(hit.field.owner.qualifiedName() + "#" + hit.field.name);
  }

  private static final int VALUE = 0;
  private static final int TYPE = 1;
  private static final int PACKAGE = 2;
  private static final int NOTHING = 3;

  private static final class Meaning {
    final int kind;
    final Type type;
    final ClassSymbol cls;
    final String pkg;

    Meaning(int kind, Type type, ClassSymbol cls, String pkg) {
      this.kind = kind;
      this.type = type;
      this.cls = cls;
      this.pkg = pkg;
    }
  }

  private static final Meaning NO_MEANING = new Meaning(NOTHING, JavaTypeModel.UNKNOWN, null, null);

  private static Meaning value(Type t) {
    return new Meaning(VALUE, t == null ? JavaTypeModel.UNKNOWN : t, null, null);
  }

  /** Classifies an expression used as a qualifier: value, type, package or nothing (JLS 6.5.2). */
  private Meaning qualifier(Expr e, Scope s) {
    if (e instanceof Name) {
      String id = ((Name) e).id;
      NameHit hit = lookupVariable(id, s);
      if (hit.local != null || hit.field != null) {
        if (failedType(hit)) {
          boolean field = hit.local == null;
          error(e.start, e.end, field ? "ui_diagnostic_unknown_type_of_field" : "ui_diagnostic_unknown_type_of_variable",
              field ? "Unknown type of field '%1$s'" : "Unknown type of variable '%1$s'", null, id);
          return NO_MEANING;
        }
        return value(typeOfHit(hit));
      }
      ClassSymbol c = resolveSimpleType(id, s);
      if (c != null) return new Meaning(TYPE, null, c, null);
      if (packageLike(id)) return new Meaning(PACKAGE, null, null, id);
      if (!hit.uncertain && staticImportsExclude(id, false) && typeAbsenceCertain(id, s)
          && (Character.isUpperCase(id.charAt(0)) || librariesComplete))
        errorChoices(e.start, e.end, "ui_diagnostic_unknown_entity", "Unknown entity '%1$s'",
            importChoices(id), id);
      return NO_MEANING;
    }
    if (e instanceof Select) {
      Select sel = (Select) e;
      if (sel.name.isEmpty()) return NO_MEANING;
      if (sel.target instanceof Super) return value(selectOnSuper((Super) sel.target, sel, s));
      Meaning m = qualifier(sel.target, s);
      switch (m.kind) {
        case PACKAGE: {
          String qn = m.pkg + "." + sel.name;
          ClassSymbol c = universe.byQualified(qn);
          if (c != null) return new Meaning(TYPE, null, c, null);
          if (packageLike(qn)) return new Meaning(PACKAGE, null, null, qn);
          if (typesCheckable && packageFullyKnown(m.pkg) && !generatedName(sel.name))
            error(sel.nameStart, sel.end, "ui_diagnostic_unknown_entity", "Unknown entity '%1$s'", null, qn);
          return NO_MEANING;
        }
        case TYPE: {
          Lookup l = JavaTypeModel.lookup(m.cls.thisType(), sel.name, universe);
          if (l.field != null) return value(JavaTypeModel.subst(l.field.type, l.fieldEnv));
          if (l.memberType != null) return new Meaning(TYPE, null, l.memberType, null);
          ClassSymbol inherited = JavaTypeModel.memberTypeInherited(m.cls, sel.name);
          if (inherited != null) return new Meaning(TYPE, null, inherited, null);
          if (l.complete)
            error(sel.nameStart, sel.end, "ui_diagnostic_unknown_field", "Unknown field '%1$s' of '%2$s'",
                null, sel.name, m.cls.qualifiedName());
          return NO_MEANING;
        }
        case VALUE:
          return value(fieldOf(m.type, sel, true));
        default:
          return NO_MEANING;
      }
    }
    return value(attrib(e, s));
  }

  /** {@code receiver.name} where receiver is a value. */
  private Type fieldOf(Type receiverType, Select sel, boolean report) {
    Type r = JavaTypeModel.receiverOf(receiverType, universe);
    if (r instanceof ArrayType) {
      // The reference's built-in array class: 'length' is its only field (Object has none).
      if (sel.name.equals("length")) return JavaTypeModel.INT;
      if (report && !(((ArrayType) r).element == JavaTypeModel.UNKNOWN))
        error(sel.nameStart, sel.end, "ui_diagnostic_unknown_field", "Unknown field '%1$s' of '%2$s'",
            null, sel.name, r.display());
      return JavaTypeModel.UNKNOWN;
    }
    if (!(r instanceof ClassType)) return JavaTypeModel.UNKNOWN;
    ClassType ct = (ClassType) r;
    Lookup l = JavaTypeModel.lookup(ct, sel.name, universe);
    if (l.field != null) return JavaTypeModel.subst(l.field.type, l.fieldEnv);
    if (report && l.complete && l.memberType == null)
      error(sel.nameStart, sel.end, "ui_diagnostic_unknown_field", "Unknown field '%1$s' of '%2$s'",
          null, sel.name, ct.symbol.qualifiedName());
    return JavaTypeModel.UNKNOWN;
  }

  private Type selectOnSuper(Super sup, Select sel, Scope s) {
    ClassType base = superTypeOf(sup, s);
    if (base == null) return JavaTypeModel.UNKNOWN;
    return fieldOf(base, sel, true);
  }

  private ClassType superTypeOf(Super sup, Scope s) {
    if (sup.qualifier != null) return null; // Outer.super / Iface.super: not judged
    ClassSymbol c = innermostClass(s);
    return c == null ? null : c.superclass();
  }

  private ClassSymbol innermostClass(Scope s) {
    for (Scope x = s; x != null; x = x.parent) if (x.owner != null) return x.owner;
    return null;
  }

  private SourceClass innermostNamedClass(Scope s) {
    for (Scope x = s; x != null; x = x.parent)
      if (x.owner instanceof SourceClass && !((SourceClass) x.owner).decl.anonymous) return (SourceClass) x.owner;
    return null;
  }

  private boolean staticContext(Scope s, ClassSymbol target) {
    for (Scope x = s; x != null; x = x.parent) {
      if (x.owner == target) return false;
      if (x.isStatic) return true;
    }
    return false;
  }

  // ───────────────────────────── expressions ─────────────────────────────

  private Type stringType() {
    ClassSymbol c = universe.byQualified("java.lang.String");
    return c == null ? JavaTypeModel.UNKNOWN : new ClassType(c, null);
  }

  private Type attrib(Expr e, Scope s) {
    return attrib(e, s, null);
  }

  /** Types {@code e}; {@code hint} is the expected type text for "create field" fixes. */
  private Type attrib(Expr e, Scope s, String hint) {
    if (e == null || out.size() >= MAX_FINDINGS) return JavaTypeModel.UNKNOWN;
    if (e instanceof Literal) {
      switch (((Literal) e).kind) {
        case LIT_INT:
          return JavaTypeModel.INT;
        case LIT_LONG:
          return JavaTypeModel.LONG;
        case LIT_FLOAT:
          return JavaTypeModel.FLOAT;
        case LIT_DOUBLE:
          return JavaTypeModel.DOUBLE;
        case LIT_CHAR:
          return JavaTypeModel.CHAR;
        case LIT_STRING:
          return stringType();
        case LIT_BOOLEAN:
          return JavaTypeModel.BOOLEAN;
        default:
          return JavaTypeModel.NULL;
      }
    }
    if (e instanceof Name) return attribName((Name) e, s, hint);
    if (e instanceof Select) {
      Meaning m = qualifier(e, s);
      return m.kind == VALUE ? m.type : JavaTypeModel.UNKNOWN;
    }
    if (e instanceof Call) return attribCall((Call) e, s);
    if (e instanceof NewObject) return attribNew((NewObject) e, s);
    if (e instanceof NewArray) {
      NewArray na = (NewArray) e;
      Type t = resolveType(na.elementType, s, true);
      for (Expr d : na.dimExprs) checkIntIndex(d, attrib(d, s), true);
      if (na.init != null) attrib(na.init, s);
      for (int i = 0; i < na.dims; i++) t = new ArrayType(t);
      return t;
    }
    if (e instanceof ArrayInit) {
      for (Expr x : ((ArrayInit) e).elements) attrib(x, s);
      return JavaTypeModel.UNKNOWN;
    }
    if (e instanceof Index) {
      Type a = attrib(((Index) e).array, s);
      checkIntIndex(((Index) e).index, attrib(((Index) e).index, s), false);
      return a instanceof ArrayType ? ((ArrayType) a).element : JavaTypeModel.UNKNOWN;
    }
    if (e instanceof Unary) {
      Unary u = (Unary) e;
      Type t = attrib(u.operand, s);
      if (u.op == "++" || u.op == "--") checkWritable(u.operand, s);
      if (!unaryApplies(u.op, t)) {
        error(u.start, u.end, "ui_diagnostic_unary_operator",
            "The '%1$s' operator can not be applied to an instance of type '%2$s'", null, u.op, t.display());
        return JavaTypeModel.UNKNOWN;
      }
      if (u.op == "!") return JavaTypeModel.BOOLEAN;
      Primitive p = unboxed(t);
      if (p == null) return JavaTypeModel.UNKNOWN;
      if (u.op == "++" || u.op == "--") return t;
      return promote(p, JavaTypeModel.INT);
    }
    if (e instanceof Binary) return attribBinary((Binary) e, s);
    if (e instanceof Assign) {
      Assign a = (Assign) e;
      Type v = attrib(a.value, s);
      String h = a.op == "=" ? hintOf(v) : null;
      Type target = attrib(a.target, s, h);
      boolean writable = checkWritable(a.target, s);
      if (a.op == "=" && assignsItself(a.target, a.value, s))
        report(a.start, a.end, Diagnostic.Severity.WARNING, "ui_diagnostic_assignment_no_effect",
            "This assignment has no effect", null);
      if (writable && a.op == "=" && !(a.value instanceof ArrayInit)) {
        int kind = targetKind(a.target, s);
        if (kind == 1)
          checkAssignable(v, target, a.value, "ui_diagnostic_incompatible_variable",
              "An instance of type '%1$s' can not be assigned to a variable of type '%2$s'");
        else if (kind == 2)
          checkAssignable(v, target, a.value, "ui_diagnostic_incompatible_field",
              "An instance of type '%1$s' can not be assigned to a field of type '%2$s'");
      }
      return target;
    }
    if (e instanceof Conditional) {
      Conditional c = (Conditional) e;
      checkCondition(c.cond, attrib(c.cond, s));
      Type a = attrib(c.whenTrue, s);
      Type b = attrib(c.whenFalse, s);
      if (a == JavaTypeModel.NULL) return b;
      if (b == JavaTypeModel.NULL) return a;
      if (a.display().equals(b.display())) return a;
      Primitive pa = unboxed(a);
      Primitive pb = unboxed(b);
      if (pa != null && pb != null && pa.isNumeric() && pb.isNumeric()) return promote(pa, pb);
      return JavaTypeModel.UNKNOWN;
    }
    if (e instanceof Cast) {
      Cast c = (Cast) e;
      Type t = resolveType(c.type, s, true);
      boolean typeFailed = lastReported;
      for (TypeRef b : c.extraBounds) resolveType(b, s, true);
      Type o = attrib(c.operand, s);
      // R6 (Id): the operand already has exactly the cast type
      if (!typeFailed && c.extraBounds.isEmpty() && c.operand != null && sameExactType(o, t)
          && !(t instanceof Primitive && involvesCall(c.operand))
          && c.operand.end <= src.length() && c.operand.start >= 0 && c.operand.end > c.operand.start)
        report(c.start, c.end, Diagnostic.Severity.WARNING, "ui_diagnostic_cast_not_required",
            "This cast is not required",
            QuickFix.replaceText(src, c.start, c.end, src.substring(c.operand.start, c.operand.end),
                "ui_quick_fix_remove_cast", ""));
      return t;
    }
    if (e instanceof InstanceOf) {
      InstanceOf io = (InstanceOf) e;
      attrib(io.operand, s);
      if (io.pattern != null) declarePattern(io.pattern, s);
      else resolveType(io.type, s, true);
      return JavaTypeModel.BOOLEAN;
    }
    if (e instanceof Lambda) {
      Lambda l = (Lambda) e;
      Scope ls = new Scope(s, null, s.isStatic);
      for (VarDecl p : l.params) {
        Type t = p.type == null || p.type.inferred ? JavaTypeModel.UNKNOWN : resolveType(p.type, s, true);
        boolean failed = p.type != null && !p.type.inferred && lastReported;
        Var lpv = new Var(p.name, t, failed);
        lpv.isFinal = p.mods != null && p.mods.has(FINAL);
        declareLocal(ls, lpv, p.nameStart, false);
      }
      int savedContext = returnContext, savedLoops = loopDepth, savedSwitches = switchDepth;
      returnContext = CTX_NONE; // the lambda's own result type is not judged here
      loopDepth = 0;
      switchDepth = 0;
      int savedExceptions = exceptionContext;
      ArrayList<ClassSymbol> savedHandlers = handlers;
      exceptionContext = EXC_NONE; // the functional interface's throws clause is unknown here
      handlers = new ArrayList<>();
      try {
        if (l.body instanceof Block) attribBlockInto((Block) l.body, ls);
        else if (l.body instanceof Expr) attrib((Expr) l.body, ls);
      } finally {
        returnContext = savedContext;
        loopDepth = savedLoops;
        switchDepth = savedSwitches;
        exceptionContext = savedExceptions;
        handlers = savedHandlers;
      }
      return JavaTypeModel.UNKNOWN;
    }
    if (e instanceof MethodRef) {
      MethodRef mr = (MethodRef) e;
      if (mr.typeTarget != null) resolveType(mr.typeTarget, s, true);
      else if (mr.target instanceof Super) superTypeOf((Super) mr.target, s);
      else if (mr.target != null) qualifier(mr.target, s);
      return JavaTypeModel.UNKNOWN;
    }
    if (e instanceof This) {
      This t = (This) e;
      if (t.qualifier == null) {
        ClassSymbol c = innermostClass(s);
        return c == null ? JavaTypeModel.UNKNOWN : c.thisType();
      }
      Meaning m = qualifier(t.qualifier, s);
      return m.kind == TYPE ? m.cls.thisType() : JavaTypeModel.UNKNOWN;
    }
    if (e instanceof Super) return JavaTypeModel.UNKNOWN;
    if (e instanceof ClassLit) {
      resolveType(((ClassLit) e).type, s, true);
      ClassSymbol c = universe.byQualified("java.lang.Class");
      return c == null ? JavaTypeModel.UNKNOWN : new ClassType(c, null);
    }
    if (e instanceof SwitchExpr) {
      SwitchExpr se = (SwitchExpr) e;
      Type sel = attrib(se.selector, s);
      switchDepth++;
      try {
        attribCases(se.cases, sel, s);
      } finally {
        switchDepth--;
      }
      return JavaTypeModel.UNKNOWN;
    }
    if (e instanceof Paren) return attrib(((Paren) e).inner, s, hint);
    if (e instanceof TypeExpr) {
      resolveType(((TypeExpr) e).type, s, true);
      return JavaTypeModel.UNKNOWN;
    }
    if (e instanceof Pattern) {
      declarePattern((Pattern) e, s);
      return JavaTypeModel.BOOLEAN;
    }
    return JavaTypeModel.UNKNOWN;
  }

  /**
   * هل «الاسمُ ليس عضوًا هنا» جزْمٌ محليّ؟ أي: كلُّ صنفٍ في سلسلة النطاقات مُعلَنٌ في هذا الملف،
   * موثوقُ البنية، سلسلتُه العليا محسومةٌ ولا تمتدّ إلى غير Object الضمني، ولا عضوَ له بهذا الاسم —
   * فلا حاجة إلى فهرسِ منصّة ولا إلى نموذجِ مشروع. تُستعمل هذه القرينةُ لتقرير **بلاغٍ واحد** لا
   * لتخمين نوعٍ ولا لعرض إصلاحٍ على صنفٍ غير معلوم.
   */
  private boolean localOwnMemberCertain(Scope s, String name) {
    if (JavaLangObjectSurface.mightBeInherited(name)) return false;
    boolean any = false;
    for (Scope x = s; x != null; x = x.parent) {
      if (x.owner == null) continue;
      if (!(x.owner instanceof SourceClass)) return false;
      SourceClass c = (SourceClass) x.owner;
      // «مُعلَنٌ هنا» هو الأساس: لا قرينةَ بلا اكتمالِ الإعلان، ولا نطلب فوقه حلقةً عليا مفسَّرة.
      if (c.decl == null || c.decl.anonymous || c.file != file || !c.reliable()) return false;
      ClassType sup = c.superclass();
      if (sup != null && !"java.lang.Object".equals(sup.symbol.qualifiedName())) return false;
      if (!JavaTypeModel.lookup(c.thisType(), name, universe).methods.isEmpty()) return false;
      any = true;
    }
    return any;
  }

  private static String hintOf(Type v) {
    if (v == null || v == JavaTypeModel.UNKNOWN || v == JavaTypeModel.NULL) return "Object";
    if (v instanceof ClassType) return ((ClassType) v).symbol.simpleName();
    if (v instanceof ArrayType && ((ArrayType) v).element instanceof ClassType)
      return ((ClassType) ((ArrayType) v).element).symbol.simpleName() + "[]";
    if (v instanceof TypeVar || v instanceof WildcardType) return "Object";
    return v.display();
  }

  private Type attribName(Name n, Scope s, String hint) {
    NameHit hit = lookupVariable(n.id, s);
    if (hit.local != null || hit.field != null) return typeOfHit(hit);
    if (resolveSimpleType(n.id, s) != null || packageLike(n.id)) return JavaTypeModel.UNKNOWN;
    if (hit.uncertain || !apiReady || !staticImportsExclude(n.id, false)) return JavaTypeModel.UNKNOWN;
    boolean allCaps = n.id.equals(n.id.toUpperCase(java.util.Locale.ROOT));
    if (Character.isUpperCase(n.id.charAt(0)) && !typeAbsenceCertain(n.id, s) && n.id.length() > 1
        && !allCaps) return JavaTypeModel.UNKNOWN;
    // اسمٌ كلُّهُ أحرفٌ كبيرةٌ — صياغةُ الثوابتِ — هو الذي يُجاوِزُ حارسَ الأنواعِ أعلاه، فلا يَحرسُهُ
    // سواهُ: لا نفيَ لحقلٍ والسلسلةُ العلويُّ للحاضنِ منفتحةٌ (وهمُ DATABASE_NAME). وأمَّا سائرُ
    // الأسماءِ فيَبقَى حُكمُها كما عندَ المرجعِ، لأنَّ بوَّابةَ m4/R3 تُثبِتُ عليهِ النَّفيَ حتى معَ
    // أبٍ من مكتبةٍ لم تُفهَرْسْ (unknownThing) — فلا نُضيِّقُ ما ليسَ سببَ الشكوى.
    if (allCaps && !memberAbsenceCertain(s)) return JavaTypeModel.UNKNOWN;
    SourceClass target = innermostNamedClass(s);
    QuickFix fix = target == null ? null
        : QuickFix.createField(target.simpleName(), hint == null ? "Object" : hint, n.id,
            staticContext(s, target));
    error(n.start, n.end, "ui_diagnostic_unknown_identifier", "Unknown variable or field '%1$s'", fix, n.id);
    return JavaTypeModel.UNKNOWN;
  }

  private static Primitive unboxed(Type t) {
    if (t instanceof Primitive) return (Primitive) t;
    if (!(t instanceof ClassType)) return null;
    switch (((ClassType) t).symbol.qualifiedName()) {
      case "java.lang.Integer":
        return JavaTypeModel.INT;
      case "java.lang.Long":
        return JavaTypeModel.LONG;
      case "java.lang.Double":
        return JavaTypeModel.DOUBLE;
      case "java.lang.Float":
        return JavaTypeModel.FLOAT;
      case "java.lang.Short":
        return JavaTypeModel.SHORT;
      case "java.lang.Byte":
        return JavaTypeModel.BYTE;
      case "java.lang.Character":
        return JavaTypeModel.CHAR;
      case "java.lang.Boolean":
        return JavaTypeModel.BOOLEAN;
      default:
        return null;
    }
  }

  private static int rank(Primitive p) {
    if (p == JavaTypeModel.DOUBLE) return 4;
    if (p == JavaTypeModel.FLOAT) return 3;
    if (p == JavaTypeModel.LONG) return 2;
    return 1;
  }

  private static Primitive promote(Primitive a, Primitive b) {
    int r = Math.max(rank(a), rank(b));
    return r == 4 ? JavaTypeModel.DOUBLE : r == 3 ? JavaTypeModel.FLOAT : r == 2 ? JavaTypeModel.LONG : JavaTypeModel.INT;
  }

  private Type attribBinary(Binary b, Scope s) {
    // Long "a + b + c ..." chains are left-nested: walk them iteratively to bound the recursion.
    ArrayList<Binary> chain = new ArrayList<>();
    Expr x = b;
    while (x instanceof Binary && chain.size() < 10000) {
      chain.add((Binary) x);
      x = ((Binary) x).left;
    }
    Type acc = attrib(x, s);
    for (int i = chain.size() - 1; i >= 0; i--) {
      Binary node = chain.get(i);
      Type r = attrib(node.right, s);
      if (!binaryApplies(node.op, acc, r)) {
        error(node.start, node.end, "ui_diagnostic_binary_operator",
            "The '%1$s' operator can not be applied to instances of type '%2$s' and '%3$s'", null,
            node.op, acc.display(), r.display());
        acc = JavaTypeModel.UNKNOWN;
        continue;
      }
      acc = binaryType(node.op, acc, r);
    }
    return acc;
  }

  private Type binaryType(String op, Type l, Type r) {
    switch (op) {
      case "==":
      case "!=":
      case "<":
      case ">":
      case "<=":
      case ">=":
      case "&&":
      case "||":
        return JavaTypeModel.BOOLEAN;
      default:
        break;
    }
    if (op == "+" && (isString(l) || isString(r))) return stringType();
    Primitive pl = unboxed(l);
    Primitive pr = unboxed(r);
    if (pl == null || pr == null) return JavaTypeModel.UNKNOWN;
    if (op == "&" || op == "|" || op == "^") {
      if (pl == JavaTypeModel.BOOLEAN && pr == JavaTypeModel.BOOLEAN) return JavaTypeModel.BOOLEAN;
    }
    if (!pl.isNumeric() || !pr.isNumeric()) return JavaTypeModel.UNKNOWN;
    if (op == "<<" || op == ">>" || op == ">>>") return promote(pl, JavaTypeModel.INT);
    return promote(pl, pr);
  }

  private static boolean isString(Type t) {
    return t instanceof ClassType && "java.lang.String".equals(((ClassType) t).symbol.qualifiedName());
  }

  // ───────────────────────────── calls ─────────────────────────────

  private List<Type> attribArgs(List<Expr> args, Scope s) {
    ArrayList<Type> types = new ArrayList<>(args.size());
    for (Expr a : args) types.add(attrib(a, s));
    return types;
  }

  private static String argsDisplay(List<Type> types) {
    StringBuilder b = new StringBuilder("(");
    for (int i = 0; i < types.size(); i++) {
      Type t = types.get(i);
      b.append(i == 0 ? "" : ", ").append(t == null ? "?" : t.display());
    }
    return b.append(')').toString();
  }

  private Type attribCall(Call c, Scope s) {
    List<Type> argTypes = attribArgs(c.args, s);
    if (c.target == null && (c.name == "this" || c.name == "super")) return JavaTypeModel.VOID;
    if (c.name == null || c.name.isEmpty()) return JavaTypeModel.UNKNOWN;
    int nameEnd = c.nameStart + c.name.length();
    if (c.target == null) {
      ClassSymbol found = null;
      Lookup hits = null;
      boolean uncertain = false;
      for (Scope x = s; x != null; x = x.parent) {
        if (x.owner == null) continue;
        Lookup l = JavaTypeModel.lookup(x.owner.thisType(), c.name, universe);
        if (!l.methods.isEmpty()) {
          found = x.owner;
          hits = l;
          break;
        }
        if (!l.complete) uncertain = true;
      }
      if (hits == null) {
        for (Import im : file.imports) {
          if (!im.isStatic) continue;
          String ownerName;
          if (im.onDemand) ownerName = im.name;
          else if (JavaTypeModel.lastSegment(im.name).equals(c.name)) {
            int dot = im.name.lastIndexOf('.');
            ownerName = dot > 0 ? im.name.substring(0, dot) : "";
          } else continue;
          ClassSymbol owner = universe.byQualified(ownerName);
          if (owner == null) {
            uncertain = true;
            continue;
          }
          Lookup l = JavaTypeModel.lookup(owner.thisType(), c.name, universe);
          if (!l.methods.isEmpty()) {
            found = owner;
            hits = l;
            break;
          }
          if (!l.complete) uncertain = true;
        }
      }
      if (hits == null) {
        SourceClass target = innermostNamedClass(s);
        // W7: قرينةٌ محليةٌ بحتة. إن كان كلُّ صنفٍ في سلسلة النطاقات مُعلَنًا في هذا الملف وموثوقًا
        // وغيرَ وارثٍ غير Object الضمني، فمعدومُ العضوية معلومٌ من الإعلان نفسه — ولا يجوز أن يصمت
        // البلاغُ لأن فهرسَ المنصّة غيرُ جاهز (قيسَ في W7: setKev() بلا أيّ رسالة). وأسماءُ Object
        // محجوزةٌ بـ{@link JavaLangObjectSurface} فلا جزمَ عليها إطلاقًا.
        boolean local = target != null && localOwnMemberCertain(s, c.name);
        if (uncertain && !local) return JavaTypeModel.UNKNOWN;
        if (target == null || (!apiReady && !local)) return JavaTypeModel.UNKNOWN;
        QuickFix fix = QuickFix.createMethod(target.simpleName(),
            ProjectSymbolIndex.inferReturnType(src, c.start), c.name,
            ProjectSymbolIndex.inferQuickFixParams(src, openParen(c)), staticContext(s, target));
        error(c.nameStart, nameEnd, "ui_diagnostic_missing_method", "Unknown method '%1$s' of '%2$s'",
            fix, c.name, target.qualifiedName());
        return JavaTypeModel.UNKNOWN;
      }
      return pick(hits, argTypes, c, found, !uncertain);
    }
    if (c.target instanceof Super) {
      ClassType base = superTypeOf((Super) c.target, s);
      if (base == null) return JavaTypeModel.UNKNOWN;
      return callOn(base, c, argTypes, s, false);
    }
    Meaning m = qualifier(c.target, s);
    if (m.kind == TYPE) return callOn(m.cls.thisType(), c, argTypes, s, true);
    if (m.kind != VALUE) return JavaTypeModel.UNKNOWN;
    Type r = JavaTypeModel.receiverOf(m.type, universe);
    if (r instanceof Primitive) {
      error(c.nameStart, nameEnd, "ui_diagnostic_call_on_primitive",
            "Method '%1$s' can not be called on the type '%2$s'", null, c.name, r.display());
      return JavaTypeModel.UNKNOWN;
    }
    if (r instanceof ArrayType) {
      if (c.name.equals("clone") && c.args.isEmpty()) return r;
      ClassSymbol object = universe.byQualified("java.lang.Object");
      if (object == null) return JavaTypeModel.UNKNOWN;
      Lookup l = JavaTypeModel.lookup(new ClassType(object, null), c.name, universe);
      if (l.methods.isEmpty() && l.complete) {
        error(c.nameStart, nameEnd, "ui_diagnostic_missing_method", "Unknown method '%1$s' of '%2$s'",
            null, c.name, r.display());
        return JavaTypeModel.UNKNOWN;
      }
      return pick(l, argTypes, c, object, l.complete);
    }
    if (!(r instanceof ClassType)) return JavaTypeModel.UNKNOWN;
    return callOn((ClassType) r, c, argTypes, s, false);
  }

  private int openParen(Call c) {
    int at = src.indexOf('(', c.nameStart + c.name.length());
    return at < 0 ? c.nameStart + c.name.length() : at;
  }

  private Type callOn(ClassType receiver, Call c, List<Type> argTypes, Scope s, boolean viaType) {
    Lookup l = JavaTypeModel.lookup(receiver, c.name, universe);
    if (l.methods.isEmpty()) {
      if (!l.complete) return JavaTypeModel.UNKNOWN;
      ClassSymbol owner = receiver.symbol;
      QuickFix fix = null;
      if (owner instanceof SourceClass && !((SourceClass) owner).decl.anonymous
          && !((SourceClass) owner).decl.name.isEmpty()) {
        fix = QuickFix.createMethod(owner.simpleName(), ProjectSymbolIndex.inferReturnType(src, c.start),
            c.name, ProjectSymbolIndex.inferQuickFixParams(src, openParen(c)), viaType);
      }
      error(c.nameStart, c.nameStart + c.name.length(), "ui_diagnostic_missing_method",
          "Unknown method '%1$s' of '%2$s'", fix, c.name, owner.qualifiedName());
      return JavaTypeModel.UNKNOWN;
    }
    return pick(l, argTypes, c, receiver.symbol, l.complete);
  }

  /** Chooses the result among the candidates; reports when no candidate takes this many args. */
  private Type pick(Lookup l, List<Type> argTypes, Call c, ClassSymbol owner, boolean certain) {
    ArrayList<Integer> applicable = new ArrayList<>();
    for (int i = 0; i < l.methods.size(); i++) if (l.methods.get(i).acceptsArity(argTypes.size())) applicable.add(i);
    if (applicable.isEmpty()) {
      if (certain) {
        LinkedHashSet<String> signatures = new LinkedHashSet<>();
        for (MethodSymbol m : l.methods) signatures.add(m.signature());
        String args = argsDisplay(argTypes);
        if (signatures.size() == 1) {
          error(c.nameStart, c.argsEnd > c.nameStart ? c.argsEnd : c.nameStart + c.name.length(),
              "ui_diagnostic_not_applicable_method", "Method '%1$s' in '%2$s' can not be applied to '%3$s'",
              null, signatures.iterator().next(), owner.qualifiedName(), args);
        } else {
          error(c.nameStart, c.argsEnd > c.nameStart ? c.argsEnd : c.nameStart + c.name.length(),
              "ui_diagnostic_no_applicable_method", "There is no applicable method to '%1$s'", null,
              c.name + args);
        }
      }
      return JavaTypeModel.UNKNOWN;
    }
    reportApiLevel(applicable, l, c);
    Type result = null;
    boolean same = true;
    int bestScore = -1;
    Type best = null;
    boolean tie = false;
    for (int idx : applicable) {
      MethodSymbol m = l.methods.get(idx);
      Type rt = JavaTypeModel.subst(m.returnType(), l.methodEnvs.get(idx));
      if (!m.typeParams.isEmpty() && mentionsVar(rt, m.typeParams)) rt = JavaTypeModel.UNKNOWN;
      if (result == null) result = rt;
      else if (!result.display().equals(rt.display())) same = false;
      int score = matchScore(m, argTypes);
      if (score > bestScore) {
        bestScore = score;
        best = rt;
        tie = false;
      } else if (score == bestScore && !best.display().equals(rt.display())) tie = true;
    }
    if (same && result != null) return result;
    return tie || best == null ? JavaTypeModel.UNKNOWN : best;
  }

  /**
   * جولةُ ٤١: عُضوٌ مَوجودٌ في المنصَّةِ، لكنَّهُ يَطلُبُ إصدارًا أعلى من حدِّ المشروعِ، أو حُذِفَ فيما
   * يُتَرجَمُ عليهِ. اليَقينُ أو لا شَيءَ على أبيوابٍ أربعَةٍ: ‏`minSdk`‏ مُصَرَّحٌ في ‏`build.gradle`‏؛
   * وكلُّ مُرشَّحٍ مُناسِبٍ مَعروضٌ للحُكمِ — فإن أتاحَ واحدٌ منهمُ النِداءَ فلا وِزرَ على المُستَخدِمِ
   * لأنَّهُ هو ما سيَختارُهُ المُترجِمُ؛ ولا حُكمَ على عُضوٍ من مَجلِسٍ مَحَلِّيٍّ (لا ‏`since`‏ لَهُ
   * أصلًا فينغلقُ البابُ بذاتِهِ)؛ ولا وسمَ في ملفٍّ يَحمِلُ حارسَ إصدارٍ أو تعليقَ مُراجِعٍ
   * (‏`SDK_INT`‏، ‏`@RequiresApi`‏، ‏`@TargetApi`‏، ‏`@SuppressLint`‏) — فبُرهانُ أنَّ الحارسَ يَشمَلُ
   * هذا المَوضِعَ يَطلُبُ مَسارَ سَيطَرَةٍ، وبِلا بُرهانٍ صَمتٌ عندَنا لا جَرَسٌ.
   */
  private void reportApiLevel(List<Integer> applicable, Lookup l, Call c) {
    ProjectPlatform platform = ProjectPlatform.current();
    if (!platform.gatesApi() || applicable.isEmpty()) return;
    if (guardPresent()) return; // ملفٌّ يَحفَظُ نَفسَهُ بحارسٍ: لا جَرَسَ عليهِ
    int since = 0;
    int removed = 0;
    boolean allRemoved = true;
    for (int i = 0; i < applicable.size(); i++) {
      MethodSymbol m = l.methods.get(applicable.get(i));
      boolean needsNewer = platform.requiresAboveMin(m.since);
      boolean gone = platform.removedForThisProject(m.removedIn);
      if (!needsNewer && !gone) return;
      if (m.since > since) since = m.since;
      if (!gone) allRemoved = false;
      else if (removed == 0 || m.removedIn < removed) removed = m.removedIn;
    }
    int nameEnd = c.nameStart + c.name.length();
    if (allRemoved && removed > 0) {
      error(c.nameStart, nameEnd, "ui_diagnostic_removed_api",
          "Method '%1$s' was removed in API level %2$d", null, c.name, Integer.valueOf(removed));
      return;
    }
    if (since > platform.minSdk)
      error(c.nameStart, nameEnd, "ui_diagnostic_requires_api",
          "Method '%1$s' requires API level %2$d (minSdk is %3$d)",
          sdkGuardFix(c.nameStart, since), c.name, Integer.valueOf(since),
          Integer.valueOf(platform.minSdk));
  }

  /**
   * حارسُ الإصدارِ في الملفِّ يُلتَمَسُ مرَّةً واحدةً لكلِّ نصٍّ، لا عندَ كلِّ نِداءٍ: أربعةُ أبحُثٍ في
   * ألفِ سطرٍ لا تُبطِئُ الفحصَ، وتِكرارُها على كلِّ عُضوٍ يَفعَلُ.
   */
  private String guardedText;
  private boolean guardedSeen;

  private boolean guardPresent() {
    if (guardedText != src) {
      guardedText = src;
      guardedSeen = src.indexOf("SDK_INT") >= 0 || src.indexOf("@RequiresApi") >= 0
          || src.indexOf("@TargetApi") >= 0 || src.indexOf("@SuppressLint") >= 0;
    }
    return guardedSeen;
  }

  /**
   * «لُفَّ بفحصِ الإصدارِ» — عندَ ما يَكونُ السطرُ تِمامَهُ نِداءً واحِدًا لا أكثرَ: فَبدلٌ واحدٌ
   * مَحدودُ المَدَى لا يَلْمَسُ جِوارَهُ، والاسمُ مُقيَّدٌ كُلِّيًّا (‏`android.os.Build`‏) فلا استيرادَ
   * يَتعلَّقُ بقرارٍ، ولا سطرَ تعليقٍ في المولَّدِ (قاعدةُ جولةِ ٣٦). والتَّخصيصُ والتَّصريحُ
   * والتَّحكُّمُ مُستثنًى كلُّهُ: ‏return‏ داخلَ ‏if‏ يَترُكُ الطَّريقَ بلا عَودةٍ، وتَصريحٌ داخلَ حَاجزٍ
   * يُغيِّرُ نِطاقَ الاسمِ — وهذَانِ خطأٌ نَحنُ نَجرَفُهُ، لا نَصحٌ نَعرِضُهُ. فاذا لم يَصِحَّ اللَّفُّ
   * يُترَكُ الوَسمُ بلا إصلاحٍ.
   */
  private QuickFix sdkGuardFix(int nameStart, int since) {
    if (guardPresent()) return null;
    int ls = nameStart;
    while (ls > 0 && src.charAt(ls - 1) != '\n') ls--;
    int le = src.indexOf('\n', nameStart);
    if (le < 0) le = src.length();
    String line = src.substring(ls, le);
    int pad = 0;
    while (pad < line.length() && (line.charAt(pad) == ' ' || line.charAt(pad) == '\t')) pad++;
    String body = line.substring(pad);
    if (!isPlainInvocation(body)) return null;
    StringBuilder out = new StringBuilder(line.length() + 96);
    out.append(line, 0, pad).append("if (android.os.Build.VERSION.SDK_INT >= ").append(since)
        .append(") {\n").append(line, 0, pad).append("  ").append(body).append('\n')
        .append(line, 0, pad).append('}');
    return QuickFix.replaceText(src, ls, le, out.toString(), "ui_fix_wrap_api_check",
        String.valueOf(since));
  }

  /** نِداءٌ مُجرَّدٌ على سطرِهِ: يَبتَدِئُ باسمٍ، ويَنتَهي ب‏`);`‏، وبلا تَخصيصٍ ولا قَوسَينِ مُتَعَشِّقَينِ ولا نصٍّ. */
  private static boolean isPlainInvocation(String body) {
    if (body.length() < 4 || !body.endsWith(");")) return false;
    if (body.indexOf('{') >= 0 || body.indexOf('}') >= 0) return false;
    if (body.indexOf('"') >= 0 || body.indexOf('\'') >= 0) return false;
    if (body.indexOf('=') >= 0) return false;
    if (body.indexOf(';') != body.length() - 1) return false;
    if (body.indexOf('(') <= 0) return false;
    if (!Character.isJavaIdentifierStart(body.charAt(0))) return false;
    String head = body.substring(0, body.indexOf('('));
    if (head.equals("return") || head.equals("throw") || head.equals("new") || head.equals("super")) {
      return false;
    }
    int depth = 0;
    for (int i = 0; i < body.length(); i++) {
      char c = body.charAt(i);
      if (c == '(') depth++;
      else if (c == ')') {
        depth--;
        if (depth < 0) return false;
      }
    }
    return depth == 0;
  }

  private static boolean mentionsVar(Type t, List<String> vars) {
    if (t instanceof TypeVar) return vars.contains(((TypeVar) t).name);
    if (t instanceof ArrayType) return mentionsVar(((ArrayType) t).element, vars);
    if (t instanceof WildcardType) return ((WildcardType) t).bound != null && mentionsVar(((WildcardType) t).bound, vars);
    if (t instanceof ClassType) for (Type a : ((ClassType) t).args) if (mentionsVar(a, vars)) return true;
    return false;
  }

  private static int matchScore(MethodSymbol m, List<Type> args) {
    int score = 0;
    for (int i = 0; i < args.size() && i < m.paramTypes.size(); i++) {
      String p = m.paramTypes.get(i);
      int lt = p.indexOf('<');
      if (lt > 0) p = p.substring(0, lt);
      int dot = p.lastIndexOf('.');
      if (dot >= 0) p = p.substring(dot + 1);
      Type a = args.get(i);
      String an = a instanceof ClassType ? ((ClassType) a).symbol.simpleName() : a.display();
      if (p.equals(an)) score += 2;
    }
    if (!m.varargs && m.paramTypes.size() == args.size()) score++;
    return score;
  }

  private Type attribNew(NewObject n, Scope s) {
    List<Type> argTypes = attribArgs(n.args, s);
    ClassSymbol c = null;
    if (n.outer != null) {
      Type ot = JavaTypeModel.receiverOf(attrib(n.outer, s), universe);
      if (ot instanceof ClassType && n.type.names.size() == 1)
        c = JavaTypeModel.memberTypeInherited(((ClassType) ot).symbol, n.type.names.get(0));
    } else {
      Type t = resolveType(n.type, s, true);
      if (t instanceof ClassType) c = ((ClassType) t).symbol;
    }
    ClassType type = null;
    if (c != null) {
      List<TypeRef> last = n.type.args.isEmpty() ? null : n.type.args.get(n.type.args.size() - 1);
      List<Type> args = null;
      if (last != null && !last.isEmpty()) {
        args = new ArrayList<>();
        for (TypeRef a : last) args.add(resolveType(a, s, false));
      }
      type = new ClassType(c, args);
      if (n.body == null || !c.isInterface()) checkConstructor(c, argTypes, n);
      if (n.body == null && c instanceof SourceClass && c.kind() == CLASS
          && ((SourceClass) c).decl.mods.has(ABSTRACT))
        error(n.type.start, n.type.end, "ui_diagnostic_abstract_instantiation",
            "An instance of an abstract class can not be created", null);
    }
    if (n.body != null) {
      SourceClass anon = new SourceClass(n.body, file, innermostClass(s), universe, new ScopeNames(s));
      anon.anonymousBase = type;
      attribClass(anon, s);
    }
    return type == null ? JavaTypeModel.UNKNOWN : type;
  }

  private void checkConstructor(ClassSymbol c, List<Type> argTypes, NewObject n) {
    if (!c.reliable() || c.isInterface()) return;
    List<MethodSymbol> ctors = c.constructors();
    if (ctors.isEmpty()) return;
    if (c instanceof JavaTypeModel.IndexedClass && !c.supertypesResolved()) return;
    for (MethodSymbol m : ctors) if (m.acceptsArity(argTypes.size())) return;
    int at = n.type.nameStarts.isEmpty() ? n.type.start : n.type.nameStarts.get(n.type.nameStarts.size() - 1);
    error(at, n.type.end, "ui_diagnostic_no_applicable_constructor",
        "There is no applicable constructor to '%1$s'", null, c.simpleName() + argsDisplay(argTypes));
  }

  // ───────────────────────────── warnings ─────────────────────────────

  private void checkUnusedPrivateFields() {
    if (file.lombok) return;
    HashMap<String, Integer> counts = null;
    ArrayList<TypeDecl> types = new ArrayList<>();
    for (TypeDecl d : unit.types) collectTypes(d, types);
    for (TypeDecl d : types) {
      if (d.kind == RECORD || !d.mods.annotations.isEmpty()) continue;
      for (Member m : d.members) {
        if (!(m instanceof FieldDecl)) continue;
        FieldDecl f = (FieldDecl) m;
        if (!f.mods.has(PRIVATE) || !f.mods.annotations.isEmpty() || f.mods.has(NATIVE)) continue;
        for (VarDecl v : f.vars) {
          if (v.name.isEmpty() || v.name.equals("serialVersionUID") || v.name.equals("serialPersistentFields"))
            continue;
          if (counts == null) counts = identifierCounts();
          Integer n = counts.get(v.name);
          if (n != null && n > 1) continue;
          report(v.nameStart, v.nameStart + v.name.length(), Diagnostic.Severity.WARNING,
              "ui_diagnostic_unused_private_field", "There is no access to field '%1$s'", null, v.name);
        }
      }
    }
  }

  private static void collectTypes(TypeDecl d, List<TypeDecl> into) {
    into.add(d);
    for (Member m : d.members) if (m instanceof TypeDecl) collectTypes((TypeDecl) m, into);
  }

  private HashMap<String, Integer> identifierCounts() {
    JavaLexer lx = JavaLexer.tokenize(src);
    HashMap<String, Integer> counts = new HashMap<>();
    for (int i = 0; i < lx.count; i++)
      if (lx.kind[i] == JavaLexer.IDENT) counts.merge(lx.text[i], 1, Integer::sum);
    return counts;
  }
}
