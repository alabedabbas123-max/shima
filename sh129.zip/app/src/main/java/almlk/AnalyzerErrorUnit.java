package almlk;

import com.almlkid.kay.ui.CodeLanguageTools;
import com.almlkid.kay.ui.ProjectDiagnostic;
import com.shima.analyzer.core.AnalysisResult;
import com.shima.analyzer.core.Diagnostic;
import com.shima.analyzer.core.SourceRange;
import com.shima.analyzer.core.TextEdit;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * وَحدَةُ الفَحصِ وَالرَّسمِ المُوحَّدَةُ — ‏1.0.198 (ج٤٧).
 *
 * <p>هذَا الصِّنفُ هُوَ المَكَانُ الوَحيدُ الَّذِي يَعرِفُ أنَ لِلمِشرُوعِ مُحرِّكَي نَحوٍ:
 * مُحرِّكُنَا (`JavaCodeAnalyzer` وَغَيرُهُ) وَوَحدَةُ ‏`com.shima.analyzer` (JNI + tree-sitter).
 * لا يَكتُبُ فِي المُحرِّرِ، وَلَا يَجلِسُ عَلى خَيطِ الوَاجِهَةِ، وَلَا يَملِكُ مُؤَقِّتًا:
 * التَّردُّدُ وَالحَصرُ وَالعَدُّ عَلى جِيلِ النَّتَائِجِ كُلُّهُ عِندَ ‏`AnalysisHandle` وَالوَاجِهَةُ
 * تُعطيهِ النَّصَّ وَتَأخُذُ مِنهُ الصُّفوفَ فَقط — فَلا سَبيلَ لِصفَّةِ تَحرُّرٍ أَن تَبلُغَ المُحرِّرَ.
 *
 * <p><b>سِيَاسَةُ التَّوحِيدِ</b> (وَهنَا تُعرَفُ القَواعِدُ الأَربَعُ، لَا عِندَ المُستَهلِكِ):
 * <ol>
 *   <li><b>صَفٌّ وَاحِدٌ لِلكَسرِ الوَاحدِ</b>: إِنَّ كَانَ عِندَنَا خَطَأٌ فِي السَّطرِ نَفسِهِ
 *       وَنَفسِ المِلفِّ بِشِدةِ {@code ERROR} وَكَانَ صَفُّ المَكتَبَةِ مِن رُمُوزِ النَّحْوِ
 *       (`SYNTAX_ERROR`, `MISSING_TOKEN`, `PARSER_FAILURE`) فَالمَكتَبَةُ تَسكُتُ عَنهُ:
 *       رِسالَتُنَا تَحمِلُ صُفوفَ الإِصلاحِ وَهُوَ لَا — وَالنَّافِذَةُ لَا تَستَحقُّ صَفَّينِ
 *       لِفَاصِلَةٍ نَاقِصَةٍ. أَمَّا غَيرُ النَّحْوِ (unused، تَكرَارُ الأَعضاءِ، R، XML،
 *       Kotlin، الأَرقَامُ الغَيرُ مُتَوافِقَةِ مَعَ البَسائِطِ) فَكُلُّهُ يُترَكُ: هذَا هُوَ
 *       الفَرقُ بَينَ «إِضافَةٍ» وَ«إِبدَالٍ»، وَقَد طَلَبَ الصَّاحِبُ إِضَافَةً بِلَا إِفسَادٍ.</li>
 *   <li><b>البَابُ سَيِّدُ المَعنَى</b>: صَفُّ المَكتَبَةِ لَا يُمسَحُ لِأَنَّ مُحرِّكًا آخَرَ
 *       قَالَّ غَيرَهُ فِي سَطرٍ آخَرَ؛ وَالتَّرجَمَةُ تَجرِي عَلى فَهرَسِ {@code diagnosticMergeKey}
 *       عِندَ المُضيفِ (مِفتاحُ المِلكِيَّةِ: صَاحبُ المِلفِّ ثُمَّ السَّطرُ وَالعَمدُ وَالنُّقطَةُ)،
 *       فَالتَّكرَارُ التَّمَامِيُّ يَسقُطُ هُنَاكَ بِأَولِيَّةِ المُحرِّكِ، وَهُنَا نَمنَعُ التَّكَرُّرَ
 *       الدَّلالِيَّ النَّحَوِيَّ فَقط.</li>
 *   <li><b>لَا صَمتَ عِندَ العُطبِ</b>: إِنَّ رَجَعَتِ النَّتِيجَةُ {@code PARTIAL} أَو سَقَطَ
 *   الجِذرُ، يُنشَرُ سَطْرُ تَحقِيرٍ (WARNING) بِكُودِ المَكتَبَةِ نَفسِهَا يَشرَحُ السَّبَبَ —
 *   لِأَنَّ «لَا أَخطَاءَ» عِندَ مَن لَم يَنظُرْ كَذِبٌ عَلَى المُستَخدِمِ.</li>
 *   <li><b>لَا إِصلاحَ زَائِفَ</b>: صَفُّ الإِصلاحِ يُعرَضُ إِذَا كانَ المُحرِّرُ هُوَ النَّصُّ
 *       الَّذِي فُحِصَ (خَتمُ SHA‑256 عِندَ المَكتَبَةِ) وَإِن كَانَ لِذلِكَ التَّشخِيصِ إِصلاحٌ
 *       مَحَلِّيٌّ. الإِصلاحَاتُ عَابِرَةُ المِلَفَّاتِ ({@code WorkspaceFix}) تُعَدُّ وَلَا
 *       تُنفَّذُ فِي هذِهِ الدَّورَةِ، وَعَدَدُهَا مَكتُوبٌ عَلى الصَّفِّ كَي لَا يَظُنَّ أحَدُنَا
 *       أنَّ المَكتَبَةَ لَا تَعرِفُهَا.</li>
 * </ol>
 *
 * <p>كُلُّ مَا هُنَا دَالَّةٌ ثَابِتَةٌ تَقرَأُ قَائِمَةً وَتُرجِعُ قَائِمَةً: لِذَا تَجرِي البَوَّابَةُ
 * عَلَيهَا عَلى جَاوَا مَعَ JNI حَقِيقِيٍّ (`tools/build_native.sh host`) — لَا وَهمَ صَندوقٍ رَمْلِيٍّ.
 */
public final class AnalyzerErrorUnit {

  /** رُمُوزُ النَّحْوِ عِندَ المَكتَبَةِ: هِيَ وَحدَهَا الَّتي يَترَجَّلُ بِهَا مُحرِّكُنَا. */
  private static final Set<String> SYNTAX_CODES = codes("SYNTAX_ERROR", "MISSING_TOKEN", "PARSER_FAILURE");

  /** رُمُوزُ الصَّمَتِ المُعلَنِ: تَحقِيرٌ يَشهَدُ عَلى نَفسِهِ، لَا تَهمِيدٌ. */
  private static final String CODE_LIMIT = "ANALYSIS_LIMIT";
  private static final String CODE_PARSER_UNAVAILABLE = "PARSER_UNAVAILABLE";

  /** الإِصلاحُ المَحَلِّيُّ يُنسَبُ إِلَى المَكتَبَةِ بِهذَا القَفصِ، فَيَقرَأُ المُستَخدِمُ مَن تَكَلَّمَ. */
  public static final String FIX_TITLE_KEY = "ui_analyzer_fix";

  /**
   * سَقۡفُ العَرۡضِ لِكُلِّ مِلَفٍّ. مَفتُوحٌ لِأَنَّ رَأۡسَ اللُّوحَةِ صَارَ يَبۡنِي «n of k» عَلَيۡهِ (ج٥٧):
   * رَقۡمٌ وَاحدٌ فِي مَكَانَيۡهِ أَسنَدُ مِنۡ مِائَتَيۡنِ يَكتُبُهُمَا كُلُّ مَكَانٍ عَن نَفۡسِهِ.
   */
  public static final int MAX_ROWS_PER_FILE = 100;

  private AnalyzerErrorUnit() { }

  private static Set<String> codes(String... values) {
    Set<String> out = new HashSet<>();
    Collections.addAll(out, values);
    return Collections.unmodifiableSet(out);
  }

  /** صَفٌّ مِن المَكتَبَةِ مَعَ إِصلاحِهَا المُحَتَمَلِ — الوَحدَةُ الَّتي تَنتَقِلُ إِلَى المُضيفِ. */
  public static final class Row {
    public final ProjectDiagnostic diagnostic;
    /** إِصلاحُ المَكتَبَةِ المَحَلِّيُّ مُترجَمًا إِلَى صَفِّنَا؛ قَد يَكونُ {@code null}. */
    public final QuickFix fix;
    /** عَدَدُ مَا يُحجَزُ: قَد لَا يَحمِلُ التَّشخِيصُ إِلَّا إِصلاحًا عَابِرَ المِلَفَّاتِ. */
    public final int workspaceFixCount;
    /**
     * نَصُّ المَكتَبَةِ نَفسِهَا بَعدَ إِصلاحِهَا — البَوَّابَةُ تُقَارِنُ صَفَّنَا بِهِ حَرفًا بِحَرفٍ،
     * فَلا نَنسِبُ نَجَاحًا بِنَا إِلَينَا.
     */
    public final String libraryApplied;
    /**
     * ج٥٧: كَم صَفًّا تُرِكَ وَرَاءَ هذَا الصَّفِّ بِسَقۡفِنَا — صِفۡرٌ لِغَيۡرِ صَفِّ السَّقۡفِ.
     * يُحۡمَلُ هُنَا لَا فِي جَدۡوِلٍ جَدِيدٍ: فَالرَّأسُ يَعدُّ مَا تَرَى اللُّوحَةُ فِقۡطۡ، فَإِنۡ سَقَطَ
     * صَفُّ السَّقۡفِ نَفۡسُهُ (بِتَغبِيرٍ أَوۡ بِمَسۡحٍ) زَالَ العَدُّ مَعَهُ — لَا رَقۡمٌ يَبقَىٰ بَعدَ صَاحِبِه.
     */
    public final int trimmedBehind;

    public Row(ProjectDiagnostic diagnostic, QuickFix fix, int workspaceFixCount, String libraryApplied) {
      this(diagnostic, fix, workspaceFixCount, libraryApplied, 0);
    }

    public Row(
        ProjectDiagnostic diagnostic,
        QuickFix fix,
        int workspaceFixCount,
        String libraryApplied,
        int trimmedBehind) {
      this.diagnostic = diagnostic;
      this.fix = fix;
      this.workspaceFixCount = workspaceFixCount;
      this.libraryApplied = libraryApplied;
      this.trimmedBehind = Math.max(0, trimmedBehind);
    }
  }

  /**
   * تَرجَمَةُ نَتِيجَةِ المَكتَبَةِ إِلَى صُفوفِ المِشرُوعِ. {@code source} هُوَ النَّصُّ الَّذِي
   * فُحِصَ (هُوَ المِلكُ فِي خَتمِ الإِصلاحِ)، فَإِن لَم يَكُن هُوَ الحَالِيَّ فَلا إِصلاحَ يُعرَضُ.
   * تُرجَعُ صُفوفٌ بِقَدرِ مَا فِي النَّتِيجَةِ، مَحمِيَّةً بِسَقفِ {@code MAX_ROWS_PER_FILE}.
   */
  public static List<Row> map(
      String fileName, String reference, String source, AnalysisResult result) {
    ArrayList<Row> rows = new ArrayList<>();
    if (result == null) return rows;
    List<Diagnostic> diagnostics = result.getDiagnostics();
    int seen = 0;
    for (Diagnostic item : diagnostics) {
      seen++;
      if (item == null) continue;
      ProjectDiagnostic row = toRow(fileName, reference, source, item);
      if (row == null) continue;
      rows.add(new Row(row, localFix(source, item), item.getWorkspaceFixes().size(),
          libraryAppliedText(source, item)));
      if (rows.size() >= MAX_ROWS_PER_FILE) break;
    }
    final int trimmed = seen < diagnostics.size() ? diagnostics.size() - seen : 0;
    if (trimmed > 0) {
      // سَقفُ عَرضٍ مِن عِندِنَا لَا حَدُّ مُحرِّكٍ: قَائِمَةٌ تُعرَضُ نَاقِصَةً بِغَيرِ قَولٍ
      // تَجعَلُ «لا أَخطَاءَ أُخرَى» كَذِبًا. الصَّفُّ بِمَصدَرٍ فَارِغٍ — لِأنَّهُ لِلُّوحَةِ لَا لِلرَّسمِ.
      // ج٥٧: العَدَدُ يُكۡتَبُ عَلَى الصَّفِّ نَفۡسِهِ (trimmedBehind)، فَلَا وَجهَ أَنۡ يَنۡقَسِمَ
      // رَأۡسُ اللُّوحَةِ عَنۡ صَفِّهِ بِرَقۡمَيۡنِ لِحَادِثَةٍ وَاحِدَة.
      ProjectDiagnostic cut = warn(fileName, reference, "", CODE_LIMIT,
          "العَرضُ مَوقُوفٌ عِندَ " + MAX_ROWS_PER_FILE + " صَفًّا لِهذَا المِلَفِّ — تُرِكَ "
              + trimmed + " صَفًّا بَعدَهُ. سِيَاسَةُ اللَّوحَةِ هذِهِ، لَا نَقصٌ فِي الفَحصِ.");
      if (cut != null) rows.add(new Row(cut, null, 0, null, trimmed));
    }
    if (result.getStatus() == AnalysisResult.Status.PARTIAL) {
      rows.add(
          new Row(
              warn(fileName, reference, source, CODE_LIMIT,
                  "التَّحلِيلُ جُزئِيٌّ: بَلَغَ الفَحصُ حِدَّ الوَقتِ أو المِقدَارِ، فَصُمتُهُ لَيسَ سَلامَةً."),
              null, 0, null));
    }
    return rows;
  }

  /** النَّحوُ غَيرُ مُتَاحٍ (جِذرٌ مَفْقُودٌ أو عَطِبٌ): صَفٌّ وَاحدٌ يَقُولُ السَّبَبَ، لَا سُكُوتٌ. */
  public static List<Row> unavailable(String fileName, String reference, String source, Throwable error) {
    String why = error == null ? "سببٌ غيرُ مَذكورٍ" : error.getClass().getSimpleName()
        + (error.getMessage() == null || error.getMessage().isEmpty() ? "" : ": " + error.getMessage());
    ProjectDiagnostic row = warn(fileName, reference, source, CODE_PARSER_UNAVAILABLE,
        "لا نَحوَ لِلمَكتَبَةِ فِي هذَا الجِهَازِ (" + why + ") — الأَخطَاءُ الَّتي تَراهَا مِن مُحرِّكِنَا وَحدَهُ.");
    ArrayList<Row> rows = new ArrayList<>();
    if (row != null) rows.add(new Row(row, null, 0, null));
    return rows;
  }

  /** صَفُّ تَحقِيرٍ بِرِسَالَةٍ حُرَّةٍ (بِلَا مِفتاحٍ: كَصَفِّ «‏MODULE» عِندَ الوَحدَةِ المَربُوطَةِ). */
  private static ProjectDiagnostic warn(
      String fileName, String reference, String source, String code, String message) {
    CodeLanguageTools.Diagnostic diagnostic =
        CodeLanguageTools.Diagnostic.localized(
            0, 0, 1, 1, CodeLanguageTools.Diagnostic.Severity.WARNING, code, null, message);
    return ProjectDiagnostic.fromSource(fileName, reference, source, diagnostic);
  }

  /** صَفٌّ كَامِلٌ: النِّطَاقُ نِصفُ المُفتَرَضِ عِندَ المَكتَبَةِ UTF‑16، وَهُوَ عِندَنَا أَيْضًا. */
  private static ProjectDiagnostic toRow(
      String fileName, String reference, String source, Diagnostic item) {
    CodeLanguageTools.Diagnostic.Severity severity;
    switch (item.getSeverity()) {
      case ERROR: severity = CodeLanguageTools.Diagnostic.Severity.ERROR; break;
      case WARNING: severity = CodeLanguageTools.Diagnostic.Severity.WARNING; break;
      default: severity = CodeLanguageTools.Diagnostic.Severity.INFO; break;
    }
    String text = source == null ? "" : source;
    SourceRange range = item.getRange();
    int start = range == null ? 0 : clamp(range.getStartOffset(), 0, text.length());
    int end = range == null ? start : clamp(range.getEndOffset(), start, text.length());
    int line = range == null || range.getStartLine() <= 0 ? 1 : range.getStartLine();
    int column = range == null || range.getStartColumn() <= 0 ? 1 : range.getStartColumn();
    CodeLanguageTools.Diagnostic diagnostic =
        CodeLanguageTools.Diagnostic.restored(
            start, end, line, column, severity, item.getCode(), item.getMessage(), null, null);
    return ProjectDiagnostic.fromSource(fileName, reference, text, diagnostic);
  }

  private static int clamp(int value, int low, int high) {
    return value < low ? low : (value > high ? high : value);
  }

  /**
   * إِصلاحٌ مَحَلِّيٌّ قَابِلٌ لِلتَّطبِيقِ، أَو {@code null}. صَفٌّ بِصِفرِ إِصلاحٍ لَا يُعرَضُ
   * (قَاعِدَةُ الجَولَةِ المَاضِيَةِ: لَا «إِصلاحًا» وَهمِيًّا). الإِصلاحَاتُ عَابِرَةُ المِلَفَّاتِ
   * لَا تُترجَمُ إِلَى صَفٍّ هذِهِ الدَّورَةَ؛ عَدَدُهَا يُذكَرُ عَلَى صَفِّ التَّشخِيصِ.
   */
  private static QuickFix localFix(String source, Diagnostic item) {
    List<com.shima.analyzer.core.QuickFix> offered = item.getQuickFixes();
    if (source == null || offered.isEmpty()) return null;
    com.shima.analyzer.core.QuickFix fix = offered.get(0);
    if (fix == null || !fix.isApplicableTo(source)) return null;
    List<TextEdit> edits = fix.getEdits();
    if (edits.isEmpty()) return null;
    int start = Integer.MAX_VALUE;
    int end = 0;
    for (TextEdit edit : edits) {
      if (edit.getEndOffset() > source.length()) return null; // النَّصُّ تَحَرَّكَ: لَا صَفَّ.
      start = Math.min(start, edit.getStartOffset());
      end = Math.max(end, edit.getEndOffset());
    }
    // دُفعَةٌ وَاحدَةٌ عَلى نِطَاقٍ وَاحدٍ: البِدَلُ مَا يَحُلُّ مَكَانَ [start,end) فَقط. وَكَانَ
    // قَد وَقَعَ هُنَا: «‏applyTo‏» يُرجِعُ الوَثيقَةَ كُلَّهَا بَعدَ الإِصلاحِ، فَتَسقُطُ الوَسطَةُ
    // بِوَثيقَةٍ كَامِلَةٍ — أَمسَكَ بِهَا بَابُنَا قَبلَ أن يَقتَرِبَ أَحَدٌ مِنَ الجِهَازِ.
    StringBuilder region = new StringBuilder(source.substring(start, end));
    for (TextEdit edit : edits) {
      int from = edit.getStartOffset() - start;
      int to = edit.getEndOffset() - start;
      if (from < 0 || to > region.length() || to < from) return null;
      region.replace(from, to, edit.getReplacement());
    }
    String replacement = region.toString();
    QuickFix row = QuickFix.replaceText(source, start, end, replacement, FIX_TITLE_KEY, fix.getTitle());
    if (row == null) return null;
    int held = item.getWorkspaceFixes().size();
    if (held == 0) return row;
    // يُعلَنُ المَحتَجَزُ وَلَا يُنفَّذُ: «لَا شَيءَ هُنَا» أَصدَقُ مِن صَفٍّ يَنقُصُهُ نِصفُ العَمَلِ.
    return QuickFix.replaceText(
        source, start, end, replacement, FIX_TITLE_KEY,
        fix.getTitle() + " — وَمَعَهُ إِصلاحٌ عَابِرُ المِلَفَّاتِ (" + held + ") لَا يُطبَّقُ مِن هُنَا");
  }

  /** مَا تُنتِجُهُ المَكتَبَةُ بِنَفسِهَا لَو طُبِّقَ إِصلاحُهَا — مَرجِعٌ لِلْبَوَّابَةِ فَقط. */
  public static String libraryAppliedText(String source, Diagnostic item) {
    if (source == null || item == null || item.getQuickFixes().isEmpty()) return source;
    com.shima.analyzer.core.QuickFix fix = item.getQuickFixes().get(0);
    if (fix == null || !fix.isApplicableTo(source) || fix.getEdits().isEmpty()) return source;
    return fix.applyTo(source);
  }

  /** هَل هذَا الكُودُ نَحوِيٌّ عِندَ المَكتَبَةِ؟ (مَفتُوحٌ لِلبَوَّابَةِ: سِيَاسَةٌ لَا جَدوَلٌ دَفينٌ). */
  public static boolean isSyntaxCode(String code) {
    return code != null && SYNTAX_CODES.contains(code);
  }

  /**
   * قَرارُ التَّرجُّلِ: صَفُّ نَحوٍ مِنَ المَكتَبَةِ يَسقُطُ إِذَا كَانَ عِندَنَا فِي المِلفِّ
   * نَفسِهِ وَالسَّطرِ نَفسِهِ خَطَأٌ بِشِدةِ {@code ERROR}. سِوَى ذلِكَ يُبقَى.
   */
  public static List<ProjectDiagnostic> suppressSyntaxOverlaps(
      List<ProjectDiagnostic> engineRows, List<ProjectDiagnostic> analyzerRows) {
    ArrayList<ProjectDiagnostic> kept = new ArrayList<>();
    if (analyzerRows == null || analyzerRows.isEmpty()) return kept;
    Set<String> engineErrors = new HashSet<>();
    if (engineRows != null) {
      for (ProjectDiagnostic item : engineRows) {
        if (item == null || item.diagnostic == null) continue;
        if (item.diagnostic.severity != CodeLanguageTools.Diagnostic.Severity.ERROR) continue;
        engineErrors.add(item.reference + "|" + item.diagnostic.line);
      }
    }
    for (ProjectDiagnostic item : analyzerRows) {
      if (item == null || item.diagnostic == null) continue;
      if (isSyntaxCode(item.diagnostic.code)
          && engineErrors.contains(item.reference + "|" + item.diagnostic.line)) {
        continue;
      }
      kept.add(item);
    }
    return kept;
  }
  /* ═══ المِخْزَنُ: مِفتاحُهُ مَسارُ المِلَفِّ، كَـ«‏TarinerHintMaps‏» — صَفْحَةٌ لا سِجلَّ لِلوَاجِهَةِ ═══ */

  /** أَكبَرُ عَدَدٍ مِنَ المِلَفَّاتِ تَحفَظُ الوَحدَةُ؛ الأَقدَمُ يَخرُجُ أَوَّلًا (بِلَا نَومٍ وَلَا جُوعٍ). */
  private static final int MAX_STORED_FILES = 64;
  private static final LinkedHashMap<String, List<Row>> STORE = new LinkedHashMap<>();
  private static int heldWorkspaceFixes;

  /** نَتِيجَةٌ حَقيقيَّةٌ لِمِلَفٍّ: تُستَبدَلُ صُفوفُهُ كُلُّهَا، فَلا صَفٌّ يَبقَى مِن جِيلٍ مَضى. */
  public static synchronized void put(String reference, String fileName, String source, AnalysisResult result) {
    putRows(reference, map(fileName, reference, source, result));
  }

  /** صُفُوفٌ بِيَدِ مَمرِّ المِشرُوعِ (هُوَ يَجمَعَهَا مِن نَفسِ المُلقَطِ): تَحلُّ مَكَانَ سَابِقِهَا. */
  public static synchronized void putProjectRows(String reference, List<Row> rows) {
    putRows(reference, rows);
  }

  /**
   * صَفُّ «الفَحصُ الجَمعِيُّ نَاقِصٌ»: مَا تُرِكَ عَنِ المِيزَانِيَّةِ يُعلَنُ لَا يُمحَى، وَلا
   * نَستَعمِلُ «‏unavailable‏» هُنَا — لِأنَّ الجِذرَ سَلِيمٌ وَالسَّقَطُ حِصَّةٌ، فَالتَّسمِيَةُ
   * الخَاطِئَةُ تَدفَعُ المُستَخدِمَ إِلَى إِصْلَاحِ مَا لَم يُكسَرْ.
   */
  public static final String CODE_WORKSPACE_INCOMPLETE = "WORKSPACE_INCOMPLETE";

  public static Row budgetRow(String fileName, String reference, String note) {
    ProjectDiagnostic row =
        warn(fileName, reference, "", CODE_WORKSPACE_INCOMPLETE,
            note == null || note.isEmpty() ? "الفَحصُ الجَمعِيُّ نَاقِصٌ: تُرِكَتْ مِلَفَّاتٌ عَنِ المِلقَطِ." : note);
    return row == null ? null : new Row(row, null, 0, null);
  }

  /** النَّحوُ غَيرُ مُتَاحٍ: صَفٌّ وَاحدٌ يَشرَحُ، وَيَسقُطُ كُلُّ مَا قِيلَ قَبلَ أن يَسقُطَ الجِذرُ. */
  public static synchronized void putUnavailable(String reference, String fileName, String source, Throwable error) {
    putRows(reference, unavailable(fileName, reference, source, error));
  }

  private static void putRows(String reference, List<Row> rows) {
    String key = reference == null ? "" : reference;
    if (rows == null || rows.isEmpty()) {
      STORE.remove(key);
    } else {
      STORE.put(key, Collections.unmodifiableList(new ArrayList<>(rows)));
    }
    while (STORE.size() > MAX_STORED_FILES) {
      Iterator<String> oldest = STORE.keySet().iterator();
      if (!oldest.hasNext()) break;
      oldest.next();
      oldest.remove();
    }
    int held = 0;
    for (List<Row> list : STORE.values()) {
      for (Row row : list) held += row.workspaceFixCount;
    }
    heldWorkspaceFixes = held;
  }

  /** كُلُّ الصُّفوفِ الجَاهِزَةِ لِلنَّشرِ (بِلا تَرجُّلٍ: سِيَاسَتُهُ عِندَ المُضيفِ بَعدَ قِرَاءَةِ مُحرِّكِهِ). */
  public static synchronized List<ProjectDiagnostic> rows() {
    ArrayList<ProjectDiagnostic> out = new ArrayList<>();
    for (List<Row> list : STORE.values()) {
      for (Row row : list) if (row.diagnostic != null) out.add(row.diagnostic);
    }
    return out;
  }

  /** إِصلاحُ المَكتَبَةِ لِهذا السَّطرِ فِي هذَا المِلفِّ، أَو {@code null} — لَا صَفَّ بِلا عَمَلٍ. */
  public static synchronized QuickFix fixAt(String reference, int line) {
    List<Row> list = STORE.get(reference == null ? "" : reference);
    if (list == null) return null;
    for (Row row : list) {
      if (row.fix != null && row.diagnostic != null && row.diagnostic.diagnostic != null
          && row.diagnostic.diagnostic.line == line) {
        return row.fix;
      }
    }
    return null;
  }

  /**
   * إِصلاحُ السَّطرِ المُنقَرِ (وَجهَةُ الحُشرَةِ). {@code fileHint} هُوَ مَا يَحمِلُهُ المُحرِّرُ
   * مِن اسمٍ — قَد يَكونُ مُجَرَّدًا، فَالنِّهَايَتَانِ تَتَطَابَقَانِ؛ وَإن لَم نَجِدْ فَصِفرٌ،
   * وَلَا صَفَّ «إِصلاحًا» لَا يَعرِفُ أحَدٌ مَا يَفعَلُ.
   */
  public static synchronized QuickFix fixNear(int line, String fileHint) {
    for (Map.Entry<String, List<Row>> entry : STORE.entrySet()) {
      String key = entry.getKey();
      if (fileHint != null && !fileHint.isEmpty()
          && !(key.endsWith(fileHint) || fileHint.endsWith(key) || key.contains(fileHint))) {
        continue;
      }
      for (Row row : entry.getValue()) {
        if (row.fix == null || row.diagnostic == null || row.diagnostic.diagnostic == null) continue;
        if (row.diagnostic.diagnostic.line == line) return row.fix;
      }
    }
    return null;
  }

  /** كَم مِقدَارُ مَا نَعَرِفُهُ وَلَا نَفعَلُهُ — لِلبَوَّابَةِ وَشَريطِ «المَزِيدُ مَوجودٌ» بَعدَهَا. */
  public static synchronized int heldWorkspaceFixes() {
    return heldWorkspaceFixes;
  }

  public static synchronized void clear(String reference) {
    STORE.remove(reference == null ? "" : reference);
  }

  public static synchronized void clearAll() {
    STORE.clear();
    heldWorkspaceFixes = 0;
  }

  /** عَدَدُ المِلَفَّاتِ المَحمُولَةِ — حَرَسُ الحَجمِ، ولِيَس لَيسَ دَاخِلَ حِفظِ الوَاجِهَةِ. */
  public static synchronized int storedFileCount() {
    return STORE.size();
  }

  /**
   * ج٥٧: مَا تُرِكَ عَنِ العَرۡضِ بِسَقۡفِنَا فِي جَمِيعِ المِلَفَّاتِ المَحمُولَةِ، مَجمُوعًا.
   * لَا جَدۡوِلَ هُنَا: المُجَمَّعُ هُوَ صُفُوفُ السَّقۡفِ نَفۡسُهَا الَّتي فِي المِخۡزَنِ — فَإِنۡ مُسِحَ
   * مِلَفٌّ أَوۡ بُدِّلَتۡ صُفُوفُهُ زَالَ رَقۡمُهُ بِزَوَالِ صَفِّهِ، فَاللُّوحَةُ لَا تَسۡتَطِيعُ أَنۡ
   * تُبۡقِيَ «k» بَعدَ أَنۡ ذَهَبَتۡ «n».
   */
  public static synchronized int trimmedRowCount() {
    int total = 0;
    for (List<Row> list : STORE.values()) {
      for (Row row : list) total += row.trimmedBehind;
    }
    return total;
  }

  /** السَّقۡفُ نَفۡسُهُ يُسۡأَلُ مِنَ الوَحدَةِ — لِئَلَّا يُكۡتَبَ «‏100‏» فِي مَكَانَينِ بِأَيۡدٍ مُختَلِفَة. */
  public static int displayCeiling() {
    return MAX_ROWS_PER_FILE;
  }
}
