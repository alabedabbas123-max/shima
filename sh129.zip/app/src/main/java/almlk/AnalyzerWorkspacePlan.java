package almlk;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * جَدوَلَةُ فَحصِ المِشرُوعِ (ج٤٨): مَن يَمشِي، وَمَن يُستَثنَى، وَمَا يَسَعُ المِيزَانِيَّةَ.
 *
 * <p>لِأنَّ المَكتَبَةَ تَرمِي ‏IllegalArgumentException‏ عِندَمَا يَتَجَاوَزُ المُلقَطُ حُدُودَهَا
 * (‏maxProjectFiles‏ = 500، ‏maxProjectChars‏ = 2 000 000)، فَالحِارسُ هُنَا لَا عِندَهَا:
 * سَقفُنَا أَدنَى عَمدًا — رَمِيٌّ عَلى الحُدُودِ لَيسَ رَأيًا فِي الكُودِ، وَإِنَّمَا إِغلَاقُ
 * الفَحصِ كُلِّهِ. وَكَذَلِكَ لَا «تَخمِينُ» لِلأَحمَالِ: نَزنُ بِالبَائِتِ عَلى القَرصِ، لِأنَّ
 * ‏chars ≤ bytes‏ دَائِمًا (حَتَّى بِالعَرَبِيَّةِ الَّتي تَأكُلُ ثَلَثَةَ بُيُوتٍ لِلحَرفِ) —
 * فَالمِيزَانِيَّةُ بِالبَائِتِ أَشَدُّ مِنهَا بِالحُروفِ، وَالأَشَدُّ هُوَ المَطلُوبُ.
 *
 * <p>وَالأَهمُّ: مَا سَقَطَ عَنِ المِيزَانِيَّةِ يُعَدُّ وَيُعلَنُ، لَا يَختَفِي. «لَا خَطَأَ فِي
 * المِشرُوعِ» وَ«لَم أَصِلْ إِلَى جَمِيعِهِ» جُمْلَتَانِ مُختَلِفَتَانِ تَمَامًا، وَالوَسطَةُ الَّتي
 * تُسكِتُ الفَرقَ تُصَيِّرُ الأَخطَاءَ عَادَةً.
 */
public final class AnalyzerWorkspacePlan {

  /** أَدنَى مِن سَقفِ المَكتَبَةِ (500) — فَلا استِثنَاءَ يُغلِقُ الفَحصَ، وَلا جَلَدَ عَلى المُحرِّرِ. */
  public static final int MAX_FILES = 400;
  /** أَدنَى مِن ‏maxProjectChars‏ (2 000 000)؛ تُحصَى بِالبَائِتِ كَمَا يَأْتِي شَارِحُ الصِّنفِ. */
  public static final int MAX_TOTAL_CHARS = 1_500_000;
  /** = ‏AnalysisConfig.maxDocumentChars‏: أَكبَرُ مِنهُ تَرفَضُهُ المَكتَبَةُ بِـ ‏DOCUMENT_TOO_LARGE. */
  public static final int MAX_FILE_CHARS = 200_000;

  /** مُستَعمَلٌ لِلتَّرجِيمَةِ لَا لِلقِيَاسِ: المِلَفُّ الكَبيرُ يُترَكُ وَلَا يُحسَبُ «سَلِيمًا». */
  public static final long BYTE_PRESCREEN = 3L * MAX_FILE_CHARS;

  public enum Kind {
    JAVA,
    KOTLIN,
    XML,
    OTHER
  }

  /** مُرشَّحٌ كَمَا رَأتِهِ المِشيَةُ: مَسَارٌ نِسبِيٌّ لِلوَحدَةِ، وَحَجمٌ مِنَ القَرصِ. */
  public static final class Entry {
    public final String relativePath;
    public final Kind kind;
    public final long sizeBytes;

    /** عامٌّ لِأَنَّ الجَدوَلَةَ قَطْعِيَّةُ البِنَاءِ: صَفٌّ فِيهِ مَسَارٌ وَجِنسٌ وَحَجْمٌ لَا أَكثَرُ. */
    public Entry(String relativePath, Kind kind, long sizeBytes) {
      this.relativePath = relativePath;
      this.kind = kind;
      this.sizeBytes = sizeBytes;
    }

    /** نَفسُ شَكْلِ ‏MarkBinding.tabReference‏: مِلَفٌّ مَعرُوفٌ بِمُطلَقِهِ، فَصَفُّهُ يَجِدُهُ. */
    public String reference(File moduleDir) {
      return new File(moduleDir, relativePath).getAbsolutePath();
    }

    public String fileName() {
      int slash = Math.max(relativePath.lastIndexOf('/'), relativePath.lastIndexOf('\\'));
      return slash < 0 ? relativePath : relativePath.substring(slash + 1);
    }

    /** ‏src/main/…‏ أَهمُّ مِن ‏src/test/…‏ وَمِن أَيِّ مُجلَّدٍ عَرَضِيٍّ: هذَا تَرتيبُ الجُودَةِ. */
    boolean isMainSource() {
      String p = relativePath.replace('\\', '/');
      return p.startsWith("src/main/") && !p.startsWith("src/main/assets/");
    }
  }

  /** مَا يَنبَغِي قِرَاءتَهُ بِالتَّحدِيدِ، وَمَا تُرِكَ — بِعَدَدِهِ لَا بِإِطرَاقٍ. */
  public static final class Plan {
    public final List<Entry> sources;
    public final List<Entry> resources;
    /** مَسَارُ ‏ids.xml‏ نِسبَةً لِلوَحدَةِ، أو {@code null} إِذَا لَم يَكُن — فَلا نَزعُمُ تَمَامًا. */
    public final String idsRelativePath;
    public final boolean resourcesComplete;
    public final int skippedByCap;
    public final int skippedTooLarge;
    public final int skippedOther;
    public final long budgetBytes;

    Plan(
        List<Entry> sources,
        List<Entry> resources,
        String idsRelativePath,
        boolean resourcesComplete,
        int skippedByCap,
        int skippedTooLarge,
        int skippedOther,
        long budgetBytes) {
      this.sources = Collections.unmodifiableList(sources);
      this.resources = Collections.unmodifiableList(resources);
      this.idsRelativePath = idsRelativePath;
      this.resourcesComplete = resourcesComplete;
      this.skippedByCap = skippedByCap;
      this.skippedTooLarge = skippedTooLarge;
      this.skippedOther = skippedOther;
      this.budgetBytes = budgetBytes;
    }

    public boolean isEmpty() {
      return sources.isEmpty() && resources.isEmpty();
    }

    public int includedCount() {
      return sources.size() + resources.size();
    }

    /** هَل تُرِكَ شَيءٌ عَنِ الفَحصِ؟ (لَا يَجُوزُ أن يُقالَ «لَا شَيءَ» بَعدَئِذٍ). */
    public boolean incomplete() {
      return skippedByCap > 0 || skippedTooLarge > 0 || !resourcesComplete;
    }

    /**
     * الجُملَةُ الَّتي تَظهَرُ عَلَى اللَّوحَةِ: عَدَدٌ، وَسَبَبٌ، وَلَا عِبَارَةَ يَجمَلِيَّةً تُخفِي
     * الحِجَايَةَ. {@code null} عِندَمَا لَم يُترَكْ شَيءٌ — فَلا صَفَّ تَجمِيلٍ.
     */
    public String coverageNote() {
      if (!incomplete()) return null;
      StringBuilder note = new StringBuilder();
      if (skippedByCap > 0) {
        note.append("لَم يُفحَصْ ")
            .append(skippedByCap)
            .append(" مِلَفًّا لِأنَّ الفَحصَ الجَمعِيَّ مَحصُورٌ فِي ")
            .append(MAX_FILES)
            .append(" مِلَفًّا وَ")
            .append(MAX_TOTAL_CHARS)
            .append(" حَرفًا؛ ");
      }
      if (skippedTooLarge > 0) {
        note.append("وَتُرِكَتْ ")
            .append(skippedTooLarge)
            .append(" مِلَفَّاتٍ تَفُوقُ ")
            .append(MAX_FILE_CHARS)
            .append(" حَرفًا؛ ");
      }
      if (!resourcesComplete) {
        note.append("وَفَهرَسُ المِواردِ غَيرُ تَامٍّ (لا ‏ids.xml‏ مَعرُوفًا أو تُرِكَتْ مِواردُ)؛ ");
      }
      String text = note.toString();
      while (text.endsWith("؛ ") || text.endsWith("، ")) text = text.substring(0, text.length() - 2);
      return "الفَحصُ الجَمعِيُّ نَاقِصٌ: " + text + " — فَصَمتِي عَمَّا لَم أَصِلْ إِلَيهِ لَيسَ بَرَاءَةً.";
    }
  }

  /**
   * مَا يَسقُطُ عِندَ القِرَاءَةِ (كَبيرٌ، أو اختَفَى، أو لَا يُفَتَّحُ) يُضَافُ إِلَى الجُمَلَةِ —
   * لِأنَّ «القَطيعَةَ بَعدَ الجَدوَلَةِ» هِيَ النَّوعُ الوَحيدُ مِنَ السَّقَطِ الَّذي لَا تَرَاهُ
   * عَدَّادَاتُ الجَدوَلَةِ أَصلاً، فَإِن لَم نَذكُرمهُ صَارَ المَمَرُّ أَكمَلَ مِمَّا هُوَ.
   */
  public static String withReadDrops(String coverageNote, int droppedAtRead) {
    if (droppedAtRead <= 0) return coverageNote;
    String extra =
        droppedAtRead + " مِلَفًّا سَقَطَ عِندَ القِرَاءَةِ (كَبيرٌ جِدًّا أو لَا يُقرَأُ)؛";
    if (coverageNote == null || coverageNote.isEmpty()) {
      return "الفَحصُ الجَمعِيُّ نَاقِصٌ: " + extra + " — فَصَمتِي عَمَّا لَم أَصِلْ إِلَيهِ لَيسَ بَرَاءَةً.";
    }
    int tail = coverageNote.lastIndexOf(" — فَصَمتِي");
    if (tail < 0) return coverageNote + " وَ" + extra;
    return coverageNote.substring(0, tail) + " وَ" + extra + coverageNote.substring(tail);
  }

  private AnalyzerWorkspacePlan() {}

  public static Kind kindOf(String relativePath) {
    String p = relativePath == null ? "" : relativePath.replace('\\', '/');
    int dot = p.lastIndexOf('.');
    if (dot < 0) return Kind.OTHER;
    String ext = p.substring(dot + 1).toLowerCase(java.util.Locale.ROOT);
    if ("java".equals(ext)) return Kind.JAVA;
    if ("kt".equals(ext) || "kts".equals(ext)) return Kind.KOTLIN;
    if ("xml".equals(ext)) return Kind.XML;
    return Kind.OTHER;
  }

  /**
   * مَا لَا يَجُوزُ أن يَدخُلَ فَهرَسَ المِشرُوعِ أَصلاً: مُخَرَّجَاتُ البِنَاءِ، وَالمَكَتَبَاتُ
   * الجَاهِزَةُ، وَأَموَاضُ القَوَالِبِ (فِي تَطْبِيقِنَا نَفسِهِ ‏assets/templates‏ يَحمِلُ
   * ‏.java‏ شَابَّةً يَجِبُ ألَّا تُقَرَأَ كَكَودِ المُستَخدِمِ)، وَالأَدوَاتُ الوَقتِيَّةُ.
   */
  public static boolean isExcluded(String relativePath) {
    String p = relativePath == null ? "" : relativePath.replace('\\', '/');
    if (p.startsWith("/")) return true;
    for (String seg : p.split("/")) {
      if (seg.isEmpty()) continue;
      if (seg.equals("build")
          || seg.equals("out")
          || seg.equals("target")
          || seg.equals("node_modules")
          || seg.equals("libs")
          || seg.equals("jars")
          || seg.equals(".gradle")
          || seg.equals(".cxx")
          || seg.equals(".idea")
          || seg.equals(".git")
          || seg.equals(".out")
          || seg.equals("intermediates")
          || seg.equals("outputs")
          || seg.equals("assets")
          || seg.equals("jniLibs")
          || seg.equals("third_party")) {
        return true;
      }
    }
    return false;
  }

  /** مَشيٌ بِلا رِجعِيَّةٍ (مِلَفَّاتُ المِشرُوعِ قَد تَعمُقُ)، وَبِلا قِرَاءَةٍ: الحُجومُ تَكفِي. */
  public static List<Entry> scan(File moduleDir) {
    ArrayList<Entry> found = new ArrayList<>();
    if (moduleDir == null || !moduleDir.isDirectory()) return found;
    String rootPath = moduleDir.getAbsolutePath();
    ArrayList<File> stack = new ArrayList<>();
    stack.add(moduleDir);
    while (!stack.isEmpty()) {
      File dir = stack.remove(stack.size() - 1);
      File[] children = dir.listFiles();
      if (children == null) continue;
      for (File child : children) {
        if (child == null) continue;
        String rel = relative(rootPath, child);
        if (isExcluded(rel)) continue;
        if (child.isDirectory()) {
          stack.add(child);
        } else if (child.isFile()) {
          Kind kind = kindOf(rel);
          if (kind == Kind.OTHER) continue;
          found.add(new Entry(rel, kind, child.length()));
        }
      }
    }
    Collections.sort(
        found,
        new Comparator<Entry>() {
          @Override
          public int compare(Entry a, Entry b) {
            int rank = Boolean.compare(!a.isMainSource(), !b.isMainSource());
            if (rank != 0) return rank;
            return a.relativePath.replace('\\', '/').compareTo(b.relativePath.replace('\\', '/'));
          }
        });
    return found;
  }

  public static Plan of(File moduleDir) {
    return of(moduleDir, MAX_FILES, MAX_TOTAL_CHARS);
  }

  /**
   * تَجزِئَةٌ وَمِيزَانِيَّةٌ. السَّقفَانِ مَفتُوحَانِ هُنَا لِتَستَطِيعَ البَوَّابَةُ أن تَصنَعَ
   * جُوعًا حَقِيقِيًّا بِخَمسَةِ مِلَفَّاتٍ، لَا أن تَحمِلَ مِشرُوعًا كَامِلًا فِي ذَاكِرَتِهَا.
   */
  public static Plan of(File moduleDir, int maxFiles, int maxTotalChars) {
    List<Entry> all = scan(moduleDir);
    ArrayList<Entry> sources = new ArrayList<>();
    ArrayList<Entry> resources = new ArrayList<>();
    int tooLarge = 0;
    int other = 0;
    int capDrops = 0;
    long bytes = 0L;
    int limit = Math.max(0, maxFiles);
    long charBudget = Math.max(0, maxTotalChars);
    for (Entry entry : all) {
      if (entry.sizeBytes > BYTE_PRESCREEN && entry.sizeBytes / 3L > MAX_FILE_CHARS) {
        tooLarge++;
        continue;
      }
      if (sources.size() + resources.size() >= limit) {
        capDrops++;
        continue;
      }
      if (bytes + Math.max(1L, entry.sizeBytes) > charBudget) {
        capDrops++;
        continue;
      }
      bytes += Math.max(1L, entry.sizeBytes);
      if (entry.kind == Kind.XML) resources.add(entry);
      else if (entry.kind == Kind.JAVA || entry.kind == Kind.KOTLIN) sources.add(entry);
      else other++;
    }
    String ids = pickIdsFile(resources);
    boolean complete = ids != null;
    return new Plan(sources, resources, ids, complete, capDrops, tooLarge, other, bytes);
  }

  /** ‏src/main/res/values/ids.xml‏ أَوَّلًا؛ وَإِلَّا أَيُّ ‏…/res/values/ids.xml؛ وَإِلَّا null. */
  public static String pickIdsFile(List<Entry> resources) {
    String best = null;
    for (Entry entry : resources) {
      String p = entry.relativePath.replace('\\', '/');
      if (!p.endsWith("res/values/ids.xml")) continue;
      if (p.startsWith("src/main/res/values/ids.xml")) return p;
      if (best == null) best = p;
    }
    return best;
  }

  /** نَتيجَةُ قِرَاءَةٍ ثُلَاثِيَّةٌ: نَصٌّ، أو كَبيرٌ، أو لَا يُقرَأ — لَا «فَارِغٌ» المُلبَسَةُ. */
  public static final class Read {
    public final String text;
    public final boolean tooLarge;
    public final String failure;

    private Read(String text, boolean tooLarge, String failure) {
      this.text = text;
      this.tooLarge = tooLarge;
      this.failure = failure;
    }

    static Read ok(String text) {
      return new Read(text, false, null);
    }

    static Read large() {
      return new Read(null, true, null);
    }

    static Read failed(String why) {
      return new Read(null, false, why == null ? "سببٌ غيرُ مذكورٍ" : why);
    }

    public boolean usable() {
      return text != null;
    }
  }

  /**
   * قِرَاءَةٌ بِحَدٍّ: نَقرَأُ ‏cap+1‏، فَإِن زَادَ الحَرفُ الوَاحِدُ فَالمِلَفُّ خَارِجُ المِيزَانِيَّةِ
   * (وَيَجِبُ أن يُعلَنَ كَذلِكَ) — وَلَا نَقرَأُ مِلَفَّاتِ المِئَاتِ المِغَابَايتِ لِنَكتَشِفَ ذلِكَ.
   */
  public static Read read(File moduleDir, Entry entry, int charCap) {
    File file = new File(moduleDir, entry.relativePath);
    if (!file.isFile()) return Read.failed("لم يَعُدْ مِلَفًّا");
    StringBuilder text = new StringBuilder((int) Math.min(64 * 1024L, Math.max(16L, entry.sizeBytes)));
    FileInputStream stream = null;
    try {
      stream = new FileInputStream(file);
      byte[] chunk = new byte[8 * 1024];
      long decoded = 0L;
      int got;
      while ((got = stream.read(chunk)) > 0) {
        text.append(new String(chunk, 0, got, "UTF-8"));
        decoded = text.length();
        if (decoded > charCap) return Read.large();
      }
      return Read.ok(text.toString());
    } catch (IOException | RuntimeException error) {
      return Read.failed(error.getClass().getSimpleName() + ": " + error.getMessage());
    } finally {
      if (stream != null) {
        try {
          stream.close();
        } catch (IOException ignored) {
          // إِغلَاقُ القَارِئِ لَا يَنبَغِي أن يَكسِرَ فَحصًا نَجَحَ.
        }
      }
    }
  }

  public static Read read(File moduleDir, Entry entry) {
    return read(moduleDir, entry, MAX_FILE_CHARS);
  }

  private static String relative(String rootPath, File child) {
    String absolute = child.getAbsolutePath();
    if (absolute.startsWith(rootPath)) {
      String rel = absolute.substring(rootPath.length());
      while (rel.startsWith("/") || rel.startsWith("\\")) rel = rel.substring(1);
      return rel.replace('\\', '/');
    }
    return child.getName();
  }

  /** مُسَاعِدَةٌ لِلْبَوَّابَةِ: تَرتِيبٌ قَابِلٌ لِلتَّكرَارِ عَلَى أَيِّ لَستَةٍ. */
  public static List<Entry> sortedByPath(List<Entry> entries) {
    ArrayList<Entry> copy = new ArrayList<>(entries);
    Collections.sort(
        copy,
        new Comparator<Entry>() {
          @Override
          public int compare(Entry a, Entry b) {
            return a.relativePath.compareTo(b.relativePath);
          }
        });
    return copy;
  }
}
