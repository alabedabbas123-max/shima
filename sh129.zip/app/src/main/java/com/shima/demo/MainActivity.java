package com.shima.demo;

import android.app.*;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import androidx.drawerlayout.widget.DrawerLayout;
import android.view.*;
import android.widget.*;
import com.almlkid.kay.ui.BuildDiagnosticsParser;
import com.almlkid.kay.ui.CodeLanguageTools;
import com.almlkid.kay.ui.ProjectDiagnostic;
import com.almlkid.kay.ui.ProjectSearchEngine;
import com.almlkid.kay.ui.ProjectSymbolIndex;
import com.almlkid.kay.ui.UsageSearchEngine;
import com.almlkid.kay.view.VPDrawerLayout;
import com.almlkid.ui.SequentialPanelHost;
import com.almlkid.ui.AIDEEditorPager;
import com.almlkid.ui.browsers.BrowserPager;
import com.shima.projects.ProjectWizard;
import java.io.File;
import java.util.*;

/** Java controller for the original res/layout/main_drawer.xml screen. */
public class MainActivity extends LocaleAwareActivity
    implements BrowserPager.ActionListener, CommandCenter.Host {
  VPDrawerLayout drawer;
  AIDEEditorPager editor;

  /** شريطُ أدواتِ المحرّر — يُعيدُ بناءَهُ بعد الحفظِ من الإعدادات. */
  almlk.QuickKeyBar quickKeyBar;
  BrowserPager browser;
  ImageButton masterButton;
  View moreActionView;
  View empty;
  boolean projectOpen = false;

  /**
   * W27/1: لا يعملُ المحرِّكُ التحليليُّ حتى يُفتَتَحَ ملفٌّ جوهريٌّ داخلَ مجلدِ الوحدةِ (ملحقُ ‏W27/1)؛
   * التصفُّحُ يَترُكُها {@code false} فلا رسالةَ ولا تبديلَ سياقٍ، وهي الحالةُ التي تُقرَأُ في اللوحةِ.
   */
  boolean analysisArmed = false;

  /** آخرُ قرارِ توقيتٍ مُسمّى: يُثبِتُ أنَّ الصمتَ قرارٌ لا سهوٌ. */
  String analysisGateState = "no_file";

  /** مسارُ مشروعٍ طلبنا تبديلَه لملفٍّ جوهريٍّ منهُ — يمنعُ ظهورَ الحوارِ مرّتينِ لنفسِ المشروعِ. */
  private String pendingFileSwitchPath;
  private String languageAtLastCreate;
  final CommandCenter commands = new CommandCenter();
  ShellCommandRunner shell;
  ProjectSession session;
  // شريط وضع التحرير (دلالة المرجع): يتحول مع ظهور كيبورد المحرر ويعود مع إخفائه.
  boolean editingToolbar;
  boolean lastCanUndo, lastCanRedo, lastPendingEdits;
  /** شارة عدد الأخطاء في الشريط (المرجع AIDEErrorsView): تُخفى عند 0 وعلى الشاشات ≤360dp. */
  private almlk.ErrorCountBadge errorBadge;
  private boolean errorBadgeVisible;
  AlertDialog requiredStorageDialog;
  FrameLayout sequentialPanelsDrawer;
  View sequentialPanelsScrim;
  SequentialPanelHost sequentialPanels;
  private final ArrayList<ProjectDiagnostic> sourceDiagnostics = new ArrayList<>();
  private final ArrayList<ProjectDiagnostic> buildDiagnostics = new ArrayList<>();
  /** M3: علامات أسطر الاعتماد في ملف الوحدة (غير محلول / متغير / صيغة). */
  private final ArrayList<ProjectDiagnostic> dependencyDiagnostics = new ArrayList<>();
  /** W21′2: صفوفُ ملفاتِ الظلِّ المرفوضةِ — قائمةٌ مستقلّةٌ كصفوفِ الاعتماداتِ. */
  private final ArrayList<ProjectDiagnostic> shadowDiagnostics = new ArrayList<>();
  /**
   * W22/4ب٢‑ب٣: حالةُ الوحداتِ المرتبطةِ التي لا تُحَلُّ — قائمةٌ خامسةٌ مستقلّةٌ،
   * تحذيرٌ دائمًا: لا تُبطلُ بناءً ولا تُنذِرُ بفشلٍ، ولا تلمسُ قرصًا في خيطِ الواجهةِ.
   */
  private final ArrayList<ProjectDiagnostic> moduleDiagnostics = new ArrayList<>();
  private com.almlkid.ui.DependencyCycle dependencyCycle;
  private final ArrayList<ProjectDiagnostic> displayedDiagnostics = new ArrayList<>();
  /**
   * ‏1.0.198 (ج٤٧): وَحدَةُ الفَحصِ وَالرَّسمِ — الجِسْرُ إِلَى ‏com.shima.analyzer. يُنشَأُ عِندَ
   * أَوَّلِ إِشارَةِ مُحرِّرٍ (لا شَيءَ فِي ‏onCreate: لا مَسارَ يَبدا وَالتَّحقُّقُ مِن جِذرٍ لَم
   * يَحمِلهُ أحدٌ)، وَلا يُغلَقُ إِلّا عِندَ إِغلاقِ التَّبويِبِ كُلِّهَا — فَالمِخزَنُ يَحفَظُ
   * الصُّفوفَ وَالعَمَلُ كُلُّهُ عَلى خَيطِ «shima-analyzer» ذِي الأَولَوِيَّةِ الخافِضَةِ.
   */
  private almlk.AnalyzerBridge analyzerBridge;
  private String analyzerActiveName;
  private String analyzerActiveReference;

  /**
   * ج٥٨: بَابُ الرَّسمِ يَعرِفُ صَاحِبَهُ. رَسمٌ يُنَادِيهِ رَسمٌ عَلى الخَيطِ نَفسِهِ
   * مُجَمَّعٌ إِلَى نَظرَةٍ وَاحدَةٍ بَعۡدَ أن تَسۡتَقِرَّ الأُولَىٰ — فَالحَامِلُ قَدۡ يُنَادِي
   * مِن دَاخِلِ إِشرَاقٍ أَعدَنَاهُ نَحنُ (دَورَةُ ج٥٤). الحَارِسُ خَيطٌ لَا عَلَامَةٌ:
   * نَتَائِجُ المَكتَبَةِ تَأتِي عَلَىٰ خَيطِهَا فَلَا يَسُدُّهَا حَظرٌ عَامٌّ.
   */
  private Thread paintOwner;
  private boolean paintAgain;
  private boolean paintAgainComplete;

  /** الجِسْرُ عِندَ الحاجَةِ، وَنَصُّهُ عِندَ الطَّلَبِ: التبويبُ الجَارِي لَا نُسخَةُ القُرمِ. */
  private almlk.AnalyzerBridge analyzerBridge() {
    if (analyzerBridge == null) {
      analyzerBridge =
          new almlk.AnalyzerBridge(
              this,
              reference -> {
                if (editor == null || analyzerActiveName == null) return null;
                if (reference != null && !reference.equals(analyzerActiveReference)) return null;
                return editor.textOf(analyzerActiveName);
              },
              () -> publishProjectDiagnostics(false));
      // ج٤٨: المُضيفُ لَا يَحمِلُ لِلجِسْرِ إِلَّا «أَينَ الوَحدَةُ وَمَا حِزمَتُهَا» — فَكُلَّمَا
      // قَلَّ مَا يَعرِفُهُ المُساعِدُ قَلَّ مَا يَقدِرُ عَلَى إِفسَادِهِ: لَا Gradle، وَلَا قُرصًا عَارِيًا.
      analyzerBridge.setProjectHost(
          new almlk.AnalyzerBridge.ProjectHost() {
            @Override public java.io.File moduleDir() {
              return currentModuleDir();
            }

            @Override public String namespace() {
              return currentProjectPackage();
            }
          });
    }
    return analyzerBridge;
  }

  /** الصَّفحَةُ تُخبِرُ عَنِ الوَجهَةِ: الاسمُ لِلنَّصِّ، والمرجَعُ لِلوَسمِ وَالرَّسمِ. */
  private void onAnalyzerFocus(String fileName, String reference) {
    analyzerActiveName = fileName;
    analyzerActiveReference = reference;
    analyzerBridge().onEditorSignal(fileName, reference);
  }

  @Override
  public void onCreate(Bundle state) {
    super.onCreate(state);
    shell = new ShellCommandRunner(this);
    languageAtLastCreate = almlk.AppSettings.language(this);
    // لا سوادَ مدهونًا هنا بعدَ الإنشاء: نمطُ النشاطِ (almlk.ChromeTheme) هو الذي يقرِّرُ لونَ الشريطِ
    // ولونَ شريطَيِ الحالةِ والتنقُّلِ وأيقاتِهِ — وإلّا كانَت هذه الشاشةُ وحدها بيضاءُ حولَ سواد.
    if (getIntent().getBooleanExtra("safe_mode", false)) {
      showSafeMode();
      return;
    }
    try {
      session = new ProjectSession(this);
      setContentView(R.layout.main_drawer);
      configureActionBar();
      drawer = findViewById(R.id.mainDrawerLayout);
      editor = findViewById(R.id.mainCodePageView);
      // شريطُ الأدواتِ مالكُهُ النشاطُ لا المُحرِّر: يُلحَمُ في mainQuickKeyBarContainer ويُبنى من سلسلةِ
      // نوعِ الملفِ النشِط (.java/.xml/.c)، والمُحرِّرُ مُضيفُهُ فيُدرَجُ من منفذِ الكتابةِ نفسِه.
      quickKeyBar =
          new almlk.QuickKeyBar(this, findViewById(R.id.mainQuickKeyBarContainer), null);
      if (editor != null) editor.attachQuickKeyBar(quickKeyBar);
      // Fix: create the panel host in code instead of inflating <com.almlkid.ui.SequentialPanelHost>
      // from XML. LayoutInflater resolves custom views via reflection, and any build pipeline that
      // strips "unreferenced" constructors makes inflation crash with NoSuchMethodException.
      FrameLayout panelSlot = findViewById(R.id.mainSequentialPanelHost);
      sequentialPanels = panelSlot == null ? null : new SequentialPanelHost(this);
      if (panelSlot != null) {
        panelSlot.addView(
            sequentialPanels,
            new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
      }
      browser = sequentialPanels == null ? findViewById(R.id.mainBrowserPager) : sequentialPanels.browser();
      attachBrowserSwipe();
      empty = findViewById(R.id.mainCodeEmptyView);
      if (drawer == null || editor == null || browser == null || sequentialPanels == null || empty == null)
        throw new IllegalStateException("main_drawer.xml is missing a required view");
      browser.setOnFileSelectedListener(
          (name, content) -> {
            // Keep only the stable path/SAF URI in the session; the text is still loaded lazily.
            openFile(name, content, browser.fileReference(name));
          });
      // تقرير فتح الملفات — الفتح الفوري: التبويب يظهر لحظة النقرة («جارٍ فتح الملف…»)،
      // وحوار تبديل المشروع يُطلق هنا عند النقرة وليس عند وصول المحتوى.
      browser.setOnFileOpeningListener(
          name -> {
            drawer.closeDrawers();
            String reference = browser.fileReference(name);
            // W27/1: النقرةُ لا تُبدِّلُ السياقَ وحدَها — تُسلَّحُ فقط إن كانَ الملفُّ جوهريًّا في وحدتِهِ.
            armAnalysisForOpenedFile(reference);
            projectOpen = true;
            empty.setVisibility(View.GONE);
            editor.openFilePending(name, reference);
            if (masterButton != null)
              masterButton.setVisibility(masterAllowed() ? View.VISIBLE : View.GONE);
            getActionBar().setTitle(name);
            getActionBar().setSubtitle(ui("ui_open_project_subtitle"));
          });
      browser.setActionListener(this);
      sequentialPanels.setProjectDiagnostics(displayedDiagnostics);
      sequentialPanels.setErrorClickListener(
          new com.almlkid.ui.SequentialPanelHost.ErrorClickListener() {
            @Override
            public void clicked(ProjectDiagnostic diagnostic) {
              openProjectDiagnostic(diagnostic, false);
            }

            @Override
            public void fileRowClicked(String reference, String fileName) {
              openErrorFileRow(reference, fileName);
            }
          });
      sequentialPanels.setErrorActionsListener(item -> openProjectDiagnostic(item, true));
      sequentialPanels.setBuildOutput(ui("ui_build_not_started"));
      sequentialPanels.setUsageClickListener(
          usage -> {
            if (usage == null || editor == null) return;
            // كالمرجع: الانتقال بالسطر/العمود على النص الحي وقت النقر — لا إزاحات بائتة،
            // والقفزة تُؤجل تلقائيًا داخل المحرر إن كان محتوى التبويب قيد التحميل الكسول.
            // التفعيل بالمرجع الثابت يحترم أسماء التبويبات المفردة ولا يفتح تبويبًا مكررًا.
            String openTab = editor.selectIfOpenLive(usage.reference, usage.fileName);
            if (openTab == null && editor.activateTabIfOpen(usage.fileName))
              openTab = usage.fileName;
            if (openTab != null) {
              editor.goToMatch(openTab, usage.line, usage.column, usage.endColumn);
              // الدخول المباشر كما في المرجع: اللوحة تُغلق فورًا ويظهر المحرر على الموقع.
              closeSequentialPanels();
              return;
            }
            browser.openUsageAsync(
                usage,
                (success, fileName, content, offset, message) -> {
                  if (!success || fileName == null || content == null) {
                    // نصُّ المرجعِ حرفيًّا: ‏path + " could not be loaded!"، واللوحةُ لا تُغلَقُ.
                    Toast.makeText(
                            this, notLoadedText(usage.reference, usage.fileName),
                            Toast.LENGTH_SHORT)
                        .show();
                    return;
                  }
                  // ترتيب المرجع: الفتح (حقن متزامن) يسبق القفزة دائمًا — والقفزة تستهدف
                  // اسم التبويب الفعلي بعد الفتح (قد يكون مفردًا).
                  openFile(fileName, content, browser.fileReference(fileName));
                  editor.goToMatch(
                      editor.getActiveFile(), usage.line, usage.column, usage.endColumn);
                  closeSequentialPanels();
                });
          });
      sequentialPanels.setCloseListener(this::closeSequentialPanels);
      editor.setProjectDiagnostics(displayedDiagnostics);
      editor.setDiagnosticsListener(this::onEditorDiagnostics);
      editor.setFileChangedListener(this::onEditorFileChanged);
      // المرحلة الثامنة: بذل افتراضيات نمط الكود مرة واحدة، بلا دهم اختيار المستخدم.
      almlk.CodeStyle.seedDefaults(this);
      com.almlkid.ui.preferences.BuildActions.delegate =
          new com.almlkid.ui.preferences.BuildActions.Delegate() {
            @Override
            public void refreshMaven() {
              java.io.File root = session == null ? null : session.directory();
              if (browser == null || root == null) {
                Toast.makeText(MainActivity.this, ui("ui_error_open_project_first"), Toast.LENGTH_SHORT).show();
                return;
              }
              // M2: تأكيد ثم إعادة تنزيل مكتبات المشروع الحالي كلها (كالمرجع)، ثم إعادة الفهرسة والفحص.
              new android.app.AlertDialog.Builder(MainActivity.this)
                  .setTitle(ui("preference_title_refresh_maven"))
                  .setMessage(ui("ui_maven_refresh_confirm"))
                  .setPositiveButton(
                      android.R.string.ok,
                      (d, w) -> dependencyCycle().start(root, com.almlkid.ui.DependencyCycle.Mode.REFRESH))
                  .setNegativeButton(ui("dialog_cancel"), null)
                  .show();
            }

            @Override
            public void applyEditorVisual() {
              almlk.AppSettings.applyGradleCompletionRules(MainActivity.this);
              runOnUiThread(() -> { if (editor != null) editor.applyAdvancedSettings(); });
            }

            @Override
            public void openGradleRules() {
              java.io.File file = almlk.AppSettings.gradleRulesFile(MainActivity.this);
              try {
                if (!file.isFile()) {
                  file.getParentFile().mkdirs();
                  java.io.Writer w = new java.io.OutputStreamWriter(new java.io.FileOutputStream(file), "UTF-8");
                  w.write(ui("ui_gradle_rules_header") + "\n");
                  w.close();
                }
              } catch (Exception failure) {
                Toast.makeText(MainActivity.this,
                    uiFormat("ui_save_failed", UiStrings.message(MainActivity.this, failure)),
                    Toast.LENGTH_SHORT).show();
                return;
              }
              openFile(file.getAbsolutePath());
              almlk.AppSettings.applyGradleCompletionRules(MainActivity.this);
            }

            @Override
            public void writeProguardConfig() {
              java.io.File root = session == null ? null : session.directory();
              if (root == null) {
                Toast.makeText(MainActivity.this, ui("ui_error_open_project_first"), Toast.LENGTH_SHORT).show();
                return;
              }
              java.io.File target = new java.io.File(root, "proguard-rules.pro");
              try {
                if (!target.exists()) {
                  java.io.FileOutputStream out = new java.io.FileOutputStream(target);
                  out.write(("# قواعد حماية شيميا الافتراضية\n-keep class ** { *; }\n")
                      .getBytes("UTF-8"));
                  out.close();
                }
                Toast.makeText(MainActivity.this, uiFormat("ui_protection_file_path", target.getAbsolutePath()),
                    Toast.LENGTH_LONG).show();
              } catch (Exception e) {
                Toast.makeText(MainActivity.this, ui("ui_error_write_protection_file"),
                    Toast.LENGTH_SHORT).show();
              }
            }

            @Override
            public void configureGradle() {
              java.io.File root = session == null ? null : session.directory();
              if (root == null) {
                Toast.makeText(MainActivity.this, ui("ui_error_open_project_first"), Toast.LENGTH_SHORT).show();
                return;
              }
              java.io.File target = new java.io.File(root, "gradle.properties");
              try {
                if (!target.exists()) {
                  java.io.FileOutputStream out = new java.io.FileOutputStream(target);
                  out.write(("org.gradle.jvmargs=-Xmx1536m\n").getBytes("UTF-8"));
                  out.close();
                  Toast.makeText(MainActivity.this, ui("ui_gradle_properties_created"),
                      Toast.LENGTH_SHORT).show();
                } else {
                  Toast.makeText(MainActivity.this, ui("ui_gradle_properties_exists"),
                      Toast.LENGTH_SHORT).show();
                }
              } catch (Exception e) {
                Toast.makeText(MainActivity.this, ui("ui_error_create_gradle_properties"),
                    Toast.LENGTH_SHORT).show();
              }
            }

            @Override
            public void ndkToggle() {
              android.content.SharedPreferences sp = almlk.AppSettings.prefs(MainActivity.this);
              boolean now = !sp.getBoolean("ndk_support_installed", false);
              sp.edit().putBoolean("ndk_support_installed", now).apply();
              Toast.makeText(MainActivity.this, ui(now ? "ui_ndk_support_installed" : "ui_ndk_support_removed"),
                  Toast.LENGTH_SHORT).show();
            }
          };
      editor.setHostCommandListener(new AIDEEditorPager.HostCommandListener() {
        @Override public void run(String commandId) { dispatch(commandId); }
        @Override public void run(String commandId, String argument) {
          if ("replace".equals(commandId)) promptReplace(argument);
          else dispatch(commandId);
        }
      });
      // قائمة التبويب: عند إغلاق كل التبويبات منها تُعرض الواجهة الفارغة كما في بقية المسارات.
      editor.setTabsClosedListener(
          () -> {
            if (analyzerBridge != null) analyzerBridge.release();
            analyzerActiveName = null;
            analyzerActiveReference = null;
            empty.setVisibility(View.VISIBLE);
            editor.setVisibility(View.GONE);
            if (masterButton != null) masterButton.setVisibility(View.GONE);
          });
      editor.setAnalyzerFocusListener(this::onAnalyzerFocus);
      editor.setQuickFixListener(quickFixExecutor::execute);
      editor.setDefinitionListener(this::openDefinition);
      editor.setDefinitionRequestListener(this::findDefinitionForSelection);
      editor.setUsageListener(this::findUsagesForSelection);
      editor.setHistoryStateListener(this::refreshEditingToolbarState);
      masterButton = findViewById(R.id.mainMasterButton);
      if (masterButton != null) {
        masterButton.setOnClickListener(v -> showCommands());
        hideMasterButtonWithKeyboard(masterButton);
      }
      ProgressBar progress = findViewById(R.id.mainErrorProgress);
      if (progress != null) progress.setVisibility(View.GONE);
      configureDrawer();
      applySelectedTheme();
      showNoProject();
      editor.restoreSessionAsync(
          restored -> {
            if (!restored) return;
            projectOpen = true;
            empty.setVisibility(View.GONE);
            editor.setVisibility(View.VISIBLE);
            if (masterButton != null)
              masterButton.setVisibility(masterAllowed() ? View.VISIBLE : View.GONE);
            // A reopened project is scanned once below (with or without restored tabs).
            if (session == null || !session.isOpen()) indexAndScanProject();
          });
      // حفظ المشروع المفتوح عبر إعادة التشغيل: استرجاع عنوانه وفتح جذره مباشرة.
      if (session != null && session.isOpen()) {
        projectOpen = true;
        getActionBar().setTitle(session.name());
        getActionBar().setSubtitle(ui("ui_android_project_subtitle"));
        if (browser != null) {
          // تقرير AIDE — بروتوكول الاستعادة = إعادة تنفيذ بروتوكول الفتح ذاته (جذر + فهرسة + إعلام).
          browser.openProjectRoot(session.path());
          Toast.makeText(this, uiFormat("ui_project_opened", session.name()), Toast.LENGTH_SHORT).show();
          // Like the source app: the whole project is checked as soon as it opens, so the error
          // panel is filled before any file is touched.
          indexAndScanProject();
        }
      }
      browser.postDelayed(this::showPermissionsCenterOnFirstRun, 500);
    } catch (Throwable error) {
      CrashStore.save(this, error);
      showStartupError(error);
    }
  }

  void configureActionBar() {
    ActionBar b = getActionBar();
    if (b == null) return;
    b.setTitle(ui("ui_current_project"));
    b.setSubtitle(getString(R.string.app_name));
    b.setDisplayHomeAsUpEnabled(true);
    b.setHomeButtonEnabled(true);
    // يبقى يدويًّا ما لا يملكُهُ النمطُ وحدَهُ: أيقونتُنا الخاصةُ بيضاءُ خالصة، فتُلبَسُ لونَ نصِّ
    // النمطِ الجاري — سوداءُ على الشريطِ الفاتح وبيضاءُ على الداكن، في كلِّ شاشةٍ لا هنا فقط.
    b.setHomeAsUpIndicator(almlk.ChromeTheme.navigationIcon(this, R.drawable.ic_navigation_menu));
  }

  void applySelectedTheme() {
    ThemeConfig theme = new ThemeConfig(this);
    int background = theme.color(ThemeConfig.BACKGROUND);
    // الشريطُ وشريطَا الحالةِ والتنقُّلِ من نمطِ النشاطِ الذي ثبَّتَهُ ChromeTheme عندَ الإنشاء — فلا يبقى
    // لونٌ يدويٌّ يسبقُ بقيّةَ الشاشات: المحرِّرُ وحدَهُ من اللوحة، والشريطُ من نمطِ التطبيقِ كلِّه.
    // المرحلة 4: نافذة/شريط حالة من الإعدادات المتقدمة.
    if (almlk.AppSettings.prefs(this).getBoolean("use_adjustPan", false))
      getWindow()
          .setSoftInputMode(
              android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN
                  | android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);
    else
      getWindow()
          .setSoftInputMode(
              android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN
                  | android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
    // استثناءٌ صريحٌ طلبتْهُ الإعداداتُ المتقدمة (شريطُ حالةٍ أسودَ دائمًا): يُبطِلُ معَهُ الأيقوناتُ
    // السوداءُ على الشريطِ الفاتح، وإلّا صارَ الشريطُ أسودَ بأيقاتٍ سوداء.
    if (almlk.AppSettings.prefs(this).getBoolean("dark_statusbar", false)) {
      getWindow().setStatusBarColor(Color.BLACK);
      getWindow()
          .getDecorView()
          .setSystemUiVisibility(
              getWindow()
                  .getDecorView()
                  .getSystemUiVisibility()
                  & ~android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
    }
    ActionBar bar = getActionBar();
    if (bar != null) {
      bar.setHomeAsUpIndicator(
          almlk.ChromeTheme.navigationIcon(this, R.drawable.ic_navigation_menu));
    }
    if (empty != null) empty.setBackgroundColor(background);
    if (editor != null) editor.applyTheme();
    if (browser != null) browser.applyTheme();
  }

  /** المرحلة 5: الدرج والزر الرئيسي يحترمان مفاتيح التطبيق المتقدمة عند كل استئناف. */
  private void applyDrawerSettings() {
    android.content.SharedPreferences sp = almlk.AppSettings.prefs(this);
    if (drawer != null) {
      boolean drawerOn = sp.getBoolean("advanced_setting_enable_drawer", true);
      boolean toggleOn = sp.getBoolean("enableDrawerToggle", true);
      drawer.setDrawerLockMode(
          drawerOn && toggleOn
              ? androidx.drawerlayout.widget.DrawerLayout.LOCK_MODE_UNLOCKED
              : androidx.drawerlayout.widget.DrawerLayout.LOCK_MODE_LOCKED_CLOSED,
          android.view.Gravity.START);
    }
    if (masterButton != null && !masterAllowed()) masterButton.setVisibility(View.GONE);
  }

  private boolean masterAllowed() {
    return almlk.AppSettings.prefs(this).getBoolean("enableMainMasterButton", true);
  }

  void configureDrawer() {
    drawer.setScrimColor(Color.BLACK);
    drawer.setHorizontalSwipeListener(
        new VPDrawerLayout.HorizontalSwipeListener() {
          @Override
          public void onDrawerSwipeLeft() {
            // The file browser and tool panes are one continuous pager.
            if (sequentialPanels != null) sequentialPanels.nextPage();
          }

          @Override
          public boolean onDrawerSwipeRight() {
            // At the file page return false so DrawerLayout can close normally.
            return sequentialPanels != null && sequentialPanels.previousPageIfPossible();
          }
        });
    drawer.addDrawerListener(
        new DrawerLayout.SimpleDrawerListener() {
          @Override
          public void onDrawerOpened(View v) {
            getActionBar()
                .setHomeAsUpIndicator(
                    almlk.ChromeTheme.navigationIcon(
                        MainActivity.this, R.drawable.ic_navigation_back));
            invalidateOptionsMenu();
          }

          @Override
          public void onDrawerClosed(View v) {
            getActionBar()
                .setHomeAsUpIndicator(
                    almlk.ChromeTheme.navigationIcon(
                        MainActivity.this, R.drawable.ic_navigation_menu));
            invalidateOptionsMenu();
          }
        });
  }

  void showNoProject() {
    projectOpen = false;
    analysisArmed = false;
    analysisGateState = "no_file";
    if (editor != null) editor.setAnalysisArmed(false);
    if (dependencyCycle != null) dependencyCycle.reset();
    sourceDiagnostics.clear();
    buildDiagnostics.clear();
    dependencyDiagnostics.clear();
    shadowDiagnostics.clear();
    moduleDiagnostics.clear();
    publishProjectDiagnostics(true);
    empty.setVisibility(View.VISIBLE);
    editor.setVisibility(View.GONE);
    if (masterButton != null) masterButton.setVisibility(View.GONE);
    getActionBar().setTitle(ui("ui_current_project"));
    getActionBar().setSubtitle(getString(R.string.app_name));
  }

  void openFile(String file) {
    openFile(file, null);
  }

  void openFile(String file, String content) {
    openFile(file, content, "");
  }

  void openFile(String file, String content, String reference) {
    // تقرير فتح الملفات — تقرير التبديل بين المشاريع يسبق القراءة الآن (setOnFileOpeningListener)
    // أي وصول openFile هنا يعني أن المحتوى جاهز للحقن فقط.
    projectOpen = true;
    empty.setVisibility(View.GONE);
    editor.openFile(file, content, reference);
    if (browser != null)
      browser.setActiveEditorSnapshot(editor.getActiveFile(), editor.getTextContent(), reference);
    if (masterButton != null) masterButton.setVisibility(View.VISIBLE);
    getActionBar().setTitle(file);
    getActionBar().setSubtitle(ui("ui_open_project_subtitle"));
  }

  @Override
  public void onProjectOpened(String name, String path) {
    // فتح مشروع مختلف عمّا هو مفتوح: تأكيد أولًا مع إيقاف تخزين المشروع السابق بسرعة.
    if (projectOpen
        && session != null
        && session.isOpen()
        && path != null
        && !path.isEmpty()
        && !session.path().equals(path)) {
      confirmProjectSwitch(name, path);
      return;
    }
    applyProjectOpen(name, path);
  }

  /** حوار تأكيد أنيق قبل استبدال المشروع الحالي بآخر جديد. */
  private void confirmProjectSwitch(final String name, final String path) {
    final String previousName = session.name();
    final String previousPath = session.path();
    new AlertDialog.Builder(this)
        .setTitle(ui("ui_project_wizard_title"))
        .setMessage(uiFormat("ui_project_switch_message", name, previousName))
        .setPositiveButton(
            ui("ui_open_project_entry"),
            (dialog, which) -> {
              suspendProjectCaches(previousPath);
              applyProjectOpen(name, path);
            })
        .setNegativeButton(
            ui("dialog_cancel"),
            (dialog, which) -> {
              // تراجع أنيق: إبقاء المشروع السابق مفتوحًا وإعادة المتصفح إلى جذره.
              if (browser != null) browser.openProjectRoot(previousPath);
            })
        .show();
  }

  /** التخزين المؤقت للمشروع الحالي فقط: إسقاط فهرس/كاش المشروع السابق فورًا. */
  private void suspendProjectCaches(String previousPath) {
    ProjectSymbolIndex.clear();
    if (editor != null) editor.closeAll();
    if (browser != null) browser.suspendProjectCacheFor(previousPath);
  }

  /**
   * W27/1 (ملحقُ ‏W27/1): توقيتُ الفحصِ مشروطٌ بالملفِّ المستهدَفِ. تُسلَّحُ المحرِّكاتُ التحليليّةُ فقط
   * لملفٍّ جوهريٍّ داخلَ مجلدِ الوحدةِ (بناءٌ، موردٌ ‏xml، manifest، مصدرٌ)؛ وكلُّ نقرةٍ أخرى تَفتَحُ
   * للتحريرِ بلا حوارٍ وبلا تغييرِ مشروعٍ وبلا إقلاعِ محركٍ — وهو ما كانَ {@code
   * maybeSwitchProjectForFile}/{@code maybeOpenProjectForBuildFile} يَفعلُهُ بالعكسِ.
   */
  private void armAnalysisForOpenedFile(String reference) {
    String openRoot = session != null && session.isOpen() ? session.path() : null;
    almlk.AnalysisTargets.Decision decision = almlk.AnalysisTargets.of(reference, openRoot);
    analysisGateState = decision.state + (decision.kind == null ? "" : "/" + decision.kind);
    if (decision.armsAnalysis()) {
      analysisArmed = true;
      if (editor != null) editor.setAnalysisArmed(true);
      return;
    }
    if (!decision.mayAskOpenProject()) {
      // تصفُّحٌ أو ملفٌّ خارجَ كلِّ مشروعٍ: صمتٌ تامٌّ، واللوحةُ تُخبِرُ بالسببِ عندَ فتحِها لا الآنَ.
      if (editor != null) editor.setAnalysisArmed(analysisArmed);
      return;
    }
    final File root = decision.projectRoot;
    final String projectPath = root.getAbsolutePath();
    if (projectPath.equals(pendingFileSwitchPath)) return;
    pendingFileSwitchPath = projectPath;
    getWindow()
        .getDecorView()
        .postDelayed(
            () -> {
              if (projectPath.equals(pendingFileSwitchPath)) pendingFileSwitchPath = null;
            },
            4000);
    confirmOpenProjectForTargetFile(root, decision.projectName);
  }

  /**
   * الوجه الوحيد الباقي لـ«افتح المشروعَ» (‏1.0.113‑M3 مُعدَّلًا بملحقِ W27/1): يُعرَضُ لنقرٍ على ملفٍّ
   * **جوهريٍّ** في مشروعٍ غيرِ المفتوحِ، لا لكلِّ تصفُّحٍ. NO: الملفُّ للتحريرِ فقط ولا إقلاعَ؛ YES:
   * إيقافُ خِزاناتِ السابقِ ثمَّ فتحُ صاحبِ الملفِّ فتبدأُ دورةُ الفحصِ والتنزيلِ.
   */
  private void confirmOpenProjectForTargetFile(File projectRoot, final String projectName) {
    final String projectPath = projectRoot.getAbsolutePath();
    final File moduleDir = new File(projectRoot, almlk.AnalysisTargets.APP_MODULE);
    new AlertDialog.Builder(this)
        .setTitle(ui("dialog_open_project_title"))
        .setMessage(uiFormat("dialog_open_project_message", moduleDir.getAbsolutePath()))
        .setNegativeButton(R.string.action_no, (dialog, which) -> pendingFileSwitchPath = null)
        .setPositiveButton(
            R.string.action_yes,
            (dialog, which) -> {
              pendingFileSwitchPath = null;
              if (session != null && session.isOpen()) suspendProjectCaches(session.path());
              applyProjectOpen(projectName, projectPath);
              if (browser != null) browser.openProjectRoot(projectPath);
            })
        .setOnCancelListener(dialog -> pendingFileSwitchPath = null)
        .show();
  }

  /** هل المحرِّكُ مُسلَّحٌ لهذا الملفِّ؟ (تُستعمَلُ في اللوحةِ وعندَ اكتمالِ فتحِ المشروعِ) */
  boolean analysisArmedFor(String reference) {
    String openRoot = session != null && session.isOpen() ? session.path() : null;
    return almlk.AnalysisTargets.of(reference, openRoot).armsAnalysis();
  }

  /** سطرُ حالةٍ واحدٌ حينَ تُفتَحُ لوحةُ الأخطاءِ وهيَ غيرُ مُسلَّحةٍ: لا نافذةَ، لا مقاطعةَ للتحديثِ. */
  private void reportAnalysisGateIfNeeded() {
    if (sequentialPanels == null || analysisArmed) return;
    sequentialPanels.setSearchStatus(ui("ui_analysis_waits_for_app_file"));
  }

  private void applyProjectOpen(String name, String path) {
    maybeInitGitRepo();
    projectOpen = true;
    session.open(name, path);
    boolean hasOpenFile = editor.hasOpenFile();
    empty.setVisibility(hasOpenFile ? View.GONE : View.VISIBLE);
    editor.setVisibility(hasOpenFile ? View.VISIBLE : View.GONE);
    if (masterButton != null)
      masterButton.setVisibility(
          (hasOpenFile && masterAllowed()) ? View.VISIBLE : View.GONE);
    getActionBar().setTitle(name);
    getActionBar().setSubtitle(ui("ui_android_project_subtitle"));
    // المشروعُ المفتوحُ حديثًا لا يُعتَبَرُ نشِطًا تحليليًّا إلّا بملفٍّ جوهريٍّ مفتوحٍ فيهِ.
    String active = editor == null ? null : editor.getActiveFileReference();
    analysisArmed = analysisArmedFor(active);
    if (editor != null) editor.setAnalysisArmed(analysisArmed);
    sourceDiagnostics.clear();
    buildDiagnostics.clear();
    dependencyDiagnostics.clear();
    shadowDiagnostics.clear();
    moduleDiagnostics.clear();
    publishProjectDiagnostics(true);
    indexAndScanProject();
    // ج٤٨: أَوَّلُ نَظرَةٍ جَمعِيَّةٌ — قَبلَهَا لَا تَرَى النَّافِذَةُ إِلَّا مَا فِي التبويبِ.
    analyzerBridge().requestProjectPass();
    // M3 كالمرجع: فحص المكتبات محليًا — الموجود يُحقن بصمت، والمفقود يُنزَّل تلقائيًا بحوار التقدّم.
    File projectDir = session.directory() != null ? session.directory() : new File(path);
    dependencyCycle().start(projectDir, com.almlkid.ui.DependencyCycle.Mode.OPEN);
  }

  private com.almlkid.ui.DependencyCycle dependencyCycle() {
    if (dependencyCycle == null) {
      dependencyCycle =
          new com.almlkid.ui.DependencyCycle(
              this,
              new com.almlkid.ui.DependencyCycle.Host() {
                @Override
                public String liveText(File buildFile) {
                  if (editor == null || !editor.hasOpenFile()) return null;
                  return almlk.FileReferences.same(buildFile.getAbsolutePath(), editor.activeFileReference())
                      ? editor.getTextContent()
                      : null;
                }

                @Override
                public void publishDependencyMarkers(
                    File buildFile, String text, List<almlk.ProjectLibraries.Marker> markers) {
                  showDependencyMarkers(buildFile, text, markers);
                }

                @Override
                public void onLibrariesResolved() {
                  indexLibrariesThenScan();
                }
              });
    }
    return dependencyCycle;
  }

  /** يحوّل علامات الاعتماد إلى تشخيصات المشروع (تموّج أحمر + رسالة في اللوحة والمحرر). */
  private void showDependencyMarkers(
      File buildFile, String text, List<almlk.ProjectLibraries.Marker> markers) {
    dependencyDiagnostics.clear();
    shadowDiagnostics.clear();
    String reference = buildFile.getAbsolutePath();
    for (almlk.ProjectLibraries.Marker marker : markers) {
      CodeLanguageTools.Diagnostic diagnostic =
          CodeLanguageTools.Diagnostic.localized(
              marker.offset,
              marker.end,
              marker.line,
              marker.column,
              CodeLanguageTools.Diagnostic.Severity.ERROR,
              "MAVEN",
              marker.problem.messageKey,
              marker.problem.fallback,
              marker.problem.argument);
      ProjectDiagnostic item =
          ProjectDiagnostic.fromSource(buildFile.getName(), reference, text, diagnostic);
      if (item != null) dependencyDiagnostics.add(item);
    }
    publishProjectDiagnostics(true);
  }

  /** بعد حفظ ملف: ملف بناء داخل المشروع يعيد دورة المكتبات (بلا عمل إن لم تتغيّر البصمة). */
  private void onFileSaved(String fileName) {
    File root = session == null ? null : session.directory();
    if (root != null && fileName != null && fileName.endsWith(".xml"))
      new Thread(almlk.LibraryClassIndex::refreshProjectResources, "ProjectResources").start();
    if (root == null || !almlk.ProjectLibraries.isBuildConfiguration(fileName)) return;
    dependencyCycle().start(root, com.almlkid.ui.DependencyCycle.Mode.SAVE);

    // W21′1: المحفوظُ حقُّ المنادِينِ في علامةٍ فورًا، لا في مسحٍ قادمٍ عندَ إعادةِ فتحِ المشروعِ.
    touchDeclarationWatch();
  }

  private void openDefinition(ProjectSymbolIndex.DefinitionTarget definition) {
    if (definition == null) return;
    // بند 3 — وضع لوحة المفاتيح لا يتغير بسبب الانتقال أو القوائم.
    final boolean imeWasVisible = isImeVisible();
    // المقارنة بالاسم القصير + مرجع الجلسة الدقيق — أسماء التبويبات قد تكون مفردة (app/X.java).
    String activeName = editor == null ? null : editor.getActiveFile();
    String activeShort =
        activeName == null ? "" : activeName.substring(activeName.lastIndexOf('/') + 1);
    String activeReference = editor == null ? "" : editor.activeFileReference();
    boolean sameOpenFile = definition.fileName != null
        && (definition.fileName.equals(activeName) || definition.fileName.equals(activeShort))
        && (definition.reference == null || definition.reference.isEmpty()
            || activeReference.isEmpty() || definition.reference.equals(activeReference));
    if (definition.source == null && sameOpenFile) {
      // هذا المسار لمرجع محدد؛ تحديد التعريف نفسه يُحوَّل قبل الوصول هنا إلى قائمة الاستخدامات.
      editor.goToSymbol(definition.symbol, definition.offset);
      restoreKeyboardIfVisible(imeWasVisible);
      return;
    }
    // تبويب مفتوح آخر محتواه حي: تفعيل مباشر وقفزة على نصه — لا إعادة حقن من القرص
    // تدمّر تعديلات غير محفوظة.
    if (definition.source == null && editor != null) {
      String openTab = editor.selectIfOpenLive(definition.reference, definition.fileName);
      if (openTab != null) {
        editor.goToSymbol(definition.symbol, definition.offset);
        restoreKeyboardIfVisible(imeWasVisible);
        return;
      }
    }
    final String targetReference = definition.reference;
    browser.openDefinition(
        definition,
        (success, fileName, content, offset, message) -> {
          if (!success || fileName == null || content == null) {
            // المرجع يتنقل بصمت — التنبيه عند الفشل فقط.
            Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
            return;
          }
          String reference = targetReference == null || targetReference.isEmpty()
              ? browser.fileReference(fileName) : targetReference;
          openFile(fileName, content, reference);
          // عند تحديد مرجع، افتح التعريف وحدد الرمز؛ أما تحديد التعريف فيُحوَّل لقائمة الاستخدامات.
          editor.goToSymbol(definition.symbol, offset);
          restoreKeyboardIfVisible(imeWasVisible);
        });
  }

  private boolean isImeVisible() {
    android.graphics.Rect frame = new android.graphics.Rect();
    android.view.View decor = getWindow().getDecorView();
    decor.getWindowVisibleDisplayFrame(frame);
    int heightDiff = decor.getRootView().getHeight() - frame.bottom;
    return heightDiff > getResources().getDisplayMetrics().density * 100;
  }

  private void restoreKeyboardIfVisible(boolean wasVisible) {
    if (wasVisible && editor != null) editor.postDelayed(editor::ensureKeyboardVisible, 150);
  }

  private void findDefinitionForSelection(
      String fileName, String source, int selectionStart, int selectionEnd) {
    // المرحلة السابعة: مراجع XML تُحل من فهرس موارد المشروع، لا من محلل رموز Java.
    if (almlk.XmlCodeFormatter.isXmlName(fileName)) {
      resolveXmlResourceDefinition(source, selectionStart);
      return;
    }
    browser.findDefinitionAsync(
        fileName,
        source,
        selectionStart,
        selectionEnd,
        target -> {
          if (target == null) {
            Toast.makeText(this, ui("ui_error_definition_not_found"), Toast.LENGTH_SHORT).show();
          } else if (ProjectSymbolIndex.isDefinitionSelection(
              fileName, source, selectionStart, selectionEnd, target)) {
            findUsagesForSelection(fileName, source, selectionStart, selectionEnd);
          } else {
            openDefinition(target);
          }
        });
  }

  /** حلّ {@code @type/name} إلى ملف القيم الذي يعرّفه — فهرسة على خيط خلفي وقفزة على الرئيسي. */
  private void resolveXmlResourceDefinition(String source, int offset) {
    if (browser == null) return;
    browser.resolveXmlResourceAsync(
        source,
        offset,
        (reference, declaration) -> {
          if (reference == null) {
            Toast.makeText(this, ui("ui_xml_cursor_resource_reference"), Toast.LENGTH_SHORT)
                .show();
            return;
          }
          if (declaration == null) {
            Toast.makeText(
                    this,
                    reference.framework
                        ? uiFormat("ui_xml_framework_resource", reference.display())
                        : uiFormat("ui_xml_resource_not_found", reference.display()),
                    Toast.LENGTH_SHORT)
                .show();
            return;
          }
          openDefinition(
              new ProjectSymbolIndex.DefinitionTarget(
                  declaration.file,
                  "@" + declaration.type,
                  declaration.name,
                  null,
                  declaration.offset,
                  false,
                  declaration.file,
                  ProjectSymbolIndex.DefinitionTarget.KIND_FIELD));
        });
  }

  private void findUsagesForSelection(
      String fileName, String source, int selectionStart, int selectionEnd) {
    final String symbol = UsageSearchEngine.identifierAt(source, selectionStart, selectionEnd);
    if (symbol.isEmpty()) {
      Toast.makeText(this, ui("ui_error_symbol_selection_required"), Toast.LENGTH_SHORT).show();
      return;
    }
    showSequentialPanels(SequentialPanelHost.Panel.SEARCH);
    sequentialPanels.setSearchStatus(uiFormat("ui_search_usages_start", symbol));
    sequentialPanels.setSearchResults(Collections.emptyList(), symbol);
    browser.findUsagesAsync(
        fileName,
        source,
        selectionStart,
        selectionEnd,
        (usages, done) -> {
          if (sequentialPanels != null) {
            sequentialPanels.setSearchResults(usages, symbol);
            int count = usages == null ? 0 : usages.size();
            sequentialPanels.setSearchStatus(
                !done
                    ? uiFormat("ui_search_usages_in_progress", symbol, count)
                    : count == 0
                        ? uiFormat("ui_search_no_usages", symbol)
                        : uiFormat("ui_search_usages_found", count));
          }
        });
  }

  /**
   * M4: يبني فهرس المكتبات المحقونة (أصناف وأعضاء وR وموارد AAR) على خيط عامل، ثم يعيد فهرسة المشروع
   * وفحصه كي تُحسب التشخيصات والإكمال بالمعرفة الجديدة.
   */
  /**
   * W22/4ب٢‑ب٣: يحوّلُ حالةَ الوحداتِ المرتبطةِ إلى صفوفٍ في اللوحةِ عبرَ صانعِها: لا اسمَ
   * للطبقةِ الصافيةِ في هذا الملفِّ، ولا قرصَ — السطرُ ونصُّهُ حُمِلا وقتَ الحلِّ — ولا
   * خطأَ بناءٍ: كلُّ صفٍّ تحذيرٌ باسمِ الوحدةِ، ولا صفحةَ إدارةِ وحداتٍ ولا حوارَ «تعذّرَ
   * الحلُّ»؛ ولا دورةَ حلٍّ تُعادُ لأجلِ علامةٍ، بل العلامةُ تُرفَقُ بما ينتجُهُ الحلُّ.
   */
  private void collectModuleDiagnostics(almlk.GradleBuildModel model) {
    moduleDiagnostics.clear();
    moduleDiagnostics.addAll(
        ProjectDiagnostic.fromModuleIssues(model == null ? null : model.projectModules));
    publishProjectDiagnostics(true);
  }

  private void indexLibrariesThenScan() {
    almlk.GradleBuildModel model = dependencyCycle == null ? null : dependencyCycle.model();
    collectModuleDiagnostics(model);
    if (model == null) {
      indexAndScanProject();
      return;
    }
    // W22/4ب: الطلبُ يُبنى هناك — فلا جردَ libs/ ولا فكَّ AAR في خيطِ الواجهةِ.
    almlk.LibraryClassIndex.installAsync(
        model, com.almlkid.ui.DependencyCycle.state(), getCacheDir(),
        () -> runOnUiThread(this::indexAndScanProject));
  }

  private void indexAndScanProject() {
    if (browser == null) return;
    // W22/4ب٢‑ب٢: مصادرُ الوحداتِ المرتبطةِ خارجَ الجذرِ تُبذَرُ في المسحةِ نفسِها. الحلُّ يُترَكُ
    // لخيطِ الفهرسةِ (sourceDirs() تمسُّ القرصَ)، ولا قرصَ في خيطِ الواجهةِ؛ وبلا وحداتَ معلَنةٍ
    // يُرسَلُ مُعطِّلٌ صريحٌ فلا تُفهرَسُ شجرةٌ غريبةٌ بغيرِ دعوةٍ.
    final almlk.GradleBuildModel scanned = dependencyCycle == null ? null : dependencyCycle.model();
    browser.setLinkedSourceRoots(
        scanned == null ? null : scanned.projectRoot,
        scanned == null || scanned.projectModules == null
            ? null
            : () -> scanned.projectModules.sourceDirs());
    // W22/4ب٢‑ب٣: ومواردُ تلكَ الوحداتِ كذلكَ — نفسُ الحِلمةِ الكسولةِ، فلا ماشيَ
    // قرصٍ في خيطِ الواجهةِ، وبلا مُعطِّلٍ صريحٍ تُهمَلُ الشجرةُ الغريبةُ.
    browser.setLinkedResourceRoots(
        scanned == null ? null : scanned.projectRoot,
        scanned == null || scanned.projectModules == null
            ? null
            : () -> scanned.projectModules.resourceRoots());
    // R6: the errors saved by the last scan appear at once, before the index is even built.
    browser.restoreProjectDiagnostics(projectScanListener);
    // الجولةُ ٣٨: المسحُ العامُّ يَنطلِقُ معَ الفتحِ لا بعدَهُ — خيوطُهُ الأربَعُ تعملُ والفهرسُ يُبنى
    // مَعَها، والمفتوحُ ومكتباتُهُ في أوَّلِ الطابورِ. وإن لم يكنِ الكتالوجُ دافئًا جُمِعَ الطلبُ في
    // قَفزةٍ واحدةٍ إلى آخِرِ مُسمًّى (لا ضِعفَ عملٍ على الفتحِ نفسِهِ)، ثمَّ تُعادُ الجولةُ بعدَ الفهرسِ
    // حينَ يصيرُ الجزمُ بالمَغيوبِ مُمكنًا.
    scanProjectDiagnostics();
    browser.indexProjectSymbols(
        () -> {
          if (editor != null) editor.refreshSemanticDiagnostics();
          scanProjectDiagnostics();
        });
  }

  /** Project scan results: partial batches while it runs, then the complete picture. */
  private final BrowserPager.ProjectDiagnosticsListener projectScanListener =
      new BrowserPager.ProjectDiagnosticsListener() {
        @Override
        public void completed(List<ProjectDiagnostic> found) {
          sourceDiagnostics.clear();
          if (found != null) sourceDiagnostics.addAll(found);
          refreshShadowNotices();
          publishProjectDiagnostics(true);
          if (editor != null) editor.refreshSemanticDiagnostics();
          // W21′1: كلُّ ملفٍّ أعيدَ تسجيلُهُ في المسحِ مرَّ ببصمةِ تعريفاتِهِ — فليُعادَ فحصُ منادِيهِ.
          touchDeclarationWatch();
        }

        @Override
        public void progress(List<ProjectDiagnostic> found) {
          applyPartialScan(found);
        }
      };

  /**
   * R6: a partial scan replaces the project findings, except the active file's — the editor's
   * live check of the text being typed is newer than any scan of the saved file.
   */
  private void applyPartialScan(List<ProjectDiagnostic> found) {
    String active = editor != null ? editor.getActiveFileReference() : "";
    ArrayList<ProjectDiagnostic> live = new ArrayList<>();
    if (active != null && !active.isEmpty())
      for (ProjectDiagnostic item : sourceDiagnostics)
        if (item != null && almlk.FileReferences.same(active, item.reference)) live.add(item);
    sourceDiagnostics.clear();
    if (found != null)
      for (ProjectDiagnostic item : found) {
        if (item == null) continue;
        if (!live.isEmpty() && almlk.FileReferences.same(active, item.reference)) continue;
        sourceDiagnostics.add(item);
      }
    sourceDiagnostics.addAll(live);
    refreshShadowNotices();
    publishProjectDiagnostics(false);
  }

  /** {@code symbol} في صفوفِ الظلالِ — علامةٌ تُميِّزُها فلا تُمسُّ بمسحِ ملفٍّ أو إعادةِ فحصٍ. */
  static final String SHADOW_ROW = "shadowed-definition";

  /**
   * W21′2 — ما رفضَهُ الفهرسُ لأنَّهُ يُعيدُ تعريفَ صنفٍ تملِكُهُ المنصّةُ أو مكتبةٌ لا يُترَكُ
   * صامتًا: يظهرُ خطأٌ على ملفِّهِ نفسِهِ في اللوحةِ، وإلا بقيَ في ذهنِ القارئِ أنَّ أسطُرًا
   * قليلةً نُسِخَت عن {@code android.content.Context} مكتبةٌ مثبّتةٌ أو أنَّ المشروعَ سليمٌ.
   * تُبدَّلُ القائمةُ كلُّها بعدَ كلِّ مسحٍ: تظهَرُ بظهورِ سببِها وتزولُ بزوالِهِ، ولا تُعادُ مع
   * النشرِ الخفيفِ بينَ دفعةٍ وأخرى، ولا تُمسُّ صفوفُ غيرِها.
   */
  private void refreshShadowNotices() {
    shadowDiagnostics.clear();
    for (Map.Entry<String, String> item : ProjectSymbolIndex.shadowedDefinitions()) {
      if (item == null || item.getKey() == null || item.getKey().isEmpty()) continue;
      String reference = item.getKey();
      String shown = reference.substring(reference.lastIndexOf('/') + 1);
      if (shown.isEmpty()) shown = reference;
      CodeLanguageTools.Diagnostic found =
          CodeLanguageTools.Diagnostic.localized(
              0,
              1,
              1,
              1,
              CodeLanguageTools.Diagnostic.Severity.ERROR,
              almlk.JavaDiagnosticCodes.UNCLASSIFIED,
              "ui_shadow_file_ignored",
              "%1$s re-declares %2$s, which belongs to the platform or a library: this file is not "
                  + "that type's definition, so it is not indexed as one.",
              shown,
              item.getValue() == null ? "" : item.getValue());
      ProjectDiagnostic row =
          ProjectDiagnostic.restored(shown, reference, "", SHADOW_ROW, 1, found);
      if (row != null) shadowDiagnostics.add(row);
    }
  }

  private void scanProjectDiagnostics() {
    if (browser == null) return;
    browser.setDiagnosticsPriority(editor != null ? editor.getActiveFileReference() : null);
    browser.scanProjectDiagnosticsAsync(projectScanListener);
  }

  /**
   * سقفُ إعادةِ الفحصِ الموضعيّةِ في مسارِها الواحدِ: بعدَ إصلاحٍ (W20′2) وبعدَ تغيّرِ تعريفٍ (W21′1) —
   * حتى لا ينقلبَ إصلاحٌ واحدٌ أو حذفُ عضوٍ واحدٍ مسحًا للمشروعِ كلِّهِ.
   */
  private static final int MAX_DEPENDENT_REINSPECTIONS = 8;

  /**
   * W20′2 — أثرُ الإصلاحِ موضعيٌّ: يُعادُ فحصُ الملفِّ النشِطِ من المحرِّرِ نفسِهِ (فحصُهُ الحيُّ يملكُ
   * علاماتِهِ ولا يُنشرُ من غيرِهِ لئلا يتعارَضا)، ثمَّ تُعادُ قراءةُ الملفاتِ التي يَتغيَّرُ حكمُها
   * وحدَها: الملفُّ الذي عُدِّلَ إن كانَ تبويبًا خاملًا، وكلُّ ملفٍّ في اللوحةِ يُلومُ نفسَ الرمزِ
   * (مواضعُ نداءٍ أخرى لدالةٍ أُنشِئَت الآنَ). تُبدَّلُ نتائجُ تلكَ الملفاتِ في اللوحةِ بصفوفِها من
   * مكانِها بنشرٍ خفيفٍ — لا إغلاقَ للوحةِ ولا إعادةَ صفحةٍ ولا مسحَ للمشروعِ كلِّهِ، وعلاماتُ غيرِها
   * باقيةٌ كما هي. المصدرُ الحيُّ للتبويبِ مقدَّمٌ على القرصِ فلا تُقرأ نسخةٌ قديمةٌ عن تعديلٍ لم يُحفَظْ.
   */
  private void reinspectAfterQuickFix(almlk.QuickFix fix, String editedFile) {
    if (editor != null) editor.reinspectActiveFileDiagnostics();
    final ArrayList<BrowserPager.Reinspection> probes = new ArrayList<>();
    HashSet<String> seen = new HashSet<>();
    String active = editor == null ? null : editor.getActiveFile();
    String activeReference = editor == null ? null : editor.getActiveFileReference();
    addReinspectionProbe(probes, seen, editedFile, active, activeReference);
    String blamed =
        fix == null
            ? ""
            : (fix.methodName == null || fix.methodName.isEmpty() ? fix.targetClass : fix.methodName);
    if (blamed != null && !blamed.isEmpty()) {
      for (ProjectDiagnostic item : new ArrayList<>(sourceDiagnostics)) {
        if (probes.size() >= MAX_DEPENDENT_REINSPECTIONS) break;
        if (item == null || item.fromBuild) continue;
        if (blamed.equals(item.symbol)
            || (item.diagnostic != null
                && item.diagnostic.message != null
                && item.diagnostic.message.contains(blamed)))
          addReinspectionProbe(probes, seen, item.fileName, active, activeReference);
      }
    }
    reinspectProbes(probes);
  }

  /**
   * الحشدُ الواحدُ لكلِّ إعادةِ فحصٍ موضعيّةٍ (مسارُ الإصلاحِ ومسارُ المنادِينِ معًا): تُبدَّلُ نتائجُ
   * الملفاتِ المذكورةِ في اللوحةِ بصفوفِها من مكانِها بنشرٍ خفيفٍ — لا إغلاقَ للوحةِ ولا إعادةَ صفحةٍ ولا
   * مسحَ للمشروعِ كلِّهِ، فعلاماتُ غيرِها باقيةٌ كما هي فلا وميضَ بينَ جولةٍ وأختِها.
   */
  private void reinspectProbes(final ArrayList<BrowserPager.Reinspection> probes) {
    if (browser == null || probes.isEmpty()) {
      publishProjectDiagnostics();
      return;
    }
    browser.reinspectFilesAsync(
        probes,
        new BrowserPager.ProjectDiagnosticsListener() {
          @Override
          public void completed(List<ProjectDiagnostic> found) {
            for (BrowserPager.Reinspection probe : probes)
              removeDiagnosticsForFile(sourceDiagnostics, probe.fileName, probe.reference);
            if (found != null)
              for (ProjectDiagnostic item : found)
                if (item != null) sourceDiagnostics.add(item);
            publishProjectDiagnostics();
          }

          @Override
          public void progress(List<ProjectDiagnostic> found) {
            // ملفاتٌ معدودةٌ تُفحصُ دفعةً واحدةً: لا شيءَ بينَ البدءِ والاكتمالِ.
          }
        });
  }

  /** ملفٌّ يستحقُّ إعادةَ فحصٍ: حيٌّ غيرُ النشِطِ، بمرجعِهِ ومحتواهُ الحيِّ (null تُقرأُ من القرصِ). */
  private void addReinspectionProbe(
      ArrayList<BrowserPager.Reinspection> probes,
      HashSet<String> seen,
      String fileName,
      String activeFile,
      String activeReference) {
    if (fileName == null || fileName.isEmpty() || probes.size() >= MAX_DEPENDENT_REINSPECTIONS) return;
    if (fileName.equals(activeFile)) return;
    String reference = browser == null ? "" : browser.fileReference(fileName);
    if (reference == null || reference.isEmpty()) reference = fileName;
    if (activeReference != null && almlk.FileReferences.same(activeReference, reference)) return;
    String live = editor == null ? null : editor.tabContent(fileName);
    // لا نصَّ حيَّ ولا موضعٌ معروفٌ في الفهرسِ: الملفُّ لا يُسبارُ، فتبقى علاماتُهُ كما هي بدلَ أن
    // تُمحَا بمسحٍ لا يردُّ عليهِ شيءٌ (كذبُ الصمتِ).
    if (live == null && browser != null && !browser.hasFileEntry(fileName, reference)) return;
    if (!seen.add(almlk.FileReferences.normalize(reference))) return;
    probes.add(new BrowserPager.Reinspection(fileName, reference, live));
  }

  // ───────────────── W21′1 — مواكبةُ المنادِينِ: حذفُ عضوٍ يُعيدُ وسمَ كلِّ من ناداهُ ─────────────────

  /** تجميعُ بُرقةِ تغيّرِ التعريفاتِ (خمولٌ 350م.ث، سقفٌ 1200م.ث) — منطقُهُ كلُّهُ صافٍ في almlk/. */
  private final almlk.DeclarationWatch declarationWatch = new almlk.DeclarationWatch();
  private boolean dependentSweepScheduled;
  /** ما عُولِجَ من البُرقةِ الجاريةِ وجولتُها: الحدُّ لا يتركُ منادِيًا بلا حكمٍ في بُرقةٍ واحدةٍ. */
  private final ArrayList<String> dependentSweepSkip = new ArrayList<>();
  private int dependentSweepRound;
  private static final int MAX_DEPENDENT_SWEEP_ROUNDS = 4;
  private final android.os.Handler dependentSweepHandler =
      new android.os.Handler(android.os.Looper.getMainLooper());
  private final Runnable dependentSweep =
      new Runnable() {
        @Override
        public void run() {
          runDependentSweep();
        }
      };

  /**
   * إعلانٌ بأنَّ الفهرسَ يحملُ تغيّرَ تعريفٍ لم تُواكََبْ بعدُ: يُسلَّمُ إلى التجميعِ ويُجدَّلُ لهُ موعدٌ.
   * لا عملَ لهُ إن لم يترقّبْ شيئًا، فلا ضجيجَ مع كلِّ ضغطةِ مفتاحٍ ولا فحصَ لمنادٍ لم يتغيّرْ عقدُهُ.
   */
  private void touchDeclarationWatch() {
    if (!ProjectSymbolIndex.hasPendingDeclarationChanges()) return;
    long now = android.os.SystemClock.uptimeMillis();
    long deadline = declarationWatch.offer(now, ProjectSymbolIndex.pendingMemberNames());
    if (dependentSweepScheduled || deadline <= 0L) return;
    dependentSweepScheduled = true;
    dependentSweepHandler.postDelayed(dependentSweep, Math.max(0L, deadline - now));
  }

  /**
   * W21′1 — المنادُون يجبُ أن يُجابُوا عن الحالةِ التي على الشاشةِ لا عن نسخةِ القرصِ: إن حُذِفَت دالةٌ
   * من صنفِها وجبَ أن يعودَ الخطأُ إلى كلِّ ملفٍّ ناداها في اللحظةِ نفسِها، وإلّا بقِيَ «لا خطأَ» كذبًا —
   * وهو ما بلّغَ عنهُ المستخدمُ. ثلاثُ خطواتٍ لا رابعَ لها: (1) ائتمانُ الفهرسِ بنصِّ التبويبِ الحيِّ
   * للصنفِ الذي تغيّرَ عقدُهُ — كفعلِ المرجعِ إذْ يُطعَمُ التعديلَ ثمَّ يُجيبُ الاستعلامُ، (2) استخراجُ
   * الملفَّاتِ الأخرى التي تذكرُ أسماءَ الأعضاءِ المتغيّرةِ من الفهرسِ نفسِهِ (لا اسمَ الصنفِ: المنادِي
   * لم يكتبْهُ)، (3) إعادةُ فحصِها عبرَ حشدِ اللوحةِ القائمِ (reinspectProbes) بتقديمِ التبويباتِ
   * المفتوحةِ. النشرُ خفيفٌ، ووسومُ غيرِ الملفَّاتِ المعدودةِ تبقى في مكانِها.
   */
  private void runDependentSweep() {
    dependentSweepScheduled = false;
    long now = android.os.SystemClock.uptimeMillis();
    if (!declarationWatch.due(now)) {
      long left = declarationWatch.delayFor(now);
      if (left > 0L && declarationWatch.pending() && !dependentSweepScheduled) {
        dependentSweepScheduled = true;
        dependentSweepHandler.postDelayed(dependentSweep, left);
      }
      return;
    }
    final ArrayList<String> names = declarationWatch.takeNames();
    ArrayList<String> changedFiles =
        ProjectSymbolIndex.drainPendingDeclarationFiles(MAX_DEPENDENT_REINSPECTIONS);
    ProjectSymbolIndex.clearPendingDeclarationChanges();
    if (names.isEmpty() || changedFiles.isEmpty()) return;
    for (String changed : changedFiles) {
      String live = editor == null ? null : editor.tabContent(changed);
      // لا معلَّقَ في التبويبِ: القرصُ هو المثبَّتُ في الفهرسِ فعلًا، فلا شيءَ ليؤتمَنَ عليهِ
      if (live == null) continue;
      String reference = browser == null ? changed : browser.fileReference(changed);
      ProjectSymbolIndex.registerSource(
          changed, reference == null || reference.isEmpty() ? changed : reference, live);
    }
    // (2) المنادُون على خيطِ الفحصِ، ثمَّ (3) إعادةُ فحصِهم من هنا عندَ العودةِ إلى الواجهةِ.
    final ArrayList<String> wanted =
        names.size() > MAX_DEPENDENT_REINSPECTIONS
            ? new ArrayList<>(names.subList(0, MAX_DEPENDENT_REINSPECTIONS))
            : names;
    if (browser == null) return;
    browser.findDependentsAsync(
        wanted,
        MAX_DEPENDENT_REINSPECTIONS,
        dependentSweepRound == 0 ? null : new ArrayList<>(dependentSweepSkip),
        new BrowserPager.DependentsListener() {
          @Override
          public void found(ArrayList<BrowserPager.Reinspection> dependents) {
            reinspectDependents(wanted, dependents);
          }
        });
  }

  /**
   * التبويباتُ المفتوحةُ أولًا (محتواها الحيُّ يُبدَّلُ بمحتواها لا بنسخةِ القرصِ في addReinspectionProbe)،
   * والملفُّ النشِطُ لا يُسبارُ من هنا لأنَّ فحصَهُ الحيَّ يملكُ علاماتِهِ. لا شيءَ هنا يمسُّ المؤشّرَ ولا
   * المنظرَ: قراءةٌ ونشرٌ في مكانِهما.
   */
  private void reinspectDependents(ArrayList<String> wanted, ArrayList<BrowserPager.Reinspection> dependents) {
    if (dependents == null || dependents.isEmpty()) {
      dependentSweepSkip.clear();
      dependentSweepRound = 0;
      return;
    }
    ArrayList<BrowserPager.Reinspection> probes = new ArrayList<>();
    HashSet<String> seen = new HashSet<>();
    String active = editor == null ? null : editor.getActiveFile();
    String activeReference = editor == null ? null : editor.getActiveFileReference();
    for (int pass = 0; pass < 2; pass++) {
      for (BrowserPager.Reinspection item : dependents) {
        if (item == null) continue;
        boolean open = editor != null && editor.tabContent(item.fileName) != null;
        if ((pass == 0) != open) continue;
        addReinspectionProbe(probes, seen, item.fileName, active, activeReference);
        if (item.reference != null && !item.reference.isEmpty() && !dependentSweepSkip.contains(item.reference))
          dependentSweepSkip.add(item.reference);
      }
    }
    reinspectProbes(probes);
    // الحدُّ يعني أنَّ المرشَّحاتِ لم تنفدْ: جولةٌ أخرى من البُرقةِ نفسِها تُكملُ الطابورَ بمنادِينِ جُددٍ،
    // وحدُّ الجولاتِ يبقي الحدَّ الأعلى معروفًا (4 جولاتٍ × 8 ملفاتٍ) ثمَّ يُولّي المسحُ الشاملُ الحكمَ
    // عندَ الفتحِ أو التحديثِ — لا سكوتٌ عن منادٍ بقيَ بلا فحصٍ ولا ادّعاءٌ بأنَّ الشيءَ تمَّ.
    if (dependents.size() >= MAX_DEPENDENT_REINSPECTIONS
        && dependentSweepRound < MAX_DEPENDENT_SWEEP_ROUNDS) {
      dependentSweepRound++;
      long at =
          declarationWatch.offer(
              android.os.SystemClock.uptimeMillis(),
              wanted == null ? java.util.Collections.<String>emptyList() : wanted);
      if (at > 0L && !dependentSweepScheduled) {
        dependentSweepScheduled = true;
        dependentSweepHandler.postDelayed(
            dependentSweep, Math.max(0L, at - android.os.SystemClock.uptimeMillis()));
      }
    } else {
      dependentSweepSkip.clear();
      dependentSweepRound = 0;
    }
  }

  private void onEditorFileChanged(String fileName, String reference) {
    // M3: علامات الاعتماد تُعاد من النص الحي (تتبع الأسطر) بدل الإزالة.
    if (dependencyCycle != null) dependencyCycle.onEditorTextChanged(reference);
    boolean removed = removeDiagnosticsForFile(sourceDiagnostics, fileName, reference);
    removed |= removeDiagnosticsForFile(buildDiagnostics, fileName, reference);
    if (removed) publishProjectDiagnostics();
    // ‏1.0.198: نَفسُ الإِشارَةِ تَذهَبُ لِلوَحدَةِ — تَرَدُّدُ المَكتَبَةِ (‏250ms‏) يُجَدوِلُها،
    // وَالحَصرُ عِندَهَا: صِفْرُ فَحصٍ عَلَى خَيطِ الوَاجِهَةِ، وَلا قُفلَ عَلَى المُحرِّرِ.
    analyzerBridge().onEditorSignal(fileName, reference);
    // ج٤٨: الفَحصُ الجَمعِيُّ يُجَدوَلُ هُنَا أَيْضًا — المَمَرُّ نَفسُهُ يَرفُضُ التَّكرَارَ قَبلَ
    // أَربَعِ ثَوَانٍ، فَإِن كَثُرَتِ الإِشَارَاتُ اِنقَبَضَت عَلى قُفلٍ وَاحدٍ لَا عَلى طَابُورٍ.
    analyzerBridge().requestProjectPass();
  }

  private void onEditorDiagnostics(
      String fileName,
      String reference,
      String source,
      List<CodeLanguageTools.Diagnostic> found) {
    removeDiagnosticsForFile(sourceDiagnostics, fileName, reference);
    if (found != null) {
      for (CodeLanguageTools.Diagnostic diagnostic : found) {
        ProjectDiagnostic item =
            ProjectDiagnostic.fromSource(fileName, reference, source, diagnostic);
        if (item != null) sourceDiagnostics.add(item);
      }
    }
    publishProjectDiagnostics();

    // W21′1: تغيّرُ تعريفٍ في هذا الملفِ يُعلَنُ هنا، فتتولّاهُ دورةُ المنادِينِ المجمَّعةُ.
    // W27/3 (‏1.0.180): الفوريّةُ التي طلبَها الملحقُ — لا انتظارَ لفتحِ اللوحةِ. والكبتُ ببصمةِ
    // (الملفِّ + الصنفِ + الدوالِّ) في الطبقةِ الصافيةِ، فلا رَجَّةَ «توستٍ» معَ كلِّ ضغطةِ مفتاحٍ،
    // ولا مَرَّ ثانٍ على الشجرةِ إن لم يَكُنْ في الرَّدِّ تشخيصُنا أصلًا.
    if (almlk.AbstractImplementationGap.hasGapDiagnostic(found)) {
      String gapFile = reference == null || reference.isEmpty() ? fileName : reference;
      almlk.AbstractImplementationGap.Announcement note =
          almlk.AbstractImplementationGap.announcement(source, announcedGaps.get(gapFile));
      if (note != null) {
        announcedGaps.put(gapFile, note.fingerprint);
        Toast.makeText(this, uiFormat(note.messageKey, note.args()), Toast.LENGTH_LONG).show();
      }
    }

    touchDeclarationWatch();
  }

  /** بصمةُ ما أُعلِنَ لكلِّ ملفٍّ: حقلٌ واحدٌ لا لوحةَ حالةٍ (‏W27/3). */
  private final java.util.HashMap<String, String> announcedGaps =
      new java.util.HashMap<String, String>();

  private boolean removeDiagnosticsForFile(
      ArrayList<ProjectDiagnostic> values, String fileName, String reference) {
    String shortName = fileName == null ? "" : fileName.substring(fileName.lastIndexOf('/') + 1);
    boolean removed = false;
    for (int i = values.size() - 1; i >= 0; i--) {
      ProjectDiagnostic item = values.get(i);
      if (item == null) {
        values.remove(i);
        removed = true;
        continue;
      }
      boolean sameReference =
          almlk.FileReferences.same(reference, item.reference);
      boolean sameName =
          (item.fileName.equals(fileName) || item.fileName.equals(shortName))
              && (reference == null || reference.isEmpty() || item.reference.isEmpty());
      if (sameReference || sameName) {
        values.remove(i);
        removed = true;
      }
    }
    return removed;
  }

  /** تحديث خفيف بعد تغيّر ملف واحد (المرجع MainActivity.j6(String) ← ErrorBrowser.Hw). */
  private void publishProjectDiagnostics() {
    publishProjectDiagnostics(false);
  }

  /**
   * ينشر لقطة التشخيصات للمحرر واللوحة والشارة. {@code complete}: اكتمل تحليل/حلّ/بناء (المرجع
   * MainActivity.j6() ← ErrorBrowser.FH) فتُعاد صفحة الأخطاء كاملة؛ وإلا فالتحديث الخفيف.
   */
  private void publishProjectDiagnostics(boolean complete) {
    if (paintOwner == Thread.currentThread()) {
      paintAgain = true;
      if (complete) paintAgainComplete = true;
      return;
    }
    paintOwner = Thread.currentThread();
    try {
      paintProjectDiagnostics(complete);
      while (paintAgain) {
        boolean whole = paintAgainComplete;
        paintAgain = false;
        paintAgainComplete = false;
        paintProjectDiagnostics(whole);
      }
    } finally {
      paintAgain = false;
      paintAgainComplete = false;
      paintOwner = null;
    }
  }

  /**
   * جِسمُ الرَّسمِ: لَا يُنادَىٰ إِلَّا مِن بَابِهِ أَعۡلَاهُ — فَلا رَسمَ دَاخِلَ رَسمٍ، وَلَا
   * طَرِيقٌ يَتَجَاوَزُ الحَارِسَ (هٰذَا مَا أَقعَدَ ج٥٤: كُلُّ حَارِسٍ كَانَ يَعرِفُ طَرِيقًا).
   */
  private void paintProjectDiagnostics(boolean complete) {
    LinkedHashMap<String, ProjectDiagnostic> unique = new LinkedHashMap<>();
    for (ProjectDiagnostic item : sourceDiagnostics) {
      if (item == null) continue;
      String key = diagnosticMergeKey(item);
      if (!unique.containsKey(key)) unique.put(key, item);
    }
    for (ProjectDiagnostic item : buildDiagnostics) {
      if (item == null) continue;
      String key = diagnosticMergeKey(item);
      if (!unique.containsKey(key)) unique.put(key, item);
    }
    for (ProjectDiagnostic item : dependencyDiagnostics) {
      if (item == null) continue;
      String key = diagnosticMergeKey(item);
      if (!unique.containsKey(key)) unique.put(key, item);
    }
    for (ProjectDiagnostic item : shadowDiagnostics) {
      if (item == null) continue;
      String key = diagnosticMergeKey(item);
      if (!unique.containsKey(key)) unique.put(key, item);
    }
    for (ProjectDiagnostic item : moduleDiagnostics) {
      if (item == null) continue;
      String key = diagnosticMergeKey(item);
      if (!unique.containsKey(key)) unique.put(key, item);
    }
    // ‏1.0.198 (ج٤٧): الصَّفُّ السَّادسُ — وَحدَةُ الفَحصِ وَالرَّسمِ. تَسبِقُهَا سِيَاسَةُ التَّرجُّلِ
    // (نَحوٌ مَكتوبٌ عِندَ مُحرِّكِنَا فِي السَّطرِ نَفسِهِ لَا يُكرَرُ)، ثُمَّ تَدخُلُ بِمِفتاحِ
    // دَمجِهِم جَميعًا: فَلا نَافِذَةَ ثَانِيَةً، وَلَا وِسمَ ثَانِيًا، وَلَا شَارَةً تَعدُّ مَرَّتَينِ.
    for (ProjectDiagnostic item :
        almlk.AnalyzerErrorUnit.suppressSyntaxOverlaps(
            new ArrayList<>(unique.values()), almlk.AnalyzerErrorUnit.rows())) {
      if (item == null) continue;
      String key = diagnosticMergeKey(item);
      if (!unique.containsKey(key)) unique.put(key, item);
    }
    displayedDiagnostics.clear();
    displayedDiagnostics.addAll(unique.values());
    displayedDiagnostics.sort(
        (a, b) -> {
          int file = a.groupKey().compareToIgnoreCase(b.groupKey());
          if (file != 0) return file;
          int line = Integer.compare(a.diagnostic.line, b.diagnostic.line);
          return line != 0 ? line : Integer.compare(a.diagnostic.column, b.diagnostic.column);
        });
    if (editor != null) editor.setProjectDiagnostics(displayedDiagnostics);
    // تحديث خفيف كالمرجع: الصفوف لا تُعاد إلا إذا تغيّر العدد وكان أقل من 100.
    if (sequentialPanels != null) {
      if (complete) sequentialPanels.setProjectDiagnostics(displayedDiagnostics);
      else sequentialPanels.updateProjectDiagnostics(displayedDiagnostics);
    }
    refreshErrorBadge();
  }

  /** يحدّث رقم الشارة، ويعيد بناء القائمة فقط حين تنقلب أهلية ظهورها. */
  private void refreshErrorBadge() {
    int count = SequentialPanelHost.countErrors(displayedDiagnostics);
    boolean visible =
        almlk.ErrorCountBadge.visibleFor(count, getResources().getConfiguration().screenWidthDp);
    if (errorBadge != null) errorBadge.setCount(count);
    if (visible != errorBadgeVisible) invalidateOptionsMenu();
  }

  @Override
  public void onConfigurationChanged(android.content.res.Configuration newConfig) {
    super.onConfigurationChanged(newConfig);
    // المانيفست يحتفظ بالنشاط عند التدوير؛ عرض الشاشة يغيّر أهلية الشارة.
    refreshErrorBadge();
  }

  /**
   * عبارةُ الفشلِ كما نَطَقَها المرجعُ: ‏{@code path + " could not be loaded!"} — بالمسارِ الكاملِ إن
   * وُجِدَ وإلا بالاسمِ. لا نُضيفُ «تعذَّرَ» ولا نُقصِرُ المسارَ: البندُ 2/5 يُثبِتُ المطابقةَ لا التشابهَ.
   */
  private String notLoadedText(String reference, String fileName) {
    String path = reference == null || reference.isEmpty() ? String.valueOf(fileName) : reference;
    return UiStrings.format(this, "ui_error_file_not_loaded", path);
  }

  private String diagnosticMergeKey(ProjectDiagnostic item) {
    String owner = item.reference.isEmpty() ? item.fileName : almlk.FileReferences.normalize(item.reference);
    String point = item.symbol.isEmpty()
        ? item.diagnostic.code + "|" + String.valueOf(item.diagnostic.message)
        : item.symbol;
    return owner + "|" + item.diagnostic.line + "|" + item.diagnostic.column + "|" + point;
  }

  private void openProjectDiagnostic(ProjectDiagnostic diagnostic) {
    openProjectDiagnostic(diagnostic, false);
  }

  /**
   * فتح/تفعيل ملف التشخيص ثم تحديد **مداه الكامل** والتمرير إليه وإغلاق اللوحة (المرجع
   * MainActivity.j6(Tl)). مع {@code showActions} (الضغط المطوّل) يفتح شريط «تحديد الإجراءات».
   */
  private void openProjectDiagnostic(ProjectDiagnostic diagnostic, boolean showActions) {
    if (diagnostic == null || diagnostic.diagnostic == null || editor == null) return;
    int line = Math.max(1, diagnostic.diagnostic.line);
    int column = Math.max(1, diagnostic.diagnostic.column);
    int endColumn = Math.max(column + 1, diagnostic.endColumn);
    // W27/2 (ملحقُ ‏W27/2): «حدِّدِ الرمزَ المُخطِئَ» — المَدى الأوسعُ من رمزٍ يُضيَّقُ إلى المُعرِّفِ عندَ
    // البدايةِ في المحرِّرِ، ويبقى مَداها هو المُستَعمَلَ للفقاعةِ وشريطِ الإجراءاتِ. القرارُ في الطبقةِ
    // الصافيةِ (سقفٌ مُعلَنٌ) لا هُنا، فلا يُترَكُ حُكمُ العرضِ بلا قياسٍ.
    boolean tokenOnly = almlk.ErrorBrowserPolicy.narrowsToToken(column, endColumn);
    String tab = editor.activateTabByReference(diagnostic.reference, diagnostic.fileName);
    if (tab != null) {
      editor.goToDiagnostic(tab, line, column, endColumn, showActions, tokenOnly);
      closeSequentialPanels();
      return;
    }
    if (browser == null) return;
    UsageSearchEngine.Usage target =
        new UsageSearchEngine.Usage(
            diagnostic.fileName,
            diagnostic.reference,
            Math.max(0, diagnostic.diagnostic.offset),
            line,
            column,
            endColumn,
            diagnostic.preview,
            "diagnostic");
    browser.openUsageAsync(
        target,
        (success, fileName, content, offset, message) -> {
          if (!success || fileName == null || content == null) {
            Toast.makeText(
                    this, notLoadedText(diagnostic.reference, diagnostic.fileName),
                    Toast.LENGTH_SHORT)
                .show();
            return; // اللوحةُ مفتوحةٌ: يُعادُ النقرُ محاولةَ قراءةٍ جديدةً لا مشاهدةَ عطلٍ قديمٍ
          }
          openFile(fileName, content, browser.fileReference(fileName));
          String active = editor.getActiveFile();
          if (active != null)
            editor.goToDiagnostic(active, line, column, endColumn, showActions, tokenOnly);
          closeSequentialPanels();
        });
  }

  /**
   * نقر **رأس الملف** في متصفح الأخطاء (W2، مطابق للمرجع): يفتح الملف عند أول سطر **بلا تحديد ولا
   * شريط إجراءات** — المرجع يبني للترويسة {@code Tl(path,1,1,1,1)} لا أول خطأ. الملف المفتوح يُفعَّل
   * ويُمرَّر إلى أعلاه، وغير المفتوح يُحمَّل عبر المتصفح ثم تُنفَّذ القفزة بعد اكتمال التحميل الكسول.
   */
  private void openErrorFileRow(String reference, String fileName) {
    if (editor == null || reference == null || reference.isEmpty()) return;
    String tab = editor.activateTabByReference(reference, fileName);
    if (tab != null) {
      editor.goToDiagnostic(tab, 1, 1, 1, false);
      closeSequentialPanels();
      return;
    }
    if (browser == null) return;
    // صفُّ ترويسةِ الملفِّ الخاطئِ لا مَدَى لَهُ: موقعٌ واحدٌ بلا تحديدٍ، كقاعدةِ المرجعِ الفارغةِ.
    UsageSearchEngine.Usage target =
        new UsageSearchEngine.Usage(fileName, reference, 0, 1, 1, 1, "", "error-file-header");
    browser.openUsageAsync(
        target,
        (success, name, content, offset, message) -> {
          if (!success || name == null || content == null) {
            Toast.makeText(this, notLoadedText(reference, fileName), Toast.LENGTH_SHORT).show();
            return; // صفُّ الترويسةِ لم يَفُحْ له محتوى: اللوحةُ تبقى كما هي
          }
          openFile(name, content, browser.fileReference(name));
          String active = editor.getActiveFile();
          if (active != null) editor.goToDiagnostic(active, 1, 1, 1, false);
          closeSequentialPanels();
        });
  }


  private void showSequentialPanels(SequentialPanelHost.Panel initial) {
    if (sequentialPanels == null) return;
    sequentialPanels.setProjectDiagnostics(displayedDiagnostics);
    sequentialPanels.showPage(initial == null ? SequentialPanelHost.Panel.ERRORS : initial);
    if (drawer != null && !drawer.isDrawerOpen(Gravity.START)) drawer.openDrawer(Gravity.START);
  }

  private void closeSequentialPanels() {
    if (drawer != null && drawer.isDrawerOpen(Gravity.START)) drawer.closeDrawer(Gravity.START);
  }

  private void showPanel(SequentialPanelHost.Panel panel) {
    showSequentialPanels(panel);
  }

  /** المرحلة 3: منفّذ الإصلاح السريع (تأكيد «تعديل الملفات» ثم التعديل وفتح الدالة المنشأة). */
  private final almlk.QuickFixExecutor quickFixExecutor =
      new almlk.QuickFixExecutor(
          new almlk.QuickFixExecutor.Host() {
            @Override
            public android.app.Activity activity() {
              return MainActivity.this;
            }

            @Override
            public com.almlkid.ui.AIDEEditorPager editor() {
              return editor;
            }

            @Override
            public com.almlkid.ui.browsers.BrowserPager browser() {
              return browser;
            }

            @Override
            public void quickFixApplied(almlk.QuickFix fix, String editedFile) {
              reinspectAfterQuickFix(fix, editedFile);
            }

            /** 1.0.175: «Fetch library» من التشخيصِ — مسارٌ صامتٌ بلا حوارٍ وبلا بناءٍ. */
            @Override
            public boolean fetchDependency(almlk.QuickFix fix) {
              return startDependencyFetch(fix);
            }

            /**
             * ‏1.0.197: «‏Create class 'X'‏» — صَفٌّ يَكتُبُ مِلَفًّا، فَالمَوضِعُ وَالقُدرَةُ عَلى
             * الكِتابَةِ تُقرَآنِ مِنَ التابِ الحَيِّ لا مِنَ الفَحصِ (لا يَرى نَفسَهُ مُجَلَّدًا).
             * المُجَلَّدُ هُوَ أَبُ المِلَفِّ الحَامِلِ لِذلِكَ المَجهُولِ — وَهُوَ سَوَاءُ باقَتِهِ،
             * وَإلّا تَركَ المُتَصَفِّرُ الصَّفَّ يَرذُلُ. وَالخَبَرُ بَعدَ الكِتابَةِ: إِعادَةُ فَحصٍ
             * مَوضِعِيَّةٌ تُميطُ كُلَّ صَفٍّ لَوَّمَ ذَاكَ الاسمَ، فَيَكُونُ الأَثَرُ مَرئِيًّا فِي
             * اللوحَةِ فِي نَفسِ اللَّحمَةِ الَّتي ضَغَطَ فِيهَا المُستَخدِمُ.
             */
            @Override
            public boolean createType(almlk.QuickFix fix) {
              almlk.CreateClassPlan plan = fix == null ? null : fix.createType;
              if (plan == null || editor == null || browser == null) return false;
              if (!editor.isActiveFileWritableNow()) return false;
              String reference = editor.activeFileReference();
              if (reference == null || reference.isEmpty()) reference = editor.getActiveFile();
              if (reference == null) return false;
              String dir =
                  almlk.SourceLayout.directoryOf(android.net.Uri.decode(reference));
              return browser.createClassForQuickFix(
                  dir, plan.className, plan.packageName,
                  written -> {
                    if (written.booleanValue()) {
                      quickFixApplied(fix, plan.fileName);
                      Toast.makeText(
                              MainActivity.this,
                              uiFormat("ui_class_created", plan.className),
                              Toast.LENGTH_SHORT)
                          .show();
                    }
                  });
            }
          });

  @Override
  public boolean onCreateOptionsMenu(Menu menu) {
    menu.clear();
    // شارة الأخطاء قبل التشغيل كالمرجع (mainMenuErrorsView): تُنشأ مع كل بناء للقائمة.
    int errorCount = SequentialPanelHost.countErrors(displayedDiagnostics);
    errorBadgeVisible =
        almlk.ErrorCountBadge.visibleFor(
            errorCount, getResources().getConfiguration().screenWidthDp);
    errorBadge = new almlk.ErrorCountBadge(this, v -> showDiagnostics());
    errorBadge.setCount(errorCount);
    MenuItem errorsItem = menu.add(0, 7, 0, ui("command_show_errors"));
    errorsItem.setActionView(errorBadge.view());
    errorsItem.setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
    errorsItem.setVisible(errorBadgeVisible);
    menu.add(0, 1, 0, getString(R.string.command_run))
        .setIcon(R.drawable.ic_vectoric_run)
        .setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
    // دلالة المرجع: أثناء الكتابة يحل زوج التراجع/الإعادة محل القلم، بأهلية حية
    // (المتاح أبيض والمعطل باهت) — وخارج التحرير يعود القلم كما كان.
    boolean editingNow =
        editingToolbar && (drawer == null || !drawer.isDrawerOpen(Gravity.START));
    if (editingNow && editor != null) {
      lastCanUndo = editor.canUndoEdit();
      lastCanRedo = editor.canRedoEdit();
      lastPendingEdits = hasPendingEdits(); // «احفَظِ الكُلَّ» يَبعَثُ حَيًّا: لا ضَجيجَ معَ كُلِّ حَرفٍ
      MenuItem undoItem =
          menu.add(0, 4, 1, getString(R.string.command_undo)).setIcon(R.drawable.ic_vectoric_undo);
      undoItem.setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
      undoItem.setEnabled(lastCanUndo);
      if (undoItem.getIcon() != null)
        undoItem.getIcon().mutate().setAlpha(lastCanUndo ? 255 : 95);
      MenuItem redoItem =
          menu.add(0, 5, 2, getString(R.string.command_redo)).setIcon(R.drawable.ic_vectoric_redo);
      redoItem.setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
      redoItem.setEnabled(lastCanRedo);
      if (redoItem.getIcon() != null)
        redoItem.getIcon().mutate().setAlpha(lastCanRedo ? 255 : 95);
    } else if (activeLayoutXml()) {
      // دلالة المرجع: ملف تخطيط XML بلا كيبورد → أيقونة معاينة التصميم محل القلم.
      menu.add(0, 6, 1, ui("command_design"))
          .setIcon(R.drawable.ic_vectoric_design)
          .setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
    } else
      menu.add(0, 2, 1, getString(R.string.command_edit))
          .setIcon(R.drawable.ic_vectoric_edit)
          .setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
    MenuItem more = menu.add(0, 3, 3, getString(R.string.menu_more));
    ImageButton button = new ImageButton(this);
    button.setImageResource(R.drawable.ic_vectoric_more);
    button.setContentDescription(getString(R.string.menu_more));
    button.setBackgroundColor(Color.TRANSPARENT);
    button.setPadding(dp(12), dp(12), dp(12), dp(12));
    button.setOnClickListener(v -> showIdeRootMenu(v));
    moreActionView = button;
    more.setActionView(button);
    more.setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
    return true;
  }

  /** اختصارات العتاد على مستوى الـIDE — ترسل معرفات الأوامر للفهرس كما كل نقاط الواجهة. */
  @Override
  public boolean onKeyShortcut(int keyCode, android.view.KeyEvent event) {
    if (event.isCtrlPressed()) {
      switch (keyCode) {
        case android.view.KeyEvent.KEYCODE_S:
          dispatch("save");
          return true;
        case android.view.KeyEvent.KEYCODE_F:
          dispatch(event.isShiftPressed() ? "replace" : "find");
          return true;
        case android.view.KeyEvent.KEYCODE_H:
          dispatch("replace");
          return true;
        case android.view.KeyEvent.KEYCODE_G:
          dispatch("goto_line");
          return true;
        case android.view.KeyEvent.KEYCODE_SLASH:
          dispatch("comment");
          return true;
        case android.view.KeyEvent.KEYCODE_L:
          dispatch("format");
          return true;
        case android.view.KeyEvent.KEYCODE_SPACE:
          dispatch("complete");
          return true;
        default:
          break;
      }
    }
    return super.onKeyShortcut(keyCode, event);
  }

  @Override
  public boolean onOptionsItemSelected(MenuItem item) {
    if (item.getItemId() == android.R.id.home) {
      if (drawer.isDrawerOpen(Gravity.START)) drawer.closeDrawers();
      else openBrowser();
      return true;
    }
    if (item.getItemId() == 1) {
      // نمط المرجع: الأيقونة ترسل معرف الأمر للفهرس فيفحص الأهلية ثم ينفذ.
      dispatch("run");
      return true;
    }
    if (item.getItemId() == 2) {
      // أيقونة القلم كما في المرجع: دخول التحرير مباشرة، وإن لا ملف مفتوحًا نفتح المتصفح.
      if (editor == null || !editor.beginEditingSession()) openFilesBrowser();
      return true;
    }
    if (item.getItemId() == 6) {
      openDesigner();
      return true;
    }
    if (item.getItemId() == 4) {
      dispatch("undo");
      return true;
    }
    if (item.getItemId() == 5) {
      dispatch("redo");
      return true;
    }
    if (item.getItemId() == 3) {
      showIdeRootMenu(moreActionView != null ? moreActionView : masterButton);
      return true;
    }
    return super.onOptionsItemSelected(item);
  }

  @Override
  public void onCreateProject() {
    drawer.closeDrawers();
    // بنية المرجع: معالج قوالب حقيقي — فئات من JSON، اسم/حزمة بتحقق حي، نسخ واستبدالات،
    // ثم فتح المشروع وملفات البداية. لا ستب ولا وهم (بند الإحلال الكامل).
    ProjectWizard.show(
        this,
        browser != null ? browser.projectsTargetDirectory() : null,
        new ProjectWizard.Host() {
          @Override
          public void onProjectCreated(
              File projectRoot, File mainModule, java.util.List<File> starterFiles) {
            if (browser != null) browser.openCreatedProject(projectRoot);
            openStarterFiles(starterFiles);
          }

          @Override
          public void onProjectImported(File targetDirectory) {
            if (browser != null) browser.refreshListing();
          }

          @Override
          public void cloneRepository(
              File targetDirectory, String url, ProjectWizard.CloneListener listener) {
            cloneInto(targetDirectory, url, listener);
          }
        });
  }

  /** فتح ملفات بداية المشروع في التبويبات بالترتيب — القراءة خلفية والحقن على الواجهة. */
  private void openStarterFiles(java.util.List<File> starters) {
    if (starters == null || starters.isEmpty()) return;
    new Thread(
            () -> {
              for (File starter : starters) {
                String content;
                try (java.io.FileInputStream in = new java.io.FileInputStream(starter)) {
                  java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
                  byte[] buffer = new byte[8192];
                  int read;
                  while ((read = in.read(buffer)) > 0) out.write(buffer, 0, read);
                  content = out.toString("UTF-8");
                } catch (Exception unreadable) {
                  continue;
                }
                final String name = starter.getName();
                final String text = content;
                final String reference = starter.getAbsolutePath();
                runOnUiThread(() -> openFile(name, text, reference));
              }
            })
        .start();
  }

  @Override
  public void onCloneGit() {
    drawer.closeDrawers();
    View v = getLayoutInflater().inflate(R.layout.gitclonerepository, null);
    ((TextView) v.findViewById(R.id.gitclonerepositoryLocation))
        .setText("/storage/emulated/0/AppProjects");
    ((EditText) v.findViewById(R.id.gitclonerepositoryUrl)).setText("");
    ((EditText) v.findViewById(R.id.gitclonerepositoryDirectoryName)).setText("");
    new AlertDialog.Builder(this)
        .setTitle(ui("ui_clone_git_entry"))
        .setView(v)
        .setNegativeButton(ui("dialog_cancel"), null)
        .setPositiveButton(
            ui("ui_clone_git_entry"),
            (d, w) -> Toast.makeText(this, ui("ui_clone_git_entry"), Toast.LENGTH_SHORT).show())
        .show();
  }

  /** فتح الدرج على القسم المثبت — زر القائمة لا يُسقط المستخدم من الأخطاء/البحث للملفات. */
  void openBrowser() {
    if (drawer != null) drawer.openDrawer(Gravity.START);
  }

  /** فتح الدرج على صفحة الملفات تحديدًا — للأوامر التي تقصد الملفات صراحة. */
  void openFilesBrowser() {
    if (sequentialPanels != null) sequentialPanels.showFilesPage();
    if (drawer != null) drawer.openDrawer(Gravity.START);
  }

  @Override
  public void onStoragePermissionRequested() {
    showPermissionsCenter();
  }

  private void showPermissionsCenterOnFirstRun() {
    ensureRequiredStorageAccess();
  }

  private void ensureRequiredStorageAccess() {
    if (browser == null || !browser.needsProjectFolderSelection()) {
      if (requiredStorageDialog != null && requiredStorageDialog.isShowing()) {
        requiredStorageDialog.dismiss();
      }
      return;
    }
    if (isFinishing() || (requiredStorageDialog != null && requiredStorageDialog.isShowing()))
      return;

    requiredStorageDialog =
        new AlertDialog.Builder(this)
            .setTitle(ui("ui_permission_first_run_title"))
            .setMessage(ui("ui_permission_first_run_message"))
            .setPositiveButton(ui("ui_permission_select_project_folder"), (dialog, which) -> onSelectProjectFolder())
            .setNeutralButton(ui("ui_permission_all_files"), (dialog, which) -> openAllFilesSettings())
            .create();
    requiredStorageDialog.setCancelable(false);
    requiredStorageDialog.setCanceledOnTouchOutside(false);
    requiredStorageDialog.show();
  }

  private void showPermissionsCenter() {
    String files =
        (android.os.Build.VERSION.SDK_INT < 30 || android.os.Environment.isExternalStorageManager()
                ? "✓ "
                : "")
            + ui("ui_permission_all_files");
    String installs =
        (getPackageManager().canRequestPackageInstalls()
                ? "✓ "
                : "")
            + ui("ui_permission_install_apks");
    String overlay =
        (android.provider.Settings.canDrawOverlays(this)
                ? "✓ "
                : "")
            + ui("ui_permission_overlay");
    android.os.PowerManager power =
        (android.os.PowerManager) getSystemService(android.content.Context.POWER_SERVICE);
    String battery =
        (power != null && power.isIgnoringBatteryOptimizations(getPackageName())
            ? "✓ "
            : "")
            + ui("ui_permission_battery_exemption");
    String[] options = {
      ui("ui_permission_choose_project_recommended"),
      files,
      installs,
      overlay,
      battery,
      ui("ui_permission_legacy_storage"),
      ui("ui_permission_advanced_info")
    };
    new AlertDialog.Builder(this)
        .setTitle(ui("ui_permission_title"))
        .setItems(
            options,
            (dialog, which) -> {
              switch (which) {
                case 0:
                  onSelectProjectFolder();
                  break;
                case 1:
                  openAllFilesSettings();
                  break;
                case 2:
                  openInstallPackagesSettings();
                  break;
                case 3:
                  openOverlaySettings();
                  break;
                case 4:
                  requestBatteryExemption();
                  break;
                case 5:
                  requestLegacyStoragePermissions();
                  break;
                default:
                  showMessage(ui("ui_permission_explanation_title"), ui("ui_permission_explanation"));
              }
            })
        .setNegativeButton(ui("ui_action_close"), null)
        .show();
  }

  private void openAllFilesSettings() {
    if (android.os.Build.VERSION.SDK_INT < 30) {
      requestLegacyStoragePermissions();
      return;
    }
    try {
      startActivity(
          new android.content.Intent(
              android.provider.Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
              android.net.Uri.parse("package:" + getPackageName())));
    } catch (Exception error) {
      startActivity(
          new android.content.Intent(
              android.provider.Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));
    }
  }

  private void openInstallPackagesSettings() {
    startActivity(
        new android.content.Intent(
            android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
            android.net.Uri.parse("package:" + getPackageName())));
  }

  private void openOverlaySettings() {
    startActivity(
        new android.content.Intent(
            android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            android.net.Uri.parse("package:" + getPackageName())));
  }

  private void requestBatteryExemption() {
    try {
      startActivity(
          new android.content.Intent(
              android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
              android.net.Uri.parse("package:" + getPackageName())));
    } catch (Exception error) {
      startActivity(
          new android.content.Intent(
              android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
    }
  }

  private void requestLegacyStoragePermissions() {
    if (android.os.Build.VERSION.SDK_INT >= 33) {
      showMessage(ui("ui_storage_permission_title"), ui("ui_storage_permission_message"));
      return;
    }
    String[] permissions =
        android.os.Build.VERSION.SDK_INT <= 29
            ? new String[] {
              android.Manifest.permission.READ_EXTERNAL_STORAGE,
              android.Manifest.permission.WRITE_EXTERNAL_STORAGE
            }
            : new String[] {android.Manifest.permission.READ_EXTERNAL_STORAGE};
    requestPermissions(permissions, 40);
  }

  @Override
  public void onSelectProjectFolder() {
    android.content.Intent intent =
        new android.content.Intent(android.content.Intent.ACTION_OPEN_DOCUMENT_TREE);
    intent.addFlags(
        android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
            | android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            | android.content.Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
            | android.content.Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
    startActivityForResult(intent, 77);
  }

  @Override
  protected void onActivityResult(int requestCode, int resultCode, android.content.Intent data) {
    super.onActivityResult(requestCode, resultCode, data);
    if (requestCode == 88) {
      applySelectedTheme();
      return;
    }
    if (requestCode == 7811) {
      if (resultCode == RESULT_OK && browser != null) browser.refresh();
      return;
    }
    if (requestCode == 7801) {
      if (resultCode != RESULT_OK || data == null || editor == null) return;
      // تعديلات المصمم تعود نصًا كاملًا — تُحقن عبر موديل المحرك (قابلة للتراجع + حفظ تلقائي).
      String updated = data.getStringExtra("xml");
      if (updated != null) editor.replaceActiveContent(updated);
      int designerOffset = data.getIntExtra("goto", -1);
      if (designerOffset >= 0) editor.goToOffset(designerOffset);
      return;
    }
    if (requestCode == 77) {
      if (resultCode == RESULT_OK && data != null && data.getData() != null) {
        android.net.Uri uri = data.getData();
        int flags =
            data.getFlags()
                & (android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                    | android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        try {
          getContentResolver().takePersistableUriPermission(uri, flags);
        } catch (Exception ignored) {
        }
        if (browser != null) browser.openTree(uri);
      }
      getWindow().getDecorView().postDelayed(this::ensureRequiredStorageAccess, 350);
    }
  }

  @Override
  protected void onPause() {
    if (quickKeyBar != null) quickKeyBar.setActivityResumed(false);
    if (editor != null) editor.saveSession();
    super.onPause();
    stopAutosave();
  }

  /** بعد حفظِ سلسلةٍ من الإعدادات أو رجوعٌ من الملف: يُعادُ البناءُ والحارسُ يمنعُ المسَّ إن لم يتغيّر شيء. */
  public void rebuildQuickKeyBar() {
    if (quickKeyBar != null) quickKeyBar.rebuild();
  }

  @Override
  protected void onStop() {
    // تقرير 03 — حفظ الجلسة والملفات المتسخة عند مغادرة الواجهة، وليس فقط عند الإغلاق.
    if (editor != null) editor.saveSession();
    // W21′1: لا سويبةَ معلَّقةً خلفَ الواجهةِ — تُبقَى الأسماءُ في طابورِ الفهرسِ وتُستأنَفُ عندَ العودةِ.
    dependentSweepHandler.removeCallbacks(dependentSweep);
    dependentSweepScheduled = false;
    super.onStop();
  }

  @Override
  public void onTrimMemory(int level) {
    super.onTrimMemory(level);
    // تقارير 01/03 — تحرير كاشات التوكنز/النتائج عند ضغط الذاكرة بدل الانتظار حتى OOM.
    if (editor != null) editor.trimMemoryCaches();
  }

  @Override
  protected void onResume() {
    super.onResume();
    String selectedLanguage = almlk.AppSettings.language(this);
    if (languageAtLastCreate != null && !languageAtLastCreate.equals(selectedLanguage)) {
      languageAtLastCreate = selectedLanguage;
      recreate();
      return;
    }
    if (editor != null) editor.applyEditorSettings();
    if (editor != null) editor.applyAdvancedSettings();
    if (quickKeyBar != null) {
      quickKeyBar.setActivityResumed(true);
      quickKeyBar.rebuild();
    }
    applyDrawerSettings();
    scheduleAutosave();
    applySelectedTheme();
    if (browser != null) browser.refresh();
    // حُذفت مكتبات المشروع من الإعدادات: فحص محلي فتنزيل تلقائي للمفقود (كالفتح).
    if (com.almlkid.ui.DependencyCycle.consumeRecheck() && session != null && session.directory() != null)
      dependencyCycle().start(session.directory(), com.almlkid.ui.DependencyCycle.Mode.OPEN);
    getWindow()
        .getDecorView()
        .postDelayed(
            () -> {
              ensureRequiredStorageAccess();
              // تقرير AIDE — بعد منح صلاحية التخزين نسترد التبويبات التي فشل فتحها عند الإقلاع.
              if (browser != null && !browser.needsProjectFolderSelection() && editor != null) {
                editor.retryLazySessionReferences();
              }
            },
            450);
    // W21′1: ما تراكمَ من تغيّراتِ التعريفاتِ في الغيابِ يُواكَبُ عندَ العودةِ.
    touchDeclarationWatch();
  }

  /** Displays the localized hierarchical menu declared in res/menu/main_options_menu.xml. */
  void showIdeRootMenu(View anchor) {
    if (anchor == null) return;
    PopupMenu popup = new PopupMenu(this, anchor, Gravity.END);
    Menu menu = popup.getMenu();
    getMenuInflater().inflate(R.menu.main_options_menu, menu);

    MenuItem editMode = menu.findItem(R.id.mainMenuEditMode);
    MenuItem navigateMode = menu.findItem(R.id.mainMenuNavigateMode);
    if (editMode != null) editMode.setVisible(!editingToolbar);
    if (navigateMode != null) navigateMode.setVisible(editingToolbar);
    updateIdeMenuState(menu);

    popup.setOnMenuItemClickListener(this::onIdeMenuItemClick);
    popup.show();
  }

  /** Applies live command eligibility without creating menu rows or titles in Java. */
  private void updateIdeMenuState(Menu menu) {
    for (int index = 0; index < menu.size(); index++) {
      MenuItem item = menu.getItem(index);
      int itemId = item.getItemId();
      if (itemId == R.id.editorMenuComment || itemId == R.id.editorMenuUnComment) {
        item.setEnabled(isEditorWritable());
      } else {
        String commandId = ideCommandForMenuItem(itemId);
        if (commandId != null) {
          CommandCenter.Command command = commands.get(commandId);
          item.setEnabled(command != null && command.enabled(this));
        }
      }
      if (item.hasSubMenu()) updateIdeMenuState(item.getSubMenu());
    }
  }

  /** Routes resource menu ids to the shared command catalogue. */
  private String ideCommandForMenuItem(int itemId) {
    if (itemId == R.id.mainMenuOpenFileBrowser) return "files";
    if (itemId == R.id.mainMenuOpenErrorBrowser) return "show_errors";
    if (itemId == R.id.mainMenuOpenSearchBrowser || itemId == R.id.mainMenuSearchInProject)
      return "show_search_results";
    if (itemId == R.id.mainMenuOpenDebugBrowser) return "show_debugger";
    if (itemId == R.id.mainMenuOpenLogCatBrowser) return "show_logcat";
    if (itemId == R.id.mainMenuGoto) return "goto_element";
    if (itemId == R.id.mainMenuForward) return "forward";
    if (itemId == R.id.mainMenuSave) return "save";
    if (itemId == R.id.mainMenuSaveAll) return "save_all";
    if (itemId == R.id.editorMenuFindUsage) return "find_usages";
    if (itemId == R.id.mainMenuSearch) return "find";
    if (itemId == R.id.mainMenuReplace || itemId == R.id.editorMenuReplace) return "replace";
    if (itemId == R.id.mainMenuGotoLine) return "goto_line";
    if (itemId == R.id.editorMenuRename) return "rename";
    if (itemId == R.id.editorMenuInlineVariable) return "inline";
    if (itemId == R.id.editorMenuIntroduceVariable) return "introduce";
    if (itemId == R.id.editorMenuExtractMethod) return "extract_method";
    if (itemId == R.id.editorMenuOrganizeImports) return "organize_imports";
    if (itemId == R.id.editorMenuSurroundWithTryCatch) return "surround_try";
    if (itemId == R.id.editorMenuCreateSetters) return "create_setters";
    if (itemId == R.id.editorMenuCreateConstructor) return "create_constructor";
    if (itemId == R.id.editorMenuExtractResources) return "extract_resources";
    if (itemId == R.id.editorMenuFormatCode) return "format";
    if (itemId == R.id.editorMenuLearnCodeStyle) return "learn_style";
    if (itemId == R.id.editorMenuConfigureCodeStyle) return "configure_style";
    if (itemId == R.id.mainMenuRefreshBuild) return "refresh_build";
    if (itemId == R.id.mainMenuConvertProject) return "convert_project";
    if (itemId == R.id.mainMenuJumpToDirectory) return "go_to_directory";
    if (itemId == R.id.mainMenuMaterialIcons) return "material_icons";
    if (itemId == R.id.mainMenuCodeFormatting) return "format";
    if (itemId == R.id.mainMenuSyntaxHighlighting) return "syntax_highlighting";
    if (itemId == R.id.mainMenuEscapeJava) return "escape_java";
    if (itemId == R.id.mainMenuEscapeXml) return "escape_xml";
    if (itemId == R.id.mainMenuBatchReplace) return "batch_replace";
    if (itemId == R.id.mainMenuJson2Bean) return "json2bean";
    if (itemId == R.id.mainMenuSystemResources) return "system_resources";
    if (itemId == R.id.mainMenuRebuild) return "build_debug";
    if (itemId == R.id.mainMenuBuildRelease) return "build_release";
    if (itemId == R.id.mainMenuSelectBuildVariant) return "select_build_variant";
    if (itemId == R.id.mainMenuPublishProject) return "publish_project";
    if (itemId == R.id.mainMenuCloseProject) return "close_project";
    if (itemId == R.id.mainMenuTerminal) return "terminal";
    if (itemId == R.id.mainMenuPermissions) return "permissions";
    if (itemId == R.id.mainMenuTheme) return "theme";
    if (itemId == R.id.mainMenuAbout) return "about";
    if (itemId == R.id.mainMenuGitStatus) return "git_status";
    if (itemId == R.id.mainMenuGitLog) return "git_log";
    if (itemId == R.id.mainMenuGitAdd) return "git_add";
    if (itemId == R.id.mainMenuGitCommit) return "git_commit";
    if (itemId == R.id.mainMenuGitPull) return "git_pull";
    if (itemId == R.id.mainMenuGitPush) return "git_push";
    if (itemId == R.id.mainMenuSettings) return "settings";
    if (itemId == R.id.mainMenuExit) return "exit";
    return null;
  }

  private boolean onIdeMenuItemClick(MenuItem item) {
    int itemId = item.getItemId();
    if (itemId == R.id.mainMenuEditMode || itemId == R.id.mainMenuNavigateMode) {
      toggleEditNavigateMode();
      return true;
    }
    if (itemId == R.id.mainMenuShowOpenFiles) {
      showOpenFilesDialog();
      return true;
    }
    if (itemId == R.id.editorMenuHelp) {
      openDocumentation();
      return true;
    }
    if (itemId == R.id.editorMenuComment) {
      if (editor != null) editor.commentLines();
      return true;
    }
    if (itemId == R.id.editorMenuUnComment) {
      if (editor != null) editor.uncommentLines();
      return true;
    }
    String commandId = ideCommandForMenuItem(itemId);
    if (commandId == null) return false;
    dispatch(commandId);
    return true;
  }

  /** بند المرجع المتبدل: وضع التحرير يفتح كيبورد المحرر، ووضع التنقل يخفيه. */
  private void toggleEditNavigateMode() {
    if (editor == null) return;
    if (editingToolbar) {
      View focused = getCurrentFocus();
      android.view.inputmethod.InputMethodManager imm =
          (android.view.inputmethod.InputMethodManager)
              getSystemService(INPUT_METHOD_SERVICE);
      if (imm != null && focused != null)
        imm.hideSoftInputFromWindow(focused.getWindowToken(), 0);
    } else if (!editor.beginEditingSession()) {
      openFilesBrowser();
    }
  }

  /** «قائمة الملفات المفتوحة» المرجعية: اختيار تبويب يفعّله مباشرة. */
  private void showOpenFilesDialog() {
    if (editor == null) return;
    final List<String> names = editor.openFileNames();
    if (names.isEmpty()) {
      Toast.makeText(this, ui("view_no_open_files"), Toast.LENGTH_SHORT).show();
      return;
    }
    new AlertDialog.Builder(this)
        .setTitle(ui("ui_open_files_title"))
        .setItems(names.toArray(new String[0]), (d, w) -> editor.showOpenFile(names.get(w)))
        .setNegativeButton(ui("ui_action_close"), null)
        .show();
  }

  /** التوثيق: فتح وثائق أندرويد للرمز تحت المؤشر (أو الصفحة المرجعية عامة). */
  private void openDocumentation() {
    String symbol = editor == null ? "" : editor.documentationQuery();
    String url =
        symbol == null || symbol.isEmpty()
            ? "https://developer.android.com/reference"
            : "https://developer.android.com/s/results?q=" + android.net.Uri.encode(symbol);
    try {
      startActivity(
          new android.content.Intent(
              android.content.Intent.ACTION_VIEW, android.net.Uri.parse(url)));
    } catch (Exception noBrowser) {
      Toast.makeText(this, ui("ui_no_browser_for_docs"), Toast.LENGTH_SHORT).show();
    }
  }

  /** إغلاق المشروع كما في المرجع: إغلاق التبويبات ومسح الجلسة والعودة لمجلد المشاريع. */
  private void closeCurrentProject() {
    if (editor != null) editor.closeAll();
    if (session != null) session.clear();
    showNoProject();
    if (browser != null) browser.showProjectsHome();
    if (drawer != null) drawer.openDrawer(Gravity.START);
  }

  /** Project › Refresh Build كالمرجع: تأكيد «Refresh Build?» ثم إعادة حلّ المكتبات وتنزيل الناقص. */
  private void confirmRefreshBuild() {
    final File root = session == null ? null : session.directory();
    if (root == null) {
      Toast.makeText(this, ui("ui_error_open_project_first"), Toast.LENGTH_SHORT).show();
      return;
    }
    new AlertDialog.Builder(this)
        .setTitle(ui("command_refresh_build"))
        .setMessage(ui("dialog_refresh_build_message"))
        .setNegativeButton(R.string.action_no, null)
        .setPositiveButton(
            R.string.action_yes,
            (dialog, which) ->
                dependencyCycle().start(root, com.almlkid.ui.DependencyCycle.Mode.REFRESH_BUILD))
        .show();
  }

  /** أدوات › أخرى › تحويل المشروع: يحفظ التعديل المعلّق أولًا ثم يخيّر بين AppCompat و AndroidX. */
  private void promptConvertProject() {
    final File root = session == null ? null : session.directory();
    if (root == null || !hasGradleProject()) {
      Toast.makeText(this, ui("ui_error_open_project_first"), Toast.LENGTH_SHORT).show();
      return;
    }
    Runnable choose =
        () ->
            new AlertDialog.Builder(this)
                .setTitle(ui("command_convert_project"))
                .setItems(
                    new String[] {ui("ui_convert_to_appcompat"), ui("ui_convert_to_androidx")},
                    (dialog, which) -> convertProject(root, which == 1))
                .setNegativeButton(ui("dialog_cancel"), null)
                .show();
    saveAllThen(choose);
  }

  /**
   * ج٤٢: يَحفَظُ كلَّ تَعدِيلٍ مُعَلَّقٍ في جَميعِ التَّبويباتِ ثُمَّ يُنفِّذُ الإجراءَ. وسابِقُها كانَ
   * يَحفَظُ النَّشِطَ وَحدَهُ: فَما كُتِبَ في تَبوِيبٍ ثانٍ لا يَبلُغُ القُرسَ قَبلَ البِناءِ، والمَسحُ
   * الشَّامِلُ يَقرَأُ شَيفَرَةَ الأَمسِ فَيُخبِرُ عَن غَيرِ ما يَراهُ المُستَخدِمُ. والكَاتِبُ واحِدٌ في
   * كُلِّ مَرَّةٍ (كَسِياقَةِ التَّحفِظِ الذَّاتِيِّ) كَي لا يَتَزاحَمَ حِفظانِ على قارِئَينِ، والعَدَدُ
   * المَنطوقُ عَدَدُ ما حُفِظَ حَرفِيًّا لا عَدَدُ ما طُلِبَ.
   */
  private void saveAllThen(final Runnable next) {
    saveAllThen(next, true);
  }

  /** ‏announce`‏ صَمتٌ عِندَ التَّحفِظِ الذَّاتِيِّ: رِسالةٌ كُلَّ ثَوانٍ أَضَجُّ مِنَ الفَائدَةِ. */
  private void saveAllThen(final Runnable next, final boolean announce) {
    if (editor == null || browser == null) {
      if (next != null) next.run();
      return;
    }
    final java.util.List<String> pending = editor.dirtyTabs();
    if (pending.isEmpty()) {
      if (next != null) next.run();
      return;
    }
    saveDirtyAt(pending, 0, 0, next, announce);
  }

  /** حِفظٌ دُخُولِيٌّ بِعَدَدٍ: لا يَسقُطُ الإجراءُ ولا يُكرَرُ، والفَاشِلُ يُقالُ ثُمَّ يُترَكُ وَشرَهُ. */
  private void saveDirtyAt(final java.util.List<String> pending, final int at, final int saved,
      final Runnable next, final boolean announce) {
    if (at >= pending.size()) {
      if (saved > 0 && analyzerBridge != null) {
        // لَا نَخرِقُ الجِسْرَ عِندَ الحِفظِ لِأَجلِ إِعلَانٍ: إِنْ لَم يَكُن هُنَا فَلَم يَكُن هُنَا
        // أَحَدٌ يَنظُرُ، وَالنَّافِذَةُ تَجِدُ جَولَتَهَا عِندَ أَوَّلِ إِشَارَةِ مُحرِّرٍ بَعدَهَا.
        analyzerBridge.requestProjectPass();
      }
      if (announce && saved > 0) {
        Toast.makeText(this, uiFormat("ui_save_all_done", saved), Toast.LENGTH_SHORT).show();
      }
      if (next != null) next.run();
      return;
    }
    final String tab = pending.get(at);
    final String text = editor.textOf(tab);
    if (text == null) {
      // لا نَصَّ لِلِّسانِ بَينَ الدَّفعَتَينِ (أُغلِقَ مَثَلًا): نَنتَقِلُ، ولا نَكتُبُ جَهلًا على القُرسِ.
      saveDirtyAt(pending, at + 1, saved, next, announce);
      return;
    }
    browser.saveOpenedFileAsync(
        tab,
        text,
        (ok, message) -> {
          if (ok) {
            editor.markTabSaved(tab);
            mirrorSync(tab, text);
            onFileSaved(tab); // حِفظُ مِلَفِّ البِناءِ يُعيِدُ دَورَةَ المُكتَبَاتِ، والمانيفستُ مِثلَهُ
            saveDirtyAt(pending, at + 1, saved + 1, next, announce);
          } else {
            if (message != null && !message.isEmpty())
              Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
            saveDirtyAt(pending, at + 1, saved, next, announce);
          }
        });
  }

  /** وحدة المشروع الحالية (app في المشاريع متعددة الوحدات)، أو null بلا مشروع. */
  private File currentModuleDir() {
    File root = session == null ? null : session.directory();
    if (root == null || !root.isDirectory()) return null;
    File build = almlk.GradleDependencyEditor.moduleBuildFile(root);
    File module = build == null ? null : build.getParentFile();
    return module != null ? module : root;
  }

  private File moduleSubdir(String... candidates) {
    File module = currentModuleDir();
    if (module == null) return null;
    for (String c : candidates) {
      File dir = new File(module, c);
      if (dir.isDirectory()) return dir;
    }
    return null;
  }

  /** حزمة المشروع: namespace في ملف البناء، ثم package في المانيفست، ثم applicationId. */
  private String currentProjectPackage() {
    File module = currentModuleDir();
    if (module == null) return "";
    java.util.regex.Pattern[] patterns = {
      java.util.regex.Pattern.compile("\\bnamespace\\s*=?\\s*['\"]([\\w.]+)['\"]"),
      java.util.regex.Pattern.compile("\\bapplicationId\\s*=?\\s*['\"]([\\w.]+)['\"]")
    };
    File build = almlk.GradleDependencyEditor.buildFileIn(module);
    String buildText = build == null ? "" : readSmallText(build);
    java.util.regex.Matcher m = patterns[0].matcher(buildText);
    if (m.find()) return m.group(1);
    File manifest = new File(module, "src/main/AndroidManifest.xml");
    if (!manifest.isFile()) manifest = new File(module, "AndroidManifest.xml");
    m = java.util.regex.Pattern.compile("\\bpackage\\s*=\\s*\"([\\w.]+)\"").matcher(readSmallText(manifest));
    if (m.find()) return m.group(1);
    m = patterns[1].matcher(buildText);
    return m.find() ? m.group(1) : "";
  }

  private static String readSmallText(File file) {
    try {
      if (file == null || !file.isFile() || file.length() > 1024 * 1024) return "";
      return new String(java.nio.file.Files.readAllBytes(file.toPath()), java.nio.charset.StandardCharsets.UTF_8);
    } catch (java.io.IOException e) {
      return "";
    }
  }

  /** أدوات › Material Icons: مجلد res للوحدة الحالية يفعّل «إضافة إلى المشروع». */
  private void openMaterialIcons() {
    Intent intent = new Intent(this, com.almlkid.ui.tools.MaterialIconsActivity.class);
    File res = moduleSubdir("src/main/res", "res");
    if (res != null) intent.putExtra(com.almlkid.ui.tools.MaterialIconsActivity.EXTRA_RES_DIR, res.getAbsolutePath());
    startActivityForResult(intent, 7811);
  }

  /** أدوات › أخرى › استبدال جماعي: الهدف الافتراضي src/main للوحدة؛ التبويبات المفتوحة تُحدَّث بعده. */
  private void openBatchReplace() {
    File target = moduleSubdir("src/main");
    if (target == null) target = currentModuleDir();
    com.almlkid.ui.tools.BatchReplaceDialog.show(
        this,
        target,
        rewritten -> {
          if (editor != null) editor.reloadReferences(rewritten);
          if (browser != null) browser.refresh();
          if (hasProject()) indexAndScanProject();
        });
  }

  /** أدوات › أخرى › Json2Bean: الحزمة من المشروع، والتصدير إلى src/main/java. */
  private void openJsonBean() {
    com.almlkid.ui.tools.JsonBeanDialog.show(
        this,
        currentProjectPackage(),
        moduleSubdir("src/main/java", "src"),
        new com.almlkid.ui.tools.JsonBeanDialog.Host() {
          @Override
          public boolean insertIntoEditor(String text) {
            return editor != null && editor.insertAtCursor(text);
          }

          @Override
          public void fileCreated(File file) {
            if (browser != null) browser.refresh();
            openFile(file.getAbsolutePath());
          }
        });
  }

  private void convertProject(final File root, final boolean toAndroidX) {
    final ProgressDialog progress = new ProgressDialog(this);
    progress.setMessage(ui("ui_converting"));
    progress.setCancelable(false);
    progress.show();
    new Thread(
            () -> {
              almlk.AndroidXMigration.Result result = null;
              Throwable failure = null;
              final HashMap<String, String> rewritten = new HashMap<>();
              try {
                result = almlk.AndroidXMigration.convertProject(root, toAndroidX);
                for (File changed : result.changed) {
                  rewritten.put(
                      changed.getAbsolutePath(),
                      new String(java.nio.file.Files.readAllBytes(changed.toPath()),
                          java.nio.charset.StandardCharsets.UTF_8));
                }
              } catch (Throwable error) {
                failure = error;
              }
              final almlk.AndroidXMigration.Result done = result;
              final Throwable error = failure;
              runOnUiThread(
                  () -> {
                    if (isFinishing()) return;
                    progress.dismiss();
                    if (done == null) {
                      new AlertDialog.Builder(this)
                          .setTitle(ui("command_convert_project"))
                          .setMessage(uiFormat("ui_convert_failed", UiStrings.message(this, error)))
                          .setPositiveButton(android.R.string.ok, null)
                          .show();
                      return;
                    }
                    if (editor != null) editor.reloadReferences(rewritten);
                    if (browser != null) browser.refresh();
                    new AlertDialog.Builder(this)
                        .setTitle(ui("ui_convert_done_title"))
                        .setMessage(uiFormat("ui_convert_done_message", done.files, done.replacements, done.millis))
                        .setPositiveButton(android.R.string.ok, null)
                        .show();
                    if (done.files > 0) {
                      indexAndScanProject();
                      dependencyCycle().start(root, com.almlkid.ui.DependencyCycle.Mode.SAVE);
                    }
                  });
            },
            "ConvertProject")
        .start();
  }

  /** أدوات › أخرى › الانتقال إلى مجلد: مسار مُعبّأ بمجلد التطبيق الداخلي ويُعرض في المتصفح. */
  private void promptGoToDirectory() {
    final EditText input = new EditText(this);
    input.setSingleLine(true);
    input.setText(getFilesDir().getAbsolutePath());
    input.setSelection(input.length());
    LinearLayout box = new LinearLayout(this);
    int pad = Math.round(20 * getResources().getDisplayMetrics().density);
    box.setPadding(pad, pad / 2, pad, 0);
    box.addView(input, new LinearLayout.LayoutParams(-1, -2));
    new AlertDialog.Builder(this)
        .setTitle(ui("command_go_to_directory"))
        .setView(box)
        .setNegativeButton(ui("dialog_cancel"), null)
        .setPositiveButton(
            android.R.string.ok,
            (dialog, which) -> {
              File target = new File(input.getText().toString().trim());
              if (browser == null || !browser.showDirectory(target)) {
                Toast.makeText(
                        this, uiFormat("ui_directory_not_found", target.getPath()), Toast.LENGTH_SHORT)
                    .show();
                return;
              }
              if (drawer != null) drawer.openDrawer(Gravity.START);
            })
        .show();
  }

  private void confirmExit() {
    new AlertDialog.Builder(this)
        .setTitle(R.string.menu_exit_title)
        .setMessage(R.string.menu_exit_message)
        .setNegativeButton(R.string.action_no, null)
        .setPositiveButton(R.string.action_yes, (dialog, which) -> finish())
        .show();
  }

  void showCommands() {
    final List<String> groups = commands.groups();
    new AlertDialog.Builder(this)
        .setTitle(ui("ui_commands_title"))
        .setItems(groups.toArray(new String[0]), (d, w) -> showCommandGroup(groups.get(w)))
        .show();
  }

  void showCommandGroup(String group) {
    final List<CommandCenter.Command> list = commands.inGroup(group);
    String[] labels = new String[list.size()];
    for (int i = 0; i < list.size(); i++) {
      CommandCenter.Command c = list.get(i);
      labels[i] = (c.enabled(this) ? "" : "🔒  ") + c.titleFor(this);
    }
    new AlertDialog.Builder(this)
        .setTitle(group)
        .setItems(labels, (d, w) -> dispatch(list.get(w).id))
        .setNegativeButton(ui("ui_action_back"), (d, w) -> showCommands())
        .show();
  }

  /** المرحلة 3: اختصارات المفاتيح المخزّنة تسبق أي معالجة إدخال أخرى. */
  @Override
  public boolean dispatchKeyEvent(android.view.KeyEvent event) {
    if (event.getAction() == android.view.KeyEvent.ACTION_DOWN) {
      String command =
          almlk.Keybinds.commandFor(
              this,
              event.isCtrlPressed(),
              event.isAltPressed(),
              event.isShiftPressed(),
              event.getKeyCode());
      if (command != null) {
        dispatch(command);
        return true;
      }
    }
    return super.dispatchKeyEvent(event);
  }

  void dispatch(String id) {
    CommandCenter.Command c = commands.get(id);
    if (!commands.dispatch(id, this)) {
      String reason;
      if (c == null) reason = ui("ui_command_unknown");
      else if (c.needsProject && !hasProject()) reason = ui("ui_error_open_project_first");
      else if (c.needsEditor && !hasEditor()) reason = ui("ui_open_file_first");
      else if (("goto_definition".equals(id) || "goto_element".equals(id))
          && !hasExplicitEditorSelection())
        reason = ui("ui_error_symbol_selection_required");
      else if (!isEditorWritable()
          && ("format".equals(id) || "comment".equals(id) || "replace".equals(id)
              || "save".equals(id)))
        reason = ui("ui_file_read_only");
      else reason = ui("ui_command_unavailable");
      Toast.makeText(this, reason, Toast.LENGTH_SHORT).show();
    }
  }

  /** Opens a bounded, debounced project-symbol search without doing source I/O on the UI thread. */
  /** آخر استعلام GoTo — يُحفظ بين الفتحات ويُستعاد محددًا بالكامل كما في المرجع. */
  private static String lastGotoQuery = "";

  /** حد عرض نتائج GoTo كما في المرجع: فوق الحد تُعرض رسالة «اكتب المزيد» بدل القائمة. */
  private static final int GOTO_RESULT_LIMIT = 50;

  void promptGotoElement() {
    View view = getLayoutInflater().inflate(R.layout.gotobrowser, null);
    EditText queryBox = view.findViewById(R.id.gotobrowserSearchBox);
    Switch includeSystem = view.findViewById(R.id.gotobrowserSwitch);
    ListView resultList = view.findViewById(R.id.gotobrowserSymbolList);
    TextView message = view.findViewById(R.id.gotobrowserMessage);
    ProgressBar progress = view.findViewById(R.id.gotobrowserProgress);
    if (queryBox == null || resultList == null || message == null || progress == null) return;
    if (browser != null && editor != null && editor.hasOpenFile())
      browser.setActiveEditorSnapshot(
          editor.getActiveFile(), editor.getTextContent(), editor.activeFileReference());
    includeSystem.setTextOn(ui("ui_include_all_symbols"));
    includeSystem.setTextOff(ui("ui_include_project_symbols"));
    includeSystem.setChecked(false);
    final ArrayList<ProjectSymbolIndex.DefinitionTarget> targets = new ArrayList<>();
    // صف النتيجة كما في المرجع: أيقونة النوع + الاسم (مع «()» للدوال) + الحاوية كسطر ثانٍ.
    ArrayAdapter<ProjectSymbolIndex.DefinitionTarget> adapter =
        new ArrayAdapter<ProjectSymbolIndex.DefinitionTarget>(this, 0, targets) {
          @Override
          public View getView(int position, View convertView, android.view.ViewGroup parent) {
            View row = convertView != null
                ? convertView
                : getLayoutInflater().inflate(R.layout.gotobrowser_entry, parent, false);
            ProjectSymbolIndex.DefinitionTarget target =
                position < targets.size() ? targets.get(position) : null;
            android.widget.ImageView icon = row.findViewById(R.id.gotobrowserEntryImage);
            TextView name = row.findViewById(R.id.gotobrowserEntryName);
            TextView container = row.findViewById(R.id.gotobrowserEntryContainerName);
            View help = row.findViewById(R.id.gotobrowserHelpButton);
            if (help != null) help.setVisibility(View.GONE);
            if (target == null) return row;
            if (icon != null) icon.setImageResource(gotoEntryIcon(target));
            if (name != null)
              name.setText(
                  target.kind == ProjectSymbolIndex.DefinitionTarget.KIND_METHOD
                      ? target.symbol + "()"
                      : target.symbol);
            if (container != null) container.setText(resultLocation(target));
            return row;
          }
        };
    resultList.setAdapter(adapter);
    AlertDialog dialog =
        new AlertDialog.Builder(this)
            .setTitle(ui("ui_goto_element_title"))
            .setView(view)
            .setNegativeButton(ui("ui_action_close"), null)
            .create();
    final int[] generation = {0};
    final Runnable[] pending = {null};
    android.text.TextWatcher watcher = new android.text.TextWatcher() {
      @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
      @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
        final int request = ++generation[0];
        if (pending[0] != null) queryBox.removeCallbacks(pending[0]);
        targets.clear();
        adapter.notifyDataSetChanged();
        String text = s == null ? "" : s.toString().trim();
        message.setText(text.isEmpty() ? ui("ui_goto_element_prompt") : ui("ui_searching"));
        progress.setVisibility(text.isEmpty() ? View.GONE : View.VISIBLE);
        if (text.isEmpty()) return;
        final boolean showSystem = includeSystem.isChecked();
        pending[0] = () -> browser.searchSymbolsAsync(text, showSystem, (found, cancelled) -> {
          if (request != generation[0] || !dialog.isShowing()) return;
          progress.setVisibility(View.GONE);
          targets.clear();
          if (found != null && found.size() > GOTO_RESULT_LIMIT) {
            // سلوك المرجع عند تجاوز الحد: رسالة «أكثر من N مطابقة» بلا قائمة.
            message.setText(uiFormat("ui_goto_more_than_limit", GOTO_RESULT_LIMIT));
          } else {
            if (found != null) targets.addAll(found);
            message.setText(
                targets.isEmpty() ? ui("ui_no_matching_symbols") : ui("ui_choose_symbol_to_open"));
          }
          adapter.notifyDataSetChanged();
        });
        // Keep only a tiny frame budget: the search worker is cancellable and the in-memory
        // snapshot makes results appear while the user is still typing.
        queryBox.postDelayed(pending[0], 35);
      }
      @Override public void afterTextChanged(android.text.Editable s) {}
    };
    queryBox.addTextChangedListener(watcher);
    includeSystem.setOnCheckedChangeListener((button, checked) -> {
      if (queryBox.getText().length() > 0) queryBox.setText(queryBox.getText());
    });
    resultList.setOnItemClickListener((parent, row, position, id) -> {
      if (position < 0 || position >= targets.size()) return;
      ProjectSymbolIndex.DefinitionTarget target = targets.get(position);
      dialog.dismiss();
      openDefinition(target);
    });
    dialog.setOnDismissListener(d -> {
      // حفظ الاستعلام بين الفتحات — نفس حقل المرجع الساكن المحفوظ عند الإغلاق.
      lastGotoQuery = queryBox.getText() == null ? "" : queryBox.getText().toString();
      generation[0]++;
      if (pending[0] != null) queryBox.removeCallbacks(pending[0]);
      browser.cancelProjectSearch();
    });
    dialog.setOnShowListener(d -> {
      queryBox.requestFocus();
      dialog.getWindow().setSoftInputMode(
          android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
    });
    // استعادة آخر استعلام + تحديد كامل + بحث فوري عند الفتح — كما يفعل المرجع في onCreate.
    if (!lastGotoQuery.isEmpty()) queryBox.setText(lastGotoQuery);
    queryBox.selectAll();
    dialog.show();
  }

  /** أيقونة صف GoTo حسب نوع الرمز — كتمييز المرجع بين كلاس/دالة/حقل. */
  private int gotoEntryIcon(ProjectSymbolIndex.DefinitionTarget target) {
    if (target == null) return R.drawable.completion_variable;
    switch (target.kind) {
      case ProjectSymbolIndex.DefinitionTarget.KIND_CLASS:
        return R.drawable.completion_class;
      case ProjectSymbolIndex.DefinitionTarget.KIND_METHOD:
        return R.drawable.completion_method;
      case ProjectSymbolIndex.DefinitionTarget.KIND_FIELD:
        return R.drawable.completion_variable;
      default:
        return target.symbol != null && target.symbol.equals(target.className)
            ? R.drawable.completion_class
            : R.drawable.completion_variable;
    }
  }

  /** السطر الثاني لصف GoTo: الحاوية (الكلاس) ثم الملف — كما يعرض المرجع اسم الحاوية. */
  private String resultLocation(ProjectSymbolIndex.DefinitionTarget target) {
    if (target == null) return "";
    String file = target.fileName == null ? "" : target.fileName;
    boolean ownClass = target.className == null
        || target.className.isEmpty()
        || target.className.equals(target.symbol);
    return ownClass ? file : target.className + " — " + file;
  }

  void showDesigner() {
    View v = getLayoutInflater().inflate(R.layout.designer, null);
    new AlertDialog.Builder(this)
        .setTitle(ui("ui_designer_title"))
        .setView(v)
        .setNegativeButton(ui("ui_action_close"), null)
        .show();
  }

  void runProject() {
    runBuild("assembleDebug", ui("command_run"));
  }

  /** المرحلة 5: يتعلم نمط الإزاحة من المستند ويحفظه في CodeStyle. */
  void learnCodeStyle() {
    if (editor == null || !editor.hasOpenFile()) {
      Toast.makeText(this, ui("ui_open_file_first_short"), Toast.LENGTH_SHORT).show();
      return;
    }
    String text = editor.getTextContent();
    int size = almlk.CodeStyle.detectIndent(text);
    String file = editor.getActiveFile();
    String key = almlk.XmlCodeFormatter.isXmlName(file)
        ? almlk.CodeStyle.XML_INDENT_KEY
        : almlk.CodeStyle.JAVA_INDENT_KEY;
    almlk.CodeStyle.setIndentSize(this, key, size);
    Toast.makeText(this, uiFormat("ui_detected_indent_size", size), Toast.LENGTH_LONG).show();
  }

  // ===== المرحلة 1 (الإعدادات): حفظ تلقائي + سحب المتصفح =====
  private final android.os.Handler autosaveHandler =
      new android.os.Handler(android.os.Looper.getMainLooper());

  private void scheduleAutosave() {
    autosaveHandler.removeCallbacksAndMessages(null);
    int seconds = almlk.AppSettings.autosaveSeconds(this);
    if (seconds <= 0) return;
    autosaveHandler.postDelayed(this::autosaveTick, seconds * 1000L);
  }

  private void stopAutosave() {
    autosaveHandler.removeCallbacksAndMessages(null);
  }

  private void autosaveTick() {
    // ج٤٢: الكُلُّ لا النَّشِطُ وَحدَهُ — ما في التَّبويباتِ الخَامِلَةِ كانَ لا يُحفَظُ أبدًا، فَلا
    // العَلامَةُ تَزُولُ ولا الفَحصُ يَرَى الشَّيفَرَةَ. والصَّمتُ مَفروضٌ: رِسالةٌ كُلَّ دَورَةٍ ضَجيجٌ.
    saveAllThen(this::scheduleAutosave, false);
  }

  /** سحب أفقي يمينًا في المتصفح = صعود مستوى (يُحترم مفتاح browser_swipe). */
  private void attachBrowserSwipe() {
    if (browser == null) return;
    final android.view.GestureDetector detector =
        new android.view.GestureDetector(
            this,
            new android.view.GestureDetector.SimpleOnGestureListener() {
              @Override
              public boolean onFling(
                  android.view.MotionEvent e1,
                  android.view.MotionEvent e2,
                  float velocityX,
                  float velocityY) {
                if (!almlk.AppSettings.browserSwipe(MainActivity.this)) return false;
                if (e1 == null || e2 == null) return false;
                float dx = e2.getX() - e1.getX();
                if (dx <= 0 || Math.abs(dx) < 120 || Math.abs(velocityX) < 200) return false;
                java.io.File root = browser.projectRootFile();
                java.io.File parent = root == null ? null : root.getParentFile();
                if (parent != null && parent.canRead()) {
                  browser.openProjectRoot(parent.getAbsolutePath());
                  return true;
                }
                return false;
              }
            });
    browser.setOnTouchListener(
        (view, event) -> {
          detector.onTouchEvent(event);
          return false;
        });
  }

  private String selectedBuildVariant = "debug";

  /** متغيرات البناء كما في المرجع: اختيار debug/release يُحفظ ويوجّه البناء. */
  void promptBuildVariant() {
    final String[] variants = {"debug", "release"};
    new android.app.AlertDialog.Builder(this)
        .setTitle(ui("command_build_variants"))
        .setItems(variants, (d, which) -> {
          selectedBuildVariant = variants[which];
          Toast.makeText(this, uiFormat("ui_build_current_variant", selectedBuildVariant), Toast.LENGTH_SHORT)
              .show();
        })
        .show();
  }

  /**
   * أمرُ البناءِ — مسارٌ واحدٌ لافرعانِ متوازيانِ: «Enable gradle system» (`advanced_setting_enable_gradle`)
   * عند المرجعِ يعني gradle النظامِ بدلَ gradlew المشروعِ؛ فالتنفيذُ هنا يختارُ بينهما، ويعيدُ null حينَ
   * طُلِبَ `gradlew` ولا wrapper في المشروعِ — فيُعلَنُ السببُ للمستخدمِ ولا يُبتَلَعُ الطلبُ صامتًا.
   */
  java.util.List<String> gradleInvocation(File root, String task) {
    if (root == null || task == null || task.isEmpty()) return null;
    if (almlk.AppSettings.useSystemGradle(this)) return Arrays.asList("gradle", task, "--no-daemon");
    return new File(root, "gradlew").isFile() ? Arrays.asList("sh", "gradlew", task, "--no-daemon") : null;
  }

  /** أينَ خرجَ الـAPK؟ الدليلُ كلُّهُ في {@link almlk.BuildOutputLocator}؛ المجلدُ والنسخةُ من الإعداداتِ. */
  File locateBuiltApk(File root) {
    return almlk.BuildOutputLocator.newestApk(
        root, almlk.AppSettings.apkOutputDir(this), selectedBuildVariant);
  }

  void runBuild(String task, String title) {
    File root = session == null ? null : session.directory();
    if (root == null || !root.isDirectory()) {
      showMessage(
          ui("ui_build_title"), ui("ui_build_local_path_required"));
      return;
    }
    java.util.List<String> invocation = gradleInvocation(root, task);
    if (invocation == null) {
      showMessage(ui("ui_build_title"), uiFormat("ui_gradle_wrapper_not_found", root.getAbsolutePath()));
      return;
    }
    buildDiagnostics.clear();
    publishProjectDiagnostics(true);
    showPanel(SequentialPanelHost.Panel.BUILD);
    final StringBuilder collectedBuildOutput = new StringBuilder(8192);
    if (sequentialPanels != null)
      sequentialPanels.setBuildOutput("$ sh gradlew " + task + " --no-daemon\n");
    View view = getLayoutInflater().inflate(R.layout.outputconsole, null);
    TextView output = view.findViewById(R.id.outputConsole);
    output.setTextColor(Color.LTGRAY);
    output.setTextSize(13);
    output.setPadding(dp(12), dp(10), dp(12), dp(10));
    AlertDialog dialog =
        new AlertDialog.Builder(this)
            .setTitle(title)
            .setView(view)
            .setNegativeButton(ui("ui_action_stop"), null)
            .create();
    dialog.setOnShowListener(
        x -> {
          dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener(v -> shell.cancel());
          Map<String, String> env = buildEnv(root);
          shell.run(
              root,
              buildCommand(invocation),
              env,
              new ShellCommandRunner.Listener() {
                public void onStart(String c) {
                  collectedBuildOutput.setLength(0);
                  output.setText("$ " + c + "\n\n");
                }

                public void onLine(String line) {
                  if (line != null) collectedBuildOutput.append(line).append('\n');
                  output.append(line + "\n");
                  if (sequentialPanels != null) sequentialPanels.appendBuildOutput(line);
                }

                public void onFinish(int code, boolean cancelled) {
                  String summary = cancelled ? ui("ui_process_stopped") : uiFormat("ui_process_finished_code", code);
                  File built = code == 0 && !cancelled ? locateBuiltApk(root) : null;
                  if (built != null)
                    summary = summary + "\n" + uiFormat("ui_build_apk_found", built.getAbsolutePath(),
                        almlk.MavenStore.formatSize(built.length()));
                  output.append("\n" + summary);
                  if (sequentialPanels != null) sequentialPanels.appendBuildOutput(summary);
                  if (!cancelled && browser != null) {
                    ArrayList<BuildDiagnosticsParser.BuildError> parsed =
                        BuildDiagnosticsParser.parse(collectedBuildOutput.toString());
                    if (!parsed.isEmpty())
                      browser.resolveBuildDiagnosticsAsync(
                          parsed,
                          found -> {
                            buildDiagnostics.clear();
                            if (found != null) buildDiagnostics.addAll(found);
                            publishProjectDiagnostics(true);
                            if (!buildDiagnostics.isEmpty()) showPanel(SequentialPanelHost.Panel.ERRORS);
                          });
                  }
                  dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setText(ui("ui_action_close"));
                  dialog
                      .getButton(AlertDialog.BUTTON_NEGATIVE)
                      .setOnClickListener(v -> dialog.dismiss());
                }
              });
        });
    dialog.setOnDismissListener(x -> shell.cancel());
    dialog.show();
  }

  /** المرحلة 2: بيئة البناء تحمل مفاتيح Build & Run المختارة (قناة SHIMA_* القائمة). */
  private Map<String, String> buildEnv(File root) {
    Map<String, String> env = new HashMap<>();
    env.put("SHIMA_CURRENT_PROJECT", root.getAbsolutePath());
    android.content.SharedPreferences sp = almlk.AppSettings.prefs(this);
    String jar = sp.getString("user_androidjar", "");
    if (!jar.isEmpty()) env.put("SHIMA_ANDROID_JAR", jar);
    // M1: مستودعات المستخدم المحلية ثم مخزن مكتباتنا، كي لا يعيد Gradle تنزيل ما نزّلناه.
    env.put("SHIMA_M2_REPOSITORIES", almlk.AppSettings.mavenStore(this).gradleRepositoriesValue());
    if (sp.getBoolean("optimze_dex", false)) env.put("SHIMA_OPTIMIZE_DEX", "1");
    if (sp.getBoolean("use_proguard", false)) env.put("SHIMA_USE_PROGUARD", "1");
    if (sp.getBoolean("native_build_parallel", false)) env.put("SHIMA_NATIVE_PARALLEL", "1");
    // W22/1: بقيةُ مفاتيحِ Build & Run وAdvanced في القناةِ نفسِها — لا صفٌّ يُوهِمُ بأنَّهُ يُغيّرُ شيئًا.
    if (almlk.AppSettings.dexMergerEnabled(this)) env.put("SHIMA_DEX_MERGER", "1");
    String apkOut = almlk.AppSettings.apkOutputDir(this);
    if (!apkOut.isEmpty()) env.put("SHIMA_APK_OUT", new File(root, apkOut).getAbsolutePath());
    if (sp.getBoolean("ndk_support_installed", false)) env.put("SHIMA_NDK_SUPPORT", "1");
    if (sp.getBoolean("use_user_keystore", false)) {
      String keystore = sp.getString("user_keystore", "");
      if (!keystore.isEmpty()) env.put("SHIMA_KEYSTORE", keystore);
    }
    String sshDir = sp.getString("git_dot_ssh_dir", "");
    if (!sshDir.isEmpty()) env.put("SHIMA_GIT_SSH_DIR", sshDir);
    if (sp.getBoolean("git_keep_ssh_session_info", false)) env.put("SHIMA_GIT_KEEP_SSH", "1");
    return env;
  }

  /** المرحلة 3: مرآة محلية للمزامنة التلقائية (auto_sync_dropbox) بلا خادم خارجي. */
  private void mirrorSync(String name, String content) {
    if (name == null || content == null) return;
    if (!almlk.AppSettings.prefs(this).getBoolean("auto_sync_dropbox", true)) return;
    try {
      java.io.File dir = new java.io.File(getFilesDir(), "dropbox_mirror");
      dir.mkdirs();
      java.io.File target = new java.io.File(dir, new java.io.File(name).getName());
      java.io.FileOutputStream out = new java.io.FileOutputStream(target);
      out.write(content.getBytes("UTF-8"));
      out.close();
    } catch (Exception ignored) {
      // المرآة تحسين لا شرط؛ فشلها لا يُسقط الحفظ.
    }
  }

  /**
   * W22/2a: زرُّ GIT في حوارِ إنشاءِ المشروعِ — استنساخٌ قصيرُ العمقِ في مجلدِ المشاريعِ عبرَ
   * قناةِ الأوامرِ نفسِها (`buildCommand` يحترمُ run_as_root، و`shell` يقتلُ الشجرةَ عندَ الإلغاءِ).
   * نجاحُ الاستنساخِ مشروعًا كانَ (فيه build.gradle/settings.gradle) يُفتَحُ مباشرةً، وإلّا
   * يُحدَّثُ الجردُ فقطْ — لا «استُنسخَ» كاذبةً بلا مجلدٍ.
   */
  private void cloneInto(
      final File targetDirectory, final String url, final ProjectWizard.CloneListener listener) {
    final File dest = new File(targetDirectory, almlk.ProjectNaming.repoName(url));
    if (dest.exists()) {
      if (listener != null) listener.onCloneFinished(null, dest.getName() + " already exists");
      return;
    }
    java.util.List<String> command =
        java.util.Arrays.asList("git", "clone", "--depth", "1", url, dest.getAbsolutePath());
    final StringBuilder tail = new StringBuilder(2048);
    shell.run(
        targetDirectory,
        buildCommand(command),
        new java.util.HashMap<>(),
        new ShellCommandRunner.Listener() {
          public void onStart(String c) {}

          public void onLine(String line) {
            if (line == null) return;
            if (tail.length() > 6000) tail.delete(0, tail.length() - 4000);
            tail.append(line).append('\n');
          }

          public void onFinish(int code, boolean cancelled) {
            if (code == 0 && dest.isDirectory()) {
              runOnUiThread(
                  () -> {
                    if (isGradleProject(dest) && browser != null) {
                      browser.openCreatedProject(dest);
                    } else if (browser != null) {
                      browser.refreshListing();
                    }
                    if (listener != null) listener.onCloneFinished(dest, null);
                  });
              return;
            }
            String reason =
                cancelled ? ui("toast_git_cancelled") : lastLineOf(tail, "git exit code " + code);
            runOnUiThread(() -> { if (listener != null) listener.onCloneFinished(null, reason); });
          }
        });
  }

  private static String lastLineOf(StringBuilder buffer, String fallback) {
    String text = buffer == null ? "" : buffer.toString().trim();
    if (text.isEmpty()) return fallback;
    int nl = text.lastIndexOf('\n');
    return (nl >= 0 ? text.substring(nl + 1) : text).trim();
  }

  /** مشروعُ Gradle؟ يُفتَحُ كمجلدِ عملٍ فقطْ إن كانَ كذلكَ، وإلّا بقيَ في المتصفِّحِ. */
  private static boolean isGradleProject(File directory) {
    return directory != null
        && directory.isDirectory()
        && (new File(directory, "settings.gradle").isFile()
            || new File(directory, "settings.gradle.kts").isFile()
            || new File(directory, "build.gradle").isFile());
  }

  /** المرحلة 3: إنشاء مستودع git عند الفتح وفق git_create_for_projects مع الهوية المحفوظة. */
  private void maybeInitGitRepo() {
    android.content.SharedPreferences sp = almlk.AppSettings.prefs(this);
    if (!sp.getBoolean("git_create_for_projects", false)) return;
    final java.io.File root = session == null ? null : session.directory();
    if (root == null || new java.io.File(root, ".git").exists()) return;
    String userName = sp.getString("git_user_name", "Shima");
    String userEmail = sp.getString("git_user_email", "shima@local");
    String script =
        "git init && git config user.name \"" + userName + "\" && git config user.email \""
            + userEmail + "\"";
    shell.run(
        root,
        java.util.Arrays.asList("sh", "-c", script),
        new java.util.HashMap<>(),
        new ShellCommandRunner.Listener() {
          public void onStart(String c) {}

          public void onLine(String line) {}

          public void onFinish(int code, boolean cancelled) {
            runOnUiThread(
                () -> android.widget.Toast.makeText(
                        MainActivity.this,
                        code == 0 ? ui("ui_git_repository_created") : ui("ui_git_repository_create_failed"),
                        android.widget.Toast.LENGTH_SHORT)
                    .show());
          }
        });
  }

  /** run_as_root: لفّ الأمر بـ su عند تفعيل المفتاح. */
  private java.util.List<String> buildCommand(java.util.List<String> cmd) {
    if (!almlk.AppSettings.prefs(this).getBoolean("run_as_root", false)) return cmd;
    StringBuilder joined = new StringBuilder();
    for (String part : cmd) {
      if (joined.length() > 0) joined.append(' ');
      joined.append(part);
    }
    return Arrays.asList("su", "-c", joined.toString());
  }

  void runShell(String command, String title) {
    File root = session == null ? null : session.directory();
    if (root == null) {
      showMessage(title, ui("ui_shell_needs_local_project"));
      return;
    }
    View view = getLayoutInflater().inflate(R.layout.outputconsole, null);
    TextView output = view.findViewById(R.id.outputConsole);
    output.setTextColor(Color.LTGRAY);
    output.setTextSize(13);
    AlertDialog dialog =
        new AlertDialog.Builder(this)
            .setTitle(title)
            .setView(view)
            .setNegativeButton(ui("ui_action_stop"), null)
            .create();
    dialog.setOnShowListener(
        x -> {
          dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener(v -> shell.cancel());
          Map<String, String> env = buildEnv(root);
          shell.run(
              root,
              buildCommand(Arrays.asList("sh", "-c", command)),
              env,
              new ShellCommandRunner.Listener() {
                public void onStart(String c) {
                  output.setText("$ " + command + "\n\n");
                }

                public void onLine(String line) {
                  output.append(line + "\n");
                }

                public void onFinish(int code, boolean stopped) {
                  output.append(stopped ? "\n" + ui("ui_process_stopped_short") : "\n" + uiFormat("ui_exit_code", code));
                  dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setText(ui("ui_action_close"));
                  dialog
                      .getButton(AlertDialog.BUTTON_NEGATIVE)
                      .setOnClickListener(v -> dialog.dismiss());
                }
              });
        });
    dialog.setOnDismissListener(x -> shell.cancel());
    dialog.show();
  }

  void promptTerminal() {
    final EditText input = new EditText(this);
    input.setHint(uiFormat("ui_terminal_example_hint", "./gradlew tasks"));
    input.setSingleLine(true);
    new AlertDialog.Builder(this)
        .setTitle(ui("ui_terminal_title"))
        .setView(input)
        .setNegativeButton(ui("dialog_cancel"), null)
        .setPositiveButton(
            ui("ui_terminal_run"),
            (d, w) -> {
              String c = input.getText().toString().trim();
              if (!c.isEmpty()) runShell(c, ui("ui_terminal_title"));
            })
        .show();
  }

  void promptCommit() {
    final EditText input = new EditText(this);
    input.setHint(ui("ui_commit_message_hint"));
    input.setSingleLine(true);
    new AlertDialog.Builder(this)
        .setTitle(ui("ui_git_commit_title"))
        .setView(input)
        .setNegativeButton(ui("dialog_cancel"), null)
        .setPositiveButton(
            ui("ui_action_commit"),
            (d, w) -> {
              String m = input.getText().toString().trim();
              if (!m.isEmpty()) runShell("git commit -m " + shellQuote(m), "Git");
            })
        .show();
  }

  String shellQuote(String value) {
    return "'" + value.replace("'", "'\\''") + "'";
  }

  void showMessage(String title, String text) {
    new AlertDialog.Builder(this)
        .setTitle(title)
        .setMessage(text)
        .setPositiveButton(ui("ui_action_ok"), null)
        .show();
  }

  @Override
  public boolean hasProject() {
    return projectOpen && session != null && session.isOpen();
  }

  @Override
  public boolean hasEditor() {
    return editor != null && editor.hasOpenFile();
  }

  @Override
  public boolean hasExplicitEditorSelection() {
    return hasEditor() && editor.hasExplicitEditorSelection();
  }

  @Override
  public boolean canUndo() {
    return hasEditor() && editor.canUndoEdit();
  }

  @Override
  public boolean canRedo() {
    return hasEditor() && editor.canRedoEdit();
  }

  @Override
  public boolean isXmlEditor() {
    if (!hasEditor()) return false;
    return almlk.XmlCodeFormatter.isXmlName(editor.getActiveFile());
  }

  @Override
  public boolean isEditorWritable() {
    return hasEditor() && editor.isActiveFileWritableNow();
  }

  /** ج٤٢: الدَّفْتَرُ هُوَ المَنبَعُ — لِسانٌ خَامِلٌ مُعَلَّقٌ يُفعِّلُ «احفَظِ الكُلَّ» بلا سَبَبٍ آخَرَ. */
  @Override
  public boolean hasPendingEdits() {
    return editor != null && !editor.dirtyTabs().isEmpty();
  }

  @Override
  public boolean isLayoutXmlEditor() {
    return activeLayoutXml();
  }

  @Override
  public boolean panelsShowing() {
    return drawer != null && drawer.isDrawerOpen(Gravity.START);
  }

  @Override
  public boolean hasGradleProject() {
    File root = session == null ? null : session.directory();
    return root != null
        && (new File(root, "build.gradle").isFile() || new File(root, "build.gradle.kts").isFile());
  }

  @Override
  public void onBuildFilesChanged(File buildFile) {
    File root = session == null ? null : session.directory();
    if (root != null) dependencyCycle().start(root, com.almlkid.ui.DependencyCycle.Mode.SAVE);
  }

  // ═══════════════ 1.0.175: الجَلبُ الصامتُ عندَ الرمزِ غيرِ المحلولِ ═══════════════

  /**
   * جَلبُ اعتمادٍ طلبَهُ القارئُ من تشخيصِ استيرادٍ: لا «Modify files»، لا {@code ProgressDialog}، لا
   * {@code gradle} — الخطةُ والقرصُ على خيطٍ عاملٍ، وسطرُ الحالةِ هو <b>سطرُ حالةِ اللوحةِ التسلسُليّةِ
   * القائمُ</b> (نفسُ ما يَستعمِلُهُ البحثُ عن الاستعمالاتِ)، والكتابةُ في {@code dependencies {}} عبرَ
   * {@link almlk.DependencyFetchQueue} وحدَهُ، ثمَّ دورةُ اعتمادياتٍ واحدةٌ بإعادةِ فحصٍ موضعيّةٍ فلا
   * يتحرَّكُ المؤشرُ ولا المِرناءُ (W20/3).
   */
  private boolean startDependencyFetch(final almlk.QuickFix fix) {
    if (fix == null || session == null || !session.isOpen()) return false;
    final File root = session.directory();
    final File buildFile = almlk.GradleDependencyEditor.moduleBuildFile(root);
    if (root == null || buildFile == null) return false;
    final almlk.DependencyFetchQueue queue = almlk.DependencyFetchQueue.forProject(root);
    if (queue.transport() == null) queue.setTransport(dependencyTransport(root));
    if (queue.listener() == null) queue.setListener(dependencyListener());
    final boolean kts = buildFile.getName().endsWith(".kts");
    new Thread(
            () -> {
              // 1.0.176: وحدةُ الصنفِ أولًا — إن كانَ الملفُّ تحتَ مصدرِ وحدةٍ أُخرَى كُتِبَ السطرُ هناك،
              // وإلا فملفُّ بناءِ الجذرِ (الجهلُ لا يُخمَّنُ). القراءةُ كلُّها على هذا الخيطِ لا على الواجهةِ.
              File targetBuild = buildFile;
              almlk.GradleBuildModel cycleModel = dependencyCycle() == null ? null : dependencyCycle().model();
              if (cycleModel != null && cycleModel.projectModules != null) {
                String activeRef = editor == null ? null : editor.getActiveFileReference();
                File moduleBuild =
                    activeRef == null || activeRef.isEmpty()
                        ? null
                        : cycleModel.projectModules.buildFileFor(new File(activeRef));
                if (moduleBuild != null && moduleBuild.isFile()) targetBuild = moduleBuild;
              }
              final File buildForWrite = targetBuild;
              final boolean ktsForWrite = buildForWrite.getName().endsWith(".kts");
              String buildText = "";
              try {
                buildText = almlk.DependencyFetchQueue.read(buildForWrite);
              } catch (Exception unreadable) {
                buildText = "";
              }
              almlk.UnresolvedSymbolRule.Tally tally = new almlk.UnresolvedSymbolRule.Tally();
              final almlk.DependencyFetchPlan plan =
                  almlk.UnresolvedSymbolRule.planForSymbol(
                      fix.methodName,
                      fix.targetClass,
                      buildText,
                      ktsForWrite,
                      /* offline= */ false,
                      dependencyProvider(),
                      tally);
              if (!almlk.UnresolvedSymbolRule.shouldQueue(plan)) {
                final String refused =
                    plan.statusKey().isEmpty() ? "ui_fetch_status_not_found" : plan.statusKey();
                runOnUiThread(() -> sequentialPanels.setSearchStatus(ui(refused)));
                return;
              }
              queue.enqueue(buildForWrite, ktsForWrite, java.util.Collections.singletonList(plan));
            },
            "DependencyPlan")
        .start();
    return true;
  }

  /** ما يَعرِفُ المخزنُ المحليُّ: إحداثيّةٌ مُثبَّتةٌ تُقدَّمُ على كلِّ اشتقاقٍ، بلا قرصٍ في خيطِ الواجهةِ. */
  private almlk.UnresolvedSymbolRule.Provider dependencyProvider() {
    final almlk.MavenStore store = almlk.AppSettings.mavenStore(this);
    return new almlk.UnresolvedSymbolRule.Provider() {
      @Override
      public String qualifiedFor(String simpleName) {
        return null; // الاسمُ المؤهَّلُ وصلَ مِنَ التشخيصِ نفسِهِ؛ لا بحثَ في باقاتٍ من مُبسَّطٍ وحدَهُ
      }

      @Override
      public int candidatesFor(String simpleName) {
        return 0;
      }

      @Override
      public String coordinateFor(String qualifiedName) {
        if (store == null || qualifiedName == null) return null;
        int dot = qualifiedName.lastIndexOf('.');
        if (dot <= 0) return null;
        String pkg = qualifiedName.substring(0, dot);
        // الاستعلامُ عن الباقةِ الأولى والثانيةِ فقط: هما «المجموعةُ» في عُرفِ ‏{@code group:artifact}،
        // وبها يُجيِبُ فهرسُ المخزنِ على اسمِ الحزمةِ لا على اسمِ الصنفِ.
        String query = pkg;
        int first = pkg.indexOf('.');
        int second = first > 0 ? pkg.indexOf('.', first + 1) : -1;
        if (second > 0) query = pkg.substring(0, second);
        try {
          for (almlk.MavenIndex.Hit hit :
              almlk.MavenIndex.search(query, almlk.MavenIndex.sources(store), 4)) {
            String coordinate = hit == null ? null : hit.coordinate();
            if (coordinate != null && coordinate.indexOf(':') > 0) return coordinate;
          }
        } catch (RuntimeException unreadableIndex) {
          return null; // الفهرسُ القرصيُّ ترفٌّ في هذهِ الطريقِ: الاشتقاقُ يَكفي
        }
        return null;
      }
    };
  }

  /** التثبيتُ في المخزنِ: {@link almlk.MavenResolver} نفسُهُ الذي تَستعمِلُهُ دورةُ الاعتمادياتِ. */
  private almlk.DependencyFetchQueue.Transport dependencyTransport(final File root) {
    return plan -> {
      if (plan == null || plan.coordinate.indexOf(':') <= 0) return false;
      almlk.MavenStore store = almlk.AppSettings.mavenStore(MainActivity.this);
      almlk.GradleBuildModel model = almlk.GradleBuildModel.load(root);
      java.io.File mavenLocal =
          new java.io.File(
              android.os.Environment.getExternalStorageDirectory(), ".m2/repository");
      java.util.List<almlk.MavenResolver.Repo> repos =
          almlk.MavenResolver.repositories(
              model, mavenLocal, almlk.AppSettings.extraRepositories(MainActivity.this));
      java.util.List<almlk.MavenResolver.Request> requests =
          java.util.Collections.singletonList(almlk.MavenResolver.Request.of(plan.coordinate));
      almlk.MavenResolver.Result result =
          new almlk.MavenResolver(store, repos, new almlk.MavenDownloader())
              .resolve(requests, false, null, null);
      return result != null && result.ok();
    };
  }

  /** سطرُ الحالةِ ثمَّ أثرُ الكتابةِ: دورةُ اعتمادياتٍ واحدةٌ وإعادةُ فحصِ ما مَسَّهُ التغييرُ وحدَهُ. */
  private almlk.DependencyFetchQueue.Listener dependencyListener() {
    return new almlk.DependencyFetchQueue.Listener() {
      @Override
      public void onFetchStatus(String statusKey, String coordinate) {
        final String line =
            coordinate == null || coordinate.isEmpty()
                ? ui(statusKey)
                : uiFormat(statusKey, coordinate);
        runOnUiThread(() -> sequentialPanels.setSearchStatus(line));
      }

      @Override
      public void onFetchFinished(
          almlk.DependencyFetchQueue.Outcome outcome, int written, int fetched, int failed) {
        runOnUiThread(
            () -> {
              sequentialPanels.setSearchStatus(ui(fetchOutcomeKey(outcome)));
              if (written > 0) {
                // سطرُ {@code dependencies {}} الجديدُ يَمُرُّ بالمسارِ القائمِ نفسِهِ الذي يَمُرُّ بِهِ
                // حفظُ ملفِّ البناءِ: دورةُ اعتمادياتٍ، لا إعادةَ مسحٍ للمشروعِ ولا بناءً للمستخدمِ.
                onBuildFilesChanged(almlk.GradleDependencyEditor.moduleBuildFile(
                    session == null ? null : session.directory()));
                Toast.makeText(MainActivity.this, ui("ui_add_dependency_added"), Toast.LENGTH_SHORT).show();
              }
              if (written > 0 || fetched > 0) reinspectAfterQuickFix(null, null);
            });
        }
    };
  }

  private static String fetchOutcomeKey(almlk.DependencyFetchQueue.Outcome outcome) {
    if (outcome == almlk.DependencyFetchQueue.Outcome.FAILED) return "ui_fetch_status_failed_all";
    if (outcome == almlk.DependencyFetchQueue.Outcome.PARTIAL) return "ui_fetch_status_partial";
    if (outcome == almlk.DependencyFetchQueue.Outcome.REJECTED) return "ui_fetch_status_overloaded";
    return "ui_fetch_status_done";
  }

  @Override
  public void execute(String id) {
    switch (id) {
      case "run":
      case "build_debug":
        // ج٤٢: البِناءُ على ما في المُحرِّرِ لا على ما على القُرسِ — حِفظُ الكُلِّ أوَّلًا ثُمَّ البِناءُ.
        saveAllThen(
            () -> runBuild("assembleDebug", ui(id.equals("run") ? "command_run" : "menu_build_debug")));
        break;
      case "build_release":
        saveAllThen(() -> runBuild("assembleRelease", ui("menu_build_release")));
        break;
      case "clean":
        saveAllThen(() -> runBuild("clean", ui("menu_clean")));
        break;
      case "terminal":
        promptTerminal();
        break;
      case "save_all":
        if (editor == null || editor.dirtyTabs().isEmpty())
          Toast.makeText(this, ui("ui_save_all_none"), Toast.LENGTH_SHORT).show();
        else saveAllThen(null);
        break;
      case "save":
        browser.saveOpenedFileAsync(
            editor.getActiveFile(),
            editor.getTextContent(),
            (saved, message) -> {
              if (saved) {
                editor.markSaved();
                mirrorSync(editor.getActiveFile(), editor.getTextContent());
                onFileSaved(editor.getActiveFile());
              }
              Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
            });
        break;
      case "undo":
        editor.undoEdit();
        break;
      case "redo":
        editor.redoEdit();
        break;
      case "find":
        promptFind();
        break;
      case "replace":
        promptReplace();
        break;
      case "goto_line":
        promptGotoLine();
        break;
      case "goto_element":
      case "goto_definition":
        // يلزم تحديد صريح: التعريف يفتح استخدامات الدالة/الحقل، والمرجع يقفز إلى تعريفه.
        editor.requestDefinitionForCurrentSelection();
        break;
      case "format":
        editor.formatSource();
        Toast.makeText(this, ui("ui_format_source_complete"), Toast.LENGTH_SHORT).show();
        break;
      case "comment":
        editor.toggleLineComment();
        break;
      case "select_all":
        editor.selectAllText();
        break;
      case "analyze":
        showDiagnostics();
        break;
      case "complete":
        showCompletions();
        break;
      case "find_usages":
        editor.requestUsageForCurrentSelection();
        break;
      case "design":
        openDesigner();
        break;
      case "panels":
        // سلوك المرجع: عنصر اللوحات يتبدّل بين الإظهار والإخفاء حسب الحالة الراهنة.
        if (panelsShowing()) closeSequentialPanels();
        else showPanel(SequentialPanelHost.Panel.ERRORS);
        break;
      case "show_errors":
        showPanel(SequentialPanelHost.Panel.ERRORS);
        break;
      case "show_search_results":
        showPanel(SequentialPanelHost.Panel.SEARCH);
        break;
      case "show_build_output":
        showPanel(SequentialPanelHost.Panel.BUILD);
        break;
      case "show_debugger":
        showPanel(SequentialPanelHost.Panel.DEBUGGER);
        break;
      case "show_logcat":
        showPanel(SequentialPanelHost.Panel.LOGCAT);
        break;
      case "close_file":
        editor.closeCurrent();
        if (!editor.hasOpenFile()) {
          empty.setVisibility(View.VISIBLE);
          editor.setVisibility(View.GONE);
          if (masterButton != null) masterButton.setVisibility(View.GONE);
        }
        break;
      case "close_all":
        editor.closeAll();
        empty.setVisibility(View.VISIBLE);
        editor.setVisibility(View.GONE);
        if (masterButton != null) masterButton.setVisibility(View.GONE);
        break;
      case "files":
        openFilesBrowser();
        break;
      case "new_file":
        openFilesBrowser();
        browser.createFile();
        break;
      case "new_folder":
        openFilesBrowser();
        browser.createFolder();
        break;
      case "refresh":
        browser.refresh();
        break;
      case "git_status":
        runShell("git status --short --branch", ui("ui_command_git_status"));
        break;
      case "git_log":
        runShell("git log --oneline -n 20", ui("ui_command_git_log"));
        break;
      case "git_add":
        runShell("git add -A && git status --short", ui("ui_command_git_add"));
        break;
      case "git_commit":
        promptCommit();
        break;
      case "git_pull":
        runShell("git pull --ff-only", ui("command_git_pull"));
        break;
      case "git_push":
        runShell("git push", ui("command_git_push"));
        break;
      case "theme":
        startActivityForResult(new android.content.Intent(this, ThemeActivity.class), 88);
        break;
      case "permissions":
        showPermissionsCenter();
        break;
      case "documentation":
        openDocumentation();
        break;
      case "settings":
        startActivity(new Intent(this, com.almlkid.ui.preferences.AlmlkPreferencesActivity.class));
        break;
      case "exit":
        confirmExit();
        break;
      case "close_project":
        closeCurrentProject();
        break;
      case "publish_project":
        runBuild("assembleRelease", ui("command_publish_project"));
        break;
      case "select_build_variant":
        promptBuildVariant();
        break;
      case "refresh_build":
        confirmRefreshBuild();
        break;
      case "convert_project":
        promptConvertProject();
        break;
      case "go_to_directory":
        promptGoToDirectory();
        break;
      case "material_icons":
        openMaterialIcons();
        break;
      case "syntax_highlighting":
        startActivityForResult(
            new Intent(this, ThemeActivity.class)
                .putExtra(ThemeActivity.EXTRA_TITLE, ui("menu_syntax_highlighting")),
            88);
        break;
      case "escape_java":
        com.almlkid.ui.tools.ToolDialogs.showJavaEscape(this);
        break;
      case "escape_xml":
        com.almlkid.ui.tools.ToolDialogs.showXmlEscape(this);
        break;
      case "batch_replace":
        saveAllThen(this::openBatchReplace);
        break;
      case "json2bean":
        openJsonBean();
        break;
      case "system_resources":
        startActivity(new Intent(this, com.almlkid.ui.tools.SystemResourcesActivity.class));
        break;
      case "forward":
        Toast.makeText(this, ui("ui_forward_history_empty"), Toast.LENGTH_SHORT).show();
        break;
      case "rename":
        editor.renameCurrentSelection();
        break;
      case "inline":
        editor.refactorInline();
        break;
      case "introduce":
        editor.refactorIntroduce();
        break;
      case "extract_method":
        editor.refactorExtract();
        break;
      case "create_setters":
        editor.codegenSetters();
        break;
      case "create_constructor":
        editor.codegenConstructor();
        break;
      case "extract_resources":
        editor.codegenExtractResource();
        break;
      case "organize_imports":
        editor.organizeImports();
        break;
      case "surround_try":
        editor.surroundWithTryCatch();
        break;
      case "learn_style":
        learnCodeStyle();
        break;
      case "configure_style":
        startActivity(new Intent(this, CodeStyleActivity.class));
        break;
      case "about":
        showMessage(
            ui("ui_about_title"), ui("ui_about_message"));
        break;
    }
  }

  void showDiagnostics() {
    showSequentialPanels(SequentialPanelHost.Panel.ERRORS);
    reportAnalysisGateIfNeeded();
    if (editor != null) editor.refreshSemanticDiagnostics();
    if (sequentialPanels != null) sequentialPanels.setProjectDiagnostics(displayedDiagnostics);
  }

  void showCompletions() {
    // المراحل 1-4: نفس النافذة الحية المنمطة (أيقونات+توقيع) مع الالتزام الذكي والاستيراد.
    editor.showCompletionPopup();
  }

  void promptFind() {
    LinearLayout box = new LinearLayout(this);
    box.setOrientation(LinearLayout.VERTICAL);
    final EditText input = new EditText(this);
    input.setHint(ui("ui_find_text_hint"));
    input.setSingleLine(true);
    final CheckBox project = new CheckBox(this);
    final CheckBox caseSensitive = new CheckBox(this);
    final CheckBox wholeWord = new CheckBox(this);
    final CheckBox regex = new CheckBox(this);
    project.setText(ui("ui_search_project_checkbox"));
    caseSensitive.setText(ui("ui_match_case_checkbox"));
    wholeWord.setText(ui("ui_whole_word_checkbox"));
    regex.setText(ui("ui_regex_checkbox"));
    box.addView(input);
    box.addView(project);
    box.addView(caseSensitive);
    box.addView(wholeWord);
    box.addView(regex);
    regex.setOnCheckedChangeListener((button, checked) -> {
      wholeWord.setEnabled(!checked);
      if (checked) wholeWord.setChecked(false);
    });
    new AlertDialog.Builder(this)
        .setTitle(ui("ui_find_title"))
        .setMessage(ui("ui_find_description"))
        .setView(box)
        .setNegativeButton(ui("dialog_cancel"), null)
        .setPositiveButton(
            ui("ui_action_search"),
            (d, w) -> {
              String text = input.getText().toString().trim();
              if (text.isEmpty()) {
                Toast.makeText(this, ui("ui_enter_search_text"), Toast.LENGTH_SHORT).show();
                return;
              }
              ProjectSearchEngine.Query query =
                  new ProjectSearchEngine.Query(
                      text,
                      caseSensitive.isChecked(),
                      wholeWord.isChecked(),
                      regex.isChecked(),
                      ProjectSearchEngine.DEFAULT_MAX_RESULTS);
              if (project.isChecked()) {
                showSequentialPanels(SequentialPanelHost.Panel.SEARCH);
                sequentialPanels.setSearchStatus(ui("ui_searching_project_files"));
                sequentialPanels.setSearchResults(Collections.emptyList(), text);
                browser.searchProjectAsync(
                    query,
                    (results, filesScanned, cancelled) -> {
                      if (sequentialPanels == null) return;
                      sequentialPanels.setSearchResults(results, text);
                      sequentialPanels.setSearchStatus(
                          cancelled
                              ? uiFormat("ui_search_cancelled_count", filesScanned)
                              : uiFormat("ui_search_completed_count", filesScanned, results.size()));
                    });
              } else {
                boolean found = editor.findText(
                    text,
                    caseSensitive.isChecked(),
                    wholeWord.isChecked(),
                    regex.isChecked(),
                    true);
                Toast.makeText(
                        this,
                        ui(found ? "ui_next_match" : "ui_text_not_found"),
                        Toast.LENGTH_SHORT)
                    .show();
              }
            })
        .show();
  }

  void promptReplace() {
    promptReplace("");
  }

  void promptReplace(String initialQuery) {
    LinearLayout box = new LinearLayout(this);
    box.setOrientation(LinearLayout.VERTICAL);
    final EditText from = new EditText(this), to = new EditText(this);
    from.setHint(ui("ui_find_replace_from_hint"));
    from.setText(initialQuery == null ? "" : initialQuery);
    if (from.length() > 0) from.setSelection(from.length());
    to.setHint(ui("ui_find_replace_to_hint"));
    final CheckBox caseSensitive = new CheckBox(this);
    final CheckBox wholeWord = new CheckBox(this);
    final CheckBox regex = new CheckBox(this);
    caseSensitive.setText(ui("ui_match_case_checkbox"));
    wholeWord.setText(ui("ui_whole_word_checkbox"));
    regex.setText(ui("ui_regex_checkbox"));
    regex.setOnCheckedChangeListener((button, checked) -> {
      wholeWord.setEnabled(!checked);
      if (checked) wholeWord.setChecked(false);
    });
    box.addView(from);
    box.addView(to);
    box.addView(caseSensitive);
    box.addView(wholeWord);
    box.addView(regex);
    new AlertDialog.Builder(this)
        .setTitle(ui("ui_find_replace_title"))
        .setView(box)
        .setNegativeButton(ui("dialog_cancel"), null)
        .setPositiveButton(
            ui("ui_action_replace_all"),
            (d, w) -> editor.replaceAllAsync(
                from.getText().toString(),
                to.getText().toString(),
                caseSensitive.isChecked(),
                wholeWord.isChecked(),
                regex.isChecked(),
                count -> Toast.makeText(
                    this, uiFormat("ui_replace_count", count), Toast.LENGTH_SHORT).show()))
        .show();
  }

  void promptGotoLine() {
    final EditText input = new EditText(this);
    input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
    input.setHint(ui("ui_line_number_hint"));
    new AlertDialog.Builder(this)
        .setTitle(ui("ui_go_to_line_title"))
        .setView(input)
        .setNegativeButton(ui("dialog_cancel"), null)
        .setPositiveButton(
            ui("command_goto_line"),
            (d, w) -> {
              try {
                if (!editor.goToLine(Integer.parseInt(input.getText().toString())))
                  Toast.makeText(this, ui("ui_line_out_of_range"), Toast.LENGTH_SHORT).show();
              } catch (Exception e) {
                Toast.makeText(this, ui("ui_enter_valid_number"), Toast.LENGTH_SHORT).show();
              }
            })
        .show();
  }

  /** ملف التبويب النشط تخطيط XML (داخل res/layout*) — شرط ظهور زر معاينة التصميم. */
  boolean activeLayoutXml() {
    if (editor == null || !projectOpen) return false;
    // اسم التبويب قصير — الموقع الحقيقي في المرجع المستقر (مسار كامل أو SAF URI مرمّز).
    String candidate = editor.getActiveFileReference();
    if (candidate == null || candidate.isEmpty()) candidate = editor.getActiveFile();
    if (candidate == null) return false;
    if (candidate.startsWith("content:")) candidate = android.net.Uri.decode(candidate);
    String normalized = candidate.replace('\\', '/').toLowerCase(java.util.Locale.US);
    if (!normalized.endsWith(".xml")) return false;
    int slash = normalized.lastIndexOf('/');
    if (slash <= 0) return false;
    int parentSlash = normalized.lastIndexOf('/', slash - 1);
    String parent = normalized.substring(parentSlash + 1, slash);
    return "layout".equals(parent) || parent.startsWith("layout-");
  }

  /** فتح المصمم على النص الحي للتبويب النشط — المعاينة تعكس آخر ما كتبته ولو غير محفوظ. */
  void openDesigner() {
    if (editor == null || !activeLayoutXml()) return;
    if (!editor.isActiveFileWritableNow()) {
      Toast.makeText(this, ui("ui_file_read_only"), Toast.LENGTH_SHORT).show();
      return;
    }
    android.content.Intent intent = new android.content.Intent(this, DesignerActivity.class);
    intent.putExtra("xml", editor.getTextContent());
    String reference = editor.getActiveFileReference();
    intent.putExtra("file", reference.isEmpty() ? editor.getActiveFile() : reference);
    startActivityForResult(intent, 7801);
  }


  /** إعادة بناء الشريط فقط عند انقلاب أهلية التراجع/الإعادة فعلًا — لا عمل زائدًا بكل حرف. */
  void refreshEditingToolbarState() {
    if (editor == null) return;
    if (!editingToolbar) {
      // خارج وضع الكتابة: تبديل التبويب قد يبدّل زر القلم/معاينة التصميم.
      invalidateOptionsMenu();
      return;
    }
    boolean canUndo = editor.canUndoEdit();
    boolean canRedo = editor.canRedoEdit();
    if (canUndo != lastCanUndo || canRedo != lastCanRedo || hasPendingEdits() != lastPendingEdits)
      invalidateOptionsMenu();
  }

  void hideMasterButtonWithKeyboard(final View masterButton) {
    final View root = getWindow().getDecorView();
    final int[] largestVisibleHeight = {0};
    root.getViewTreeObserver()
        .addOnGlobalLayoutListener(
            () -> {
              android.graphics.Rect frame = new android.graphics.Rect();
              root.getWindowVisibleDisplayFrame(frame);
              int currentHeight = frame.height();
              if (currentHeight > largestVisibleHeight[0]) largestVisibleHeight[0] = currentHeight;
              int difference = largestVisibleHeight[0] - currentHeight;
              boolean keyboardShown = difference > Math.max(dp(170), largestVisibleHeight[0] / 6);
              boolean editorActive =
                  editor != null && editor.hasOpenFile() && editor.getVisibility() == View.VISIBLE;
              int expected = keyboardShown || !editorActive ? View.GONE : View.VISIBLE;
              if (masterButton.getVisibility() != expected) masterButton.setVisibility(expected);
              // شريط وضع التحرير (دلالة المرجع): يتبدل مع ظهور كيبورد المحرر وإخفائه.
              boolean editingNow = keyboardShown && editorActive;
              if (editingNow != editingToolbar) {
                editingToolbar = editingNow;
                invalidateOptionsMenu();
              }
            });
  }

  void showStartupError(Throwable error) {
    ActionBar bar = getActionBar();
    if (bar != null) bar.hide();
    LinearLayout page = new LinearLayout(this);
    page.setOrientation(LinearLayout.VERTICAL);
    page.setPadding(dp(20), dp(24), dp(20), dp(16));
    page.setBackgroundColor(almlk.ChromeTheme.appBackground(this));
    TextView title = new TextView(this);
    title.setText(ui("ui_safe_startup_error_title"));
    title.setTextColor(almlk.ChromeTheme.primaryText(this));
    title.setTextSize(22);
    page.addView(title);
    TextView message = new TextView(this);
    message.setText(
        ui("ui_safe_startup_error_body"));
    message.setTextColor(almlk.ChromeTheme.secondaryText(this));
    message.setPadding(0, dp(10), 0, dp(12));
    page.addView(message);
    TextView log = new TextView(this);
    log.setText(CrashStore.read(this));
    log.setTextColor(almlk.ChromeTheme.errorText(this));
    log.setTextSize(11);
    log.setTypeface(android.graphics.Typeface.MONOSPACE);
    log.setTextIsSelectable(true);
    ScrollView scroll = new ScrollView(this);
    scroll.addView(log);
    page.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
    Button safe = new Button(this);
    safe.setText(ui("ui_open_safe_mode"));
    safe.setOnClickListener(v -> showSafeMode());
    page.addView(safe);
    Button retry = new Button(this);
    retry.setText(ui("ui_retry"));
    retry.setOnClickListener(v -> recreate());
    page.addView(retry);
    setContentView(page);
  }

  void showSafeMode() {
    ActionBar bar = getActionBar();
    if (bar != null) bar.hide();
    LinearLayout page = new LinearLayout(this);
    page.setOrientation(LinearLayout.VERTICAL);
    page.setGravity(Gravity.CENTER_HORIZONTAL);
    page.setPadding(dp(24), dp(42), dp(24), dp(20));
    page.setBackgroundColor(almlk.ChromeTheme.appBackground(this));
    ImageView logo = new ImageView(this);
    logo.setImageResource(R.drawable.ic_launcher);
    page.addView(logo, new LinearLayout.LayoutParams(dp(80), dp(80)));
    TextView title = new TextView(this);
    title.setText(ui("ui_safe_mode_title"));
    title.setTextColor(almlk.ChromeTheme.primaryText(this));
    title.setTextSize(22);
    title.setGravity(Gravity.CENTER);
    title.setPadding(0, dp(18), 0, dp(8));
    page.addView(title);
    TextView note = new TextView(this);
    note.setText(
        ui("ui_safe_mode_body"));
    note.setTextColor(almlk.ChromeTheme.secondaryText(this));
    note.setTextSize(15);
    note.setGravity(Gravity.CENTER);
    page.addView(note, new LinearLayout.LayoutParams(-1, 0, 1));
    Button retry = new Button(this);
    retry.setText(ui("ui_open_full_interface"));
    retry.setOnClickListener(
        v -> {
          getIntent().removeExtra("safe_mode");
          recreate();
        });
    page.addView(retry, new LinearLayout.LayoutParams(-1, dp(52)));
    Button report = new Button(this);
    report.setText(ui("ui_show_last_error"));
    report.setOnClickListener(
        v -> startActivity(new android.content.Intent(this, RecoveryActivity.class)));
    page.addView(report, new LinearLayout.LayoutParams(-1, dp(52)));
    setContentView(page);
  }

  private String ui(String key) {
    return UiStrings.get(this, key);
  }

  private String uiFormat(String key, Object... values) {
    return UiStrings.format(this, key, values);
  }

  int dp(int n) {
    return (int) (n * getResources().getDisplayMetrics().density + .5f);
  }

  @Override
  public void onBackPressed() {
    if (drawer != null && drawer.isDrawerOpen(Gravity.START)) {
      drawer.closeDrawers();
      return;
    }
    // الانتقال لعنصر ثم «عودة» يعيد للكلاس/الموضع السابق عبر سجل التنقل.
    if (editor != null && editor.navigateBack()) return;
    // مع مشروع مفتوح: «عودة» تعرض قائمة الملفات/الكلاسات ولا تُخرج المشروع لشاشة الفراغ.
    if (projectOpen) {
      if (drawer != null) drawer.openDrawer(Gravity.START);
      return;
    }
    super.onBackPressed();
  }
}
