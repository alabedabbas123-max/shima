package com.almlkid.kay.ui;

import android.content.Context;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.util.Log;
import android.view.ActionMode;
import android.view.Menu;
import android.view.MenuItem;
import almlk.CodeEditorView;
import almlk.DiagnosticSpanIndex;
import almlk.IdentifierOccurrences;
import almlk.ImportSoundness;
import almlk.IncrementalScope;
import almlk.DiagnosticUnderline;
import almlk.LineOffsetTable;
import almlk.MarkTable;
import almlk.QuickFixBubble;
import almlk.IdentifierBounds;
import almlk.LineDocument;
import almlk.LineStyler;
import almlk.XmlColorLiteral;
import com.almlkid.kay.ui.CodeLanguageTools;
import com.shima.demo.ThemeConfig;
import com.shima.demo.UiStrings;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import almlk.AnalyzerProtocol;
import com.almlkid.analyzer.AnalyzerConnection;

/**
 * واجهة المحرر الرسمية للتطبيق — نفس اسم الكلاس والـAPI العام كما كان، لكنها بعد بند الإحلال
 * (البند 4) يقودها محرك almlk الكامل: لوحة رسم مخصصة + موديل أسطر + ملوّن تزايدي خلفي +
 * إدخال OEditor + تراجع مدمج. حُذف مسار EditText/Spans القديم نهائيًا (لا مساران متوازيان).
 *
 * <p>محوّلات التوافق الباقية (adapters — يسمح بها البند 4): التشخيصات والإكمال والتنسيق عبر
 * {@link CodeLanguageTools}، وفهرسة الرموز عبر ProjectSymbolIndex من طبقة الـPager كما كانت.
 */
import almlk.EditorSyntaxRoles;

public class AlmlkEditor extends CodeEditorView {

  public interface DiagnosticsListener {
    void onDiagnostics(List<CodeLanguageTools.Diagnostic> items);
  }

  public interface ChangeListener {
    void onChanged(long documentVersion);
  }

  public interface ScrollListener {
    void onEditorScroll(int x, int y);

    void onEditorZoom(float textSizePixels);
  }

  /** نتيجة تأكيد معاملة لون: تطبيق واحد، أو لا تغيير، أو إلغاء لأن المصدر صار بائتًا. */
  public enum ColorLiteralEditResult {
    APPLIED,
    UNCHANGED,
    STALE
  }

  /** لقطة غير قابلة للتعديل لهوية literal عند فتح المنتقي. */
  public static final class ColorLiteralEdit {
    private final long documentVersion;
    private final int startOffset;
    private final int endOffset;
    private final int line;
    private final int startColumn;
    private final int endColumn;
    private final int originalArgb;
    private final XmlColorLiteral.Format format;
    private final XmlColorLiteral literal;
    private final String originalText;

    private ColorLiteralEdit(
        long documentVersion,
        int startOffset,
        int endOffset,
        XmlColorLiteral literal,
        String originalText) {
      this.documentVersion = documentVersion;
      this.startOffset = startOffset;
      this.endOffset = endOffset;
      this.line = literal.line;
      this.startColumn = literal.startColumn;
      this.endColumn = literal.endColumn;
      this.originalArgb = literal.argb;
      this.format = literal.format;
      this.literal = literal;
      this.originalText = originalText;
    }

    public int originalArgb() {
      return originalArgb;
    }
  }

  // ---------------- الحقول ----------------

  /** لونُ كلِّ نمطٍ وعلامتُهُ، محسوبانِ من جدولِ الأدوارِ عندَ تغييرِ الثيم: لا قراءةَ SharedPrefs في onDraw. */
  private final int[] styleColors = new int[EditorSyntaxRoles.PALETTE_SIZE];
  private final int[] styleFlags = new int[EditorSyntaxRoles.PALETTE_SIZE];
  private int plainColor = 0xFFECEFF1;

  private String fileName = "";
  private volatile boolean analysisPaused;

  private final LineStyler styler;
  /**
   * W23/1 — جسرُ التحليلِ إلى عمليةِ {@code :analyzer} المنفصلةِ، بديلًا عن خيطِ الواجهةِ الخلفيِّ:
   * القراءةُ والتحليلَ واستنتاجُ المُعرِّفاتِ خرجَتْ من حسابِ الواجهةِ، فلا جُمودَ عندَ ملفٍّ كبيرٍ ولا
   * {@code OutOfMemory} يقتلُ التطبيقَ كلَّهُ. جلسةٌ لكلِّ محرِّرٍ حيٍّ: تُربَطُ عندَ الاتصالِ بالنافذةِ
   * وتُنقَطُ عندَ الانفصالِ، وما لم يُرسَلْ من طلباتٍ يبقى في طابورِ الجلسةِ لا في النسيانِ.
   */
  private final AnalyzerConnection analyzer =
      new AnalyzerConnection(
          new AnalyzerConnection.Sink() {
            @Override
            public void applied(
                String file,
                List<CodeLanguageTools.Diagnostic> found,
                AnalyzerProtocol.Members members,
                AnalyzerProtocol.Reply reply) {
              onAnalyzed(file, found, members, reply);
            }

            @Override
            public void state(String state, String detail) {
              onAnalyzerState(state, detail);
            }
          });

  /** اللقطةُ التي يُنتظَرُ ردُّها (نسخةُ المستندِ ونصُّها): للفرزِ بينَ «ما زالَت صالحةً» و«تُنبَرُ». */
  private long analysisDocumentVersion;
  private String analysisText = "";

  /**
   * W23/2 — حالةُ الفحصِ المتدرِّجِ: بصمةُ كلِّ ملفٍّ ومَا رُدَّ عليهِ كاملًا، وجدولُ الأدوارِ مزدوجُ
   * الصفيحتَينِ (ما يُرسَمُ الآنَ وما يَجيءُ من الردِّ الجاري). الطلبُ الذي لم يتغيَّرْ عنهُ شيءٌ لا
   * يُرسَلُ، والعلامةُ تُطبَقُ صفيحةً صافيةً ثمَّ تُقلَبُ — فلا وميضَ ولا تراكُمَ عملٍ على خيطِ الواجهةِ.
   */
  private final IncrementalScope inspectionScope = new IncrementalScope();
  private final MarkTable inspectionMarks = new MarkTable();

  /**
   * جدولُ إزاحاتِ هذا الإصدارِ من النصِّ: يُبنى مرةً واحدةً عندَ نشرِ التشخيصاتِ أو عندَ أولِ سؤالٍ
   * بعدَ تغيُّرٍ، وتَقرَأُ منهُ القفزةُ ‏O(1) — فلا نَسخَ لنصِّ المحرِّرِ كلِّهِ ولا عَدَّ أسطرٍ لكلِّ
   * نقرةٍ في اللوحةِ (ورقةُ هذهِ الجولةِ §٢/‏٨).
   */
  private volatile LineOffsetTable jumpOffsets;

  /**
   * لا تذكيرَ هنا بعدَ اليومِ (الجولةُ ‏33، قـ٤): كانَ «إلغاءُ التلوينِ على مَدارِ الخطإِ» يَنسخُ
   * مصفوفةَ الأنماطِ ويَصفرُها تحتَ كلِّ خطأٍ، فتُصبِحَ أسماءُ الدوالِّ والثوابتِ التي أجسامُها معلولةٌ
   * سادةً. التسطيرُ وحدَهُ مَدارُ الفحصِ، والنحوُ لا يُمسُّ — فمِفتاحُ التلوينِ هو مُلوِّنُ الأسطرِ.
   */
  private long inspectionRevision;
  private long pendingInspectionRevision;
  private int pendingInspectionFrom;
  private int pendingInspectionTo;
  private String inspectionState = "idle";
  private List<String> inspectionProblems = Collections.emptyList();
  /** علاماتُ المواضعِ من آخرِ ردٍّ: سطورٌ وأعمدةٌ وأدوارٌ ومجموعةٌ، يقرؤُها الرَّسامُ بلا إعادةِ مسحٍ. */
  private int[] inspectionOccurrenceMarks = new int[0];
  private final Runnable diagnosticsTask = this::runDiagnostics;
  // الفحص أثناء الكتابة (R5): بداية فترة التعديلات المعلّقة، وتحليل جارٍ، وطلب إعادة بعده.
  private long diagnosticsPendingSince;
  /** زمنُ آخرِ تعديلٍ فتحَ بُرقةَ فحصٍ (0 = لا شيءَ منذُ الهدوءِ) — لحدِّ البُرقةِ السريعِ. */
  private long lastEditUptimeMs;
  private boolean diagnosticsInFlight;
  private long diagnosticsInFlightSince;
  /**
   * إيقاعُ هذا الملفِ وحدَهُ (طلبُ ١.٠.١٨٨): أرضيةُ الانتظارِ تُقاسُ من ثمنِ جَولاتِهِ لا من طولِهِ،
   * فجِهازٌ سريعٌ لا يَنتظِرُ شيئًا وجِهازٌ بطيءٌ لا يَتراكَمُ عليهِ عملٌ.
   */
  private final almlk.AnalysisPace analysisPace = new almlk.AnalysisPace();
  private boolean diagnosticsRerun;
  private List<CodeLanguageTools.Diagnostic> diagnostics = Collections.emptyList();
  private List<ProjectDiagnostic> projectDiagnostics = Collections.emptyList();
  /** مديات التشخيص لكل سطر — تتحرك مع التعديلات بين جولتي تحليل (مرحلة 1 من فحص الأخطاء). */
  private final DiagnosticSpanIndex diagnosticSpans = new DiagnosticSpanIndex();
  private final QuickFixBubble errorPopup = new QuickFixBubble(this);
  /** مُنتقي الإصلاح من فقاعة المؤشر: يُفَوَّض إلى مسار التطبيق الوحيد عند مالك المحرر. */
  public interface QuickFixPickListener {
    void picked(almlk.QuickFix fix);
  }

  private QuickFixPickListener quickFixPickListener;

  public void setQuickFixPickListener(QuickFixPickListener listener) {
    quickFixPickListener = listener;
  }
  // المرحلة 5: نقاط توقف منفصلة عن أعلام التشخيص فلا تمسحها updateDiagnostics.
  private final java.util.HashSet<Integer> breakpoints = new java.util.HashSet<>();

  private ChangeListener changeListener;
  private ScrollListener scrollListener;
  private DiagnosticsListener diagnosticsListener;
  private final ArrayList<TextWatcher> watchers = new ArrayList<>();

  /** مخزن النص الكامل بالإصدار — يبنى مرة لكل إصدار (callers تقرأه بلا كلفة متكررة). */
  private String textCache = "";
  private long textCacheVersion = -1;
  private String lastDispatchedText = "";

  public AlmlkEditor(Context context) {
    this(context, null);
  }

  public AlmlkEditor(Context context, AttributeSet attrs) {
    this(context, attrs, 0);
  }

  public AlmlkEditor(Context context, AttributeSet attrs, int style) {
    super(context);
    styler = new LineStyler(getDocument());
    styler.setListener((from, to) -> postInvalidate());
    setStyleProvider(
        new StyleProvider() {
          @Override
          public int[] lineStyles(LineDocument document, int line) {
            // قـ٤ (الجولةُ ‏33): بلاغةُ الفحصِ التسطيرُ لا اللونُ، فلا تُلمَسُ مصفوفةُ الأنماطِ.
            return styler.stylesForLine(line);
          }

          @Override
          public int colorFor(int styleId) {
            return AlmlkEditor.this.colorFor(styleId);
          }
        });
    setColorDecorationProvider((document, line) -> styler.colorLiteralsForLine(line));
    setDiagnosticDecorationProvider((document, line) -> diagnosticSpans.underlines(line));
    setLineFlagProvider(
        line -> {
          synchronized (breakpoints) {
            return breakpoints.contains(line) ? FLAG_BREAKPOINT : 0;
          }
        });
    setReplacementListener(this::onContentReplaced);
    applyEditorInteraction();
    applyTheme();
  }

  // ---------------- التوصيل بطبقة الإدخال (hooks من CodeEditorView) ----------------

  private void applyEditorInteraction() {
    // CodeEditorView يملك بالفعل مستمع تفاعلات للوحة (قائمة التحديد/الكيبورد)؛ هنا نضيف
    // بثّ التمرير/التكبير الخارجي عبر hooks محمية في الأب.
  }

  @Override
  protected void onEditorScrolledExternal(int x, int y) {
    ScrollListener listener = scrollListener;
    if (listener != null) listener.onEditorScroll(x, y);
  }

  @Override
  protected void onEditorZoomedExternal(float textSizePixels) {
    ScrollListener listener = scrollListener;
    if (listener != null) listener.onEditorZoom(textSizePixels);
  }

  // ---------------- نص الواجهة (CharSequence المقروء) ----------------

  public String currentText() {
    long version = getDocument().version();
    if (version != textCacheVersion) {
      textCacheVersion = version;
      textCache = getDocument().toString();
    }
    return textCache;
  }

  /** متوافق مع EditText.getText() — للقراءة فقط. التحرير يمر بـ replaceRange/الإدخال. */
  public CharSequence getText() {
    return currentText();
  }

  public void setText(CharSequence text) {
    String before = currentText();
    getDocument().setAll(text == null ? "" : text.toString());
    clearHistory();
    clearSelection();
    setCaret(0, 0);
    styler.request(0, Integer.MAX_VALUE);
    scrollTo(0, 0);
    dispatchTextChanged(before, currentText(), 0, before.length());
    scheduleDiagnostics(120);
  }

  public int length() {
    return getDocument().length();
  }

  // ---------------- التحديد بالإزاحات (واجهة TextView) ----------------

  public int getSelectionStart() {
    return selectionOffsets()[0];
  }

  public int getSelectionEnd() {
    return selectionOffsets()[1];
  }

  public void setSelection(int index) {
    int offset = Math.max(0, Math.min(index, length()));
    int line = getDocument().lineForOffset(offset);
    setCaret(line, offset - getDocument().lineStartOffset(line));
  }

  public void setSelection(int start, int end) {
    int from = Math.max(0, Math.min(Math.min(start, end), length()));
    int to = Math.max(from, Math.min(Math.max(start, end), length()));
    if (from == to) {
      setSelection(from);
      return;
    }
    int startLine = getDocument().lineForOffset(from);
    int endLine = getDocument().lineForOffset(to);
    setSelectionRange(
        startLine, from - getDocument().lineStartOffset(startLine),
        endLine, to - getDocument().lineStartOffset(endLine));
  }

  /**
   * قيمة اللون التي تحتوي المؤشر المطوي أو التحديد كله. النهاية حصرية، والتحديد العابر لسطر
   * أو لاقتباس/قيمة ثانية لا يطابق. هذه هي بوابة الأهلية الموحدة؛ لا فحص Hex نصي موازٍ.
   */
  public XmlColorLiteral colorLiteralForSelection() {
    int start = getSelectionStart();
    int end = getSelectionEnd();
    int from = Math.min(start, end);
    int to = Math.max(start, end);
    LineDocument document = getDocument();
    int startLine = document.lineForOffset(from);
    int endLine = document.lineForOffset(to);
    if (startLine != endLine) return null;
    int lineStart = document.lineStartOffset(startLine);
    int startColumn = from - lineStart;
    int endColumn = to - lineStart;
    XmlColorLiteral[] literals = styler.colorLiteralsForLine(startLine);
    return from == to
        ? XmlColorLiteral.atColumn(literals, startColumn)
        : XmlColorLiteral.containingRange(literals, startColumn, endColumn);
  }

  /** مدى القيمة الحالية كإزاحتين مطلقتين، أو null إن كان المؤشر/التحديد خارج قيمة واحدة. */
  public int[] colorLiteralSelectionRange() {
    XmlColorLiteral literal = colorLiteralForSelection();
    if (literal == null) return null;
    int lineStart = getDocument().lineStartOffset(literal.line);
    return new int[] {lineStart + literal.startColumn, lineStart + literal.endColumn};
  }

  /** يطبّع المؤشر أو التحديد الجزئي داخل اللون إلى القيمة كاملة شاملة #. */
  public boolean normalizeSelectionToColorLiteral() {
    int[] range = colorLiteralSelectionRange();
    if (range == null) return false;
    if (getSelectionStart() != range[0] || getSelectionEnd() != range[1])
      setSelection(range[0], range[1]);
    return true;
  }

  /** يبدأ معاملة اللون من الفهرس الحالي بعد تطبيع المدى؛ لا يغيّر النص أو سجل التراجع. */
  public ColorLiteralEdit beginColorLiteralEdit() {
    if (!normalizeSelectionToColorLiteral()) return null;
    LineDocument document = getDocument();
    synchronized (document) {
      XmlColorLiteral literal = colorLiteralForSelection();
      if (literal == null) return null;
      int start = document.lineStartOffset(literal.line) + literal.startColumn;
      int end = document.lineStartOffset(literal.line) + literal.endColumn;
      return new ColorLiteralEdit(
          document.version(), start, end, literal, document.subText(start, end));
    }
  }

  /**
   * يؤكد معاملة اللون ذريًا بالنسبة للمستند. أي تغير بعد فتح الحوار، أو اختلاف في المدى/الفهرس،
   * يعيد STALE بلا كتابة. النجاح يستدعي replaceRange مرة واحدة فقط، لذلك Undo خطوة واحدة.
   */
  public ColorLiteralEditResult applyColorLiteralEdit(ColorLiteralEdit edit, int newArgb) {
    if (edit == null) return ColorLiteralEditResult.STALE;
    LineDocument document = getDocument();
    synchronized (document) {
      if (document.version() != edit.documentVersion) return ColorLiteralEditResult.STALE;
      if (edit.line < 0 || edit.line >= document.lineCount()) return ColorLiteralEditResult.STALE;
      int lineStart = document.lineStartOffset(edit.line);
      if (lineStart + edit.startColumn != edit.startOffset
          || lineStart + edit.endColumn != edit.endOffset)
        return ColorLiteralEditResult.STALE;
      XmlColorLiteral current = XmlColorLiteral.atColumn(
          styler.colorLiteralsForLine(edit.line), edit.startColumn);
      if (current == null
          || current.startColumn != edit.startColumn
          || current.endColumn != edit.endColumn
          || current.argb != edit.originalArgb
          || current.format != edit.format
          || !document.subText(edit.startOffset, edit.endOffset).equals(edit.originalText))
        return ColorLiteralEditResult.STALE;

      String replacement = edit.literal.formatReplacement(newArgb);
      if (replacement.equals(edit.originalText)) return ColorLiteralEditResult.UNCHANGED;
      replaceRange(edit.startOffset, edit.endOffset, replacement);
      return ColorLiteralEditResult.APPLIED;
    }
  }

  public int[] selectionOrIdentifier() {
    // اللون يسبق IdentifierBounds: خاناته الرقمية ليست معرفًا منفصلًا، و# جزء من الكيان.
    int[] colorRange = colorLiteralSelectionRange();
    if (colorRange != null) return colorRange;
    int start = getSelectionStart(), end = getSelectionEnd();
    if (start != end) return new int[] {start, end};
    String text = currentText();
    if (text.isEmpty() || start >= text.length())
      return new int[] {Math.max(0, Math.min(start, text.length())),
          Math.max(0, Math.min(start, text.length()))};
    int from = IdentifierBounds.start(text, start);
    int to = IdentifierBounds.end(text, start);
    return new int[] {from, to};
  }

  public void normalizeSelectionToTouchedIdentifier() {
    int selectionStart = getSelectionStart();
    int selectionEnd = getSelectionEnd();
    int[] range = colorLiteralSelectionRange();
    if (range == null && selectionStart != selectionEnd) {
      range = IdentifierBounds.wholeIdentifierForSelection(
          currentText(), selectionStart, selectionEnd);
      if (range == null) range = new int[] {selectionStart, selectionEnd};
    } else if (range == null) {
      range = selectionOrIdentifier();
    }
    // لا نعيد كتابة التحديد المطابق: setSelectionRange يغيّر provenance اللمس إلى برمجي.
    if (range[0] < range[1]
        && (range[0] != selectionStart || range[1] != selectionEnd)) {
      setSelection(range[0], range[1]);
    }
  }

  // ---------------- TextWatcher مكافئ (الـPager يعتمدها) ----------------

  public void addTextChangedListener(TextWatcher watcher) {
    if (!watchers.contains(watcher)) watchers.add(watcher);
  }

  public void removeTextChangedListener(TextWatcher watcher) {
    watchers.remove(watcher);
  }

  private void dispatchTextChanged(String before, String after, int start, int removedCount) {
    int addedCount = Math.max(0, after.length() - (before.length() - removedCount));
    for (int i = watchers.size() - 1; i >= 0; i--) {
      TextWatcher watcher = watchers.get(i);
      watcher.beforeTextChanged(before, start, removedCount, addedCount);
      watcher.onTextChanged(after, start, removedCount, addedCount);
      watcher.afterTextChanged(null);
    }
    lastDispatchedText = after;
  }

  private void onContentReplaced(int start, int removedCount, int insertedCount) {
    String before = lastDispatchedText;
    shiftDiagnosticSpans(before, start, removedCount, insertedCount);
    errorPopup.dismiss();
    String after = currentText();
    dispatchTextChanged(before, after, start, removedCount);
    ChangeListener listener = changeListener;
    if (listener != null) listener.onChanged(getDocument().version());
    scheduleDiagnostics(almlk.LiveDiagnostics.TYPING_DELAY_MS);
  }

  /**
   * ينقل خطوط الأخطاء مع النص المكتوب قبل أن تعود جولة التحليل: الموضع الأول من المستند الجديد،
   * ونهاية المحذوف من النص السابق (مسح المحذوف وحده — بلا تحويل للنص كله).
   */
  private void shiftDiagnosticSpans(String before, int start, int removedCount, int insertedCount) {
    if (diagnosticSpans.isEmpty()) return;
    LineDocument document = getDocument();
    if (before == null || start < 0 || start + removedCount > before.length()) {
      diagnosticSpans.clear(); // نص سابق غير متزامن: لا تخمين — التحليل القادم يعيد الخطوط
      return;
    }
    int startLine = document.lineForOffset(start);
    int startColumn = start - document.lineStartOffset(startLine);
    int newlines = 0;
    int lastNewline = -1;
    for (int i = start, end = start + removedCount; i < end; i++) {
      if (before.charAt(i) == '\n') {
        newlines++;
        lastNewline = i;
      }
    }
    int removedEndLine = startLine + newlines;
    int removedEndColumn =
        newlines == 0 ? startColumn + removedCount : start + removedCount - lastNewline - 1;
    int insertedEnd = Math.min(start + insertedCount, document.length());
    int insertedEndLine = document.lineForOffset(insertedEnd);
    int insertedEndColumn = insertedEnd - document.lineStartOffset(insertedEndLine);
    diagnosticSpans.applyEdit(startLine, startColumn, removedEndLine, removedEndColumn,
        insertedEndLine, insertedEndColumn);
  }

  /**
   * لمسة المستخدم استقرت (نقرة أو نقرة مزدوجة أو ضغط مطوّل): إن وقع المؤشر أو التحديد على مدى
   * تشخيص ظهرت فقاعةٌ عند ذلك الموضع تحمل رسالته **وتحتها صفوف إصلاحه** — كالمرجع، دون أخذ التركيز
   * أو إغلاق الكيبورد؛ الضغط المطوّل على كلمة الخطأ يحددها ويفتح شريط "تحديد الإجراءات" عبر مسار
   * التحديد القائم نفسه.
   */
  @Override
  protected void onTouchPositionSettled(boolean fromLongPress) {
    showDiagnosticMessageAtCaret();
  }

  /**
   * فقاعة التشخيص تحت المؤشر/التحديد: سطر الرسالة ثم صفٌّ لكل إصلاح متاح لنفس المدى (حتى 6 بلا
   * تكرار — قاعدة الشريط نفسها)، والنقر على صفٍّ يمرّ إلى {@code quickFixPickListener} فيطبّقه
   * المالك من مساره الوحيد. بلا تشخيص تُغلق الفقاعة؛ وبلا إصلاح تنحدر إلى رسالة تختفي ذاتيًا.
   */
  public void showDiagnosticMessageAtCaret() {
    CodeLanguageTools.Diagnostic diagnostic = diagnosticAtSelection();
    if (diagnostic == null) {
      errorPopup.dismiss();
      return;
    }
    ArrayList<QuickFixBubble.Entry> entries = new ArrayList<>();
    java.util.HashSet<String> seen = new java.util.HashSet<>();
    for (almlk.QuickFix fix :
        almlk.JavaImportResolver.withFixImportsRow(quickFixesAtSelection())) {
      if (fix == null || !seen.add(fix.key())) continue;
      final almlk.QuickFix chosen = fix;
      entries.add(
          new QuickFixBubble.Entry(
              UiStrings.format(getContext(), chosen.menuKey(), chosen.signature(), chosen.targetClass),
              () -> {
                QuickFixPickListener listener = quickFixPickListener;
                if (listener != null) listener.picked(chosen);
              }));
    }
    // ‏1.0.198 (ج٤٧): صَفُّ وَحدَةِ الفَحصِ — إِذَا كَانَ لِلمَكتَبَةِ إِصلاحٌ لِهذَا السَّطرِ
    // فَهُوَ صَفٌّ كَصَفُوفِنَا: نَفسُ النِّقرِ، وَنَفسُ {@code quickFixPickListener}، وَنَفسُ
    // مَسَارِ التَّراجُعِ وَالوَسِمِ وَالحِفظِ قَبلَ البِنَاءِ. وَإن لَم يَكُن فَلا صَفَّ: لا وَعْدًا زَائِفًا.
    almlk.QuickFix analyzerFix = almlk.AnalyzerErrorUnit.fixNear(diagnostic.line, fileName);
    if (analyzerFix != null && seen.add(analyzerFix.key())) {
      final almlk.QuickFix picked = analyzerFix;
      entries.add(
          new QuickFixBubble.Entry(
              UiStrings.format(
                  getContext(), picked.menuKey(), picked.signature(), picked.targetClass),
              () -> {
                QuickFixPickListener listener = quickFixPickListener;
                if (listener != null) listener.picked(picked);
              }));
    }
    int[] caret = caretPointInWindow();
    errorPopup.show(
        diagnosticMessage(diagnostic), entries, caret == null ? -1 : caret[0], caret == null ? -1 : caret[1]);
  }

  /**
   * موضع المؤشر بإحداثيات النافذة لتُربط الفقاعة به كما في المرجع. {@code null} عند تعذّر القياس
   * (لا Layout بعد، أو عرض مُزال) فتسقط الفقاعة إلى قاع الوعاء بدل أن تُرمى خارج الشاشة.
   */
  private int[] caretPointInWindow() {
    try {
      if (getWidth() == 0 || getHeight() == 0) return null;
      int[] point = caretPointInView();
      int[] where = new int[2];
      getLocationInWindow(where);
      int x = where[0] + point[0];
      int y = where[1] + point[1];
      return x < 0 || y < 0 ? null : new int[] {x, y};
    } catch (RuntimeException unmeasured) {
      return null;
    }
  }

  /** رسالة التشخيص تحت المؤشر/التحديد الحالي (معرّبة عبر مفاتيح الموارد) أو null. */
  public CharSequence diagnosticMessageAtCaret() {
    CodeLanguageTools.Diagnostic diagnostic = diagnosticAtSelection();
    return diagnostic == null ? null : diagnosticMessage(diagnostic);
  }

  /**
   * المرحلة 3 — إصلاحات التشخيص الواقع تحت المؤشر/التحديد (حتى 6، بلا تكرار). القائمة جاهزة مسبقًا
   * من جولة التحليل، فيظهر زر الإصلاح في شريط «تحديد الإجراءات» فورًا كالمرجع.
   */
  public List<almlk.QuickFix> quickFixesAtSelection() {
    CodeLanguageTools.Diagnostic diagnostic = diagnosticAtSelection();
    if (diagnostic == null) return Collections.emptyList();
    // المرحلة 4: الإصلاحات جزء من كائن التشخيص نفسه (يحسبها المدقق الدلالي في جولة الخلفية).
    List<almlk.QuickFix> found = diagnostic.quickFixes;
    return found.size() <= 6 ? found : found.subList(0, 6);
  }

  private CodeLanguageTools.Diagnostic diagnosticAtSelection() {
    DiagnosticSpanIndex.Span span;
    if (hasSelection()) {
      int[] range = orderedSelection();
      int to = range[2] == range[0] ? range[3] : getDocument().lineLength(range[0]);
      span = diagnosticSpans.spanOverlapping(range[0], range[1], to);
    } else {
      span = diagnosticSpans.spanAt(caretLine(), caretColumn());
    }
    if (span == null || !(span.payload instanceof CodeLanguageTools.Diagnostic)) return null;
    return (CodeLanguageTools.Diagnostic) span.payload;
  }

  private String diagnosticMessage(CodeLanguageTools.Diagnostic diagnostic) {
    if (diagnostic.messageKey != null)
      return com.shima.demo.UiStrings.format(
          getContext(), diagnostic.messageKey, diagnostic.messageArgs);
    if (diagnostic.message != null && !diagnostic.message.isEmpty()) return diagnostic.message;
    return com.shima.demo.UiStrings.get(getContext(), "ui_error_generic");
  }

  // ---------------- المستمعون الخارجيون ----------------

  public void setChangeListener(ChangeListener listener) {
    changeListener = listener;
  }

  public void setScrollListener(ScrollListener listener) {
    scrollListener = listener;
  }

  public void setDiagnosticsListener(DiagnosticsListener listener) {
    diagnosticsListener = listener;
  }

  /** Replaces external project/compiler markers for the current file without changing text state. */
  public void setProjectDiagnostics(List<ProjectDiagnostic> values) {
    projectDiagnostics =
        values == null || values.isEmpty()
            ? Collections.emptyList()
            : new ArrayList<>(values);
    rebuildDiagnosticDecorations();
    invalidate();
    invalidateSelectionActions();
  }

  /**
   * توقُّفُ التحليلِ يَمسُّ التحليلَ وحدَهُ (‏1.0.189). كانَ يُطفِئُ مَعَها مِلوَنا فَيَخرُجُ الملفُّ
   * أبيضَ ساذجًا طالَ أنَّ الجلسةَ غيرُ مُسلَّحةٍ — مشروعٌ غيرُ مفتوحٍ، أو مُهلِلُ تحليلٍ مُنتَظَرٌ،
   * أو استعادةُ تبويبٍ كسولةٍ — والتلوينُ لا يَحتاجُ واحدًا من هذا كلِّهِ: محليٌّ على نصٍّ في الذاكرةِ.
   * وعندَ العودَةِ يُفحَصُ جدولُ الأنماطِ ولا يُُؤمَنُ على ثقةٍ سابقةٍ.
   */
  public void setAnalysisPaused(boolean paused) {
    analysisPaused = paused;
    if (paused) removeCallbacks(diagnosticsTask);
    else refreshNow();
    ensureColorsVisibleNow();
  }

  /**
   * فحصُ اللونِ كما يَفعَلُ المصدرُ في الكلاسِ المفتوحِ: إن وُجِدَ سطرٌ ظاهرٌ بلا أنماطٍ أُكسِيَت
   * نافذتُهُ الآنَ على خيطِ الطلبِ (نفسُ {@code request} ونفسُ التكسيةِ الفوريّةِ، لا مسارَ ثانِيَ)،
   * وما تحتَ النافذةِ يَمضِيهِ الخيطُ الخلفيُّ. مكتمِلٌ؟ لا عملَ ولا جيلَ يُهدَمُ (شرطٌ دائمٌ ‏20).
   */
  public void ensureColorsVisibleNow() {
    int from = firstVisibleLine();
    int to = lastVisibleLine();
    if (to < from) return;
    if (styler.needsColoring(from, to)) styler.request(from, Integer.MAX_VALUE);
  }

  /** نافذةٌ جديدةٌ (تمريرٌ أو فتحٌ أو تبدُّلُ ثيمٍ): الفحصُ عندَ دخولِها، لا بعدَ شكوى المُستخدِمِ. */
  @Override
  protected void onVisibleRangeChanged(int fromLine, int toLine) {
    ensureColorsVisibleNow();
  }

  /** توافق واجهة EditText: عناصر قائمة تحديد مخصصة تُلحق بالقائمة المدمجة. */
  public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
    if (callback == null) {
      setActionModeContributor(null);
      return;
    }
    setActionModeContributor(
        new ActionModeContributor() {
          @Override
          public void onCreateMenu(ActionMode mode, Menu menu) {
            callback.onCreateActionMode(mode, menu);
          }

          @Override
          public boolean onPrepareMenu(ActionMode mode, Menu menu) {
            return callback.onPrepareActionMode(mode, menu);
          }

          @Override
          public boolean onMenuItem(ActionMode mode, MenuItem item) {
            return callback.onActionItemClicked(mode, item);
          }

          @Override
          public void onDestroy(ActionMode mode) {
            callback.onDestroyActionMode(mode);
          }
        });
  }

  /** توافق TextView.setLineSpacing (الإضافة بالبكسل تمرر لمقاسات اللوحة). */
  public void setLineSpacing(float add, float mult) {
    setLineSpacingExtra(mult <= 0 ? add : add * mult);
  }

  /** توافق TextView.setHint بمورد نصي. */
  public void setHint(int resource) {
    setHint(getContext().getString(resource));
  }

  /** توافق EditText.onTextContextMenuItem (قائمة السياق أندرويد من الـPager). */
  public boolean onTextContextMenuItem(int id) {
    if (id == android.R.id.selectAll) {
      selectAll();
      return true;
    }
    if (id == android.R.id.cut) {
      cutSelection();
      return true;
    }
    if (id == android.R.id.copy) {
      copySelection();
      return true;
    }
    if (id == android.R.id.paste) {
      pasteClipboard();
      return true;
    }
    return false;
  }

  /** توافق EditText.bringPointIntoView: التمرير حتى تظهر الإزاحة (بحث/انتقال). */
  public boolean bringPointIntoView(int offset) {
    return scrollOffsetIntoView(offset);
  }

  /** موضع إزاحة داخل الـView: [x أفقي، y أسفل السطر] — بديل Layout القديم لنوافذ الإكمال. */
  public int[] offsetToViewPosition(int offset) {
    int clamped = Math.max(0, Math.min(offset, length()));
    int line = getDocument().lineForOffset(clamped);
    int column = clamped - getDocument().lineStartOffset(line);
    float x = columnToContentX(line, column) - getScrollX();
    float y = (line + 1) * lineStride() - getScrollY();
    return new int[] {(int) x, (int) y};
  }

  // ---------------- الملف والتحليل ----------------

  public void setFileName(String name) {
    String previous = fileName;
    fileName = name == null ? "" : name;
    // ملفٌّ آخرَ = نصٌّ آخرَ بسِعرٍ لم يُعرَفْ: الإيقاعُ يُعادُ ضبطُهُ ولا يُحمَلُ من ملفٍّ سابقٍ.
    if (!fileName.equals(previous)) analysisPace.reset();
    styler.setFileName(fileName);
    ensureColorsVisibleNow();
    scheduleDiagnostics(150);
  }

  /**
   * توافق تاريخي مع استدعاء الـPager بعد الحفظ: الموديل الجديد هو المرجع الوحيد فلا شيء
   * يُعاد ربطه — يكتفي بتحديث اسم الملف.
   */
  public void resetCoreModel(String uri, CharSequence currentText) {
    setFileName(uri);
  }

  /** تنسيق بأسلوب جافا بإزاحة من تفضيل المستخدم — المرحلة الثامنة. */
  public String formatCode() {
    return CodeLanguageTools.format(
        currentText(), almlk.CodeStyle.indentSizeFor(getContext(), fileName));
  }

  /**
   * W20′2: إعادةُ فحصٍ وحدَها بلا إعادةِ تلوينٍ — للنصِّ الذي لم يتغيّرْ لكنّ معرفةَ المشروعِ عنهُ
   * تغيّرتْ (أُصلِحَ في ملفٍّ آخرَ)، فلا requestٌ كلّيٌّ للتلوينِ ولا انتظارُ كتابةٍ.
   */
  public void reinspectNow() {
    scheduleDiagnostics(0);
  }

  public void refreshNow() {
    if (analysisPaused) return;
    // الناقصُ وحدَهُ يُكسَى: كانَ الطلبُ الشاملُ يَهدِمُ تلوينَ ملفٍّ كاملٍ لأجلِ سطرٍ فُحِصَ من جديدٍ.
    styler.requestMissing();
    scheduleDiagnostics(250);
  }

  /** مُلوِّنُ المحرِّرِ للبوَّابةِ والوصلاتِ: هل اكتمَلَ جدولُ الأنماطِ لهذا الإصدارِ؟ */
  public boolean isStylingComplete() {
    return styler.isComplete();
  }

  /** كم سطرًا لهُ أنماطٌ منشورةٌ الآنَ (مقياسُ «كاملٌ فورًا»، لا انطباعٌ). */
  public int styledLineCount() {
    return styler.styledLineCount();
  }

  public List<String> completions() {
    return CodeLanguageTools.complete(fileName, currentText(), getSelectionStart());
  }

  public void applyCompletion(String value) {
    String text = currentText();
    int cursor = Math.max(0, Math.min(getSelectionStart(), text.length()));
    int start =
        Math.max(0, Math.min(CodeLanguageTools.completionStart(fileName, text, cursor), cursor));
    replaceRange(start, cursor, value);
    int target = start + value.length();
    if (value.endsWith("()")) target--;
    setSelection(Math.min(target, length()));
    requestFocus();
  }

  /** المراحل 1-4: اقتراحات مُنمَّطة من فهرس الرموز (دالة/متغير/كلاس/XML/بناء). */
  public java.util.List<com.almlkid.kay.ui.ProjectSymbolIndex.CompletionItem> typedCompletions() {
    return com.almlkid.kay.ui.ProjectSymbolIndex.complete(
        fileName, currentText(), getSelectionStart());
  }

  /** التزام ذكي: يُدرج التوقيع ويضع المؤشر، وللكلاسات **يضيف import تلقائيًا** (المرحلة 3). */
  public void applyTypedCompletion(com.almlkid.kay.ui.ProjectSymbolIndex.CompletionItem item) {
    if (item == null) return;
    String text = currentText();
    int cursor = Math.max(0, Math.min(getSelectionStart(), text.length()));
    int start =
        Math.max(0, Math.min(CodeLanguageTools.completionStart(fileName, text, cursor), cursor));
    String insert = item.insertText == null ? item.label : item.insertText;
    boolean isMethod = item.kind == com.almlkid.kay.ui.ProjectSymbolIndex.CompletionItem.METHOD;
    boolean parensFollow = cursor < text.length() && text.charAt(cursor) == '(';
    int caret;
    if (isMethod && insert.endsWith("()") && parensFollow) {
      // the call's parentheses are already written: insert the name and step into them
      insert = insert.substring(0, insert.length() - 2);
      caret = start + insert.length() + 1;
    } else if (item.caretBack >= 0) {
      caret = start + insert.length() - item.caretBack; // inside () or ="" like the reference
    } else {
      caret = start + insert.length(); // Gradle blocks, smali, keywords, classes
    }
    String replacement = insert;
    replaceRange(start, cursor, replacement);
    int shift = 0;
    boolean javaBuffer =
        fileName != null && !fileName.toLowerCase(java.util.Locale.US).endsWith(".xml");
    boolean classRow = item.kind == com.almlkid.kay.ui.ProjectSymbolIndex.CompletionItem.CLASS;
    if (javaBuffer && (classRow || (item.importNames != null && !item.importNames.isEmpty()))) {
      ArrayList<String> names = new ArrayList<String>();
      if (item.importNames != null) names.addAll(item.importNames);
      if (names.isEmpty() && classRow) names.add(item.label); // CLASS rows carry the FQN in the label
      int before = length();
      addImportsIfNeeded(names);
      shift = length() - before; // the import lines are inserted above the caret
    }
    setSelection(Math.max(0, Math.min(caret + shift, length())));
    requestFocus();
  }

  /**
   * يُدرج {@code import حزمة.كلاس;} عندَ قبولِ اقتراحٍ — كلُّ ما يَلزَمُ في عمليةٍ واحدةٍ على النصِّ
   * الحيِّ، والقاعدةُ كلُّها في {@code JavaImportResolver} (هي نفسها التي يستعملُها إصلاحُ «Add
   * 'import …'» ومنظِّمُ الاستيراداتِ)، فلا قاعدةَ ثانيةً للإدراجِ ولا سطرٌ يُفتَحُ مرَّتينِ. صفوفُ
   * المنصَّةِ تَحمِلُ اسمَها المُقيَّدَ، وصفوفُ المشروعِ تُطلَبُ من الفهرسِ. ‏1.0.189: قائمةٌ لا اسمٌ
   * واحدٌ — فدالةٌ مُولَّدةٌ قد تَحمِلُ ثلاثةَ أنواعٍ لا استيرادَ لها، و«مهما كانَ عدَدُها» شرطٌ لا
   * زينةٌ: الكِتابَةُ كتلةٌ مُتَّصِلةٌ واحدةٌ بخطوةِ تراجعٍ واحدةٍ.
   */
  private void addImportsIfNeeded(List<String> classNames) {
    if (classNames == null || classNames.isEmpty()) return;
    String source = currentText();
    ArrayList<String> qualified = new ArrayList<String>(classNames.size());
    for (String className : classNames) {
      if (className == null || className.isEmpty()) continue;
      String simple = className.contains(".")
          ? className.substring(className.lastIndexOf('.') + 1)
          : className;
      String pkg = className.contains(".")
          ? className.substring(0, className.lastIndexOf('.'))
          : com.almlkid.kay.ui.ProjectSymbolIndex.packageOf(simple);
      if (pkg == null || pkg.isEmpty()) continue;
      qualified.add(pkg + "." + simple);
    }
    almlk.QuickFix.Insertion plan =
        almlk.JavaImportResolver.insertionForAll(source, qualified);
    if (plan == null) return;
    replaceRange(plan.offset, plan.removeEnd, plan.text);
  }

  // ---------------- التشخيصات (محوّل — كما كانت، خلفية + أعلام سطور بدل Spans) ----------------

  private void scheduleDiagnostics(long delayMs) {
    if (analysisPaused) return;
    long now = android.os.SystemClock.uptimeMillis();
    // W21′1 — حدُّ البُرقةِ: أولُ تعديلٍ بعدَ هدوءٍ يُجابُ عندَ FIRST_RUN_DELAY_MS لا بعدَ تأجيلٍ
    // كاملٍ، والكتابةُ داخلَ البُرقةِ واحدةٍ تحفظُ تأجيلَها فلا تصطفُّ تحليلاتٌ لكلِّ حرفٍ. صفرٌ يبقى
    // صفرًا (إعادةُ الفحصِ بعدَ الإصلاحِ أو تنشيطُ التبويبِ لا تنتظرُ شيئًا).
    long requested =
        almlk.LiveDiagnostics.delayForBurst(now, delayMs > 0 ? lastEditUptimeMs : 0L, delayMs);
    if (delayMs > 0) lastEditUptimeMs = now;
    // الكتابة المتواصلة لا تؤجّل الفحص بلا نهاية: سقف انتظار من أول تعديل معلّق.
    long wait =
        Math.max(almlk.LiveDiagnostics.delayFor(now, diagnosticsPendingSince, requested),
            analysisPace.floorFor(getDocument().length()));
    if (diagnosticsPendingSince == 0) diagnosticsPendingSince = now;
    removeCallbacks(diagnosticsTask);
    postDelayed(diagnosticsTask, wait);
  }

  private void runDiagnostics() {
    diagnosticsPendingSince = 0;
    if (analysisPaused) return;
    long now = android.os.SystemClock.uptimeMillis();
    if (diagnosticsInFlight && now - diagnosticsInFlightSince < almlk.LiveDiagnostics.STALE_RUN_MS) {
      diagnosticsRerun = true; // تحليل جارٍ: يُعاد فور انتهائه بدل اصطفاف طلبات قديمة
      return;
    }
    final String name = fileName;
    final long documentVersion = getDocument().version();
    final String text = currentText();
    if (name.isEmpty()) {
      updateDiagnostics(Collections.<CodeLanguageTools.Diagnostic>emptyList());
      return;
    }
    // W23/2 — لا جولةَ تحليلٍ على نصٍّ لم يتغيَّرْ: البصمةُ هي الحكمُ، والجولةُ الكاملةُ تُفرَضُ عندَ
    // الافتتاحِ وتغيُّرِ سياقِ المشروعِ وتجاوُزِ سقفِ المتابعةِ (‏512 ملفًّا) — كلها حالاتٌ مسمّاةٌ لا صمتٌ.
    IncrementalScope.Plan scope = inspectionScope.plan(name, analysisText, text);
    if (scope == null) {
      // البصمةُ لم تتغيَّرْ منذُ آخرِ فحصٍ مُطبَّقٍ: لا طلبَ ولا إعادةَ تزيينٍ، والحالةُ تُقرَأُ في اللوحةِ.
      inspectionState = inspectionScope.state();
      return;
    }
    inspectionState = inspectionScope.state();
    inspectionProblems = scope.problems.isEmpty() ? inspectionScope.problems() : scope.problems;
    pendingInspectionRevision = scope.revision;
    // النطاقُ الحاضنُ يَسري على المسحِ الإضافيِّ في هذهِ العمليةِ؛ والتكرارُ عندَ ابنِ التحليلِ يَمسحُ
    // الملفَّ كلَّهُ عمدًا: «كلُّ المواضعِ» لا تُعرَفُ من نطاقٍ ضيِّقٍ — وهذا حدُّ الفرقِ بينَ الطلبينِ.
    pendingInspectionFrom = scope.wholeFile ? 0 : scope.from;
    pendingInspectionTo = scope.wholeFile ? text.length() : scope.to;
    // W7: أُلغِيَت هاويةُ «الملف الضخم» — كان >80٬000 محرفٍ يمسح التشخيصات كلها صامتًا، فاختفت
    // الأخطاء عن كل ملفٍّ كبير (ولوحةُ الأخطاء معه). الملفُ الكبيرُ يُفحص كما الصغير الآن، وانتظارُهُ
    // مَقيسٌ لا مَفروضٌ: «almlk.AnalysisPace» يَأخُذُ ثمنَ جَولاتِهِ نفسِها (البطيءُ يَنتظِرُ والسريعُ
    // يُمضِي) بدلَ جدولٍ على الطولِ وحدَهُ — والعملُ كلُّهُ في خيطٍ واحدٍ لا يتراكَم.
    // والسقفُ الصارمُ الوحيدُ يبقى في المحرّك (فوقَهُ النحوُ وحدَهُ، مُعلَن).
    // W23/1 — لا خيطَ هنا بعدَ اليومِ: تُرسَلُ اللقطةُ إلى عمليةِ التحليلِ، ويأتي الردُّ على خيطِ
    // الواجهةِ. قيدٌ واحدٌ بقيَ كما كانَ — طلبٌ جارٍ واحدٌ، لكنَّهُ الآنَ مُعلَنٌ في طابورِ الجلسةِ التي
    // تدمجُ اللقطاتِ المتتابعةَ للملفِّ نفسِهِ، فلا تُحلَّلُ الكتابةُ المتواصلةُ مرةً لكلِّ حرفٍ.
    analysisDocumentVersion = documentVersion;
    analysisText = text;
    diagnosticsInFlight = true;
    diagnosticsInFlightSince = now;
    diagnosticsRerun = false;
    analyzer.attach(getContext());
    analyzer.request(name, text);
  }

  /**
   * ردُّ عمليةِ التحليلِ — على خيطِ الواجهةِ مباشرةً (حاملُ الردودِ في {@code AnalyzerConnection} على
   * {@code Looper.getMainLooper()})، فلا حاجةَ إلى {@code post} ولا إلى حارسٍ للتسابقِ.
   *
   * <p>الترتيبُ مقصودٌ: تُقابَلُ المُعرِّفاتُ الحيّةُ أولًا فيُعلَنَ عن تغيُّرِها ({@code
   * ProjectSymbolIndex.recordMemberDelta} يرفعُ {@code structureEpoch}) قبلَ أن تُطبَّقَ التشخيصاتُ،
   * كما كانَ يفعلُ خيطُ الفحصِ من قبلُ؛ والمقابلةُ وحدها — النصُّ غيرُ المحفوظِ لا يغيّرُ ما تحلُّ منهُ
   * بقيةُ المشروعِ حتى تجيءَ دورةُ الإصلاحِ التي تئتمنُ الفهرسَ عليهِ.
   */
  private void onAnalyzed(
      String name,
      List<CodeLanguageTools.Diagnostic> found,
      AnalyzerProtocol.Members members,
      AnalyzerProtocol.Reply reply) {
    diagnosticsInFlight = false;
    // القياسُ الوحيدُ الذي يُحرِّكُ الإيقاعَ: جَولةٌ رُدَّتْ على هذا الملفِّ، والاعتبارُ للقططةِ التي
    // فُحِصتْ لا للنصِّ الجاري — وإلّا كانَ الرقمُ ثمنَ عملٍ لم يُعمَلْ.
    if (name.equals(fileName) && analysisText != null)
      analysisPace.observe(
          android.os.SystemClock.uptimeMillis() - diagnosticsInFlightSince, analysisText.length());
    ProjectSymbolIndex.applyLiveMembers(name, members);
    if (found != null && name.equals(fileName)) {
      if (analysisDocumentVersion == getDocument().version()) {
        updateDiagnostics(found);
      } else {
        // نتيجة على لقطةٍ أقدمَ: تُنقَلُ إلى النصِّ الحاليِّ بدلَ رميِها، فيبقى الفحصُ حيًّا أثناءَ الكتابةِ.
        updateDiagnostics(almlk.LiveDiagnostics.remap(found, analysisText, currentText()));
      }
    }
    if (diagnosticsRerun) {
      diagnosticsRerun = false;
      scheduleDiagnostics(0);
    }
  }

  /**
   * حالةُ القناةِ (لا اتصالَ، رفضٌ، قطعُ العمليةِ، ضغطُ ذاكرةٍ، سقفٌ مُعلَنٌ): سطرُ سجلٍّ وفكُّ
   * الانتظارِ. ولا نافذةَ ولا شريطَ تقدُّمٍ — الفحصُ خدمةٌ خلفيةٌ تُخبِرُ عن حالِها ولا تُقاطِعُ.
   */
  private void onAnalyzerState(String state, String detail) {
    if (AnalyzerProtocol.STATE_OK.equals(state)) return;
    // W23/2: ردٌّ مَرفوضٌ أو بائتٌ لا يَترُكُ بصمةً مُعلَّقةً تُسقِطُ الفحصَ عن النصِّ الحاليِّ.
    inspectionScope.forget(fileName);
    // لا انتظارَ إلى أبدِ: الحالةُ تُنهِي الجولةَ كما يُنهِيها الردُّ، وإلا بقيَ المحرِّرُ رافضًا لفحصٍ جديدٍ.
    diagnosticsInFlight = false;
    Log.i("AlmlkEditor", "analyzer " + state + (detail == null || detail.isEmpty() ? "" : ": " + detail));
    if (diagnosticsRerun) {
      diagnosticsRerun = false;
      scheduleDiagnostics(0);
    }
  }

  /** عددُ ما في طابورِ الجلسةِ (للوصلاتِ وللتشخيصِ عن بُعدٍ): لا يقرَأُهُ شيءٌ من الواجهةِ. */
  public int analyzerQueueSize() {
    return analyzer.queue().size();
  }

  /** حالةُ التحليلِ المسمّاةُ: {@code idle|queued|sending|overflow} عندَنا، وحالةُ القناةِ عندَ العمليةِ. */
  public String analyzerState() {
    return analyzer.queue().state();
  }

  private void updateDiagnostics(List<CodeLanguageTools.Diagnostic> found) {
    if (analysisPaused) return;
    // W23/2 — سلامةُ الاستيرادِ تُحصَى هنا لا في ابنِ التحليلِ: معرفةُ المكتباتِ المُحمَّلةِ والمنصّةِ
    // تسكُنُ هذهِ العمليةَ (نفسُ العلةِ التي من أجلِها كانَ نُطَبِّقُ المُعرِّفاتِ الحيّةَ هنا)، وهي مشياتُ مجموعاتٍ لا
    // تحليلُ نصٍّ، فلا جمودَ عليها. وما لا يُثبَتُ يقينًا لا يُبلَغُ عنهُ أصلًا (الفهرسُ غيرُ كاملٍ ⇦ صمتٌ).
    List<CodeLanguageTools.Diagnostic> merged = withImportSoundness(found);
    diagnostics = merged == null ? Collections.emptyList() : new ArrayList<>(merged);
    inspectionScope.noteApplied(fileName, pendingInspectionRevision);
    applyInspectionMarks(diagnostics);
    rebuildDiagnosticDecorations();
    invalidate();
    invalidateSelectionActions(); // زر الإصلاح يظهر/يختفي حيًا في شريط التحديد المفتوح
    DiagnosticsListener listener = diagnosticsListener;
    if (listener != null) listener.onDiagnostics(getDiagnostics());
  }

  /** نصُّ سطرٍ الآنَ — لمراجعةِ أنَّ الوسمَ المشروعِيَّ ما زالَ على سطرِهِ (قـ٣، الجولةُ ‏33). */
  private String lineTextAt(int line) {
    LineDocument source = getDocument();
    if (source.lineCount() == 0) return "";
    int clamped = Math.max(0, Math.min(line, source.lineCount() - 1));
    return source.line(clamped).toString();
  }

  /**
   * جدولُ إزاحاتِ السطورِ للإصدارِ الجاري: إن كانَ طازجًا فالبلاطةُ الجاهزةُ، وإلا فبناءٌ واحدٌ
   * ‏O(lines) ثمَّ قراءةٌ ‏O(1) لكلِّ قفزةٍ بعدها.
   */
  public LineOffsetTable jumpOffsets() {
    LineDocument source = getDocument();
    LineOffsetTable cached = jumpOffsets;
    if (cached != null && cached.isFreshFor(source.version())) return cached;
    LineOffsetTable built = LineOffsetTable.build(source);
    jumpOffsets = built;
    return built;
  }

  /** سطرٌ بمخزنِهِ — للقفزةِ التي تَقرَأُ حروفَ الكلمةِ بلا نَسخِ المستندِ كلِّهِ. */
  public almlk.LineBuffer lineBufferAt(int line) {
    LineDocument source = getDocument();
    int count = source.lineCount();
    if (count == 0) return new almlk.LineBuffer();
    return source.line(Math.max(0, Math.min(line, count - 1)));
  }

  /** يبني فهرس المديات من نتيجة التحليل الحية وتشخيصات المشروع/البناء معًا. */
  private void rebuildDiagnosticDecorations() {
    ArrayList<DiagnosticSpanIndex.Span> spans = new ArrayList<>();
    for (CodeLanguageTools.Diagnostic item : diagnostics) {
      if (item != null)
        spans.add(diagnosticSpan(item, item.column + Math.max(1, item.end - item.offset)));
    }
    // W23/2 — كلُّ مواضعِ العنصرِ تُسطَّرُ بحمولتِهِ نفسِها، فيفتحُ النقرُ على أيِّها نفسَ الفقاعةِ:
    // المكرَّرُ مُشارٌ إليهِ حيثُ وُجِدَ، لا حيثُ شُخِصَ مرَّةً واحدةً.
    int[] marks = inspectionOccurrenceMarks;
    for (int k = 0; k + 4 < marks.length; k += 5) {
      int role = marks[k];
      int severity = MarkTable.severityOf(role);
      if (severity < 0) continue; // دورٌ نحوٌيّ: لونُهُ من لوحةِ المحرِّرِ، لا تَسطيرَ فوقَهُ
      // ‏2 = تلميحٌ أصفرُ: مَدارٌ للمحرِّرِ وحدَهُ، لا صفَّ في اللوحةِ ولا عدَّ شارةٍ.
      int line = marks[k + 1];
      int start = Math.max(0, marks[k + 2] - 1);
      int end = Math.max(start + 1, marks[k + 3] - 1);
      int group = marks[k + 4];
      int index = group - 1; // المجموعةُ تبدأُ من الواحدِ: صفرٌ عندَ المرجعِ يعني «بلا مجموعةٍ»
      CodeLanguageTools.Diagnostic payload =
          index >= 0 && index < diagnostics.size() ? diagnostics.get(index) : null;
      if (payload == null) continue; // لا حمولةَ: لا نَختَرِعُ سطيرًا يتيمًا بلا سببٍ خلفَهُ
      spans.add(diagnosticSpanAt(line, start, end, severity, payload));
    }
    for (ProjectDiagnostic item : projectDiagnostics) {
      if (item == null || item.diagnostic == null) continue;
      // قـ٣ (الجولةُ ‏33): وسمٌ حُسِبَ على سطرٍ ثمَّ حُرِّرَ ذلكَ السطرُ لم يعُدْ وسمَ هذا النصِّ، فلا
      // يُخاطُ على حروفٍ غيرِ التي شُخِصَ عليها. صفُّ اللوحةِ باقٍ: لوحةُ المشروعِ تصفُ الملفَّ لا المحرِّرَ.
      if (almlk.MarkBinding.isStale(item.preview, lineTextAt(item.diagnostic.line - 1))) continue;
      spans.add(diagnosticSpan(item.diagnostic, item.endColumn));
    }
    diagnosticSpans.replaceAll(spans);
  }

  private static DiagnosticSpanIndex.Span diagnosticSpan(
      CodeLanguageTools.Diagnostic diagnostic, int oneBasedEndColumn) {
    int line = Math.max(0, diagnostic.line - 1);
    int start = Math.max(0, diagnostic.column - 1);
    int end = Math.max(start + 1, oneBasedEndColumn - 1);
    return diagnosticSpanAt(line, start, end, familyOf(diagnostic), diagnostic);
  }

  /** أسرةُ التَسطيرِ من رتبةِ التشخيصِ: خطأٌ ‏0، إنذارٌ ‏1، تلميحُ محرِّرٍ ‏2 (شرطٌ دائمٌ ‏21). */
  private static int familyOf(CodeLanguageTools.Diagnostic diagnostic) {
    if (diagnostic.severity == CodeLanguageTools.Diagnostic.Severity.ERROR) return 0;
    if (diagnostic.severity == CodeLanguageTools.Diagnostic.Severity.WARNING) return 1;
    return 2;
  }

  private static DiagnosticSpanIndex.Span diagnosticSpanAt(
      int line, int start, int end, int family, Object payload) {
    if (family == 2) return DiagnosticSpanIndex.Span.hint(line, start, end, payload);
    return new DiagnosticSpanIndex.Span(line, start, end, family == 1, payload);
  }

  public List<CodeLanguageTools.Diagnostic> getDiagnostics() {
    return new ArrayList<>(diagnostics);
  }

  /** حالةُ المتابعةِ المتدرِّجةِ: {@code idle|tracking|capped} — تُقرأُ في اللوحةِ والوصلةِ لا في حوارٍ. */
  public String inspectionState() {
    return inspectionState;
  }

  /** سقوفُ الفحصِ المُعلَنةُ المستعمَلةُ مؤخرًا (تخطٍّ، سقفُ متابعةٍ، سقفُ مواضعَ): لا صمتَ عندَ الاقتصاصِ. */
  public List<String> inspectionProblems() {
    return inspectionProblems;
  }

  /** عددُ العلاماتِ في الصفيحةِ الحيّةِ — تُثبِتُ البوابةُ أنَ التزيينَ تعدَّدَ فعلاً لا في الردِّ وحدَهُ. */
  public int inspectionMarkCount() {
    return inspectionMarks.size();
  }

  /** كم علامةٌ بهذا الدورِ في الصفيحةِ الحيّةِ؟ (التكرارُ والإنذارُ والخطأُ تُعَدُّ كلُّها على حدةٍ). */
  public int inspectionMarkCount(int role) {
    return inspectionMarks.countOf(role);
  }

  /**
   * دورُ العنصرِ تحتَ الموضعِ (‏-1 عندَ انعدامِ العلامةِ): الخطأُ وأدوارُ الفحصِ تسبقُ التلوينَ في الجدولِ
   * نفسِهِ، فلا تُظلِمُ لوحةَ التفاصيلِ علامةُ نحوٍ فاتتَ على مَكرَّرٍ.
   */
  public int inspectionRoleAt(int zeroBasedLine, int oneBasedColumn) {
    int[] mark = inspectionMarks.markAt(zeroBasedLine, oneBasedColumn);
    return mark == null ? -1 : mark[0];
  }

  /** يَنسَخُ جولةً كاملةً تاليةً (بعدَ تغيُّرِ سياقِ المشروعِ أو المكتباتِ): تُطرَدُ البصمةُ لا التشخيصاتُ. */
  public void forceFullInspection() {
    inspectionScope.forget(fileName);
    inspectionState = inspectionScope.state();
  }

  /** عَدُّ الفحصِ المتدرِّجِ: طلباتٌ، وتخطٍّ، ومُخرَجونَ من المتابعةِ — للوحةِ التفاصيلِ والوصلاتِ. */
  public String inspectionCounters() {
    return "tracked=" + inspectionScope.trackedCount() + " requested=" + inspectionScope.requestedCount()
        + " skipped=" + inspectionScope.skippedCount() + " evicted=" + inspectionScope.evictedCount()
        + " marks=" + inspectionMarks.size() + " swaps=" + inspectionMarks.swapsCount()
        + " dropped=" + inspectionMarks.droppedCount() + " stale=" + inspectionMarks.staleRejectedCount();
  }

  /** الدورُ الذي يُميَّزُ بهِ التشخيصُ: للتكرارِ دورُهُ المستقلُّ لأنَّهُ يُبرَزُ في كلِّ مواضعِهِ. */
  private static int roleFor(CodeLanguageTools.Diagnostic item) {
    String key = item.messageKey;
    if (key != null && key.startsWith("ui_diagnostic_duplicate")) return MarkTable.ROLE_DUPLICATE;
    if (key != null && key.endsWith("_import")) {
      return item.severity == CodeLanguageTools.Diagnostic.Severity.WARNING
          ? MarkTable.ROLE_UNUSED_IMPORT
          : MarkTable.ROLE_IMPORT;
    }
    if (item.severity == CodeLanguageTools.Diagnostic.Severity.INFO) return MarkTable.ROLE_HINT;
    return item.severity == CodeLanguageTools.Diagnostic.Severity.WARNING
        ? MarkTable.ROLE_WARNING
        : MarkTable.ROLE_ERROR;
  }

  /** صفيحةً صافيةً ثمَّ قلبًا: لا وميضَ بينَ ردَّينِ، ولا بقايا علاماتٍ من نصٍّ سابقٍ. */
  private void applyInspectionMarks(List<CodeLanguageTools.Diagnostic> found) {
    inspectionMarks.begin();
    String text = currentText();
    int group = 1; // صفرٌ = بلا مجموعةٍ في جدولِ العلاماتِ، فلا يبدأُ التزيينُ منهُ
    ArrayList<Integer> flat = new ArrayList<>();
    if (found != null) {
      for (CodeLanguageTools.Diagnostic item : found) {
        int role = item == null ? MarkTable.ROLE_ERROR : roleFor(item);
        if (item != null && item.hasOccurrences()) {
          int[] marks = IdentifierOccurrences.toMarks(text, item.occStarts, item.occEnds, role, group);
          for (int m = 0; m + 4 < marks.length; m += 5) {
            inspectionMarks.append(marks[m], marks[m + 1], marks[m + 2], marks[m + 3], group);
            flat.add(marks[m]);
            flat.add(marks[m + 1]);
            flat.add(marks[m + 2]);
            flat.add(marks[m + 3]);
            flat.add(marks[m + 4]);
          }
        } else if (item != null) {
          int end = item.column + Math.max(1, item.end - item.offset);
          inspectionMarks.append(role, item.line - 1, item.column, end, group);
        }
        group++;
      }
    }
    int[] out = new int[flat.size()];
    for (int i = 0; i < out.length; i++) out[i] = flat.get(i);
    inspectionOccurrenceMarks = out;
    if (inspectionMarks.commit(inspectionRevision + 1L)) inspectionRevision++;
  }

  /** حالاتُ الاستيرادِ الستُّ — تُضافُ إلى ما جاءَ من ابنِ التحليلِ، ولا تُزاحِمُ تشخيصًا قالَهُ هو. */
  private List<CodeLanguageTools.Diagnostic> withImportSoundness(
      List<CodeLanguageTools.Diagnostic> found) {
    if (fileName == null || !fileName.endsWith(".java")) return found;
    String text = currentText();
    if (text.isEmpty()) return found;
    ImportSoundness.Result result =
        ImportSoundness.check(
            text,
            almlk.JavaImportResolver.currentPackage(text),
            new ProjectImportResolver(text),
            pendingInspectionFrom,
            pendingInspectionTo);
    if (result == null || result.issues.isEmpty()) return found;
    if (result.isClipped()) inspectionProblems = result.problems;
    ArrayList<CodeLanguageTools.Diagnostic> out =
        found == null ? new ArrayList<CodeLanguageTools.Diagnostic>() : new ArrayList<>(found);
    // 1.0.176: دفعةُ الحذفِ واحدةٌ لكلِّ الملفِّ (كما يَعرِضُ المرجعُ «Fix imports» صَفًّا واحدًا): سِجلُّ
    // عملياتٍ مَبنِيٌّ من نصٍّ حيٍّ يُعادُ بناؤُهُ عندَ الطلبِ، فالتطويقُ لا يكونُ على سطرٍ تحرَّكَ.
    almlk.ImportFixActions.Tally actionTally = new almlk.ImportFixActions.Tally();
    almlk.ImportFixActions.Plan batch =
        almlk.ImportFixActions.planForIssues(
            text, result.issues, actionTally, pendingInspectionFrom, pendingInspectionTo);
    for (ImportSoundness.Issue issue : result.issues) {
      if (alreadyReported(out, issue)) continue;
      out.add(importDiagnostic(text, issue, batch));
    }
    return out;
  }

  /** هل قالَ ابنُ التحليلِ هذا نفسَهُ؟ (استيرادٌ مجهولٌ عندَهُ مُقابِلُ Unknown import عندَنا). */
  private static boolean alreadyReported(List<CodeLanguageTools.Diagnostic> items, ImportSoundness.Issue issue) {
    for (CodeLanguageTools.Diagnostic item : items) {
      if (item == null || item.messageKey == null) continue;
      if (!item.messageKey.endsWith("_import")) continue;
      if (item.offset == issue.start || (issue.start >= item.offset && issue.end <= item.end)) return true;
    }
    return false;
  }

  private CodeLanguageTools.Diagnostic importDiagnostic(
      String text, ImportSoundness.Issue issue, almlk.ImportFixActions.Plan batch) {
    int line = 1;
    int lineStart = 0;
    for (int i = 0; i < issue.start && i < text.length(); i++) {
      if (text.charAt(i) == '\n') {
        line++;
        lineStart = i + 1;
      }
    }
    int column = issue.start - lineStart + 1;
    int width = Math.max(1, issue.end - issue.start);
    int[] starts = new int[issue.occurrences.length / 3];
    int[] ends = new int[starts.length];
    for (int i = 0; i < starts.length; i++) {
      starts[i] = issue.occurrences[i * 3];
      ends[i] = issue.occurrences[i * 3 + 1];
    }
    String key = ImportSoundness.messageKey(issue.kind);
    String message = localized(key, issue.name);
    // 1.0.175: «Fetch library» على الاستيرادِ غيرِ المحلولِ — لا تُنسَجُ الإحداثيّةُ هُنا (لا قرصَ في خيطِ
    // الواجهةِ)، بل يُحمَلُ الصنفُ المؤهَّلُ في الإصلاحِ ويُخطَّطُ على خيطِ المشروعِ عندَ الطلبِ.
    java.util.List<almlk.QuickFix> fixes = java.util.Collections.emptyList();
    if (issue.kind == ImportSoundness.KIND_MISSING || issue.kind == ImportSoundness.KIND_UNKNOWN) {
      almlk.QuickFix fetch = almlk.QuickFix.fetchDependency(issue.qualifiedName, issue.name);
      if (fetch != null) fixes = java.util.Collections.singletonList(fetch);
    } else if (almlk.ImportFixActions.isRemovable(issue.kind)) {
      almlk.QuickFix remove = almlk.QuickFix.removeImports(batch);
      if (remove != null) fixes = java.util.Collections.singletonList(remove);
    }
    CodeLanguageTools.Diagnostic diagnostic =
        CodeLanguageTools.Diagnostic.restored(
                issue.start,
                issue.start + width,
                line,
                column,
                ImportSoundness.isWarning(issue.kind)
                    ? CodeLanguageTools.Diagnostic.Severity.WARNING
                    : CodeLanguageTools.Diagnostic.Severity.ERROR,
                almlk.JavaDiagnosticCodes.UNCLASSIFIED,
                message,
                key,
                new Object[] {issue.name})
            .withQuickFixes(fixes);
    return starts.length == 0 ? diagnostic : diagnostic.withOccurrences(starts, ends);
  }

  /** عنوانٌ من الموردِ بمفتاحٍ معلومٍ؛ غيابُهُ لا يُسكِتُ التشخيصَ بل يُظهرُ المفتاحَ للتشخيصِ نفسِهِ. */
  private String localized(String key, String argument) {
    int id = getResources().getIdentifier(key, "string", getContext().getPackageName());
    if (id == 0) return key;
    try {
      return getContext().getString(id, argument);
    } catch (RuntimeException shape) {
      return getResources().getString(id); // مفتاحٌ بلا وسيطٍ: لا نُطفئُ التشخيصَ من أجلِ صيغةٍ
    }
  }

  /** حَلُّ الأسماءِ على الطبقاتِ الثلاثِ: المشروعُ، والمنصّةُ، والمكتباتُ المُحمَّلةُ والمحلّيّةُ. */
  private static final class ProjectImportResolver implements ImportSoundness.Resolver {
    private final String source;

    ProjectImportResolver(String source) {
      this.source = source == null ? "" : source;
    }

    @Override
    public boolean provides(String qualifiedName) {
      if (qualifiedName == null) return false;
      int dot = qualifiedName.lastIndexOf('.');
      if (dot <= 0 || dot == qualifiedName.length() - 1) return false;
      String pkg = qualifiedName.substring(0, dot);
      String simple = qualifiedName.substring(dot + 1);
      // الفهرسُ غيرُ الكاملِ لا يُجيَبُ عن «غيرُ موجودٍ» — وإلا صارَ كلُّ صنفٍ في مكتبةٍ لم تُفهرَسْ خطأً.
      if (almlk.LibraryClassIndex.importsCheckable(pkg, simple)) return true;
      if (almlk.JavaImportResolver.provides(pkg, simple)) return true;
      return ProjectSymbolIndex.knowsClass(qualifiedName) || ProjectSymbolIndex.knowsClass(simple);
    }

    @Override
    public boolean availableWithoutImport(String simpleName, String filePackage) {
      if (simpleName == null || simpleName.isEmpty()) return false;
      // «الاسمُ محسومٌ بلا استيرادٍ» سؤالٌ واحدٌ عندَنا: {@code resolution} يُجيبُ — java.lang، أو باقةُ
      // الملفِّ، أو استيرادٌ صريحٌ يَثبِتُهُ. لا نَختَرِعُ إعفاءً بمعاينةِ البادئةِ: «صنفٌ تحتَ java.lang»
      // حُكمٌ على اسمٍ لا على وجودِهِ، وإلا صارَ كلُّ اسمٍ مُختلَقٍ مُعفى من الفحصِ.
      almlk.JavaImportResolver.Resolution resolution =
          almlk.JavaImportResolver.resolution(
              simpleName, filePackage == null || filePackage.isEmpty() ? null : filePackage, source);
      return resolution != null && resolution.kind == almlk.JavaImportResolver.Resolution.Kind.LOCAL;
    }

    @Override
    public boolean ambiguousByWildcard(String simpleName, String[] wildcardPackages) {
      if (simpleName == null || wildcardPackages == null) return false;
      int hits = 0;
      for (String pkg : wildcardPackages) {
        if (pkg == null) continue;
        if (almlk.JavaImportResolver.provides(pkg, simpleName)
            || almlk.LibraryClassIndex.importsCheckable(pkg, simpleName)) {
          hits++;
          if (hits > 1) return true;
        }
      }
      // وغموضُ المُرشَّحِ نفسِهِ الذي يَراهُ مُنسِّقُ الاستيرادِ (باقةُ المشروعِ والمنصّةُ معًا) يُبلَّغُ بِهِ
      // عندَ الاستعمالِ، لا عندَ السطرِ: لا حُزمةً تُختارُ بالترتيبِ ولا بصمتٍ.
      return hits == 1
          && almlk.JavaImportResolver.resolution(
                  simpleName, almlk.JavaImportResolver.currentPackage(source), source)
              .isAmbiguous();
    }

    @Override
    public String uniqueCandidate(String simpleName) {
      if (simpleName == null || simpleName.isEmpty()) return null;
      almlk.JavaImportResolver.Resolution resolution =
          almlk.JavaImportResolver.resolution(
              simpleName, almlk.JavaImportResolver.currentPackage(source), source);
      return resolution != null && resolution.isFixable() ? resolution.qualifiedName : null;
    }
  }

  // ---------------- المرحلة 5: نقاط التوقف ----------------
  /** يبدّل نقطة توقف عند سطر المؤشر؛ يعيد true إن صارت مضبوطة. */
  public boolean toggleBreakpointAtCaret() {
    int line = lineOfOffset(getSelectionStart());
    boolean nowSet;
    synchronized (breakpoints) {
      if (breakpoints.contains(line)) { breakpoints.remove(line); nowSet = false; }
      else { breakpoints.add(line); nowSet = true; }
    }
    invalidate();
    return nowSet;
  }

  public boolean hasBreakpoint(int line) {
    synchronized (breakpoints) { return breakpoints.contains(line); }
  }

  private int lineOfOffset(int offset) {
    String t = currentText();
    int n = Math.max(0, Math.min(offset, t.length()));
    int line = 0;
    for (int i = 0; i < n; i++) if (t.charAt(i) == '\n') line++;
    return line;
  }

  // ---------------- الثيم والألوان ----------------

  /**
   * يملأُ لوحتَيِ الأنماطِ من جدولِ الأدوارِ لا من أسماءِ حقولٍ مفردة: لونُ كلِّ نمطٍ هو لونُ دورِهِ في
   * اللوحةِ النشِطة، وعلامتُهُ غامقٌ أو مائلٌ كما عندَ المصدر. تُقرأُ اللوحتانِ في الرسمِ قراءةً مباشرةً
   * بالمُعامِل، فتصيرُ تلوينَةُ الكتابةِ أثناءَ الإدخالِ نفسَ تلوينَةِ الملوّح: مصدرٌ واحدٌ لا مسارَان.
   */
  public void applyTheme() {
    ThemeConfig theme = new ThemeConfig(getContext());
    boolean light = theme.isLight();
    for (int styleId = 0; styleId < EditorSyntaxRoles.PALETTE_SIZE; styleId++) {
      String role = EditorSyntaxRoles.paletteKey(styleId);
      styleColors[styleId] = theme.color(role, !light);
      styleFlags[styleId] = EditorSyntaxRoles.flagsFor(styleId);
    }
    plainColor = styleColors[0];

    // عمودُ الترقيمِ هو سطحُ المحرِّرِ نفسِهِ لا لوحةً فوقَهُ: لا لونَ لهُ في اللوحةِ ولا ظلَّ. وكانَ
    // الظلُّ يُصنَعُ بضربِ كلِّ قناةٍ في 1.15 ثمَّ إقناعِها بـ&0xFF — وعلى خلفيةٍ بيضاءَ يصيرُ
    // 255×1.15 = 293 أي 37 بعدَ القصِّ: فحمٌ على بياضٍ، وهو الشريطُ المنفصلُ الذي بلَّغتَ عنهُ.
    // أمّا رقمُ السطرِ فلونُهُ الخاصُّ بهِ من اللوحةِ وحدَها: LINE_NUMBER.
    int background = theme.color(ThemeConfig.BACKGROUND, !light);
    setEditorColors(
        plainColor,
        theme.color(ThemeConfig.LINE_NUMBER, !light),
        background,
        theme.color(ThemeConfig.LINE_BACKGROUND, !light),
        theme.color(ThemeConfig.SELECTED_BACKGROUND, !light),
        plainColor,
        theme.color(ThemeConfig.OPERATOR, !light));
    setFlagColors(0xFFEF5350, 0xFFFFA726, 0xFFEC407A, 0xFF42A5F5);
    // التلميحُ أصفرُ: فاتحُ الثيمِ يَطلُبُ أصفَرَ غامقًا يُرى على البياضِ، وداكِنُهُ أصفَرَ ساطعًا.
    setHintFlagColor(light ? 0xFFF9A825 : 0xFFFFEE58);
    refreshNow();
    // الثيمُ لا يُنتظَرُ أن «يَستَقِرَّ»: جدولُ الأنماطِ إن لم يَكُنْ مَبنيًّا بَنيناهُ الآنَ، وإلّا
    // صارَ تبدُّلُ الثيمِ سببَ بياضٍ كما بلَّغتَ (‏1.0.189).
    ensureColorsVisibleNow();
  }

  /** لونُ نمطٍ لغويٍّ في اللوحةِ النشِطة — من cacheِ الأدوار، لا من جدولِ ألوانٍ مكررٍ هُنا. */
  public int colorFor(int type) {
    return type >= 0 && type < styleColors.length ? styleColors[type] : plainColor;
  }

  /** غمقٌ/ميلٌ كما قرّرَهُ جدولُ الأدوار: المفتاحُ والعليقةُ غامقان، الباقةُ مائلة، والاستدعاءاتُ سادة. */
  public int flagsFor(int type) {
    return type >= 0 && type < styleFlags.length ? styleFlags[type] : EditorSyntaxRoles.FLAG_NONE;
  }

  // ---------------- دورة الحياة ----------------

  @Override
  protected void onDetachedFromWindow() {
    removeCallbacks(diagnosticsTask);
    errorPopup.dismiss();
    // تعليقٌ لا إغراقٌ: جدولُ الأنماطِ يبقى منشورًا، فتعودُ الصفحةُ مُلوَّنةً من أوَّلِ إطارٍ.
    styler.suspend();
    analyzer.detach();
    diagnosticsInFlight = false;
    diagnosticsPendingSince = 0;
    analysisText = "";
    super.onDetachedFromWindow();
  }

  @Override
  protected void onAttachedToWindow() {
    super.onAttachedToWindow();
    // انفصالٌ سابقٌ قطَعَ الربطَ ومحَصَ الطابورَ: عودةٌ إلى النافذةِ تعيدُ الجلسةَ حيّةً بلا انتظارِ كتابةٍ.
    analyzer.attach(getContext());
    // والملوِّنُ يَستأنِفُ ما ناقصٌ فقط — ولا يُعادُ بناءُ ما لم يَمسَّسْهُ النصُّ (شرطٌ دائمٌ ‏20).
    styler.resume();
    // ثمَّ فحصُ الظاهرِ: عودةُ تبويبٍ إلى النافذةِ تَجِدُ لونَها في أوَّلِ إطارٍ.
    ensureColorsVisibleNow();
  }
}
