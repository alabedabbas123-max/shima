package com.almlkid.analyzer;

import almlk.AnalyzerProtocol;
import almlk.IdentifierOccurrences;
import almlk.QuickFix;
import com.almlkid.kay.ui.CodeLanguageTools;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * تحويلُ التشخيصِ والإصلاحِ بينَ شكلِهما في المحرِّرِ وشكلِهما على السِّلكِ (المرحلةُ ١ من عزلِ المُحرِّكِ).
 *
 * <p>لا ‏android‏ هنا عمدًا: هذا الملفُّ في قائمةِ {@code qa.sh} الصافيةِ، فترتيبُ الحقولِ — وهو أسرعُ موضعٍ
 * لخطإٍ صامتٍ في أيِّ جسرٍ بينَ العملياتِ — مُغطًّى بـ{@code RegressionSuite} لا بالبناءِ وحدَه.
 *
 * <p>ما يُرسَلُ وما لا يُرسَلُ: تُرسَلُ الرسالةُ بمفتاحِها ووسومِها لأنَّ الواجهةَ تعيدُ توليدَ النصِّ
 * المحليِّ عندَ تغيّرِ اللغَةِ ({@code UiStrings.format})، وتُرسَلُ الإصلاحاتُ معَ تشخيصِها كما في المرجعِ
 * ({@code SyntaxError.tp: String[]} — عناوينُ الإصلاحِ تَسبِقُ الطلبَ فلا تُحاوِرُ الواجهةُ المُحرِّكَ عندَ
 * كلِّ نقرةٍ). ولا يُرسَلُ شيءٌ من حالةِ المحرِّرِ (المؤشرُ، المنظرُ): التحليلُ لا يَقرؤُها، فَبُقيَت هنا.
 */
public final class AnalyzerWire {

  private AnalyzerWire() {}

  /** تشخيصاتُ المحرِّرِ ← حِملٌ سِلكيٌّ (بلا تكرارٍ، وبِسقفِ العددِ في {@code Builder}). */
  public static AnalyzerProtocol.Finding[] encode(List<CodeLanguageTools.Diagnostic> items) {
    if (items == null || items.isEmpty()) return new AnalyzerProtocol.Finding[0];
    ArrayList<AnalyzerProtocol.Finding> out = new ArrayList<>(items.size());
    for (CodeLanguageTools.Diagnostic item : items) {
      if (item == null) continue;
      out.add(encode(item));
    }
    return out.toArray(new AnalyzerProtocol.Finding[0]);
  }

  /** تشخيصٌ واحدٌ ← حِملٌ سِلكيٌّ: الحقولُ العشرةُ بنفسِ ترتيبِ {@code CodeLanguageTools.Diagnostic}. */
  public static AnalyzerProtocol.Finding encode(CodeLanguageTools.Diagnostic item) {
    Object[] args = item.messageArgs == null ? new Object[0] : item.messageArgs;
    char[] tags = new char[args.length];
    String[] values = new String[args.length];
    for (int i = 0; i < args.length; i++) {
      if (args[i] instanceof Integer || args[i] instanceof Long) {
        tags[i] = 'i';
        values[i] = String.valueOf(args[i]);
      } else {
        tags[i] = 's';
        values[i] = args[i] == null ? "" : String.valueOf(args[i]);
      }
    }
    List<QuickFix> fixes = item.quickFixes;
    AnalyzerProtocol.Fix[] encoded =
        fixes == null || fixes.isEmpty()
            ? new AnalyzerProtocol.Fix[0]
            : new AnalyzerProtocol.Fix[fixes.size()];
    if (fixes != null) {
      for (int i = 0; i < fixes.size(); i++) encoded[i] = encode(fixes.get(i));
    }
    return new AnalyzerProtocol.Finding(
        item.offset,
        item.end,
        item.line,
        item.column,
        item.severity == null
            ? AnalyzerProtocol.SEVERITY_ERROR
            : item.severity.ordinal(),
        item.code,
        item.message,
        item.messageKey,
        tags,
        values,
        encoded);
  }

  /** حِملٌ سِلكيٌّ ← تشخيصاتُ المحرِّرِ، عبرَ مُنشِئِ الاستعادةِ القائمِ {@code Diagnostic.restored}. */
  public static List<CodeLanguageTools.Diagnostic> decode(AnalyzerProtocol.Finding[] wire) {
    if (wire == null || wire.length == 0) return Collections.emptyList();
    ArrayList<CodeLanguageTools.Diagnostic> out = new ArrayList<>(wire.length);
    for (AnalyzerProtocol.Finding f : wire) {
      if (f == null) continue;
      Object[] args = new Object[f.argValues.length];
      for (int i = 0; i < args.length; i++) {
        args[i] = f.argTags.length > i && f.argTags[i] == 'i' ? (Object) parseInt(f.argValues[i]) : f.argValues[i];
      }
      List<QuickFix> fixes = new ArrayList<>(f.fixes.length);
      for (AnalyzerProtocol.Fix x : f.fixes) {
        QuickFix fix = decode(x);
        if (fix != null) fixes.add(fix);
      }
      CodeLanguageTools.Diagnostic.Severity[] values = CodeLanguageTools.Diagnostic.Severity.values();
      CodeLanguageTools.Diagnostic.Severity severity =
          f.severity >= 0 && f.severity < values.length ? values[f.severity] : values[values.length - 1];
      out.add(
          CodeLanguageTools.Diagnostic.restored(
                  f.offset, f.end, f.line, f.column, severity, f.code, f.message, f.messageKey, args)
              // W23/2: المواضعُ كلُّها تعبرُ السِّلكَ معَ تشخيصِها، فلا يُرسَمُ التسطيرُ على أوَّلِها فقط.
              .withQuickFixes(fixes)
              .withOccurrences(f.occStarts, f.occEnds));
    }
    return out;
  }

  /**
   * توسيعُ تشخيصاتِ التكرارِ إلى كلِّ مواضعِ العنصرِ (البندُ الأولُ من طلبِ الجولةِ ‏24/2: «على جميعِ
   * مواضعِ تواجدهِ لا في موضعٍ واحدٍ»). يعملُ في ابنِ التحليلِ حيثُ النصُّ كاملٌ طازجٌ، فيَستغني المُحرِّرُ
   * عن أيِّ مسحٍ عندَ التطبيقِ. السقفُ {@link AnalyzerProtocol#MAX_OCCURRENCES} تُطبِقُهُ {@code
   * AnalyzerProtocol.Builder#clamp} ويَعدُّ الزيادةَ في {@code dropped}؛ وما لا وسيطَ لهُ يبقى بلا توسيعٍ
   * — لا نَختَرِعُ اسمًا لم نَقرَؤُهُ.
   */
  public static AnalyzerProtocol.Finding[] withOccurrences(String text, AnalyzerProtocol.Finding[] items) {
    if (text == null || items == null) return items;
    for (int i = 0; i < items.length; i++) {
      AnalyzerProtocol.Finding f = items[i];
      if (f == null || !isDuplicateFamily(f.messageKey) || f.hasOccurrences()) continue;
      String name = f.argValues.length > 0 ? f.argValues[0] : "";
      if (name == null || name.isEmpty()) continue;
      int[] flat = IdentifierOccurrences.findAll(text, name, 0, text.length());
      if (flat.length < 6) continue; // أقلُّ من ثلاثةِ مواضعَ: لا سلسلةَ تكرارٍ تُربَطُ هُنا
      int count = Math.min(flat.length / 3, AnalyzerProtocol.MAX_OCCURRENCES);
      int[] starts = new int[count];
      int[] ends = new int[count];
      for (int k = 0; k < count; k++) {
        starts[k] = flat[k * 3];
        ends[k] = flat[k * 3 + 1];
      }
      items[i] =
          new AnalyzerProtocol.Finding(
              f.offset, f.end, f.line, f.column, f.severity, f.code, f.message, f.messageKey, f.argTags,
              f.argValues, f.fixes, starts, ends);
    }
    return items;
  }

  /** عائلةُ التكرارِ كلُّها: متغيِّرٌ، حقلٌ، دالةٌ، صنفٌ، واصفٌ، حالةٌ، افتراضٌ، مُنشِئٌ، واسمُ مُعامِلٍ. */
  public static boolean isDuplicateFamily(String messageKey) {
    return messageKey != null && messageKey.startsWith("ui_diagnostic_duplicate");
  }

  // ─────────────────────────── الإصلاحُ ───────────────────────────

  /**
   * {@code QuickFix} ← حِملُهُ: الحقولُ الاثنا عشرَ التي تُعيدهُ كما كانَ، بلا إعادةِ حسابٍ، وعَلمُ
   * التغطيةِ وبَقِيَّةُ الدَّفعَةِ من ‏1.0.191‏ — لأنَّ الدَّفعَةَ إذا نَقَصَها سِلكٌ أعادَها صِفرًا.
   */
  public static AnalyzerProtocol.Fix encode(QuickFix fix) {
    if (fix == null) return null;
    int params = fix.params == null ? 0 : fix.params.size();
    String[] types = new String[params];
    String[] names = new String[params];
    for (int i = 0; i < params; i++) {
      QuickFix.Param param = fix.params.get(i);
      types[i] = param == null ? "" : param.type;
      names[i] = param == null ? "" : param.name;
    }
    AnalyzerProtocol.Fix[] companions =
        fix.companions == null || fix.companions.isEmpty()
            ? new AnalyzerProtocol.Fix[0]
            : new AnalyzerProtocol.Fix[fix.companions.size()];
    if (companions.length > 0) {
      int at = 0;
      for (QuickFix companion : fix.companions) {
        AnalyzerProtocol.Fix encoded = encode(companion);
        if (encoded == null) {
          // رفيقٌ لا يُرمَزُ: الدَّفعَةُ كلُّها تَسقُطُ إلى «لا إصلاحَ» — لا نِصفَ دَفعَةٍ يَكتُبُها المُحرِّرُ.
          return null;
        }
        companions[at++] = encoded;
      }
    }
    return new AnalyzerProtocol.Fix(
        fix.kind == null ? "" : fix.kind.name(),
        fix.targetClass,
        fix.returnType,
        fix.methodName,
        fix.importName,
        fix.titleKey,
        fix.titleArg,
        fix.expected,
        types,
        names,
        fix.isStatic,
        fix.insertOffset,
        fix.editEnd,
        fix.overrides,
        companions,
        fix.importsToFetch == null || fix.importsToFetch.isEmpty()
            ? new String[0]
            : fix.importsToFetch.toArray(new String[0]));
  }

  /** حِملُ الإصلاحِ ← {@code QuickFix.restored}: نفسُ البنيةِ، لا إعادةَ توليدِ نصٍّ من المُحرِّرِ. */
  public static QuickFix decode(AnalyzerProtocol.Fix x) {
    if (x == null) return null;
    QuickFix.Kind kind;
    try {
      kind = QuickFix.Kind.valueOf(x.kind);
    } catch (IllegalArgumentException | NullPointerException unknown) {
      return null;
    }
    ArrayList<QuickFix.Param> params = new ArrayList<>(x.paramTypes.length);
    for (int i = 0; i < Math.min(x.paramTypes.length, x.paramNames.length); i++) {
      params.add(new QuickFix.Param(x.paramTypes[i], x.paramNames[i]));
    }
    QuickFix fix =
        QuickFix.restored(
            kind, x.targetClass, x.returnType, x.methodName, params, x.isStatic, x.importName,
            x.titleKey, x.titleArg, x.expected, x.insertOffset, x.editEnd);
    // ‏1.0.191: عَلمُ التغطيةِ والدَّفعَةُ وأسطرُها حقائقُ عن صِفةِ المُحرِّكِ ومَولودِهِ، فلا تُعادُ
    // حسابًا ههنا — تُنقَلُ كما هِيَ؛ وأمّا «أفي الملفِّ سطرُها؟» فسؤالٌ عنِ النصِّ الحيِّ يُترَكُ له.
    fix.overrides = x.overrides;
    if (x.imports.length > 0) {
      fix.withImports(new ArrayList<String>(java.util.Arrays.asList(x.imports)));
    }
    if (x.companions.length > 0) {
      ArrayList<QuickFix> companions = new ArrayList<>(x.companions.length);
      for (AnalyzerProtocol.Fix c : x.companions) {
        QuickFix member = decodeCompanion(c, x.targetClass);
        if (member == null) return null;
        companions.add(member);
      }
      fix.companions = java.util.Collections.unmodifiableList(companions);
    }
    return fix;
  }

  /** رفيقُ الدَّفعَةِ: توقيعٌ وجِسمٌ فقطِ — العنوانُ والمِرناءُ للرأسِ وحدَهُ في كلِّ صيغةِ الدَّفعَةِ. */
  private static QuickFix decodeCompanion(AnalyzerProtocol.Fix c, String targetClass) {
    if (c == null) return null;
    if (!QuickFix.Kind.CREATE_METHOD.name().equals(c.kind)) return null;
    ArrayList<QuickFix.Param> params = new ArrayList<>(c.paramTypes.length);
    for (int i = 0; i < Math.min(c.paramTypes.length, c.paramNames.length); i++) {
      params.add(new QuickFix.Param(c.paramTypes[i], c.paramNames[i]));
    }
    QuickFix member =
        QuickFix.restored(
            QuickFix.Kind.CREATE_METHOD, targetClass, c.returnType, c.methodName, params, false, "",
            "", "", "", -1, -1);
    member.overrides = c.overrides;
    return member;
  }

  private static Integer parseInt(String value) {
    try {
      return Integer.valueOf(value);
    } catch (RuntimeException malformed) {
      return 0;
    }
  }
}
